local __digground = {}
local kMoveByDistance = 100
local kJumpDis = 64
local kRandomM = 36
local kPromptZorder = 10
--���õ�ǰѡ�еĹ�������
function __digground.setSelectedMonsterItem(obj,monsterItem)
    obj._selectedMonsterItem = monsterItem
end
--��ȡ��ǰѡ�еĹ�������
function __digground.getSelectedMonsterItem(obj)
   return obj._selectedMonsterItem
end
--���õ�ǰѡ�еĹ���
function __digground.setSelectedMonster(obj,monster)
    obj._selectedMonster = monster
end
--��ȡ��ǰѡ�еĹ���
function __digground.getSelectedMonster(obj)
   return obj._selectedMonster
end
--���õ�ǰѡ�еĿ�
function __digground.setSelectedResCar(obj,rescar)
    obj._selectedResCar = rescar
end
--��ȡ��ǰѡ�еĿ�
function __digground.getSelectedResCar(obj)
   return obj._selectedResCar
end
--���ù�
function __digground.sendMonsterTo(obj,idx,posX,posY)
    local diglayer = AccountHelper:get(kDigHole)
    local blocklayer = obj._blocklayer
    local creaturelayer = obj._creaturelayer
	--�������0ʱȡ��ѡ�񣨹����������㣩
	local monsterid = obj._selectedMonsterItem:getMonsterID()
     if account_data.monsterPool[monsterid].n <= 0 then 
        obj._selectedMonsterItem:setSelected(false)
        obj._selectedMonsterItem = nil
        diglayer:hideUsingPt()
		return
     end
    --����λ��Ϊδ�ھ������,��ʾ֮��ȡ��ѡ��(��Ҫ�ѿ��ѵ�����)
    if  not blocklayer:isDigged(idx) then 
        obj:showPropMsg(TxtList.digPrompt[2],posX,posY) 
        obj._selectedMonsterItem:setSelected(false)
        obj._selectedMonsterItem = nil
        diglayer:hideUsingPt()
        return
    end
    --����λ������Դ������ʾ��ȡ��ѡ����Ҫ�յأ�
    if creaturelayer:hasResCar(idx) then
        obj:showPropMsg(TxtList.digPrompt[3],posX,posY) 
        return
    end
    --����λ��������
    if creaturelayer:hasMonser(idx) then --�ж��Ƿ��ѷ��ù�
        local monster = creaturelayer:getMonsterByIdx(idx)
        diglayer:showDel(true)
        obj._selectedMonster = monster
        obj._selectedMonster:setSelected(true)
        creaturelayer:selectFlagAt(idx,true)
        obj._selectedMonsterItem:setSelected(false)
        obj._selectedMonsterItem = nil
        diglayer:hideUsingPt()
        SoundHelper.playEffect(SoundList.click_monster_dig)
		return
    end
	obj:doSendMonsterTo(idx)
    
end
function __digground.doSendMonsterTo(obj,idx)
	 local diglayer = AccountHelper:get(kDigHole)
     local monsterid = obj._selectedMonsterItem:getMonsterID()
     local consume = obj._selectedMonsterItem:getConsume()
     local left = account_data.maxDigPt - account_data.digPt - (account_data.usedPt + consume)
     SoundHelper.playEffect(SoundList.click_monster_dig)
     if left<0 then  --ʣ�����ֲ����Բ��õ�ǰ��ʱ��ȡ��ѡ�񣨹����������㣩
          obj._selectedMonsterItem:setSelected(false)
          obj._selectedMonsterItem = nil
          diglayer:hideUsingPt()
     else
         local lv = obj._d_data.monsterLvLook[monsterid]
         local monster = Monster.new(monsterid,lv,idx)
         local creaturelayer = obj._creaturelayer
         creaturelayer:insertMonster(monster)
         creaturelayer:addFlag(idx,monster:getprop("graphName"))
         account_data.creatureList[idx] = monsterid
         account_data.monsterPool[monsterid].n = account_data.monsterPool[monsterid].n - 1
         account_data.usedPt = account_data.usedPt + consume
         SendMsg[932008](monsterid,idx)
         diglayer:showUsingPt(consume)	
        --�������0ʱȡ��ѡ�񣨹����������㣩
        if account_data.monsterPool[monsterid].n <= 0 then 
            obj._selectedMonsterItem:setSelected(false)
            obj._selectedMonsterItem = nil
            diglayer:hideUsingPt()
        end
    end
end
function __digground.doCollMonster(obj,monster)
    local monsterid = monster:getprop("type")
    local pos = monster:getprop("birthPlace")
    local consume =  monster:getprop("consume")
    local creaturelayer = obj._creaturelayer
    ai_module.destroy(monster)
    creaturelayer:removeMonster(monster)
    creaturelayer:removeFlag(pos)
    account_data.creatureList[pos] = nil
    account_data.monsterPool[monsterid].n = account_data.monsterPool[monsterid].n + 1
    account_data.usedPt = account_data.usedPt - consume
    SendMsg[932009](monsterid,pos)
end
--���չ�
function __digground.bringMonsterBack(obj,monster)
    obj:doCollMonster(monster)
    obj._selectedMonsterItem = nil
    obj._selectedMonster = nil
    obj._selectedResCar = nil   
    local diglayer = AccountHelper:get(kDigHole) 
    diglayer:hideUsingPt()
    SoundHelper.playEffect(SoundList.click_monster_menu)
end
--�ƶ���
function __digground.moveMonsterTo(obj,idx,posX,posY)
    local srcPos = obj._selectedMonster:getprop("birthPlace") --��ǰѡ�йֵĳ���λ��
    local diglayer = AccountHelper:get(kDigHole)
	local creaturelayer = obj._creaturelayer
    --���ε��ͬһ����,ֱ��ȡ��ѡ��
    if idx == srcPos then 
        obj._selectedMonster:setSelected(false)
        creaturelayer:selectFlagAt(srcPos,false)
        obj._selectedMonster = nil
        diglayer:showDel(false)
        return 
    end
    local blocklayer = obj._blocklayer
    --�ƶ�λ�÷ǿյأ���ʾ��ȡ��ѡ��
    if not blocklayer:isDigged(idx) then 
        obj:showPropMsg(TxtList.digPrompt[2],posX,posY) 
        obj._selectedMonster:setSelected(false)
        creaturelayer:selectFlagAt(srcPos,false)
        obj._selectedMonster = nil
        diglayer:showDel(false)
        SoundHelper.playEffect(SoundList.click_Error)
        return
    end
    --�ƶ�λ���ѷ��ÿ�,��ʾ��ȡ��ѡ��
    if creaturelayer:hasResCar(idx) then
        obj:showPropMsg(TxtList.digPrompt[3],posX,posY) 
        obj._selectedMonster:setSelected(false)
        creaturelayer:selectFlagAt(srcPos,false)
        obj._selectedMonster = nil
        diglayer:showDel(false)
        SoundHelper.playEffect(SoundList.click_Error)
        return
    end  
    --ȡ����ǰѡ�й� 
    obj._selectedMonster:setSelected(false)   
    creaturelayer:selectFlagAt(srcPos,false) 
    local monsterid = obj._selectedMonster:getprop("type") 
    if creaturelayer:hasMonser(idx) then --�ж�����λ�ô��Ƿ��й�
       local oldmonster = creaturelayer:getMonsterByIdx(idx) --Ŀ��λ�õĹ������
       local oldMonsterid = oldmonster:getprop("type") --Ŀ��λ�õĹ���ID
       --������ID��ͬʱ������λ��
       if oldMonsterid ~= monsterid then
          account_data.creatureList[srcPos] = oldMonsterid
          account_data.creatureList[idx] = monsterid
          creaturelayer:moveMonsterTo(oldmonster,srcPos) --���ƶ�Ŀ��λ��ԭ�еĹ�
          creaturelayer:moveMonsterTo(obj._selectedMonster,idx) --�ƶ�ѡ�й���Ŀ��λ��
          creaturelayer:exFlag(idx,srcPos)
          SendMsg[932003](monsterid,srcPos,idx)
      end
        SoundHelper.playEffect(SoundList.set_monster_dig)
   else
        account_data.creatureList[srcPos] = nil
        creaturelayer:moveFlag(srcPos,idx) --�ƶ���������ָ��λ��
        account_data.creatureList[idx] = monsterid
        creaturelayer:moveMonsterTo(obj._selectedMonster,idx) --�ƶ�ѡ�й���Ŀ��λ��
        SendMsg[932003](monsterid,srcPos,idx)
        SoundHelper.playEffect(SoundList.set_monster_dig)
   end
   obj._selectedMonster = nil
   diglayer:showDel(false)
end
 --�ƶ���
function __digground.moveResCarTo(obj,idx,posX,posY)
    local blocklayer = obj._blocklayer
    local creaturelayer = obj._creaturelayer
    obj._selectedResCar:setSelected(false)
	if obj._selectedResCar:getprop("birthPlace") ~= idx then
		--Ŀ��λ���ǿ���
		if blocklayer:isExposedMine(idx)  then
			--[[
			local destype = obj._d_data.mileSpread[idx].type
			if destype ~= mtype then --�������Ͳ�������ʾ��ȡ��ѡ��
				obj:showPropMsg(TxtList.need..TxtList.mileName[mtype],posX,posY) 
				SoundHelper.playEffect(SoundList.click_Error)
			else
			--]]
			if creaturelayer:hasResCar(idx) then--�ѷ��ÿ�,��ʾֻ�ܷ���һ̨��
				obj:showPropMsg(TxtList.digPrompt[5],posX,posY) 
				SoundHelper.playEffect(SoundList.click_Error)
			else
				local x,y =blocklayer:getPosByIdx(idx) 
				obj._selectedResCar:egSetPosition(x,y)
				local collVal,coinType = obj._selectedResCar:moveToMine(idx) --�޸�UI��ʾ���ʺ�����
				if collVal > 0 then obj:showNumPrompt(coinType,collVal,posX,posY) end
				SendMsg[932006](obj._selectedResCar:getprop("idx"),idx)
				SoundHelper.playEffect(SoundList.click_rescar_digres)
			end
		elseif blocklayer:isDigged(idx)  then --�ж��Ƿ��ǿյ�
			if creaturelayer:hasMonser(idx) then --�յ����ѷ��ù����ʾ��ռ��
				obj:showPropMsg(TxtList.digPrompt[3],posX,posY) 
				SoundHelper.playEffect(SoundList.click_Error)
			else
				local x,y =blocklayer:getPosByIdx(idx) 
				obj._selectedResCar:egSetPosition(x,y)
				local collVal,coinType =  obj._selectedResCar:moveToBlank(idx) --�޸�UI��ʾ
				if collVal > 0 then obj:showNumPrompt(coinType,collVal,posX,posY) end
				SendMsg[932006](obj._selectedResCar:getprop("idx"),idx)
				SoundHelper.playEffect(SoundList.set_rescar_digres)
			end
		else --�ǿյ�Ҳ�ǿ���
			obj:showPropMsg(TxtList.digPrompt[2],posX,posY) --��ʾ���ܷ���
			SoundHelper.playEffect(SoundList.click_Error)
		end
	end
    obj._selectedResCar = nil
end
function __digground.digAt(obj,idx,posX,posY)
    if not idx then return end
    local blocklayer = obj._blocklayer
    local creaturelayer = obj._creaturelayer
    if creaturelayer:hasMonser(idx) then
        local monster = creaturelayer:getMonsterByIdx(idx)
        AccountHelper:get(kDigHole):showDel(true)
        obj._selectedMonster = monster
        obj._selectedMonster:setSelected(true)
        creaturelayer:selectFlagAt(idx,true)
        SoundHelper.playEffect(SoundList.click_monster_dig)
    else
        local rescar = creaturelayer:getResCarAt(idx) --��ȡλ�ڵ����Ŀ󳵣�û�з���NIL
        if rescar then
            if rescar:hasRes() then
               local collVal,coinType = rescar:doCollectRes()
               obj:showNumPrompt(coinType,collVal,posX,posY)
                SoundHelper.playEffect(SoundList.click_rescar_dighasres)
            else
                obj._selectedResCar = rescar
                obj._selectedResCar:setSelected(true)
                SoundHelper.playEffect(SoundList.click_rescar_dig)
            end
        else
            if blocklayer:isRemoveableBlock(idx)  then    --�ж��Ƿ�Ϊ���ھ������
                obj:digBlockAt(idx,posX,posY)
            elseif blocklayer:isExposedMine(idx) then
                
                local freecar = creaturelayer:getFreeResCar()
				--û�п��п󳵣���ȡ���һ���ƶ���ɼ����Ŀ�
				if not freecar then freecar = creaturelayer:getLastMovedResCar() end
                if not freecar then 
					obj:showPropMsg(TxtList.digPrompt[6],posX,posY) --��ʾ�޿��п�
					SoundHelper.playEffect(SoundList.click_Error)
                else
                    local collVal,coinType = freecar:moveToMine(idx) --�޸�UI��ʾ���ʺ�����
                    if collVal > 0 then obj:showNumPrompt(coinType,collVal,posX,posY) end
                    creaturelayer:moveResCarToward(freecar,idx) 
                    SendMsg[932006](freecar:getprop("idx"),idx)
                    SoundHelper.playEffect(SoundList.click_rescar_digres)
                end
            end
        end
    end
end
--�ھ�����
function __digground.digBlockAt(obj,idx,posX,posY)
    local blocklayer = obj._blocklayer
    local viewlayer = obj._viewlayer
    local block = blocklayer._blocks[idx]
    local leftDigCnt = block:getprop("leftDigCount")
    local digCnt = block:getprop("digCount")
    local askLv = block:getprop("digTrainLv")
    local digTrainLv = account_data.train[train.def.digging].lv
    local dp = block:getprop("deep")
    
    if  account_data.digPt < digCnt then 
        SoundHelper.playEffect(SoundList.digDisabled)
        obj:showPropMsg(TxtList.needDigPt,posX,posY) 
        return 
    end--�ж��ھ����ֵ
    if digTrainLv < askLv then 
        obj:showPropMsg(string.format(TxtList.needDigLv,askLv),posX,posY) 
        SoundHelper.playEffect(SoundList.digDisabled)
        return 
    end  --�ж���Ҫ���ھ���ȼ�
    blocklayer:showBlockBroken(block)
    if leftDigCnt > 1 then 
        SoundHelper.playEffect(SoundList.digFailed)
        block:setprop("leftDigCount",leftDigCnt - 1) 
    else
        SoundHelper.playEffect(SoundList.digBlock)
        blocklayer:removeBlockAt(idx)
        blocklayer:showBlocksInVision(idx,obj._d_data.digVision)--��ʾ���������ڵ�����
        viewlayer:showViewInVision(idx,obj._d_data.digVision)
        local digPt = account_data.digPt - digCnt
        if digPt < 0 then digPt = 0 end
        account_data.digPt = digPt
        local gaingold,gainoil = baseCalc.getBlockRes(account_data.digLv,digTrainLv,obj._d_data.sceneID,dp)
        if gaingold > 0 then obj:showGoldPrompt(gaingold,posX,posY) end
        if gainoil > 0 then obj:showOilPrompt(gainoil,posX,posY)end
        account_data.gold = account_data.gold + gaingold
        account_data.oil = account_data.oil + gainoil 
        SendMsg.addDigMsg(idx,dp,gaingold,gainoil)
    end
   -- obj:showNumPrompt("dig",-1,posX,posY)
end
function __digground.jumpAndScaleWidget(obj,widget,s1,desx,desy,jumph,jumpnum,scale,s2)
    local jumpto = CCJumpTo:create(s1,ccp(desx,desy),jumph,jumpnum)
	local scaleto = CCScaleTo:create(s1,scale)
	local spawn = CCSpawn:createWithTwoActions(jumpto,scaleto)
	local delay = CCDelayTime:create(s2)
	local function callbackfunc()
         widget:egRemoveSelf()
	end
	local callfunc = CCCallFuncN:create(callbackfunc)
	local array = CCArray:create()
	array:addObject(spawn)
	array:addObject(delay)
	array:addObject(callfunc)
	local action = CCSequence:create(array)
	widget:egRunAction(action)
end
function __digground.showGoldPrompt(obj,num,posX,posY)
    local widget = DigPrompt.new(KVariantList.coinGold,num)
    obj:addChild(widget:egNode(),kPromptZorder,kPromptZorder)
    local innerContainer = obj:getInnerContainer()
    local innerpos = innerContainer:convertToNodeSpace(ccp(posX,posY))
    local ttfSize =widget:egNode():getSize()
    innerpos.x = innerpos.x  - ttfSize.width/2
    if innerpos.x < 0 then 
        innerpos.x = 0
    elseif innerpos.x > obj._viewWidth - ttfSize.width then
        innerpos.x = obj._viewWidth - ttfSize.width
    end
    widget:egSetPosition(innerpos.x,innerpos.y)
    obj:jumpAndScaleWidget(widget,0.4,innerpos.x -kRandomM,innerpos.y + kJumpDis,kMoveByDistance,1,1.1,0.6)
end
function __digground.showOilPrompt(obj,num,posX,posY)
    local widget = DigPrompt.new(KVariantList.coinOil,num)
    obj:addChild(widget:egNode(),kPromptZorder,kPromptZorder)
    local innerContainer = obj:getInnerContainer()
    local innerpos = innerContainer:convertToNodeSpace(ccp(posX,posY))
    local ttfSize =widget:egNode():getSize()
    innerpos.x = innerpos.x  - ttfSize.width/2
    if innerpos.x < 0 then 
        innerpos.x = 0
    elseif innerpos.x > obj._viewWidth - ttfSize.width then
        innerpos.x = obj._viewWidth - ttfSize.width
    end
    widget:egSetPosition(innerpos.x,innerpos.y)
    obj:jumpAndScaleWidget(widget,0.4,innerpos.x+kJumpDis,innerpos.y+ kJumpDis +kRandomM,kMoveByDistance,1,1.1,0.6)
end
--��ʾ�ھ�������ʾ
function __digground.showNumPrompt(obj,promptype,num,posX,posY)
    local widget = DigPrompt.new(promptype,num)
    obj:addChild(widget:egNode(),kPromptZorder,kPromptZorder)
     local movey = kMoveByDistance
     local innerContainer = obj:getInnerContainer()
    local innerpos = innerContainer:convertToNodeSpace(ccp(posX,posY))
    local ttfSize =widget:egNode():getSize()
    innerpos.x = innerpos.x  - ttfSize.width/2
     if innerpos.x < 0 then 
        innerpos.x = 0
    elseif innerpos.x > obj._viewWidth - ttfSize.width then
        innerpos.x = obj._viewWidth - ttfSize.width
    end
    widget:egSetPosition(innerpos.x,innerpos.y)
    obj:jumpAndScaleWidget(widget,0.4,innerpos.x,innerpos.y + kMoveByDistance,kRandomM,1,1.1,0.6)
end 

function __digground.touchAtPos(obj,posX,posY)
    local idx = obj._blocklayer:getIdxByScreenPos(posX,posY) --��ȡ��ǰ���������λ��
    if obj._selectedMonsterItem then
            obj:sendMonsterTo(idx,posX,posY) --���ù���
    elseif obj._selectedMonster then
            obj:moveMonsterTo(idx,posX,posY) --�ƶ�����
    elseif obj._selectedResCar  then
            obj:moveResCarTo(idx,posX,posY) --�ƶ���
    else
            obj:digAt(idx,posX,posY) --�ڳ����е�����顢�󳵻�����
    end
end

function __digground.bindTouchEvent(obj)
    local p_movedelta = 0
    local p_touchstart = 0
    local p_touches={count=0}

    local function onTouchesBegan(touches) --touch began
        for i = 1,#touches,3 do
            p_touches[touches[i+2]] = {x = touches[i],y =touches[i+1]}
            p_touches.count = p_touches.count + 1
        end

        if p_touches.count == 1 then    p_touchstart = os.clock() end
    end
    local function onTouchesMoved(touches)
        if p_touches.count == 0 then return end
        local x = touches[1]
        local y = touches[2]
        local id = touches[3]

        p_movedelta = ccpDistance(ccp(x,y),ccp(p_touches[id].x,p_touches[id].y))
    end
    local function onTouchesEnded(touches)
         if p_touches.count == 0 then return end
        local touch_ms = (os.clock()-p_touchstart) * 1000
        if  p_movedelta<=obj._egkmaxoffset and  touch_ms < obj._egkmaxtouchms and p_touches.count == 1 then
            obj:touchAtPos(touches[1],touches[2])
            p_touchstart = 0
		else
			if AccountHelper:isLocked(kStateGuide) then
				obj:touchAtPos(touches[1],touches[2])
				p_touchstart = 0
			end
        end
        p_movedelta = 0
        for i = 1,#touches,3 do
            p_touches[touches[i+2]] = nil
            p_touches.count = p_touches.count-1
        end
    end
    
    obj:egBindTouchesEvent(onTouchesBegan,onTouchesMoved,onTouchesEnded)
end
DigGround={}
function DigGround.install(obj)
    table_aux.unpackTo(__digground, obj)
    obj._egkmaxtouchms = 350
    obj._egkmaxoffset = 36
    obj._selectedMonsterItem = nil
    obj._selectedMonster = nil
    obj._selectedResCar = nil
    obj:bindTouchEvent()
end
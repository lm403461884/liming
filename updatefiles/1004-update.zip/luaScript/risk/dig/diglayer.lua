local kPanelLayer = "dig_panel"
local kBtnDel = "btn_del"
local kBtnNew = "btn_dig_new"
local kBtnBack = "btn_back"
local kBtnZoomOut = "btn_zoomout"
local kBtnZoomIn = "btn_zoomin"
local kPanelMask = "panel_new"
local kLblNeedAct="lbl_dig_act"
local kImgAct = "img_dig_act"
local kImgChain3 = "chain_3"

local kLblCD = "lbl_cd_left_num"
local kLblCDCH = "lbl_cd_left_ch"

local kScrollMonster = "monster_list"
local kLblDig ="lbl_dig_val"
local kLblLeft = "lbl_left_val"
local kLblUsed = "lbl_used_val"
local kBarDig ="bar_dig"
local kBarUsing = "bar_ox_using"
local kBarUsed = "bar_ox_used"
local kBarWarning = "bar_warning"
local kImgRes = "res_panel"
local kImgFront = "mix_front"
local kImgDig = "img_dig"
local kImgLeaf = "img_leaf"
local kImgLeaf0 = "img_leafing"

local kImgTrain = "img_train"
local kLabelTrain = "lbl_lv"
local kLabelTrains = "lbl_lv_s"

--local kPanelNotice = "notice_panel"
--local kBtnYes = "btn_yes"
--local kBtnNo = "btn_no"
--local kBtnNo2 = "btn_no_2"

local kMaskOrder = 3
local kItemW = 142
local kMarginX = 10
local kRedColor = ccc3(255,0,0)
local kGreenColor = ccc3(0,255,0)
local kWhiteColor = ccc3(255,255,255)
local kOffsetY = 10
local __diglayer={}
function __diglayer.init(obj,d_data)
    obj._d_data = d_data
    obj._monsterItems= {}    
    obj:egHideWidget(kBtnZoomIn) --��Ҫ��ʾ�Ŵ���Сʱ����ע��
    obj:egHideWidget(kBtnZoomOut)--��Ҫ��ʾ�Ŵ���Сʱ����ע��
    obj:egHideWidget(kPanelMask) --���¿�ʱ��ʾ
    obj[string.format("_%s_rect",kBarDig)] = obj:getImgTextureRect(kBarDig)
    obj[string.format("_%s_rect",kBarUsed)] = obj:getImgTextureRect(kBarUsed)
    obj[string.format("_%s_rect",kBarUsing)] = obj:getImgTextureRect(kBarUsing)
    --obj:showPromptPanel(false)--���¿���ʾ��
   -- obj:egHideWidget(kLblLeft) --��ʱ����ʾ
    --����ȡ�����ð���
    obj:showDel(false)
    obj:loadOpenHoleInfo()
    obj:loadMonsterItem() --���ع�,���㲢��ʼ��account_data.usedPt
    obj._digPt = account_data.digPt
    obj._usedPt = account_data.usedPt
    obj._perDig = account_data.digPt*100/account_data.maxDigPt
    obj._perUsed = account_data.usedPt*100/account_data.maxDigPt
    obj:setImgShowPer(kBarDig,obj._perDig)
    obj:setImgShowPer(kBarUsed,obj._perUsed)--�Ѳ�������������Ϣ
    obj:setImgShowPer(kBarUsing,obj._perUsed)--����ռ�õ�����ֵ��ʾ
    obj:egSetBMLabelStr(kLblDig,account_data.digPt)
    obj:egSetBMLabelStr(kLblUsed,account_data.usedPt)
	--[[
	if account_data.usedPt<=0 then
		obj:egHideWidget(kLblUsed)
	else
		obj:egShowWidget(kLblUsed)
	end
	--]]
    obj._digFlag = obj:egGetWidgetByName(kImgDig)
    obj._resLen = obj:egGetWidgetByName(kImgRes):getSize().width
    obj._leafFlag = obj:egGetWidgetByName(kImgLeaf)
    obj._leafFlag0 = obj:egGetWidgetByName(kImgLeaf0)
    obj._digFlag:setPosition(ccp(obj._perDig*obj._resLen/100,kOffsetY))
    obj._leafFlag:setPosition(ccp(obj._resLen - obj._perUsed*obj._resLen/100,kOffsetY))
    obj._leafFlag0:setVisible(false)
	obj:egSetLabelStr(kLabelTrain,string.format("LV %d",account_data.train[train.def.digging].lv))
    obj:egSetLabelStr(kLabelTrains,string.format("LV %d",account_data.train[train.def.digging].lv))
	obj:showLeftOx(account_data.digPt,account_data.usedPt)
end
function __diglayer.showLeftOx(obj,leftDig,usedOx)
	local leftOx = account_data.maxDigPt - (leftDig+usedOx)
	obj:egSetBMLabelStr(kLblLeft,leftOx)
	if leftOx<=0 then 
		obj:egHideWidget(kLblLeft)
	else
		obj:egShowWidget(kLblLeft)
		local widget = obj:egGetWidgetByName(kLblLeft)
		local posX = leftDig/ account_data.maxDigPt*obj._resLen + leftOx/account_data.maxDigPt*obj._resLen/2
		--local posX = leftDig/ account_data.maxDigPt*obj._resLen
		widget:setPosition(ccp(posX,widget:getPositionY()))
	end
end
function __diglayer.setImgShowPer(obj,widgetName,per)
	per = math.max(per,0)
	per = math.min(per,100)
	local widget = obj:egGetWidgetByName(widgetName)
	local img =  tolua.cast(widget,"ImageView")
	local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
	local rect = obj[string.format("_%s_rect",widgetName)]
    local explen = per/100 * rect.w
    local anchor = widget:getAnchorPoint()
	if anchor.x == 0 then
		img:setTextureRect(CCRectMake(rect.x + rect.w-explen,rect.y,explen,rect.h))	
	elseif anchor.x == 1 then
		img:setTextureRect(CCRectMake(rect.x ,rect.y,explen,rect.h))
	end
end
function __diglayer.getImgTextureRect(obj,widgetName)
    local widget = obj:egGetWidgetByName(widgetName)
    local img =  tolua.cast(widget,"ImageView")
	local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
	local rect = sprite:getTextureRect()
	return {x=rect.origin.x,y = rect.origin.y,w=rect.size.width,h = rect.size.height}
end
--��ȡ�����������ܼ�����
function __diglayer.getMonsterCnt(obj)
   local Cnt = 0
    account_data.usedPt = 0
    for monsterid,item in pairs(account_data.monsterPool) do
        local s_data = monster_data.get(monsterid,account_data.monsterLvLook[monsterid] )
        account_data.usedPt = account_data.usedPt + (item.N-item.n)*s_data.consume
        Cnt = Cnt+1
    end
    return Cnt
end

--���ػ���ʾȡ������
function __diglayer.showDel(obj,show)
    if show then
        obj:egShowWidget(kBtnDel)
        obj:egShowWidget(kImgChain3)
    else
        obj:egHideWidget(kBtnDel)
        obj:egHideWidget(kImgChain3)
    end
end
function __diglayer.showUsingPt(obj,consume)
    local usingPt = account_data.usedPt + consume
    local left = account_data.maxDigPt - account_data.digPt - usingPt --�������ĺ�ʣ�����ֵ
    local per = usingPt*100/account_data.maxDigPt
    if per>100 then per = 100 end
    obj:setImgShowPer(kBarUsing,per)
    obj._leafFlag0:setVisible(true)
    obj._leafFlag0:setPosition(ccp(obj._resLen - per*obj._resLen/100,kOffsetY))
    if left < 0 then --�������ĺ�ʣ�����ֵС��0
        obj:egSetWidgetColor(kBarUsing,kRedColor)
    else
        obj:egSetWidgetColor(kBarUsing,kGreenColor)
    end
end
function __diglayer.hideUsingPt(obj)
    obj:setImgShowPer(kBarUsing,0)
    obj._leafFlag0:setVisible(false)
end
function __diglayer.loadMonsterItem(obj)
    local cnt = obj:getMonsterCnt()
    local listview = obj:egGetListView(kScrollMonster)
    local newW = cnt*(kItemW+kMarginX)-kMarginX
    local size = listview:getSize()
    local oldW = size.width
    for monsterid,item in pairs(account_data.monsterPool) do
        local monsteritem = MonsterItem.new(monsterid,item)
        listview:pushBackCustomItem(monsteritem:egNode())
        obj:bindClickToItem(monsteritem)
        obj._monsterItems[monsterid] = monsteritem
    end
    if newW < oldW then 
        listview:setPosition(ccp(listview:getPositionX() + (oldW - newW)/2*listview:getScale(),listview:getPositionY() ))
		listview:setSize(CCSizeMake(newW,size.height))
    end
end
function __diglayer.bindClickToItem(obj,monsteritem)
    local holelayer = AccountHelper:get(kHoleLayer) --�ھ��
    local function clickCallback(sender)
        local selectedMonsterItem = holelayer:getSelectedMonsterItem()
       
        if selectedMonsterItem== sender then
            selectedMonsterItem:setSelected(false)
            holelayer:setSelectedMonsterItem(nil)
            obj:hideUsingPt()
            --�򿪹���ͼ��
        else
            if selectedMonsterItem then selectedMonsterItem:setSelected(false) end
            obj:showUsingPt(sender:getConsume())
            holelayer:setSelectedMonsterItem(sender)
            sender:setSelected(true)
        end
        local selectedResCar = holelayer:getSelectedResCar()
        if selectedResCar then  --ȡ����ѡ��״̬
            selectedResCar:setSelected(false)  
            holelayer:setSelectedResCar(nil)
        end
        local selectedMonster = holelayer:getSelectedMonster()
        if selectedMonster then --ȡ������ѡ��״̬
            selectedMonster:setSelected(false)
            holelayer:setSelectedMonster(nil)
        end --
        obj:showDel(false)
        SoundHelper.playEffect(SoundList.click_monster_menu)
    end
    monsteritem:onClicked(clickCallback)
end

--���ص���
function __diglayer.bindBackListener(obj)
    local function touchEnded(sender)
	    sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_back_button)
		local scene = TownScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
--���¿�
function __diglayer.bindNewListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnNew,false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
        if account_data.actPt >= numDef.openHole then
            --obj:showPromptPanel(true)
            DigMapScene.new(obj._d_data.sceneID):egReplace()
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNew,nil,nil,touchEnded,touchCanceled)
end
function __diglayer.bindZoomOutListener(obj) 
    local function touchEnded(sender)
         obj._groundlayer:zoomOut()
    end
     obj:egBindTouch(kBtnZoomOut,nil,nil,touchEnded,nil)
end
function __diglayer.bindZoomInListener(obj)
    local function touchEnded(sender)
        --obj._groundlayer:zoomIn()
		dofile("luaScript/testScript.lua")
    end
     obj:egBindTouch(kBtnZoomIn,nil,nil,touchEnded,nil)
end
--ȡ������
function __diglayer.bindDelListener(obj)
    local function touchEnded(sender)
			if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
           obj:showDel(false)
           local holelayer = AccountHelper:get(kHoleLayer) --�ھ��
           local selectedMonster = holelayer:getSelectedMonster()
           if selectedMonster then 
                holelayer:bringMonsterBack(selectedMonster)
                holelayer:setSelectedMonster(nil)
           end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnDel,nil,nil,touchEnded,touchCanceled)
end
function __diglayer.activeResUpdate(obj)
    local function callback()
       if  obj._digPt < account_data.digPt then
            obj._digPt = obj._digPt +1
       elseif obj._digPt > account_data.digPt then
            obj._digPt = obj._digPt -1
       end
       obj:egSetBMLabelStr(kLblDig,obj._digPt)
       if obj._usedPt <account_data.usedPt then
            obj._usedPt = obj._usedPt +1
       elseif obj._usedPt > account_data.usedPt then
             obj._usedPt = obj._usedPt -1
       end
       obj:egSetBMLabelStr(kLblUsed,obj._usedPt )
	   --[[
	   if obj._usedPt<=0 then
		obj:egHideWidget(kLblUsed)
	else
		obj:egShowWidget(kLblUsed)
	end
	--]]
       local perDig = account_data.digPt*100/account_data.maxDigPt
       if obj._perDig ~= perDig then
            local sub = perDig - obj._perDig
            if sub > 0 then
                local per = math.ceil(sub/10) 
                obj._perDig = obj._perDig + per
                if obj._perDig> perDig then obj._perDig=perDig end
            elseif sub<0 then
                local per = math.floor(sub/10) 
                obj._perDig = obj._perDig + per
                if obj._perDig < perDig then obj._perDig=perDig end
            end
            obj:setImgShowPer(kBarDig,obj._perDig)
            obj._digFlag:setPosition(ccp(obj._perDig*obj._resLen/100,kOffsetY))
       end
       local perUsed = account_data.usedPt*100/account_data.maxDigPt
       if obj._perUsed ~= perUsed then
            local sub = perUsed - obj._perUsed
            if sub > 0 then
                local per = math.ceil(sub/10) 
                obj._perUsed = obj._perUsed + per
                if obj._perUsed > perUsed then obj._perUsed=perUsed end
            elseif sub<0 then
                local per = math.floor(sub/10) 
                obj._perUsed = obj._perUsed + per
                if obj._perUsed < perUsed then obj._perUsed=perUsed end
            end
            obj:setImgShowPer(kBarUsed,obj._perUsed)
            obj._leafFlag:setPosition(ccp(obj._resLen - obj._perUsed*obj._resLen/100,kOffsetY))
       end
	   obj:showLeftOx(obj._digPt,obj._usedPt)
    end
    obj:egBindWidgetUpdate(kImgFront,callback)
end
--���ؿ��¿������Ϣ
function __diglayer.loadOpenHoleInfo(obj)
	if not account_data.openHoleContext then obj:loadActPt() return end
	local oldLeft = account_data.openHoleContext.left -(os.time() - account_data.openHoleContext.st)
	account_data.openHoleContext.left = oldLeft
	account_data.openHoleContext.st = os.time()
	if oldLeft <= 0 then
		account_data.openHoleContext = nil
		obj:loadActPt()
		return
	end
	obj:egHideWidget(kImgAct)
	obj:egHideWidget(kLblNeedAct)
	obj:egShowWidget(kLblCD)
	obj:egShowWidget(kLblCDCH)
	obj:egSetWidgetEnabled(kBtnNew,false)
	obj._cd_left_Num,obj._cd_left_Unit = Funs.formmatTimeCh2(oldLeft)
	obj:egSetBMLabelStr(kLblCD,obj._cd_left_Num)
	obj:egSetBMLabelStr(kLblCDCH,obj._cd_left_Unit)
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		account_data.openHoleContext.left = math.ceil(oldLeft - passed)
		account_data.openHoleContext.st = os.time()
		if account_data.openHoleContext.left <= 0 then
			obj:egUnbindWidgetUpdate(kLblCD)
			account_data.openHoleContext = nil
			obj:loadActPt()
		else
			local cdLeftNum,cdLeftUnit = Funs.formmatTimeCh2(account_data.openHoleContext.left)
			if obj._cd_left_Num~= cdLeftNum then
				obj._cd_left_Num = cdLeftNum
				obj:egSetBMLabelStr(kLblCD,obj._cd_left_Num)
			end
			if obj._cd_left_Unit~= cdLeftUnit then
				obj._cd_left_Num = cdLeftUnit
				obj:egSetBMLabelStr(kLblCDCH,obj._cd_left_Unit)
			end
		end
	end
	obj:egBindWidgetUpdate(kLblCD,callback)
end
--��ʾ���¿���Ҫ���ж���
function __diglayer.loadActPt(obj)
	obj:egHideWidget(kLblCD)
	obj:egHideWidget(kLblCDCH)
	obj:egShowWidget(kImgAct)
	obj:egShowWidget(kLblNeedAct)
	obj:egSetLabelStr(kLblNeedAct,numDef.openHole)
	obj:egSetWidgetColor(kLblNeedAct,kWhiteColor)
	obj:egSetWidgetEnabled(kBtnNew,true)
	if account_data.actPt < numDef.openHole then
		obj:egSetWidgetColor(kLblNeedAct,kRedColor)
		obj:egSetWidgetEnabled(kBtnNew,false)
		local function callback()
			if account_data.actPt >=numDef.openHole then
				obj:egUnbindWidgetUpdate(kLblNeedAct)
				obj:egSetWidgetColor(kLblNeedAct,kWhiteColor)
				obj:egSetWidgetEnabled(kBtnNew,true)
			end
		end
		obj:egBindWidgetUpdate(kLblNeedAct,callback)
	end
end
function __diglayer.activeUpdate(obj)
    local function update()
		if not AccountHelper:isLocked(kStateGuide) then
			ai_module.update()
		end
    end
	local function clear()
		ai_module.clear()
	end
     obj:egBindUpdate(update,clear)
end
DigLayer={}
function DigLayer.new(d_data)
    local obj =  TouchWidget.new(JsonList.digLayer)
    obj:egNode()
    table_aux.unpackTo(__diglayer, obj)
    obj:init(d_data)
    obj:bindBackListener()
    obj:bindNewListener()
    obj:bindZoomOutListener()
    obj:bindZoomInListener()
    obj:bindDelListener()
    --obj:bindYesListener()
    --obj:bindNoListener()
    --obj:bindNo2Listener()
    obj:activeUpdate()
	obj:activeResUpdate()
    AccountHelper:bind(kDigHole,obj)
    return obj
end

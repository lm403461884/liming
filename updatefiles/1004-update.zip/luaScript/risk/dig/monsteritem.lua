local kImgMonster = "img_monster"
local kBtnMonster = "btn_monster"
local kLabelNum = "lbl_left"
local kLblCost = "lbl_cost_val"
local kLblCostCH = "lbl_cost"
local kGrayColor = ccc3(64,64,64)
local kWhiteColor = ccc3(255,255,255)
local __monsteritem = {}
function __monsteritem.init(obj,monsterid,d_data)
    obj._d_data = d_data
    obj._n = obj._d_data.n
    obj._N = obj._d_data.N
    obj._monsterid = monsterid
    local lv = account_data.monsterLvLook[monsterid]
    local s_cfg = monster_data.getConfig(monsterid)
    local s_data = monster_data.get(monsterid,lv )
    local img = string.format('%s_020201.png',s_cfg.graphList[s_data.graphLV])
    obj._consume = s_data.consume
    obj:egChangeImg(kImgMonster,img,UI_TEX_TYPE_PLIST) 
    obj:egSetBMLabelStr(kLabelNum,string.format("%d%s%d",obj._d_data.n,"/",obj._d_data.N))
    
    obj:egSetLabelStr(kLblCost,s_data.consume)
    obj._curColor = kWhiteColor
    if obj._d_data.n < 1 then obj._curColor = kGrayColor end
    if account_data.maxDigPt - account_data.digPt - account_data.usedPt < obj._consume then
        obj._curColor = kGrayColor
    end
    obj._imgWidget = tolua.cast(obj:egGetWidgetByName(kImgMonster),"ImageView")
    obj._btnWidget = tolua.cast(obj:egGetWidgetByName(kBtnMonster),"Button")
    obj._imgWidget:setColor(obj._curColor)
end
function __monsteritem.onClicked(obj,clickCallBack)
    obj._clickCallBack = clickCallBack
end
function __monsteritem.getConsume(obj)
    return obj._consume
end
function __monsteritem.getMonsterID(obj)
    return obj._monsterid
end
function __monsteritem.setSelected(obj,selected)
    obj._selected = selected
    obj._btnWidget:setFocused(selected)
    if selected then
        obj._imgWidget:setOpacity(200)
        obj._btnWidget:setScale(1.02)
        
    else
       obj._imgWidget:setOpacity(255)
       obj._btnWidget:setScale(1)
    end
    
end
function __monsteritem.activeTouch(obj)
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._clickCallBack then obj._clickCallBack(obj) end
		sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnMonster,nil,nil,touchEnded,touchCanceled)
end
function __monsteritem.activeUpdate(obj)
    local function callback()
        if obj._d_data.n ~= obj._n or obj._d_data.N ~= obj._N  then
             obj._n = obj._d_data.n
             obj._N = obj._d_data.N
             obj:egSetBMLabelStr(kLabelNum,string.format("%d%s%d",obj._d_data.n,"/",obj._d_data.N))
        end
        local color = kWhiteColor
        if obj._d_data.n < 1 then color = kGrayColor end
        if account_data.maxDigPt - account_data.digPt - account_data.usedPt < obj._consume then
            color = kGrayColor
        end
        if obj._curColor~=color then
            obj._curColor = color
            obj._imgWidget:setColor(obj._curColor)
        end
    end
    obj:egBindWidgetUpdate(kImgMonster,callback)
end
MonsterItem = {}
function MonsterItem.new(monsterid,d_data)
    local obj = {}
    CocosWidget.install(obj,JsonList.monsterItem)
    BaseProp.install(obj)
    InnerProp.install(obj)
    table_aux.unpackTo(__monsteritem, obj)
    obj:init(monsterid,d_data)
    obj:activeTouch()
    obj:activeUpdate()
    return obj
end
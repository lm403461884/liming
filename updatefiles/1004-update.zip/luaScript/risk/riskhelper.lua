local kBaseNum = 256
local kBehaviorDig = 0 --��Ϊ��ʶ �ھ�
local kBehaviorAtk = 1 --��Ϊ��ʶ ����
local kBehaviorDef = 2 --��Ϊ��ʶ ����
RiskHelper={}
--------------------------
--�ھ򳡾�����
--------------------------
function RiskHelper.getDigSceneData()
    enableExpandAI = false
	behaviorFlag = kBehaviorDig --��Ϊ��ʶ �ھ�
    local tb = {}
    local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
	tb.showFlag = true
    tb.w = s_data.w
    tb.h = s_data.h
    tb.maxDigPt = account_data.maxDigPt
    tb.digVision = account_data.digVision --�ھ���Ұ
    tb.dfs = account_data.guid
	tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLv = account_data.sceneLv
    tb.digTrace = account_data.digTrace
    tb.mileSpread = account_data.mileSpread --�����ֲ�
    tb.collectorList = account_data.collectorList --�󳵷ֲ�
    tb.spread = s_data.spread
    tb.entraIdx = s_data.w/2
    if not tb.digTrace[tb.entraIdx] then
       tb.digTrace[tb.entraIdx] = 1
    end
    tb.creatureList = account_data.creatureList
    tb.monsterLvLook = account_data.monsterLvLook
    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/iceberg_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    tb.mineOutRange = RiskHelper.getMineOutOfDigTrance(tb) --��ȡ�ھ����������ʾ�Ŀ�
    return tb
end

--------------------------
--��ȡ������������
--------------------------
function RiskHelper.getAtkSceneData(areaid,stageid)
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    local stagedata = pveQuery.queryStage(areaid,stageid)
    local tb = {}
    tb.type = 0
	tb.btFlag = 0
    tb.digVision = account_data.digVision
	tb.digLv = account_data.digLv
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
    tb.dfs = 0
    tb.dfsName = TxtList.pveDefName
    tb.areaid = areaid
    tb.stageid = stageid
    tb.sceneID = areaid
    tb.sceneLv = stageid
	tb.battleBox = {[1]={},[2]={},[3]={}}
	tb.battleBoxCnt = 0
	tb.consume = account_data.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.areaid,tb.stageid,tb.dfsName,tb.consume ) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ������ߣ��ڽ��յ�ս���ط����ݺ�ָ� 394001
    tb.w = stagedata.w
    tb.h = stagedata.h
    tb.digTrace = Funs.copy(stagedata.digTrace)
    tb.mileSpread = {}
	tb.boxList = stagedata.boxList
    tb.collectorList = stagedata.collectorList --�󳵷ֲ�
    tb.spread = stagedata.spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(stagedata.creatureList)
	--�ճ����������ִ�յȼ���������ȼ�
	if MissionHelper.groupIdx then
		tb.monsterLvLook =  baseCalc.getMonsterLv(tb.digLv, stagedata.monsterLvLook)
	else --��ͨ����ֱ�Ӷ�����
		tb.monsterLvLook = Funs.copy(stagedata.monsterLvLook)
	end
	tb.heroList = {}
	tb.teamList = account_data.team
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.heroList[heroid].hp= hero_data.getData(heroid, tb.heroList[heroid].lv, "maxHP")
		tb.heroList[heroid].power = numDef.originalPower
	end
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag

    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ����ս������
--------------------------
function RiskHelper.getDefSceneData(pidIdx)
    enableExpandAI = true
	behaviorFlag = kBehaviorDef --��Ϊ��ʶ ����
    --��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
	local tb = {}
	tb.stageid = account_data.pveGuardQuest.qid[pidIdx]
	tb.pidIdx = pidIdx

    local stagedata = pveGuardQuery.getName(tb.stageid)
	local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
	tb.awardRes=RiskHelper.getDefAwardRes(tb.stageid)
    tb.type = 1
    tb.btFlag = 3
    tb.digVision = account_data.digVision
    tb.atk = 0
    tb.digLv = account_data.digLv
    tb.atkName = TxtList.pveAtkName
    tb.dfs = account_data.guid
    tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLV = account_data.sceneLV
	tb.consume = stagedata.consume

	RiskHelper.initBP(tb.type,tb.btFlag, tb.sceneID,tb.stageid,tb.dfsName,tb.consume)

    tb.w = s_data.w
    tb.h = s_data.h
	tb.entraIdx =  s_data.w/2
    tb.digTrace = Funs.copy(account_data.digTrace)
    tb.mileSpread = Funs.copy(account_data.mileSpread)
    tb.collectorList =  Funs.copy(account_data.collectorList)
	for idx,prop in ipairs(tb.collectorList) do
		 tb.mileSpread[prop.pos] = nil
		 tb.digTrace[prop.pos] = 1
	end
	tb.creatureList = Funs.copy(account_data.creatureList)
    tb.monsterLvLook = Funs.copy(account_data.monsterLvLook)
    tb.spread = s_data.spread

    --tb.heroList = Funs.copy(pveGuardQuest.pveGuardheroLv(account_data,tb.stageid))
    tb.heroList = defHeroList --������Ϣ��ʾ���洴����ȫ�ֱ���
    for idx,hero in pairs (tb.heroList) do
        hero.hp = hero_data.getData(hero.type,hero.lv,"maxHP")
		hero.power = numDef.originalPower
    end
    tb.teamList = Funs.copy(stagedata.team)

    tb.equipments = Funs.copy(pveGuardQuest.pveGuardequipLv(account_data,tb.stageid))


    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ��ս��������
--------------------------
function RiskHelper.getPvpSceneData()
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    local tb = {}
    tb.type = 0
	tb.btFlag = 1
    tb.digVision = account_data.digVision
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
	tb.digLv = account_data.digLv
    tb.dfs = pvpaccount_data.guid
	tb.dfsName = pvpaccount_data.user
    tb.sceneID = pvpaccount_data.sceneID
    tb.sceneLv = pvpaccount_data.sceneLv
	tb.consume = account_data.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName,tb.consume) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ�������,�ڽ��յ�ս���ط����ݺ�ָ� 395004
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(pvpaccount_data.digTrace)
    tb.mileSpread = Funs.copy(pvpaccount_data.mileSpread)
    tb.collectorList = Funs.copy(pvpaccount_data.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(pvpaccount_data.creatureList)
    tb.monsterLvLook = Funs.copy(pvpaccount_data.monsterLvLook)
    tb.teamList = account_data.team
	tb.heroList = {}
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.heroList[heroid].hp= hero_data.getData(heroid, tb.heroList[heroid].lv, "maxHP")
		tb.heroList[heroid].power = numDef.originalPower
	end
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag

    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/grasslands_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ¼�񳡾�����
--------------------------
function RiskHelper.getVideoSceneData()
	 enableExpandAI = true
	 behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
     local tb = {}
     tb.type = 0
	 tb.btFlag = 2
     tb.old_acct = VideoDetail.atk
     if VideoDetail.def.user == account_data.guid then
        tb.type = 1
        tb.old_acct = VideoDetail.def
    end
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    tb.digVision = VideoDetail.atk.digVision or 2
    tb.atk = VideoDetail.atk.guid
	tb.atkName = VideoDetail.atk.userName
	tb.digLv = VideoDetail.atk.digLv or 1
    tb.dfs = VideoDetail.def.guid
	tb.dfsName = VideoDetail.def.userName
    tb.sceneID = VideoDetail.def.sceneID
    tb.sceneLv = VideoDetail.def.sceneLv
    tb.frameCnt = VideoDetail.atk.frameCnt
	tb.consume = VideoDetail.atk.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName,tb.consume) --��ʼ��ս������
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(VideoDetail.def.digTrace)
    tb.mileSpread =  Funs.copy(VideoDetail.def.mileSpread)
    tb.collectorList = Funs.copy(VideoDetail.def.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(VideoDetail.def.creatureList)
    tb.monsterLvLook = Funs.copy(VideoDetail.def.monsterLvLook)
    tb.heroList = VideoDetail.atk.heroList
	for idx,hero in pairs(tb.heroList) do
        hero.hp = hero_data.getData(hero.type, hero.lv, "maxHP")
		hero.power = numDef.originalPower
    end
    tb.teamList = Funs.copy(VideoDetail.atk.team )
	tb.equipments = VideoDetail.atk.equipments
    tb.teamBag = Funs.copy(VideoDetail.atk.teamBag)

    tb.itemFrame = Funs.copy(VideoDetail.atk.itemUsageFrame) or {} --ʹ��ʱ��
	tb.itemPos = Funs.copy(VideoDetail.atk.itemUsagePos) or {}--ʹ��λ��
    tb.heroEnterFrame = Funs.copy(VideoDetail.atk.heroEnterFrame) or {}
	tb.heroCreatedFrame = Funs.copy(VideoDetail.atk.heroCreatedFrame) or {}
	tb.skillFrame = Funs.copy(VideoDetail.atk.skillUsageFrame) or {}
    tb.bag = {}
    for itemid,usetb in pairs(tb.itemFrame) do
        tb.bag [itemid] = #usetb
    end
    --ս����ʧ��Ϣ�����������ʾ
	tb.atk_elo = VideoDetail.atk_elo
	tb.def_elo = VideoDetail.def_elo
	for idx = 1,7 do
		local coinname = KVariantList.coinType[idx]
		local atkparam = string.format("atk_%s",coinname)
		local defparam = string.format("def_%s",coinname)
		tb[atkparam] = VideoDetail[atkparam]
		tb[defparam] = VideoDetail[defparam]
	end
    tb.stars = VideoDetail.stars
    ----------------------
    tb.headImg = scene_data[tb.sceneID].sub_img
    tb.entraImg =scene_data[tb.sceneID].enter_img
    tb.earthImg = EarthImages[tb.sceneID]
    return tb

end
--------------------------
--��ȡԶ����������
--------------------------
function RiskHelper.getExPveSceneData(stageid)
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    local stagedata = farpveQuery.queryStage(stageid)
    local tb = {}
    tb.type = 0
	tb.btFlag = 4
    tb.digVision = account_data.digVision
	tb.digLv = account_data.digLv
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
    tb.dfs = 0
    tb.dfsName = TxtList.pveDefName
    tb.areaid = stagedata.areaid
    tb.stageid = stageid
    tb.sceneID = tb.areaid
    tb.sceneLv = stageid
	tb.battleBox = {[1]={},[2]={},[3]={}}
	tb.battleBoxCnt = 0
	tb.consume = account_data.consume
	tb.awardRes=RiskHelper.getExpeditionAwardRes(tb.stageid)
    RiskHelper.initBP(tb.type,tb.btFlag,tb.areaid,tb.stageid,tb.dfsName,tb.consume ) --��ʼ��ս������
    tb.w = stagedata.w
    tb.h = stagedata.h
    tb.digTrace = Funs.copy(stagedata.digTrace)
    tb.mileSpread = {}
	tb.boxList = stagedata.boxList
    tb.collectorList = stagedata.collectorList --�󳵷ֲ�
    tb.spread = stagedata.spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(account_data.exMission.creatureList)
	--����ִ�յȼ���������ȼ�

	tb.monsterLvLook =  baseCalc.getMonsterLv(tb.digLv, stagedata.monsterLvLook)
	tb.teamList = account_data.exMission.team
	tb.heroList = {}
	tb.totalLv = 0
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.totalLv = tb.totalLv + tb.heroList[heroid].lv
		tb.heroList[heroid].hp,tb.heroList[heroid].power =  RiskHelper.getHPPower(account_data.expedition[heroid])
	end
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag
    tb.entraImg =scene_data[tb.sceneID].enter_img
    tb.earthImg = EarthImages[tb.sceneID]
	
    return tb
end
--��ȡ�ֲ������ھ�������Ŀ�
function RiskHelper.getMineOutOfDigTrance(d_data)
    local openedView = Funs.getIdxInVision(d_data.digTrace,d_data.w,d_data.h,d_data.digVision,nil)--�ھ���Ұ
    local mineView =  Funs.getIdxInVision(d_data.entraIdx,d_data.w,d_data.h,d_data.maxDigPt,nil)--������Ұ
    local cnt = baseCalc.getVisibleMineCnt() --��ʾ����
    local tb = {}
    for idx,item in pairs(d_data.mileSpread) do
        if #tb>= cnt then return tb end
        if not openedView[idx] then
            if mineView[idx] and not d_data.digTrace[idx] then
                table.insert(tb,idx)
            end
        end
    end
    return tb
end
--------------------------
--��ȡ��������������б�
--------------------------
function RiskHelper.getDefAwardRes(pid)
    local tb={}
    local awarddata = pveGuardQuest.pveGuardprize(account_data,pid)
    if awarddata then
        for key,val in pairs(awarddata) do
			if KVariantList.coinName[key] then
				tb[key] = val
			end
        end
    end
    return tb
end
--------------------------
--��ȡԶ������������б�
--------------------------
function RiskHelper.getExpeditionAwardRes(stageid)
    local tb={}
    local awarddata = farpveCalc.getAwardRes(account_data,stageid)
    if awarddata then
        for key,val in pairs(awarddata) do
            tb[key] = val
        end
    end
    return tb
end
--------------------------
--��ȡӢ�۶���
--------------------------
function RiskHelper.getHeroObj(heroid,heroObjs)
    if heroObjs then
        for _, hero in pairs(heroObjs) do
            if hero:getprop("type")== heroid then
                return hero
            end
        end
    end
   -- print("can not find HeroObj from heroObjs with heroid:",heroid)
    return nil
end
--��ȡԶ���ӳ�Ա����
function RiskHelper.getExTeamCnt()
    if not account_data.expedition then return 0 end
	local cnt = 0
	for key,val in pairs(account_data.expedition) do
		cnt = cnt+1
	end
	return cnt
end
--��ȡӢ������
function RiskHelper.getHeroCnt()
	local cnt = 0
	for key,val in pairs(account_data.heroList) do
		cnt = cnt+1
	end
	return cnt
end
--��ȡӢ��Ѫ����ŭ��ֵ
function RiskHelper.getHPPower(hpPower)
	local hp =math.floor(hpPower/kBaseNum)
	local power = math.min(hpPower%kBaseNum,100)
	return hp,power
end
--����Ӣ��Ѫ����ŭ��ֵ��Ӧ������
function RiskHelper.calHPPower(hp,Power)
	return hp*kBaseNum + Power
end

--------------------------
--��ȡӢ�۶�������ֵ
--------------------------
function RiskHelper.getHeroConsume(heroid,herolist)
    local hero = herolist[heroid]
    local s_data = hero_data.get(hero.type,hero.lv)
    return s_data.consume
end
--------------------------
--�жϿ����Ƿ���ھ�
--------------------------
function RiskHelper.isRemovable(idx,digTrace,w,h)
    if idx > 0 and digTrace[idx] then return false end
    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  digTrace[idx_l] then  return true end--����������ھ�
    return false
end

--��ʼ��ս������
function RiskHelper.initBP(mtype,btFlag,areaid,stageid,defUser,consume)
    battleAIData = {}
    battleProgress ={}
	battleProgress.user = defUser
    battleProgress.type = mtype
    battleProgress.btFlag = btFlag
    battleProgress.startTime = os.time()
	battleProgress.consume = consume
    battleProgress.areaID = areaid
    battleProgress.stageID = stageid
    battleProgress.heroDamage = {} --heroDamage={[heroid]={damage1,time1,damage2,time2...}}
    battleProgress.monsterDeath = {}
	battleProgress.heroHpPower={}--heroHpPower={heroid1,hp*256+power,...}
    battleProgress.gold = {}  --gold = {pos,pos2...} --posΪ����collectorList��������λ��
    battleProgress.oil = {}   --oil = {pos,pos2...}
	battleProgress.collector={}--collector={idx1,idx2...}idxΪ����collectorList��������λ��
    --battleProgress.itemUsage = {} --itemUsage = {[itemid]={time1,time2,...}}
    battleProgress.itemUsageFrame = {}--itemUsageFrame = {[itemid]={framid1,frameid2,...}}
	battleProgress.itemUsagePos = {}--itemUsagePos = {[itemid]={idx1,idx2,...}} --����ʹ��λ��
    battleProgress.heroEnterFrame = {} --heroEnterFrame={heroid,framid,}
    battleProgress.heroCreatedFrame = {} --heroCreatedFrame={heroid,framid,} --Ӣ��AI������
	battleProgress.skillUsageFrame = {} --skillUsageFrame={[heroid]={framid1,..frameidn},} --Ӣ�ۼ���ʹ��֡
    battleProgress.stars = 0
    battleProgress.frameCnt = 0
	battleProgress.gainRes = {} --gainRes={gold=0,stoneR = 0,...}
	battleProgress.gainHeroMsg={} --gainHeroMsg={[heroid] = msgNum,...}Ӣ��ID����õ���Ϣ��
end

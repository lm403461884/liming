local kGroundOrder = 1
local kAtkOrder = 2
local kScoreOrder = 6
local __replaypvpscene={}
function __replaypvpscene.init(obj)
    obj._d_data = RiskHelper.getVideoSceneData()
    obj:startPlayBGM()
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._videolayer = VideoLayer.new(obj._d_data,obj)
        obj._videolayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
	if obj._d_data.type == 0 then
		obj._groundlayer:showInAtkScene(callback)
	else
		obj._groundlayer:showInDefScene(callback)
	end
	obj._groundlayer:onHeroShown(callback)
end
function __replaypvpscene.stopBattle(obj)
	BPResult ={}
    if obj._d_data.type == 0 then
        BPResult.elo = obj._d_data.atk_elo
        BPResult.stars = obj._d_data.stars
		for idx = 1,7 do
			local coinname = KVariantList.coinType[idx]
			BPResult[coinname] = obj._d_data[string.format("atk_%s",coinname)]
		end
    else
        BPResult.elo = obj._d_data.def_elo
        BPResult.stars =  numDef.starsPerStage - obj._d_data.stars
		for idx = 1,7 do
			local coinname = KVariantList.coinType[idx]
			BPResult[coinname] = obj._d_data[string.format("def_%s",coinname)]
		end
    end
    AccountHelper:unlock(kStateBpResult)
	obj._scoreLayer= BattleResultLayer.new(obj._d_data)
	obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end
function __replaypvpscene.startPlayBGM(obj)
    if obj._d_data.type == 0 then
        -- SoundHelper.playBGM(SoundList.atk_bgm)
    else
        --SoundHelper.playBGM(SoundList.def_bgm)
    end
end
ReplayPvpScene={}
function ReplayPvpScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__replaypvpscene, obj)
    
    obj:init()
    --showEmDialog(obj,GuideScene.def.kVideoScene) --����������Ϣ
    --obj:startPlayBGM()
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
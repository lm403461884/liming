--! local context
local sumaries = {} --using as array
local videos = {}  --using as hash, key is videoid(vid)

--! module videomanager
	videomanager = {}

function videomanager.getlastvid()
	if #sumaries == 0 then
		return -1
	end
	return sumaries[#sumaries].vid
end

function videomanager.addsumary(sum)
	table.insert(sumaries, sum)
end

function videomanager.addvideo(vid, vd)
	videos[vid] = vd
end

function videomanager.getsumaries()
	return sumaries
end

function videomanager.getvideo(vid)
	return videos[vid]
end
function videomanager.getvideoDetail(vid)
    local videoinfo = videos[vid]
    local videodetail = {}
    videodetail.atk = videoinfo.atk
    videodetail.def = videoinfo.def
	videodetail.atk.guid = videoinfo.bpresult.atkGuid
    videodetail.atk.userName = videoinfo.bpresult.atkName
	videodetail.def.guid = videoinfo.bpresult.defGuid
	videodetail.def.userName = videoinfo.bpresult.defName
	videodetail.atk_elo = videoinfo.bpresult.atk_elo
	videodetail.def_elo = videoinfo.bpresult.def_elo
	for idx = 1,7 do
        local coinname = KVariantList.coinType[idx]
        local atkparam = string.format("atk_%s",coinname)
        local defparam = string.format("def_%s",coinname)
        videodetail[atkparam] = videoinfo.bpresult[atkparam]
        videodetail[defparam] = videoinfo.bpresult[defparam]
	end
	videodetail.stars = videoinfo.bpresult.stars
    return videodetail
end

local kImgFlag = "img_flag"
local kImgBg = "img_bg"
local kPanelFlag = "inner_panel"
local kPanelCD = "cd_panel"
local kImgCd = "img_cd"
local kImgTimeCh = "lbl_time_ch"
local kImgTimeNum = "lbl_time_num"
local kCellW = 72
local kRedColor = ccc3(245,100,100)
local kWhiteColor = ccc3(255,255,255)
local __mineflag = {}
function __mineflag.updateMineFlag(obj)
	obj._hasCar = obj:hasResCar()
	obj:loadCdBar()
	obj:showFlag()
end
function __mineflag.showFlag(obj)
	local widget = obj:egGetWidgetByName(kPanelFlag)
	if obj._hasCar then
		--widget:stopAllActions()
        obj:egHideWidget(kPanelFlag)
	else
		obj:egShowWidget(kPanelFlag)
		
		--[[
		local scaleto1 = CCScaleTo:create(1,0.8)
		local scaleto2 = CCScaleTo:create(1,1)
		local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
		local repeatever = CCRepeatForever:create(sequence)
		widget:runAction(repeatever)
		--]]
	end
end
--加载冷却进度条
function __mineflag.loadCdBar(obj)
	obj:egHideWidget(kPanelCD)
	if obj._mineData.dt > 0 and not obj._hasCar then
		obj:egShowWidget(kPanelCD)
		local per = math.max(obj._mineData.dt,0)*100/obj._mine_cfg.gainInt
		obj._leftTime,obj._timeUnit = Funs.formmatTimeCh2(obj._mineData.dt,true)
		obj:egSetBMLabelStr(kImgTimeNum,obj._leftTime)
		obj:egSetBMLabelStr(kImgTimeCh,obj._timeUnit)
		obj._cdsprite:setPercentage(per)
		obj:egSetWidgetColor(kImgTimeNum,kRedColor)
		obj:egSetWidgetColor(kImgTimeCh,kRedColor)
		obj:egSetWidgetColor(kImgBg,kRedColor)
	else
		obj:egSetWidgetColor(kImgBg,kWhiteColor)
	end
end
function __mineflag.hasResCar(obj)
     for key,item in ipairs(obj._d_data.collectorList) do
            if item.pos == obj._idx then
                return true
            end
     end
     return false
end
function __mineflag.init(obj,idx,d_data)
    obj._idx = idx
    obj._d_data = d_data
	obj._hasCar = obj:hasResCar()
	obj._mineData = obj._d_data.mileSpread[idx]
	local mineName = KVariantList.coinType[obj._mineData.type]
	local minesrc = ImageList[string.format("comm_%s",mineName)]
	obj._mine_cfg = mile_data.get(obj._mineData.type, obj._mineData.lv)
	obj:egChangeImg(kImgFlag,minesrc,UI_TEX_TYPE_PLIST)
	
		--创建冷却显示控件
	local cdwidget = tolua.cast(obj:egGetWidgetByName(kImgCd):getVirtualRenderer(),"CCSprite")
    local sprite = CCSprite:createWithSpriteFrameName(ImageList.comm_cd)
    local scale = kCellW/sprite:getContentSize().width
    
    obj._cdsprite = CCProgressTimer:create(sprite)
    obj._cdsprite:setScale(scale)
	obj._cdsprite:setType(kCCProgressTimerTypeRadial)
	cdwidget:addChild(obj._cdsprite)
	
	obj:loadCdBar()
	obj:showFlag()
end
MineFlag = {}
function MineFlag.new(idx,d_data)
    local obj = {}
    CocosWidget.install(obj,JsonList.mineFlag)
    table_aux.unpackTo(__mineflag, obj)
    obj:init(idx,d_data)
    return obj
end
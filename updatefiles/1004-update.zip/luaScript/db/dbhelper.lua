local kTBGameVer = "TBGameVer"
local kTBAcctLog = "TBAcctLog"
local kTBAcctCfg = "TBAcctCfg"
local kTBLogHistory = "TBLogHistory"
local kTBPrivateMsg = "TBPrivateMsg"
local kTBPublicMsg = "TBPublicMsg"
local kTBGuildMsg = "TBGuildMsg"
local kTBCMScript = "TBCMScript"
local kTBCMScriptVersion = "TBCMScriptVersion"
DBHelper={}
function DBHelper.initDB()
	local dbname = "dblmdata.db"
	local dbpath = CCFileUtils:sharedFileUtils():getWritablePath()
	DBUtil:init(dbpath,dbname)
end
--=============================
--TBGameVer �ͻ��˰汾���
--=============================
--��ȡ��ǰ��Ϸ�汾
function DBHelper.getGameVer()
	local gameVer = DBUtil:getTop1CellVal(kTBGameVer,"rGameVer")
	gameVer = tonumber(gameVer or 0)
	return gameVer
end
--��ȡ��ǰ�����ص���Ϸ�汾
function DBHelper.getDownVer()
	local gameVer = DBUtil:getTop1CellVal(kTBGameVer,"rDownVer")
	gameVer = tonumber(gameVer or 0)
	return gameVer
end
--��ȡ��ǰ���µ���Ϸ�汾
function DBHelper.getLatestVer()
	local gameVer = DBUtil:getTop1CellVal(kTBGameVer,"rLatestVer")
	gameVer = tonumber(gameVer or 0)
	return gameVer
end
--��ȡ��ǰ��Ϸ�汾
function DBHelper.setGameVer(val)
	DBUtil:setTop1CellVal(kTBGameVer,"rGameVer",val)
end
--��ȡ��ǰ�����ص���Ϸ�汾
function DBHelper.setDownVer(val)
	DBUtil:setTop1CellVal(kTBGameVer,"rDownVer",val)
end
--��ȡ��ǰ���µ���Ϸ�汾
function DBHelper.setLatestVer(val)
	if not val then
		val = DBHelper.getDownVer()
	end
	DBUtil:setTop1CellVal(kTBGameVer,"rLatestVer",val)
end

--=============================
--TBAcctLog ��½��Ϣ���
--=============================
--��ȡ�ϴε�½������
--logName��½�ʺ�
function DBHelper.getLastLogServer(logName)
	local serverid = DBUtil:getValWithKey(kTBAcctLog,"rLogServer","rLogName",logName)
	if serverid then serverid = tonumber(serverid) end
	return serverid
end
--�޸��û���¼������
--logName��½�ʺ�
function DBHelper.setLastLogServer(logName,serverid)
	DBUtil:addOrSetValWithKey(kTBAcctLog,"rLogServer",serverid,"rLogName",logName)
end
--=============================
--TBAcctCfg ��������
--=============================
function DBHelper.getCfgWithKey(key)
	local cfgVal = DBUtil:getValWithKey(kTBAcctCfg,"rCfgVal","rCfgKey",key)
	if cfgVal then 
		cfgVal = tonumber(cfgVal) 
		if cfgVal == 0 then 
			cfgVal = false
		else 
			cfgVal = true
		end
	else
		cfgVal = false
	end
	return cfgVal
end
function DBHelper.setCfgWithKey(key,val)
	if val then 
		val = 1 
	else
		val = 0
	end
	DBUtil:addOrSetValWithKey(kTBAcctCfg,"rCfgVal",val,"rCfgKey",key)
end
--=============================
--TBLogHistory �ϴε�½���ʺ���Ϣ
--=============================
function DBHelper.getLastLogPID()
	local uid = DBUtil:getTop1CellVal(kTBLogHistory,"rPUserID")
	if uid then uid = tostring(uid) end
	return uid
end
function DBHelper.setLastLogPID(uid)
	DBUtil:setOrAddTop1CellVal(kTBLogHistory,"rPUserID",uid)
end
--=============================
--TBPrivateMsg ˽����Ϣ
----rIsRecv 0���͵���Ϣ 1���յ�����Ϣ
--=============================
function DBHelper.addPrivateMsg(userid,msgInfo)
	local insertCols = {}
	insertCols.rUserID=userid
	insertCols.rIsRecv=msgInfo.recvmsg
	insertCols.rTUserID=msgInfo.guid
	insertCols.rTUserName=msgInfo.name
	insertCols.rTDigLv=msgInfo.digLv
	insertCols.rTClubID=msgInfo.clubid
	insertCols.rTClubName=msgInfo.clubname
	insertCols.rMsg=msgInfo.content
	insertCols.rDate=msgInfo.date
	DBUtil:insertDataRow(kTBPrivateMsg,insertCols)
end
function DBHelper.getPrivateMsg(userid,cnt)
	local sql = string.format("SELECT * FROM TBPrivateMsg WHERE rUserID=$rUserID ORDER BY rID DESC LIMIT %d",cnt)
	local datatable = DBUtil:getDataTableWithParm(sql,{userid})
	local msgKey = {"recvmsg","guid","name","digLv","clubid","clubname","content","date"}
	local msgList = {}
	for rowid,datarow in ipairs(datatable) do
		local msginfo = {}
		msginfo.flag = 3
		for key,val in ipairs(msgKey) do
			msginfo[val] = datarow[key+2]
		end
		table.insert(msgList,msginfo)
	end
	table.sort(msgList,function(a,b) return a.date<b.date end)
	datatable = nil
	msgKey=nil
	return msgList
end
--=============================
--TBPublicMsg ������Ϣ
--=============================
function DBHelper.addPublicMsg(userid,msgInfo)
	local insertCols = {}
	insertCols.rUserID=userid
	insertCols.rFUserID=msgInfo.guid
	insertCols.rFUserName=msgInfo.name
	insertCols.rFDigLv=msgInfo.digLv
	insertCols.rFClubID=msgInfo.clubid
	insertCols.rFClubName=msgInfo.clubname
	insertCols.rMsg=msgInfo.content
	insertCols.rDate=msgInfo.date
	DBUtil:insertDataRow(kTBPublicMsg,insertCols)
end
function DBHelper.getPublicMsg(userid,cnt)
	local sql = string.format("SELECT * FROM TBPublicMsg WHERE rUserID=$rUserID ORDER BY rID DESC LIMIT %d",cnt)
	local datatable = DBUtil:getDataTableWithParm(sql,{userid})
	local msgKey = {"guid","name","digLv","clubid","clubname","content","date"}
	local msgList = {}
	for rowid,datarow in ipairs(datatable) do
		local msginfo = {}
		for key,val in ipairs(msgKey) do
			msginfo[val] = datarow[key+2]
		end
		table.insert(msgList,msginfo)
	end
	table.sort(msgList,function(a,b) return a.date<b.date end)
	datatable = nil
	msgKey=nil
	return msgList
end
--=============================
--TBCMScriptVersion �ű��汾
--=============================
function DBHelper.getCMScriptVer()
	local cmVer = DBUtil:getTop1CellVal(kTBCMScriptVersion,"rCMScriptVer")
	cmVer = tonumber(cmVer or 0)
	return cmVer
end
function DBHelper.setCMScriptVer(cmVer)
	DBUtil:setOrAddTop1CellVal(kTBCMScriptVersion,"rCMScriptVer",cmVer)
end
--=============================
--TBCMScript ����ű�
--=============================
--�洢�ű�
function DBHelper.saveCMScript(filename,filedata)
	DBUtil:addOrSetValWithKey(kTBCMScript,"rFileData",filedata,"rFileName",filename)
end
--�������г���ű�
function DBHelper.loadCMScript()
	local selectSql = string.format("SELECT * FROM TBCMScript")
	local function callbackfunc(filename,filedata)
		assert(filename and filedata)
		local chunck, err = loadstring(filedata,filename)
        if not chunck then print(err) return end
        local succ, err = pcall(chunck)
        if not succ then print(err) return end
	end
	DBUtil:execNonQueryWithCallback(selectSql,callbackfunc)
end
--�жϽű��Ƿ��б䶯
function DBHelper.hasNewCMScript()
	local sql = "SELECT COUNT(*) FROM TBCMScript"
	local cnt = tonumber(DBUtil:execScalar(sql,db))
	return cnt > 0
end


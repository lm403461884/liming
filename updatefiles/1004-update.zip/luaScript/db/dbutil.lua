local sqlite3 = require("lsqlite3")
DBUtil={}
--初始化数据库
function DBUtil:init(filepath,filename)
	self._sqlfolder = "luaScript/db"
	self._dbfile = filepath..filename
	if CCApplication:sharedApplication():getTargetPlatform() ==kTargetWindows then
		self._dbfile = Funs.toUTF(self._dbfile)
		print(self._dbfile)
	end
	self._db = sqlite3.open(self._dbfile)
	assert(self._db~=nil)
	if DBUtil:isDBNotEmpty(self._db) then 
		local dbver = DBUtil:getDBVer(self._db)
		for key,verCode in ipairs(DBVerList) do
			if dbver < verCode then
				dbver = verCode
				print("updating to ver:",dbver)
				local updatefile = self._sqlfolder.."/dbupdate"..dbver..".lua"
				HOEntryHelper.loadScriptByName(updatefile)
			end
		end
	else
		print("create db")
		local updatefile = self._sqlfolder.."/dbinstall.lua"
		HOEntryHelper.loadScriptByName(updatefile)
	end
	self._db:close()
	self._db = nil
end
--打开数据库 必须与closeDB成对出现
function DBUtil:openDB()
	local db = sqlite3.open(self._dbfile) 
	return db
end
--关闭数据库 调用openDB后必须调用
function DBUtil:closeDB(db)
	db:close()
end
function DBUtil:ExecSql(sql)
	DBUtil:execNoQuery(sql,self._db)
end
--查询并返回单个数值
function DBUtil:execScalar(sql,db)
	local needClose = false
	assert(sql~=nil)
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local colVal = nil
	local function callback(ud, ncols, values, names)
		colVal = values[1]
	end
	local rtn = db:exec(sql,callback)
	assert(rtn==sqlite3.ABORT or rtn==sqlite3.OK)
	if needClose then db:close() end
	return colVal
end
--查询并返回单行数值
function DBUtil:getDataRow(sql,db)
	local needClose = false
	assert(sql~=nil)
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local rowdata = nil
	assert(db:exec(sql,function (ud, ncols, values, names) rowdata = values end)==sqlite3.ABORT)
	if needClose then db:close() end
	return rowdata
end
--执行insert/update 等不需要返回值的语句
function DBUtil:execNoQuery(sql,db)
	local needClose = false
	assert(sql~=nil)
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	assert(db:exec(sql)==sqlite3.OK)
	if needClose then db:close() end
end
function DBUtil:execNonQueryWithCallback(sql,callback,db)
	local needClose = false
	assert(sql~=nil)
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	function execCallback(ud, ncols, values, names)
		if callback then callback(unpack(values)) end
		return sqlite3.OK
	end
	assert(db:exec(sql,execCallback)==sqlite3.OK)
	if needClose then db:close() end
end
--查询并返回数据表
function DBUtil:getDataTable(sql,db)
	local needClose = false
	assert(sql~=nil)
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local rowData = {}
	function callback(ud, ncols, values, names)
		local tb = {}
		for key,val in ipairs(values) do
			tb[key] = val
		end
		table.insert(rowData,tb)
		return sqlite3.OK
	end
	assert(db:exec(sql,callback)==sqlite3.OK)
	if needClose then db:close() end
	return rowData
end
--获取指定列第一行的数据
function DBUtil:getTop1CellVal(tbname,colname,db)
	local sql = string.format("SELECT %s FROM %s LIMIT 1",colname,tbname)
	local colval = DBUtil:execScalar(sql,db)
	return colval
end
function DBUtil:setTop1CellVal(tbname,colname,colval,db)
	local sql = string.format("UPDATE %s SET %s=$%s ",tbname,colname,colname)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(colval) == sqlite3.OK)
	assert(vm:step() == sqlite3.DONE)
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
function DBUtil:insertTop1CellVal(tbname,colname,colval,db)
	local sql = string.format("INSERT INTO %s (%s) Values($%s) ",tbname,colname,colval)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(colval) == sqlite3.OK)
	assert(vm:step() == sqlite3.DONE)
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--只适用于只有一行数据的表
function DBUtil:setOrAddTop1CellVal(tbname,colname,colval,db)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	assert(db~=nil)
	local selectSql = string.format("SELECT COUNT(*) FROM %s ",tbname)
	local vm = db:prepare(selectSql)
	assert(vm, db:errmsg())
	local isExisted = false
	if (vm:step() == sqlite3.ROW) then
		isExisted = (tonumber(vm:get_uvalues()) > 0 )
	end
	assert(vm:finalize() == sqlite3.OK)
	if isExisted then
		DBUtil:setTop1CellVal(tbname,colname,colval,db)
	else
		DBUtil:insertTop1CellVal(tbname,colname,colval,db)
	end
	if needClose then db:close() end
end
--使用单值查找单个数据
function DBUtil:getValWithKey(tbname,selCol,conCol,conVal,db)
	local sql = string.format("SELECT %s FROM %s WHERE %s=$%s ",selCol,tbname,conCol,conCol)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local selVal = nil
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(conVal) == sqlite3.OK)
	if (vm:step() == sqlite3.ROW) then
		selVal = vm:get_uvalues()
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
	return selVal
end
--根据单个条件，修改单值
function DBUtil:setValWithKey(tbname,setCol,setVal,conCol,conVal,db)
	local sql = string.format("UPDATE %s SET %s=$%s WHERE %s=$con%s",tbname,setCol,setCol,conCol,conCol)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(setVal,conVal) == sqlite3.OK)
	assert(vm:step() == sqlite3.DONE)
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--根据单个条件，修改或者添加单值,只适用于队指定值化，其它值都可以空的表
function DBUtil:addOrSetValWithKey(tbname,setCol,setVal,conCol,conVal,db)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	assert(db~=nil)
	local selectSql = string.format("SELECT COUNT(*) FROM %s WHERE %s=$%s ",tbname,conCol,conCol)
	local vm = db:prepare(selectSql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(conVal) == sqlite3.OK)
	local isExisted = false
	if (vm:step() == sqlite3.ROW) then
		isExisted = (tonumber(vm:get_uvalues()) > 0 )
	end
	assert(vm:finalize() == sqlite3.OK)
	if isExisted then
		DBUtil:setValWithKey(tbname,setCol,setVal,conCol,conVal,db)
	else
		DBUtil:insertDataRow(tbname,{[setCol]=setVal,[conCol]=conVal},db)
	end
	if needClose then db:close() end
end
--添加或者修改单行数据
function DBUtil:addOrSetSingleRow(tbname,updateCols,conCols,db)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local conPart = ""
	local conCnt = 0
	for key,val in pairs(conCols) do
		conCnt = conCnt +1
		if conCnt == 1 then
			conPart = key.."=$"..key
		else
			conPart = conPart .." AND ".. key.."=$"..key
		end
	end
	local selectSql = string.format("SELECT COUNT(*) FROM %s WHERE %s ",tbname,conPart)
	local isExisted = false
	local vm = db:prepare(selectSql)
	assert(vm, db:errmsg())
	assert(vm:bind_names(conCols) == sqlite3.OK)
	if (vm:step() == sqlite3.ROW) then
		isExisted = (tonumber(vm:get_uvalues()) > 0 )
	end
	assert(vm:finalize() == sqlite3.OK)
	if isExisted then
		DBUtil:updateData(tbname,updateCols,conCols,db)
	else
		local insertCols = {}
		for key,val in pairs(updateCols) do	
			insertCols[key] = val
		end
		for key,val in pairs(conCols) do	
			insertCols[key] = val
		end
		DBUtil:insertDataRow(tbname,insertCols,db)
	end
	if needClose then db:close() end
end
--修改数据
function DBUtil:updateData(tbname,updateCols,conCols,db)
	local updatePart = ""
	local conPart = ""
	local paramData = {}
	local colCnt = 0
	for key,val in pairs(updateCols) do
		colCnt = colCnt +1
		if colCnt == 1 then
			updatePart = key.."=$"..key
		else
			updatePart = updatePart ..",".. key.."=$"..key
		end
		paramData[key] = val
	end
	local conCnt = 0
	for key,val in pairs(conCols) do
		conCnt = conCnt +1
		if conCnt == 1 then
			conPart = key.."=$con"..key
		else
			conPart = conPart .." AND ".. key.."=$con"..key
			
		end
		paramData["con"..key] = val
	end
	local sql = string.format("UPDATE %s SET %s WHERE %s",tbname,updatePart,conPart)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_names(paramData) == sqlite3.OK)
	assert(vm:step() == sqlite3.DONE)
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--插入单行数据
--insertCols = {col1 = val1,..}
function DBUtil:insertDataRow(tbname,insertCols,db)
	local colPart = ""
	local valPart = ""
	local colCnt = 0
	for key,val in pairs(insertCols) do
		colCnt = colCnt+1
		if colCnt == 1 then
			colPart = key
			valPart = "$"..key
		else
			colPart = colPart..","..key
			valPart = valPart..",$"..key
		end
		
	end
	local sql = string.format("INSERT INTO %s (%s) VALUES(%s)",tbname,colPart,valPart)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_names(insertCols) == sqlite3.OK)
	assert(vm:step() == sqlite3.DONE)
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--插入多行数据
--insertCols = {col1,col2..}
--insertVals = {{val1,val2..},..}
function DBUtil:insertTable(tbname,insertCols,insertVals,db)
	local colPart = ""
	local valPart = ""
	for key,val in ipairs(insertCols) do
		if key == #insertCols then
			colPart = colPart..val
			valPart = valPart .."$"..val 
		else
			colPart = colPart..val..","
			valPart = valPart .."$"..val..","
		end
	end
	local sql = string.format("INSERT INTO %s (%s) VALUES(%s)",tbname,colPart,valPart)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	for key,paramData in ipairs(insertVals) do
		assert(vm:reset() == sqlite3.OK)
		assert(vm:bind_values(unpack(paramData)) == sqlite3.OK)
		assert(vm:step() == sqlite3.DONE)
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--插入或者修改多行数据
--insertCols = {col1,col2..}
--insertVals = {{val1,val2..},..}
--keyIdx --唯一字段在insertCols中的索引
function DBUtil:insertOrUpdateTable(tbname,insertCols,insertVals,keyIdx,db)
	if not keyIdx or not insertCols[keyIdx] then return end
	local colPart = ""
	local valPart = ""
	for key,val in ipairs(insertCols) do
		if key == #insertCols then
			colPart = colPart..val
			valPart = valPart .."$"..val 
		else
			colPart = colPart..val..","
			valPart = valPart .."$"..val..","
		end
	end
	local sql = string.format("INSERT INTO %s (%s) VALUES(%s)",tbname,colPart,valPart)
	local delsql = string.format("DELETE FROM %s WHERE %s=$%s",tbname,insertCols[keyIdx],insertCols[keyIdx])
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	--删除原有记录
	local delvm = db:prepare(delsql)
	assert(delvm, db:errmsg())
	for key,paramData in ipairs(insertVals) do
		assert(delvm:reset() == sqlite3.OK)
		assert(delvm:bind_values(paramData[keyIdx]) == sqlite3.OK)
		assert(delvm:step() == sqlite3.DONE)
	end
	assert(delvm:finalize() == sqlite3.OK)
	--插入记录
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	for key,paramData in ipairs(insertVals) do
		assert(vm:reset() == sqlite3.OK)
		assert(vm:bind_values(unpack(paramData)) == sqlite3.OK)
		assert(vm:step() == sqlite3.DONE)
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--删除满足条件的所有数据
--conCols ={colname=val,...}
function DBUtil:deleteData(tbname,conCols,db)
	local conCnt = 0
	local conPart = ""
	for key,val in pairs(conCols) do
		conCnt = conCnt +1
		if conCnt == 1 then
			conPart = key.."=$"..key
		else
			conPart = conPart .." AND ".. key.."=$con"..key
		end
	end
	local sql = string.format("DELETE FROM %s WHERE %s",tbname,conPart)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_names(conCols) == sqlite3.OK)
	assert(vm:step() == sqlite3.DONE)
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
end
--清除单表数据
function DBUtil:clearTable(tbname,db)
	local sql = "DELETE FROM "..tbname
	DBUtil:execNoQuery(sql,db)
end
--获取满足条件的数据的首行首列值
function DBUtil:selectCellData(tbname,colName,conCols,tb)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local conPart = ""
	local conCnt = 0
	for key,val in pairs(conCols) do
		conCnt = conCnt +1
		if conCnt == 1 then
			conPart = key.."=$"..key
		else
			conPart = conPart .." AND ".. key.."=$"..key
		end
	end
	local selectSql = string.format("SELECT %s FROM %s WHERE %s ",colName,tbname,conPart)
	local vm = db:prepare(selectSql)
	assert(vm, db:errmsg())
	assert(vm:bind_names(conVal) == sqlite3.OK)
	local cellVal = nil
	if (vm:step() == sqlite3.ROW) then
		cellVal = vm:get_value()
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
	return cellVal
end
--不指定查询数据列，整个返回
function DBUtil:selectFullDataWithKey(tbname,conCol,conVal,db)
	local selectSql = string.format("SELECT * FROM %s WHERE %s=$%s ",tbname,conCol,conCol)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(selectSql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(conVal) == sqlite3.OK)
	local dataRow = {}
	while (vm:step() == sqlite3.ROW) do
		table.insert(dataRow,vm:get_values())
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
	return dataRow
end
--查询并返回指定数据列数据
--colList 需要返回的数据列
function DBUtil:selectColDataWithKey(tbname,colList,conCol,conVal,db)
	local colStr = table.concat(colList,",")
	local selectSql = string.format("SELECT %s FROM %s WHERE %s=$%s ",colStr,tbname,conCol,conCol)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(selectSql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(conVal) == sqlite3.OK)
	local dataRow = {}
	while (vm:step() == sqlite3.ROW) do
		table.insert(dataRow,vm:get_values())
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
	return dataRow
end
--使用已知的SQL和参数查询数据表
function DBUtil:getDataTableWithParm(sql,parmList,db)
	local needClose = false
	if not db then 
		db = sqlite3.open(self._dbfile) 
		needClose = true
	end
	local vm = db:prepare(sql)
	assert(vm, db:errmsg())
	assert(vm:bind_values(unpack(parmList)) == sqlite3.OK)
	local dataRow = {}
	while (vm:step() == sqlite3.ROW) do
		table.insert(dataRow,vm:get_values())
	end
	assert(vm:finalize() == sqlite3.OK)
	if needClose then db:close() end
	return dataRow
end
--判断数据库是否是空库
function DBUtil:isDBNotEmpty(db)
	local tbname = "TBDBVer"
	local notEmpty = DBUtil:isTableExisted(tbname,db)
	return notEmpty
end
--判断数据表是否存在
function DBUtil:isTableExisted(tbname,db)
	local sql =string.format(" SELECT count(*) FROM sqlite_master WHERE type='table' AND name='%s'",tbname)
	local tbCnt = tonumber(DBUtil:execScalar(sql,db))
	local isExisted = (tbCnt==1)
	return isExisted
end
--获取数据库版本,
function DBUtil:getDBVer(db)
	local sql =string.format(" SELECT rDBVer FROM TBDBVer LIMIT 1")
	local dbVer = tonumber(DBUtil:execScalar(sql,db))
	return dbVer
end

local kPanelLayer = "town_train"
local kImgTrain = "img_train"
local kMarkArrow = "img_arrow"
local kTrainName = "lbl_train_name"
local kTrainNames = "lbl_train_name_s"
local kBarLeft = "bar_left"

local kBtnOil = "btn_oil"
local kBtnGold = "btn_gold"
local kBtnDig = "btn_dig"

local kPanelOil = "oil_panel"
local kPanelGold = "gold_panel"
local kPanelDig = "dig_panel"
local kImgNoteFunc = "img_note_func"
local kImgNote = "img_note"
local kLblLeft = "lbl_left"

local kScale1 = 1.3
local kScale2 = 1.5
local kInterval1 = 1

local __townTrain = {}
function __townTrain.init(obj,trainid)
	obj._trainid = trainid
    obj._oldlv = account_data.train[trainid].lv --当前等级
    if trainid == 0 then obj._oldlv = account_data.digLv end
    local train_cfg = train.config[trainid]
    local s_data = train_cfg.research[obj._oldlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())
	obj:egSetLabelStr(kTrainName,TxtList.TrainIntr[trainid])
	obj:egSetLabelStr(kTrainNames,TxtList.TrainIntr[trainid])
	obj:egHideWidget(kBtnOil)
	obj:egHideWidget(kBtnGold)
	obj:egHideWidget(kBtnDig)
	obj:egHideWidget(kPanelDig)
	obj:egHideWidget(kPanelGold)
	obj:egHideWidget(kPanelOil)
	obj:egHideWidget(kImgNoteFunc)
	obj:egHideWidget(kImgNote)
	obj:egHideWidget(kBarLeft)
end
--��������ʾ
function __townTrain.bindImgStateListener(obj)
	obj._isUpdating = false --�����б��
	obj._left = 0
	local train_cfg = train.config[obj._trainid]
	local function update()
		local ri = account_data.train[obj._trainid].ri --��������
		if obj._isUpdating then
			if not ri or ri.left<=0 then --�������
				local train_cfg = train.config[obj._trainid]
				obj._oldlv = obj._oldlv + 1
				local s_data = train_cfg.research[obj._oldlv]
				obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
				obj._isUpdating = false
				obj:egHideWidget(kBarLeft)
		    else
		        if obj._left ~= ri.left then
                    obj._left = ri.left
                    local total = train_cfg.research[obj._oldlv+1].duration
                    obj:egSetBMLabelStr(kLblLeft,Funs.formatTime(obj._left))
                    obj:egSetBarPercent(kBarLeft,100- obj._left*100/total)
				end
			end
		else
			if ri and ri.left > 0 then --��ʼ����
			    obj._left = ri.left 
			    obj:egShowWidget(kBarLeft)
			    obj._isUpdating = true
			    obj:egChangeImg(kImgTrain,ImageList.town_train_updating)
			    local total = train_cfg.research[obj._oldlv+1].duration
			    obj:egSetBMLabelStr(kLblLeft,Funs.formatTime(obj._left))
                obj:egSetBarPercent(kBarLeft,100- obj._left*100/total)
			end
		end
	end
	obj:egBindWidgetUpdate(kImgTrain,update)
end
--��ͷ��������ʾ
function __townTrain.bindImgHeadListener(obj)
	obj._isUpdating = false --�����б��
	obj._left = 0
	local s_data = licenceLevelup[account_data.digLv]
	local function update()
		local ri = account_data.diggingLvContext --��������
		if obj._isUpdating then
			if not ri or ri.left<=0 then --�������
				--local train_cfg = train.config[obj._trainid]
				--obj._oldlv = obj._oldlv + 1
				--local s_data = train_cfg.research[obj._oldlv]
				--if obj._trainid then s_data = licenceLevelup[account_data.digLv]end--��ͷ
				print(train.config[obj._trainid].research[account_data.digLv].bodyImage[1])
				obj:egChangeImg(kImgTrain,train.config[obj._trainid].research[account_data.digLv].bodyImage[1])
				obj._isUpdating = false
				obj:egHideWidget(kBarLeft)
		    else
		        if obj._left ~= ri.left then
                    obj._left = ri.left
                    local total = s_data.duration
                    obj:egSetBMLabelStr(kLblLeft,Funs.formatTime(obj._left))
                    obj:egSetBarPercent(kBarLeft,100- obj._left*100/total)
				end
			end
		else
			if ri and ri.left > 0 then --��ʼ����
			    obj._left = ri.left 
			    obj:egShowWidget(kBarLeft)
			    obj._isUpdating = true
			    obj:egChangeImg(kImgTrain,ImageList.town_train_head_updating)
			    local total = s_data.duration
			    obj:egSetBMLabelStr(kLblLeft,Funs.formatTime(obj._left))
                obj:egSetBarPercent(kBarLeft,100- obj._left*100/total)
			end
		end
	end
	obj:egBindWidgetUpdate(kImgTrain,update)
end
--����������ʾ
function __townTrain.bindLvUpListener(obj)
	obj._canUpdate = false
	obj._noteImg = tolua.cast(obj:egGetWidgetByName(kImgNote),"ImageView")
	obj._noteImg:setVisible(false)	
	local function update()
		if not obj._isUpdating then
			local rearchData = train.config[obj._trainid].research[obj._oldlv+1]
			local canupdate= (rearchData and rearchData.licence <= account_data.digLv)
			if obj._canUpdate ~= canupdate then
				obj._canUpdate = canupdate
				obj._noteImg:setVisible(canupdate)
				if canupdate then
					obj:scaleWidget(obj._noteImg,kScale1,kScale2,kInterval1)
				else
					obj._noteImg:stopAllActions()
				end
			end
		elseif obj._canUpdate then
		    obj._noteImg:stopAllActions()
		    obj._canUpdate = false
			obj._noteImg:setVisible(false)
		end 
	end
	obj:egBindWidgetUpdate(kImgNote,update)
end
--��ͷ������ʾ
function __townTrain.bindHeadLvUpListener(obj)
    obj._canUpdate = false
    obj._noteImg = tolua.cast(obj:egGetWidgetByName(kImgNote),"ImageView")
	obj._noteImg:setVisible(false)	
    local function update()
        if not obj._isUpdating then
			local rearchData = licenceLevelup[account_data.digLv+1]
			local s_data = licenceLevelup[account_data.digLv]
			local canupdate= (rearchData and s_data.stars<= account_data.unlockedPVE[s_data.areaID].areaStars)
			if obj._canUpdate ~= canupdate then
				obj._canUpdate = canupdate
				obj._noteImg:setVisible(canupdate)
				if canupdate then
					obj:scaleWidget(obj._noteImg,kScale1,kScale2,kInterval1)
				else
					obj._noteImg:stopAllActions()
				end
			end
		elseif obj._canUpdate then
		    obj._noteImg:stopAllActions()
		    obj._canUpdate = false
			obj._noteImg:setVisible(false)
		end 
    end
    obj:egBindWidgetUpdate(kImgNote,update)
end

function __townTrain.scaleWidget(obj,widget,from,to,s)
	local scaleto1 = CCScaleTo:create(s,from)
	local scaleto2 = CCScaleTo:create(s,to)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end
function __townTrain.getTrainID(obj)
    return obj._trainid 
end
function __townTrain.getTrain(obj)
    return obj:egGetWidgetByName(kImgTrain)
end

function __townTrain.setSelected(obj,selected)
	if selected then
		obj:egNode():setScale(1.1)
	else
		obj:egNode():setScale(1)
	end
end
function __townTrain.onClicked(obj,callback)
    obj._clickCallBack = callback
end
function __townTrain.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._clickCallBack then obj._clickCallBack(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgTrain,nil,nil,touchEnded,touchCanceled)
end
TownTrain = {}
function TownTrain.new(trainid)
    local obj = {}
    CocosWidget.install(obj,JsonList.townTrain)
    table_aux.unpackTo(__townTrain, obj)
    obj:init(trainid)
	TrainInitial.install(obj,trainid) --加载各车箱自己的代码
    obj:bindClickListener()
    return obj
end

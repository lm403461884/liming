local kBtnOil = "btn_oil"
local kBtnGold = "btn_gold"
local kBtnDig = "btn_dig"
local kImgNoteFunc = "img_note_func"
local kImgNote = "img_note"
local kPanelDig = "dig_panel"
local kPanelOil = "oil_panel"
local kPanelGold = "gold_panel"
local kGoldZorder = 2
local kOilZorder = 3
local kPromptZorder = 4
local kMoveDistance = 100
local kRedColor = ccc3(245,100,100)
local kWhiteColor = ccc3(255,255,255)
local kScale1 = 1.3
local kScale2 = 1.5
local kInterval1 = 1
local __traininitial={}
-----------------------------------------------------
--��ͷ
----------------------------------------------------
local trainid = 0
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	--obj:egShowWidget(kImgNoteFunc)
	--obj:bindFuncListener()
	obj:bindImgHeadListener()
	obj:bindHeadLvUpListener()
end
--�ж��Ƿ����������������������
__traininitial[trainid].hasNewArea=function(obj)
	for areaID, pveArea in pairs(account_data.unlockedPVE) do
		if areaID ~= account_data.worldAreaID then
			for k, v in pairs(pveArea) do
				if type(v) == 'table' and v.stars == 0 then
					return true
				end
			end
		end
	end
	return false
end
--�����������������ʾ
__traininitial[trainid].bindFuncListener=function(obj)
	obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	obj._noteFuncImg:setVisible(false)
	obj._hasNewFunc = false
	local function update()
	    if not obj._canUpdate then
		    local hasNewFunc = obj:hasNewArea()
		    if obj._hasNewFunc ~= hasNewFunc then
			    obj._hasNewFunc = hasNewFunc
			    obj._noteFuncImg:setVisible(obj._hasNewFunc)
			    if obj._hasNewFunc then
				    obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
			    else
				    obj._noteFuncImg:stopAllActions()
			    end
		    end
		elseif obj._hasNewFunc then --�����������ʱ������������ʾ 
            obj._hasNewFunc = false
            obj._noteFuncImg:setVisible(false)
            obj._noteFuncImg:stopAllActions()   
		end    
	end
	obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
------------------------------------------------------------------
--��β
----------------------------------------------------
local trainid = 99
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNoteFunc)
	obj:bindFuncListener()
end
--�ж��Ƿ��п��Թ���ĳ���
__traininitial[trainid].hasNewTrain=function(obj)
    obj._allBought = true
	for key,val in pairs(train.def ) do
        if not account_data.train[val] then
            obj._allBought = false
            local traindata = train.config[val]
			local s_cfg = traindata.research[1]
			local licence = s_cfg.licence or 1
			if licence <= account_data.digLv then return true end
        end
    end
	return false
end
--�³�����ʾ
__traininitial[trainid].bindFuncListener=function(obj)
	obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	obj._noteFuncImg:setVisible(false)
	obj._hasNewFunc = false
	local function update()
		local hasNewFunc = obj:hasNewTrain()
		if obj._hasNewFunc ~= hasNewFunc then
			obj._hasNewFunc = hasNewFunc
			obj._noteFuncImg:setVisible(obj._hasNewFunc)
			if obj._hasNewFunc then
				obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
			else
				obj._noteFuncImg:stopAllActions()
			end
		end
		if obj._allBought then obj:egUnbindWidgetUpdate(kImgNoteFunc) end
	end
	obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
------------------------------------------------------------------
--���ﳵ��
----------------------------------------------------
local trainid = 6
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNoteFunc)
	obj:egShowWidget(kImgNote)
	obj:bindImgStateListener()
	obj:bindLvUpListener()
	obj:bindFuncListener()
end
--�ж��Ƿ��п��Թ���Ĺ���
__traininitial[trainid].hasNewMonster=function(obj)
    for monsterid,item in pairs(MonsterTrain) do
		local maxNum = item[obj._oldlv] or 0
		local ownNum = 0
		local ownData = account_data.monsterPool[monsterid]
		if ownData then ownNum = ownData.N end
		if ownNum < maxNum then return true end
    end
    return false
end
--�¹�����ʾ
__traininitial[trainid].bindFuncListener=function(obj)
	obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	obj._noteFuncImg:setVisible(false)
	obj._hasNewFunc = false
	local function update()
		if not obj._canUpdate  then
			local hasNewFunc = obj:hasNewMonster()
			if obj._hasNewFunc ~= hasNewFunc then
				obj._hasNewFunc = hasNewFunc
				obj._noteFuncImg:setVisible(obj._hasNewFunc)
				if obj._hasNewFunc then
					obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
				else
					obj._noteFuncImg:stopAllActions()
				end
			end
	    elseif obj._hasNewFunc then --�����������ʱ�����ع�����ʾ
	        obj._hasNewFunc  = false
	        obj._noteFuncImg:setVisible(false)
	        obj._noteFuncImg:stopAllActions()
		end
	end
	obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
------------------------------------------------------------------
--�ھ���
----------------------------------------------------
local trainid = 2
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNote)
	obj:egShowWidget(kPanelDig)
	obj:egShowWidget(kPanelGold)
	obj._goldPanel = obj:egGetWidgetByName(kPanelGold)
	obj._digPanel = obj:egGetWidgetByName(kPanelDig)
	obj._goldPanel:setPosition(ccp(obj._digPanel:getPositionX(),obj._digPanel:getPositionY()))
	obj:bindGoldBtnListener()--Click Event
	obj:bindDigBtnListener()--Click Event
    if obj:getDigState() then
        obj._digPanel:setVisible(true)
		obj._goldPanel:setVisible(false)
		obj:egHideWidget(kBtnGold)
        obj:egShowWidget(kBtnDig)
		obj:scaleWidget(obj._digPanel,0.9,1,kInterval1)
    else
        obj._digPanel:setVisible(false)
        obj:egHideWidget(kBtnDig)
        obj:bindGoldListener() --timer
    end
	obj:bindImgStateListener()
	obj:bindLvUpListener()
	
end
__traininitial[trainid].bindGoldBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = DigScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnGold,nil,nil,touchEnded,nil)
end
__traininitial[trainid].bindDigBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = DigScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnDig,nil,nil,touchEnded,nil)
end

--���ռ���Դ��ʾ
__traininitial[trainid].bindGoldListener=function(obj)
    obj._goldPanel:setVisible(false)
    obj:egHideWidget(kBtnGold)
	local function update()
	    local hasCollRes = obj:hasCollRes()
	    if hasCollRes then
	        obj:egUnbindWidgetUpdate(kBtnGold)
	        obj._goldPanel:setVisible(true)
	        obj:scaleWidget(obj._goldPanel,0.9,1,kInterval1)
	        obj:egShowWidget(kBtnGold)
	    end
	end
	obj:egBindWidgetUpdate(kBtnGold,update)
end
__traininitial[trainid].hasCollRes = function(obj)
    for key,resCar in ipairs(account_data.collectorList) do
		local targetMine = account_data.mileSpread[resCar.pos]
		if targetMine then
			if not targetMine.dt or targetMine.dt <= 0 then return true end
		end
    end
    return false
end
__traininitial[trainid].isMineRemovable = function(obj,idx,digTrace,w,h)
    if idx > 0 and digTrace[idx] then return false end
    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  digTrace[idx_l] then  return true end--����������ھ�
    return false
end
--�ھ���ʾ
__traininitial[trainid].getDigState=function(obj)
    if account_data.digPt ==account_data.masDigPt  then return true end
    local w,h = scene_data.getWH(account_data.sceneID, account_data.sceneLv)
    for key,val in pairs(account_data.mileSpread) do
        if obj:isMineRemovable(key,account_data.digTrace,w,h) then 
            return false
        end
    end
    return true
end
------------------------------------------------------------------
--���߳���
----------------------------------------------------
local trainid = 3
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNote)
	obj:bindImgStateListener()
	obj:bindLvUpListener()
end
--------------------------------------------------------------------
--װ������
---------------------------------------------------------------------
local trainid = 8 
__traininitial[trainid] = {}
__traininitial[trainid].initSelfData = function(obj)
    obj:egShowWidget(kImgNoteFunc)
	obj:egShowWidget(kImgNote)
	obj:bindImgStateListener()
	obj:bindLvUpListener()
	obj:bindFuncListener()
end
--�ж��Ƿ��п�������װ��
__traininitial[trainid].hasEquipLvUp = function (obj)
	local trainlv = account_data.train[train.def.equip].lv
    for eid,item in pairs (account_data.equipments) do
        local curlv,curqa = equipFuncs.getEquipQL(eid, account_data)
		local maxlv = trainlv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
		if (curlv <maxlv and equipFuncs.getData(eid,curlv+1))  or math.floor(curlv* numDef.weaponQaFactor) > curqa then --������������׿ռ�
            return true
        end
    end
    return false
end

__traininitial[trainid].bindFuncListener = function(obj)
    obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
    obj._noteFuncImg:setVisible(false)
    obj._hasNewFunc = false
    local function update()
        if not obj._canUpdate then
            local hasNewFunc = obj:hasEquipLvUp()
            if  obj._hasNewFunc ~= hasNewFunc then
                obj._hasNewFunc = hasNewFunc
                obj._noteFuncImg:setVisible(obj._hasNewFunc)
                if obj._hasNewFunc then
                    obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
                else
                    obj._noteFuncImg:stopAllActions()
                end
            end
        elseif obj._hasNewFunc then
            obj._hasNewFunc  = false
	        obj._noteFuncImg:setVisible(false)
	        obj._noteFuncImg:stopAllActions()
        end
    end
    obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
----------------------------------------------------------------------
--��Ϣ��
----------------------------------------------------
local trainid = 4
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNote)

	obj:bindImgStateListener()
	obj:bindLvUpListener()
end 
----------------------------------------------------
TrainInitial={}
function TrainInitial.install(obj,trainid)
	if __traininitial[trainid] then
		table_aux.unpackTo(__traininitial[trainid], obj)
		obj:initSelfData()
	end
end
------------------------------------------------------------
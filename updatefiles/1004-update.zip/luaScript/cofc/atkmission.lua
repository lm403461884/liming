local kLabelMissionName = "mission_name_lbl"
local kLabelHard = "hard_lbl"
local kLabelTeamCap = "lbl_team_cap"
local kBtnRight0 ="btn_right"
local kBtnRight1 ="btn_right1"

local kBtnStart = "btn_start"
local kBtnBack = "btn_back"
local kPanelLayer = "atk_mission_panel"
local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"
local kPanelAward3 = "award_panel3"
local kPanelAward = "award_panels"

local kPanelHero = "hero_list"
local kPanelMonster = "monster_list"
local kLabelCost = "lbl_cost"
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)
local kMaxLoadNum = 2
local kMaxNum = 4
local kCellW = 110
local __atkmission ={}
function __atkmission.init(obj,areaid,stageid)
    obj._areaid = areaid
    obj._stageid = stageid
    obj._s_data = pveQuery.queryStage(areaid,stageid)
    obj._costVal = obj._s_data.costAct
	local suggestAtk = obj._s_data.suggestLv
	if  MissionHelper.groupIdx  then --�ճ�����
		suggestAtk =  baseCalc.getDaysuggestLv(account_data.digLv, obj._s_data.suggestLv) 
	elseif account_data.unlockedPVE[areaid][stageid].first then  
		obj._costVal = 0
	end
	
    obj:egSetBMLabelStr(kLabelCost,obj._costVal)    
    if obj._costVal > account_data.actPt then 
        obj:egSetWidgetColor(kLabelCost,kRedColor) 
        obj:egSetWidgetEnabled(kBtnStart,false)
        obj:activeUpdate()
    end
	
	local teamCap = obj:getTeamAtkCap()
    obj:egSetLabelStr(kLabelMissionName,obj._s_data.name)
	obj:egSetLabelStr(kLabelHard,string.format("%s: %d",TxtList.suggestCap,suggestAtk))
	obj:egSetLabelStr(kLabelTeamCap,string.format("%s: %d",TxtList.teamCap,teamCap))
	if teamCap >= suggestAtk then obj:egSetWidgetColor(kLabelHard,kBrownColor) end
	obj:loadAward()
    obj:loadHeros()
    obj:loadMonsters()
    obj:showWithAction()
end
--����ļ������Ӣ��ս�������ݱ�
function __atkmission.getTeamAtkCap(obj)
    local tb = {}
	local teamAtk = 0
    for key,heroprop in pairs(account_data.heroList) do
        local equiplv,equipqa =  equipFuncs.getEquipQL(heroprop.eid,account_data)
        local atkcap = baseCalc.getBattlePoint(heroprop.lv,equiplv,equipqa)
        tb[heroprop.type] = atkcap
    end
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk + tb[heroid]
    end
	tb = nil
    return teamAtk
end
--��ȡ������Ϣ
function __atkmission.getAwardResList(obj)
	local resList={}
	local heroMsgList = {}
	local expVal = obj._s_data.exp
	for idx = 1,7 do resList[idx] = 0 end
	if MissionHelper.groupIdx then
		resList[1],resList[3],resList[4],resList[5],resList[6],resList[7]=baseCalc.getDayRes(account_data.digLv, obj._s_data.gold,obj._s_data.iron,obj._s_data.copper,obj._s_data.stoneR,obj._s_data.stoneB,obj._s_data.stoneD)
		heroMsgList = obj._s_data.heromessage or {}
		expVal = baseCalc.getDaypveExp(account_data.digLv,obj._s_data.exp)
	else
		if account_data.unlockedPVE[obj._areaid][obj._stageid].first then
			for idx = 1,7 do 
				resList[idx] = obj._s_data[ KVariantList.coinType[idx]] or 0
			end
			heroMsgList = obj._s_data.heromessage or {}
		else
			for idx = 1,2 do 
				resList[idx] = obj._s_data[ KVariantList.coinType[idx]] or 0
			end
		end
	end
	return resList,heroMsgList,expVal
end
--���ص�һ�δ��������Ľ�����Ϣ
function __atkmission.loadAward(obj)

	local awardResList,heroMsgList,expVal = obj:getAwardResList()
	local loadCnt = 0
    for idx,coinval in pairs(awardResList) do
		local coinname = KVariantList.coinType[idx]
		if coinval > 0 then
			loadCnt = loadCnt+1
			local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,coinval))
			obj:addItemToAwardPanel(awarditem,loadCnt)
		end
	end
	for heroid,msgnum in pairs(heroMsgList) do
	    loadCnt = loadCnt + 1
	    local heromsg = HeroMsg.new(heroid,string.format("%s%d",TxtList.numSymbol,msgnum))
		obj:addItemToAwardPanel(heromsg,loadCnt)
	end
	local expitem = AwardItem.new("exp",string.format("%s%d",TxtList.numSymbol,expVal))
	 loadCnt = loadCnt + 1
	obj:addItemToAwardPanel(expitem,loadCnt)
	if loadCnt <= kMaxLoadNum then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panel1:getSize().height
		panel2:setVisible(false)
		panel3:setVisible(false)
		panel:setPosition(ccp(panel:getPositionX(),panel:getPositionY() + (panelsize.height-newh)/2))
		panel:setSize(CCSizeMake(panelsize.width,newh))
	elseif loadCnt <= kMaxLoadNum*2 then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panelsize.height - panel3:getSize().height
		panel3:setVisible(false)
		panel:setPosition(ccp(panel:getPositionX(),panel:getPositionY() + (panelsize.height-newh)/2))
		panel:setSize(CCSizeMake(panelsize.width,newh))
	end
end
function __atkmission.addItemToAwardPanel(obj,item,loadCnt)
    local margin = 50
	local awardsize = item:egNode():getSize()
	item:egNode():setSize(CCSizeMake(awardsize.width + margin,awardsize.height))
	if loadCnt <= kMaxLoadNum then
	    local panel1 = obj:egGetWidgetByName(kPanelAward1)
		panel1:addChild(item:egNode())
	elseif loadCnt <= kMaxLoadNum*2 then
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
		panel2:addChild(item:egNode())
	else
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
		panel3:addChild(item:egNode())
	end
end
function __atkmission.loadHeros(obj)
    local heros = account_data.team
    local listview  = obj:egGetListView(kPanelHero)
    for key,heroid in ipairs(heros) do
		local herodata =account_data.heroList[heroid]
        heroHead = HeroHead.new(heroid,herodata.lv)
        listview:pushBackCustomItem(heroHead:egNode())
    end
    if #heros < kMaxNum then 
		local size = listview:getSize()
		local neww = #heros * kCellW
		local newx = (size.width-neww)/2 + listview:getPositionX()
		listview:setSize(CCSizeMake(neww,size.height))
		listview:setPosition(ccp(newx,listview:getPositionY()))
    end
end

function __atkmission.getMonsters(obj)
    local tb = {}
    for pos,monsterid in pairs(obj._s_data.creatureList) do
        if not tb[monsterid] then tb[monsterid] = 1 
        else tb[monsterid] = tb[monsterid] + 1 end
    end
    return tb
end
function __atkmission.loadMonsters(obj)
    local monsters = obj:getMonsters()
    local listview =obj:egGetListView(kPanelMonster)
    local cnt = 0
     for monsterid,num in pairs(monsters) do
        cnt = cnt + 1
        local monsterHead = MonsterHead.new(monsterid,num,obj._s_data)
        listview:pushBackCustomItem(monsterHead:egNode())
     end
     if cnt > 3 then 
        obj:egShowWidget(kBtnRight0)
     else
        obj:egHideWidget(kBtnRight0)
     end
end

function __atkmission.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __atkmission.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end

function __atkmission.clickStart(obj)
    SoundHelper.playEffect(SoundList.click_shop_goods)
    account_data.actPt = account_data.actPt - obj._costVal
	--�ھ���־������̸���,ֻ�����Ĵ���0�ǽ���
	if obj._costVal > 0 then
		task.updateTaskStatus(account_data,task.client_event_id.cost_actPt,{obj._costVal})	
	end
	----------------------------------------------------------
    if account_data.actPt < 0 then account_data.actPt = 0 end
    local scene = AtkScene.new(obj._areaid,obj._stageid)
    scene:egReplace()
end
--��ʼPVEս��
function __atkmission.bindStartListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:clickStart()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
function __atkmission.bindBackListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egSetWidgetTouchEnabled(kBtnCancel,false)
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __atkmission.activeUpdate(obj)
    local function callback()
         if obj._costVal <= account_data.actPt then 
            obj:egSetWidgetColor(kLabelCost,kWhiteColor) 
            obj:egSetWidgetEnabled(kBtnStart,true)
            obj:egUnbindWidgetUpdate(kBtnStart)
        end
    end
    obj:egBindWidgetUpdate(kBtnStart,callback)
end
AtkMission={}
function AtkMission.new(areaid,stageid,onloaded)
     local obj =  TouchWidget.new(JsonList.cofcAtkMission)
    table_aux.unpackTo(__atkmission, obj)
    obj._onloaded = onloaded
    obj:init(areaid,stageid)
    obj:bindStartListener()
    obj:bindBackListener()
    return obj
end
function showAtkMission(areaid,stageid,onloaded)
        local layer = AtkMission.new(areaid,stageid,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer + 1,UILv.popLayer + 1)
end

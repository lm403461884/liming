local kTypeImg = {[0]=ImageList.pve_atk,[1]=ImageList.pve_dfs}--��������ͼƬ��Դ����0:������1������
local kPanelAward = "award_panel"
local kImgPvpType = "pvp_type_img"
local kLabelUserType = "pvp_user_lbl"
local kLabelUserName = "lbl_user_name"
local kLabelTime = "time_lbl"
local kBtnPlay = "play_btn"
local kPanelHero = "hero_list"
local kLabelState = "lbl_state"
local kImgStamp = "img_stamp"
local kRedColor = ccc3(128,0,0)
local kGreenColor = ccc3(0,128,0)
local __pvpitem={}
function __pvpitem.init(obj,idx)
    obj._idx = idx
    obj._videoinfo = account_data.battleSumaries[obj._idx]
    obj._vid = obj._videoinfo.vid
	for idx = 2,7 do
		local coinname = KVariantList.coinType[idx]
		obj._videoinfo[string.format("def_%s",coinname)] = -(obj._videoinfo[string.format("atk_%s",coinname)] or 0)
	end
    obj._ptime = Funs.formatTimeCh(os.time() -  obj._videoinfo.time,true,true,true,nil,true)
    if  obj._videoinfo.atkGuid == account_data.guid then
		obj:loadAtkInfo()
		obj:loadHeros( obj._videoinfo.hero,false)
	else
		obj:loadDefInfo()
		obj:loadHeros( obj._videoinfo.hero,true)
    end
end
function __pvpitem.loadAward(obj,atkflag)
    local panel = obj:egGetWidgetByName(kPanelAward)
    local eloaward = AwardItem.new("elo",Funs.signedNum(obj._videoinfo[string.format("%s_%s",atkflag,"elo")]))
    panel:addChild(eloaward:egNode())
    for idx = 1,7 do
        local coinname = KVariantList.coinType[idx]
        local coinval = obj._videoinfo[string.format("%s_%s",atkflag,coinname)] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
            panel:addChild(awarditem:egNode())
        end
    end
end
--Ϊ������ʱ��¼������
function __pvpitem.loadAtkInfo(obj)
	obj:egChangeImg(kImgPvpType,ImageList.pve_atk,UI_TEX_TYPE_PLIST)
	obj:loadAward("atk")
    obj:egSetLabelStr(kLabelTime,string.format("%s%s",obj._ptime,TxtList.ago))
	obj:egSetLabelStr(kLabelUserType,TxtList.defUserTxt)
	obj:egSetLabelStr(kLabelUserName,obj._videoinfo.defName)
	if obj._videoinfo.stars > 0 then
		obj:egSetWidgetColor(kLabelState,kGreenColor)
		obj:egSetWidgetColor(kImgStamp,kGreenColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.succTxt))
	else
		obj:egSetWidgetColor(kLabelState,kRedColor)
		obj:egSetWidgetColor(kImgStamp,kRedColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.failTxt))
	end
end
--Ϊ���ط�ʱ��¼������
function __pvpitem.loadDefInfo(obj)
	obj:egChangeImg(kImgPvpType,ImageList.pve_dfs,UI_TEX_TYPE_PLIST)
	obj:loadAward("def")
    obj:egSetLabelStr(kLabelTime,string.format("%s%s",obj._ptime,TxtList.ago))
	obj:egSetLabelStr(kLabelUserType,TxtList.atkUserTxt)
	obj:egSetLabelStr(kLabelUserName, obj._videoinfo.atkName)
	if obj._videoinfo.stars == 0 then
		obj:egSetWidgetColor(kLabelState,kGreenColor)
		obj:egSetWidgetColor(kImgStamp,kGreenColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.succTxt))
	else
		obj:egSetWidgetColor(kLabelState,kRedColor)
		obj:egSetWidgetColor(kImgStamp,kRedColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.failTxt))
	end
end
function __pvpitem.getValTxt(obj,val)
	local txt = math.abs(val)
	if val > 0 then txt = string.format("+%s",txt)
	elseif val <0 then txt = string.format("-%s",txt) end
	return txt
end
function __pvpitem.loadHeros(obj,herolist,isememy)
	local listview =obj:egGetListView(kPanelHero)
    for heroid,herolv in pairs(herolist)do
        local heroHead  = HeroHead.new(heroid,herolv,isememy)
        listview:pushBackCustomItem(heroHead:egNode())
    end
end
--��ȡ��ƵID
function __pvpitem.getItemIdx(obj)
	return obj._vid
end
function __pvpitem.onClicked(obj,callback)
	obj._clickCallback = callback
end
function __pvpitem.bindPlayListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_shop_goods)  --�����Ŀ
       obj:egSetWidgetTouchEnabled(kBtnPlay,false)
       if obj._clickCallback then obj._clickCallback(obj) end
    end
    obj:egBindTouch(kBtnPlay,nil,nil,touchEnded,nil)
end

PvpItem={}
function PvpItem.new(idx)
    local obj = {}
    CocosWidget.install(obj,JsonList.pvpItem)
    table_aux.unpackTo(__pvpitem, obj)
    obj:init(idx)
    obj:bindPlayListener()
    return obj
end

local kPanelLayer ="info_panel"
local kLblLicence = "lbl_licence"
local kLblElo = "lbl_elo"
local kLblName = "lbl_username"
local kLblClub = "lbl_club"
local kLblAtkCap = "lbl_atkCap"
local kLblDigPt = "lbl_digPt"
local kHeroList = "hero_list"
local kBtnClose = "btn_close"
local kPanleDetail = "detail_panel"
local kImgLoading = "img_loading"
local kCardW = 146
local __pubuserinfo={}

function __pubuserinfo.init(obj,userguid)
    obj._guid = userguid
	obj._userBrief = ChatHelper.getUserBrief(userguid)
	if obj._userBrief  then
		obj:loadUserData()
	else
		SendMsg[931009](obj._guid)
		obj:egHideWidget(kPanleDetail)
		obj:activeWaitTimer()
	end
	obj:showWithAction()
end
function __pubuserinfo.activeWaitTimer(obj)
    obj:egShowWidget(kImgLoading)
    local passed = 0
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
    local function callback(delta)
        passed = passed + delta
		obj._userBrief = ChatHelper.getUserBrief(obj._guid)
		if obj._userBrief then
			 obj:egUnbindWidgetUpdate(kImgLoading)
			 obj:loadUserData()
		elseif passed > numDef.clientTimeOut then
			 obj:egUnbindWidgetUpdate(kImgLoading)
			 imgWidget:stopAllActions()
             local function callback()
				  local scene = LogoScene.new()
				  scene:egReplace()
			 end
			local msglayer = MsgLayer.new(nil,TxtList.dataUnMatch,1,callback)
			msglayer:show()
		end
    end
    obj:egBindWidgetUpdate(kImgLoading,callback)
end
function __pubuserinfo.loadUserData(obj)
	obj:egHideWidget(kImgLoading)
	obj:egShowWidget(kPanleDetail)
	obj:egSetBMLabelStr(kLblLicence,obj._userBrief.diglv)
	obj:egSetBMLabelStr(kLblElo,obj._userBrief.elo)
	obj:egSetLabelStr(kLblName,obj._userBrief.username)
	
	if obj._userBrief.clubid == 0 then
		obj:egSetLabelStr(kLblClub,TxtList.noClub)
	else
		obj:egSetLabelStr(kLblClub,string.format("<%s>",obj._userBrief.clubname))
	end
	obj:egSetLabelStr(kLblDigPt,obj._userBrief.digPt)
	local heroPanel = obj:egGetWidgetByName(kHeroList)
	local teamAtkCap = 0
	local heroCnt = 0
	for key,heroprop in pairs(obj._userBrief.heroList) do
		teamAtkCap = teamAtkCap + baseCalc.getBattlePoint(heroprop.herolv,heroprop.equiplv,heroprop.equipqa)
		local herocard = PubHeroCard.new(heroprop)
		heroPanel:addChild(herocard:egNode())
		heroCnt = heroCnt + 1
    end
	local oldw = heroPanel:getSize().width
	local h = heroPanel:getSize().height
	local w = kCardW * heroCnt
	heroPanel:setSize(CCSizeMake(w,h))
	local offsetx = (oldw - w)/2
	heroPanel:setPosition(ccp(heroPanel:getPositionX() + offsetx,heroPanel:getPositionY()))
	
    obj:egSetLabelStr(kLblAtkCap,teamAtkCap)
end
function __pubuserinfo.hideWithAction(obj)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
        if obj._onclosed then obj._onclosed() end
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __pubuserinfo.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     baseWidget:runAction(spawn)

end
--�ر�����ҳ��
function __pubuserinfo.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,nil)
end
PubUserInfo={}
function PubUserInfo.new(guid,onclosed)
   local obj =  TouchWidget.new(JsonList.pubUserInfo)
    table_aux.unpackTo(__pubuserinfo, obj)
    obj._onclosed = onclosed
    obj:init(guid)
    obj:bindCloseListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end
function showPubUserInfo(guid,onclosed)
    local layer = PubUserInfo.new(guid,onclosed)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
local __pubMsgList = {} --������Ϣ��
local __guidShield = {} --�����ε���guid
local __hasInnerMsg = false
local __hasPubMsg = false
local __newCreated = false
local __newJoin = false
local __userBriefs = {}
ChatHelper = {}
--��ȡ����Ϣ
function ChatHelper.getMsgById(mid)
	return __pubMsgList[mid]
end
function ChatHelper.getMaxId()
	return #__pubMsgList
end
--�Ƿ��й�����Ϣ
function ChatHelper.hasInnerMsg()
	return __hasInnerMsg
end
--�Ƿ��й�����Ϣ
function ChatHelper.hasPubMsg()
	return __hasPubMsg
end
--�Ƿ����´����ɹ��Ĺ���
function ChatHelper.isNewCreated()
	return __newCreated
end
--�Ƿ��Ǹ��������Ĺ���
function ChatHelper.isNewJoin()
	return __newJoin
end
--���ù�����Ϣ��ʶ
function ChatHelper.setHasInnerMsg(has)
	__hasInnerMsg = has
end
--���ù�����Ϣ��ʶ
function ChatHelper.setHasPubMsg(has)
	__hasPubMsg = has
end
--�����¹����ʶ
function ChatHelper.setNewCreated(isnew)
	__newCreated = isnew
end
--�����¼����ʶ
function ChatHelper.setNowJoin(isnew)
	__newJoin = isnew
end
--��ȡ��ǰ�鿴���û���Ϣ���
function ChatHelper.getUserBrief(userguid)
	if userguid == account_data.guid then
		local tb = {}
		tb.diglv = account_data.digLv
		tb.elo = account_data.elo
		tb.username = account_data.nickName
		tb.digPt = account_data.maxDigPt
		tb.clubid = 0
		tb.clubname = ""
		if club_data then
			tb.clubid = club_data.cid
			tb.clubname = club_data.clubName
		end
		tb.heroList={}
		for key,heroid in ipairs(account_data.team) do
			local herodata = account_data.heroList[heroid]
			local heroprop = {}
			heroprop.heroid = heroid
			heroprop.herolv= herodata.lv
			heroprop.equipid=herodata.eid
			heroprop.equiplv,heroprop.equipqa=equipFuncs.getEquipQL(herodata.eid,account_data)
			tb.heroList[heroid] = heroprop
		end
		return tb
	else
		if __userBriefs[userguid] and os.time() -  __userBriefs[userguid].refreshTime < 2 then
			return __userBriefs[userguid]
		else
			return nil
		end
	end
end
--�޸ĵ�ǰ�鿴���û���Ϣ
function ChatHelper.addUserBrief(userbrief)
	local userguid = userbrief.guid
	local cnt = #__pubMsgList
	userbrief.clubid = 0
	userbrief.clubname = ""
	userbrief.username = ""
	for idx =cnt,1,-1 do
		local pubmsg = __pubMsgList[idx]
		if pubmsg.guid == userguid then
			userbrief.clubid = pubmsg.clubid
			userbrief.clubname = pubmsg.clubname
			userbrief.username = pubmsg.name
			break
		end
	end
	__userBriefs[userguid] = userbrief	
end
--�������������Ϣ
function ChatHelper.shieldMsg(userguid)
    table.insert(__guidShield,userguid)
	local cnt = #__pubMsgList
	for idx = cnt,1,-1 do
		local pubmsg = __pubMsgList[idx]
		if pubmsg.guid == userguid then
			table.remove(__pubMsgList,idx)
		end
	end
end
--�����µĹ�����Ϣ
function ChatHelper.addNewMsg(userguid,digLv,name,clubid,clubname,content)
	for _,shieldguid in ipairs (__guidShield) do
	    if newmsg.guid == shieldguid then return end
	end
	local newmsg = {}
	newmsg.guid = userguid
	newmsg.name = name
	newmsg.digLv = digLv
	newmsg.date = os.time()
	newmsg.clubid = clubid
	newmsg.clubname = clubname
	newmsg.content = content
	for key,pubmsg in ipairs(__pubMsgList) do
		if pubmsg.guid == userguid then
			pubmsg.digLv = digLv
			pubmsg.clubid = clubid
			pubmsg.clubname = clubname
		end
	end
	table.insert(__pubMsgList,newmsg)
	__hasPubMsg = true
end
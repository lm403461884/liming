local kImgName = "img_search_name"
local kTextName = "text_search_name"
local kLblNo = "lbl_search_no"
local kBtnSearch = "btn_search"
local kImgPrompt = "img_prompt1"
local kImgLongLine = "img_longline1"
local kListMembers = "list_members"
local kImgLoading = "img_loading"

local kBtnMember = "Button_member" --����json�ļ�
local kWhiteColor = ccc3(255,255,255)
local kRedColor = ccc3(255,0,0)
local kMaxNum = 6
 kStateSearch = "club_search_result"

club_search = nil
local __searchlayer={}
function __searchlayer.init(obj)
    obj:egHideWidget(kLblNo)
    obj._changed = false --���������Ƿ�ı� 
    obj._oldName = nil
    obj._nameColor = kWhiteColor
    obj._guildInfo = nil
    obj._listview = obj:egGetListView(kListMembers)
    obj._oldH=0
    
    obj._imgWait = obj:egGetWidgetByName(kImgLoading)
    obj:egHideWidget(kImgPrompt) 
    obj:egHideWidget(kImgLongLine)  
    obj:egHideWidget(kListMembers)
    obj:egHideWidget(kImgLoading)
end
function __searchlayer.checkName(obj)
    local guildname = obj:egGetTextFieldVal(kTextName)
    if guildname == obj._oldName then
        obj._changed = false
    else
        obj._changed = true
        obj._oldName = guildname
    end
    local len = string.len(guildname)
    if len<1 or len>16 then
        print("name is too long")
        return false
    end
    return true
end

function __searchlayer.bindNameBgListener(obj)
     local function touchEnded(sender)
         local textField = tolua.cast(obj:egGetWidgetByName(kTextName),"TextField")
         textField:attachWithIME()
     end
     obj:egBindTouch(kImgName,nil,nil,touchEnded,nil)
end

function __searchlayer.bindTextNameListener(obj)
    local function textFieldEvent(sender)
        local textField = tolua.cast(sender,"TextField")
        local text = textField:getStringValue()
        if text =="" and obj._nameColor == kWhiteColor then
            obj._nameColor = kRedColor
            obj:egSetWidgetColor (kImgName,kRedColor)
        elseif text ~="" and obj._nameColor == kRedColor then
            obj._nameColor = kWhiteColor
            obj:egSetWidgetColor (kImgName,kWhiteColor)    
        end
    end
    local widget = obj:egGetWidgetByName(kTextName)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent)
end

function __searchlayer.bindSearchListener(obj) -- ��������
    local function touchEnded(sender)
       local guildname = obj:egGetTextFieldVal(kTextName)
       if not obj:checkName() then return end
       if not obj._changed then  return end
       obj:egSetWidgetTouchEnabled(kBtnSearch,false)
       club_search = nil
       AccountHelper:lock(kStateSearch)
       SendMsg[938003](guildname)
       obj:actionWait()
       obj:activeUpdate()
    end
    obj:egBindTouch(kBtnSearch,nil,nil,touchEnded,nil)
end

--��������ȴ�����
function __searchlayer.actionWait(obj)
    obj:egShowWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
end

function __searchlayer.activeUpdate(obj)
    local function callback()
        if not AccountHelper:isLocked(kStateSearch) then
            if club_search then
                obj:egSetWidgetTouchEnabled(kBtnSearch,true)
                obj._imgWait:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:removeMembers()
                obj:loadMembers()
                obj._egObj:unscheduleUpdate()
            else
                obj:egSetWidgetTouchEnabled(kBtnSearch,true)
                obj:egShowWidget(kLblNo)
                obj._imgWait:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:egHideWidget(kImgLongLine)
                obj:egHideWidget(kImgPrompt)
                obj:removeMembers()
                obj._egObj:unscheduleUpdate()
            end
        end   
    end 
    obj:egBindUpdateWithPriorityLua(callback)
end
--�����Ա����
function __searchlayer.membersOrder(obj,members)
    local itemOrder = {}
    obj._guidOrder = {}
    for guid,item in pairs(members) do
        table.insert(itemOrder,item)
    end
    table.sort(itemOrder,function(a,b) return a.elo>b.elo end)
    for _,item in ipairs (itemOrder) do
        for guid,member in pairs (members)do
            if member.name == item.name then
                table.insert(obj._guidOrder,guid)
                break
            end
        end
    end
    obj._maxNum = #obj._guidOrder
    obj._startIdx = 1   
end
--���ع����Ա
function __searchlayer.addGuildMembers(obj,num,kind)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num-1,obj._maxNum)
    for idx = startIdx,obj._maxNum,1 do
        if idx > endIdx then break end
        local guid = obj._guidOrder[idx]
        local memberItem = GuildMemberItem.new(guid,kind,idx)
        obj._listview:pushBackCustomItem(memberItem:egNode())
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __searchlayer.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:addGuildMembers(kMaxNum)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent)
end
function __searchlayer.loadMembers(obj)
   obj:egHideWidget(kImgPrompt) 
   obj:egHideWidget(kLblNo)
   obj:egShowWidget(kImgLongLine)  
   obj:egShowWidget(kListMembers)
   obj:membersOrder(club_search.members)
   obj:addGuildMembers(kMaxNum,1)   
   if obj._maxNum>5 then
       obj:egShowWidget(kImgPrompt)
   end
   local kind = 1
   local guildInfo = GuildInfo.new(kind)
   obj._guildInfo = guildInfo
   obj:egAddChildTo(kPanelGuild,guildInfo:egNode())   
end

function __searchlayer.removeMembers(obj)
    local listView = obj:egGetListView(kListMembers)
    for idx =1,listView:getChildrenCount() do
        item = listView:getItem(idx-1)
        listView:removeChildByTag(item:getTag(),true)
    end
    listView:removeAllItems()
    listView:jumpToTop()
    if obj._guildInfo then
        obj._guildInfo:egRemoveSelf() 
        obj._guildInfo = nil
    end    
end

SearchLayer={}
function SearchLayer.new()
    local obj = {}
    CocosWidget.install(obj,JsonList.searchLayer)
    table_aux.unpackTo(__searchlayer, obj)
    obj:init()
    obj:bindScrollListener()
    obj:bindSearchListener()
    obj:bindTextNameListener()
    obj:bindNameBgListener()
    return obj
end
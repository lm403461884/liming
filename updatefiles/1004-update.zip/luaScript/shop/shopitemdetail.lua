local kBtnOk = "btn_ok"
local kBtnBack = "btn_back"
local kImgItem = "img_item"
local kLblConsume = "lbl_consume"
local kLblUcd = "lbl_ucd"
local kLblFcd = "lbl_fcd"
local kLblName = "lbl_name"
local kLblDetail = "lbl_detail"
local kPanelLayer = "detail_panel"
local kLblW = 430
local kLblH = 220
local __shopitemdetail = {}
function __shopitemdetail.init(obj,s_data)
    local consumeTxt = string.format("%s%d",obj:egGetLabelStr(kLblConsume),s_data.consume)
    local ucdTime = Funs.formatTimeCh(s_data.ucd,true,true,true,true,true)
    local fcdTime = Funs.formatTimeCh(s_data.fcd,true,true,true,true,true)
    local ucdTxt = string.format("%s%s",obj:egGetLabelStr(kLblUcd),ucdTime)
    local fcdTxt = string.format("%s%s",obj:egGetLabelStr(kLblFcd),fcdTime)
    obj:egChangeImg(kImgItem,s_data.icon,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblName,s_data.name)
    obj:egSetLabelStr(kLblConsume,consumeTxt)
    obj:egSetLabelStr(kLblUcd,ucdTxt)
    obj:egSetLabelStr(kLblFcd,fcdTxt)
    local widget = obj:egGetWidgetByName(kLblDetail)
	local lbl =  tolua.cast(widget,"Label")
	lbl:setText(s_data.info)
	local size = lbl:getSize()
	if size.width > kLblW then
        lbl:setTextAreaSize(CCSizeMake(kLblW,kLblH))
	end
end
--�·��رհ���
function __shopitemdetail.bindOkListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
--���Ϸ��رհ���
function __shopitemdetail.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __shopitemdetail.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __shopitemdetail.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
ShopItemDetail={}
function ShopItemDetail.new(s_data,onloaded)
   local obj =  TouchWidget.new(JsonList.shopItemDetail)
    table_aux.unpackTo(__shopitemdetail, obj)
    obj._onloaded = onloaded
    obj:init(s_data)
    obj:bindOkListener()
    obj:bindBackListener()
    return obj
end
function showShopItemDetail(s_data,onloaded)
    local layer = ShopItemDetail.new(s_data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end
local kBtnClose="btn_close"
local kImgMail = "img_mail"
local kImgMask = "img_dark_mask"
local kImgLight = "img_light"
local kAwardList = "award_list"

local kPoint0 = ccp(640,409)
local kPoint1=ccp(-25,-230)
local kStartW = 190
local kJumpH = 300
local kCardW = 150
local kItemW = 142
local kMargin1 = 10
local kMargin2 = 15
local __popmail={}
function __popmail.init(obj,awardinfo,x,y)
  --��ʾ�ŷ���ʾ��
    obj._awardinfo = awardinfo
	obj._loadW = 0
    obj:egHideWidget(kBtnClose)
	obj:egHideWidget(kImgLight)
    obj:egChangeImg(kImgMail,ImageList.mail_closed)
    local mail = obj:egGetWidgetByName(kImgMail)
    mail:setTouchEnabled(false)
    mail:setPosition(ccp(x,y))
    mail:setScale(kStartW/mail:getSize().width)
    obj:showWidthAction()
end
function __popmail.showWidthAction(obj)
     local mail = obj:egGetWidgetByName(kImgMail)
    local scaleto = CCScaleTo:create(0.5,1)
    local jumpto = CCJumpTo:create(0.5,kPoint0,kJumpH,1)
    local spawn = CCSpawn:createWithTwoActions(scaleto,jumpto)
    local function callback()
        mail:setTouchEnabled(true)
        local moveby1 = CCMoveBy:create(1,ccp(0,-20))
        local moveby2 = CCMoveBy:create(1,ccp(0,20))
        local sequence1 = CCSequence:createWithTwoActions(moveby1,moveby2)
        local repeatever = CCRepeatForever:create(sequence1)
        mail:runAction(repeatever)
        if obj._onloaded then obj._onloaded() end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
    mail:runAction(sequence)
    local widget = obj:egGetWidgetByName(kImgMask)
    widget:setOpacity(0)
    widget:runAction(CCFadeTo:create(0.2,180))
end
--��ȡӢ����Ϣ����Դ��������
function __popmail.getAwardDetail(obj)
	local heroAward = {}
	local resAward = {}
	for cointype,val in pairs(obj._awardinfo) do
        if cointype == "heroMsg" then
            for heroid,msgnum in pairs(val) do
                if msgnum > 0 then
                    table.insert(heroAward,heroid)
                    table.insert(heroAward,msgnum)
                end
            end
        else
            if val > 0 then 
                table.insert(resAward,cointype)
                table.insert(resAward,val)
            end
        end
    end
	return heroAward,resAward
end
function __popmail.rotateAndShow(obj,awardItem,margin,callbackfunc)
	local panel = obj:egGetWidgetByName(kAwardList)
	local panelH = panel:getSize().height
	local panelW = panel:getSize().width
	local widget = awardItem:egNode()
	local widgetW = widget:getSize().width
	local widgetH = widget:getSize().height
	widget:setPosition(ccp(obj._loadW ,(panelH - widgetH)/2)) --���������ʾλ��
	awardItem:scaleAndShow(callbackfunc)
	panel:addChild(widget)	
	obj._loadW  = obj._loadW + (widgetW + margin)
end
function __popmail.loadResAward(obj,resList)
	local function loadAwardByIdx(idx)
	    local cnt = idx * 2
        if cnt <=  #resList then
			SoundHelper.playEffect(SoundList.buy_message_01)
            local cointype = resList[cnt-1]
            local num = resList[cnt]
            local resaward = ResAward.new(cointype,num)
            account_data[cointype] = account_data[cointype] + num
            local function callback()
                idx = idx + 1
                loadAwardByIdx(idx)
            end
            obj:rotateAndShow(resaward,kMargin2,callback)
        else
            obj:egShowWidget(kBtnClose)
        end
		
	end
	loadAwardByIdx(1)
end
--���ػ�õ���Դ
function __popmail.loadAwardItems(obj)
    local  heroMsgList,resList = obj:getAwardDetail()
   -- resList={"stoneR",10,"copper",2,"gold",5}
    local cnt1 = #heroMsgList/2
    local cnt2 = #resList/2
	local newW = cnt1*(kCardW + kMargin1) + cnt2*(kItemW +kMargin2 )
	local panel = obj:egGetWidgetByName(kAwardList)
	local size = panel:getSize()
	obj._loadW  = (size.width - newW)/2
	--panel:setSize(CCSizeMake(newW,size.height))
	--panel:setPosition(ccp(newx,panel:getPositionY()))
	local msgchanged = false
	local function loadAwardByIdx(idx)
		
	    local cnt = idx * 2
        if cnt <=  #heroMsgList then
            msgchanged = true
            local heroid = heroMsgList[cnt-1]
            local msgnum = heroMsgList[cnt]
            local heromsg = HeroMsgAward.new(heroid,msgnum)
            local s_cfg = hero_data.getConfig(heroid)
            if not account_data.heroInfoList[heroid] then
                account_data.heroInfoList[heroid] = math.min(msgnum,s_cfg.infoCnt)
                if obj._firstGainCallback then obj._firstGainCallback(heroid) end
            else
                account_data.heroInfoList[heroid] =  math.min(account_data.heroInfoList[heroid] + msgnum,s_cfg.infoCnt)
                if obj._gainHeroMsgCallback then obj._gainHeroMsgCallback(heroid) end
				SoundHelper.playEffect(SoundList.buy_message_01)
			end
            local function callback()
                idx = idx + 1
                loadAwardByIdx(idx)
            end
            obj:rotateAndShow(heromsg,kMargin1,callback)
        else
             if msgchanged and obj._msgChangedCallback then obj._msgChangedCallback() end
             obj:loadResAward(resList)
        end
    end
    loadAwardByIdx(1)
end
function __popmail.onFirstGainHeroMsg(obj,callback)
    obj._firstGainCallback = callback
end
function __popmail.onGainHeroMsg(obj,callback)
    obj._gainHeroMsgCallback = callback
end
function __popmail.onHeroMsgChanged(obj,callback)
    obj._msgChangedCallback = callback
end
function __popmail.showLight(obj)
	local lightbg = obj:egGetWidgetByName(kImgLight)
	lightbg:setVisible(true)
	lightbg:setEnabled(true)
    local rotateby1 = CCRotateBy:create(2,37.2)
    local scaleto1 = CCScaleTo:create(2,0.55)
    local rotateby2 = CCRotateBy:create(2,37.2)
    local scaleto2 = CCScaleTo:create(2,0.45)
    local spawn1 = CCSpawn:createWithTwoActions(rotateby1,scaleto1)
    local spawn2 = CCSpawn:createWithTwoActions(rotateby2,scaleto2)
    local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
    local repeatever = CCRepeatForever:create(sequence)
    lightbg:runAction(repeatever)
end
--�ŷ����¼�
function __popmail.bindMailListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_letter_open)
		
		sender:stopAllActions()
		sender:setScale(0.4)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		local lightbg = obj:egGetWidgetByName(kImgLight)
		local newpoint = ccp(lightbg:getPositionX(),lightbg:getPositionY())
		local jumpto = CCJumpTo:create(0.5,newpoint,100,1)
		local function callback()
			obj:showLight()
			obj:egChangeImg(kImgMail,ImageList.mail_opened)
			obj:loadAwardItems()
		end
		local callfunc = CCCallFunc:create(callback)
		local sequence = CCSequence:createWithTwoActions(jumpto,callfunc)
		sender:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgMail,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __popmail.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_back_button)
        obj._awardinfo = nil
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

PopMail={}
function PopMail.new(awardinfo,x,y,onloaded)
    local obj =  TouchWidget.new(JsonList.popMail)
    table_aux.unpackTo(__popmail, obj)
    obj._onloaded = onloaded
    obj:init(awardinfo,x,y)
    obj:bindMailListener()
    obj:bindCloseListener()
    return obj
end

local kBtnClose="btn_close_charge"
local kBtnCharge="btn_charge"
local kImgBg = "img_charge_bg"
local kLblNeedVal = "lbl_need_jewel_val"
local __popcharge={}
function __popcharge.init(obj,needVal)
	local bg = obj:egGetWidgetByName(kImgBg)
	obj:egSetWidgetTouchEnabled(kBtnCharge,false)
	obj:egSetLabelStr(kLblNeedVal,needVal)
	bg:setScale(0)
	local scaleto = CCScaleTo:create(0.5,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		obj:egSetWidgetTouchEnabled(kBtnCharge,true)
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	bg:runAction(sequence)
end
--��ֵ��ť
function __popcharge.bindChargeListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCharge,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __popcharge.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

PopCharge={}
function PopCharge.new(needVal,onloaded)
    local obj =  TouchWidget.new(JsonList.popCharge)
    table_aux.unpackTo(__popcharge, obj)
    obj._onloaded = onloaded
    obj:init(needVal)
    obj:bindChargeListener()
    obj:bindCloseListener()
    return obj
end

function showPopCharge(needVal,onloaded)
	local layer =  PopCharge.new(needVal,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

local kImgCoin = "img_res"
local kLblVal = "lbl_num"
local kImgBg = "img_res_bg"
local kSx = 640
local kSy = 345
local __resaward = {}
function __resaward.init(obj,name,val)
    local imgsrc = ImageList[string.format("comm_%s",name)]
    obj:egChangeImg(kImgCoin,imgsrc,UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblVal,Funs.signedNum(val))
end
function __resaward.scaleAndShow(obj,callbackfunc)
	obj:scaleAndShowWithSrc(kSx,kSy,callbackfunc)
end
function __resaward.scaleAndShowWithSrc(obj,srcx,srcy,callbackfunc)
	local widget = obj:egGetWidgetByName(kImgBg)
	local x = obj:egNode():getPositionX()
	local oldx = widget:getPositionX()
	local oldy = widget:getPositionY()
	local sx = srcx - x
	widget:setPosition(ccp(sx,srcy))
	local scaleto = CCScaleTo:create(0.2,1.5)
	local moveto = CCMoveTo:create(0.2,ccp(oldx,oldy))
	local array = CCArray:create()
	array:addObject(scaleto)
	array:addObject(moveto)
	local spawn = CCSpawn:create(array)
	local function callback()
	    callbackfunc()
	end
	local callfunc = CCCallFunc:create(callback)
	local scaleto1 = CCScaleTo:create(0.1,1)
	--local bouceout = CCEaseBounceOut:create(scaleto1)
	local delay = CCDelayTime:create(0.3)
	local array1 = CCArray:create()
	array1:addObject(spawn)
	array1:addObject(scaleto1)
	array1:addObject(delay)
	array1:addObject(callfunc)
	local sequence = CCSequence:create(array1)
	widget:runAction(sequence)
end
ResAward={}
function ResAward.new(name,val)
    local obj = {}
    CocosWidget.install(obj,JsonList.resAward)
    table_aux.unpackTo(__resaward, obj)
    obj:init(name,val)
    return obj
end

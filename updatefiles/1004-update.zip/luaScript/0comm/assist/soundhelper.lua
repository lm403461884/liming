SoundHelper = {}
local BGM = nil
local kBGM_STATE_KEY = "S_BGM_STATE_OFF"
local kEFFECT_STATE_KEY = "S_EFFECT_STATE_OFF"
function SoundHelper.setBGMState(val)
	SoundHelper._BGM_off = val
	DBHelper.setCfgWithKey(kBGM_STATE_KEY,val)
end
function SoundHelper.setEffectState(val)
	SoundHelper._Effect_off = val
	DBHelper.setCfgWithKey(kEFFECT_STATE_KEY,val)
end
function SoundHelper.getBGMState()
	if  SoundHelper._BGM_off == nil then
		SoundHelper._BGM_off = DBHelper.getCfgWithKey(kBGM_STATE_KEY)
	end
	return  SoundHelper._BGM_off
end
function SoundHelper.getEffectState()
	if  SoundHelper._Effect_off == nil then
		SoundHelper._Effect_off = DBHelper.getCfgWithKey(kEFFECT_STATE_KEY)
	end
	return  SoundHelper._Effect_off
end
function SoundHelper.playBGM(filename)
	local m_BGM_off = SoundHelper.getBGMState()
	if (not m_BGM_off) and  BGM ~= filename then
		BGM = filename
		AudioEngine.stopMusic(true)
		AudioEngine.playMusic(BGM, true)
		--print("BGM switch to "..filename)
	end
end
function SoundHelper.playBGMOnce(filename)
	local m_BGM_off = SoundHelper.getBGMState()
    if (not m_BGM_off) and  BGM ~= filename then
        BGM = filename
        AudioEngine.playMusic(BGM, false)
        --print("BGM switch to "..filename)
    end
end
function SoundHelper.stopBGM()
	BGM = nil
	AudioEngine.stopMusic(true)
end
function SoundHelper.playEffect(filename)
	local m_Effect_off = SoundHelper.getEffectState()
	if not m_Effect_off then
		if not SoundHelper._preloadEffects then SoundHelper._preloadEffects = {} end
		if not SoundHelper._effects then SoundHelper._effects = {} end
		AudioEngine.playEffect(filename, false)

		if not SoundHelper._preloadEffects[filename] then SoundHelper._effects[filename] = os.time() end
		for key,val in pairs(SoundHelper._effects) do
			if os.time()-val >= 10 then
				AudioEngine.unloadEffect(key)
				SoundHelper._effects[key] = nil
			end
		end
	end
end
function SoundHelper.preLoadEffect(filename)
	if not SoundHelper._preloadEffects then SoundHelper._preloadEffects = {} end
	SoundHelper._preloadEffects[filename] = 1
    AudioEngine.preloadEffect(filename)
end
function SoundHelper.unloadEffect(filename)
	if not SoundHelper._preloadEffects then SoundHelper._preloadEffects = {} end
	SoundHelper._preloadEffects[filename] = nil
	AudioEngine.unloadEffect(filename)
end
--是否开启背景音乐
function SoundHelper.isBGMOn()
	local m_BGM_off = SoundHelper.getBGMState()
	return not m_BGM_off
end
--是否开启音效
function SoundHelper.isEffectOn()
	local m_Effect_off = SoundHelper.getEffectState()
	return not m_Effect_off
end
--打开背景音乐
function SoundHelper.turnOnBGM(filename,playOnce)
	if filename then
		BGM = filename
		if not playOnce then 
			AudioEngine.playMusic(BGM, true)
		else
			AudioEngine.playMusic(BGM, false)
		end
	end
	 SoundHelper.setBGMState(false)
end
--关闭背景音乐
function SoundHelper.turnOffBGM()
	BGM = nil
	AudioEngine.stopMusic()
	SoundHelper.setBGMState(true)
end
--开关背景音效
function SoundHelper.turnOffEffect(turnoff)
	if not turnoff then 
		turnoff = false 
	end
	SoundHelper.setEffectState(turnoff)
end
PushMsgCode={}
PushMsgCode.pvpAtk = 1
PushMsgCode.clubWar = 2

local m_PushMsgStateKey = 
{
	[1] = "S_PVP_ATTACKEN_NOTIFY_OFF",
	[2] ="S_CLUB_WAR_NOTIFY_OFF",
}
local m_PushMsgStateVal = {}

PushMsgHelper={}
--获取配置
function PushMsgHelper.getPushStataByTag(tag)
	if m_PushMsgStateVal[tag] == nil then
		m_PushMsgStateVal[tag] = DBHelper.getCfgWithKey(m_PushMsgStateKey[tag])
	end
	return m_PushMsgStateVal[tag]
end
--修改配置
function PushMsgHelper.setPushStataByTag(tag,val)
	m_PushMsgStateVal[tag] = val
	DBHelper.setCfgWithKey(m_PushMsgStateKey[tag],val)
end
--关闭指定类型的消息推送
function PushMsgHelper.turnOff(tag)
	PushMsgHelper.setPushStataByTag(tag,true)
end
--开启指定类型的消息推送
function PushMsgHelper.turnOn(tag)
	PushMsgHelper.setPushStataByTag(tag,false)
end
--消息推送状态
function PushMsgHelper.isTurnOn(tag)
	local stateoff = PushMsgHelper.getPushStataByTag(tag)
	return not stateoff
end
local function bool2int(val)
	if val then return 1 else return 0 end
end
function PushMsgHelper.isAllTurnOff()
	for tag,_ in pairs(m_PushMsgStateKey) do
		local stateoff = PushMsgHelper.getPushStataByTag(tag)
		if stateoff == false then return false end
	end
	return true
end
function PushMsgHelper.start()
	if (not PushMsgHelper.isAllTurnOff()) and AcctManager:get() then
		local paramTb = {}
		paramTb.timeInv = 30*1000
		paramTb.host = DSConfig.host
		paramTb.port =  DSConfig.port1
		paramTb.keys = {AcctManager:getParam("guid"), AcctManager:getParam("cid") or 0}
		paramTb.infos = {TxtList.remoteNotifyMsg[1],TxtList.remoteNotifyMsg[2]}
		paramTb.states = {bool2int(PushMsgHelper.getPushStataByTag(1)),bool2int(PushMsgHelper.getPushStataByTag(2))}
		ServerNotification:start( json.encode(paramTb))
	end
end
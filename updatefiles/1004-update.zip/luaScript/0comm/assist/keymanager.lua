KeyManager={}
--������Կ
function KeyManager.init()
	ZipUtils:setPvrKey(1846848570,673251273,3914159395,270548114)
	--6E14AC3A,2820FFC9,E94D5523,10203C92
end

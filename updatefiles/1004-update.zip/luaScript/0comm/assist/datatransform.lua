

--!@module:	dataTranform
--!@brief:	将紧缩格式字段解析为完全展开形式
--!@remark: 转换的结果保存在输入表 无返回值

	dataTranform = {}

function dataTranform.unlockedPVE(unlockedPVE)
	for aid, area in pairs(unlockedPVE) do
		for sid, v in pairs(area) do
			if type(sid) == 'number' then
				local stars = v % 256
				local nextUnlocked = math.floor(v / 256) % 256
				local first = math.floor(v / 65536)
				area[sid] = {stars=stars, nextUnlocked=nextUnlocked, first=first}
				if nextUnlocked == 0 then area[sid].nextUnlocked = nil end
				if first == 0 then area[sid].first = nil end
			end
		end
	end
end
function dataTranform.pveGuardQuest(pveGuardList)
	if not pveGuardList then return end
	for key,val in pairs(pveGuardList) do
		local stars = val % 256
		local nextUnlocked = math.floor(val / 256) % 256
		local first = math.floor(val / 65536)
		if nextUnlocked == 0 then nextUnlocked = nil end
		if first == 0 then first = nil end
		pveGuardList[key] = {stars=stars, nextUnlocked=nextUnlocked, first=first}
	end
end
function dataTranform.equipments(acct)
	acct.equipments = {}
	for _,hero in pairs(acct.heroList) do
		acct.equipments[hero.eid] = {hero.equ%256, math.floor(hero.equ/256)}
	end
end

function dataTranform.mileSpread(mileSpread, mileInCD)

	for pos, packet in pairs(mileSpread) do

		local cnt = math.floor(packet / 10000)
		local type = math.floor(packet / 100) % 100
		local lv = packet % 100
		mileSpread[pos] = {type=type, lv=lv, dt=0, cnt=cnt}

		if mileInCD then
			mileSpread[pos].dt =  mileInCD[pos] or 0
		end
	end

end

function dataTranform.rewardMails(mails)
	if mails then
		for k,v in pairs(mails) do
			local id = v%65536
			local val = math.floor(v/65536)
			mails[k] = {id=id, val=val}
		end
	end
end

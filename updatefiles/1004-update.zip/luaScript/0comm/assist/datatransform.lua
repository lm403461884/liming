

--!@module:	dataTranform
--!@brief:	将紧缩格式字段解析为完全展开形式
--!@remark: 转换的结果保存在输入表 无返回值

	dataTranform = {}

function dataTranform.unlockedPVE(unlockedPVE)
	for aid, area in pairs(unlockedPVE) do 
		for sid, v in pairs(area) do
			if type(sid) == 'number' then
				local stars = v % 256
				local nextUnlocked = math.floor(v / 256) % 256
				local first = math.floor(v / 65536)
				local stage = {stars=stars, nextUnlocked=nextUnlocked, first=first}
				if nextUnlocked == 0 then stage.nextUnlocked = nil end
				if first == 0 then stage.first = nil end
				area[sid] = stage
			end
		end
	end
end

function dataTranform.equipments(equipments)
	for eid, equip in pairs(equipments) do
		local elv = equip % 256
		local eqa = math.floor(equip / 256)
		equipments[eid] = {elv, eqa}
	end
end

function dataTranform.mileSpread(mileSpread, mileInCD)

	for pos, packet in pairs(mileSpread) do

		local cnt = math.floor(packet / 10000)
		local type = math.floor(packet / 100) % 100
		local lv = packet % 100
		local mile = {type=type, lv=lv, dt=0, cnt=cnt}
		mileSpread[pos] = mile
		
		if mileInCD then
			mile.dt =  mileInCD[pos] or 0	
		end
	end
	
end

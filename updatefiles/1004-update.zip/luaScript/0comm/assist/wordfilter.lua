local maxLen = 17
WorldFilter = {}
--替换字符串的敏感字段
--str 需要替换的字符串
--ignoreP 是否忽略标点 true 忽略
function WorldFilter.replaceWords(str,ignoreP)
	if ignoreP then 
		return WorldFilter.replaceWords0(str,FilterWordDB)
	else
		return WorldFilter.replaceWords1(str,FilterWordDB)
	end
end
--判断是否存在需要被过滤的词组
function WorldFilter.needFilter1(str,wordDB)
	local wordtb = WorldFilter.splitStrToTable1(str)
	local wordLen = #wordtb
	local limtLen = math.min(wordLen,maxLen)
	local actLen = 0
	local concatVal = nil
	for key,val in ipairs(wordtb) do
		actLen = math.min(limtLen,wordLen - key + 1)
		for idx=1,actLen do
			concatVal = table.concat(wordtb,nil,key,key+idx-1)
			if wordDB[concatVal] then return true end
		end
	end
	return false
end
--替换字符串中被过滤掉的词组
function WorldFilter.replaceWords1(str,wordDB)
	local wordtb = WorldFilter.splitStrToTable1(str)
	local wordLen = #wordtb
	local limtLen = math.min(wordLen,maxLen)
	local actLen = 0
	local concatVal = nil
	local repLen = nil
	for key = 1,wordLen do
		repLen = 0
		actLen = math.min(limtLen,wordLen - key + 1)
		for idx=1,actLen do
			concatVal = table.concat(wordtb,nil,key,key+idx-1)
			if wordDB[concatVal] then
				repLen = idx
			end
		end
		for idx = 1,repLen do
			wordtb[key+idx - 1] = "*"
		end
		key =  key + repLen
	end
	return table.concat(wordtb)
end
--过滤字符串，并返回被过滤的词组
function WorldFilter.filterWorlds1(str,wordDB)
	local wordtb = WorldFilter.splitStrToTable1(str)
	local wordLen = #wordtb
	
	local limtLen = math.min(wordLen,maxLen)
	local actLen = 0
	local concatVal = nil
	local filtertb = {}
	for key,val in ipairs(wordtb) do
		actLen = math.min(limtLen,wordLen - key + 1)
		for idx=1,actLen do
			concatVal = table.concat(wordtb,nil,key,key+idx-1)
			if wordDB[concatVal] then
				table.insert(filtertb,concatVal)
			end
		end
	end
	return filtertb
end
--将原句子拆分成单个词组
function WorldFilter.splitStrToTable1(str)
	local lenInByte = #str
	local wordTb = {}
	for i=1,lenInByte do
		local curByte = string.byte(str, i)
		local byteCount = 0;
		if curByte>0 and curByte<=127 then
			byteCount = 1
		elseif curByte>=192 and curByte<223 then
			byteCount = 2
		elseif curByte>=224 and curByte<239 then
			byteCount = 3
		elseif curByte>=240 and curByte<=247 then
			byteCount = 4
		end
		if byteCount > 0 then
			local val = string.sub(str, i, i+byteCount-1)
			table.insert(wordTb,val)
			i = i + byteCount -1
		end
	end
	return wordTb
end
----------------------------------------------------
---加强版本,忽略标点
----------------------------------------------------
--判断是否存在需要被过滤的词组
function WorldFilter.needFilter0(str,wordDB)
	local wordtb,_,_ = WorldFilter.splitStrToTable0(str)
	local wordLen = #wordtb
	local limtLen = math.min(wordLen,maxLen)
	local actLen = 0
	local concatVal = nil
	for key,val in ipairs(wordtb) do
		actLen = math.min(limtLen,wordLen - key + 1)
		for idx=1,actLen do
			concatVal = table.concat(wordtb,nil,key,key+idx-1)
			if wordDB[concatVal] then return true end
		end
	end
	return false
end
--替换字符串中被过滤掉的词组
function WorldFilter.replaceWords0(str,wordDB)
	local wordtb,ignorewords,ignoreidxs = WorldFilter.splitStrToTable0(str)
	local wordLen = #wordtb
	local limtLen = math.min(wordLen,maxLen)
	local actLen = 0
	local concatVal = nil
	local repLen = nil
	for key = 1,wordLen do
		repLen = 0
		actLen = math.min(limtLen,wordLen - key + 1)
		for idx=1,actLen do
			concatVal = table.concat(wordtb,nil,key,key+idx-1)
			if wordDB[concatVal] then
				repLen = idx
			end
		end
		for idx = 1,repLen do
			wordtb[key+idx - 1] = "*"
		end
		key =  key + repLen
	end
	for key,val in ipairs(ignoreidxs) do
		table.insert(wordtb,val,ignorewords[key])
	end
	return table.concat(wordtb)
end
--过滤字符串，并返回被过滤的词组
function WorldFilter.filterWorlds0(str,wordDB)
	local wordtb,_ = WorldFilter.splitStrToTable0(str)
	local wordLen = #wordtb
	
	local limtLen = math.min(wordLen,maxLen)
	local actLen = 0
	local concatVal = nil
	local filtertb = {}
	for key,val in ipairs(wordtb) do
		actLen = math.min(limtLen,wordLen - key + 1)
		for idx=1,actLen do
			concatVal = table.concat(wordtb,nil,key,key+idx-1)
			if wordDB[concatVal] then
				table.insert(filtertb,concatVal)
			end
		end
	end
	return filtertb
end
--拆分句子为单个词组，忽略标点和空格
function WorldFilter.splitStrToTable0(str)
	local lenInByte = #str
	local wordTb = {}
	local ignoreWords = {}
	local ignoreIdxs = {}
	local ignoreVal = nil
	local validVal = nil
	local idx = 0
	for i=1,lenInByte do
		local curByte = string.byte(str, i)
		local byteCount = 0;
		if curByte>0 and curByte<=127 then
			byteCount = 1
		elseif curByte>=192 and curByte<223 then
			byteCount = 2
		elseif curByte>=224 and curByte<239 then
			byteCount = 3
		elseif curByte>=240 and curByte<=247 then
			byteCount = 4
		end
		if byteCount > 0 then
			idx = idx + 1
			ignoreVal = string.sub(str, i, i+byteCount-1)
			validVal =  string.gsub(ignoreVal,"[%p,%s]","")
			if validVal~="" then
				table.insert(wordTb,validVal)
			else
				table.insert(ignoreIdxs,idx)
				table.insert(ignoreWords,ignoreVal)
			end
			i = i + byteCount -1
		end
	end
	return wordTb,ignoreWords,ignoreIdxs
end

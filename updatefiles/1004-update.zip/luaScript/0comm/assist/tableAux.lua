--! @module table aux

table_aux = {}

local format = string.format

-- forward declaration for table serial
local __serialTable

__serialTable = function(t)
    local ret = ""
    for k, v in pairs(t) do
        local tk, tv = type(k), type(v)
        if tk == "number" and tv == "number" then
            ret = format('%s[%d]=%d,', ret, k, v)
        elseif tk == "number" and tv == "string" then
            ret = format("%s[%d]='%s',", ret, k, v)
        elseif tk == "string" and tv == "number" then
            if tonumber(k) then ret = format("%s['%s']=%d,", ret, k, v)
            else ret = format("%s%s=%d,", ret, k, v) end
        elseif tk == "string" and tv == "string" then
            if tonumber(k) then ret = format("%s['%s']='%s',", ret, k, v)
            else ret = format("%s%s='%s',", ret, k, v) end
        elseif tk == "number" and tv == "table" then
            ret = format("%s[%d]=%s,", ret, k, __serialTable(v))
        elseif tk == "string" and tv == "table" then
            if tonumber(k) then    ret = format("%s['%s']=%s,", ret, k, __serialTable(v))
            else ret = format("%s%s=%s,", ret, k, __serialTable(v)) end
        end
    end
    return format("{%s}", ret)
end

function table_aux.serial(t, isCallable)
    if isCallable then
        return format("do return %s end", __serialTable(t))
    else
        return __serialTable(t)
    end
end

function table_aux.unpackTo(t_src, t_dst)
    for k, v in pairs(t_src) do
        t_dst[k] = v
    end
end

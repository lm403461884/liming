local __tablelayout={}
function __tablelayout.setOuterBorder(obj,x,y)
    obj._outerborderX = x
    obj._outerborderY =y
end

function __tablelayout.setInnerBorder(obj,x,y)
    obj._innerborderX = x
    obj._innerborderY = y
end

function __tablelayout.getPosByIdx(obj,idx,anchor)
    local width = obj._cellW + obj._innerborderX
    local height = obj._cellH + obj._innerborderY 
	local x = 0
	local y = 0
	x = (idx - 1)% obj._cols
	y,_ =math.modf((idx-1)/obj._cols)
	y = obj._rows - y -1
	local px = x * width  + obj._outerborderX + width* anchor.x
	local py = y * height + obj._outerborderY + height* anchor.y
	return px,py
end

function __tablelayout.getMinMatrix(obj)
    local cellwidth = obj._cellW + obj._innerborderX
    local cellheight = obj._cellH + obj._innerborderY
    local viewwidth = obj._viewW  - obj._outerborderX*2 + obj._innerborderX
    local viewheight = obj._viewH  - obj._outerborderY*2 + obj._innerborderY
    
    local col,_ = math.modf(viewwidth/cellwidth)
    local row,_ = math.modf(viewheight/cellheight)
    
    if viewwidth % cellwidth > 0 and  obj._isHorizontal then col = col  + 1 end
    if viewheight * cellheight > 0 and not obj._isHorizontal then row = row + 1 end
    return row,col
end

function __tablelayout.getMatrix(obj,count)
    local minrow,mincol = obj:getMinMatrix()
    local rows  = minrow
    local cols = mincol
     if count <= 0 then return  minrow,mincol end 
     if obj._isHorizontal then
         cols,_ = math.modf(count/minrow)
        if count%minrow > 0 then cols = cols + 1 end
        if cols < mincol then cols =  mincol end
     else
        rows,_ = math.modf(count/mincol)
        if count%mincol > 0 then rows = rows + 1 end
        if rows < minrow then rows =  minrow end
    end
    return rows,cols
end

function __tablelayout.setHorizontal(obj,horizontal)
     obj._isHorizontal= horizontal
end
function __tablelayout.layOutData(obj,owner,data)
    local count = #data
    if count == 0 then return end
    local rows,cols = obj:getMatrix(count)
    obj._cols = cols
    obj._rows = rows
    local width = cols * (obj._cellW + obj._innerborderX) -obj._innerborderX + 2*obj._outerborderX
    local height = rows *(obj._cellH + obj._innerborderY ) - obj._innerborderY + 2*obj._outerborderY
    
    if width < obj._viewW then width = obj._viewW end
    if height < obj._viewH then height = obj._viewH end
   local scrollview = tolua.cast(owner,"ScrollView")
   scrollview:setInnerContainerSize(CCSizeMake(width,height))
    for idx,item in pairs(data) do
        local px,py = obj:getPosByIdx(idx,item:getAnchorPoint())
        item:setPosition(ccp(px,py))
    end
end
TableLayout={}
function TableLayout.new(w,h,cellw,cellh)
    local obj = {}
    table_aux.unpackTo(__tablelayout, obj)
    obj._cellW = cellw
    obj._cellH = cellh
    obj._viewW =  w
    obj._viewH = h
    obj._innerborderX = 0
    obj._innerborderY = 0
    obj._outerborderX = 0
    obj._outerborderY = 0
    obj._isHorizontal= false
    return obj
end

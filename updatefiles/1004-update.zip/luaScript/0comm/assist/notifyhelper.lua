
NotifyCode={}
NotifyCode.actPtFull = 1
NotifyCode.teamReturn = 2

local m_NotifyStateKey = 
{
	[1] = "S_ACTPT_NOTIFY_OFF",
	[2] ="S_TEAMRETURN_NOTIFY_OFF",
}
local m_NotifyStateVal = {}
--添加体力值满消息推送
local _innerNotifySender={}
--行动力
_innerNotifySender[1] = function(acct)
	local stateoff =  NotifyHelper.getNotifyStataByTag(1)
	if stateoff then return end
	baseCalc.resetActPt(acct,os.time()-1)
	if acct.actPt < acct.maxActPt then
		local totalSec = math.ceil((acct.maxActPt - acct.actPt)/numDef.valAP)*numDef.durAP
		LocalNotification:show(TxtList.localNotifyMsg[1],totalSec,1)
	end
end
--自己探险队回归
_innerNotifySender[2]=function(acct)
	local stateoff =  NotifyHelper.getNotifyStataByTag(2)
	if stateoff then return end
	 for heroid,item in pairs(acct.cbTeam) do
		if item.tid == acct.guid then
			local totalSec = item.ed - os.time()
			if totalSec > 0 then LocalNotification:show(TxtList.localNotifyMsg[2],totalSec,2) end
			return
		end
	 end
end
NotifyHelper={}
--获取配置
function NotifyHelper.getNotifyStataByTag(tag)
	if m_NotifyStateVal[tag] == nil then
		m_NotifyStateVal[tag] = DBHelper.getCfgWithKey(m_NotifyStateKey[tag])
	end
	return m_NotifyStateVal[tag]
end
--修改配置
function NotifyHelper.setNotifyStataByTag(tag,val)
	m_NotifyStateVal[tag] = val
	DBHelper.setCfgWithKey(m_NotifyStateKey[tag],val)
end
--关闭指定类型的消息推送
function NotifyHelper.turnOff(tag)
	NotifyHelper.setNotifyStataByTag(tag,true)
end
--开启指定类型的消息推送
function NotifyHelper.turnOn(tag)
	NotifyHelper.setNotifyStataByTag(tag,false)
end
--消息推送状态
function NotifyHelper.isTurnOn(tag)
	local stateoff = NotifyHelper.getNotifyStataByTag(tag)
	return not stateoff
end

function NotifyHelper.start()
	if AcctManager:get() then
		for key,tag in pairs(NotifyCode) do
			_innerNotifySender[tag](AcctManager:get())
		end
	end
	PushMsgHelper.start()
end
function NotifyHelper.stop()
	for key,tag in pairs(NotifyCode) do
		LocalNotification:cancel(tag)
	end
	ServerNotification:stop()
end
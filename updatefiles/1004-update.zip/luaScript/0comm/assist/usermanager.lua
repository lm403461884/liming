
UserManager = {}
--��ȡ��ǰ�鿴���û���Ϣ���
function UserManager:getUserBrief(userguid)
	if userguid == AcctManager:getParam("guid") then
		local tb = {}
		tb.diglv = AcctManager:getParam("digLv")
		tb.elo = AcctManager:getParam("elo")
		tb.nickName = AcctManager:getParam("nickName")
		tb.digPt = AcctManager:getParam("maxDigPt")
		tb.cid = AcctManager:getParam("cid") or 0
		tb.cbName = AcctManager:getParam("cbName") or ""
		tb.heroList={}
		tb.equipments ={}
		local team = AcctManager:getParam("team")
		for key,heroid in ipairs(team) do
			local heroprop = AcctManager:getHashParam("heroList",heroid)
			tb.heroList[heroid] = heroprop
			tb.equipments[heroprop.eid] = AcctManager:getHashParam("equipments",heroprop.eid)
		end
		return tb
	else
		if not self._userlist then self._userlist = {} end
		if self._userlist[userguid] and os.time() -  self._userlist[userguid].refreshTime < 2 then
			return self._userlist[userguid]
		else
			return nil
		end
	end
end
--�޸ĵ�ǰ�鿴���û���Ϣ
function UserManager:addUserBrief(userbrief)
	if not self._userlist then self._userlist = {} end
	self._userlist[userbrief.guid] = userbrief	
end

local kTrainPrompt = 2
local kLicencePrompt = 3
local kChemyPrompt = 4
local kGvgPrompt = 5

local __acctManager = {}
function __acctManager.initAcctTime(acct)
	acct.scOffsetTime = os.time() - acct.onlinedt
	
	--������ļˢ��ʱ��
	acct.freeMsgExpire = (acct.freeMsgExpire or (os.time()-acct.scOffsetTime)) + acct.scOffsetTime
	acct.freeBoxExpire = (acct.freeBoxExpire or (os.time()-acct.scOffsetTime)) + acct.scOffsetTime
	--����PVP����ʱ��
	acct.shellPvp = acct.shellPvp + acct.scOffsetTime
	--����ִ������ʱ��
	if acct.diggingLvContext > 0 then acct.diggingLvContext = acct.diggingLvContext + acct.scOffsetTime end
	--�������¿�ʱ��
	if acct.openHoleContext > 0 then acct.openHoleContext = acct.openHoleContext + acct.scOffsetTime end
	--������������ʱ��
	for idx,item in pairs(acct.train) do
		if not item.exp then item.exp = -1 end
		if item.exp > 0 then item.exp = item.exp + acct.scOffsetTime end
    end
    --����ǩ��ʱ��
    if acct.signInExp_d then  acct.signInExp_d = acct.signInExp_d + acct.scOffsetTime end
    if acct.signInExp_m then acct.signInExp_m = acct.signInExp_m + acct.scOffsetTime end
	
		--�����ھ���־�������ʱ��
	if acct.taskRt >= 0 then 
		acct.taskRt = acct.taskRt  + acct.scOffsetTime 
	else
		acct.taskRt = Funs.getTimeWithHMS(numDef.dayTaskRefreshUTH,numDef.dayTaskRefreshUTM,0,acct.scOffsetTime)
	end
	--������һ��Զ������ʼʱ��
	if  acct.exMission then
		acct.exMission.nextSt = acct.exMission.nextSt + acct.scOffsetTime
	end
	
end
--ˢ�´������ʱ��
function __acctManager.initAcctCnt(acct)
	--����ˢ��ʱ��
	if acct.revengeNextSt and acct.revengeNextSt >= 0 then
		acct.revengeNextSt = acct.revengeNextSt + acct.scOffsetTime
	else
		acct.revengeNextSt = Funs.getTimeWithHMS(numDef.revengeRefreshUTH,numDef.revengeRefreshUTM,0,acct.scOffsetTime)
	end
	--��ҹ������
	if not acct.goldBoughtCnt then acct.goldBoughtCnt = 0 end
	if acct.goldNextSt and acct.goldNextSt >= 0 then 
		acct.goldNextSt = acct.goldNextSt  + acct.scOffsetTime 
	else
		acct.goldNextSt = Funs.getTimeWithHMS(numDef.goldRefreshUTH,numDef.goldRefreshUTM,0,acct.scOffsetTime)
	end
	--PVE����ʹ�ô���
	if not acct.pveUsedCnt then acct.pveUsedCnt = 0 end
	if acct.pveNextSt and acct.pveNextSt >= 0 then 
		acct.pveNextSt = acct.pveNextSt  + acct.scOffsetTime 
	else
		acct.pveNextSt = Funs.getTimeWithHMS(numDef.pveRefreshUTH,numDef.pveRefreshUTM,0,acct.scOffsetTime)
	end
	--����ʹ�ô���
	if not acct.chatUsedCnt then acct.chatUsedCnt = 0 end
	if acct.chatNextSt and acct.chatNextSt >= 0 then 
		acct.chatNextSt = acct.chatNextSt  + acct.scOffsetTime 
	else
		acct.chatNextSt = Funs.getTimeWithHMS(numDef.chatRefreshUTH,numDef.chatRefreshUTM,0,acct.scOffsetTime)
	end
end
-----------------------
--�����ж����ظ�ʱ��,�������ˢ��ʱ�䣬ʹ֮��ͻ���ʱ��һ��
-----------------------
function __acctManager.initAcctAp(acct)
    acct.rcAP = acct.rcAP + acct.scOffsetTime
	--�ж����ظ�ʱ��,�ÿͻ���ʼ�ձȷ�������һ������
	if not acct.apBoughtCnt then acct.apBoughtCnt = 0 end
	if not acct.actPtSt then
		acct.actPtSt = os.time()
		acct.actPtNextSt = Funs.getTimeWithHMS(numDef.actPtUTH,numDef.actPtUTM,0,acct.scOffsetTime)
	else
		acct.actPtSt = acct.actPtSt + acct.scOffsetTime
		acct.actPtNextSt = acct.actPtNextSt + acct.scOffsetTime
	end
end
------------------------
--�����󳵲ɼ�ʱ��(������ȴʱ��)
-------------------------
function __acctManager.initAcctResCar(acct)
    for key,item in ipairs(acct.collectorList) do
		item.st = item.st + acct.scOffsetTime
		local targetMine = acct.mileSpread[item.pos]
		if targetMine then
			
			targetMine.dt = math.max(targetMine.dt - (os.time()- item.st),0)
			targetMine.st = os.time()
			--��ȴʱ�� ��  ԭ������ȴʱ�� �� (��ǰʱ������Ͽ�ʱ���ʱ���)
        end
    end
end
-----------------------------------------
--����̽�ն�����
------------------------------------------
function __acctManager.initCbTeam(acct)
	local heroList = {}
	local heroInfo ={}
    for heroid,item in pairs(acct.cbTeam) do
		--����̽�նӻع�ʱ��
		if not item.ed then item.ed = 0 end
	    item.ed = item.ed + acct.scOffsetTime
		--=========================================
        if item.reward then
			table.insert(heroInfo,heroid)
			heroList[heroid]={}
			heroList[heroid].fexp = item.reward.fexp
			heroList[heroid].gold = item.reward.fgold
			heroList[heroid].boxid = item.reward.boxid
			heroList[heroid].wins =  item.reward.wins
			heroList[heroid].newExp,heroList[heroid].newLv,heroList[heroid].expChange =RiskHelper.getHeroExpAndLv( item.reward.fexp,acct.digLv,acct.heroList[heroid])
			if item.reward.boxid > 0 then
				heroList[heroid].awardRes =  baseCalc.treasureBox(acct,item.reward.boxid,nil,nil)
			end --�б���
		    acct.cbTeam[heroid]=nil
        end
    end
	local idx = 0
	while idx < table.getn(heroInfo) do
		local tb = {type=6,data={team={},heroList=heroList}}
		local startIdx = idx + 1
		local endIdx = math.min(table.getn(heroInfo),idx+5)
		for i = startIdx,endIdx do
			table.insert(tb.data.team,heroInfo[i])
		end
		idx = idx + 5
		AccountHelper:addNewPrompt(tb)
	end
	if table.getn(heroInfo) > 0 then
	    SendMsg[9313007](heroInfo,heroList)
	end
end

--��ȡ��������ֵ
function __acctManager.countTrainProps(trainid,acct)
    if not train.props[trainid] then return {} end
    local tb = {}
    for key,_ in pairs(train.props[trainid]) do
        tb[key] = acct[key]
    end
    return tb
end
function __acctManager.countTrainPropChanges(oldtb,newtb)
    local tb = {}
    for key,val in pairs(oldtb) do
        tb[key] = {val,newtb[key]}
    end
    return tb
end
----------------------------------
--��������
--acct.train = {[1] = {lv,exp}
--����ID={��ǰ�ȼ���������Ϣ��{Ŀ��ȼ���ʣ��ʱ��,��ʼʱ��}}
----------------------------------
function __acctManager.updateTrainLvUp(acct)
    for idx,item in pairs (acct.train) do
        if item.exp > 0 and item.exp <= os.time() then
            local oldtb = __acctManager.countTrainProps(idx,acct) --��ȡ����ǰ����
			local tlv = item.lv + 1
            acct.train[idx].lv = tlv
            SendMsg[937003](idx,tlv)
			--�ھ���־������̸���,������
			task.updateTaskStatus(acct,task.client_event_id.update_train,{idx,tlv})
			----------------------------------------------------------
            train.levelup(acct,idx, tlv)
            acct.train[idx].exp = -1
            postEventSignal(kEventTrainUpEnd..idx)
            local newtb = __acctManager.countTrainProps(idx,acct) --��ȡ����������
            --��Ϣ��ʾ---------------
            local tb = {}
            tb.type = kTrainPrompt
            tb.data={}
            tb.data.trainid = idx
            tb.data.from = tlv - 1
            tb.data.to = tlv
            tb.data.changes =  __acctManager.countTrainPropChanges(oldtb,newtb)
            AccountHelper:addNewPrompt(tb)
            -----------------------------
        end
    end
end
--------------------------
--ִ������ diggingLvContext��{st ��ʼʱ��,left ʣ��ʱ��}
--------------------------
function __acctManager.UpdateLicenceLvUp(acct)
    if acct.diggingLvContext and acct.diggingLvContext> 0 and acct.diggingLvContext<= os.time() then --����-1ʱ��ʾû������
        local lv = acct.digLv
        local tlv = lv + 1
        acct.digLv = tlv
        SendMsg[932005](lv,tlv)
		TDHelper.setLevel(acct.digLv)
			--�ھ���־������̸���,���ִ������
		task.updateTaskStatus(acct,task.client_event_id.diglv_update,{tlv})
			----------------------------------------------------------
        licenceLevelup.onLvUp(acct)
        acct.diggingLvContext = -1
        postEventSignal(kEventLicenceUpEnd)
        postEventSignal(kEventNoticeMission)
        --��Ϣ��ʾ-----------------------
        local tb = {}
        tb.type = kLicencePrompt
        tb.data = {from = lv,to = tlv}
        AccountHelper:addNewPrompt(tb)
        --------------------------
   end
end
--------------------------
--ˢ�¿�����ȴʱ��
--------------------------
function __acctManager.updateResCar(acct)
	for key,item in ipairs(acct.collectorList) do
		local targetMine = acct.mileSpread[item.pos]
		if targetMine and targetMine.dt>0 then
			local passed = os.time() - targetMine.st
			if passed > 0 then
				targetMine.dt = targetMine.dt - passed
				targetMine.st = os.time() --������Ե�ǰʱ��ˢ��ST
			end
        end
    end
end
--------------------------
--�ھ���־�������
--------------------------
function __acctManager.updateTaskList(acct)
	if os.time() >= acct.taskRt then
		acct.taskRt =  Funs.getTimeWithHMS(numDef.dayTaskRefreshUTH,numDef.dayTaskRefreshUTM,0,acct.scOffsetTime)
		local today_taskid = task.refresh(acct)
		if today_taskid then
			for key, taskid in ipairs(today_taskid) do
				local taskinfo = taskQuery.getName(taskid)
				if taskinfo then
					taskinfo.taskrefresh(acct)
				else
					print('tid ' .. taskid .. ', do not exsit')
				end
			end
			--������Ϣ��������
			SendMsg[9310001](today_taskid)
		end
	end
end
--------------------------------
--̽�ն�ʣ��ʱ��
--------------------------------
function __acctManager.updateExploreTime(acct)
    for heroid,item in pairs(acct.cbTeam) do
        local leftTime = item.ed - os.time()
        if leftTime<=0 and not item.timeOver and not item.reward and club_data then
            SendMsg[9313004](item.tid)
            item.timeOver = true
        end
    end
end
AcctManager={}
--��ʼ���ʺ�����
function AcctManager:init(acct,onlinedt)
	acct = SecurityManager:encrypt(acct)

	acct.onlinedt = onlinedt
	dataTranform.equipments(acct)
	dataTranform.unlockedPVE(acct.unlockedPVE)
	dataTranform.pveGuardQuest(acct.pveGuardQuest)
	dataTranform.mileSpread(acct.mileSpread, acct.mileInCD)
	dataTranform.rewardMails(acct.rewardMails)
	
	if acct.cbName then acct.cbName = HOAux:hexstr2str(acct.cbName) end
	if not acct.rewardMails then acct.rewardMails={} end
    if not acct.activityAwardMails then acct.activityAwardMails={} end
	if not acct.gmAwardMails then acct.gmAwardMails={} end
	__acctManager.initAcctTime(acct)
	__acctManager.initAcctCnt(acct)
	__acctManager.initAcctAp(acct)
	__acctManager.initAcctResCar(acct)
	__acctManager.initCbTeam(acct)
	self._acct = acct
	self._hasdata = true
end
--����ʺ�����
function AcctManager:clear()
	self._hasdata = nil
	--self._acct = nil
end
function AcctManager:hasData()
	return self._hasdata
end
--�����ʺ�����
function AcctManager:update()
	if not self._hasdata  then return end
	--�ظ��ж���
	baseCalc.resetActPt(self._acct,os.time()-1)
	__acctManager.updateTrainLvUp(self._acct)
	__acctManager.UpdateLicenceLvUp(self._acct)
	__acctManager.updateResCar(self._acct)
	__acctManager.updateTaskList(self._acct)
	__acctManager.updateExploreTime(self._acct)
end
function AcctManager:initHoleData(scenetb)
	if not scenetb then return end
	if not self._acct  then return end

	self._acct.sceneID =scenetb.aid
	self._acct.sceneLv = scenetb.sid
	self._acct.creatureList = {}

	dataTranform.mileSpread(scenetb.ms)
	self._acct.mileSpread = scenetb.ms
	self._acct.digPt = self._acct.maxDigPt
	self._acct.digTrace = scenetb.dt
	self._acct.collectorList = scenetb.cl
	
    for key,item in pairs(self._acct.monsterPool) do
        item.n = item.N
    end
end
--��ȡ�ʺ�����
function AcctManager:get()
	return self._acct
end
--��ȡ�ʺ�����
function AcctManager:getParam(propname)
	if not self._acct  then return nil end
	return self._acct[propname]
end
--�����ʺ�����
function AcctManager:setParam(propname,val)
	if not self._acct  then return end
	self._acct[propname] = val
end
function AcctManager:incrParam(propname,val)
	if not self._acct  then return end
	if not self._acct[propname]  then self._acct[propname] = 0 end
	self._acct[propname] = self._acct[propname] + val
end

function AcctManager:copyParam(propname)
	 if not self._acct  then return nil end
	 if not self._acct[propname] then return nil end
	 return Funs.copy(self._acct[propname])
end
--�����ʺ��ӱ�����
function AcctManager:setHashParam(propname,key,val)
	if not self._acct  then return end
	if not self._acct[propname] then self._acct[propname] = {} end
	self._acct[propname][key] = val
end
--��ȡ�ʺ��ӱ�����
function AcctManager:getHashParam(propname,key)
	if not self._acct  then return nil end
	if not self._acct[propname] then return nil end
	return self._acct[propname][key]
end
function AcctManager:incrHashParam(propname,key,val)
	if not self._acct  then return end
	if not self._acct[propname]  then self._acct[propname] = {} end
	if not self._acct[propname][key]  then self._acct[propname][key] = 0 end
	self._acct[propname][key] = self._acct[propname][key] + val
end
function AcctManager:copyHashParam(propname,key)
	 if not self._acct  then return nil end
	 if not self._acct[propname] then return nil end
	 if not self._acct[propname][key] then return nil end
	 return Funs.copy(self._acct[propname][key])
end
--��ȡPVP����ʱ��
function AcctManager:getPvpShellLeft()
	if not self._acct  then return 0 end
	if not self._acct.shellPvp then return 0 end
	return math.max(self._acct.shellPvp - os.time(),0)
end
--��ȡ�ͻ����������ʱ���
function AcctManager:getOffsetTime()
	if not self._acct  then return 0 end
	if not self._acct.scOffsetTime then return 0 end
	return self._acct.scOffsetTime
end
-----------------------------------------------------------------------------------------
--��ս������Ϣ
--flag: "pvp"��ͨ,"clubpvp"�����ս "revenge"��ͨpvp����
function AcctManager:setPvpAcct(flag,pvpacct)
	if not self._pvpaccts then self._pvpaccts={} end
	self._pvpaccts[flag] = pvpacct
end
function AcctManager:getPvpAcct(flag)
	if not self._pvpaccts then return nil end
	return self._pvpaccts[flag]
end
-------------------------------------------------------------------------------------------
--�ж��Ƿ���δ����Ǽ�������
function AcctManager:hasNewMission()
	if not self._acct  then return false end
	for areaid, pveArea in pairs(self._acct.unlockedPVE) do
		for stageid,stageinfo in pairs(pveArea) do
			if type(stageinfo)=="table" then 
				if stageinfo.stars == 0 then return true end
			end
		end
	end
	return false
end
--�ƹ��Ƿ��������Ŀ
function AcctManager:hasInviteChance()
	if not self._acct  then return false end
	if self._acct.freeMsgExpire<= os.time() or self._acct.freeBoxExpire<= os.time() then return true end --�Ƿ��������Ϣ��̽
	for heroid,msgnum in pairs(self._acct.heroInfoList) do
		if self._acct.heroList[heroid] then --����ļ�ж��Ƿ���Խ���
			if msgnum >= jewelCalc.getUpGradeMsg(self._acct.heroList[heroid].grade or 0) then
				return true
			end
		else --δ��ļ���ж��Ƿ�ﵽ��ļ����
			local s_cfg = hero_data.getConfig(heroid)
			if msgnum >= s_cfg.infoCnt then
				return true
			end
		end
	end
	return false
end
--�Ƿ���ڱ���
function AcctManager:hasPvpShell()
	if not self._acct  then return false end
	if not self._acct.shellPvp then return false end
	return self._acct.shellPvp > os.time()
end
--�Ƿ���δ���ʼ�
function AcctManager:hasUnReadMail()
	 for msgid,item in pairs (self._acct.msgBoxList) do
		 if item[1] == 0 then return true end
	 end
	 for msgid,item in pairs(self._acct.rewardMails) do
	     if msgid and item then return true end
	 end
	 for msgid,item in pairs(self._acct.activityAwardMails) do
	     if msgid and item then return true end
	 end
	 for msgid,item in pairs(self._acct.gmAwardMails) do
	     if msgid and item then return true end
	 end
	 return false
end
--�ھ���־������ʾ
--�ж��Ƿ�������ɵ�δ�콱������
function AcctManager:hasFinishedTask()
	if self._acct.taskList then
		for tid, taskctx in pairs(self._acct.taskList) do 
			if taskctx[2] == 1 then
				return true
			end
		end
	end
	return false
end


frameList = {--{{{
--Ӣ��-------------
{"rockman01.plist","rockman01.pvr.ccz"},
{"doublegun01.plist","doublegun01.pvr.ccz"},
{"heavygun01.plist","heavygun01.pvr.ccz"},
{"assassin01.plist","assassin01.pvr.ccz"},
{"sisters01.plist","sisters01.pvr.ccz"},
{"scientist01.plist","scientist01.pvr.ccz"},
{"artisan01.plist","artisan01.pvr.ccz"},
{"buder01.plist","buder01.pvr.ccz"},
{"nurses01.plist","nurses01.pvr.ccz"},
{"knight01.plist","knight01.pvr.ccz"},
{"villaina01.plist","villaina01.pvr.ccz"},
{"villainb01.plist","villainb01.pvr.ccz"},
{"miningrobot01.plist","miningrobot01.pvr.ccz"},
{"bigsword01.plist","bigsword01.pvr.ccz"},
{"meetcar01.plist","meetcar01.pvr.ccz"},
{"tank01.plist","tank01.pvr.ccz"},
{"joker01.plist","joker01.pvr.ccz"},
{"bowman01.plist","bowman01.pvr.ccz"},
{"snowman01.plist","snowman01.pvr.ccz"},
{"infighter01.plist","infighter01.pvr.ccz"},
{"revenger01.plist","revenger01.pvr.ccz"},
--����-------------
{"piranha01.plist","piranha01.pvr.ccz"},
{"mushroom01.plist","mushroom01.pvr.ccz"},
{"mushroom02.plist","mushroom02.pvr.ccz"},
{"spider01.plist","spider01.pvr.ccz"},
{"bear01.plist","bear01.pvr.ccz"},
{"skeletonman01.plist","skeletonman01.pvr.ccz"},
{"bomberman01.plist","bomberman01.pvr.ccz"},
{"lizard01.plist","lizard01.pvr.ccz"},
{"conch01.plist","conch01.pvr.ccz"},
{"queen01.plist","queen01.pvr.ccz"},
{"bug01.plist","bug01.pvr.ccz"},
{"shockdevice01.plist","shockdevice01.pvr.ccz"},
{"firedragon01.plist","firedragon01.pvr.ccz"},
{"icebomber01.plist","icebomber01.pvr.ccz"},
{"mole01.plist","mole01.pvr.ccz"},
{"machinemouth01.plist","machinemouth01.pvr.ccz"},
{"machinegun01.plist","machinegun01.pvr.ccz"},
{"invinciblerobot01.plist","invinciblerobot01.pvr.ccz"},
{"sportcar01.plist","sportcar01.pvr.ccz"},
{"missilelauncher01.plist","missilelauncher01.pvr.ccz"},
{"sonicgun01.plist","sonicgun01.pvr.ccz"},
--���е���---------
{"doublegun_bullet01.plist","doublegun_bullet01.pvr.ccz"},
{"mushroom_bullet01.plist","mushroom_bullet01.pvr.ccz"},
{"mushroom_bullet02.plist","mushroom_bullet02.pvr.ccz"},
{"heavygun_bullet01.plist","heavygun_bullet01.pvr.ccz"},
{"bomb01.plist","bomb01.pvr.ccz"},
{"boomerang01.plist","boomerang01.pvr.ccz"},
{"tentacle01.plist","tentacle01.pvr.ccz"},
{"fire01.plist","fire01.pvr.ccz"},
{"teargasbomb01.plist","teargasbomb01.pvr.ccz"},
{"stone01.plist","stone01.pvr.ccz"},
{"avatars01.plist","avatars01.pvr.ccz"},
{"bigbomb01.plist","bigbomb01.pvr.ccz"},
{"potion01.plist","potion01.pvr.ccz"},
{"powerpharmacy01.plist","powerpharmacy01.pvr.ccz"},
{"smallpotion01.plist","smallpotion01.pvr.ccz"},
{"tank_bullet01.plist","tank_bullet01.pvr.ccz"},
{"missile01.plist","missile01.pvr.ccz"},
{"shield01.plist","shield01.pvr.ccz"},
{"bow01.plist","bow01.pvr.ccz"},
{"snowball01.plist","snowball01.pvr.ccz"},
{"ice_bullet01.plist","ice_bullet01.pvr.ccz"},
{"defmissile01.plist","defmissile01.pvr.ccz"},
--��Ч-------------
{"effect_stun01.plist","effect_stun01.pvr.ccz"},
{"effect_blind01.plist","effect_blind01.pvr.ccz"},
{"effect_halo01.plist","effect_halo01.pvr.ccz"},
{"effect_swing01.plist","effect_swing01.pvr.ccz"},
{"effect_giantpotion01.plist","effect_giantpotion01.pvr.ccz"},
{"effect_recover01.plist","effect_recover01.pvr.ccz"},
{"effect_icebomb01.plist","effect_icebomb01.pvr.ccz"},
{"effect_slash01.plist","effect_slash01.pvr.ccz"},
{"effect_slash02.plist","effect_slash02.pvr.ccz"},
{"effect_slash03.plist","effect_slash03.pvr.ccz"},
{"effect_slash04.plist","effect_slash04.pvr.ccz"},
{"effect_slash05.plist","effect_slash05.pvr.ccz"},
{"effect_slash06.plist","effect_slash06.pvr.ccz"},
{"effect_slash07.plist","effect_slash07.pvr.ccz"},
{"effect_strike01.plist","effect_strike01.pvr.ccz"},
{"effect_strike02.plist","effect_strike02.pvr.ccz"},
{"effect_strike03.plist","effect_strike03.pvr.ccz"},
{"effect_sudden01.plist","effect_sudden01.pvr.ccz"},
{"effect_scratch01.plist","effect_scratch01.pvr.ccz"},
{"effect_pierce01.plist","effect_pierce01.pvr.ccz"},
{"effect_activeskill01.plist","effect_activeskill01.pvr.ccz"},
--����-------------
{"tile.plist","tile.pvr.ccz"},
{"grab.plist","grab.pvr.ccz"},
{"tile_bg.plist","tile_bg.pvr.ccz"},
{"resbox.plist","resbox.pvr.ccz"},

{"hero_head.plist","hero_head.pvr.ccz"},
{"herocard_1.plist","herocard_1.pvr.ccz"},
{"herocard_2.plist","herocard_2.pvr.ccz"},
{"herocard_3.plist","herocard_3.pvr.ccz"},
{"herocard_4.plist","herocard_4.pvr.ccz"},
{"herocard_5.plist","herocard_5.pvr.ccz"},
{"herocard_6.plist","herocard_6.pvr.ccz"},
{"monstercard_1.plist","monstercard_1.pvr.ccz"},
{"monstercard_2.plist","monstercard_2.pvr.ccz"},
{"monstercard_3.plist","monstercard_3.pvr.ccz"},
{"monstercard_4.plist","monstercard_4.pvr.ccz"},
{"monstercard_5.plist","monstercard_5.pvr.ccz"},
{"monstercard_6.plist","monstercard_6.pvr.ccz"},

{"monster_head.plist","monster_head.pvr.ccz"},
{"s_bg.plist","s_bg.pvr.ccz"},
{"s_bg_2.plist","s_bg_2.pvr.ccz"},
{"thumb_bg.plist","thumb_bg.pvr.ccz"},
{"tool.plist","tool.pvr.ccz"},
}--}}}
basicImgList={
	{"bar.plist","bar.pvr.ccz"},
	{"button.plist","button.pvr.ccz"},
	{"icon.plist","icon.pvr.ccz"},
	{"s_bg_1.plist","s_bg_1.pvr.ccz"},
}
animaList={--{{{
    "anima_block_0101.plist",
    "anima_block_0102.plist",
    "anima_block_0103.plist",
    "anima_block_0104.plist",
    "anima_block_0105.plist",
    "anima_mine_0101.plist",
    "anima_mine_0201.plist",
    "grab_action.plist",
    "grab_stand.plist",
	"box_silver_open.plist",
	"box_gold_open.plist",
	"box_copper_open.plist",
}--}}}

animaBattleUnit = {--{{{
    --Ӣ��
    ['rockman01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=4 , delay = 0.1},
		[11] = { frames=3 , delay = 0.3},
		[12] = { frames=5 , delay = 0.1},
    },
    ['doublegun01'] = {
        [1] = {frames=1, delay=0.1},
        [2] = {frames=4, delay=0.2},
        [10] = { frames=5 , delay = 0.1},
		[11] = { frames=2 , delay = 0.4},
		[12] = { frames=2 , delay = 0.1},
		[13] = { frames=4 , delay = 0.1},
    },
    ['heavygun01'] = {
        [1] = {frames=1, delay=0.1},
        [2] = {frames=4, delay=0.2},
        [10] = { frames=8 , delay = 0.1},
		[11] = { frames=6 , delay = 0.1},
		[12] = { frames=3 , delay = 0.1},
    },
    ['assassin01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.2},
        [10] = { frames=7 , delay = 0.1},
		[11] = { frames=7 , delay = 0.1},
		[12] = { frames=7 , delay = 0.1},
		[13] = { frames=8 , delay = 0.1},
		[14] = { frames=6 , delay = 0.1},
    },
    ['sisters01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.2},
        [10] = { frames=6 , delay = 0.1},
		[11] = { frames=8 , delay = 0.1},
		[12] = { frames=9 , delay = 0.1},
    },
    ['scientist01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=8 , delay = 0.1},
        [10] = { frames=7 , delay = 0.2},
        [11] = { frames=1 , delay = 0.1},
		[12] = { frames=6 , delay = 0.1},
		[13] = { frames=6 , delay = 0.1},
		[14] = { frames=6 , delay = 0.1},
		[15] = { frames=5 , delay = 0.1},
    },
    ['artisan01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.2},
        [10] = { frames=3 , delay = 0.2},
        [11] = { frames=2 , delay = 0.3},
        [12] = { frames=3 , delay = 0.2},
		[13] = { frames=13 , delay = 0.08},
    },
    ['buder01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=5 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=10 , delay = 0.1},
		[13] = { frames=4 , delay = 0.1},
    },
    ['nurses01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=6 , delay = 0.1},
		[11] = { frames=7 , delay = 0.1},
		[12] = { frames=4 , delay = 0.2},
		[13] = { frames=4 , delay = 0.1},
		[14] = { frames=6 , delay = 0.1},
    },
    ['knight01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.15},
        [10] = { frames=8 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=7 , delay = 0.2},
		[13] = { frames=6 , delay = 0.1},
    },
    ['villaina01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.2},
        [10] = { frames=4 , delay = 0.1},
        [11] = { frames=2 , delay = 0.2},
        [12] = { frames=1 , delay = 0.5},
    },
    ['villainb01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.2},
        [10] = { frames=5 , delay = 0.1},
    },
    ['miningrobot01'] = {
       [1] = { frames=4 , delay = 0.1},
		[2] = { frames=9 , delay = 0.1},
		[10] = { frames=10 , delay = 0.1},
		[11] = { frames=12 , delay = 0.1},
		[12] = { frames=8 , delay = 0.1},
		[13] = { frames=4 , delay = 0.1},
    },
	 ['bigsword01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.15},
		[10] = { frames=4 , delay = 0.1},
		[11] = { frames=6 , delay = 0.1},
		[12] = { frames=6 , delay = 0.1},
		[13] = { frames=4 , delay = 0.2},
		[14] = { frames=11 , delay = 0.1},
    },
	['meetcar01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=6 , delay = 0.1},
		[10] = { frames=8 , delay = 0.1},
		[11] = { frames=8 , delay = 0.1},
		[12] = { frames=6 , delay = 0.1},
		[13] = { frames=8 , delay = 0.1},
    },
	['tank01'] = {
		[1] = { frames=3 , delay = 0.1},
		[2] = { frames=6 , delay = 0.1},
		[3] = { frames=1 , delay = 0.1},
		[4] = { frames=3 , delay = 0.1},
		[5] = { frames=3 , delay = 0.1},
		[6] = { frames=6 , delay = 0.1},
		[10] = { frames=7 , delay = 0.1},
		[11] = { frames=7 , delay = 0.1},
		[12] = { frames=5 , delay = 0.2},
		[13] = { frames=3 , delay = 0.05},
		[14] = { frames=5 , delay = 0.2},
    },
	['joker01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=5 , delay = 0.1},
		[11] = { frames=9 , delay = 0.1},
		[12] = { frames=5 , delay = 0.1},
		[13] = { frames=9 , delay = 0.1},
    },
	['bowman01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=6 , delay = 0.1},
		[11] = { frames=9 , delay = 0.1},
		[12] = { frames=4 , delay = 0.1},
    },
	['snowman01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[11] = { frames=7 , delay = 0.1},
		[10] = { frames=7 , delay = 0.1},
		[12] = { frames=6 , delay = 0.1},
    },
	['infighter01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=6 , delay = 0.1},
		[11] = { frames=10 , delay = 0.1},
		[12] = { frames=1 , delay = 0.1},
		[13] = { frames=3 , delay = 0.1},
		[14] = { frames=5 , delay = 0.1},
    },
	['revenger01'] = {
       [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=5 , delay = 0.1},
		[11] = { frames=8 , delay = 0.1},
		[12] = { frames=3 , delay = 0.1},
		[13] = { frames=1 , delay = 0.1},
		[14] = { frames=4 , delay = 0.1},
		[15] = { frames=8 , delay = 0.1},
    },
    --����
    ['piranha01'] = {
        [1] = { frames=9 , delay = 0.1},
        [2] = { frames=9 , delay = 0.1},
        [11] = { frames=6 , delay = 0.1},
        [10] = { frames=6 , delay = 0.1},
        [12] = { frames=6 , delay = 0.1},
    },
    ['mushroom01'] = {
        [1] = { frames=7 , delay = 0.1},
        [2] = { frames=7 , delay = 0.1},
        [10] = { frames=8 , delay = 0.1},
    },
    ['mushroom02'] = {
        [1] = {frames=4, delay=0.2},
        [2] = {frames=4, delay=0.2},
        [10]= {frames=4, delay=0.1},
    },
    ['spider01'] = {
        [1] = { frames=2 , delay = 0.6},
        [2] = { frames=5 , delay = 0.1},
        [10] = { frames=11 , delay = 0.1},
    },
    ['bear01'] = {
        [1] = { frames=10 , delay = 0.2},
        [2] = { frames=10 , delay = 0.1},
        [10] = { frames=11 , delay = 0.1},
    },
    ['skeletonman01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.1},
        [11] = { frames=3 , delay = 0.1},
        [10] = { frames=3 , delay = 0.1},
        [12] = { frames=3 , delay = 0.1},

    },
    ['bomberman01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=3 , delay = 0.1},
        [10] = { frames=3 , delay = 0.1},
        [11] = { frames=4 , delay = 0.1},

    },
    ['lizard01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.1},
		[10] = { frames=9 , delay = 0.1},

    },
    ['conch01'] = {
        [1] = { frames=20 , delay = 0.1},
        [2] = { frames=20 , delay = 0.1},
        [10] = { frames=19 , delay = 0.06},
        [11] = { frames=19 , delay = 0.07},

    },

    ['queen01'] = {
        [1] = { frames=11 , delay = 0.1},
        [2] = { frames=12 , delay = 0.1},
        [11] = { frames=12 , delay = 0.1},
        [10] = { frames=12 , delay = 0.1},
        [12] = { frames=8 , delay = 0.1},
    },

    ['bug01'] = {
        [1] = { frames=9 , delay = 0.1},
        [2] = { frames=9 , delay = 0.1},
        [10] = { frames=9 , delay = 0.1},
        [11] = { frames=9 , delay = 0.1},
    },
    ['shockdevice01'] = {
        [1] = { frames=12 , delay = 0.1},
        [2] = { frames=12 , delay = 0.1},
        [10] = { frames=15 , delay = 0.1},
    },
	['firedragon01'] = {
        [1] = { frames=12 , delay = 0.1},
		[2] = { frames=16 , delay = 0.1},
		[11] = { frames=7 , delay = 0.1},
		[10] = { frames=7 , delay = 0.1},
		[12] = { frames=4 , delay = 0.2},
    },
	['icebomber01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=4 , delay = 0.2},
		[10] = { frames=5 , delay = 0.1},
    },
	['mole01'] = {
        [1] = { frames=1 , delay = 0.1},
		[2] = { frames=3 , delay = 0.1},
		[10] = { frames=9 , delay = 0.1},
		[11] = { frames=5 , delay = 0.1},
		[12] = { frames=8 , delay = 0.1},
		[13] = { frames=1 , delay = 0.1},
    },
	['machinemouth01'] = {
        [1] = { frames=7 , delay = 0.1},
		[2] = { frames=1 , delay = 0.1},
		[10] = { frames=6 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=3 , delay = 0.1},
    },
	['machinegun01'] = {
       [1] = { frames=7 , delay = 0.1},
		[2] = { frames=1 , delay = 0.1},
		[10] = { frames=8 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=3 , delay = 0.1},
    },
	['invinciblerobot01'] = {
       [1] = { frames=1 , delay = 0.1},
		[2] = { frames=8 , delay = 0.1},
		[10] = { frames=6 , delay = 0.1},
		[11] = { frames=8 , delay = 0.1},
		[12] = { frames=1 , delay = 0.1},
		[13] = { frames=9 , delay = 0.1},
		[14] = { frames=8 , delay = 0.1},
    },
	['sportcar01'] = {
       [1] = { frames=2 , delay = 0.1},
		[2] = { frames=7 , delay = 0.1},
		[10] = { frames=7 , delay = 0.1},
		[11] = { frames=1 , delay = 0.1},
    },
	['missilelauncher01'] = {
       [1] = { frames=12 , delay = 0.1},
		[2] = { frames=1 , delay = 0.1},
		[10] = { frames=10 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=3 , delay = 0.1},
    },
	['sonicgun01'] = {
       [1] = { frames=8 , delay = 0.1},
		[2] = { frames=1 , delay = 0.1},
		[10] = { frames=12 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=3 , delay = 0.1},
		[13] = { frames=12 , delay = 0.1},
		[14] = { frames=12 , delay = 0.1},
		[15] = { frames=1 , delay = 0.1},
		[16] = { frames=1 , delay = 0.1},
    },
    --���е���
    ['doublegun_bullet01'] = {
        [1] = {frames=1, delay=0.2},
        [2] = {frames=3, delay=0.1},
        [10]= {frames=3, delay=0.1},
        [11]= {frames=1, delay=0.1},
    },
    ['mushroom_bullet01'] = {
        [1] = { frames=1 , delay = 0.2},
        [2] = { frames=2 , delay = 0.2},
        [10] = { frames=3 , delay = 0.1},
    },
    ['mushroom_bullet02'] = {
        [1] = {frames=5, delay=0.1},
        [2] = {frames=5, delay=0.1},
        [10] = {frames=5, delay=0.1},
    },
    ['heavygun_bullet01'] = {
        [1] = {frames=1, delay=0.1},
        [2] = {frames=3, delay=0.1},
        [10]= {frames=4, delay=0.1},
        [11]= {frames=1, delay=0.1},
    },
    ['bomb01'] = {
        [1] = {frames=1, delay=0.1},
        [2] = {frames=1, delay=0.1},
        [10]= {frames=16, delay=0.05},
    },
    ['boomerang01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=1 , delay = 0.1},
        [10] = { frames=1 , delay = 0.1},
    },
    ['tentacle01'] = {
        [1] = { frames=12 , delay = 0.1},
        [2] = { frames=12 , delay = 0.05},
        [10] = { frames=12 , delay = 0.01},
        [11] = { frames=12 , delay = 0.05},
    },
    ['fire01'] = {
        [1] = { frames=6 , delay = 0.1},
        [2] = { frames=6 , delay = 0.1},
        [10] = { frames=7 , delay = 0.1},
        [11] = { frames=7 , delay = 0.1},
		[12] = { frames=15 , delay = 0.1},
    },
    ['teargasbomb01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=1 , delay = 0.1},
        [10] = { frames=7 , delay = 0.3},
    },
    ['stone01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=4 , delay = 0.1},
        [10] = { frames=3 , delay = 0.1},
    },
    ['avatars01'] = {
        [1] = { frames=6 , delay = 0.1},
        [2] = { frames=6 , delay = 0.1},
        [10] = { frames=8 , delay = 0.1},
    },
    ['bigbomb01'] = {
        [1] = { frames=1 , delay = 0.1},
        [2] = { frames=1 , delay = 0.1},
        [10] = { frames=17 , delay = 0.1},
    },
    ['potion01'] = {
        [1] = { frames=1 , delay = 1},
        [2] = { frames=1 , delay = 1},
        [10] = { frames=1 , delay = 1},
    },
    ['powerpharmacy01'] = {
        [1] = { frames=1 , delay = 1},
        [2] = { frames=1 , delay = 1},
        [10] = { frames=1 , delay = 1},
    },
	 ['smallpotion01'] = {
        [1] = { frames=1 , delay = 1},
        [2] = { frames=1 , delay = 1},
        [10] = { frames=1 , delay = 1},
    },
	['tank_bullet01'] = {
        [1] = { frames=3 , delay = 0.1},
		[2] = { frames=3 , delay = 0.1},
		[10] = { frames=7 , delay = 0.1},
		[11] = { frames=3 , delay = 0.1},
		[12] = { frames=16 , delay = 0.1},
    },
	['missile01'] = {
        [1] = { frames=2 , delay = 0.1},
		[2] = { frames=2 , delay = 0.1},
		[10] = { frames=16 , delay = 0.1},
		[11] = { frames=1 , delay = 0.1},
		[12] = { frames=7 , delay = 0.05},
		[13] = { frames=4 , delay = 0.1},
    },
	['shield01'] = {
        [1] = { frames=12 , delay = 0.1},
		[2] = { frames=3 , delay = 0.1},
		[3] = { frames=5 , delay = 0.1},
		[4] = { frames=4 , delay = 0.1},
    },
	['bow01'] = {
       [1] = { frames=1 , delay = 0.1},
		[2] = { frames=2 , delay = 0.1},
		[10] = { frames=4 , delay = 0.1},
		[11] = { frames=9 , delay = 0.1},
		[12] = { frames=5 , delay = 0.1},
    },
	['snowball01'] = {
		[1] = { frames=1 , delay = 0.1},
		[2] = { frames=1 , delay = 0.1},
		[3] = { frames=4 , delay = 0.1},
		[11] = { frames=5 , delay = 0.1},
		[13] = { frames=1 , delay = 0.1},
		[10] = { frames=4 , delay = 0.1},
		[12] = { frames=1 , delay = 0.1},
		[14] = { frames=1 , delay = 0.1},
    },
	['ice_bullet01'] = {
		[1] = { frames=3 , delay = 0.1},
		[2] = { frames=3 , delay = 0.1},
		[10] = { frames=5 , delay = 0.1},
    },
	['defmissile01'] = {
		[1] = { frames=2 , delay = 0.1},
		[2] = { frames=2 , delay = 0.1},
		[10] = { frames=8 , delay = 0.1},
		[11] = { frames=4 , delay = 0.1},
    },
    --��Ч
    ['effect_stun01'] = {
        [1] = { frames=3 , delay = 0.1},
    },
    ['effect_blind01'] = {
        [1] = { frames=1 , delay = 1},
    },
    ['effect_halo01'] = {
        [1] = { frames=7 , delay = 0.1},
    },
    ['effect_swing01'] = {
        [1] = { frames=2 , delay = 0.1},
    },
    ['effect_giantpotion01'] = {
        [1] = { frames=6 , delay = 0.1},
    },
    ['effect_recover01'] = {
        [1] = { frames=7 , delay = 0.1},
    },
    ['effect_icebomb01'] = {
        [1] = { frames=14 , delay = 0.1},
    },
    ['effect_slash01'] = {
        [1] = { frames=6 , delay = 0.1},
    },
    ['effect_slash02'] = {
        [1] = { frames=5 , delay = 0.1},
    },
    ['effect_slash03'] = {
        [1] = { frames=4 , delay = 0.1},
    },
    ['effect_slash04'] = {
        [1] = { frames=4 , delay = 0.1},
    },
    ['effect_slash05'] = {
        [1] = { frames=4 , delay = 0.1},
    },
    ['effect_slash06'] = {
        [1] = { frames=6 , delay = 0.1},
    },
	['effect_slash07'] = {
        [1] = { frames=6 , delay = 0.1},
    },
    ['effect_strike01'] = {
        [1] = { frames=4 , delay = 0.1},
    },
    ['effect_strike02'] = {
        [1] = { frames=4 , delay = 0.1},
    },
    ['effect_strike03'] = {
        [1] = { frames=4 , delay = 0.1},
    },
    ['effect_sudden01'] = {
        [1] = { frames=5 , delay = 0.1},
    },
    ['effect_scratch01'] = {
        [1] = { frames=6 , delay = 0.1},
    },
    ['effect_pierce01'] = {
        [1] = { frames=5 , delay = 0.1},
    },
	['effect_activeskill01']={
		[1] = { frames=4 , delay = 0.1},
	}
}--}}}

--!@brief:    ���򶯻�����ԭʼ���ò��������
--!@element struct:
    --[[
        [graphic_name(str)] = {
            [actionID_1(num)] = {
                [def(str)] = {}, --ref orignal cfg in battleUnit
                [0] = 'animaName1', --right 0
                [1] = 'animaName2', --down  90
                [2] = 'animaName3', --left  180
                [3] = 'animaName4', --up    270
            },
            [actionID_2(num)] = {...}
        }
    --]]

local animaContext = {}

--��������ԭʼ֡������ұ�
--key: anima name
--val: orignal delay
local _animaOrigDelayLook = {}

------------------------------------------------------------------

--! @module graphicLoader
    graphicLoader = {}

function graphicLoader.loadBasicFrame()
	ZipUtils:setPvrKey(kPvrKey[1],kPvrKey[2],kPvrKey[3],kPvrKey[4])	
	graphicLoader.loadFrame(basicImgList)
end
function graphicLoader.loadFrame(list_path)--{{{
	local srcpath = "GUIRes/image/sprite/"
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
    for idx, path in ipairs(list_path) do
        frameCache:addSpriteFramesWithFile(srcpath..path[1],srcpath..path[2])
    end
end--}}}
--���Ӿ���֡
function graphicLoader.loadFrameWithFile(list_path,file_path)
	--����ָ����·�����Ӿ���֡
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	for idx, path in ipairs(list_path) do
			frameCache:addSpriteFramesWithFile(file_path..path[1],file_path..path[2])
	end
end
--�Ƴ�����֡
function graphicLoader.unloadFrameWithFile(list_path,file_path)
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	for idx,path in ipairs(list_path) do
		frameCache:removeSpriteFramesFromFile(file_path..path[1])
	end
end
function graphicLoader.loadAnima4Way(myList)--{{{

    local animaCache = CCAnimationCache:sharedAnimationCache()

    for name, cfg in pairs(myList) do

        local name_ctx = {}

        for actionID, actionDef in pairs(cfg) do

            local f = actionDef.frames
            local d = actionDef.delay
            local s = f * d
            local ms = s * 1000
            local ctx = {def={f=f, d=d, s=s, ms=ms}}

            name_ctx[actionID] = ctx

            for dir=1, 4 do
                local anima = CCAnimation:create()
                anima:setDelayPerUnit(actionDef.delay)
                for idx=1, actionDef.frames do
                    local frameName = string.format('%s_%02d%02d%02d.png', name, actionID, dir, idx)
                    local frame = assert(graphicLoader.getFrame(frameName), 'can not find frame with name: ' .. frameName)
                    anima:addSpriteFrame(frame)
                end
                local animaName = string.format('%s_%02d%02d', name, actionID, dir)
				animaCache:removeAnimationByName(animaName)
                animaCache:addAnimation(anima, animaName)
                _animaOrigDelayLook[animaName] = actionDef.delay
                ctx[(dir-1)*90] = animaName
            end

        end

        --put context into animaContext
        animaContext[name] = name_ctx
    end
end--}}}
--���ؼ򵥶���
function graphicLoader.loadAnimaFrames(list_path)--{{{
	local animaPath = "GUIRes/image/other/"
    local animacache=CCAnimationCache:sharedAnimationCache();
    for idx,path in ipairs(list_path) do
        animacache:addAnimationsWithFile(animaPath..path)
    end
end--}}}

function graphicLoader.getFrame(frameName)--{{{
    local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
    local frame = frameCache:spriteFrameByName(frameName)
    if frame == nil then
        HOAux:print("Can not find frame " ..frameName)
    end
    return frame
end--}}}

function graphicLoader.getAnimation(animaName)--{{{
    local animaCache = CCAnimationCache:sharedAnimationCache()
    local anima = animaCache:animationByName(animaName)
    if not anima then
        HOAux:print("Can not find animation " .. animaName)
        assert(nil,"")
    end
    return anima
end--}}}

function graphicLoader.animaName(prefix, action, dir) --dir is in degree
    return animaContext[prefix][action][dir or 90]
end

function graphicLoader.animaFrames(prefix, action)
    return animaContext[prefix][action].def.f
end

function graphicLoader.animaDelay(prefix, action)
    return animaContext[prefix][action].def.d
end

function graphicLoader.animaDurS(prefix, action)
    return animaContext[prefix][action].def.s
end

function graphicLoader.animaDurMS(prefix, action)
    return animaContext[prefix][action].def.ms
end

function graphicLoader.getOrigUnitDelay(animaName)--{{{
    return _animaOrigDelayLook[animaName] or 0
end--}}}
--Ԥ����ͼƬ�Ͷ�����Դ
function graphicLoader.loadAllImages()
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	frameCache:removeSpriteFrames()
	graphicLoader.loadBasicFrame()
	graphicLoader.loadFrame(frameList)
	graphicLoader.loadAnima4Way(animaBattleUnit)
	graphicLoader.loadAnimaFrames(animaList)
end




local function encrypt(raw,proxy)--{{{
	for k,v in pairs(raw) do
		if type(v) == 'number' then
			proxy[k] = v
		elseif type(v) == 'table' then
			encrypt(v,proxy[k])
		end
	end
	return proxy
end--}}}

local function maketree(path, capture, root_at)--{{{
	local f,l,node = string.find(path, capture, 1)
	while node do
		local nt = root_at[node] or {}
		root_at[node] = nt
		root_at = nt
		f,l,node = string.find(path, capture, l+1)
	end
	return root_at
end--}}}

local function cleartree(at)--{{{
	for k,v in pairs(at) do
		if type(v) == 'table' then
			cleartree(v)
		else
			at[k] = nil
		end
	end
end--}}}

local function tproxy(raw,ctx,path,efunc,cfunc)--{{{
	local enVals = maketree(path,'(%w+.)',ctx.encrypted)
	local proxy = {
		__index = function(p,k)
			local v = raw[k]
			if type(v) == 'table' then
				return ctx[v] or tproxy(v,ctx,path..k..'.',efunc,cfunc)
			elseif type(v) == 'number' then
				if efunc(k,v) ~= enVals[k] then
					print("--------------------------------")
					for key,val in pairs(enVals) do
						print(key,val)
					end
					print("--------------------------------")
					if cfunc then cfunc(k,v) end
				end
			end
			return v
		end,
		__newindex = function(p,k,v)
			local typename = type(v)
			if typename == 'nil' then
				raw[k] = nil
				enVals[k] = nil
			elseif typename == 'table' then
				raw[k] = v
				cleartree(enVals[k..'.'] or {})
				encrypt(v,tproxy(v,ctx,path..k..'.',efunc,cfunc))
			elseif typename == 'number' then
				raw[k] = v
				enVals[k] = efunc(k,v)
			else
				raw[k] = v
			end
		end,
		rawtable = function()
			return raw
		end,
		etable = function()
			return enVals
		end
	}
	ctx[raw] = proxy
	return setmetatable(proxy,proxy)
end--}}}

	--!@module: encryptTable
	module('encryptTable',package.seeall)

function create(raw,efunc,cfunc)--{{{
	return encrypt(raw,tproxy(raw,{encrypted={}},'',efunc,cfunc))
end--}}}


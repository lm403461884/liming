local local_rs = {host = "127.0.0.1",port = {3000,3001},port1=12000}
local company_rs = {host = "192.168.1.12",port = {3001,3002},port1=12000}
local public_cloud = {host = 'ho.starforus.com', port = {3000,3001},port1=12000}

DSConfig = local_rs
UpdateConfig = {}
UpdateConfig.subDir = "duobaolianmeng"

UpdateConfig.verFileUrl = "https://raw.githubusercontent.com/alidalee/duobaolianmeng/master/version"
UpdateConfig.downLoadPath ="https://raw.githubusercontent.com/alidalee/duobaolianmeng/master/updatefiles/"

--[[
UpdateConfig.verFileUrl = "https://raw.githubusercontent.com/alidalee/UpdateEngine/master/version"
UpdateConfig.downLoadPath ="https://raw.githubusercontent.com/alidalee/UpdateEngine/master/updatefiles/"
--]]


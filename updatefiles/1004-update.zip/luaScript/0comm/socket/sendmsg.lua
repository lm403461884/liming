local keyLower = 1
local keyUpper = 10240
local function getFingerMask(checksum)
	return checksum * g_keygen(keyLower,keyUpper)
end
--写入包头
local function writeMsgHead(msgcode)
	StreamComposer:clearStream()
	if not guid then guid = 0 end
    StreamComposer:write(0,msgcode,guid,-1)
end

--写入加密包头
local function writeCryptMsgHead(msgcode)
	StreamComposer:clearStream()
	if not guid then guid = 0 end
    StreamComposer:write(0,msgcode,guid,-1,0)
end
--写入只有包头的信息并发送
local function writeHeadOnlyMsg(msgcode)
	local sockfd = SocketHelper.getGSConn()
	if not sockfd then print("can not send msg "..msgcode.." while sockfd is nil") return end
	StreamComposer:clearStream()
    StreamComposer:write(20,msgcode,guid,-1,20)
	SendQueue:push_back(sockfd,StreamComposer:getStreamHeader(),StreamComposer:getStreamLen())
end
--写入包尾并发送
local function writeMsgTail()
	local sockfd = SocketHelper.getGSConn()
	if not sockfd then print("can not send msg while sockfd is nil") return end
	StreamComposer:writeInt(0)
	local len_msg = StreamComposer:getStreamLen()
	StreamComposer:movePtrToHead()
	StreamComposer:writeInt(len_msg)
	StreamComposer:movePtrTo(len_msg-4)
	StreamComposer:writeInt(len_msg)
	SendQueue:push_back(sockfd,StreamComposer:getStreamHeader(),StreamComposer:getStreamLen())
end
--写入加密包尾并发送
local function writeCryptMsgTail0()
	local sockfd = SocketHelper.getGSConn()
	if not sockfd then print("can not send Crypt msg0 while sockfd is nil") return end
	StreamComposer:writeInt(0)
	local len_msg = StreamComposer:getStreamLen()
	local checksum = StreamComposer:getBlockCheckSum(20,len_msg-24)
	StreamComposer:movePtrToHead()
	StreamComposer:writeInt(len_msg)
	StreamComposer:movePtrTo(16)
	StreamComposer:writeInt(checksum*1982)
	StreamComposer:movePtrTo(len_msg-4)
	StreamComposer:writeInt(len_msg)
	SendQueue:push_back(sockfd,StreamComposer:getStreamHeader(),StreamComposer:getStreamLen())
end
--写入加密包尾并发送
local function writeCryptMsgTail()
	local sockfd = SocketHelper.getGSConn()
	if not sockfd then   print("can not send Crypt msg while sockfd is nil") return end
	StreamComposer:writeInt(0)
	local len_msg = StreamComposer:getStreamLen()
	local checksum = StreamComposer:getBlockCheckSum(20,len_msg-24)
	StreamComposer:movePtrToHead()
	StreamComposer:writeInt(len_msg)
	StreamComposer:movePtrTo(16)
	StreamComposer:writeInt(getFingerMask(checksum))
	StreamComposer:movePtrTo(len_msg-4)
	StreamComposer:writeInt(len_msg)
	SendQueue:push_back(sockfd,StreamComposer:getStreamHeader(),StreamComposer:getStreamLen())
end
--写入数组数据，格式＝数组长度/factor，数组内容
-- arr 需要写入的数据
--factor 一个元素需要的数据个数,
local function writeArrToMsg(arr,factor)
	if not arr then arr={} end
	if (not factor) or (factor == 0) then factor = 1 end
	local arrLen =  #arr
	if arrLen%factor ~= 0 then print(string.format("invalid arr length %d with factor %d",arrLen,factor)) return end
	StreamComposer:writeInt(arrLen/factor)
	for key,val in ipairs(arr) do
		StreamComposer:writeInt(val)
	end
end
--写入键值表数据，格式＝键值对个数，key,val...
--ht 需要写入的数据
local function writeHtToMsg(ht)
	if not ht then return end
	StreamComposer:writeInt(0)
	local mCnt = 0
	for key,val in pairs(ht) do
		StreamComposer:write(key,val)
		mCnt = mCnt + 1
	end
	--插入元素个数，其中每两个数字代表一个英雄消息
	StreamComposer:movePtrTo(StreamComposer:getStreamLen() - 8*mCnt - 4)
	StreamComposer:writeInt(mCnt)
	StreamComposer:movePtrToTail()
end
--写入获取的资源数据，格式＝资源类型数量,+资源类型，获得值...
--resht 资源收益表
local function writeGainResToMsg(resht)
	if not resht then return end
	StreamComposer:writeInt(0)
	local resCnt = 0
	for key,val in pairs(resht) do
		StreamComposer:write(KVariantList.coinName[key],val)
		resCnt = resCnt +1
	end
	--插入资源个数，其中每两个数字代表一个资源
	StreamComposer:movePtrTo(StreamComposer:getStreamLen() - 8*resCnt - 4)
	StreamComposer:writeInt(resCnt)
	StreamComposer:movePtrToTail()
end
--写入英雄技能使用时间信息 格式=使用技能的英雄数量 + 英雄ID,技能使用次数，技能使用帧...
--skillUsage 技能使用时机表
local function writeSkillUsageToMsg(skillUsage)
	if not skillUsage then return end
	local useCnt = 0
	--{heroid={framid1..framidN},..}
	for key, val in pairs(skillUsage) do
		useCnt = useCnt + 1
	end
	StreamComposer:writeInt(useCnt)
	for heroid, frames in pairs(skillUsage) do
		StreamComposer:write(heroid, #frames)
		for _, frameNo in ipairs(frames) do
			StreamComposer:writeInt(frameNo)
		end
	end
end
SendMsg={}
SendMsg.digCache={}
--===========================
--将挖掘通讯数据添加至临时缓存列表
--idx:    int    挖掘点索引位置
--dp:    int    挖掘点所属层级
--===========================
function SendMsg.addDigMsg(idx,dp,gold,oil)
    table.insert(SendMsg.digCache,idx)
    table.insert(SendMsg.digCache,dp)
    table.insert(SendMsg.digCache,gold)
    table.insert(SendMsg.digCache,oil)
end

SendMsg[981001]=function(sockfd)
	StreamComposer:clearStream()
	local uid = SDKHelper:getHOUID()
	local gameVer = DBHelper.getGameVer()
	StreamComposer:write(0,981001,0)
	StreamComposer:writeStr(uid,#uid)
	StreamComposer:writeInt(gameVer)
	StreamComposer:writeInt(0)
	local len_msg = StreamComposer:getStreamLen()
	local checksum =  StreamComposer:getBlockCheckSum(12,len_msg-16)
	StreamComposer:movePtrToHead()
	StreamComposer:writeInt(len_msg)
	StreamComposer:movePtrTo(8)
	StreamComposer:writeInt(checksum*1980)
	StreamComposer:movePtrTo(len_msg-4)
	StreamComposer:writeInt(len_msg)
	SocketHelper.setDSConn(sockfd)
	SendQueue:push_back(sockfd,StreamComposer:getStreamHeader(),StreamComposer:getStreamLen())
end
--===========================
--930000 心跳消息
--===========================
--===========================
SendMsg[930000] = function()
	local sockfd = SocketHelper.getGSConn()
	if not sockfd then FloatNode.wakeUp() return end
	StreamComposer:clearStream()
    StreamComposer:writeInt(0)
	SendQueue:push_back(sockfd,StreamComposer:getStreamHeader(),StreamComposer:getStreamLen())
	print("heartbeat-----------------------------",StreamComposer:getStreamLen())
end
--===========================
--931001 获取帐号数据
--===========================
--myguid:   个人GUID
--sid:       分区ID
--===========================
SendMsg[931001] = function(sid,myguid)
	writeCryptMsgHead(931001)
	StreamComposer:write(sid,myguid)
	writeCryptMsgTail0()
end

--===========================
--931002 注册
--hopuid 平台标识_平台UDI
--sid 分区ID
--pflag 平台标识,
--===========================

SendMsg[931002] = function(hopuid,sid,pflag)
	writeCryptMsgHead(931002)
	StreamComposer:writeStr(hopuid,#hopuid)
	StreamComposer:write(pflag,sid)
	writeCryptMsgTail0()
end
--===========================
--931003 请求录像列表
--===========================
SendMsg[931003] = function()
	local lastvid = videomanager.getlastvid()
	writeMsgHead(931003)
	StreamComposer:writeInt(lastvid)
	writeMsgTail()
end
--===========================
--931004 录像回放，请求录像信息明细
--===========================
--idx: 录像ID
--===========================
SendMsg[931004] = function(idx)
	writeMsgHead(931004)
	StreamComposer:writeInt(idx)
	writeMsgTail()
end
--===========================
--931005 清除引导项
--===========================
--sceneCode 需要加载引导项的页面编号
--itemId 引导项ID
--===========================
SendMsg[931005] = function(sceneCode,itemId)
	writeMsgHead(931005)
	StreamComposer:write(sceneCode,itemId)
	writeMsgTail()
end
--===========================
--931006 获取ELO排名
--pageIdx 当前请求页索引编号 从0 开始
--===========================
SendMsg[931006] = function(pageIdx)
	writeMsgHead(931006)
	StreamComposer:writeInt(pageIdx)
	writeMsgTail()
end
--============================
--931008 公共频道聊天发言
--============================
SendMsg[931008] = function (clubid,clubname,info)
	writeMsgHead(931008)
	StreamComposer:writeInt(clubid)
	StreamComposer:writeStr(clubname, #clubname)
    StreamComposer:writeStr(info,#info)
	writeMsgTail()
end
--============================
--931009 查询某帐号摘要数据
--============================
SendMsg[931009] = function (user_guid)
	writeMsgHead(931009)
	StreamComposer:writeInt(user_guid)
	writeMsgTail()
end
--============================
--931010 修改用户昵称
--============================
SendMsg[931010] = function (user_nickname)
	writeMsgHead(931010)
	StreamComposer:writeStr(user_nickname,#user_nickname)
	writeMsgTail()
end
--===========================
--931011 邮件领奖
--===========================
SendMsg[931011] = function (msgid)
	writeMsgHead(931011)
	StreamComposer:writeInt(msgid)
	writeMsgTail()
end
--===========================
--931012 购买行动力
--===========================
SendMsg[931012] = function ()
	writeHeadOnlyMsg(931012)
end
--===========================
--931013 重置行动力购买次数
--===========================
SendMsg[931013] = function ()
	writeHeadOnlyMsg(931013)
end
--============================
--931014 私聊频道聊天发言
--============================
SendMsg[931014] = function (recvguid,clubid,clubname,info)
	writeMsgHead(931014)
	StreamComposer:write(recvguid,clubid)
	StreamComposer:writeStr(clubname,#clubname)
    StreamComposer:writeStr(info, #info)
	writeMsgTail()
end
--===========================
--931015 请求小队战力榜单
--pageIdx 请求的数据页码
--===========================
SendMsg[931015] = function (pageIdx)
	writeMsgHead(931015)
	StreamComposer:writeInt(pageIdx)
	writeMsgTail()
end
--===========================
--931017 请求PVE成就榜单
--pageIdx 请求的数据页码
--===========================
SendMsg[931017] = function (pageIdx)
	writeMsgHead(931017)
	StreamComposer:writeInt(pageIdx)
	writeMsgTail()
end
--================================
--931018 签到
--================================
SendMsg[931018] = function()
	writeHeadOnlyMsg(931018)
end
--================================
--931019 购买金币
--================================
SendMsg[931019] = function()
	writeHeadOnlyMsg(931019)
end
--================================
--931020 商城购买产品
--================================
SendMsg[931020] = function(itemid)
	writeMsgHead(931020)
	StreamComposer:writeInt(itemid)
	writeMsgTail()
end
--================================
--931021 请求更新脚本
--cmver 脚本版本号
--================================
SendMsg[931021] = function(cmver)
	writeMsgHead(931021)
	StreamComposer:writeInt(cmver)
	writeMsgTail()
end
--================================
--931022 领取运营活动奖励
--================================
SendMsg[931022] = function(mailid)
	writeMsgHead(931022)
	StreamComposer:writeInt(mailid)
	writeMsgTail()
end
--================================
--931023 领取GM活动奖励
--================================
SendMsg[931023] = function(mailid)
	writeMsgHead(931023)
	StreamComposer:writeInt(mailid)
	writeMsgTail()
end
--================================
--931999 标记测试用户
--================================
SendMsg[931999] = function()
	writeHeadOnlyMsg(931999)
end
--===========================
--932001 挖掘消息
--===========================
--idx:    int    挖掘点索引位置
--dp:    int    挖掘点所属层级
--===========================
SendMsg[932001] = function()
    if #SendMsg.digCache <=0 then return end
	writeCryptMsgHead(932001)
    StreamComposer:write(unpack(SendMsg.digCache))
	writeCryptMsgTail()
    SendMsg.digCache={}
end
--===========================
--932002 开新坑
--===========================
SendMsg[932002] = function()
    SendMsg.digCache={}--开新坑前先清空挖掘队列中的消息
	writeHeadOnlyMsg(932002)
end

--===========================
--932003 修改怪物显示位置
--===========================
--monsterid:怪物ID
--oldpos:当前位置
--newpos:目标位置
--===========================
SendMsg[932003] = function(monsterid,oldpos,newpos)
    SendMsg[932001]() --发送前先处理挖掘队列中的消息
	
	writeMsgHead(932003)
	StreamComposer:write(monsterid,oldpos,newpos)
	writeMsgTail()
end
--===========================
--932004 开始执照升级
--===========================
--lv:当前
--tlv:目标等级
--===========================
SendMsg[932004] = function(lv,tlv)
	writeMsgHead(932004)
	StreamComposer:write(lv,tlv)
	writeMsgTail()
end
--===========================
--932005 执照升级完成
--===========================
--lv:当前
--tlv:目标等级
--===========================
SendMsg[932005] = function(lv,tlv)
	writeMsgHead(932005)
	StreamComposer:write(lv,tlv)
	writeMsgTail()
end
--===========================
--932006 移动矿车
--===========================
--idx:采集车在collectorList中的数组索引
--pos:目标位置
--===========================
SendMsg[932006] = function(idx,pos)
    SendMsg[932001]() --发送前先处理挖掘队列中的消息
	
	writeMsgHead(932006)
	StreamComposer:write(idx,pos)
	writeMsgTail()
end
--===========================
--932007 采集矿车资源
--===========================
--idx:采集车在collectorList中的数组索引
--gain:收益
--===========================
SendMsg[932007] = function(idx,gain)
    SendMsg[932001]() --发送前先处理挖掘队列中的消息
	
	writeMsgHead(932007)
	StreamComposer:write(idx,gain)
	writeMsgTail()
end
--===========================
--932008 放置怪
--===========================
--monsterid:怪物ID
--pos:目标位置
--===========================
SendMsg[932008] = function(monsterid,pos)
    SendMsg[932001]() --发送前先处理挖掘队列中的消息

	writeMsgHead(932008)
	StreamComposer:write(monsterid,pos)
	writeMsgTail()
end
--===========================
--932009 收回怪
--===========================
--monsterid:怪物ID
--pos:怪物当前位置
--===========================
SendMsg[932009] = function(monsterid,pos)
    SendMsg[932001]() --发送前先处理挖掘队列中的消息

	writeMsgHead(932009)
	StreamComposer:write(monsterid,pos)
	writeMsgTail()
end
--===========================
--932010 加速执照升级
--===========================
--lv:怪物ID
--tlv:怪物当前位置
--jewel:消耗的星钻
--===========================
SendMsg[932010] = function(lv,tlv,jewel)
	writeCryptMsgHead(932010)
    StreamComposer:write(lv,tlv,jewel)
	writeCryptMsgTail()
end

--===========================
--934001 开始PVE战斗
--===========================
SendMsg[934001] = function()
	writeHeadOnlyMsg(934001)
end

--===========================
--934002 发送PVE战斗结果数据
--===========================
--bp 战斗数据
--===========================

SendMsg[934002] = function(bp)
	writeCryptMsgHead(934002) 
	--区域ID,关卡ID,击破的矿车数量
	StreamComposer:write(bp.areaID,bp.stageID,#bp.collector)
	--获取的资源
	writeGainResToMsg(bp.gainRes)
	--获取的英雄消息
	writeHtToMsg(bp.gainHeroMsg)
	--获取的设备
	writeArrToMsg(bp.gainEquip,1)
	writeCryptMsgTail()
end

--===========================
--934003 小队成员信息修改
--===========================
--team:小队成员信息
--===========================
SendMsg[934003] = function(team)
	if not team or table.getn(team) == 0 then print("invalid team info ,can not remove all team member") return end
	writeMsgHead(934003)
	for key,val in ipairs(team) do
		StreamComposer:writeInt(val)
	end
	writeMsgTail()
end
--===========================
--934004 世界地图变更
--===========================
--areaid:区域ID
--===========================
SendMsg[934004] = function(areaid)
	writeMsgHead(934004)
    StreamComposer:writeInt(areaid)
	writeMsgTail()
end
--===========================
--934005 免费招募新成员
--===========================
--areaid:区域ID
--===========================
SendMsg[934005] = function(heroid)
	writeMsgHead(934005)
    StreamComposer:writeInt(heroid)
	writeMsgTail()
end
--===========================
--934006 免费消息打探/免费开宝箱
--=============================
--boxType：1消息打探 2黑市宝箱
--msglist: 获得的英雄消息
--reslist: 获得的资源信息
--equiplist:获得的装备信息
--===========================
SendMsg[934006] = function(boxType,msglist,reslist,equiplist)

	writeCryptMsgHead(934006) 
	--宝箱类型
	StreamComposer:writeInt(boxType)
	--获取的英雄消息
	writeArrToMsg(msglist,2)
	--获取的资源
	writeArrToMsg(reslist,2)
	--获取的装备
	writeArrToMsg(equiplist,1)
	writeCryptMsgTail()
end
--===========================
--934007 付费消息打探
--=============================
--msglist: 获得的英雄消息
--reslist: 获得的资源信息
--equiplist:获得的装备信息
--cost：支付的金额
--===========================
SendMsg[934007] = function(cost,msglist,reslist,equiplist)
	writeCryptMsgHead(934007) 
	--支付的金额
	StreamComposer:writeInt(cost)
	--获取的英雄消息
	writeArrToMsg(msglist,2)
	--获取的资源
	writeArrToMsg(reslist,2)
	--获取的装备
	writeArrToMsg(equiplist,1)
	writeCryptMsgTail()
end
--===========================
--934008 付费雇佣
--=============================
--cost: 支付金额（jewel）
--heroid:英雄ID
--===========================
SendMsg[934008] = function(heroid,cost)
    writeCryptMsgHead(934008) 
    StreamComposer:write(heroid,cost)
    writeCryptMsgTail()
end
--===========================
--934011 防御任务结束
--=============================
--stars 获得的星星数
--dmIdx 防御任务ID
--===========================
SendMsg[934011] = function(stars,dmIdx)
   writeMsgHead(934011)
   StreamComposer:write(stars,dmIdx)
   writeMsgTail()
end
--===========================
--934012 新的远征
--=============================
--mapid 远征地图ID
--heroteam 远征队成员
--===========================
SendMsg[934012] = function(mapid,heroteam)
	 writeMsgHead(934012)
	 StreamComposer:writeInt(mapid)
	 writeArrToMsg(heroteam,1)
	 writeMsgTail()
end
--===========================
--934013 远征任务战斗结束
--=============================
--bp 战场数据
--totalLv 小队英雄等级总和
--===========================
SendMsg[934013] = function(bp,totalLv)

	writeCryptMsgHead(934013) 
	--关卡ID,获得的星星数
	StreamComposer:write(bp.stageID,bp.stars)
	--死亡的怪物信息
	writeArrToMsg(bp.monsterDeath,1)
	--总等级
	StreamComposer:writeInt(totalLv)
	--远征英雄信息
	writeArrToMsg(bp.heroHpPower,2)
	--获取的资源
	writeGainResToMsg(bp.gainRes)
	--获取的英雄消息
	writeHtToMsg(bp.gainHeroMsg)
	--获取的装备
	writeArrToMsg(bp.gainEquip,1)
	writeCryptMsgTail()
end

--===========================
--934014 开始PVE扫荡
--===========================
--bp 战斗结果数据
--===========================

SendMsg[934014] = function(jewelVal,bp)
	writeCryptMsgHead(934014) 
	--消耗的星钻,区域ID,关卡ID,获得的星星数
	StreamComposer:write(jewelVal,bp.areaID,bp.stageID,bp.stars)
	--获取的资源
	writeGainResToMsg(bp.gainRes)
	--获取的英雄消息
	writeHtToMsg(bp.gainHeroMsg)
	--获取的装备
	writeArrToMsg(bp.gainEquip,1)
	writeCryptMsgTail()
end
--===========================
--934015 开始远征任务
--===========================
SendMsg[934015] = function()
	writeHeadOnlyMsg(934015)
end
--===========================
--934016 免费晋升
--heroid：需要晋升的英雄
--===========================
SendMsg[934016] = function(heroid)
	 writeMsgHead(934016)
	 StreamComposer:writeInt(heroid)
	 writeMsgTail()
end
--===========================
--934017 付费晋升
--heroid：需要晋升的英雄
--===========================
SendMsg[934017] = function(heroid)
	 writeMsgHead(934017)
	 StreamComposer:writeInt(heroid)
	 writeMsgTail()
end
--===========================
--934018 重设个人战斗力总和
--totalBp:排行榜类型
--===========================
SendMsg[934018] = function (totalBp)
	writeCryptMsgHead(934018) 
	StreamComposer:writeInt(totalBp)
	writeCryptMsgTail()
end
--===========================
--935001 搜索PVP对手
--===========================
SendMsg[935001] = function()
	writeHeadOnlyMsg(935001)
end

--===========================
--935002 开始PVP进攻
--===========================
SendMsg[935002] = function()
	writeHeadOnlyMsg(935002)
end

--===========================
--935003 放弃PVP对手
--===========================
SendMsg[935003] = function()
	writeHeadOnlyMsg(935003)
end
--===========================
--935004 结束PVP进攻
--===========================
--battledata 战斗数据
--===========================

SendMsg[935004] = function(bp)
	writeCryptMsgHead(935004) 
	--被击破的矿车
	writeArrToMsg(bp.collector,1)
	--星星数量，补给值，开始时间，结束时间，总帧数，
	StreamComposer:write(bp.stars, bp.consume,bp.startTime,bp.endTime,bp.frameCnt)
	--英雄进入帧
	writeArrToMsg(bp.heroEnterFrame,1)
	--英雄激活帧
	writeArrToMsg(bp.heroCreatedFrame,1)
	--英雄技能使用帧
	writeSkillUsageToMsg(bp.skillUsageFrame)
	writeCryptMsgTail()
end

--===========================
--935006 获取复仇对象数据
--===========================
SendMsg[935005] = function(user_guid)
	writeMsgHead(935005)
	StreamComposer:writeInt(user_guid)
	writeMsgTail()
end
--===========================
--935007 开始复仇
--===========================
SendMsg[935007] = function()
	writeHeadOnlyMsg(935007)
end
--===========================
--935008 复仇战斗结束
--vid录像ID
--battledata 战斗数据
--===========================
SendMsg[935008] = function(vid,bp)

	writeCryptMsgHead(935008) 
	--录像ID
	StreamComposer:writeInt(vid)
	--被击破的矿车
	writeArrToMsg(bp.collector,1)
	--星星数量，补给值，开始时间，结束时间，总帧数，
	StreamComposer:write(bp.stars, bp.consume,bp.startTime,bp.endTime,bp.frameCnt)
	--英雄进入帧
	writeArrToMsg(bp.heroEnterFrame,1)
	--英雄激活帧
	writeArrToMsg(bp.heroCreatedFrame,1)
	--英雄技能使用帧
	writeSkillUsageToMsg(bp.skillUsageFrame)
	writeCryptMsgTail()
end
--===========================
--935009 重置复仇次数
--===========================
SendMsg[935009] = function ()
	writeHeadOnlyMsg(935009)
end

--===========================
--936004 购买生物
--===========================
--monsterid:怪物ID
--===========================
SendMsg[936004] = function(monsterid)
	writeMsgHead(936004)
	StreamComposer:writeInt(monsterid)
	writeMsgTail()
end
--===========================
--936005 开始训练
--===========================
--utype:单位类型 1英雄 2怪
--itemid:单位ID
--isJewel:是否星钻 1是，0其它
--isSucc:是否成功 1成功 0其它
--===========================
SendMsg[936005] = function(utype,itemid,isJewel,isSucc)
	writeMsgHead(936005)
	StreamComposer:write(utype,itemid,isJewel,isSucc)
	writeMsgTail()
end
--===========================
--936006 改装怪物
--===========================
SendMsg[936006] = function(monsterid)
	writeMsgHead(936006)
	StreamComposer:writeInt(monsterid)
	writeMsgTail()
end

--===========================
--937001 购买车箱
--===========================
--id:车箱ID
--===========================
SendMsg[937001] = function(id)
	writeMsgHead(937001)
	StreamComposer:writeInt(id)
	writeMsgTail()
end
--===========================
--937002 开始车箱升级
--===========================
--id:车箱ID
--lv:目标等级
--===========================
SendMsg[937002] = function(id,lv)
	writeMsgHead(937002)
	StreamComposer:write(id,lv)
	writeMsgTail()
end

--===========================
--937003 车箱升级结束
--===========================
--id:车箱ID
--lv:目标等级
--===========================
SendMsg[937003] = function(id,lv)
	writeMsgHead(937003)
	StreamComposer:write(id,lv)
	writeMsgTail()
end
--===========================
--937005 加速车箱升级
--===========================
--id:车箱ID
--lv:目标等级
--jewel:消耗的星钻
--===========================
SendMsg[937005] = function(id,lv,jewel)
	writeCryptMsgHead(937005)
    StreamComposer:write(id,lv,jewel)
	writeCryptMsgTail()
end
--===========================
--938001 创建新公会
--===========================
--clubName:公会名称
--===========================
SendMsg[938001] = function(clubName,clubInfo)
	writeMsgHead(938001)
	StreamComposer:writeStr(clubName,#clubName)
	StreamComposer:writeStr(clubInfo,#clubInfo)
	writeMsgTail()
end
--===========================
--938002 请求公会数据
--===========================
SendMsg[938002] = function()
	writeHeadOnlyMsg(938002)
end
--===========================
--938003 查找公会摘要
--===========================
--clubname 要查找公会名字
--===========================
SendMsg[938003] = function(clubName)
	writeMsgHead(938003)
	StreamComposer:writeStr(clubName,#clubName)
	writeMsgTail()
end

--===========================
--938004 申请加入公会
--===========================
--cid 目标公会id
--===========================
SendMsg[938004] = function(cid)
	writeMsgHead(938004)
	StreamComposer:writeInt(cid)
	writeMsgTail()
end
--============================
--938005 同意加入公会
--============================
--mid 消息id
--============================
SendMsg[938005] = function(mid,state)
	writeMsgHead(938005)
	StreamComposer:write(mid,state)
	writeMsgTail()
end
--============================
--938006 离开公会
--============================
SendMsg[938006] = function()
	writeHeadOnlyMsg(938006)
end
--============================
--938008 聊天发言
--============================
SendMsg[938008] = function (info)
	writeMsgHead(938008)
	StreamComposer:writeStr(info,#info)
	writeMsgTail()
end
--============================
--938009 删除成员
--============================
--guids 被删除成员的guid
--============================
SendMsg[938009] = function(guids)
	writeMsgHead(938009)
	StreamComposer:writeInt(guids)
	writeMsgTail()
end
--=============================
--938010 解散公会
--=============================
SendMsg[938010] = function()
	writeHeadOnlyMsg(938010)
end
--=============================
--938012 获取全服公会排位
--pageIdx 当前获取的页码
--=============================
SendMsg[938012] = function(pageIdx)
	writeMsgHead(938012)
	StreamComposer:writeInt(pageIdx)
	writeMsgTail()
end
--=============================
--938013 领取公会内部奖励
--=============================
SendMsg[938013] = function()
	writeHeadOnlyMsg(938013)
end
--============================
--938014 查询某帐号所属分会摘要信息
--============================
SendMsg[938014] = function (user_guid)
	writeMsgHead(938014)
	StreamComposer:writeInt(user_guid)
	writeMsgTail()
end
--=============================
--938015 模糊查找公会
--clubName
--=============================
SendMsg[938015] = function (clubName)
	writeMsgHead(938015)
	StreamComposer:writeStr(clubName, #clubName)
	writeMsgTail()
end
--=============================
--938016 搜索页面默认显示公会
--=============================
SendMsg[938016] = function()
	writeHeadOnlyMsg(938016)
end

--=============================
--939002 英雄主装备升级
--heroid 英雄ID
--=============================
SendMsg[939002]=function(heroid)
	writeMsgHead(939002)
	StreamComposer:writeInt(heroid)
	writeMsgTail()
end
--=============================
--939003 英雄主装备品质升级
--heroid 英雄ID
--=============================
SendMsg[939003]=function(heroid)
	writeMsgHead(939003)
	StreamComposer:writeInt(heroid)
	writeMsgTail()
end
--=============================
--939004 装备附属装备
--heroid 英雄id
--equipos 装备位置
--equipid 换上的装备
--flag 保留标识， 1保留 0 分解
--=============================
SendMsg[939004]=function(heroid,equipos,equipid,flag)
	writeMsgHead(939004)
	StreamComposer:write(heroid,equipos,equipid,flag)
	writeMsgTail()
end
--=============================
--939005 卸下附属装备
--heroid 英雄id
--equipos 装备位置
--flag 保留标识， 1保留 0 分解
--=============================
SendMsg[939005]=function(heroid,equipos,flag)
	writeMsgHead(939005)
	StreamComposer:write(heroid,equipos,flag)
	writeMsgTail()
end
--=============================
--939006 附属装备升级
--heroid 装备所属英雄
--equipPos 装备位置
--=============================
SendMsg[939006]=function(heroid,equipPos)
	writeMsgHead(939006)
	StreamComposer:write(heroid,equipPos)
	writeMsgTail()
end
--=============================
--939007 分解装备
--equipId 装备ID
--=============================
SendMsg[939007]=function(equipId)
	writeMsgHead(939007)
	StreamComposer:writeInt(equipId)
	writeMsgTail()
end
--=============================
--939008 一键分解一级装备
--=============================
SendMsg[939008]=function()
	writeHeadOnlyMsg(939008)
end

--=============================
--9310001 刷新挖掘日志任务列表
--=============================
SendMsg[9310001]=function(today_taskid)
	writeMsgHead(9310001)
	writeArrToMsg(today_taskid,1)
	writeMsgTail()
end
--=============================
--9310002 更新挖掘日志任务
--=============================
SendMsg[9310002]=function(tidList,paramList)
	writeMsgHead(9310002)
	writeArrToMsg(paramList,1)
	writeArrToMsg(tidList,1)
	writeMsgTail()
end
--=============================
--9310003 领取奖励
--=============================
SendMsg[9310003]=function(tid)
	writeMsgHead(9310003)
	StreamComposer:writeInt(tid)
	writeMsgTail()
end

--=============================
--9311001 搜索对战公会
--=============================
SendMsg[9311001]=function()
	writeHeadOnlyMsg(9311001)
end
--=============================
--9311002 锁定公会战指定坑道(锁定目标)
--def_guid: 公会战防御玩家GUID
--=============================
SendMsg[9311002]=function(def_guid,cbwid)
	writeMsgHead(9311002)
	StreamComposer:write(def_guid,cbwid)
	writeMsgTail()
end
--=============================
--9311003 解锁公会战指定坑道(解锁目标)
--=============================
SendMsg[9311003]=function()
	writeHeadOnlyMsg(9311003)
end
--=============================
--9311004 结束对指定坑道的攻击(1V1战斗结束)
--bp 战斗数据
--=============================
SendMsg[9311004]=function(bp)
    writeCryptMsgHead(9311004) 
	--被击破的矿车
	writeArrToMsg(bp.collector,1)
	--星星数量，补给值，开始时间，结束时间，总帧数，
	StreamComposer:write(bp.stars, bp.consume,bp.startTime,bp.endTime,bp.frameCnt)
	--英雄进入帧
	writeArrToMsg(bp.heroEnterFrame,1)
	--英雄激活帧
	writeArrToMsg(bp.heroCreatedFrame,1)
	--英雄技能使用帧
	writeSkillUsageToMsg(bp.skillUsageFrame)
	writeCryptMsgTail()
end
--=============================
--9311007 请求公会战录像摘要
--cbwid 公会战ID
--=============================
SendMsg[9311007]=function(cbwid)
	writeMsgHead(9311007)
	StreamComposer:writeInt(cbwid)
	writeMsgTail()
end

--===========================
--9311008 请求公会战录像信息明细
--===========================
--idx: 录像ID
--===========================
SendMsg[9311008] = function(idx)
	writeMsgHead(9311008)
	StreamComposer:writeInt(idx)
	writeMsgTail()
end
--===========================
--9311009 开始公会战单挑
--===========================
--idx: 录像ID
--===========================
SendMsg[9311009] = function()
	writeHeadOnlyMsg(9311009)
end
--===========================
--9311010 请求公会战数据
--===========================
--cbwid: 公会战ID
--===========================
SendMsg[9311010]=function(cbwid)
	writeMsgHead(9311010)
	StreamComposer:writeInt(cbwid)
	writeMsgTail()
end
--============================
--9312001 排行榜奖励
--============================
SendMsg[9312001] = function(msgid)
	writeMsgHead(9312001)
	StreamComposer:writeInt(msgid)
	writeMsgTail()
end
--============================
--9313001 创建探险队
--heroid :参加探险队英雄id
--catcap :英雄战斗力
--content：招募玩家信息
--============================
SendMsg[9313001] = function(heroid,atkcap,content)
    content = content or TxtList.welcomeToTeam
	writeMsgHead(9313001)
	StreamComposer:write(heroid,atkcap)
	StreamComposer:writeStr(content,#content)
	writeMsgTail()
end
--============================
--9313002 查看探险队
--============================
SendMsg[9313002] = function(tid)
	writeMsgHead(9313002)
	StreamComposer:writeInt(tid)
	writeMsgTail()
end
--============================
--9313003 加入探险队
--============================
SendMsg[9313003] = function(tid,heroid,atkcap)
	writeMsgHead(9313003)
	StreamComposer:write(tid,heroid,atkcap)
	writeMsgTail()
end
--============================
--9313004 探险队到期
--============================
SendMsg[9313004] = function(tid)
	writeMsgHead(9313004)
	StreamComposer:writeInt(tid)
	writeMsgTail()
end
--=============================
--9313005 匹配探险队
--bpMin:战斗力匹配上限
--bpMax:战斗力匹配下限
--=============================
SendMsg[9313005] = function(bpMin,bpMax)
	writeMsgHead(9313005)
	StreamComposer:write(bpMin,bpMax)
	writeMsgTail()
end
--==============================
--9313006 防御探险队战斗结束
--tid ：探险队id
--bp：探险队战力
--stars：探险队获得星星数
--==============================
SendMsg[9313006] = function(tid,bp,stars)
	writeCryptMsgHead(9313006)
	StreamComposer:write(tid,bp,stars)
	writeCryptMsgTail()
end
--==============================
--9313007 英雄已归队信息
--heroinfo--归队的英雄ID列表
--herolist --归队的英雄收益
--==============================
SendMsg[9313007] = function(heroinfo,herolist)
	local gainRes={}
	local gainHeroMsg={}
	local gainEquip = {}
	for key,heroAward in pairs(herolist) do
		if heroAward.awardRes then
			local valnum = heroAward.awardRes[3] or 0
			local awardtype = heroAward.awardRes[1] or 0
			local subtype = heroAward.awardRes[2] or 0
			if awardtype == 1 then
				local cointype = KVariantList.coinType[subtype]
				gainRes[cointype] = (gainRes[cointype] or 0 ) + valnum
			elseif awardtype == 2 then
				gainHeroMsg[subtype] = (gainHeroMsg[subtype] or 0) + valnum
			elseif awardtype == 3 then
				table.insert(gainEquip,equipFuncs.getSubEquipId(subtype,valnum,equipFuncs.getSubEquipCfg(subtype,"quality")))
			end
		end
	end
	writeCryptMsgHead(9313007) 
	--归队的英雄列表
	writeArrToMsg(heroinfo,1)
	--获取的资源
	writeGainResToMsg(gainRes)
	--获取的英雄消息
	writeHtToMsg(gainHeroMsg)
	--获取的设备
	writeArrToMsg(gainEquip,1)
	writeCryptMsgTail()
end

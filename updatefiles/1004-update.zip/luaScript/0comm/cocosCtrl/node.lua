local __cocosnode={}
function __cocosnode.egRunAction(obj,action,callback)
    if not callback then obj._egObj:runAction(action) return end

    obj._egObj:runAction(CCSequence:createWithTwoActions(action, CCCallFunc:create(callback)))
end
function __cocosnode.egEnableAnchor(obj)
    obj._egObj:ignoreAnchorPointForPosition(false)
end

function __cocosnode.egGetAnchorPoint(obj)
    return obj._egObj:getAnchorPoint()
end

function __cocosnode.egSetAnchorPoint(obj,x,y)
    obj._egObj:setAnchorPoint(ccp(x,y))
end

function __cocosnode.egAnchorPoint(obj,x,y)
    obj._egObj:setAnchorPoint(ccp(x,y))
end

function __cocosnode.egSetVisible(obj,visible)
    obj._egObj:setVisible(visible)
end
function __cocosnode.egAddChild(obj,child,zorder,tag)

    if zorder == nil and tag ==nil then
        obj._egObj:addChild(child)
    elseif tag == nil then
        obj._egObj:addChild(child,zorder)
    else
        if obj._egObj then
            obj._egObj:addChild(child,zorder,tag)
        end
    end
end
--����ǰ�������Ϊ�ӽڵ����ӵ�ָ������
--parent ���ڵ�
function __cocosnode.egAttachTo(obj,parent,zorder,tag)
    parent:egAddChild(obj._egObj,zorder,tag)
end

function __cocosnode.egSetPos(obj,x,y)
    obj._egObj:setPosition(ccp(x, y))
end

function __cocosnode.egSetPosition(obj,x,y)
    obj._egObj:setPosition(ccp(x, y))
end
function __cocosnode.egGetPosX(obj)
    return obj._egObj:getPositionX()
end
function __cocosnode.egGetPosY(obj)
    return obj._egObj:getPositionY()
end
function __cocosnode.egPosInNode(obj,x,y)
    return obj._egObj:convertToNodeSpace(ccp(x,y))
end
function __cocosnode.egRemoveChild(obj,child)

    obj._egObj:removeChild(child,true)
end

function __cocosnode.egRemoveSelf(obj)

    local parent = obj._egObj:getParent()
    if parent ~= nil then
        parent:removeChild(obj._egObj,true)
    end
    obj._egObj = nil

end

function __cocosnode.egRemoveChildByTag(obj,tag)
    if obj._egObj:getChildByTag(tag) then obj._egObj:removeChildByTag(tag,true) end
end


function __cocosnode.egSetContentSize(obj,width,height)
    obj._egObj:setContentSize(CCSizeMake(width,height))
    obj.width = width
    obj.height = height
end
function __cocosnode.egGetContentSize(obj)
    return obj._egObj:getContentSize()
end
function __cocosnode.egGetTag(obj)
    return obj._egObj:getTag()
end

function __cocosnode.egSetTag(obj,tag)
    obj._egObj:setTag(tag)
end
function __cocosnode.egSetScale(obj,val)
    obj._egObj:setScale(val)
end
function __cocosnode.egSetScaleX(obj,val)
    obj._egObj:setScaleX(val)
end
function __cocosnode.egSetScaleY(obj,val)
    obj._egObj:setScaleY(val)
end
function __cocosnode.egPlayAnima(obj, animaName, times, rate)--{{{
    local anima = graphicLoader.getAnimation(animaName)
    local orgUnitDelay = graphicLoader.getOrigUnitDelay(animaName)
    anima:setRestoreOriginalFrame(true)
    anima:setDelayPerUnit((1 / (rate or 1)) * orgUnitDelay)
    local animate = CCAnimate:create(anima)
    obj._egAnima = CCRepeat:create(animate, times or 1000000)
    obj._egObj:runAction(obj._egAnima)
end--}}}

function __cocosnode.egGetAnimaDuration(obj, animaName)--{{{
    local anima = graphicLoader.getAnimation(animaName)
    if not anima then return 0 end
    return anima:getDuration()
end--}}}

function __cocosnode.egStopAnima(obj)--{{{
    if obj._egAnima and obj._egObj then
        obj._egObj:stopAction(obj._egAnima)
        obj._egAnima = nil
        obj._lastAnimaName = nil
    end
end--}}}

function __cocosnode.egNode(obj)--{{{
    return obj._egObj
end--}}}

function __cocosnode.egOn(obj, dur)--{{{
    local fi = CCFadeIn:create(dur or 1)
    obj._egObj:runAction(fi)
end--}}}

function __cocosnode.egOff(obj, dur)--{{{
    local fo = CCFadeOut:create(dur or 1)
    obj._egObj:runAction(fo)
end--}}}
function __cocosnode.egTo(obj, dur,dlt)--{{{
    local fo = CCFadeTo:create(dur or 1, 255*(dlt or 1))
    obj._egObj:runAction(fo)
end--}}}
function __cocosnode.egRotate(obj, dur, dlt)--{{{
    local ro = CCRotateBy:create(dur or 1, dlt or 1)
    obj._egObj:runAction(ro)
end--}}}

function __cocosnode.egScale(obj, dur, factor)--{{{
    local st = CCScaleTo:create(dur or 1, factor or 1)
    obj._egObj:runAction(st)
end--}}}

function __cocosnode.egSkew(obj, dur, xfactor, yfactor)--{{{
    local st = CCSkewTo:create(dur or 1, xfactor or 1, yfactor or 1)
    obj._egObj:runAction(st)
end--}}}

function __cocosnode.egJumpTo(obj,dur,pos_x,pos_y,height,times)
	local jumpto =CCJumpTo:create(dur,ccp(pos_x,pos_y),height,times)
	obj._egObj:runAction(jumpto)
end

EG_ACTION_ON     = 1
EG_ACTION_OFF     = 2
EG_ACTION_ROTATE = 3
EG_ACTION_SCALE  = 4
EG_ACTION_SKEW     = 5


function __cocosnode.egExecAction(obj, atype, seq, notStopLast)--{{{
    atype = atype or 1
    local array = CCArray:create()
    local idx = 1
    local len = #seq
    while idx <= len do
        local actionName = seq[idx]
        if actionName == EG_ACTION_ON then
            array:addObject(CCFadeIn:create(seq[idx + 1]))
            idx = idx + 2 --skip name and dur
        elseif actionName == EG_ACTION_OFF then
            array:addObject(CCFadeOut:create(seq[idx + 1]))
            idx = idx + 2
        elseif actionName == EG_ACTION_SCALE then
            array:addObject(CCScaleTo:create(seq[idx + 1], seq[idx + 2]))
            idx = idx + 3
        elseif actionName == EG_ACTION_SKEW then
            array:addObject(CCSkewTo:create(seq[idx + 1], seq[idx + 2], seq[idx + 3]))
            idx = idx + 4
        elseif actionName == EG_ACTION_ROTATE then
            array:addObject(CCRotateBy:create(seq[idx + 1], seq[idx + 2]))
            idx = idx + 3
        else
            return
        end
    end
    if not notStopLast then
        obj:egStopExecAction()
    end
    if atype == 1 then
        obj._egLastAction = CCSequence:create(array)
    elseif atype == 2 then
        obj._egLastAction = CCSpawn:create(array)
    end
    obj._egObj:runAction(obj._egLastAction)
end--}}}

function __cocosnode.egStopExecAction(obj)--{{{
    if obj._egLastAction then
        obj._egObj:stopAction(obj._egLastAction)
        obj._egLastAction = nil
    end
end--}}}
function __cocosnode.egBindUpdateWithPriorityLua(obj,callback)
    local function update(delta)
        if callback then callback(delta) end
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  obj._egObj:unscheduleUpdate() end
    end
    obj._egObj:scheduleUpdateWithPriorityLua(update, 0)
    obj._egObj:registerScriptHandler(exitFuns)
end
function __cocosnode.egUnbindUpdateWithPriorityLua(obj)
    obj._egObj:unscheduleUpdate()
end
function __cocosnode.egBindSchedule(obj,func,sec,pasued)
    if not sec then sec = 0 end
    if not pasued then pasued = false end
    obj._egSchedulePtr = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(func, sec, pasued)
end
function __cocosnode.egUnBindSchedule(obj)
    if obj._egSchedulePtr then
        CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(obj._egSchedulePtr )
    end
end
function __cocosnode.egBindUpdate(obj,updateFuns,clearFuns)--{{{
    local function UpdateHandler(eventType)
        if eventType == "enter" then
            if updateFuns then
                obj._eghandler = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(updateFuns, 0, false)
            end
        elseif eventType == "exit" then
            if clearFuns then  clearFuns() end
            if obj._eghandler then
                CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(obj._eghandler )
            end
        end
    end
    obj._egObj:registerScriptHandler(UpdateHandler)
end--}}}
function __cocosnode.egUnbindUpdate(obj)
    if obj._eghandler then
        CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(obj._eghandler )
    end
end
function __cocosnode.egOnExit(obj,callback)
    local function exitFuns(eventType)
        if eventType == "exit" then
            if callback then  callback() end
        end
    end
    obj._egObj:registerScriptHandler(exitFuns)
end
function __cocosnode.egOnEnter(obj,callback)
    local function exitFuns(eventType)
        if eventType == "enter" then
            if callback then  callback() end
        end
    end
    obj._egObj:registerScriptHandler(exitFuns)
end
function __cocosnode.egOnEnterAndExit(obj,enterFuns,exitFuns)
	local function scriptFuns(eventType)
        if eventType == "enter" then
            if enterFuns then  enterFuns() end
		elseif eventType == "exit" then
			 if exitFuns then  exitFuns() end
        end
    end
    obj._egObj:registerScriptHandler(scriptFuns)
end
CocosNode={}
function CocosNode.install(obj)
    table_aux.unpackTo(__cocosnode, obj)
    obj._eghandler = nil
    obj.width = obj._egObj:getContentSize().width
    obj.height = obj._egObj:getContentSize().height
end


CocosWidget=class("CocosWidget" )
CocosWidget.__index = CocosWidget
function CocosWidget.extend(target)
    local t = {}
    tolua.setpeer(target, t)
    setmetatable(t, CocosWidget)
    return target
end
function CocosWidget.new(jsonFile)
	local widget = CocosWidget.extend( GUIReader:shareReader():widgetFromJsonFile(jsonFile))
	widget._egObj =widget
    CocosNode.install(widget)
    WNode.install(widget)
	BaseProp.install(widget)
    InnerProp.install(widget)
	return widget
end 
function CocosWidget:className()
	return self.__cname
end
function CocosWidget:egGetWidgetByName(widgetName)
    if not widgetName then return self end
	if self:getName() == widgetName then return self end
    local widget = self:getChildByName(widgetName)
    if widget then return widget end
    
    local function findChild(parent,name)
        local childArray = parent:getChildren()
        local count = parent:getChildrenCount()
        if count <= 0 then return nil end
        for idx = 0,count-1 do  
            local item = tolua.cast(childArray:objectAtIndex(idx),"Widget")
            local child = item :getChildByName(name)
            if child then return child end
            local child = findChild(item,name)
            if child then return child end
        end
        return nil
    end
    widget = findChild(self,widgetName)
    return widget
end
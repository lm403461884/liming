Scene=class("Scene")
Scene.__index = Scene

function Scene.extend(target)
    local t = {}
    tolua.setpeer(target, t)
    setmetatable(t, Scene)
    return target
end
function Scene.new()
	return Scene.extend(CCScene:create())
end

function Scene:egRun()
	SceneManager:run(self)
end
function Scene:egReplace()
	SceneManager:run(self)
end
function Scene:className()
	return self.__cname
end
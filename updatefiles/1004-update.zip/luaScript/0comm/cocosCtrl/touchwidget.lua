
local __touchwidget = {}
function __touchwidget.egAddWidget(obj,widget)
    obj._egObj:addWidget(widget)
end
function __touchwidget.egGetWidgetByName(obj,widgetName)
    if not widgetName then 
        return obj._widget 
    end
    return obj._egObj:getWidgetByName(widgetName)
end
function __touchwidget.egWidget(obj)
    return  obj._widget
end
function __touchwidget.egChangeWidgetWithFile(obj,jsonFile,outSec,callback)
    local function fadeOutCallback()
        obj._egObj:removeWidget(obj._widget)
        obj._widget = GUIReader:shareReader():widgetFromJsonFile(jsonFile)
        obj._egObj:addWidget( obj._widget)
        if callback then callback() end
    end
    if outSec then
        local callFunc = CCCallFunc:create(fadeOutCallback)
        local fadeout = CCFadeOut:create(outSec)
        local action = CCSequence:createWithTwoActions(fadeout,callFunc )
        obj._widget:runAction(action)
    else
        fadeOutCallback() 
    end
end
TouchWidget={}
function TouchWidget.new(jsonFile)
    local obj = {}
    obj._egObj = TouchGroup:create()
    obj._widget = GUIReader:shareReader():widgetFromJsonFile(jsonFile)
    obj._egObj:addWidget( obj._widget)
    CocosNode.install(obj)
    TouchDelegate.install(obj)
    WNode.install(obj)
     table_aux.unpackTo(__touchwidget, obj) 
    return obj
end
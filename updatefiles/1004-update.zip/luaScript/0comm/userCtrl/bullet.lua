

Bullet={}

function Bullet.new(mtype,lv,idx)

	local obj = {}
	BaseProp.install(obj)
	InnerProp.install(obj)
	sprite.install(obj)

	local s_cfg = bullet_data.getConfig(mtype)
	local s_data = bullet_data.get(mtype,lv)
	for name,val in pairs(s_data) do
		obj:addprop(name,val)
	end

	obj:addprop('mainType', 3)
	obj:addprop('type', mtype)
	obj:addprop("level", lv)
	obj:addprop('aiEntryName', s_cfg.aiEntryName) --string
	obj:addprop('skillNames', s_cfg.skillNames) --table
	obj:addprop("zorder", 0)
	obj:addprop("birthPlace", idx)
	obj:addprop('hp', obj:getprop('maxHP'))
	obj:addprop('graphName', s_cfg.graphList[s_data.graphLV])
	obj:egChangeFrame(string.format('%s_020201.png',s_cfg.graphList[s_data.graphLV]))
	ai_module.add(obj)

	return obj
end


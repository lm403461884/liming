local ktxtbgTag = 2
local kclipTag = 1
local __guildlayer = {}
function __guildlayer.init(obj)
	
	obj._clip = CCClippingNode:create()
	obj._clip:setInverted(true)
	obj._clip:setAlphaThreshold(0)
	obj:egAddChild(obj._clip,kclipTag,kclipTag)
	obj._bg = CCLayerColor:create(ccc4(0,0,0,100))
	obj._clip:addChild(obj._bg )
	
    local guitxt = GUIReader:shareReader():widgetFromJsonFile(obj._data.uisrc)
    local btnui = guitxt:getChildByName("clickArea")
    btnui:setVisible(false)
    local btnuisize = btnui:getSize()
    local sprite = CCScale9Sprite:create(ImageList.comm_yellow_oval)
	local ttf = CCLabelTTF:create()
	ttf:setContentSize(btnuisize)
	local btn = CCControlButton:create(ttf,sprite)
	local function callbackfuns()
	    obj:hide()
	    if GuildData[obj._idx][obj._subidx + 1] then 
	        local guildlayer = GuildLayer.new(obj._idx,obj._subidx + 1)
	        guildlayer:show()
	    else
	        if obj._data.action and EventList[obj._data.action] then EventList[obj._data.action]() end
        end
	end
	
	btn:addHandleOfControlEvent(callbackfuns,CCControlEventTouchUpInside)
	btn:setPosition(ccp(0,0))
	btn:setTouchPriority(obj._priority-1)
	
	local node = CCNode:create()
	node:addChild(btn)
	node:setPosition(btnui:getPositionX(),btnui:getPositionY())
	obj._clip:setStencil(node)
	
    obj:egAddChild(guitxt,1,1)
end
function __guildlayer.show(obj,owner)
    if owner then 
        obj:egAttachTo(owner,UILv.guidLayer,UILv.guidLayer)
    else
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(obj:egNode(),UILv.guidLayer,UILv.guidLayer) 
    end
end
 
function __guildlayer.hide(obj)
    obj:egRemoveSelf()
end
GuildLayer={}
function GuildLayer.new(idx,subidx)
    local obj = {}
    table_aux.unpackTo(__guildlayer, obj)
    LayerColor.install(obj,ccc4(0,0,0,0))
    obj._priority = TouchLv.guidLayer
    obj._idx = idx
    obj._subidx = subidx
    obj._data = GuildData[obj._idx][obj._subidx]
    obj:swallowTouch(obj._priority)
    obj:init()
	return obj
end


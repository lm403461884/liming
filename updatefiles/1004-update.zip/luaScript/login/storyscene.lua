local function creator(showidx)
	local scene =  Scene.new() 
	local function callback(eventType)
		  if eventType == "enter" then
			local layer = StoryLayer.new(showidx)
			scene._baseWidget = layer
			scene:addChild(layer:egNode())
		  end
	end
	scene:registerScriptHandler(callback)
	return scene
end
StoryScene = class("StoryScene",creator)
StoryScene.__index = StoryScene
local kBtnPlay = "btn_play"
local kBtnQuit = "btn_quit"
local kBtnCancel = "btn_cancel"
local kImgBg = "img_bg"
local __quitlayer={}
--�жϰ�ť��Դ�Ƿ��Ѿ����أ�û�м��ص�����ȼ���ͼƬ��Դ
local function __loadBtnImgs()
    local framecache = CCSpriteFrameCache:sharedSpriteFrameCache()
    local framebtn = framecache:spriteFrameByName(ImageList.btn_brown_n)
    if not framebtn then
        ZipUtils:setPvrKey(kPvrKey[1],kPvrKey[2],kPvrKey[3],kPvrKey[4])
        graphicLoader.loadFrameWithFile(KVariantList.btnImgList,KVariantList.btnPvrPath) --����ͼƬ��Դ
    end
end
function __quitlayer.bindPlayListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnPlay,nil,nil,touchEnded,nil)
end
function __quitlayer.bindQuitListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        CCDirector:sharedDirector():endToLua()
    end
    obj:egBindTouch(kBtnQuit,nil,nil,touchEnded,nil)
end
function __quitlayer.bindCancelListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnded,nil)
end
function __quitlayer.showWithAction(obj)
    local widget = obj:egGetWidgetByName(kImgBg)
    widget:setScale(0)
    local scaleto = CCScaleTo:create(0.2,1)
    local backout = CCEaseBackOut:create(scaleto)
    widget:runAction(backout)
end
function __quitlayer.hideWithAction(obj)
    AccountHelper:unlock(kStateQuit) --�����˳���ʾ����
    local widget = obj:egGetWidgetByName(kImgBg)
    local scaleto = CCScaleTo:create(0.1,0)
    local function callback()
        obj:egRemoveSelf()
    end
    local callfunc = CCCallFunc:create(callback)
    widget:runAction(CCSequence:createWithTwoActions(scaleto,callfunc))
end
QuitLayer={}
function QuitLayer.new()
    __loadBtnImgs()--���ذ�����Դ
    local obj =  TouchWidget.new(JsonList.quitLayer)
    table_aux.unpackTo(__quitlayer, obj)
    obj:bindPlayListener()
    obj:bindQuitListener()
    obj:bindCancelListener()
   return obj
end
function showQuitPrompt()
    AccountHelper:lock(kStateQuit) --�����˳���ʾ����
    local layer = QuitLayer.new()
    layer:showWithAction()
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.quitLayer,UILv.quitLayer)
end
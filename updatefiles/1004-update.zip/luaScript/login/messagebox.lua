
MessageBox=class("MessageBox",function() return  TouchWidget.new(JsonList.msglayer) end)
MessageBox.__index = MessageBox
function MessageBox:className()
	return MessageBox.__cname
end
--msg ��Ҫ��ʾ����Ϣ
--sceneClass ����functionΪ�ص�����,����tableΪ��ת����
function MessageBox.show(msg,sceneClass)
	local msgbox = MessageBox.new()
	local kOffsetY = 40
	local maxW = 610
	local btnyes = tolua.cast(msgbox:egGetWidgetByName("Button_ok"),"Button")
	local btnno = tolua.cast(msgbox:getWidgetByName("Button_cancel"),"Button")
	local context =  tolua.cast(msgbox:egGetWidgetByName("Label_content"),"Label")
	local title = msgbox:getWidgetByName("Label_title")
	local imgbg = msgbox:egGetWidgetByName("img_dialog_bg")
	if not msg then msg="ok" end
	btnno:setVisible(false)
	btnno:setEnabled(false)
	title:setVisible(false)
	context:setText(msg)
	context:setPosition(ccp(context:getPositionX(),context:getPositionY() + 40))
	 btnyes:setPosition(ccp(0,btnyes:getPositionY()))
	local txtlen = context:getSize().width
	if txtlen > maxW then
		local rows = math.ceil(txtlen/maxW)
		local rowmod = txtlen%maxW
		if rowmod > maxW*2/3 and rows > 3 then rows = rows + 1 end
		local cellH = rows*context:getSize().height

		context:setSize(CCSizeMake(maxW,cellH))
		context:ignoreContentAdaptWithSize(false)
		local addH = math.max((rows-2),0)*cellH
		
		imgbg:setSize(CCSizeMake(imgbg:getSize().width,imgbg:getSize().height + addH))
		btnyes:setPosition(ccp(btnyes:getPositionX(),btnyes:getPositionY() - addH/2))
		context:setPosition(ccp(context:getPositionX(),context:getPositionY() + addH/2))
	end
	
	 local function touchCallback(sender, eventType)
		if eventType == 1 then
			sender:setTouchEnabled(false)
			SoundHelper.playEffect(SoundList.click_shop_goods)
        elseif eventType == 2 then
			FloatNode.popLayer()
            if type(sceneClass) == "function" then
				sceneClass()
			elseif type(sceneClass) == "table" then
				SceneManager:show(sceneClass)
			end
		elseif eventType == 3 then
			sender:setTouchEnabled(true)
        end
    end
    btnyes:addTouchEventListener(touchCallback)
	FloatNode.pushLayer(msgbox)
end

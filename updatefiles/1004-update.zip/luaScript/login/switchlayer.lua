
local kPanelLast = "panel_last"
local kLblLastSer = "lbl_last_ser"
local kLblLastState = "lbl_last_state"
local kLblLastLog = "lbl_last_log"
local kListArea = "area_list"

local kBtnEnter = "btn_enter"
local kPanelCur = "panel_cur"
local kPanelSelected = "panel_selected"
local kLblCurSer = "lbl_cur_ser"
local kLblCurState = "lbl_cur_state"
local kLblCurSwitch = "lbl_cur_switch"
local kLblVersion = "lbl_version"
local kCntPerRow = 3
local kMinRowCnt = 5
local kCellW = 400
local kCellH = 110
local kBlockState = 4
local kImgHeader = "img_header"
local kImgLoad = "img_load"
local kLblErr = "lbl_err"

SwitchLayer = class("SwitchLayer",function() return  TouchWidget.new(JsonList.switchLayer) end)
SwitchLayer.__index = SwitchLayer
function SwitchLayer:create()
	local layer = SwitchLayer.new()
	local function callback(eventType)
        if eventType == "enter" then
			layer:showBlankUI()
			layer:bindSelectedPanelListener()
			layer:bindEnterListener()
			layer:showVersionNum()
			layer:onLoginSucceed()
			layer:onLogserSucceed()
			layer:onLogserError()
			layer:onServerDownLoaded()
			layer:onVerNotMatch()
			layer:onDSFingerError()
			layer:onAcctDownLoad()
			layer:onClubDownLoad()
			layer:onClubWarDownLoad()
			layer:onGSLoginError()
			layer:onBeenAttack()
			layer:onForbidLogin()
			SDKHelper:login()
		elseif eventType == "exit" then
			FloatNode.unbindEvent(CLTEvent.LoginSucceed)
			FloatNode.unbindEvent(CLTEvent.LogserSucceed)
			FloatNode.unbindEvent(CLTEvent.LogserError)
			FloatNode.unbindEvent(CLTEvent.CServerDownloaded)
			FloatNode.unbindEvent(CLTEvent.CVerNotMatch)
			FloatNode.unbindEvent(CLTEvent.CDSFingerError)
			FloatNode.unbindEvent(CLTEvent.CAcctDownLoad)
			FloatNode.unbindEvent(CLTEvent.CClubDownLoad)
			FloatNode.unbindEvent(CLTEvent.CClubWarDownLoad)
			FloatNode.unbindEvent(CLTEvent.CGSLoginError)
			FloatNode.unbindEvent(CLTEvent.CBeenAttack)
			FloatNode.unbindEvent(CLTEvent.CForbidLogin)
        end
    end
	layer:registerScriptHandler(callback)
	return layer
end

function SwitchLayer:showBlankUI()
	self:hideLoadAnime()
	self:egHideWidget(kPanelCur)
	self:egHideWidget(kPanelSelected)
	self:egHideWidget(kBtnEnter)
	self:egHideWidget(kPanelLast)
	self:egHideWidget(kListArea)
	self:egHideWidget(kImgLoad)
	self:egHideWidget(kLblErr)
end
--获取服务器列表等待界面
function SwitchLayer:showSerLoadingUI()
	self:egHideWidget(kPanelCur)
	self:egHideWidget(kPanelSelected)
	self:egHideWidget(kBtnEnter)
	self:egShowWidget(kPanelLast)
	self:egShowWidget(kListArea)
	self:egHideWidget(kLblErr)

    self:showLoadAnima()

	self:egHideWidget(kLblLastState)
	self:egHideWidget(kLblLastLog)
	self:egHideWidget(kLblLastSer)
end
--在线更新界面
function SwitchLayer:showUpdatingUI()
	self:egHideWidget(kPanelCur)
	self:egHideWidget(kPanelSelected)
	self:egHideWidget(kBtnEnter)
	self:egHideWidget(kPanelLast)
	self:egHideWidget(kListArea)
	self:egShowWidget(kLblErr)
    self:showLoadAnima()
end
--服务器选择界面
function SwitchLayer:showServerSwitchUI()
	self:hideLoadAnime()
	self:egHideWidget(kPanelCur)
	self:egHideWidget(kPanelSelected)
	self:egHideWidget(kBtnEnter)
	self:egShowWidget(kPanelLast)
	self:egShowWidget(kListArea)
	self:egHideWidget(kLblErr)

	self:egShowWidget(kLblLastState)
	self:egShowWidget(kLblLastLog)
	self:egShowWidget(kLblLastSer)
end
--确认服务器界面
function SwitchLayer:showConfirmServerUI()
	self:hideLoadAnime()
	self:egShowWidget(kPanelSelected)
	self:egShowWidget(kBtnEnter)
	self:egShowWidget(kPanelCur)
	self:egHideWidget(kPanelLast)
	self:egHideWidget(kListArea)
	self:egHideWidget(kLblErr)
end
--进入游戏等待界面
function SwitchLayer:showEnterGameUI()
	self:egHideWidget(kPanelCur)
	self:egHideWidget(kPanelSelected)
	self:egHideWidget(kBtnEnter)
	self:egHideWidget(kPanelLast)
	self:egHideWidget(kListArea)
	self:egShowWidget(kLblErr)

    self:showLoadAnima()

end
--中心加载动画－开
function SwitchLayer:showLoadAnima()
	local imgWidget = self:egGetWidgetByName(kImgLoad)
	imgWidget:setVisible(true)
	imgWidget:setEnabled(true)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
	imgWidget:stopAllActions()
    imgWidget:runAction(repeatforever)
end
--中心加载动画－关
function SwitchLayer:hideLoadAnime()
	local imgWidget = self:egGetWidgetByName(kImgLoad)
    imgWidget:stopAllActions()
	imgWidget:setVisible(false)
end
function SwitchLayer:doConnToGs()
	local puid = SDKHelper:getHOUID()
	local sid = self._selectedSer.sid
	local pflag = SDKConfig.getFlag()
	self:egSetLabelStr(kLblErr,dsLoading)
	DBHelper.setLastLogServer(puid,sid)
	self._acct_ready = false
    self._club_read = false
    self._war_ready = false
	local socket = SocketHelper.createGSSocket()
	if socket then
		local function callback()
			if socket:isReady() then
				self:egUnbindWidgetUpdate(kImgHeader)
				if socket:isValid() then
					SocketHelper.setGSConn(socket:getHandle())
					if self._selectedSer.guid then
						SendMsg[931001](self._selectedSer.sid,self._selectedSer.guid)
					else
						SendMsg[931002](puid,self._selectedSer.sid,pflag)
					end
				else
					MessageBox.show(TxtList.dsLoadError,function() self:doConnToGs() end)
				end
				socket:destory()
			end
		end
		self:egBindWidgetUpdate(kImgHeader,callback)
	else
		MessageBox.show(TxtList.dsLoadError,function() self:doConnToGs() end)
	end   
end
function SwitchLayer:isValidNickName()
	local nickName = AcctManager:getParam("nickName")
    if not nickName then return false end
    if string.len(nickName)== 0 then return false end
    if nickName == AcctManager:getParam("user") then return false end
    nickName = HOAux:hexstr2str(nickName)
	AcctManager:setParam("nickName",nickName)
    if string.len(nickName)== 0 then return false end
    return true
end
function SwitchLayer:checkToStart()
	if self._acct_ready  and self._club_read and self._war_ready then
		AppScriptHandler:setEnterBackgroundHandler(function() NotifyHelper.start() end)
		AppScriptHandler:setEnterForegroundHandler( function() NotifyHelper.stop() end)
		if  not self:isValidNickName() then
			showNickNameLayer()
        else
            SDKHelper:submitServerInfo()
            SDKHelper:submitLoginGameRole()
			TDHelper.setAccountName(AcctManager:getParam("nickName"))
			if AcctManager:getHashParam("guideList",GuideScene.def.kGAtkScene) then --PVE关卡引导没走完
				local scene = GAtkScene.new()
				scene:egReplace()
			else
				local scene = TownScene.new()
				scene:egReplace()
			end
        end
	end
end
--=====================================================================
--回调事件
--=====================================================================
--平台登陆成功
function SwitchLayer:onLoginSucceed()
	local function eventCallback(msg)
		SDKHelper:saveUID()--记录登陆帐号
		self:downloadServerInfo()
	end
	FloatNode.bindEvent(CLTEvent.LoginSucceed,eventCallback)
end

--设置服务器ID成功
function SwitchLayer:onLogserSucceed()
	local function eventCallback(msg)
		self:doConnToGs()
	end
	FloatNode.bindEvent(CLTEvent.LogserSucceed,eventCallback)
end
--设置服务器ID失败
function SwitchLayer:onLogserError()
	local function eventCallback(msg)
		local function callback()
			self._selectedSer = nil
			self:showServerSwitchUI()
		end
		MessageBox.show(TxtList.sdkSerConnError,callback)
	end
	FloatNode.bindEvent(CLTEvent.LogserError,eventCallback)
end
--服务器列表获取成功
function SwitchLayer:onServerDownLoaded()
	local function eventCallback(msg)
		local pubinfo = SSHelper:getBeforeLoginInfo()
		if #pubinfo > 0 then
			showPubMsgBar(pubinfo) --弹出公告板
		end
		self:loadServerInfo() --上次登陆服务器不存在时，请玩家选择服务器
	end
	FloatNode.bindEvent(CLTEvent.CServerDownloaded,eventCallback)

end
--客户端版本不符
function SwitchLayer:onVerNotMatch()
	local function eventCallback(msg)
		DBHelper.setLatestVer(tonumber(msg))
		if SocketHelper.isWifiConnected() then
			self:downloadUpdateFiles()
		else
			local function callback2()
				SDKHelper:destroy()
				NotifyHelper.start()
				CCDirector:sharedDirector():endToLua()
			end
			ConfirmBox.show(TxtList.needsWifi,function() self:downloadUpdateFiles() end,callback2)
		end
	end
	FloatNode.bindEvent(CLTEvent.CVerNotMatch,eventCallback)
end
--目录服指纹检验不符
function SwitchLayer:onDSFingerError()
	local function eventCallback(msg)
		MessageBox.show(TxtList.dsFingerError,LogoScene)
	end
	FloatNode.bindEvent(CLTEvent.CDSFingerError,eventCallback)
end
--帐号数据获取成功
function SwitchLayer:onAcctDownLoad()
	local function eventCallback(msg)
		self._acct_ready = true
		self:checkToStart()
	end
	FloatNode.bindEvent(CLTEvent.CAcctDownLoad,eventCallback)
end

--公会数据获取成功
function SwitchLayer:onClubDownLoad()
	local function eventCallback(msg)
		self._club_read = true
		self:checkToStart()
	end
	FloatNode.bindEvent(CLTEvent.CClubDownLoad,eventCallback)
end
--公会战数据获取成功
function SwitchLayer:onClubWarDownLoad()
	local function eventCallback(msg)
		self._war_ready = true
		self:checkToStart()
	end
	FloatNode.bindEvent(CLTEvent.CClubWarDownLoad,eventCallback)
end
--登陆失败
function SwitchLayer:onGSLoginError()
	local function eventCallback(msg)
		--1 无效的分区
		--2 重复注册
		--3 指纹检验出错
		--4 登陆校验错误
		--5 分区错误
		MessageBox.show(TxtList.gsEnterError.."Error code "..msg,LogoScene)
	end
	FloatNode.bindEvent(CLTEvent.CGSLoginError,eventCallback)
end
--正在被攻打
function SwitchLayer:onBeenAttack()
	local function eventCallback(msg)
		self:showBlankUI()
		showBattleWaitLayer()
	end
	FloatNode.bindEvent(CLTEvent.CBeenAttack,eventCallback)
end
--封号
function SwitchLayer:onForbidLogin()
	local function eventCallback(msg)
		MessageBox.show(TxtList.forbidLogin,LogoScene)
	end
	FloatNode.bindEvent(CLTEvent.CForbidLogin,eventCallback)
end

--===============================================================
function SwitchLayer:getOrderedServer()
	local serList = SSHelper:getAreaInfo()
	local tb = {}
	for key,val in pairs(serList) do
		val.sid = key
		table.insert(tb,val)
	end
	table.sort(tb,function(a,b) return a.state < b.state end)
	return tb
end
--加载显示服务器分区列表
function SwitchLayer:loadServerInfo()
	self._sertable = self:getOrderedServer()
	self._loadCnt = 0
	self._totalCnt = #self._sertable
	self._totalRow = math.max(math.ceil(self._totalCnt/kCntPerRow),kMinRowCnt)
	self._loadRow = 0
	local scrollview = self:egGetScrollView(kListArea)
    local newh = self._totalRow * kCellH
    local size = scrollview:getSize()
    if newh > size.height then
		scrollview:setClippingEnabled(true)
        scrollview:setInnerContainerSize(CCSizeMake(size.width,newh))
    end
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if self._loadCnt >=  self._totalCnt then return end
            local innerContainer = scrollview:getInnerContainer()
            local posY = innerContainer:getPositionY()
            if (self._loadRow*kCellH) - posY  < innerContainer:getSize().height then
                self:addServerByRow(1,scrollview)
            end
        end
    end
    scrollview:addEventListenerScrollView(scrollEvent)
	self:addServerByRow(kMinRowCnt,scrollview)
	self._selectedSer = SSHelper:getLastLogServer()
	if self._selectedSer  then
		self:egSetLabelStr(kLblLastState,string.format("%s%s%s","(",TxtList.serState[self._selectedSer.state],")"))
		self:egSetLabelStr(kLblLastSer,self._selectedSer.name)
		self:bindLastPanelListener()
		self:loadSelectedServer()
	else
		self:showServerSwitchUI()
	end
end
function SwitchLayer:addServerByRow(rowcnt,scrollview)
	if self._loadCnt >= self._totalCnt then return end
	local cnt = rowcnt * kCntPerRow
	local startIdx = self._loadCnt + 1
	local endIdx = math.min(self._loadCnt + cnt,self._totalCnt)
	for idx = startIdx,endIdx do
		local row = math.ceil(idx/kCntPerRow)
		local col = (idx-1)%kCntPerRow
		local serinfo = self._sertable[idx]
		local item = SwitchItem.new(serinfo)
		local size = item:egNode():getSize()
		item:egSetPosition(kCellW * col,kCellH *(self._totalRow - row))
		scrollview:addChild(item:egNode())
		self:bindSwitchItemEvent(item)
		self._loadRow =  row
	end
	self._loadCnt = endIdx
end
function SwitchLayer:loadSelectedServer()
	self:showConfirmServerUI()
	self:egSetLabelStr(kLblCurState,string.format("%s%s%s","(",TxtList.serState[self._selectedSer.state],")"))
	self:egSetLabelStr(kLblCurSer,self._selectedSer.name)
	local color = KVariantList.serverColor[self._selectedSer.state]
	self:egSetWidgetColor(kLblCurSer,color)
	self:egSetWidgetColor(kLblCurState,color)
	self:egSetWidgetColor(kLblCurSwitch,color)
end
--点击上次登陆服务器
function SwitchLayer:bindLastPanelListener()
	local function touchEnded(sender)
		self._selectedSer = SSHelper:getLastLogServer()
		self:loadSelectedServer()
    end
    self:egBindTouch(kPanelLast,nil,nil,touchEnded,nil)
end
--点击本次需要登陆的服务器
function SwitchLayer:bindSwitchItemEvent(item)
	local function callback(sender)
		local serinfo = sender:getServerData()
		self._selectedSer = serinfo
		self:loadSelectedServer()
	end
	item:bindItemEvent(callback)
end
--切换选区事件
function SwitchLayer:bindSelectedPanelListener()
	local function touchEnded(sender)
		self._selectedSer = nil
		self:showServerSwitchUI()
	end
	self:egBindTouch(kPanelSelected,nil,nil,touchEnded,nil)
end
--进入游戏按钮
function SwitchLayer:bindEnterListener()
	local function touchEnded(sender)
		if self._selectedSer.state ~= kBlockState then
			SDKHelper:loginWithSid(self._selectedSer.sid)
			self:showBlankUI()
			self:showLoadAnima()
			self:showEnterGameUI()
			self:egSetLabelStr(kLblErr,string.format("%s %s",TxtList.dsConnecting,self._selectedSer.name))
		elseif self._selectedSer.tip then
			showLetterLayer(self._selectedSer.tip)
		end
	end
	self:egBindTouch(kBtnEnter,nil,nil,touchEnded,nil)
end
--从服务器获分区列表
function SwitchLayer:downloadServerInfo()
	self:showSerLoadingUI()
	local function connectFailCallBack()
		self:hideLoadAnime()
		--弹窗提示获取服务器列表失败
		MessageBox.show(TxtList.getServerError,function() self:downloadServerInfo() end)
	end
	local socket = SocketHelper.createDSSocket()
	if socket then
		local function callback()
			if socket:isReady() then
				self:egUnbindWidgetUpdate(kImgLoad)
				if socket:isValid() then
					SendMsg[981001](socket:getHandle())
				else
					connectFailCallBack()
				end
				socket:destory()
			end
		end
		self:egBindWidgetUpdate(kImgLoad,callback)
	else
		connectFailCallBack()
	end   
end
function SwitchLayer:handlError(msgcode)
	if msgcode == 3 or msgcode == 7  then --没有可以更新的版本
		self:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			SDKHelper:destroy()
			NotifyHelper.start()
			CCDirector:sharedDirector():endToLua()
		end
		MessageBox.show(TxtList.verError,callback)
	else --网络原因或其它原因造成的更新失败
		self:egUnbindWidgetUpdate(kImgHeader)
		MessageBox.show(TxtList.updateError,LogoScene)
	end
end
function SwitchLayer:formatVerCode(vernum,withSpace)
	local v1 = math.floor(vernum/1000)
	local v2 = math.floor(vernum%1000/100)
	local v3 = math.floor(vernum%100/10)
	local v4 = math.floor(vernum%10)
	if withSpace then
		return string.format("%d . %d . %d . %d",v1,v2,v3,v4)
	else
		return string.format("%d.%d.%d.%d",v1,v2,v3,v4)
	end

end
function SwitchLayer:activeUpdateTimer()
	local curVerTxt = ""
	local isCppChanged = false
	local verSize = 0
	local function update(delta)
		if UpdateEngine:hasNewMsg() then
			local msgtype,msgcode,exval1,exval2 = UpdateEngine:getNewMsg()
			--print(msgtype,"---",msgcode,"---",exval1,"---",exval2)
			if msgtype == 1 then --更新出错
				self:handlError(msgcode)
			elseif msgtype == 2 then --检查到版本更新
				self:egSetLabelStr(kLblErr,TxtList.updateMsg[2])
				print("get new ver")
			elseif msgtype == 3 then --开始下载
				print("start down load")
				curVerTxt = self:formatVerCode(msgcode)
				if exval2 > 0 then isCppChanged = true end
				verSize = string.format("%0.2f",exval1/1024)
				self:egSetLabelStr(kLblErr,string.format(TxtList.updateMsg[3],curVerTxt,verSize))
			elseif msgtype == 4 then --下载中
			    self:egSetLabelStr(kLblErr,string.format(TxtList.updateMsg[9],curVerTxt,verSize,msgcode,"%"))
			elseif msgtype == 5 then --下载结束
				print("down load end")
			elseif msgtype == 6 then --开始解压
				print("start un zip ")
				self:egSetLabelStr(kLblErr,string.format(TxtList.updateMsg[4],self:formatVerCode(msgcode)))
			elseif msgtype== 7 then --解压完结
				print("finish un zip ")
				self:egSetLabelStr(kLblErr,string.format(TxtList.updateMsg[5],self:formatVerCode(msgcode)))
				DBHelper.setGameVer(msgcode)
			elseif msgtype==8 then --更新完毕
                self:egUnbindWidgetUpdate(kImgHeader)
				print("update succ ")
				self:egSetLabelStr(kLblErr,TxtList.updateMsg[8])
				DBHelper.setLatestVer() --直接更新为与下载版本一致
				graphicLoader.clearAllRes()
				local filepath = "luaScript/HO.lua"
				package.loaded[filepath] = nil
				require(filepath)
				HOEntryHelper.init()
				SceneManager:replace(LogoScene)
				FloatNode.show()
			end
		end
	end
	self:egBindWidgetUpdate(kImgHeader,update)
end

function SwitchLayer:downloadUpdateFiles()
	self:showUpdatingUI()
	UpdateEngine:setStoragePath(CCFileUtils:sharedFileUtils():getWritablePath().. UpdateConfig.subDir)
	local currentVer = DBHelper.getGameVer()
	local downLoadedVer = DBHelper.getDownVer()
	local latestVer = DBHelper.getLatestVer()
	UpdateEngine:setVersionInfo(downLoadedVer,currentVer,latestVer)
	UpdateEngine:setVerFileUrl(UpdateConfig.verFileUrl)
	UpdateEngine:setDownLoadPath(UpdateConfig.downLoadPath)
	UpdateEngine:setTimeOut(60)
	UpdateEngine:update()
	self:activeUpdateTimer()
end
function SwitchLayer:showVersionNum()
	local currentVer = DBHelper.getGameVer()
	local curVerStr = self:formatVerCode(currentVer,true)
	local verInfo = string.format("%s: %s",TxtList.versionTxt,curVerStr)
	self:egSetLabelStr(kLblVersion,verInfo)
end
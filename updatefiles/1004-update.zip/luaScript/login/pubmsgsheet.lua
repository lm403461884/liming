local kLblTitle = "lbl_title"
local kPanelTxt = "txt_panel"
local __pubmsgsheet={}
function __pubmsgsheet.init(obj,msginfo)
	local title = msginfo.head
	local txtlist = Funs.splitStr(msginfo.content,"\n")
	local color = ccc3(83,49,22)
	local fontname = FNList.STHUPO
	local fontsize = 24
	obj:egSetLabelStr(kLblTitle,title)
	local panel = obj:egGetScrollView(kPanelTxt)
	local maxW = panel:getSize().width
	local oldH = panel:getSize().height
	local totalH = 0
	for key,val in ipairs(txtlist) do
		if string.len(val)>0 then 
			local lbl,showH= obj:addLblCtrl(val,color,fontname,fontsize,maxW)
			totalH = totalH + showH
			panel:addChild(lbl)
		end
	end
	if totalH >oldH then
		panel:setInnerContainerSize(CCSizeMake(maxW,totalH))
	end
end
function __pubmsgsheet.addLblCtrl(obj,str,color,fontname,fontsize,maxW)
	local lbl = Label:create()
	lbl:setText(str)
	lbl:setFontSize(fontsize)
	lbl:setColor(color)
	lbl:setFontName(fontname)
	local lblW = lbl:getSize().width
	local lblH = lbl:getSize().height
	if lblW >= maxW then
		local rows = math.ceil(lblW/maxW)
		local rowmod = lblW%maxW
		if rowmod > maxW*2/3 and rows > 3 then rows = rows + 1 end
		lblW = maxW
		lblH = rows*lblH
		--lbl:setTextAreaSize(CCSizeMake(lblW,lblH))
		lbl:setSize(CCSizeMake(lblW,lblH))
		lbl:ignoreContentAdaptWithSize(false)
	end
	return lbl,lblH
end

local function creator(msginfo)
    local obj = CocosWidget.new(JsonList.pubMsgSheet)
    table_aux.unpackTo(__pubmsgsheet, obj)
    obj:init(msginfo)
    return obj
end
PubMsgSheet = class("PubMsgSheet",creator)
PubMsgSheet.__index = PubMsgSheet
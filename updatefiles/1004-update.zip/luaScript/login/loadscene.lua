
local function creator()
	local scene =  Scene.new() 
	local function callback(eventType)
		  if eventType == "enter" then
			scene._switchlayer =  SwitchLayer:create()
			scene:addChild(scene._switchlayer)
		  end
	end
	scene:registerScriptHandler(callback)
	return scene
end
LoadScene = class("LoadScene",creator)
LoadScene.__index = LoadScene
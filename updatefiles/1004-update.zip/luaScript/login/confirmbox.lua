
ConfirmBox=class("ConfirmBox",function() return  TouchWidget.new(JsonList.msglayer) end)
ConfirmBox.__index = ConfirmBox
function ConfirmBox:className()
	return ConfirmBox.__cname
end
--msg ��Ҫ��ʾ����Ϣ
--callback1
--callback2
function ConfirmBox.show(msg,callback1,callback2)
	local msgbox = ConfirmBox.new()
	local kOffsetY = 40
	local maxW = 610
	local btnyes = tolua.cast(msgbox:egGetWidgetByName("Button_ok"),"Button")
	local btnno = tolua.cast(msgbox:egGetWidgetByName("Button_cancel"),"Button")
	local context =  tolua.cast(msgbox:egGetWidgetByName("Label_content"),"Label")
	local title = msgbox:egGetWidgetByName("Label_title")
	local imgbg = msgbox:egGetWidgetByName("img_dialog_bg")
	if not msg then msg="ok" end
	title:setVisible(false)
	context:setText(msg)
	context:setPosition(ccp(context:getPositionX(),context:getPositionY() + 40))
	local txtlen = context:getSize().width
	if txtlen > maxW then
		local rows = math.ceil(txtlen/maxW)
		local rowmod = txtlen%maxW
		if rowmod > maxW*2/3 and rows > 3 then rows = rows + 1 end
		local cellH = rows*context:getSize().height

		context:setSize(CCSizeMake(maxW,cellH))
		context:ignoreContentAdaptWithSize(false)
		local addH = math.max((rows-2),0)*cellH
		
		imgbg:setSize(CCSizeMake(imgbg:getSize().width,imgbg:getSize().height + addH))
		btnyes:setPosition(ccp(btnyes:getPositionX(),btnyes:getPositionY() - addH/2))
		btnno:setPosition(ccp(btnno:getPositionX(),btnno:getPositionY() - addH/2))
		context:setPosition(ccp(context:getPositionX(),context:getPositionY() + addH/2))
	end
	
	 local function yesCallback(sender, eventType)
		if eventType == 1 then
			sender:setTouchEnabled(false)
			btnno:setTouchEnabled(false)
        elseif eventType == 2 then
			FloatNode.popLayer()
            if callback1 then callback1() end
		elseif eventType == 3 then
			sender:setTouchEnabled(true)
			btnno:setTouchEnabled(true)
        end
    end
	 local function noCallback(sender, eventType)
		if eventType == 1 then
			sender:setTouchEnabled(false)
			btnyes:setTouchEnabled(false)
        elseif eventType == 2 then
			FloatNode.popLayer()
            if callback2 then callback2() end
		elseif eventType == 3 then
			sender:setTouchEnabled(true)
			btnyes:setTouchEnabled(true)
        end
    end
    btnyes:addTouchEventListener(yesCallback)
    btnno:addTouchEventListener(noCallback)
	FloatNode.pushLayer(msgbox)
end

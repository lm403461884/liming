local kBtnClose= "btn_close"
local kBtnLeft = "btn_left"
local kBtnRight = "btn_right"
local kPageMsg = "msg_page"
local kPanelLayer = "msg_panel"
local kImgBg = "img_bg"

local __pubmsgbar={}
function __pubmsgbar.init(obj,msgList)
    obj._msgList = msgList
	obj._selectedIdx = 1
	obj._loadedMax = 1
	local startIdx = 1
	local endIdx= math.min(2,#obj._msgList)
	local widget = obj:egGetWidgetByName(kPageMsg)
	local pageview = tolua.cast(widget,"PageView")
	for idx = startIdx,endIdx do
		obj._loadedMax = idx
		obj:addMsgSheet(idx)
	end
	obj:showpubMsgSheetAt(1)
	local function pageViewEvent(sender, eventType)
		local tmp_pageview = tolua.cast(sender, "PageView")
		local idx = tmp_pageview:getCurPageIndex() + 1
        if eventType == PAGEVIEW_EVENT_TURNING then
			obj:showpubMsgSheetAt(idx)
        end 
	end
    pageview:addEventListenerPageView(pageViewEvent)
    obj:showWithAction()
end
function __pubmsgbar.addMsgSheet(obj,idx)
	if idx < 1 or idx > #obj._msgList then return end
	local msginfo = obj._msgList[idx]
	local msgitem = PubMsgSheet.new(msginfo)
	local layout = tolua.cast(msgitem:egNode(),"Layout")
	layout:setPosition(ccp(0,0))
	local widget = obj:egGetWidgetByName(kPageMsg)
	local pageview = tolua.cast(widget,"PageView")
	pageview:addPage(layout)
end
function __pubmsgbar.showpubMsgSheetAt(obj,idx)
	local widget = obj:egGetWidgetByName(kPageMsg)
	local pageview = tolua.cast(widget,"PageView")
    if obj._selectedIdx ~= idx then
		if obj._selectedIdx < idx and obj._loadedMax < #obj._msgList then
			obj._loadedMax = obj._loadedMax + 1
			obj:addMsgSheet(obj._loadedMax)
		end
		obj._selectedIdx = idx
    end
	if  obj._msgList[obj._selectedIdx-1] then obj:egShowWidget(kBtnLeft) 
    else obj:egHideWidget(kBtnLeft)  end
    if  obj._msgList[obj._selectedIdx+1] then obj:egShowWidget(kBtnRight) 
    else obj:egHideWidget(kBtnRight)  end   
end

--�������
function __pubmsgbar.bindCloseListener(obj)
     local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if GuideManager:isGuiding() then GuideManager:unmarkFocus() end
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if GuideManager:isGuiding() then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
--����հ�����
function __pubmsgbar.bindPanelListener(obj)
     local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if GuideManager:isGuiding() then GuideManager:unmarkFocus() end
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if GuideManager:isGuiding() then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end

--��һҳ
function __pubmsgbar.bindLeftListener(obj)
     local function touchEnded(sender)
		if GuideManager:isGuiding() then GuideManager:unmarkFocus() end
        obj:egHideWidget(kBtnLeft)
		local idx = obj._selectedIdx - 1
		if idx > 0 then
		    local widget = obj:egGetWidgetByName(kPageMsg)
            local pageview = tolua.cast(widget,"PageView")
            pageview:scrollToPage(idx-1)
		end
    end
	local function touchCanceled(sender)
		if GuideManager:isGuiding() then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnLeft,nil,nil,touchEnded,touchCanceled)
end
--��һҳ
function __pubmsgbar.bindRightListener(obj)
     local function touchEnded(sender)
		if GuideManager:isGuiding() then GuideManager:unmarkFocus() end
        obj:egHideWidget(kBtnRight)
		local idx = obj._selectedIdx + 1
		if idx <= #obj._msgList then
		    local widget = obj:egGetWidgetByName(kPageMsg)
            local pageview = tolua.cast(widget,"PageView")
            pageview:scrollToPage(idx-1)
		end
    end
	local function touchCanceled(sender)
		if GuideManager:isGuiding() then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnRight,nil,nil,touchEnded,touchCanceled)
end
function __pubmsgbar.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kImgBg)
    baseWidget:setPosition(ccp(640,1080))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveBy:create(0.5,ccp(0,-720))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	baseWidget:runAction(spawn)
end
function __pubmsgbar.hideWithAction(obj,callbackfunc)
    local function callback()
			AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveBy:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kImgBg)
    baseWidget:runAction(squence)
end

local function creator(pubinfo)
    local obj = TouchWidget.new(JsonList.pubMsgPanel)
    table_aux.unpackTo(__pubmsgbar, obj)
	obj:init(pubinfo)
    obj:bindCloseListener()
	obj:bindPanelListener()
	obj:bindRightListener()
	obj:bindLeftListener()
    return obj
end
PublishMsgBar = class("PublishMsgBar",creator)
PublishMsgBar.__index = PublishMsgBar
function showPubMsgBar(pubinfo)
    local layer = PublishMsgBar.new(pubinfo)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
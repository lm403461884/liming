local kBtnOk = "btn_ok"
local kImgTxtBg = "nickname_bg"
local kTbTxt = "tb_nickname"
local kLblWarn = "lbl_warn1"
local kImgBg = "img_bg"
local kPattenChar="[%p,%c]"
local kMaxTxtLen = 16
local kBtnRandom = "btn_dice"
local kWhiteColor = ccc3(255,255,255)
__nicknamelayer={}
function __nicknamelayer.bindOkListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods) --确认
		if obj._nameReady == false then
			local nameBg = obj:egGetWidgetByName(kImgTxtBg)
			nameBg:stopAllActions()
			nameBg:setColor(kWhiteColor)
			local turnRed = CCTintTo:create(0.2,255,0,0)
			local turnWhite = CCTintTo:create(0.3,255,255,255)
			nameBg:runAction(CCSequence:createWithTwoActions(turnRed,turnWhite))
			sender:setTouchEnabled(true)
		else
			local namestr = Funs.trimStr(obj:egGetTextFieldVal(kTbTxt))
			AcctManager:setParam("nickName",namestr)
			TDHelper.setAccountName(namestr)
			TDHelper.onEvent(TDEvent.setNickName)
			SendMsg[931010](namestr)
			local widget = obj:egGetWidgetByName(kImgBg)
			local scaleto = CCScaleTo:create(0.1,0)
			widget:runAction(scaleto)
			
			local colorLayer = CCLayerColor:create(ccc4(0,0,0,0))
			obj:egAddChild(colorLayer)

			local fadeIn = CCFadeTo:create(0.5,255)
			local function callback()
			    SDKHelper:submitServerInfo()
                SDKHelper:submitLoginGameRole()
				local scene = StoryScene.new()
				scene:egReplace()
			end
			local callfunc = CCCallFunc:create(callback)
			local sequence = CCSequence:createWithTwoActions(fadeIn,callfunc)
			colorLayer:runAction(sequence)
		end
		
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnd,nil) 
end

function __nicknamelayer.bindTxgBgListener(obj)
	 local function touchEnded(sender)
        local widget = obj:egGetWidgetByName(kTbTxt)
        local textField = tolua.cast(widget,"TextField")
        textField:attachWithIME()
    end
    obj:egBindTouch(kImgTxtBg,nil,nil,touchEnded,nil)
end
function __nicknamelayer.checkNickName(obj,textField)
	local trimtxt =  Funs.trimlStr( textField:getStringValue())
	if string.len(trimtxt) == 0 then
		obj._nameReady = false
		obj:egShowWidget(kLblWarn)
		obj:egSetLabelStr(kLblWarn,TxtList.warnNoNickName)
	else
		local utfTxt = Funs.subStr(trimtxt,kMaxTxtLen)
		utfTxt = WorldFilter.replaceWords(utfTxt,true)
		textField:setText(utfTxt)
		if string.find(utfTxt,kPattenChar) then
		    --print(utfTxt)
			obj._nameReady = false
			obj:egShowWidget(kLblWarn)
			obj:egSetLabelStr(kLblWarn,TxtList.warnNickNameFormat)
		else
			obj._nameReady = true
			obj:egHideWidget(kLblWarn)
		end
	end
end
function __nicknamelayer.bindTxtListener(obj)
     local function textFieldEvent(sender, eventType)
        obj:checkNickName(tolua.cast(sender,"TextField"))
    end
    local widget = obj:egGetWidgetByName(kTbTxt)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent) 
end
function __nicknamelayer.bindRandomName(obj)
    local function randomName(sender)
        obj:randomName()
    end
    obj:egBindTouch(kBtnRandom,nil,nil,randomName,nil)
end
function __nicknamelayer.randomName(obj)
    local num1=math.random(1,#nameRadom.namepro)
    local num2 = math.random(1,#nameRadom.nameafter)
    local name = nameRadom.namepro[num1]..nameRadom.nameafter[num2]
    local widget = obj:egGetWidgetByName(kTbTxt)
    local textField = tolua.cast(widget,"TextField")
	textField:setText(name)
	obj:checkNickName(textField)
end

local function creator()
    require "gameScript/script_gamedata/nameRadom.lua"
     local obj=TouchWidget.new(JsonList.nickNameLayer)
	 table_aux.unpackTo(__nicknamelayer,obj)
	 obj._nameReady = false
	 obj:randomName()
	 obj:egHideWidget(kLblWarn)
	 obj:bindOkListener()
	 obj:bindTxgBgListener()
	 obj:bindTxtListener()
	 obj:bindRandomName()
	 return obj
end
NickNameLayer = class("NickNameLayer",creator)
NickNameLayer.__index = NickNameLayer

function showNickNameLayer()
	local layer = NickNameLayer.new()
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
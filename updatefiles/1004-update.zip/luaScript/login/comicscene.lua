local function creator()
	local scene =  Scene.new() 
	local function callback(eventType)
		  if eventType == "enter" then
			SoundHelper.playBGM(SoundList.comic_bgm)
			local layer = ComicLayer.new()
			scene._baseWidget = layer
			scene:addChild(layer:egNode())
		  end
	end
	scene:registerScriptHandler(callback)
	return scene
end
ComicScene = class("ComicScene",creator)
ComicScene.__index = ComicScene

local function creator()
	local kPanelWait = "wait_layer"
	local kLblTime = "lbl_time"
	local kWaitTime = 300 --Ԥ���ȴ�ʱ��
    local obj=TouchWidget.new(JsonList.battleWaitLayer)
	local leftTime = kWaitTime  --Ԥ���ȴ�ʱ��
	local passed = 0
    obj:egSetLabelStr(kLblTime,Funs.formatTimeCh(leftTime,false,false,true,true,false))
    local function update(delta)
		passed = passed + delta
		local tmpleft = math.ceil(kWaitTime - passed)
		if tmpleft~= leftTime then
			leftTime = tmpleft
			obj:egSetLabelStr(kLblTime,Funs.formatTimeCh(leftTime,false,false,true,true,false))
			if leftTime <= 0 then
				SceneManager:show(LogoScene)
			end
		end
	end
	obj:egBindWidgetUpdate(kLblTime,update)
	return obj
end
BattleWaitLayer = class("BattleWaitLayer",creator)
BattleWaitLayer.__index = BattleWaitLayer


function showBattleWaitLayer()
	local layer = BattleWaitLayer.new()
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
local kBgZorder = 1
local kPropZorder = 2
local kGrowZorder = 3
local __growscene={}

GrowScene = {}
function GrowScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__growscene, obj)
    obj._bgWidget = GrowBg.new()
    obj._bgWidget:egAttachTo(obj,kBgZorder,kBgZorder)
    obj._baseWidget = GrowLayer.new(account_data)
    obj._baseWidget:egAttachTo(obj,kGrowZorder,kGrowZorder)
    obj._propWidget = PropLayer.new()
    obj._propWidget:egAttachTo(obj,kPropZorder,kPropZorder)

    showEmDialog(obj,GuideScene.def.kGrowScene) --����������Ϣ
            ----------------------------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end

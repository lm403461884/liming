local kPanelMap="map_panel"
local kPanelN = "nm_pnael"
local kPanelD = "dm_panel"
local kBtnBack = "btn_close"
local kBtnMap = "btn_wordmap"
local kBtnSwitch="btn_switch"
local kLblSwitch = "lbl_switch"
local kLblSwitch_s = "lbl_switch_s"
local __missionlayer={}
function __missionlayer.init(obj,areaid)
	obj._areaid = areaid
    obj._d_data = account_data
    obj._normalList = nil
    obj._dailyList = nil
	obj:egChangeBgImg(kPanelMap,string.format("%sareamap_%d.pvr.ccz",KVariantList.bgPvrPath,obj._areaid))
	obj:egChangeBgImg(kPanelN,string.format("%sareatrace_%d.pvr.ccz",KVariantList.bgPvrPath,obj._areaid))
    if MissionHelper.showDaily then
		obj:egShowWidget(kPanelD)
		obj:egHideWidget(kPanelN)
        obj:loadDayMission()
		obj:egSetLabelStr(kLblSwitch_s,TxtList.missionNormal)
		obj:egSetLabelStr(kLblSwitch,TxtList.missionNormal)
    else
		obj:egShowWidget(kPanelN)
		obj:egHideWidget(kPanelD)
        obj:loadNormalMission()
		obj:egSetLabelStr(kLblSwitch_s,TxtList.missionDaliy)
		obj:egSetLabelStr(kLblSwitch,TxtList.missionDaliy)
    end
end
--������ͨ����
function __missionlayer.loadNormalMission(obj)
    obj._normalList = {}
    local areaid = obj._areaid 
    local nmData = missionData.normal_mission[areaid] or {}
    local panel = obj:egGetWidgetByName(kPanelN)
    for key,stageid in ipairs(nmData) do
        local mission = Mission.new(areaid,stageid)
        table.insert(obj._normalList,mission)
        local size = mission:egNode():getSize()
        local pvestage = pveQuery.queryStage(areaid,stageid)
        mission:egNode():setPosition(ccp(pvestage.x - size.width/2,pvestage.y- size.height/2))
        panel:addChild(mission:egNode())
    end
	
end

--�����ճ�����
function __missionlayer.loadDayMission(obj)
    obj._dailyList = {}
    local areaid = obj._areaid 
	local dmdata = MissionHelper.getClientMission()
    local clientdmData =dmdata[areaid] or {} --�����������
    local panel = obj:egGetWidgetByName(kPanelD)
    for groupIdx,updatedt in ipairs(clientdmData) do
		local stageid =  MissionHelper.getStageId(areaid,groupIdx)
        local mission = Mission.new(areaid,stageid,groupIdx,updatedt)
        table.insert(obj._dailyList,mission)
        local size = mission:egNode():getSize()
        if not stageid then stageid = missionData.day_mission[areaid][groupIdx].mis_array[1] end
        local pvestage = pveQuery.queryStage(areaid,stageid)
        mission:egNode():setPosition(ccp(pvestage.x - size.width/2,pvestage.y- size.height/2))
        panel:addChild(mission:egNode())
    end
	
end
--��ʾ��ͨ����
function __missionlayer.showNormalMission(obj,show)
	
    if show and not obj._normalList then
        obj:loadNormalMission()
    else
        for key,mission in ipairs(obj._normalList) do
            mission:showMission(show)
        end
    end
end
--��ʾ�ճ�����
function __missionlayer.showDayMission(obj,show)
	
    if show and not obj._dailyList then
        obj:loadDayMission()
    else
        for key,mission in ipairs(obj._dailyList) do
            mission:showMission(show)
        end
    end
end
--�����ͼ��ť����¼�
function __missionlayer.doClickMap(obj,sender)
    sender:setTouchEnabled(false)
    SoundHelper.playEffect(SoundList.click_paper_open)
    local scene = worldmapScene.new()
    scene:egReplace()
end
--�����л���ť����¼�
function __missionlayer.doClickSwitch(obj,sender)
        sender:setTouchEnabled(false)
         SoundHelper.playEffect(SoundList.click_shop_goods)
        if MissionHelper.showDaily then
            MissionHelper.showDaily = nil
            obj:egShowWidget(kPanelN)
	        obj:egHideWidget(kPanelD)
            obj:showNormalMission(true)
            obj:showDayMission(false)
			obj:egSetLabelStr(kLblSwitch_s,TxtList.missionDaliy)
			obj:egSetLabelStr(kLblSwitch,TxtList.missionDaliy)
        else
			obj:egSetLabelStr(kLblSwitch_s,TxtList.missionNormal)
			obj:egSetLabelStr(kLblSwitch,TxtList.missionNormal)
            obj:egShowWidget(kPanelD)
	        obj:egHideWidget(kPanelN)
            MissionHelper.showDaily = true
            obj:showNormalMission(false)
            obj:showDayMission(true)
        end
        sender:setTouchEnabled(true)
end
--���ذ�ť����¼�
function __missionlayer.doClickBack(obj,sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_close)
        local scene = TownScene.new()
        scene:egReplace()
end
--�����ͼ��ť
function __missionlayer.bindMapListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:doClickMap(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnMap,nil,nil,touchEnded,touchCanceled)
end
--�����л���ť
function __missionlayer.bindSwitchListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:doClickSwitch(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnSwitch,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __missionlayer.bindBackListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickBack(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
MissionLayer={}
function MissionLayer.new(d_data)
    local obj =  TouchWidget.new(JsonList.pveMap)
    table_aux.unpackTo(__missionlayer, obj)
    obj:init(d_data)
    obj:bindBackListener()
    obj:bindMapListener()
    obj:bindSwitchListener()
    return obj
end


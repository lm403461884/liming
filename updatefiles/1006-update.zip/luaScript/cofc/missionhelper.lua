local missionKey = "dmdata"
local kMaxMissionNum = 1000
local __missionData = nil
MissionHelper={}
--��ȡ�ճ�����ID
function MissionHelper.getStageId(areaid,groupid)
	local dmdata = MissionHelper.getClientMission()
	local stageid = dmdata[areaid][groupid]
	if stageid < kMaxMissionNum then return stageid end
	if stageid + missionData.day_mission[areaid][groupid].ref_time <= os.time() then 
		local newIdx = math.random(#missionData.day_mission[areaid][groupid].mis_array)
		stageid = missionData.day_mission[areaid][groupid].mis_array[newIdx]
		dmdata[areaid][groupid] = stageid
		MissionHelper.saveClientMission(dmdata)
		return stageid
	end
	return nil
end
--�޸ı����������
function MissionHelper.saveClientMission(dmdata)
	local strval = table_aux.serial(dmdata, true)
	CCUserDefault:sharedUserDefault():setStringForKey(missionKey,strval)
end
--���±����������
function MissionHelper.updateClientMission()
	if MissionHelper.groupIdx then
		local dmdata = MissionHelper.getClientMission()
		dmdata[MissionHelper.areaId][MissionHelper.groupIdx] = os.time()
		MissionHelper.saveClientMission(dmdata)
	end
end

--�����½���������ճ��������
function MissionHelper.unlockClientMission(licenceLv)
	local dmdata = MissionHelper.getClientMission()
    local areaid = licenceLevelup[licenceLv].areaID
    if licenceLv-1 <= account_data.digLv and not dmdata[areaid] then
        dmdata[areaid]={}
        local groupCnt =  #(missionData.day_mission[areaid] or {})
        for idx = 1,groupCnt do
            table.insert(dmdata[areaid],os.time())
        end
        MissionHelper.saveClientMission(dmdata)
    end
end
--���ر����ճ��������
--����������
function MissionHelper.loadClientMission()
    local strVal = CCUserDefault:sharedUserDefault():getStringForKey(missionKey)
    __missionData = {}
    if not strVal or strVal=="" then
        for areaid,unlockdata in pairs(account_data.unlockedPVE or {}) do
            if unlockdata[1] then
                __missionData[areaid]={}
                local groupCnt =  #(missionData.day_mission[areaid] or {})
                for idx = 1,groupCnt do
                    table.insert(__missionData[areaid],os.time())
                end
            end
        end
		if account_data.diggingLvContext then
			local areaid = licenceLevelup[account_data.digLv+1].areaID
			__missionData[areaid]={}
			local groupCnt =  #(missionData.day_mission[areaid] or {})
			for idx = 1,groupCnt do
				table.insert(__missionData[areaid],os.time())
			end
		end
        MissionHelper.saveClientMission(__missionData)
    else
        local chunck, err1 = loadstring(strVal)
        if not chunck then print(err1) end
        local succ, err2 = pcall(chunck)
        if not succ then print(err2) end
        __missionData = err2
    end
end
--�������ݣ�ˢ���ճ�����
function MissionHelper.fitClientMission()
	if not __missionData then return end
	local changed = false
	for areaid,item in pairs(__missionData) do
		for idx,stageid in ipairs(item) do
			if stageid > kMaxMissionNum then
				if stageid + missionData.day_mission[areaid][idx].ref_time <= os.time() then
					local newIdx = math.random(#missionData.day_mission[areaid][idx].mis_array)
					item[idx] = missionData.day_mission[areaid][idx].mis_array[newIdx]
					changed = true
				end
			end
		end
	end
	if changed then MissionHelper.saveClientMission(__missionData) end
end
function MissionHelper.getClientMission()
	if not __missionData then
		MissionHelper.loadClientMission()
		MissionHelper.fitClientMission()
	end
	return __missionData
end

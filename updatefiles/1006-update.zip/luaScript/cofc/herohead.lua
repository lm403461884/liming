local kImgItem = "img_item"
local kLblLv = "lbl_lv"
local kImgLv = "img_lv"
local __herohead = {}
function __herohead.init(obj,heroid,herolv,isememy)
    if not heroid then
        obj:egChangeImg(kImgItem,ImageList.cofc_unknownhero,UI_TEX_TYPE_PLIST)
		obj:egHideWidget(kLblLv)
    else
        local s_cfg = hero_data.getConfig(heroid)
        obj:egChangeImg(kImgItem,s_cfg.headPic,UI_TEX_TYPE_PLIST)
		obj:egSetBMLabelStr(kLblLv,herolv)
		if isememy then
			obj:egChangeImg(kImgLv,ImageList.risk_lv_red,UI_TEX_TYPE_PLIST)
		end
    end
end
HeroHead = {}
function HeroHead.new(heroid,herolv,isememy)
      local obj = {}
    CocosWidget.install(obj,JsonList.heroHead)
    table_aux.unpackTo(__herohead, obj)
    obj:init(heroid,herolv,isememy)
    return obj
end
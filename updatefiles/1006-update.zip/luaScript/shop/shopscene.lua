local __shopscene={}

ShopScene = {}
function ShopScene.new()
    SoundHelper.playBGM(SoundList.shop_bgm)
	SoundHelper.playEffect(SoundList.shop_door_open)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__shopscene, obj)
    obj._baseWidget = ShopLayer.new(account_data)
    obj._baseWidget:egAttachTo(obj)
    obj._propWidget = PropLayer.new()
    obj._propWidget:egAttachTo(obj)

    showEmDialog(obj,GuideScene.def.kShopScene) --����������Ϣ
            ----------------------------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end

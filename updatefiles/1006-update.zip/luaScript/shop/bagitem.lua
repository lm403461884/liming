local kImgItem = "img_tool"
local kLblOwn = "lbl_own"
local kLblAdd = "lbl_add"
local kBarCD = "bar_cd"
local kBtnRemove = "btn_remove"
local __bagitem = {}
function __bagitem.init(obj,itemid)
    obj:egHideWidget(kLblAdd)
    obj:egHideWidget(kBarCD)
    obj:egHideWidget(kBtnRemove)
    obj._itemid = itemid
    if obj._itemid > 0 then 
        obj:egShowWidget(kImgItem)
        obj:egShowWidget(kLblOwn)
        obj._s_data = itemQuery.query(obj._itemid)--��ȡ���߾�̬����
        obj:egChangeImg(kImgItem,obj._s_data.icon,UI_TEX_TYPE_PLIST)
        obj:loadPdInfo() --����������Ϣ��
        obj._ownNum = account_data.bag[obj._itemid] or 0
        obj:egSetBMLabelStr(kLblOwn,obj._ownNum)
        obj:activeUpdate()
    else
        obj:egHideWidget(kImgItem)
        obj:egHideWidget(kLblOwn)
        obj:disableUpdate()
    end
	
end
 --����������Ϣ��
function __bagitem.loadPdInfo(obj)
    obj._pdInfo = nil
    obj._pdCnt = 0
    local pdInfo = obj:getPdInfo()
    if pdInfo then 
        obj._pdInfo = pdInfo
        obj._pdCnt = obj._pdInfo.cnt
        obj:egShowWidget(kLblAdd) 
        obj:egShowWidget(kBtnRemove)
        obj:egShowWidget(kBarCD)
        obj:egSetBMLabelStr(kLblAdd,string.format("%s%d",TxtList.addSymbol,obj._pdCnt))
        if account_data.pdLine.items[1] == obj._pdInfo then --��ǰ��������ĵ���
            obj:egSetBarPercent(kBarCD,100-account_data.pdLine.passed*100/obj._s_data.fcd)
        else
            obj:egSetBarPercent(kBarCD,100)
        end
    end
end
--������������Ϣ
function __bagitem.refreshPdInfo(obj)
    local pdIdx = obj:getPdItemIdx(obj._itemid)
    if pdIdx  then
        if obj._pdCnt ~= obj._pdInfo.cnt then
            obj._pdCnt = obj._pdInfo.cnt
            obj:egSetBMLabelStr(kLblAdd,string.format("%s%d",TxtList.addSymbol,obj._pdCnt))
        end
        if pdIdx == 1 then --��ǰ��������ĵ���
            local oldper = obj:egGetBarPercent(kBarCD)
            local per = 100-(os.time()- account_data.pdLine.st)*100/obj._s_data.fcd
            if per ~= oldper then obj:egSetBarPercent(kBarCD,per) end
        end
        local num = account_data.bag[obj._itemid] or 0
        if obj._ownNum ~= num then
            obj._ownNum = num
            obj:egSetBMLabelStr(kLblOwn,obj._ownNum)
         end
    else
        obj:egHideWidget(kLblAdd)
        obj:egHideWidget(kBarCD)
        obj:egHideWidget(kBtnRemove)
        obj._pdInfo = nil
        local num = account_data.bag[obj._itemid] or 0
        if obj._ownNum ~= num then
            obj._ownNum = num
            obj:egSetBMLabelStr(kLblOwn,obj._ownNum)
        end
        if obj._ownNum == 0 then
            obj:init(0)
           if  obj._allRemovedCallback then obj._allRemovedCallback(obj) end
        end
    end
end
--��ȡ����������������������Ϣ
function __bagitem.getPdInfo(obj)
   for key,item in ipairs(account_data.pdLine.items) do
        if item.itemid == obj._itemid then
            return item
        end
    end
    return nil
end
--��ȡ�������������е�λ������
function __bagitem.getPdItemIdx(obj,itemid)
    for key,item in ipairs(account_data.pdLine.items) do
        if item.itemid == itemid then
            return key
        end
    end
    return nil
end
function __bagitem.activeUpdate(obj)
    local function update()
        if obj._pdInfo then
            obj:refreshPdInfo()
        else
            obj:loadPdInfo()
        end   
    end
    obj:egBindWidgetUpdate(kImgItem,update)
end
function __bagitem.disableUpdate(obj)
    obj:egUnbindWidgetUpdate(kImgItem)
end
function __bagitem.onAllRemoved(obj,callback)
    obj._allRemovedCallback = callback
end
function __bagitem.bindRemoveListenter(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        SendMsg[933003](obj._itemid)--����ȡ��������Ϣ��������
        obj._pdInfo.cnt = obj._pdInfo.cnt - 1
        if obj._pdInfo.cnt <= 0 then
           local pdIdx = obj:getPdItemIdx(obj._itemid)  
           if pdIdx then table.remove(account_data.pdLine.items,pdIdx) end
           if pdIdx == 1 then
               account_data.pdLine.st=os.time()
               account_data.pdLine.passed = 0
           end
           local ownNum = account_data.bag[obj._itemid] or 0
           if ownNum <= 0 then --��������Ϊ0����Ҫ���
                account_data.bag[obj._itemid] = nil
                for key,itemid in ipairs(account_data.teamBag) do
                    if itemid == obj._itemid then
                        table.remove(account_data.teamBag,key)
                        break
                    end
                end
           end
           
        end
        obj:refreshPdInfo()
        account_data.pdLine.total = account_data.pdLine.total - obj._s_data.fcd
        account_data.usedBagCapacity = account_data.usedBagCapacity - obj._s_data.consume
        sender:setTouchEnabled(true)
    end
    obj:egBindTouch(kBtnRemove,nil,nil,touchEnded,nil)
end
BagItem = {}
function BagItem.new(itemid)
    local obj={}
    CocosWidget.install(obj,JsonList.bagItem)
    table_aux.unpackTo(__bagitem, obj)
    obj:init(itemid)
    obj:bindRemoveListenter()
    return obj
end

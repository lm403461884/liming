local kBtnOk = "btn_ok"
local kPanelLayer = "prompt_panel"
local kImgBg = "img_bg"
local kLabelTitle = "lbl_title"
local kImgItem = "img_item"
local kLabelLv = "lbl_lv"
local kLabelUnlock = "lbl_change"
local kPanelProp = "panel_change"
local kCellH = 40
local kCellW1 = 400
local kCellH1 = 80
local __trainprompt = {}
function __trainprompt.init(obj,change_data)
    local trainid = change_data.trainid
    local from = change_data.from
    local to = change_data.to
    local s_cfg = train.config[trainid]
    obj:egChangeImg(kImgItem,s_cfg.research[to].bodyImage[1])
    obj:egSetLabelStr(kLabelTitle,string.format("%s%s",s_cfg.name,obj:egGetLabelStr(kLabelTitle)))
    obj:egSetLabelStr(kLabelLv,string.format("LV%d%sLV%d",from,TxtList.arrowSymbol,to))
    local unlockstr = s_cfg.research[to].unlockItem
    if unlockstr == "" then
        obj:egHideWidget(kLabelUnlock)
    else
		local widget = obj:egGetWidgetByName(kLabelUnlock)
		local lbl =  tolua.cast(widget,"Label")
		lbl:setText(unlockstr)
		local size = lbl:getSize()
		if size.width > kCellW1 then
			lbl:setTextAreaSize(CCSizeMake(kCellW1,kCellH1))
		end
    end
    obj:loadPropChange(change_data)
end
function __trainprompt.loadPropChange(obj,change_data)
    local trainid = change_data.trainid
    local maxW = 0
    local maxH = 0
    local widget = obj:egGetWidgetByName(kPanelProp)
    
    for key,item in pairs(change_data.changes) do
        if val ~= 0 then
            local str = string.format("%s%s%d%s%d",train.props[trainid][key],":",item[1],TxtList.arrowSymbol,item[2])
            local lbl = Label:create()
            lbl:setFontName(FNList.STHUPO)
            lbl:setFontSize(36)
            lbl:setText(str)
            lbl:setColor(ccc3(83,49,22))
            local size = lbl:getSize()
            if maxW < size.width then maxW = size.width  end
            lbl:setTextAreaSize(CCSizeMake(size.width,kCellH))
            maxH = maxH + kCellH
            widget:addChild(lbl)
        end
    end
    if maxW > 0 then
    local oldsize = widget:getSize() 
       local oldw = oldsize.width
       local oldh = oldsize.height
       local x = widget:getPositionX()
       local y = widget:getPositionY()
       widget:ignoreContentAdaptWithSize(false)
       widget:setSize(CCSizeMake(maxW,maxH))
       widget:setPosition(ccp(x + (oldw - maxW)/2,y + ( oldh- maxH)/2))
    end
end
function __trainprompt.bindOkListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnOk,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __trainprompt.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
        AccountHelper:unlock(kStatePrompt)
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __trainprompt.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
TrainPrompt={}
function TrainPrompt.new(change_data,onloaded)
   local obj =  TouchWidget.new(JsonList.trainPromt)
    table_aux.unpackTo(__trainprompt, obj)
    obj._onloaded = callback
    obj:init(change_data)
    obj:bindOkListener()
    return obj
end
function showTrainPrompt(change_data,onloaded)
    local layer = TrainPrompt.new(change_data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end
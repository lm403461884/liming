local kBtnOk = "btn_ok"
local kPanelLayer = "prompt_panel"
local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"
local kLabelState = "lbl_state"
local kLabelAtk = "lbl_atk"

local __pvpprompt = {}
function __pvpprompt.init(obj,summarydata)
    if summarydata.stars and summarydata.stars > 0 then
        obj:egSetLabelStr(kLabelState,string.format("%s%s",obj:egGetLabelStr(kLabelState),TxtList.failTxt))
    else
        obj:egSetLabelStr(kLabelState,string.format("%s%s",obj:egGetLabelStr(kLabelState),TxtList.succTxt))
		--挖掘日志任务进程更新,PVP防守胜利
		task.updateTaskStatus(account_data,task.client_event_id.finished_defend,{summarydata.stars})
		----------------------------------------------------------
    end
    obj:egSetLabelStr(kLabelAtk,string.format("%s%s",obj:egGetLabelStr(kLabelAtk),summarydata.atkName))
    obj:loadAward1(summarydata)
	obj:loadAward2(summarydata)
end
function __pvpprompt.loadAward1(obj,summarydata)
    local panel = obj:egGetWidgetByName(kPanelAward1)
    local margin = 0
    local goldAward = AwardItem.new("gold",Funs.signedNum(summarydata.gold))
    local goldsize = goldAward:egNode():getSize()
    goldAward:egNode():setSize(CCSizeMake(goldsize.width + margin,goldsize.height))
    panel:addChild(goldAward:egNode())
    local eloAward = AwardItem.new("elo",Funs.signedNum(summarydata.elo))
     panel:addChild(eloAward:egNode())
    local panelsize = panel:getSize()
    local actW = goldAward:egNode():getSize().width + eloAward:egNode():getSize().width + margin
    panel:setPosition(ccp(panel:getPositionX() + (panelsize.width-actW)/2,panel:getPositionY()))
end
function __pvpprompt.loadAward2(obj,summarydata)
    local panel = obj:egGetWidgetByName(kPanelAward2)
    local panelsize = panel:getSize()
    local actW = 0
    for idx = 2,7 do
        local coinname = KVariantList.coinType[idx]
        local coinval = summarydata[coinname]
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
            panel:addChild(awarditem:egNode())
            actW = actW + awarditem:egNode():getSize().width
        end
    end
    if actW < panelsize.width then
        panel:setPosition(ccp(panel:getPositionX() + (panelsize.width-actW)/2,panel:getPositionY()))
    elseif actW > panelsize.width then
        panel:setScale(panelsize.width/actW)
    end
    if actW <=0 then
         local panel1 = obj:egGetWidgetByName(kPanelAward1)
         panel1:setPosition(ccp(panel1:getPositionX(),panel1:getPositionY() - 30))
    end
end
function __pvpprompt.bindOkListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnOk,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __pvpprompt.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
        AccountHelper:unlock(kStatePrompt)
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __pvpprompt.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
PvpPrompt={}
function PvpPrompt.new(summarydata,onloaded)
   local obj =  TouchWidget.new(JsonList.pvpPromt)
    table_aux.unpackTo(__pvpprompt, obj)
    obj._onloaded = callback
    obj:init(summarydata)
    obj:bindOkListener()
    return obj
end
function showPvpPrompt(summarydata,onloaded)
    local layer = PvpPrompt.new(summarydata,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end
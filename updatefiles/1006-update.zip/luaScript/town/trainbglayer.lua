local kmenuZorder = 3
local kpopZorder = 4
local kImgBg1 = "bg_1"
local kImgBg2 = "bg_2"
local kImgBg3 = "bg_3"
local kPanelClound = "cloud_panel"
local kImgBg4 = "bg_4"
local kImgBg0 = "bg_0"
local kPanelTrain = "train_panel"
local kBgw = 1024*4
local kBgh = 512
local kcloudMinX = -3000
local kcloudMaxX = 0
local kRateNear = 2.5
local kRateMid = 5
local kRateFar = 32
local kRateCloud = 16
local kSpeedCloud = 10
local kOffsetX = 925
local kStopPosX = 280
local kmarginX0 = -15
local kmarginX = -30
local offsetY = 88
local __trainbg = {}

function __trainbg.init(obj,d_data)
    obj._d_data = d_data
    obj._cloudDir = -1
    obj._frameId = 0
    local areaData = scene_data[obj._d_data.worldAreaID]
    --[[
	local tmpscenename = "canyon"
    areaData.mid_img = "GUIRes/PvrCcz/scene/"..tmpscenename.."_2.pvr.ccz"
    areaData.near_img = "GUIRes/PvrCcz/scene/"..tmpscenename.."_4.pvr.ccz"
    areaData.cload_img = "GUIRes/PvrCcz/scene/"..tmpscenename.."_3.pvr.ccz"
    areaData.far_img = "GUIRes/PvrCcz/scene/"..tmpscenename.."_1.pvr.ccz"
	areaData.fixed_img = "GUIRes/PvrCcz/scene/canyon_0.pvr.ccz"
	--]]
    obj:loadImgRepeat(kImgBg1,areaData.far_img,kBgw,kBgh)
    obj:loadImgRepeat(kImgBg2,areaData.mid_img,kBgw,kBgh)
    
    obj:loadImgRepeat(kImgBg3,areaData.cload_img,kBgw,kBgh)
    obj:loadImgRepeat(kImgBg4,areaData.near_img,kBgw,kBgh)
    obj:egChangeImg(kImgBg0,areaData.fixed_img) --������
    obj._near = obj:egGetWidgetByName(kImgBg4)
    obj._mid = obj:egGetWidgetByName(kImgBg2)
    obj._far = obj:egGetWidgetByName(kImgBg1)
    obj._cloud = obj:egGetWidgetByName(kPanelClound)
    obj._scrollTrain = obj:egGetScrollView(kPanelTrain)
    
    obj._nearX = obj._near:getPositionX()
    obj._midX = obj._mid:getPositionX()
    obj._farX = obj._far:getPositionX()
    obj._cloudX = obj._cloud:getPositionX()
    obj._scrollTrainX = obj._scrollTrain:getInnerContainer():getPositionX()
    obj:loadOwnTrains()
    obj:bindScrollListener()
    
end
--ƽ�̼���ͼƬ
function __trainbg.loadImgRepeat(obj,widgetName,imgsrc,w,h)
    local widget = obj:egGetWidgetByName(widgetName)
    local img = tolua.cast(widget,"ImageView")
    img:loadTexture(imgsrc)
    local params = ccTexParams:new()
    params.minFilter = GL_LINEAR
    params.magFilter = GL_LINEAR
    params.wrapS = GL_REPEAT
    params.wrapT = GL_REPEAT
    local sprite =  tolua.cast(img:getVirtualRenderer(),"CCSprite")
    sprite:getTexture():setTexParameters(params)
    sprite:getTexture():setAliasTexParameters()
    local size = img:getSize()
    if size.height > h then h = size.height end
    img:setTextureRect(CCRectMake(0, 0, w, h))
end
function __trainbg.moveBg(obj,offsetx)
    local near = offsetx/kRateNear
    local mid = offsetx/kRateMid
    local far = offsetx/kRateFar
    local cloud = offsetx/kRateCloud
     obj._near:setPosition(ccp(obj._near:getPositionX() + near,obj._near:getPositionY()))
    obj._mid:setPosition(ccp(obj._mid:getPositionX() + mid,obj._mid:getPositionY()))
    obj._far:setPosition(ccp(obj._far:getPositionX() + far,obj._far:getPositionY()))
    obj._cloud:setPosition(ccp(obj._cloud:getPositionX() + cloud,obj._cloud:getPositionY()))
end
function __trainbg.activeCloud(obj)
    local widget = obj:egGetWidgetByName(kImgBg3)
    local function callback(delta)
	--[[]]
        if obj._frameId ==0 then
            obj._frameId = 1
        elseif obj._frameId==1 then
            obj:scrollTrain(kStopPosX - kOffsetX)
            obj._frameId = 2
        end
		--]]
        local x = widget:getPositionX()
        local y = widget:getPositionY()
        local newx = x+kSpeedCloud*obj._cloudDir*delta
        if newx <= kcloudMinX then 
            obj._cloudDir = 1 
            newx = x
        end
        if newx >= kcloudMaxX then 
            obj._cloudDir = -1
            newx = x
        end
        widget:setPosition(ccp(newx,y))
    end
    obj:egBindWidgetUpdate(kImgBg3,callback)
end
function __trainbg.getOwnTrainIdList(obj)
    local owntb = {}
	if not train.order then train.order={0,2,8,6,4,7,99} end
	for key,trainid in ipairs(train.order) do
		if obj._d_data.train[trainid] then
			table.insert(owntb,trainid)
		end
	end
    return owntb
end
function __trainbg.loadOwnTrains(obj)
    obj._trainlist = obj:getOwnTrainIdList()
    obj._trains={}
    obj._selectedTrain = nil
    local cnt = #obj._trainlist
    local x = kOffsetX
    for idx,trainid in ipairs(obj._trainlist) do
        local trainWidget = TownTrain.new(trainid)
        
        local train =  trainWidget:egNode()-- obj:createTrain(trainid)
        local trainsize = train:getSize()
        if idx == 2 then
            x = x + kmarginX0
        elseif idx > 2 then
            x = x + kmarginX
        end
        
        train:setPosition(ccp(x,offsetY))  --(ccp(x + trainsize.width/2,0))  
        obj._scrollTrain:addChild(train,-idx,idx)
        obj._trains[trainid] = trainWidget
        x = x + trainsize.width
        obj:bindTrainClickEvent(trainWidget)
    end
    local size = obj._scrollTrain:getSize()
    local neww = x + kOffsetX
    obj._scrollW = 0
    if neww > size.width then
        obj._scrollTrain:setInnerContainerSize(CCSizeMake(neww,size.height))
        obj._scrollW = neww - size.width
    end
end
--distance ��Ҫ�ƶ��ľ��� ������Ϊ��ֵ
function __trainbg.scrollTrain(obj,distance)
    local curX = obj._scrollTrain:getInnerContainer():getPositionX()
    local newper = -(curX + distance)*100/obj._scrollW
    obj._scrollTrain:scrollToPercentHorizontal(newper,0.5,false)
   --obj._scrollTrain:scrollToPercentHorizontal(50,0.5,false)
end
function __trainbg.reloadTrains(obj)
    for  key,train in pairs(obj._trains) do
        obj._scrollTrain:removeChild(train:egNode(),true)
    end
    obj:loadOwnTrains(obj)
end
function __trainbg.bindScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            local x = obj._scrollTrain:getInnerContainer():getPositionX()
            local moved = x - obj._scrollTrainX
            obj._near:setPosition(ccp(obj._nearX + moved/kRateNear,obj._near:getPositionY()))
            obj._mid:setPosition(ccp(obj._midX + moved/kRateMid,obj._mid:getPositionY()))
            obj._far:setPosition(ccp(obj._farX + moved/kRateFar,obj._far:getPositionY()))
            obj._cloud:setPosition(ccp(obj._cloudX + moved/kRateCloud,obj._cloud:getPositionY()))
         end
    end
    obj._scrollTrain:addEventListenerScrollView(scrollEvent)
end
function __trainbg.bindTrainClickEvent(obj,train)
    local function callback(sender)
        if obj._clickingCallback  then obj._clickingCallback() end
        if obj._selectedTrain ~=sender then
            AccountHelper:lock(kStatePrompt)
            showTrainFunc(sender:getTrainID(),obj._d_data)
            obj._selectedTrain = sender 
            local train = sender:getTrain()
            local endPos = train:getTouchEndPos()
            local posInNode = train:convertToNodeSpace(ccp(endPos.x,endPos.y))
            local posInScroll = obj._scrollTrain:convertToNodeSpace(ccp(endPos.x,endPos.y))
            local xToCenter = obj._scrollTrain:getSize().width/2-posInScroll.x +posInNode.x
            obj:scrollTrain(xToCenter)
        else
            obj._selectedTrain = nil
        end
    end
    train:onClicked(callback)
end
------------------------------------------------------����ר��
--�������ƶ�������
--trainid:�����Ӧ�ı��,�ο�trainConfig
function __trainbg.focusTrain(obj,trainid)
    local sender = obj._trains[trainid]
    if not sender then return end
    local train = sender:getTrain()
    local endPos = train:convertToWorldSpace(ccp(0,0))
    local posInScroll = obj._scrollTrain:convertToNodeSpace(ccp(endPos.x,endPos.y))
    local xToCenter = obj._scrollTrain:getSize().width/2-posInScroll.x
    obj:scrollTrain(xToCenter)
end
function __trainbg.onClicking(obj,callback)
    obj._clickingCallback = callback
end
function __trainbg.clearSelectedTrain(obj)
     obj._selectedTrain = nil
end
--------------------------------------------------------
TrainBgLayer={}
function TrainBgLayer.new(d_data)
    local obj = TouchWidget.new(JsonList.trainBgLayer)
    table_aux.unpackTo(__trainbg, obj)
    obj:init(d_data)
    obj:activeCloud()
    AccountHelper:bind(kTrainLayer,obj)
    return obj
end
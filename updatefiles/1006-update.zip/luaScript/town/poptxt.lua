local kLblTxt = "lbl_txt"
local kImgTxt = "img_bg"
local __poptxt= {}
function __poptxt.init(obj,txt,x,y)
    obj:egNode():ignoreAnchorPointForPosition(false)
    obj:egNode():setAnchorPoint(ccp(0.5,0.5))
    obj:egNode():setPosition(ccp(x,y))
    obj:egSetLabelStr(kLblTxt,txt)
	local widget = obj:egGetWidgetByName(kImgTxt)
    local fadein = CCFadeIn:create(0.3)
    local delayAct = CCDelayTime:create(1)
    local fadeout = CCFadeOut:create(0.2)
    local function callback()
        obj:egRemoveSelf()
    end
    local callfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(fadein)
    array:addObject(delayAct)
    array:addObject(fadeout)
    array:addObject(callfunc)
    local sequence = CCSequence:create(array)
    local size = widget:getSize()
    widget:setPosition(ccp(0,0))
    widget:runAction(sequence)
end
PopTxt = {}
function PopTxt.new(txt,x,y)
      local obj = {}
    CocosWidget.install(obj,JsonList.popTxt)
    table_aux.unpackTo(__poptxt, obj)
    obj:init(txt,x,y)
    return obj
end
function showPopTxt(txt,x,y)
	if not x then x = 640 end
	if not y then y = 360 end
    local layer = PopTxt.new(txt,x,y)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
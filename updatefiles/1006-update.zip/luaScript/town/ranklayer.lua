local kPanelLayer = "rank_panel"
local kBtnBack = "btn_close"
local kLblTime = "lbl_time"
local kLblRank = "lbl_rank"
local kLblUser = "lbl_user_txt"
local kPanelItems = "rank_list"
local kImgLoading = "img_loading"
local kBtnChange= "btn_change"
local kMaxNum = 5
local kCellH = 95
local __ranklayer={}
function __ranklayer.init(obj)
   obj._itemlist = obj:egGetScrollView(kPanelItems)
   obj._listsize = obj._itemlist:getSize()
   obj._items = {}
   obj._loadNum = 0
   obj._loadH = 0
   obj._actH = 0
   obj._kind = 1
   obj:egSetLabelStr(kLblTime,TxtList.eloCalc)
   AccountHelper:lock(kStateEloRank)
   obj:activeWaitTimer()
   SendMsg[931006]()
   obj:showWithAction()
end
--ʱ�䵹��ʱ
function __ranklayer.activeAwardTimer(obj)
    local leftTime = nil
    if obj._kind == 1 then 
        leftTime = account_data.elo_awardTime - os.time()
    else
        leftTime = account_data.honor_awardTime - os.time()
    end    
    local timeTxt = ""
    local function callback(delta)
        leftTime = leftTime - delta
        if leftTime <=0 then
            leftTime = 0
            obj:egUnbindWidgetUpdate(kLblTime)
        end
        local txt = Funs.formatTimeCh(math.ceil(leftTime),true,true,true,nil,true)
        if timeTxt~=txt then
            timeTxt = txt
            obj:egSetLabelStr(kLblTime,string.format(TxtList.eloAwardTime,timeTxt))
        end
    end
    obj:egBindWidgetUpdate(kLblTime,callback)
end
function __ranklayer.loadRank(obj)
    obj:egHideWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    imgWidget:stopAllActions()
    obj:activeAwardTimer()
    local totalCnt = 0
    if obj._kind == 1 then
         totalCnt = #account_data.elo_rank
    else
         totalCnt = #account_data.honor_rank
    end
    obj._actH = kCellH*totalCnt
    if obj._actH > obj._listsize.height then
        local innerContainer = obj._itemlist:getInnerContainer()
        obj._itemlist:setInnerContainerSize(CCSizeMake(obj._listsize.width,obj._actH))
        innerContainer:setPosition(ccp(0,obj._listsize.height-obj._actH))
    end
    obj:addRankItem(kMaxNum)
end
--��λ��ϢͨѶ�ȴ���ʱ��
function __ranklayer.activeWaitTimer(obj)
    obj:egShowWidget(kImgLoading)
    local passed = 0
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
    local function callback(delta)
        passed = passed + delta
        if obj._kind == 1 then
            obj._state = kStateEloRank
        else
            obj._state = kStateHonorRank
        end
		if AccountHelper:isLocked(kStateDisConnected) then --�Ѿ�������ʾ��
			obj:egUnbindWidgetUpdate(kImgLoading)
		else
			if not AccountHelper:isLocked(obj._state) then
				obj:egUnbindWidgetUpdate(kImgLoading)
				obj:loadRank()
			elseif passed > numDef.clientTimeOut then
				obj:egUnbindWidgetUpdate(kImgLoading)
				imgWidget:stopAllActions()
				 local function callback()
					 -- SocketHelper.disconnect()
					  local scene = LogoScene.new()
					  scene:egReplace()
				 end
				local msglayer = MsgLayer.new(nil,TxtList.dataUnMatch,1,callback)
				msglayer:show()
			end
		end
    end
    obj:egBindWidgetUpdate(kImgLoading,callback)
end
--������λ��
function __ranklayer.addRankItem(obj,num)
    local totalCnt = 0
    if obj._kind  == 1 then 
        totalCnt = #account_data.elo_rank
    else
         totalCnt = #account_data.honor_rank
    end
    if obj._loadNum >= totalCnt then return end
    local startIdx = obj._loadNum+1
    local endIdx = math.min(obj._loadNum + num,totalCnt)
    for idx = startIdx,endIdx do
        local rankItem = RankItem.new(idx,obj._kind)
        table.insert(obj._items,rankItem)
        obj._itemlist:addChild(rankItem:egNode())
        obj._loadNum = obj._loadNum+1
        obj._loadH = obj._loadH + kCellH
    end
end
function __ranklayer.bindScrollListener(obj)
    local innerContainer = obj._itemlist:getInnerContainer()
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then 
            if obj._loadH == 0 or (obj._loadH >0 and obj._loadH==obj._actH) then return end
            local posY = innerContainer:getPositionY()
            if obj._loadH - posY  < obj._actH then
                obj:addRankItem(kMaxNum)
            end
        end
    end
    obj._itemlist:addEventListenerScrollView(scrollEvent) 
end
--�رհ���
function __ranklayer.bindBackListener(obj)
    local function touchEnded(sender)
            sender:setTouchEnabled(false)
			if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		    SoundHelper.playEffect(SoundList.click_paper_close)
		    account_data.elo_rank = nil
		    account_data.honor_rank = nil
            obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __ranklayer.hideWithAction(obj,callbackfunc)
    local function callback()
			AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __ranklayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
		baseWidget:runAction(sequece)
	else
		baseWidget:runAction(spawn)
	end
end
--���scrollview����
function __ranklayer.clearList(obj)
    --for idx = 1,obj._itemlist:getChildrenCount() do
    --    item = obj._itemlist:getItem(idx- 1)
    --    obj._itemlist:removeChildByTag(item:getTag(),true)
    --end
    for _,item in ipairs(obj._items) do
        item:egRemoveSelf()
    end
    obj._items = {}
    obj._itemlist:removeAllChildren()
	obj._itemlist:jumpToTop()
	obj._itemlist:setInnerContainerSize(obj._listsize)
    obj._loadNum = 0
    obj._loadH = 0
    obj._actH = 0
end
function __ranklayer.doClickChange(obj,sender)
    if obj._kind == 1 then  -- ������а�
        obj._kind =2 
        obj:clearList()
        obj:egSetLabelStr(kLblRank,TxtList.guildRank)
        obj:egSetLabelStr(kLblUser,TxtList.guildNames)
        if account_data.honor_rank then
            obj:loadRank()
        else
            AccountHelper:lock(kStateHonorRank)
            obj:activeWaitTimer()
            SendMsg[938012]()
        end 
    elseif obj._kind == 2 then --�������а�
        obj._kind = 1  
        obj:clearList()
        obj:egSetLabelStr(kLblRank,TxtList.userRank)
        obj:egSetLabelStr(kLblUser,TxtList.users)
        if account_data.elo_rank then
            obj:loadRank()
        else
            AccountHelper:lock(kStateEloRank)
            obj:activeWaitTimer()
            SendMsg[931006]()
        end 
    end
end
function __ranklayer.bindBtnChangeListener(obj)
    local function touchEnded(sender)
        obj:doClickChange(sender)
	end
    obj:egBindTouch(kBtnChange,nil,nil,touchEnded,nil)
end

RankLayer={}
function RankLayer.new(onloaded)
    local obj =  TouchWidget.new(JsonList.rankLayer)
    table_aux.unpackTo(__ranklayer, obj)
	obj._onloaded = onloaded
    obj:init(d_data)
    obj:bindBackListener()
    obj:bindScrollListener()
    obj:bindBtnChangeListener()
    return obj
end

function showEloRank(onloaded)
    local layer = RankLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

local kImgIcon = "img_icon"
local kLblJournal = "lbl_journal"
local kLblVal = "lbl_val"
local kBtnItem = "btn_item"
local kImgFinish = "img_finish"
local kPanelTask = "panel_task_item"

local kTag1 = 11
local kTag2 = 12
local kTag3 = 13
local kOrder = 6

local __digjournalitem = {}
function __digjournalitem.init(obj,d_data,tid)
   obj:egChangeImg(kImgIcon,d_data.taskpic,UI_TEX_TYPE_PLIST)
   obj:egSetLabelStr(kLblJournal,d_data.taskname)
   obj:egSetLabelStr(kLblVal,string.format("%d/%d",account_data.taskList[tid][1],d_data.tasknum))
   obj._finished = false
   if account_data.taskList[tid][2]== 1 then
       obj:egShowWidget(kImgFinish)
       obj._finished = true
       obj:egHideWidget(kLblVal)
   end
   obj._btnItem = tolua.cast(obj:egGetWidgetByName(kBtnItem),"Button")
   obj:setprop("finished",obj._finished)
end

function __digjournalitem.setFocused(obj,focused)
    if focused then
        obj._btnItem:setFocused(focused)
        obj._btnItem:setTouchEnabled(false)
    else
        obj._btnItem:setFocused(focused)
        obj._btnItem:setTouchEnabled(true)
    end    
end
function __digjournalitem.showFinished(obj)
    if obj._finished == false then
       obj:egShowWidget(kImgFinish)
       obj._finished = true
       obj:setprop("finished",obj._finished)
       obj:egHideWidget(kLblVal)
    end
end
function __digjournalitem.binditemListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        if obj._callback then obj._callback(sender) end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnItem,nil,nil,touchEnded,touchCanceled)
end
function __digjournalitem.showWithAction(obj)
    obj:egHideWidget(kLblVal)
    local imgFinish = obj:egGetWidgetByName(kImgFinish)
    imgFinish:setScale(3)
    imgFinish:setVisible(false)
    --obj._egObj:setPosition(ccp(408,75))  
    local fadein = CCFadeIn:create(0.3)
    local delay = CCDelayTime:create(2)
    local fadeout = CCFadeOut:create(0.3)
    local callfunc2 = CCCallFunc:create(function() obj:egRemoveSelf() end)
    --local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    --local sequece = CCSequence:createWithTwoActions(backout,callfunc1)
    local array = CCArray:create()
    array:addObject(fadein)
    array:addObject(delay)
    array:addObject(fadeout)
    array:addObject(callfunc2)
    obj._egObj:runAction(CCSequence:create(array))
    obj:finishAction()
end
function __digjournalitem.finishAction(obj)
    local imgFinish = obj:egGetWidgetByName(kImgFinish)
    local delay = CCDelayTime:create(0.3)
    local scale = CCScaleTo:create(0.4,0.8)
    local backout = CCEaseBackOut:create(scale)
    local function callback()
        imgFinish:setVisible(true)
    end
    local callfunc1 = CCCallFunc:create(callback)
    local function callback2()
        SoundHelper.playEffect(SoundList.inviteHero)
    end
    local callfunc2 = CCCallFunc:create(callback2)
    local array = CCArray:create()
    array:addObject(callfunc1)
    array:addObject(delay)
    array:addObject(callfunc2)
    array:addObject(backout)
    imgFinish:runAction(CCSequence:create(array))
    --SoundHelper.playEffect(SoundList.inviteHero)
end
function __digjournalitem.onClicked(obj,callback)
    if callback then obj._callback = callback end
end
DigJournalItem = {}
function DigJournalItem.new(d_data,idx,tid)
    local obj = {}
    CocosWidget.install(obj,JsonList.taskItem)
    table_aux.unpackTo(__digjournalitem, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:setprop("task",d_data)
    obj:setprop("idx",idx)
    obj:setprop("tid",tid)
    obj:init(d_data,tid)
    obj:binditemListener()
    return obj
end
function showTaskItem(tid)
    local task_data = taskQuery.getName(tid)
    local layer = DigJournalItem.new(task_data,nil,tid)
    local scene = CCDirector:sharedDirector():getRunningScene()
    local taskitem1 = scene:getChildByTag(kTag1)
    local taskitem2 = scene:getChildByTag(kTag2)
    if taskitem1 and taskitem2 then
        scene:addChild(layer:egNode(),kOrder,kTag3)
        layer:egNode():setPosition(ccp(408,80*3))
    elseif taskitem1 then
        scene:addChild(layer:egNode(),kOrder,kTag2)
        layer:egNode():setPosition(ccp(408,80*2))
    else
        scene:addChild(layer:egNode(),kOrder,kTag1)
        layer:egNode():setPosition(ccp(408,75))
    end    
    layer:showWithAction()    
end





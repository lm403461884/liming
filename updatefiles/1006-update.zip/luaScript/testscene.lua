local __testscene={}
local h = 0
function __testscene.loaddata(obj)
    ZipUtils:setPvrKey(kPvrKey[1],kPvrKey[2],kPvrKey[3],kPvrKey[4])
	local srcpath = "GUIRes/image/sprite/"
	local plist = "bar.plist"
	local pvrccz = "bar.pvr.ccz"
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
    frameCache:addSpriteFramesWithFile(srcpath..plist,srcpath..pvrccz)
end
function __testscene.bindTouchEvent(obj)
    
	local function onTouch(eventType, x,y)
        if eventType == "began" then
            --经验条
			local widget = ImageView:create()
			local sprite = tolua.cast(widget:getVirtualRenderer(),"CCSprite")
			widget:setAnchorPoint(ccp(0,0.5))
			widget:loadTexture("exp_front.png",UI_TEX_TYPE_PLIST)
			local rect = sprite:getTextureRect()
			print(rect.origin.x,rect.origin.y,rect.size.width,rect.size.height)
			--转换类型
			local expbar = tolua.cast(widget,"ImageView")
			local expsize = expbar:getSize()
			widget:setPosition(ccp(x,y))
			obj._layer:addChild(widget)
        end
	end
	obj._layer:registerScriptTouchHandler(onTouch,false,0,true)
	obj._layer:setTouchEnabled(true)
end
TestScene = {}
function TestScene.new()
	local obj = {}
	Scene.install(obj)
	table_aux.unpackTo(__testscene, obj)
	obj._layer = CCLayerColor:create(ccc4(255,255,255,255))
	obj:egAddChild(obj._layer)
    obj:loaddata()
    obj:bindTouchEvent()
    return obj
end

local kBtnOk = "btn_ok"
local kImgTxtBg = "nickname_bg"
local kTbTxt = "tb_nickname"
local kLblWarn1 = "lbl_warn1"
local kLblWarn2 = "lbl_warn2"

__nicknamelayer={}
function __nicknamelayer.bindOkListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods) --确认
		local widget = obj:egGetWidgetByName(kTbTxt)
        local textField = tolua.cast(widget,"TextField")
		account_data.nickName = textField:getStringValue()
		SendMsg[931010](account_data.nickName)
		local scene = StoryScene.new()
        scene:egReplace()
		
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnd,nil) 
end
function __nicknamelayer.bindTxgBgListener(obj)
	 local function touchEnded(sender)
        local widget = obj:egGetWidgetByName(kTbTxt)
        local textField = tolua.cast(widget,"TextField")
        textField:attachWithIME()
    end
    obj:egBindTouch(kImgTxtBg,nil,nil,touchEnded,nil)
end

function __nicknamelayer.bindTxtListener(obj)
     local function textFieldEvent(sender, eventType)
		obj:egHideWidget(kLblWarn2)
        local textField = tolua.cast(sender,"TextField")
        local txt = textField:getStringValue()
        local len_txt = string.len(txt)
		local p_idx = string.find(txt,"[%p,%c]") or 0
		if len_txt <=0 or len_txt > 16 or p_idx > 0 then
			obj:egShowWidget(kLblWarn1)
			obj:egSetWidgetTouchEnabled(kBtnOk,false)
		else
			obj:egHideWidget(kLblWarn1)
			obj:egSetWidgetTouchEnabled(kBtnOk,true)
		end
    end
    local widget = obj:egGetWidgetByName(kTbTxt)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent) 
end
NickNameLayer={}
function NickNameLayer.new()
     local obj=TouchWidget.new(JsonList.nickNameLayer)
	 table_aux.unpackTo(__nicknamelayer,obj)
	 obj:egHideWidget(kLblWarn1)
	 obj:egHideWidget(kLblWarn2)
	 obj:bindOkListener()
	 obj:bindTxgBgListener()
	 obj:bindTxtListener()
	 return obj
end
function showNickNameLayer()
	local layer = NickNameLayer.new()
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
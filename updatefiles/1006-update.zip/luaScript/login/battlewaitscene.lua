
local kPanelWait = "wait_layer"
local kLblTime = "lbl_time"
local kWaitTime = 180  --Ԥ���ȴ�ʱ��
local __battlewaitscene = {}
function __battlewaitscene.init(obj)
    local valstr = Funs.formatTimeCh(kWaitTime,false,false,true,true,false)
    obj._baseWidget:egSetLabelStr(kLblTime,valstr)
    obj:waitBattleEnd()
end
function __battlewaitscene.waitBattleEnd(obj)
    local widgetLbl = obj._baseWidget:egGetWidgetByName(kLblTime)
    local widgetPanel = obj._baseWidget:egGetWidgetByName(kPanelWait)
    local seconds = kWaitTime
    local passTime1 = 0
    local passTime2 = 0
    
    local function callback1(delta)
        passTime1 = passTime1+delta
        passTime2 = passTime2+delta
        --ˢ��ʱ����ʾ
        if passTime1> 1 then
            passTime1 = 0
            --print("time111")
            seconds=seconds - 1
            local valstr = Funs.formatTimeCh(seconds,false,false,true,true,false)
            obj._baseWidget:egSetLabelStr(kLblTime,valstr)
            if seconds == 0 then
               seconds = 11
            end
            
            local state = RSHelper:getState()
			if state == 6 then
				RSHelper:handleRSMsg()
			end	
        end 
        
        --ˢ�µ�½����
        if passTime2 > 10 then 
            passTime2 = 0       
            --print("log111")
            obj._logname = CCUserDefault:sharedUserDefault():getStringForKey("name")
		    obj._logpwd = CCUserDefault:sharedUserDefault():getStringForKey("pwd")
            RSHelper:connect()
	        RSHelper:sendLogMsg(obj._logname,obj._logpwd)
	    end   
    end
    obj._baseWidget:egBindWidgetUpdate(kLblTime,callback1)
end

BattleWaitScene={}
function BattleWaitScene.new()
    local obj = {}
	Scene.install(obj)
	table_aux.unpackTo(__battlewaitscene, obj)
	obj._baseWidget = TouchWidget.new(JsonList.battleWaitLayer)
    obj._baseWidget:egAttachTo(obj)
	obj:init()
	    ----------------------------
	obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
	return obj
end
StoryScene={}
function StoryScene.new()
	SoundHelper.playBGM(SoundList.comic_bgm)
    local obj = {}
	Scene.install(obj)
	--table_aux.unpackTo(__logoscene, obj)
	obj._baseWidget = StoryLayer.new()
    obj._baseWidget:egAttachTo(obj)
	    ----------------------------
	obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
	return obj
end
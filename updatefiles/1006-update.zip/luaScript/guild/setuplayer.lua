local kTextName = "text_input_name"
local kTextInfo = "text_input_info"
local kImgNameBg = "img_name_bg"
local kPanelName = "lbl_name_panel"
local kLblName = "lbl_show_name"
local kImgInfoBg = "img_info_bg"
local kBtnSetup = "btn_setup"
local kLblCost = "lbl_cost"
local kPanelMsg = "msg_layer"
local kLblInfo = "lbl_info"
local kImgLoading = "img_loading"
local kMaxNameLen = 24
local kNeedGold = 99
local kWhiteColor = ccc3(255,255,255)
local kRedColor = ccc3(255,0,0)
local kGrayColor = ccc3(128,128,128)
kStateSetupGuild = "State_setup_guild"
local __setuplayer={}
function __setuplayer.init(obj)
    obj._cost = kNeedGold  --��������۸�
    obj:egSetBMLabelStr(kLblCost,obj._cost)
    obj._nameColor = kWhiteColor
    obj._infoColor = kWhiteColor
    obj:egHideWidget(kPanelMsg)
    obj:egHideWidget(kImgLoading)
    if account_data.gold<obj._cost then
       obj:egSetWidgetEnabled(kBtnSetup,false)
    end
end
function __setuplayer.checkName(obj)
    guild_name = obj:egGetTextFieldVal(kTextName)
    local len = string.len(guild_name)
    if len<1 or len>kMaxNameLen then
        --print("name is too long")
        return false
    end
    local i = string.byte(guild_name)
   -- print("i:"..i)
    if i>=48 and i<=57 then
        return false
    end
    return true
end
function __setuplayer.checkInfo(obj)
    guild_info = obj:egGetTextFieldVal(kTextInfo)
    local len = string.len(guild_info)
    if len>numDef.GuildDescLen then
     --  print("info is too long")
       return false
    end
    return true
end
function __setuplayer.bindNameBgListener(obj)
     local function touchEnded(sender)
         local widget = obj:egGetWidgetByName(kTextName)
         local textField = tolua.cast(widget,"TextField")
         textField:attachWithIME()
     end
     obj:egBindTouch(kImgNameBg,nil,nil,touchEnded,nil)
end

function __setuplayer.bindInfoBgListener(obj)
     local function touchEnded(sender)
         local widget = obj:egGetWidgetByName(kTextInfo)
         local textField = tolua.cast(widget,"TextField")
         textField:attachWithIME()
     end
     obj:egBindTouch(kImgInfoBg,nil,nil,touchEnded,nil)
end

function __setuplayer.bindTextNameListener(obj)
	local lblbg = obj:egGetWidgetByName(kPanelName)
	local size = lblbg:getSize()
	local lblTxt = obj:egGetWidgetByName(kLblName)
	local y = lblTxt:getPositionY()
    local function textFieldEvent(sender)
        local textField = tolua.cast(sender,"TextField")
        local text = textField:getStringValue()
        if text =="" and obj._nameColor == kWhiteColor then
            obj._nameColor = kRedColor
            obj:egSetWidgetColor (kImgNameBg,kRedColor)
        elseif text ~="" and obj._nameColor == kRedColor then
            obj._nameColor = kWhiteColor
            obj:egSetWidgetColor (kImgNameBg,kWhiteColor)   
        end
		if text=="" then
			obj:egSetLabelStr(kLblName,TxtList.promptGuildInput)
			obj:egSetWidgetColor (kLblName,kGrayColor)    
		else
			obj:egSetLabelStr(kLblName,text)
			obj:egSetWidgetColor (kLblName,kWhiteColor)    
		end
		if lblTxt:getSize().width > size.width then
			lblTxt:setPosition(ccp(size.width -lblTxt:getSize().width,y))
		else
			lblTxt:setPosition(ccp(0,y))
		end
    end
    local widget = obj:egGetWidgetByName(kTextName)
	local textField = tolua.cast(widget,"TextField")
    --local text = textField:getStringValue()
    textField:addEventListenerTextField(textFieldEvent)
end
function __setuplayer.bindTextInfoListener(obj)
    local function textFieldEvent(sender)
        local textField = tolua.cast(sender,"TextField")
        local text = textField:getStringValue()
        if text =="" and obj._infoColor == kWhiteColor then
            obj._infoColor = kRedColor
            obj:egSetWidgetColor (kImgInfoBg,kRedColor)
        elseif text ~="" and obj._infoColor == kRedColor then
            obj._infoColor = kWhiteColor
            obj:egSetWidgetColor (kImgInfoBg,kWhiteColor)    
        end
		if text=="" then
			obj:egSetLabelStr(kLblInfo,TxtList.promptMemoInput)
			obj:egSetWidgetColor (kLblInfo,kGrayColor)    
		else
			obj:egSetLabelStr(kLblInfo,text)
			obj:egSetWidgetColor (kLblInfo,kWhiteColor)    
		end
    end
    local widget = obj:egGetWidgetByName(kTextInfo)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent)
end

function __setuplayer.bindSetupListener(obj) -- ��������
    local function touchEnded(sender)
       if not obj:checkName() then 
           obj._clickCallback(1) 
           return 
       end
       if not obj:checkInfo() then 
           obj._clickCallback(2) 
           return 
       end
       obj:egSetWidgetEnabled(kBtnSetup,false)
       obj:actionWait()
       guild_name = obj:egGetTextFieldVal(kTextName)
       guild_info = obj:egGetTextFieldVal(kTextInfo)
       AccountHelper:lock(kStateSetupGuild)
       SendMsg[938001](guild_name,guild_info)
      -- SendMsg[938002]()
       obj:activeUpdata()
       account_data.gold = account_data.gold - obj._cost --�ı���
    end
    obj:egBindTouch(kBtnSetup,nil,nil,touchEnded,nil)
    
end
--��������ȴ�����
function __setuplayer.actionWait(obj)
    obj:egShowWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
end

function __setuplayer.onClicked(obj,callback)
    obj._clickCallback = callback
end

function __setuplayer.activeUpdata(obj)
    local function callback()
        if club_data then   
           if club_data.cid then
               if obj._clickCallback then obj._clickCallback(3) end
               --local scene = GuildScene.new()
               --scene:egReplace()
               local imgWidget = obj:egGetWidgetByName(kImgLoading)
               imgWidget:stopAllActions()
               obj:egHideWidget(kImgLoading)
               obj._egObj:unscheduleUpdate()
           end    
        end   
        if not AccountHelper:isLocked(kStateSetupGuild) then
           if obj._clickCallback then obj._clickCallback(4) end
           obj:egSetWidgetEnabled(kBtnSetup,true)
           local imgWidget = obj:egGetWidgetByName(kImgLoading)
           imgWidget:stopAllActions()
           obj:egHideWidget(kImgLoading)
           obj._egObj:unscheduleUpdate()
        end
        
    end    
    obj:egBindUpdateWithPriorityLua(callback)
end

SetupLayer={}
function SetupLayer.new()
    local obj = {}
    CocosWidget.install(obj,JsonList.setupLayer)
    table_aux.unpackTo(__setuplayer, obj)
    obj:init()
    obj:bindSetupListener()
    obj:bindTextNameListener()
    obj:bindTextInfoListener()
    obj:bindNameBgListener()
    obj:bindInfoBgListener()
    return obj
end
local kBtnAgree = "btn_agree"
local kBtnRefuse = "btn_refuse"

local kLblName = "lbl_name"
local kLblChatInfo = "lbl_info"
local kLblTime = "lbl_time"
local kLblTitle = "lbl_title"
local kLblDeal = "lbl_deal"
local kLblLv = "lbl_lv"

local kPanelLayer = "panel_msg"
local kPanelTile = "panel_title"
local kPanelInfo = "panel_info"
local kPanelBtn = "btn_panel"

local kTxtW = 535
local kTxtH = 27
local kMinH1 = 95
local __msgItem={}

function __msgItem.init(obj,mid)
   obj._mid = mid
   obj._msg = club_data.message[obj._mid]
   obj._type = obj._msg.type
   obj._guid = obj._msg.guid
   obj._panel = obj:egNode()
   obj._panel:ignoreContentAdaptWithSize(false)
   obj._size = obj._panel:getSize()
   obj._lblWidget = tolua.cast(obj:egGetWidgetByName(kLblChatInfo),"Label")
   obj:egHideWidget(kLblTitle) --��ʱû�д�����
   obj:egHideWidget(kLblLv)
   obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",obj._msg.date))
   if obj._msg.type == 1 then
       obj:loadJoinInfo() --���������Ϣ
   elseif obj._msg.type == 3 then 
       obj:loadChatInfo() --������Ϣ
   elseif obj._msg.type == 90 then
       obj:loadClientInfo() --�ͻ���������ʾ��Ϣ
   end
end
function __msgItem.showBtnPanel(obj,show)
	if show then
		obj:egShowWidget(kBtnAgree)
		obj:egShowWidget(kBtnRefuse)  
		obj:egShowWidget(kPanelBtn)
		obj:bindAgreeListener()
		obj:bindRefuseListener()
	else
		obj:egHideWidget(kBtnAgree)
		obj:egHideWidget(kBtnRefuse)  
		obj:egHideWidget(kLblDeal)  
		obj:egHideWidget(kPanelBtn)
	end
end
--������Ϣ
function __msgItem.loadChatInfo(obj)
	obj:showBtnPanel(false)--����
    if obj._msg.guid == club_data.managerID then
        obj:egShowWidget(kLblTitle)
    end
    obj:egSetLabelStr(kLblName,club_data.members[obj._msg.guid].name) 
	obj:egShowWidget(kLblLv)
	obj:egSetBMLabelStr(kLblLv,club_data.members[obj._msg.guid].digLv)
    obj._lblWidget:setText(obj._msg.content)
    obj:resizeMsgItem()
    
end
function __msgItem.resizeMsgItem(obj)
    local size = obj._lblWidget:getSize()
    local rows = math.ceil(size.width/kTxtW)
    local lblh = rows*kTxtH
    local panelh = kMinH1 + (rows-1)*kTxtH
    obj._lblWidget:setTextAreaSize(CCSizeMake(kTxtW,lblh))
    obj._panel:setSize(CCSizeMake(obj._size.width,panelh))
    local panelTile = obj:egGetWidgetByName(kPanelTile)
    local panelInfo = obj:egGetWidgetByName(kPanelInfo)
    local infoSize = panelInfo:getSize()
    obj._lblWidget:setPosition(ccp(0,lblh))
    panelInfo:setSize(CCSizeMake(infoSize.width,lblh))
    panelTile:setPosition(ccp(0,panelh - panelTile:getSize().height))
    panelInfo:setPosition(ccp(panelInfo:getPositionX(),panelh - panelTile:getSize().height - lblh + 10))
end
--�ͻ���������ʾ��Ϣ
function __msgItem.loadClientInfo(obj)
	obj:showBtnPanel(false)--����
    obj:egSetLabelStr(kLblName,obj._msg.name)
    obj._lblWidget:setText(obj._msg.content)
    obj:resizeMsgItem()
end
--���������Ϣ
function __msgItem.loadJoinInfo(obj)
	local panelbtn = obj:egGetWidgetByName(kPanelBtn)
	local px = panelbtn:getPositionX()
	local py = panelbtn:getPositionY()
    obj:egSetLabelStr(kLblName,obj._msg.name)
    obj._lblWidget:setText(TxtList.guildMsg[6])
    if obj._msg.state == 0 then
         obj:showBtnPanel(true)--��ʾ
         obj:egHideWidget(kLblDeal)  
    elseif obj._msg.state == 1 then
        obj:showBtnPanel(false)--��ʾ 
        obj:egShowWidget(kLblDeal)  
        obj:egSetLabelStr(kLblDeal,TxtList.guildMsg[1])
		obj:resizeMsgItem()
    else
        obj:showBtnPanel(false)--��ʾ 
        obj:egShowWidget(kLblDeal)  
        obj:egSetLabelStr(kLblDeal,TxtList.guildMsg[2]) 
		obj:resizeMsgItem()
    end
end
---------ͬ����빫��
function __msgItem.bindAgreeListener(obj) 
    local function touchEnded (sender)
        obj:showBtnPanel(false) 
		obj:egShowWidget(kLblDeal)
		obj:resizeMsgItem()
        obj:egSetLabelStr(kLblDeal,TxtList.guildMsg[1])
        obj._msg.state = 1
        SendMsg[938005](obj._mid,1)
    end
    obj:egBindTouch(kBtnAgree,nil,nil,touchEnded,nil)    
end
  ----------�ܾ����빫��
function __msgItem.bindRefuseListener(obj)
    local function touchEnded (sender)
        obj:showBtnPanel(false)
		obj:egShowWidget(kLblDeal)
		obj:resizeMsgItem()
        obj:egSetLabelStr(kLblDeal,TxtList.guildMsg[2])  
        club_data.message[obj._mid].state = 2
        SendMsg[938005](obj._mid,2)
    end
    obj:egBindTouch(kBtnRefuse,nil,nil,touchEnded,nil)    
end

MsgItem = {}
function MsgItem.new(mid)
   local obj ={}
   CocosWidget.install(obj,JsonList.msgItem)
   BaseProp.install(obj)
   InnerProp.install(obj)
   table_aux.unpackTo(__msgItem,obj)
   obj:init(mid)
   return obj
end
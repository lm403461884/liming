
local kLblName = "lbl_name"
local kLblChatInfo = "lbl_info"
local kLblTime = "lbl_time"
local kLblDigLv = "lbl_digLv"

local kPanelLayer = "panel_msg"
local kPanelMsg = "panel_pub_msg"
local kPanelTile = "panel_title"
local kPanelInfo = "panel_info"

local kTxtW = 535
local kTxtH = 27
local kMinH1 = 95

local __msgItem={}

function __msgItem.init(obj,msg)
   local panel = obj:egNode()
   panel:ignoreContentAdaptWithSize(false)
   local panelsize = panel:getSize()
   local lblInfo = tolua.cast(obj:egGetWidgetByName(kLblChatInfo),"Label")
   obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",msg.date))
   obj:egSetLabelStr(kLblName,msg.name) 
   obj:egSetBMLabelStr(kLblDigLv,msg.digLv)
   lblInfo:setText(msg.content)
   local size = lblInfo:getSize()
   local rows = math.ceil(size.width/kTxtW)
   local lblh = rows*kTxtH
   local panelh = kMinH1 + (rows-1)*kTxtH
   lblInfo:setTextAreaSize(CCSizeMake(kTxtW,lblh))
   panel:setSize(CCSizeMake(panelsize.width,panelh))
   local panelTile = obj:egGetWidgetByName(kPanelTile)
   lblInfo:setPosition(ccp(lblInfo:getPositionX(),lblh))
   panelTile:setPosition(ccp(0,panelh - panelTile:getSize().height))
   lblInfo:setPosition(ccp(lblInfo:getPositionX(),panelh - panelTile:getSize().height+ 10))
   if msg.guid == 0 then
		obj:egHideWidget(kLblDigLv)
   end
end
function __msgItem.onItemClicking(obj,callback)
	obj._clickingCallback = callback
end
function __msgItem.onItemClicked(obj,callback)
	obj._clickedCallback = callback
end

function __msgItem.bindPanelListener(obj)
    local function touchBegan(sender)
        if obj._clickingCallback then obj._clickingCallback(obj) end
    end
    local function touchEnd(sender)
         if obj._clickedCallback then obj._clickedCallback(obj,sender:getTouchEndPos()) end
    end
    obj:egBindTouch(kPanelMsg,touchBegan,nil,touchEnd,nil)
end
PubMsgItem = {}
function PubMsgItem.new(msg)
   local obj ={}
   CocosWidget.install(obj,JsonList.pubMsgItem)
   table_aux.unpackTo(__msgItem,obj)
   BaseProp.install(obj)
   InnerProp.install(obj)
   obj:setprop("guid",msg.guid)
   obj:setprop("clubid",msg.clubid)
   obj:setprop("name",msg.name)
    obj:setprop("clubname",msg.clubname)
    obj:setprop("msg",msg)
   obj:init(msg)
   obj:bindPanelListener()
   return obj
end
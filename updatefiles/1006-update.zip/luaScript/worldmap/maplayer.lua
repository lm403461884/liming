local kBtnBack = "btn_back"
local kPanelTouch = "map_touch_panel"
local kPanelLbl = "num_panel"
local kYellowColor = ccc3(255,255,0)
local kBrownColor = ccc3(63,38,38)
--local kWhiteColor = ccc3(255,255,255)
local __maplayer={}
local function __getUncompletedStageCount(areaid,pveArea)--{{{
    local nmdata = missionData.normal_mission[areaid]
    local cnt = 0
    for key,stageid in ipairs(nmdata) do
		--ֻ��ʾ�ѽ�����������
       --if not pveArea[stageid] or pveArea[stageid].stars == 0 then
         --   cnt = cnt + 1
       -- end
	   if  pveArea[stageid] and pveArea[stageid].stars == 0 then
            cnt = cnt + 1
        end
    end
	local dmdata = MissionHelper.getClientMission()
    local areadmdata = dmdata[areaid] or {}
	for groupidx,_ in ipairs(areadmdata) do 
		if MissionHelper.getStageId(areaid,groupidx) then cnt = cnt + 1 end
	end
	return cnt
end--}}}
function __maplayer.init(obj)
    obj._touchAreaID = 0
    obj._areaSprites = {}
	--����PVE��� ���������ͼ
	for areaID, area in pairs(account_data.unlockedPVE) do
		--����ѽ�������Ľ��沼��
		if area[1] then
		    local widgetName = 'touch_area_'..areaID
		    local img = tolua.cast(obj:egGetWidgetByName(widgetName),"ImageView")
		    local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
		    obj._areaSprites[areaID] = sprite
			--�޳���������
			local maskCtrl = obj:egGetWidgetByName('mask_'..areaID)
			maskCtrl:runAction(CCFadeOut:create(1))
			obj:showMissionNum(areaID,area)
		end
	end
end
--��ʾ����δ������۵Ĺؿ���
function __maplayer.showMissionNum(obj,areaID,area)
	--��ʾ��ǰ����δ��������ǵĹؿ�����
	local cnt = __getUncompletedStageCount(areaID,area)
	if cnt > 0 then
		local text = Label:create()
		text:setText(tonumber(cnt))
		text:setFontName(FNList.STENCIL)
		text:setFontSize(30)
		text:setColor(kBrownColor)
		local labelCtrl = obj:egGetWidgetByName('label_'..areaID)
		if areaID == licenceLevelup[account_data.digLv].areaID then
		    labelCtrl:setColor(kYellowColor) 
		   -- text:setColor(kWhiteColor)
		--else
		   --s text:setColor(kBrownColor)
		end
		local x = labelCtrl:getPositionX()
		local y = labelCtrl:getPositionY()
		text:setPosition(ccp(x+3,y))
		obj:egAddChildTo(kPanelLbl,text)
		labelCtrl:setVisible(true)
		labelCtrl:runAction(CCFadeIn:create(1.5))
		text:runAction(CCFadeIn:create(1.5))
		local scaleAction1 = CCRepeatForever:create(CCSequence:createWithTwoActions(CCScaleTo:create(0.8, 0.8), CCScaleTo:create(0.8, 0.73)))
		local scaleAction2 = CCRepeatForever:create(CCSequence:createWithTwoActions(CCScaleTo:create(0.8, 0.8), CCScaleTo:create(0.8, 0.73)))
		labelCtrl:runAction(scaleAction1)
		text:runAction(scaleAction2)
	end
end
--��ȡ��ǰ���������ID,�޵������ʱ����0
function __maplayer.getTouchedAreaID(obj,pos)
    for areaid,sprite in pairs(obj._areaSprites) do
        local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
        if not isalpha then
            return areaid
        end
	end
	return 0
end
--��ͼ�����������¼�
function __maplayer.bindTouchListener(obj)
    local function touchBegan(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		local pos =sender:getTouchStartPos()
		obj._touchAreaID = obj:getTouchedAreaID(pos)
		if obj._touchAreaID > 0 then
		    obj._areaSprites[obj._touchAreaID]:setScale(1.05)
		end
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._touchAreaID > 0 then
            local scaleto = CCScaleTo:create(0.3, 1.2)
            local fadeout = CCFadeOut:create(0.3)
            local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
            local transcation = CCSequence:createWithTwoActions(
                                spawn,
                                CCCallFunc:create(function()
                                    sender:setTouchEnabled(true)
                                    local scene = MissionScene.new(obj._touchAreaID)
                                    scene:egReplace()
                                    obj._touchAreaID = 0
                                end))
            local sprite = obj._areaSprites[obj._touchAreaID]
            sprite:runAction(transcation)
        else
            sender:setTouchEnabled(true)
		end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			if obj._touchAreaID > 0 then
				obj._areaSprites[obj._touchAreaID]:setScale(1)
			end
			obj._touchAreaID = 0
		end
    end
    obj:egBindTouch(kPanelTouch,touchBegan,nil,touchEnded,touchCanceled)
end
function __maplayer.bindBackListener(obj)
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
		local scene = TownScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __maplayer.bindExitEvent(obj)
	local function unloadSpriteFrame()
		--ɾ��Plist��Ӧ�ľ���֡
		graphicLoader.unloadFrameWithFile(KVariantList.matImgList,KVariantList.mapPvrPath)
	end
	obj:egOnExit(unloadSpriteFrame)
end
MapLayer = {}
function MapLayer.new()
	graphicLoader.loadFrameWithFile(KVariantList.matImgList,KVariantList.mapPvrPath) --����ͼƬ��Դ
	local obj =  TouchWidget.new(JsonList.worldmapScene)
    table_aux.unpackTo(__maplayer, obj)
    obj:init()
	obj:bindBackListener()
	obj:bindTouchListener()
	obj:bindExitEvent()
	return obj
end
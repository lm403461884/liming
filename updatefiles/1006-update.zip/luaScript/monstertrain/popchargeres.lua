local kBtnClose="btn_close_charge"
local kBtnCharge="btn_charge"
local kImgBg = "img_charge_bg"
local kImgCoin = "img_charge_jewel"
local kLblNeedVal = "lbl_need_jewel_val"
local __popcharge={}
function __popcharge.init(obj,coinName,needVal)
	obj._coinName = coinName
	local bg = obj:egGetWidgetByName(kImgBg)
	obj:egSetLabelStr(kLblNeedVal,needVal)
	obj:egChangeImg(kImgCoin,ImageList[string.format("comm_%s",coinName)],UI_TEX_TYPE_PLIST)
	bg:setScale(0)
	local scaleto = CCScaleTo:create(0.5,1)
	local backout =CCEaseBackOut:create(scaleto)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequence = CCSequence:createWithTwoActions(backout,callfunc)
		bg:runAction(sequence)
	else
		bg:runAction(backout)
	end
end
--��ֵ��ť
function __popcharge.bindChargeListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCharge,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __popcharge.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

PopChargeRes={}
function PopChargeRes.new(coinName,needVal,onloaded)
    local obj =  TouchWidget.new(JsonList.popCharge)
    table_aux.unpackTo(__popcharge, obj)
    obj._onloaded = onloaded
    obj:init(needVal)
    obj:bindChargeListener()
    obj:bindCloseListener()
    return obj
end

function showPopChargeRes(coinName,needVal,onloaded)
	local layer =  PopChargeRes.new(coinName,needVal,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

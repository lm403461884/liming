
MonsterScene={}
function MonsterScene.new()
    local obj = {}
    Scene.install(obj)
	obj._baseWidget = MonsterLayer.new()
	obj._baseWidget:egAttachTo(obj)
	showEmDialog(obj,GuideScene.def.kMonsterScene) --加载引导项
	-------------
	obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
	return obj
end
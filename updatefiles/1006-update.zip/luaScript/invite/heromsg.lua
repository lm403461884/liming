local kImgCoin = "img_coin"
local kLblVal = "lbl_coin_val"
local __heromsg = {}
function __heromsg.init(obj,heroid,num)
    local s_cfg =  hero_data.getConfig(heroid)
    if not s_cfg then print("can not find hero data with ID:",heroid) end
    obj:egChangeImg(kImgCoin,s_cfg.headPic,UI_TEX_TYPE_PLIST)
   
    obj:egSetLabelStr(kLblVal,num)
	local lbl = obj:egGetWidgetByName(kLblVal)
	local panelsize = obj:egNode():getSize()
	obj:egNode():setSize(CCSizeMake(lbl:getPositionX() + lbl:getSize().width + 30,panelsize.height))
end
HeroMsg={}
function HeroMsg.new(heroid,num)
    local obj = {}
    CocosWidget.install(obj,JsonList.heroMsg)
    table_aux.unpackTo(__heromsg, obj)
    obj:init(heroid,num)
    return obj
end

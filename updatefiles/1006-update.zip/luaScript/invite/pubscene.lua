PubScene = {}
function PubScene.new()--{{{
	local obj = {}
    Scene.install(obj)
	SoundHelper.playBGM(SoundList.shop_bgm)
	SoundHelper.playEffect(SoundList.shop_door_open)
	obj._baseWidget = PubLayer.new()
	obj._baseWidget:egAttachTo(obj)
	obj._propWidget = PropLayer.new()
    obj._propWidget:egAttachTo(obj)
	showEmDialog(obj,GuideScene.def.kPubScene) --����������
	-------------
	obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
	return obj
end

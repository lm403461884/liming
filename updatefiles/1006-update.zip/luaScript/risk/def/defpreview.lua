local kLblTitle = "lbl_title"
local kImgStar={"img_star1","img_star2","img_star3"}
local kListview1 = "list_atk_hero"
local kListview2 = "list_atk_hero2"
local kPanelAward1 = "panel_award1"
local kPanelAward2 = "panel_award2"
local kLblPower = "lbl_power"
local kBtnStart = "btn_start"
local kBtnBack = "btn_back"
local kImgBg = "img_bg"
local kPanelLayer = "panel_task_pre"

local kMaxLoadNum = 3
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)

defHeroList = {}

local __defpreview={}
function __defpreview.init(obj,guardID)
    obj._guardID = guardID
    obj._defdata = pveGuardQuery.getName(guardID)
    obj:egSetLabelStr(kLblTitle,obj._defdata.name)
    obj:egSetLabelStr(kLblPower,string.format("%s%d",TxtList.numSymbol,obj._defdata.costAct))
    obj:egHideWidget(kBtnBack)
    if account_data.actPt < obj._defdata.costAct then
        obj:egSetWidgetColor(kLblPower,kRedColor)
        obj:egSetWidgetEnabled(kBtnStart,false)
        obj:activeUpdate()
    end
    obj:loadHeros()
    obj:loadAward()
    obj:showWidthAction()
end
function __defpreview.loadHeros(obj)
    local listview1 = obj:egGetListView(kListview1)
    local size1 = listview1:getSize()
    local listview2 = obj:egGetListView(kListview2)
    local size2 = listview2:getSize()
    local count = 0
    local herolist = pveGuardQuest.pveGuardheroLv(account_data,obj._guardID)
    defHeroList=herolist
    for idx,heroid in ipairs (obj._defdata.team) do
        count = count + 1
        local herodata =herolist[heroid]
        heroHead = HeroHead.new(heroid,herodata.lv)
        if idx <= 4 then
            listview1:pushBackCustomItem(heroHead:egNode())
        else
            listview2:pushBackCustomItem(heroHead:egNode())
        end    
    end
    if count <= 4 then  --Ӣ�۾�����ʾ
        local posX,posY = listview1:getPosition()
        listview1:setPosition(ccp(posX+size1.width/2-count*55,posY))
    else
        local posX,posY = listview2:getPosition()
        listview2:setPosition(ccp(posX+size2.width/2-(count-4)*55,posY))
    end
end
function __defpreview.loadAward(obj)
    local awardList = obj:getAwardList()
    local maxCount = #awardList
    local margin = 149 --��item��ľ���
    local panel1 = obj:egGetWidgetByName(kPanelAward1)
    local size1 = panel1:getSize()
    local panel2 = obj:egGetWidgetByName(kPanelAward2)
    local size2 = panel2:getSize()
    local count = 0
    for idx,award in ipairs (awardList) do
        local awarditem = AwardItem.new(award[1],string.format("%s%d",TxtList.numSymbol,award[2]))
        count = count  + 1 
        if count <= kMaxLoadNum then 
            panel1:addChild(awarditem:egNode())
            local posX,posY = awarditem:egNode():getPosition()
            awarditem:egNode():setPosition(ccp(posX + margin*(count-1),posY))
        elseif count<= kMaxLoadNum*2 then
            panel2:addChild(awarditem:egNode())
            local posX,posY = awarditem:egNode():getPosition()
            awarditem:egNode():setPosition(ccp(posX + margin*(count-4),posY))
        end           
    end
    if count <= kMaxLoadNum then  --����������ʾ
        local posX,posY = panel1:getPosition()
        panel1:setPosition(ccp(posX+size1.width/2-margin/2*count,posY))
    else
        local posX,posY = panel2:getPosition()
        panel2:setPosition(ccp(posX+size2.width/2-margin/2*(count-3),posY))
    end
end
--��ȡ������Ϣ
function __defpreview.getAwardList(obj)
    local award_data = pveGuardQuest.pveGuardprize(account_data,obj._guardID)
    local awardList = {}
    if award_data.gold >0 then table.insert(awardList,{"gold",award_data.gold}) end
    if award_data.iron >0 then table.insert(awardList,{"iron",award_data.iron}) end
    if award_data.copper >0 then table.insert(awardList,{"copper",award_data.copper}) end
    if award_data.stoneR >0 then table.insert(awardList,{"stoneR",award_data.stoneR}) end
    if award_data.stoneB >0 then table.insert(awardList,{"stoneB",award_data.stoneB}) end
    if award_data.stoneD >0 then table.insert(awardList,{"stoneD",award_data.stoneD}) end
    return awardList
end
function __defpreview.showWidthAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kImgBg)
    widget:runAction(CCFadeIn:create(0.4))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(baseWidget:getPositionX(),720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(baseWidget:getPositionX(),0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    local function callback()
        if obj._onloaded then obj._onloaded()end
        obj:bindCloseListener()
        obj:egShowWidget(kBtnBack)
    end
    local callfunc = CCCallFunc:create(callback)
	local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
	baseWidget:runAction(sequece)
end
function __defpreview.onClicked(obj,callback)
    obj._callback = callback
end
--�ر�ҳ��
function __defpreview.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,nil)
end
function __defpreview.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

--��ʼ��ť
function __defpreview.bindStartListener(obj)
    local function touchEnded(sender)
        AccountHelper:lock(kStateDefBattle)
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
        account_data.actPt = account_data.actPt - obj._defdata.costAct
        local scene = DefScene.new(obj._idx)
        scene:egReplace()
    end  
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end  
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
function __defpreview.activeUpdate(obj)
    local function callback()
         if obj._defdata.costAct <= account_data.actPt then 
            obj:egSetWidgetColor(kLblPower,kWhiteColor) 
            obj:egSetWidgetEnabled(kBtnStart,true)
            obj:egUnbindWidgetUpdate(kBtnStart)
        end
    end
    obj:egBindWidgetUpdate(kBtnStart,callback)
end
DefPreview={}
function DefPreview.new(guardID,onload,idx)
    local obj =  TouchWidget.new(JsonList.defTaskPre)
    table_aux.unpackTo(__defpreview, obj)
    obj._onloaded = onload
    obj._idx = idx
    obj:init(guardID)
    obj:bindStartListener()
    obj:bindBackListener()
    return obj
end

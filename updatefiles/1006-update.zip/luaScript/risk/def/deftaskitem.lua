local kLblTitle = "lbl_def_title"
local kBtnClick = "btn_def_task"

local __deftaskitem = {}
function __deftaskitem.init(obj,guardID)
    obj._defdata = pveGuardQuery.getName(guardID)
    obj:egSetLabelStr(kLblTitle,obj._defdata.name)
end
function __deftaskitem.bindClickListener(obj)
    local function touchEnded(sender)
       SoundHelper.playEffect(SoundList.click_paper_open)
       obj:egSetWidgetTouchEnabled(kBtnClick,false)
       if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
       local function callback() obj:egSetWidgetTouchEnabled(kBtnClick,true) end
       if obj._callback then obj._callback(callback) end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClick,nil,nil,touchEnded,touchCanceled)
end
function __deftaskitem.onClicked(obj,callback)
    obj._callback = callback
end
DefTaskItem={}
function DefTaskItem.new(guardID)
    local obj = {}
    CocosWidget.install(obj,JsonList.defTaskItem)
    table_aux.unpackTo(__deftaskitem,obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:setprop("guardID",guardID)
    obj:init(guardID)
    obj:bindClickListener()
    return obj
end
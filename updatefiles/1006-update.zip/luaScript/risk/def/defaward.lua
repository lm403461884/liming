local kPanelAward = "award_list"
local kPanelLayer = "panel_award"
local kBtnClose = "btn_close"

local __defaward={}
function __defaward.init(obj)
    local awardlist = pveGuardQuest.totlePrizes[account_data.digLv]
	local panelaward = obj:egGetListView(kPanelAward)
	local maxW = 0
	local itemW = 0
	local tempW = 0
	obj._awardList = {}
	for key,val in ipairs(awardlist) do
		local awarditem = DefAwardItem.new(val)
		panelaward:pushBackCustomItem(awarditem:egNode())
		tempW = awarditem:getShownW()
		if maxW < tempW then maxW = tempW end
		itemW = awarditem:getItemW()
		table.insert(obj._awardList,awarditem)
	end
	local offsetx = (itemW - maxW)/2
	if offsetx< 0 then offsetx = 0 end
	for key,item in ipairs(obj._awardList) do
		item:reLocateLine(offsetx)
	end
	--panelaward:setPosition(ccp(panelaward:getPositionX() +offsetx ,panelaward:getPositionY()))
   obj:showWithAction(obj._onload)
end
function __defaward.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelLayer)
    widget:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveTo:create(0.3,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end
function __defaward.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,touchCanceled)
end
function __defaward.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
DefAward={}
function DefAward.new(onload)
    local obj = TouchWidget.new(JsonList.defAward)
    table_aux.unpackTo(__defaward,obj)
    obj._onload = onload
    obj:init()
    obj:bindPanelListener()
	obj:bindCloseListener()
    return obj
end

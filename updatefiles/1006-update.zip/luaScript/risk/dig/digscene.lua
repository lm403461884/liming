
local kGroundOrder = 1
local kPropOrder = 3
local kBaseOrder = 2
local kSendInterval = 5

local __digscene={}

function __digscene.activeUpdate(obj)
    local function update()
        if os.time() - obj._timeStamp  >= kSendInterval then
            SendMsg[932001]()
            obj._timeStamp = os.time()
        end
    end
    local function clear()
        SendMsg[932001]()
    end
     obj:egBindUpdate(update,clear)
end
function __digscene.init(obj)
    obj._d_data = RiskHelper.getDigSceneData()
    obj._timeStamp = os.time()
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    obj._groundlayer:showInDigScene()
	
    obj._baseWidget = DigLayer.new(obj._d_data)
    obj._baseWidget:egAttachTo(obj,kBaseOrder,kBaseOrder)
    obj._propWidget = PropLayer.new(account_data)
    obj._propWidget:egAttachTo(obj,kPropOrder,kPropOrder)

end
DigScene={}
function DigScene.new()
    SoundHelper.playBGM(SoundList.dig_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__digscene, obj)
    obj:init()
    obj:activeUpdate()
    showEmDialog(obj,GuideScene.def.kDigScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
local kcellW = 72
local kcellH = 72 

local kMonsterZorder = 1
local kFlagZorder = 2
local kHeroZorder = 4
local kResCarZorder = 3
local kBulletZorder = 6
local kBrokenZorder = 7
local kBloodZorder = 5
local kMaskZorder = 8
local kFocusZorder = 9
local __creaturelayer = {}
function __creaturelayer.initlayer(obj,d_data)
    obj._d_data = d_data
    obj._matrixW =d_data.w
    obj._matrixH = d_data.h
    obj._entraIdx = d_data.entraIdx
	obj._activeResCarAI = false
	obj._monsterOpacity = 255
    obj._monsters = {}
    obj._monsterFlags={}
    obj._heros = {}
    obj._bullets = {}
	obj._monsterCnt={}
	obj._rescars={}
	obj._masklayer = CCLayerColor:create(ccc4(0,0,0,255))
	obj._masklayer:setContentSize(CCSizeMake(obj._matrixW*kcellW,(obj._matrixH+10)*kcellH))
	obj:egAddChild(obj._masklayer,kMaskZorder,kMaskZorder)
	obj._masklayer:setVisible(false)
end
function __creaturelayer.focusHero(obj,heroObj,focus)
    if not heroObj or not heroObj:egNode() then 
		obj._masklayer:setVisible(false)
	else
		if focus then
			obj:egNode():reorderChild(heroObj:egNode(),kFocusZorder)
			obj._masklayer:setVisible(true)
			obj._masklayer:setOpacity(0)
			obj._masklayer:runAction(CCFadeTo:create(0.2,160))
		else
			obj:egNode():reorderChild(heroObj:egNode(),kHeroZorder)
			obj._masklayer:setVisible(false)
		end
	end
end
--��̬����Ӣ��
function __creaturelayer.showHeros(obj,x,y,moveDis,sec)
    local spread = obj._d_data.teamList
    for idx,heroid in ipairs(spread) do
        local herodata =obj._d_data.heroList[heroid]
        local pos = obj._entraIdx
        local hero = Hero.new(herodata,pos,obj._d_data)
        table.insert(obj._heros,hero)
        hero:egSetPos(x-(idx-1)*kcellW,y)
        hero:egAttachTo(obj,kHeroZorder,pos)
        hero:moveToward(90,moveDis,sec)
        hero:setprop("isEmemy",obj._d_data.dfs == account_data.guid)--�����Ӫ
        hero:bindBlood(obj,kBloodZorder)
        hero:hideHP()
    end       
end
function __creaturelayer.getSortedMonsters(obj)
    local tb = {}
    local spread = obj._d_data.creatureList
    for idx,_ in pairs(spread) do
        table.insert(tb,idx)
    end
    table.sort(tb)
    return tb
end
--�������й�����Ϣ
function __creaturelayer.loadAllMonster(obj)
    local spread = obj._d_data.creatureList
    local posTb = obj:getSortedMonsters()
    for key,idx in ipairs(posTb) do
        local mtype = spread[idx]
        local lv = obj._d_data.monsterLvLook[mtype]
		local monster = Monster.new(mtype,lv,idx)
		local x,y = obj:getPosByIdx(idx)
		monster:egSetPos(x,y)
		monster:egAttachTo(obj,kMonsterZorder,idx)
		table.insert(obj._monsters,monster)
		if not obj._monsterCnt[mtype] then obj._monsterCnt[mtype] = 0 end
		obj._monsterCnt[mtype] = obj._monsterCnt[mtype] + 1  --ָ�����͵Ĺ���ֲ�������1
		monster:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
		monster:bindBlood(obj,kBloodZorder)
		monster:openAi() --����AI,��ʾѪ��
    end
end
--�������й�����Ϣ,��������ʾ����--�ھ�ӵ���
function __creaturelayer.loadMonstersWithOpacity(obj)
    local spread = obj._d_data.creatureList
    for idx,mtype in pairs(spread) do
		local lv = obj._d_data.monsterLvLook[mtype]
		local monster = Monster.new(mtype,lv,idx)
		local x,y = obj:getPosByIdx(idx)
		monster:egSetPos(x,y)
		monster:egAttachTo(obj,kMonsterZorder,idx)
		table.insert(obj._monsters,monster)
		if not obj._monsterCnt[mtype] then obj._monsterCnt[mtype] = 0 end
		obj._monsterCnt[mtype] = obj._monsterCnt[mtype] + 1  --ָ�����͵Ĺ���ֲ�������1
		monster:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
		monster:bindBlood(obj,kBloodZorder)
		monster:openAi() --����AI,��ʾѪ��
		monster:setSelected(false) --δѡ��ʱ��͸��
    end
end
--������AI,�ڼ��ؿ�ǰ����
function __creaturelayer.activeResCarAI(obj)
	obj._activeResCarAI = true
end
--���ؿ���Ϣ,��������ʾ����
function __creaturelayer.loadAllResCar(obj)

    local spread = obj._d_data.collectorList
	 for idx,prop in ipairs(spread) do
		local rescar = ResourceCar.new(prop,idx,obj._d_data)
		rescar:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
		if obj._activeResCarAI then 
			rescar:bindBlood(obj,kBloodZorder)
            rescar:openAi() 
		end
		local x,y = obj:getPosByIdx(prop.pos)
		rescar:egSetPos(x,y)
		rescar:egAttachTo(obj,kResCarZorder,idx)
		table.insert(obj._rescars,rescar)
    end
end
--��������λ�ñ�ǩ
function __creaturelayer.loadMonsterFlags(obj)
    local spread = obj._d_data.creatureList
    for idx,mtype in pairs(spread) do
		local lv = obj._d_data.monsterLvLook[mtype]
        local s_cfg = monster_data.getConfig(mtype)
        local s_data = monster_data.get(mtype,lv)
        local graphName = s_cfg.graphList[s_data.graphLV]
        obj:addFlag(idx,graphName)
    end
end
--====================================
--�����ǩ���
--=====================================
--���ñ�ǩѡ��״̬
function __creaturelayer.selectFlagAt(obj,idx,selected)
    if obj._monsterFlags[idx] then
        if selected then
            local scaleto1 = CCScaleTo:create(0.5,1.1)
            local scaleto2 = CCScaleTo:create(0.5,1)
            local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
            local repeatever = CCRepeatForever:create(sequence)
            obj._monsterFlags[idx]:runAction(repeatever)
        else
            obj._monsterFlags[idx]:stopAllActions()
            obj._monsterFlags[idx]:setScale(1)
        end
    end
end
--���ӱ�ǩ
function __creaturelayer.addFlag(obj,idx,graphName)
    
    local frameName = string.format('%s_020201.png',graphName)
    local sprite = CCSprite:createWithSpriteFrameName(frameName)
    local x,y = obj:getPosByIdx(idx)
    sprite:setPosition(ccp(x,y))
   -- sprite:setOpacity(160)
    --sprite:setScale(0.8)
    obj:egAddChild(sprite,kFlagZorder,idx)
    obj._monsterFlags[idx] = sprite
end
--�Ƴ���ǩ
function __creaturelayer.removeFlag(obj,idx)
    if obj._monsterFlags[idx] then
        obj:egNode():removeChild(obj._monsterFlags[idx],true)
        obj._monsterFlags[idx] = nil
    end
end
--�ƶ���ǩ
function __creaturelayer.moveFlag(obj,from,to)
    if obj._monsterFlags[from] then
        obj._monsterFlags[to] =obj._monsterFlags[from]
        obj._monsterFlags[from] = nil
        local x,y = obj:getPosByIdx(to)
        obj._monsterFlags[to]:setPosition(ccp(x,y))
    end
end
--������ǩλ��
function __creaturelayer.exFlag(obj,idx1,idx2)
    local flag1 = obj._monsterFlags[idx1]
    local flag2 = obj._monsterFlags[idx2]
    if flag1 and flag2 then
        local pos1 = ccp(flag1:getPositionX(),flag1:getPositionY())
        local pos2 = ccp(flag2:getPositionX(),flag2:getPositionY())
        --flag1:setPosition(pos2)
       -- flag2:setPosition(pos1)
       local jumpto1 = CCJumpTo:create(0.5,pos2,flag1:getContentSize().height/2,1)
       local jumpto2 = CCJumpTo:create(0.5,pos1,flag2:getContentSize().height/2,1)
       flag1:runAction(jumpto1)
       flag2:runAction(jumpto2)
        obj._monsterFlags[idx2] = flag1
        obj._monsterFlags[idx1] = flag2
    end
end
--==============================================
--�������
--=============================================

--�ƶ�������ָ������λ�� --�ھ򳡾����¹���λ��
function __creaturelayer.moveMonsterTo(obj,monster,idx)
   local mtype = monster:getprop('type')
   local lv = monster:getprop("level")
   --local oldx = monster:egGetPosX()
   --local oldy = monster:egGetPosY()
   ai_module.destroy(monster)
   obj:removeMonster(monster)
   local item = Monster.new(mtype,lv,idx)
   item:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
   table.insert(obj._monsters,item)
   local x,y = obj:getPosByIdx(idx)
   item:egSetPos(x,y)
   item:egAttachTo(obj,kMonsterZorder,idx)
   item:bindBlood(obj,kBloodZorder)
   item:openAi()--����AI��ʾѪ��
   item:setSelected(false) --δѡ��ʱ��͸��

end
--�ڿӵ�������һ������ �ھ򳡾�,���ù�ʱ����
--monster ��Ҫ���ӵĹ���
function __creaturelayer.insertMonster(obj,monster)
    table.insert(obj._monsters,monster)
    monster:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
    local idx = monster:getprop("birthPlace")
    local x,y = obj:getPosByIdx(idx)
    monster:egSetPos(x,y)
    monster:egAttachTo(obj,kMonsterZorder,idx)
    monster:bindBlood(obj,kBloodZorder)
    monster:openAi()--����AI��ʾѪ��
    monster:setSelected(false) --δѡ��ʱ��͸��
end
--�ڿӵ�������һ������ --AI������
--monster ��Ҫ���ӵĹ���
function __creaturelayer.createMonster(obj,monster)
    table.insert(obj._monsters,monster)
    monster:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
    local idx = monster:getprop("birthPlace")
    local x,y = obj:getPosByIdx(idx)
    monster:egSetPos(x,y)
    monster:egAttachTo(obj,kMonsterZorder,idx)
    monster:bindBlood(obj,kBloodZorder)
    monster:openAi()--����AI��ʾѪ��
end
--�ڿӵ�������һ������ --AI������ ����������������С��
--monster ��Ҫ���ӵĹ���
function __creaturelayer.insertSubMonster(obj,monster)
    monster:setprop("isEmemy",obj._d_data.atk == account_data.guid) --�����Ӫ
    local idx = monster:getprop("birthPlace")
    local x,y = obj:getPosByIdx(idx)
    monster:egSetPos(x,y)
    monster:egAttachTo(obj,kMonsterZorder,idx)
    monster:bindBlood(obj,kBloodZorder)
    monster:openAi()--����AI��ʾѪ��
end

--====================================================
function __creaturelayer.moveResCarTo(obj,rescar,idx)
	local x,y = obj:getPosByIdx(idx)
    rescar:egSetPos(x,y)
   -- print("rescar move zorder",rescar:egNode():getZOrder())
end
--�ƶ���������
function __creaturelayer.moveResCarToward(obj,rescar,idx)
   local x,y = obj:getPosByIdx(idx)
   local jumpto = CCJumpTo:create(0.3,ccp(x,y),kcellH/2,1)
   rescar:egNode():runAction(jumpto)
   --rescar:egSetPosition(x,y)
   -- print("rescar jump zorder",rescar:egNode():getZOrder())
end
function __creaturelayer.insertHero(obj,hero)
    table.insert(obj._heros,hero)
    hero:setprop("isEmemy",obj._d_data.dfs == account_data.guid) --�����Ӫ
    local idx = hero:getprop("birthPlace")
    local x,y = obj:getPosByIdx(idx)
    hero:egSetPos(x,y)
    hero:egAttachTo(obj,kHeroZorder,idx)
    hero:bindBlood(obj,kBloodZorder)
    hero:openAi()--����AI��ʾѪ��
end
function __creaturelayer.insertBullet(obj,bullet)
    table.insert(obj._bullets,bullet)
    local idx = bullet:getprop("birthPlace")
    local x,y = obj:getPosByIdx(idx)
    bullet:egSetPos(x,y)
    bullet:egAttachTo(obj,kBulletZorder,idx)
end
--ս�������У��Ƴ�����
function __creaturelayer.removeMonster(obj,monster)
    for idx = #obj._monsters,1,-1 do
        if monster ==obj._monsters[idx] then
            monster:unBindBlood()
            monster:egRemoveSelf()
            table.remove(obj._monsters,idx)
            return
        end
    end
	monster:egRemoveSelf()
end
function __creaturelayer.removeHero(obj,hero)
    for idx = #obj._heros,1,-1 do
        if hero ==obj._heros[idx] then
            hero:unBindBlood()
            hero:egRemoveSelf()
            table.remove(obj._heros,idx)
            return
        end
    end
end
function __creaturelayer.removeResCar(obj,rescar)
    for idx = #obj._rescars,1,-1 do
        if rescar ==obj._rescars[idx] then
            rescar:unBindBlood()
            rescar:egRemoveSelf()
            table.remove(obj._rescars,idx)
            return
        end
    end
end
function __creaturelayer.removeBullet(obj,bullet)
    for idx = #obj._bullets,1,-1 do
        if bullet ==obj._bullets[idx] then
            bullet:egRemoveSelf()
            table.remove(obj._bullets,idx)
            return
        end
    end
end
--��ȡλ��ָ������Ĺ������
function __creaturelayer.getTouchedMonster(obj,touchLocation)
    for idx,monster in ipairs(obj._monsters) do
        local size = monster:egNode():getContentSize()
        local x =  monster:egNode():getPositionX()
        local y =  monster:egNode():getPositionY()
        x = x - size.width *0.5
        y = y - size.height * 0.5
        local rect = CCRectMake(x,y,size.width,size.height)
        if rect:containsPoint(touchLocation) then return monster end
    end
    return nil
end
--���ݳ���λ�û�ȡ�� �����ھ򳡾�������λ��ǰ����
function __creaturelayer.getMonsterByIdx(obj,idx)
	for _,monster in ipairs(obj._monsters) do
		if monster:getprop("birthPlace") == idx then
			return monster
		end
	end
	return nil
end
--��ȡλ��ָ�������Ŀ� ���ھ򳡾�����¼��е���
function __creaturelayer.getResCarAt(obj,idx)
	for _,item in ipairs(obj._rescars) do
       if item:getprop("birthPlace") == idx then
			return item
	   end
    end
	return nil
end
function  __creaturelayer.getFreeResCar(obj)
    for _,item in ipairs(obj._rescars) do
        local birthPlace = item:getprop("birthPlace")
        if not obj._d_data.mileSpread[birthPlace] then
           return item
        end
    end
    return nil
end
function __creaturelayer.getLastMovedResCar(obj)
	local resCnt = #obj._rescars
	if resCnt > 0 then
		local minSt = os.time()
		local resIdx = 1
		for idx,item in ipairs(obj._rescars) do
			local st = item:getprop("lastDigTime")
			if st < minSt then
				minSt = st
				resIdx = idx
			end
		end
		return obj._rescars[resIdx]
	end
	return nil
end
function __creaturelayer.cleanMonster(obj)

    for idx = #obj._monsters,1,-1 do
         obj._monsters[idx]:unBindBlood()
         obj._monsters[idx]:egRemoveSelf()
         table.remove(obj._monsters,idx)
    end
end

function __creaturelayer.cleanHero(obj)
    for idx = #obj._heros,1,-1 do
         obj._heros[idx]:unBindBlood()
         obj._heros[idx]:egRemoveSelf()
         table.remove(obj._heros,idx)
    end
end

function __creaturelayer.cleanBullet(obj)
    for idx = #obj._bullets,1,-1 do
         obj._bullets[idx]:egRemoveSelf()
         table.remove(obj._bullets,idx)
    end
end

function __creaturelayer.getMonsters(obj)
    return obj._monsters
end
function __creaturelayer.getHeros(obj)
    return obj._heros
end
function __creaturelayer.getBullets(obj)
    return obj._bullets
end
function __creaturelayer.getResCars(obj)
    return obj._rescars
end
--�ƶ��ֻ��ǰ���ã��ж��Ƿ��ǿ��ƶ���λ��
function __creaturelayer.hasResCar(obj,idx)
	for key,item in ipairs(obj._d_data.collectorList) do
			if item.pos == idx then
				return true
			end
	end
	return false
end
--�ƶ��ֻ��ǰ���ã��ж��Ƿ��ǿ��ƶ���λ��
function __creaturelayer.hasMonser(obj,idx)
	if not idx then return false end
	return obj._d_data.creatureList[idx]
end
function __creaturelayer.getPosByIdx(obj,idx)
    local x = kcellW*( Funs.getX(obj._matrixW,idx)+ 0.5)
    local y = kcellH*(Funs.getViewY(obj._matrixW,obj._matrixH,idx)+0.5)
    return x,y
end
function __creaturelayer.getIdxByPos(obj,x,y)
    local px = Funs.getpX(x,kcellW)

    local py = Funs.getpY(y,kcellH)

    local idx = Funs.getIndex(px,py,obj._matrixW,obj._matrixH)
    return idx
end
--[[
function __creaturelayer.activeUpdate(obj)
    local function update()
		if not AccountHelper:isLocked(kStateGuide) then
			ai_module.update()
		end
    end
	local function clear()
		ai_module.clear()
	end
     obj:egBindUpdate(update,clear)
end
-]]
CreatureLayer={}
function CreatureLayer.new(d_data)
    local obj={}
    table_aux.unpackTo(__creaturelayer, obj)
    Layer.install(obj)
    obj:initlayer(d_data)
   -- obj:activeUpdate()
    return obj
end


local kGroundOrder = 1
local kAtkOrder = 2
local kScoreOrder = 6
local __pvpscene={}
function __pvpscene.init(obj,areaid,stageid)
    SendMsg[935002]()
    obj._d_data = RiskHelper.getPvpSceneData()
    obj._groundlayer = GroundLayer.new(obj._d_data)
     obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._pvplayer = PvpLayer.new(obj._d_data,obj)
        obj._pvplayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene()
    obj._groundlayer:onHeroShown(callback)
end
function __pvpscene.stopBattle(obj)
    SendMsg[935004](battleProgress)
	account_data.newVideo = true
    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end

PvpScene={}
function PvpScene.new()
    SoundHelper.playBGM(SoundList.atk_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__pvpscene, obj)
    obj:init()
    showEmDialog(obj,GuideScene.def.kPvpScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
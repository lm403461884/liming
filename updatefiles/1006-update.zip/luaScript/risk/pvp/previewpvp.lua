local kPanelLayer = "pvp_panel"
local kPanelPreview = "preview_panel"
local kPanelSearch = "search_panel"

local kBtnQuery = "btn_query"
local kBtnStart = "btn_start"
local kBtnBack = "btn_back"
local kImgScene = "img_scene"
local kLblTimeRes = "lbl_time_res"
local kLblPromp = "lbl_promp"
--search���
local kImgLoading = "img_loading"
local kLabelSearch = "lbl_search"
local kLabelNoMatch = "lbl_nomatch"

--Ԥ�����
local kLabelDeep = "lbl_deep"
local kLabelHard = "lbl_hard"
local kLabelOwer = "lbl_hole_name"
local kPanelMonster = "monster_list"
local kLabelCost = "lbl_cost"
local kLabelAct = "lbl_act"

local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"

local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)
local kMaxNum = 4
local kCellW = 110
local kWaitTime = 30 --����ʱ30��
local __previewpvp = {}

function __previewpvp.init(obj)
    obj._panel1 = obj:egGetWidgetByName(kPanelAward1)
    obj._panel2 = obj:egGetWidgetByName(kPanelAward2)
    
    obj._panel1X = obj._panel1:getPositionX()
    obj._panel1Y = obj._panel1:getPositionY()
    obj._panel1W = obj._panel1:getSize().width
    obj._panel2X = obj._panel2:getPositionX()
    obj._panel2Y = obj._panel2:getPositionY()
    obj._panel2W = obj._panel2:getSize().width

    obj._searchCost = numDef.goldOfSearch
    obj._battleAp = numDef.pvpBattleAP
    obj:egSetBMLabelStr(kLabelCost,obj._searchCost)
    obj:egSetBMLabelStr(kLabelAct,obj._battleAp)
    obj:egSetLabelStr(kLblTimeRes,kWaitTime)
    obj:egHideWidget(kLabelNoMatch)
    obj:egHideWidget(kLblTimeRes)
    obj:egHideWidget(kLblPromp)
    obj:hidePreView()
    obj:showSearch()
    obj:activeUpdate()
    obj:showWithAction()
end
--��ʾ������
function __previewpvp.showSearch(obj)
    obj:egShowWidget(kPanelSearch)
    local pic = scene_data[account_data.sceneID].thumbPic
    obj:egChangeImg(kImgScene,pic,UI_TEX_TYPE_PLIST)
    local lblWidget = obj:egGetWidgetByName(kLabelSearch)
    local blink = CCBlink:create(1,2)
    local repeatforever1 = CCRepeatForever:create(blink)
    lblWidget:runAction(repeatforever1)
        
   local imgWidget = obj:egGetWidgetByName(kImgLoading)
   local rotateby = CCRotateBy:create(1,360)
   local repeatforever2 = CCRepeatForever:create(rotateby)
   imgWidget:runAction(repeatforever2)   
end
--����������
function __previewpvp.hideSearch(obj)
    local lblWidget = obj:egGetWidgetByName(kLabelSearch)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    lblWidget:stopAllActions()
    imgWidget:stopAllActions()
    obj:egHideWidget(kPanelSearch)
end
--����Ԥ����
function __previewpvp.hidePreView(obj,goldval,eloval)
    obj:egHideWidget(kPanelPreview)
    obj:egHideWidget(kBtnQuery)
    obj:egHideWidget(kBtnStart)
    obj:egHideWidget(kPanelMonster)
    obj:egHideWidget(kLblTimeRes)
    obj:egHideWidget(kLblPromp)
end
function __previewpvp.loadAward1(obj,goldval,eloval)
    for idx = 1,obj._panel1:getChildrenCount() do
        obj._panel1:removeChildByTag(idx,true)
    end
    local margin = 50
    local goldAward = AwardItem.new("gold",Funs.signedNum(goldval))
    local goldsize = goldAward:egNode():getSize()
    goldAward:egNode():setSize(CCSizeMake(goldsize.width + margin,goldsize.height))
    obj._panel1:addChild(goldAward:egNode(),1,1)
    local eloAward = AwardItem.new("elo",Funs.signedNum(eloval))
    obj._panel1:addChild(eloAward:egNode(),1,2)
    local actW = goldAward:egNode():getSize().width + eloAward:egNode():getSize().width + margin
    obj._panel1:setPosition(ccp(obj._panel1X + (obj._panel1W-actW)/2,obj._panel1Y))
end
function __previewpvp.loadAward2(obj)
    for idx = 1,obj._panel2:getChildrenCount() do
        obj._panel2:removeChildByTag(idx,true)
    end
    obj._panel2:setPosition(ccp(obj._panel2X,obj._panel2:getPositionY()))
    local actW = 0
    local tagidx = 0
    for idx = 2,7 do
        local coinname = KVariantList.coinType[idx]
        local coinval = pvpaccount_data.resVal[idx]
        if coinval~=0 then
            tagidx = tagidx + 1
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
            obj._panel2:addChild(awarditem:egNode(),0,tagidx)
            actW = actW + awarditem:egNode():getSize().width
        end
    end
    if actW < obj._panel2W then
        obj._panel2:setPosition(ccp(obj._panel2X  + (obj._panel2W-actW)/2,obj._panel2Y))
    elseif actW > obj._panel2W then
        obj._panel2:setScale(obj._panel2W/actW)
    end
    if actW <=0 then
         obj._panel1:setPosition(ccp(obj._panel1:getPositionX(),obj._panel1Y  - 30))
    end
end
--��ʾԤ����
function __previewpvp.showPreView(obj)
    obj:egShowWidget(kPanelPreview)
    obj:egShowWidget(kBtnQuery)
    obj:egShowWidget(kBtnStart)
    obj:egShowWidget(kPanelMonster)
    obj:egSetLabelStr(kLblTimeRes,kWaitTime)
    
    local pic = scene_data[pvpaccount_data.sceneID].thumbPic
    local ownEloWin,pvpEloLose = pvpCalc.elo(account_data.elo, pvpaccount_data.elo, 3)
    
    obj:egChangeImg(kImgScene,pic,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLabelOwer,string.format("%s%s",pvpaccount_data.user,TxtList.pvpHoleEx))
    obj:egSetLabelStr(kLabelHard,pvpaccount_data.digLv)
    obj:egSetLabelStr(kLabelDeep,string.format("%s%s%d",TxtList.holeDeep,":",pvpaccount_data.holeDeep))
    local goldDlt,oilDlt,_,_ = pvpCalc.judge( ownEloWin, pvpEloLose,3, account_data.digLv, pvpaccount_data.digLv, pvpaccount_data.gold, pvpaccount_data.oil)
	obj:loadAward1(math.floor(pvpaccount_data.resVal[1] + goldDlt),math.floor(ownEloWin - account_data.elo))
	obj:loadAward2()
	if account_data.digLv < pvpaccount_data.digLv then
		obj:egSetWidgetColor(kLabelHard,kRedColor)
	else
		obj:egSetWidgetColor(kLabelHard,kBrownColor)
	end
    if account_data.gold < obj._searchCost then 
       obj:egSetWidgetEnabled(kBtnQuery,false)
       obj:egSetWidgetColor(kLabelCost,kRedColor)
    else
        obj:egSetWidgetEnabled(kBtnQuery,true)
        obj:egSetWidgetColor(kLabelCost,kWhiteColor)
    end
    --if account_data.actPt < obj._battleAp then
    --    obj:egSetWidgetEnabled(kBtnStart,false)
    --    obj:egSetWidgetColor(kLabelAct,kRedColor)
    --else
        obj:egSetWidgetEnabled(kBtnStart,true)
        obj:egSetWidgetColor(kLabelAct,kWhiteColor)
        obj:egShowWidget(kLblTimeRes)
        obj:egShowWidget(kLblPromp)
        obj:activeTimeUpdate()
    --end
    obj:loadMonsters()
end
function __previewpvp.getMonsters(obj)
    local tb = {}
    local tb1 = {}
    for pos,monsterid in pairs(pvpaccount_data.creatureList) do
        if not tb[monsterid] then 
            tb[monsterid] = 1 
            table.insert(tb1,monsterid)
        else 
            tb[monsterid] = tb[monsterid] + 1 
        end
    end
    local showNum = math.random(kMaxNum)
    while #tb1 > showNum do
        table.remove(tb1,math.random(#tb1))
    end
    return tb,tb1
end
function __previewpvp.loadMonsters(obj)
	local listview =obj:egGetListView(kPanelMonster)
	local itemCnt = listview:getChildrenCount()
	for idx = 1,itemCnt do
       local item = listview:getItem(idx-1)
       listview:removeChildByTag(item:getTag(),true)
    end
	listview:removeAllItems()
	listview:jumpToTop()
    local monsters,monsterids = obj:getMonsters()
    for key,monsterid in ipairs(monsterids) do
        local monsterHead = MonsterHead.new(monsterid,monsters[monsterid],pvpaccount_data)
        listview:pushBackCustomItem(monsterHead:egNode())
    end
end

function __previewpvp.hideWithAction(obj,callbackfunc)--{{{
    local function callback()
      obj:egRemoveSelf()
      if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.5,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end--}}}
function __previewpvp.showWithAction(obj,callbackfunc)--{{{
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callbackfunc then
        local function callback()
            callbackfunc()
        end
        local actCallBack = CCCallFunc:create(callback)
        local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
        baseWidget:runAction(squence)
    else
        baseWidget:runAction(spawn)
    end
end--}}}
--��ʼս������¼�
function __previewpvp.doClickStart(obj)
        obj:egSetWidgetTouchEnabled(kBtnStart,false)
        obj:egUnbindWidgetUpdate(kLblTimeRes)
        SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:hideWithAction()
        account_data.actPt =  account_data.actPt - obj._battleAp
		--�ھ���־������̸���
		task.updateTaskStatus(account_data,task.client_event_id.cost_actPt,{obj._battleAp})
		----------------------------------------------------------
        local scence = PvpScene.new()
        scence:egReplace()
end
--��ʼս��
function __previewpvp.bindStartListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickStart()
    end
    obj:egBindTouch(kBtnStart,touchBegan,nil,touchEnded,nil)
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
function __previewpvp.activeUpdate(obj)
    local startTime = os.time()
    local  function callback()
        if not  AccountHelper:isLocked(kStateSearchPvp) then
            obj:egUnbindWidgetUpdate(kPanelSearch)
            account_data.gold  =account_data.gold  - obj._searchCost --�ҿ󶴳ɹ���۷�
            obj:hideSearch()
            obj:showPreView()
            if obj._onpvpmatched then obj._onpvpmatched() end
        else
            if os.time() - startTime >numDef.clientTimeOut then
                obj:egUnbindWidgetUpdate(kPanelSearch)
                local lblWidget = obj:egGetWidgetByName(kLabelSearch)
                local imgWidget = obj:egGetWidgetByName(kImgLoading)
                lblWidget:stopAllActions()
                imgWidget:stopAllActions()
                lblWidget:setVisible(true)
                obj:egSetLabelStr(kLabelSearch,TxtList.pvpSearchEnd)
                obj:egShowWidget(kLabelNoMatch)
            end
         end
    end
    obj:egBindWidgetUpdate(kPanelSearch,callback)
end
function __previewpvp.bindQueryListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egUnbindWidgetUpdate(kLblTimeRes)
        AccountHelper:lock(kStateSearchPvp)
        SendMsg[935001]()
        obj:activeUpdate()
        obj:hidePreView()
        obj:showSearch()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnQuery,nil,nil,touchEnded,touchCanceled)
end
function __previewpvp.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_paper_close)
        SendMsg[935003]()
        local function callback()
            AccountHelper:unlock(kStatePrompt)
        end
        obj:hideWithAction(callback)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
--����ʱ����
function __previewpvp.activeTimeUpdate(obj) 
    local seconds = kWaitTime
    local passTime = 0
    local function callback(delta)
        passTime = passTime + delta
        if passTime >=1 then
           passTime = 0
           seconds = seconds -1
           obj:egSetLabelStr(kLblTimeRes,seconds)
        end
        if seconds == 1 then
            obj:egSetWidgetTouchEnabled(kBtnStart,false)
            obj:egSetWidgetTouchEnabled(kBtnQuery,false)
            obj:egSetWidgetTouchEnabled(kBtnBack,false)   
        elseif seconds == 0 then
			obj:egUnbindWidgetUpdate(kLblTimeRes)
            SoundHelper.playEffect(SoundList.click_shop_goods)
            obj:hideWithAction()
            account_data.actPt =  account_data.actPt - obj._battleAp
            local scence = PvpScene.new()
            scence:egReplace()   
        end
    end
    obj:egBindWidgetUpdate(kLblTimeRes,callback)
end

PreviewPvp = {}
function PreviewPvp.new(onpvpmatched)
    local obj = TouchWidget.new(JsonList.pvpAtkView)
    table_aux.unpackTo(__previewpvp, obj)
    obj._onpvpmatched = onpvpmatched
    obj:init()
    obj:bindStartListener()
    obj:bindQueryListener()
    obj:bindBackListener()
    return obj
end
function showPreviewPvp(onpvpmatched)
    local layer = PreviewPvp.new(onpvpmatched)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

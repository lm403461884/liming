--��������
local kBtnBack = "btn_giveup"
local kBtnZoomIn = "btn_zoomin"
local kBtnZoomOut = "btn_zoomout"
local kPanelLayer= "atk_panel"
local kPanelGo = "panel_go"
local kLblCount = "lbl_count"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnNo2 = "btn_no_2"
local kPanelConfirm = "giveup_panel"
local kImgBtnBg = "img_btn_bg"
--������Ч���
local kPanelSkill = "skill_panel"
local kImgEffect = "img_effect"
local kImgHead = "img_head"
--��������
local kBarConsume = "bar_consume"
local kImgConsume = "img_bar_bg"
local kLabelLeftCost = "lbl_consume"
local kLabelPerCost = "lbl_cost_val"
local kLabelPerCosts = "lbl_cost_val_s"
--С��Ӣ��
local kListHero = "hero_list"
--��������Ϣ
local kPanelAtk = "atk_layer" 
local kLabelAtk = "lbl_atk" --����������
local kLabelAtk_s = "lbl_atk_s"--���������� ��Ӱ
local kAtkStars = {"star_atk_1","star_atk_2","star_atk_3"}
local kImgAtkBg = "atk_bg"
--���ط���Ϣ
local kPanelDef = "def_layer"
local kLabelDef = "lbl_def" --���ط�����
local kLabelDef_s = "lbl_def_s"--���������� ��Ӱ
local kDefStars = {"def_star_1","def_star_2","def_star_3"}
local kImgDefBg = "def_bg"
--������Ϣ
--local kLblBox = {"lbl_gold_box_num","lbl_silver_box_num","lbl_copper_box_num"}
--local kImgBox = {"img_box_gold","img_box_silver","img_box_copper"}
--local kLblBoxs = {"lbl_gold_box_num_s","lbl_silver_box_num_s","lbl_copper_box_num_s"}
local kPanleBox = "box_list"
local kImgShelf = "img_shelf"

local kParticleSrc = "particle/battle/ExplodingRing.plist.png"
local kParticleReady = "particle/battle/skill_ready.plist"
local kParticleFire = "particle/battle/skill_fire.plist"

local kCounterNum0 = 20
local kCounterNum1 = 10
local kMaxDamage = 99999
local kMaxBoxNum = 6
local kHeroW = 156
local kParticleCap = 1200
local __pvplayer={}

function __pvplayer.init(obj,d_data,owner)
     obj._owner = owner
     obj._d_data = d_data
     obj._frameID = 0 --֡ID
     obj._startTime = os.clock()
     obj._battleStoped = false
     obj._usedConsume = 0 --�ܼ�������
     obj._enteredHeros = {} --�ѽ���ս����Ӣ��
     obj._unenteredHeros = {}--δ����ս����Ӣ��
     obj._heroHeads = {}
     obj._skillQueen = {}
     --obj._particleList = {}
     --����ս��˫��������Ϣ
     obj:loadBaseInfo()
     --����Ӣ��
     obj:loadHeroHeads()
	 
     obj:egShowWidget(kPanelGo)
     obj:activeEnterCounter(kCounterNum0)
     --
     obj:egHideWidget(kBtnZoomIn)
     obj:egHideWidget(kBtnZoomOut)
     obj:egHideWidget(kPanelSkill)
     obj:showConfirmGiveUp(false)
	 if obj._d_data.btFlag == 0 then --PVE��������
		obj:egShowWidget(kPanleBox)
		obj:egShowWidget(kImgShelf)
		obj:bindGroundClickEvent()
	else
		obj:egHideWidget(kPanleBox)
		obj:egHideWidget(kImgShelf)
	 end
end
function __pvplayer.loadBaseInfo(obj)
 --����������Ϣ
    obj:egSetBarPercent(kBarConsume,100)
    obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume)
    obj:egSetLabelStr(kLabelPerCost,"0/s")
    obj:egSetLabelStr(kLabelPerCosts,"0/s")
     --���ؽ���������
    obj:egSetLabelStr(kLabelAtk,obj._d_data.atkName)
    obj:egSetLabelStr(kLabelAtk_s,obj._d_data.atkName)
	
     --���ط��ط�����
     obj:egSetLabelStr(kLabelDef,obj._d_data.dfsName)
     obj:egSetLabelStr(kLabelDef_s,obj._d_data.dfsName)
	 
	 if obj._d_data.atk == account_data.guid then
		obj:egChangeImg(kImgAtkBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST)
	 else
		obj:egChangeImg(kImgAtkBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST) 
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
	 end
     obj:egSetImgFlipX(kImgDefBg,true)
end
function __pvplayer.collectAllBox(obj)
	local groundlayer = obj._owner._groundlayer
    local boxlayer = groundlayer._boxlayer
	local boxpanel = obj:egGetWidgetByName(kPanleBox)
	local boxlist = boxlayer:getAllBoxes()
	for idx=#boxlist,1,-1 do
		local boxitem = boxlist[idx]
		local boxtype = boxitem:getprop("boxType")
		obj:addBattleBoxNum(boxtype)
		boxitem:egRemoveSelf()
		table.remove(boxlist,idx)
	end
end
--�󶨳�������ص�����������ʹ�ã�
function __pvplayer.bindGroundClickEvent(obj)
    local groundlayer = obj._owner._groundlayer
    local boxlayer = groundlayer._boxlayer
	local boxpanel = obj:egGetWidgetByName(kPanleBox)
	local boxCount = 0
	local margin = 33
    local function clickCallback(idx,posx,posy)
        local boxitem = boxlayer:getBoxAt(idx)
		if boxitem then
		    boxCount = boxCount + 1
			local boxtype = boxitem:getprop("boxType")
			--local imgbox = obj:egGetWidgetByName(kImgBox[boxtype])
			local desx = 0
			local desy = 0
			if boxCount > 6 then
			     desx = boxpanel:getPositionX() + margin*(boxCount-6)
			     desy = boxpanel:getPositionY() + 61 + 28
			else
			     desx = boxpanel:getPositionX() + margin*boxCount
			     desy = boxpanel:getPositionY() + 61
			end
			obj:addBattleBoxNum(boxtype)
			obj:addBattleBox(boxtype,desx,desy,boxCount)
			boxlayer:removeBox(boxitem,desx - posx,desy-posy)
		end
    end
    groundlayer:onGroundClicked(clickCallback)
end
function __pvplayer.addBattleBox(obj,boxtype,posx,posy,count)
    local src = ImageList[string.format("comm_box_%s",KVariantList.boxType[boxtype])]
    local img = ImageView:create()
    img:loadTexture(src,UI_TEX_TYPE_PLIST)
   -- local sprite = CCSprite:createWithSpriteFrameName(src)
    local panelBox = obj:egGetWidgetByName(kPanleBox)
    img:setScale(0.25)
	if count <= kMaxBoxNum then
	    --obj:egAddChild(sprite,kMaxBoxNum-count,kMaxBoxNum-count)
	    panelBox:addChild(img,kMaxBoxNum-count,kMaxBoxNum-count)
	else
        --obj:egAddChild(sprite,kMaxBoxNum*2-count,kMaxBoxNum*2-count)
        panelBox:addChild(img,kMaxBoxNum*2-count,kMaxBoxNum*2-count)
    end    
    img:setPosition (ccp(posx,posy))
end

function __pvplayer.addBattleBoxNum(obj,boxtype)
	local oldCnt = #obj._d_data.battleBox[boxtype]
	local newNumTxt = string.format("%s%d",TxtList.numSymbol,oldCnt + 1)
	
	obj._d_data.battleBoxCnt = obj._d_data.battleBoxCnt + 1
	local awardRes = baseCalc.treasureBox(account_data,boxtype)
	table.insert(obj._d_data.battleBox[boxtype],awardRes)
	local valnum = awardRes[3] or 0
	local awardtype = awardRes[1] or 0
	local subtype = awardRes[2] or 0
	if awardtype == 1 then
		local cointype = KVariantList.coinType[subtype]
		battleProgress.gainRes[cointype] = (battleProgress.gainRes[cointype] or 0 ) + valnum
	elseif awardtype == 2 then
		battleProgress.gainHeroMsg[subtype] = (battleProgress.gainHeroMsg[subtype] or 0) + valnum
	end	
end
--�볡����ʱ
function __pvplayer.activeEnterCounter(obj,counter)
    local passed = 0
    local leftNum = counter
    local function callback(delta)
        passed = passed + delta
        leftNum = counter - math.floor(passed)
        if leftNum <= 0 then
            obj:egUnbindWidgetUpdate(kLblCount)
            obj:egHideWidget(kPanelGo)
            obj:autoSendHero()--�Զ��ַ�Ӣ���볡
        end
        obj:egSetLabelStr(kLblCount,leftNum )
    end
    obj:egBindWidgetUpdate(kLblCount,callback)
end
--�Զ��ַ�Ӣ���볡
function __pvplayer.autoSendHero(obj)
    local heroHead = obj._unenteredHeros[1]
    heroHead:enterBattle()
end
--����Ӣ��ͷ��
function __pvplayer.loadHeroHeads(obj)
    local teamCnt = #obj._d_data.teamList
    local heroPanel = obj:egGetWidgetByName(kListHero)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    for key,heroObj in ipairs(creaturelayer._heros) do
        local heroHead = BattleHero.new(heroObj)
        heroPanel:addChild(heroHead:egNode())
        table.insert(obj._unenteredHeros,heroHead)
        obj._heroHeads[heroObj:getprop('type')] = heroHead 
        obj:bindHeroEntering(heroHead)
        obj:bindHeroActived(heroHead)
        obj:bindHeroDied(heroHead)
        obj:bindHeroSkillReady(heroHead)
        obj:bindHeroUsingSkill(heroHead)
    end
    local size = heroPanel:getSize()
    local oldW = size.width
    local newW = kHeroW*teamCnt
    heroPanel:setSize(CCSizeMake(newW,size.height))
    heroPanel:setPosition(ccp((oldW-newW)/2,0))
end
--Ӣ��׼���볡�ص�����
function __pvplayer.bindHeroEntering(obj,heroHead)
    local function callback(sender)
        obj:egUnbindWidgetUpdate(kLblCount)
        obj:egHideWidget(kPanelGo)
        table.insert(battleProgress.heroEnterFrame,sender:getHeroID())
        table.insert(battleProgress.heroEnterFrame,obj._frameID)
        --��Ӣ�������ѽ���ս���б�
        for key ,item in ipairs(obj._unenteredHeros) do
            if item == sender then
                table.remove(obj._unenteredHeros,key)
            end
        end
        table.insert(obj._enteredHeros,sender)
    end
    heroHead:onHeroEntering(callback)
    
end
--Ӣ�ۿ���AIǰ�Ļص�����
function __pvplayer.bindHeroActived(obj,heroHead)
    local function callback(sender)
        table.insert(battleProgress.heroCreatedFrame,sender:getHeroID())
        table.insert(battleProgress.heroCreatedFrame,obj._frameID)
    end
     heroHead:onHeroActived(callback)
end
--Ӣ�������ص�����
function __pvplayer.bindHeroDied(obj,heroHead)
    local function callback(sender)
        for key,item in ipairs(obj._enteredHeros) do
            if item == sender then
                table.remove(obj._enteredHeros,key)
                break
            end
        end
        if #obj._unenteredHeros>0 and #obj._enteredHeros== 0 then
            obj:activeEnterCounter(kCounterNum1)
        end
    end
    heroHead:onHeroDied(callback)
end
--Ӣ�ۼ���׼����ɻص�����
function __pvplayer.bindHeroSkillReady(obj,heroHead)
    local function callback(sender)
        local particle = CCParticleSystemQuad:create(kParticleReady)
        --[[
		local heroid = sender:getHeroID()
		if obj._particlelayer:getChildByTag(heroid) then
			obj._particlelayer:removeChildByTag(heroid,true)
		end
        obj._particleList[heroid] = particle
        --]]
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
    end
    heroHead:onSkillReady(callback)
end
--Ӣ��ʹ�ü���ǰ�Ļص�����
function __pvplayer.bindHeroUsingSkill(obj,heroHead)
    local function callback(sender)
		local heroid = sender:getHeroID()
		if battleProgress.skillUsageFrame[heroid] then
			table.insert(battleProgress.skillUsageFrame[heroid],obj._frameID)
		else
			battleProgress.skillUsageFrame[heroid] = {obj._frameID}
		end
        table.insert(obj._skillQueen,sender)
        local particle = CCParticleSystemQuad:create(kParticleFire)
        --[[
		local heroid = sender:getHeroID()
		if obj._particleList[heroid] then
			obj._particlelayer:removeChild(obj._particleList[heroid],true)
		end
		obj._particleList[heroid] = particle
		--]]
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
        
        obj:egShowWidget(kPanelSkill)
        obj:egChangeImg(kImgHead,hero_data.getConfig(sender:getHeroID()).skillHeadPic,UI_TEX_TYPE_PLIST)
        local img = obj:egGetWidgetByName(kImgEffect)
        img:setScaleX(0)
        img:stopAllActions()
        local scaleto = CCScaleTo:create(0.5,1)
        local expOut = CCEaseExponentialOut:create(scaleto)
        local function callback()
            obj:egHideWidget(kPanelSkill)
            for idx = #obj._skillQueen,1,-1 do
                obj._skillQueen[idx]:afterUseSkill()
                table.remove(obj._skillQueen,idx)
            end
        end
        local callfunc = CCCallFunc:create(callback)
        local delaytime = CCDelayTime:create(0.5)
        local array = CCArray:create()
        array:addObject(expOut)
        array:addObject(delaytime)
        array:addObject(callfunc)
        local sequence = CCSequence:create(array)
        img:runAction(sequence)
        
    end
    heroHead:onUsingSkill(callback)
end
--��ʾ�Ǽ����
function __pvplayer.showStarChange(obj,stars)
    if stars ~= battleProgress.stars  then 
        for idx = battleProgress.stars + 1,stars do
            local star1 = obj:egGetWidgetByName(kDefStars[idx])
            local star2 = obj:egGetWidgetByName(kAtkStars[idx])
            local blink1 = CCBlink:create(0.5,5)
            local blink2 = CCBlink:create(0.5,5)
            local function callbackfunc1()
                --obj:egChangeImg(kDefStars[idx],ImageList.lvup_starnull,UI_TEX_TYPE_PLIST)
                obj:egHideWidget(kDefStars[idx])
            end
            local function callbackfunc2()
                --obj:egChangeImg(kAtkStars[idx],ImageList.lvup_star,UI_TEX_TYPE_PLIST)
                obj:egShowWidget(kAtkStars[idx])
            end
            local action_callback1 = CCCallFuncN:create(callbackfunc1)
            local action_callback2 = CCCallFuncN:create(callbackfunc2)
            local sequence1 = CCSequence:createWithTwoActions(blink1,action_callback1)
            local sequence2 = CCSequence:createWithTwoActions(blink2,action_callback2)
            star1:runAction(sequence1)
            star2:runAction(sequence2)
        end
         battleProgress.stars  = stars
    end
end

--��ȡ�����ѽ���ӵ���Ӣ�۵�����ֵ�ܺ�
function __pvplayer.getTotalConsume(obj)
    local val = 0
    for idx,hero in pairs(obj._heroHeads) do
        val = val + hero:getTotalConsume()
    end
    if val > obj._d_data.consume then val = obj._d_data.consume end
    return val
end
--��ȡ�ܼ�ÿ������
function __pvplayer.getPerConsume(obj)
    local val = 0
    for idx,hero in ipairs(obj._enteredHeros) do
        val = val + hero:getConsume()
    end
    return val
end
--�ж����Ƿ�������
function __pvplayer.isTimeOut(obj)
   local perConsume = obj:getPerConsume()
   obj:egSetLabelStr(kLabelPerCost,string.format("%d%s",perConsume,"/s"))
   obj:egSetLabelStr(kLabelPerCosts,string.format("%d%s",perConsume,"/s"))
   local usedConsume = obj:getTotalConsume()
   if usedConsume == obj._d_data.consume then
       obj:killAllHeros()
       return true
   else
       if obj._usedConsume ~= usedConsume then
            obj._usedConsume = usedConsume
            local percent =100- usedConsume*100/obj._d_data.consume
            obj:egSetBarPercent(kBarConsume,percent)
            obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume - obj._usedConsume)
       end
       return false
   end
end
--�ж���Դ���Ƿ����
function __pvplayer.isResCarClear(obj)
	local collectorCount = #obj._d_data.collectorList
	local leftResCar = collectorCount - #battleProgress.collector
	local stars = math.floor(leftResCar / collectorCount * numDef.starsPerStage)
	if leftResCar > 0 and stars == 0 then
		stars = 1
	end
    obj:showStarChange(numDef.starsPerStage - stars)
    return leftResCar == 0 
end
--���������������£�����Ӣ����������
function __pvplayer.killAllHeros(obj)
    for _,heroid in ipairs(obj._d_data.teamList) do
        obj._heroHeads[heroid]:killHero()
        if not battleProgress.heroDamage[heroid] then
            battleProgress.heroDamage[heroid] = {kMaxDamage,os.time()}
        else
            table.insert( battleProgress.heroDamage[heroid],kMaxDamage)
            table.insert( battleProgress.heroDamage[heroid],os.time())
        end
    end
    obj._enteredHeros={}
    obj._unenteredHeros={}
    obj:egUnbindWidgetUpdate(kLblCount)
end
--�ж�Ӣ���Ƿ�����
function __pvplayer.isHeroClear(obj)
    if #obj._enteredHeros==0 and #obj._unenteredHeros==0 then 
        return true
    else
        return false
    end
end

--����ս��
function __pvplayer.stopBattle(obj)
    ai_module.clear()
	obj:collectAllBox()
	obj:saveCreatureInfo()
    obj._battleStoped = true
	AccountHelper:lock(kStateBpResult)
    obj:egSetWidgetTouchEnabled(kBtnBack,false)
    obj:showConfirmGiveUp(false)
    battleProgress.endTime = os.time()
    battleProgress.frameCnt = obj._frameID
    obj:egUnbindWidgetUpdate(kPanelLayer)
    if battleProgress.stars > 0 then
	   SoundHelper.playBGMOnce(SoundList.battleWin)
    else
	   SoundHelper.playBGMOnce(SoundList.battleLose)
    end
    
    obj._d_data.oldheroList = obj:copyHeroData()--���ƽ�ս��ǰӢ������
    obj._owner:stopBattle() --�ص�����������stopBattle����
    obj:egHideWidget(kBtnBack)
    obj:egHideWidget(kImgBtnBg)
    obj:egHideWidget(kBtnZoomOut)
    obj:egHideWidget(kBtnZoomIn)
    ---obj:egHideWidget(kPanleBox)
end
function __pvplayer.copyHeroData(obj)
   local herolist ={}
    for heroid,item in pairs(obj._d_data.heroList) do
         local heroHead = obj._heroHeads[heroid]
         if heroHead then --�ų�heroList��û����Team��Ӣ��
            local tb =Funs.copy(item)
             tb.curhp = heroHead:getHP()
			 herolist[heroid] = tb
         end
    end
    return herolist
end
--��¼Զ������ս����ʣ��ֺ�Ӣ����Ϣ
function __pvplayer.saveCreatureInfo(obj)
	if obj._d_data.btFlag == 4 then
		for heroid,heroHead in pairs(obj._heroHeads) do
			print(heroid,heroHead:getHP())
			account_data.expedition[heroid] = RiskHelper.calHPPower(heroHead:getHP(),heroHead:getPower())
			print(heroid,heroHead:getHP(),account_data.expedition[heroid])
			table.insert(battleProgress.heroHpPower,heroid)
			table.insert(battleProgress.heroHpPower,account_data.expedition[heroid])
		end
		for idx,pos in ipairs(battleProgress.monsterDeath) do
			account_data.exMission.creatureList[pos] = nil
		end
		farpveCalc.unlockNextStage(account_data,battleProgress.stageID,battleProgress.stars)	
	end
end
--���ط�����ť
function __pvplayer.hideGiveUp(obj,hide)
    if hide then
        obj:egHideWidget(kBtnBack)
		obj:egHideWidget(kImgBtnBg)
    else
        obj:egShowWidget(kBtnBack)
		obj:egShowWidget(kImgBtnBg)
    end
end
--��ʾ�������
function __pvplayer.showConfirmGiveUp(obj,show)
    if show then
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        --obj:egShowWidget(kBtnNo2)
        obj:egShowWidget(kPanelConfirm)
    else
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
       -- obj:egHideWidget(kBtnNo2)
        obj:egHideWidget(kPanelConfirm)
    end
end

function __pvplayer.bindPanelUpdate(obj)
    local  function callback()
          obj._frameID = obj._frameID + 1
          if obj:isTimeOut() then 
                obj:stopBattle()
          elseif obj:isResCarClear() then
                obj:stopBattle()
          elseif obj:isHeroClear() then
                obj:stopBattle()
          end
    end
    obj:egBindWidgetUpdate(kPanelLayer,callback)
end
--����
function __pvplayer.bindBackListener(obj)
     local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:showConfirmGiveUp(true)
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
--ȷ�Ϸ���
function __pvplayer.bindYesListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
        if not obj._battleStoped  then
            obj:killAllHeros() --����ֱ��KILL����Ӣ��
        end
    end
     obj:egBindTouch(kBtnYes,nil,nil,touchEnded,nil)
end
--ȡ������
function __pvplayer.bindNoListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:egSetWidgetTouchEnabled(kBtnBack,true)
    end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,nil)
end
--ȡ������
function __pvplayer.bindNo2Listener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:egSetWidgetTouchEnabled(kBtnBack,true)
    end
    obj:egBindTouch(kBtnNo2,nil,nil,touchEnded,nil)
end
function __pvplayer.bindZoomOutListener(obj) 
    local function touchEnded(sender)
        local holelayer = AccountHelper:get(kHoleLayer)
        holelayer:zoomOut()
    end
    obj:egBindTouch(kBtnZoomOut,nil,nil,touchEnded,nil)
end
function __pvplayer.bindZoomInListener(obj)
    local function touchEnded(sender)
         local holelayer = AccountHelper:get(kHoleLayer)
         holelayer:zoomIn()
    end
     obj:egBindTouch(kBtnZoomIn,nil,nil,touchEnded,nil)
end
function __pvplayer.activeUpdate(obj)
    local function update()
		if #obj._skillQueen== 0 then
			ai_module.update()
		end
    end
	local function clear()
		ai_module.clear()
	end
     obj:egBindUpdate(update,clear)
end
PvpLayer={}
function PvpLayer.new(d_data,owner)
    local obj = TouchWidget.new(JsonList.atkLayer)
	obj._particlelayer =  CCParticleBatchNode:create(kParticleSrc,kParticleCap)
	obj:egAddChild(obj._particlelayer,1,1)
    table_aux.unpackTo(__pvplayer, obj)
    obj:init(d_data,owner)
    obj:bindBackListener()
    obj:bindZoomOutListener() 
    obj:bindZoomInListener(obj)
    obj:bindYesListener()
    obj:bindNoListener()
    --obj:bindNo2Listener()
	obj:bindPanelUpdate() 
	obj:activeUpdate()
    return obj
end

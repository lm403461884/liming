local kPanelCard = "hero_list"
local kPanelItem = "item_list"
local kBtnBack = "btn_back"
local kBtnGo = "btn_go"

local kLblAttack = "lbl_attack"
local kLblConsume = "lbl_material"  --��ս���ʣ�ս��������������
local kCellW = 145
local kCellH = 160
local kMarginX = 10
local kMarginY = 5
local kCardW = 210
local __exteamlayer = {}
function __exteamlayer.init(obj,d_data)
    obj._heroItems = {} --Ӣ�ۿ�
    obj._emptyItems = {} --�հ׿�
    obj._heroCards = {} --Ӣ�ۿ�Ƭ
    obj._d_data=d_data
    obj._heroAtkList =obj:getHeroAtkCapList()--��ȡ����Ӣ�������б�
    obj._capHashTb,obj._capTb = obj:getOrderdHeroList()
	obj:initExTeam()
	obj._teamAtk = obj:getExTeamAtkCap() --Զ����ս����
	obj:egSetLabelStr(kLblAttack,obj._teamAtk)
    obj:egSetLabelStr(kLblConsume,obj._d_data.consume)--��ս����
    obj:loadHeroItems()
	obj:loadHeroCards()
end
--��ʼ��Զ��������
function __exteamlayer.initExTeam(obj)
	obj._newExTeam =  {} --̽�ն�Ӣ������
	local cnt = 0
	for idx,cap in pairs(obj._capTb) do
		for key,heroid in ipairs(obj._capHashTb[cap]) do
			local herodata = obj._d_data.heroList[heroid]
			local hp = hero_data.getData(herodata.type, herodata.lv, "maxHP")
			
			if cnt >= numDef.maxExTeamCnt then return end
			cnt = cnt + 1
			obj._newExTeam[heroid] = RiskHelper.calHPPower(hp,0)
		end
	end
end
--����ļ������Ӣ��ս�������ݱ�
function __exteamlayer.getHeroAtkCapList(obj)
    local tb = {}
    for key,heroprop in pairs(obj._d_data.heroList) do
        local equiplv,equipqa =  equipFuncs.getEquipQL(heroprop.eid,obj._d_data)
        local atkcap = baseCalc.getBattlePoint(heroprop.lv,equiplv,equipqa)
        tb[heroprop.type] = atkcap
    end
    return tb
end
--��ȡ��ս���������Ӣ���б�
function __exteamlayer.getOrderdHeroList(obj)
    local tb = {} --ս���������
    local hashtb = {}--ս���������
    for key,heroprop in pairs(obj._d_data.heroList) do
        local atkcap = obj._heroAtkList[heroprop.type]
        if not hashtb[atkcap] then
            hashtb[atkcap]={heroprop.type}
            table.insert(tb,atkcap)
        else
            table.insert(hashtb[atkcap],heroprop.type)
        end
    end
    table.sort(tb,function(a,b) return a>b end)
    return hashtb,tb
end
--Զ����ս����
function __exteamlayer.getExTeamAtkCap(obj)
	local atk = 0
	for heroid,_ in pairs(obj._newExTeam) do
		atk = atk + obj._heroAtkList[heroid]
	end
	return atk
end
--����Ӣ�ۿ�Ƭ
function __exteamlayer.loadHeroCards(obj)
    local listview = obj:egGetScrollView(kPanelCard)
    
    local loadedNum = 0
	local function addHeroCard(heroid)
		 if not obj._heroCards[heroid] then
			local herocard =  ExHeroCard.new(heroid,obj._newExTeam[heroid],#obj._emptyItems<=0)
			listview:addChild(herocard:egNode())
			herocard:egSetPosition(loadedNum*kCardW,0)
			obj._heroCards[heroid] = herocard
			obj:bindJoinTeamCallback(herocard)
			loadedNum = loadedNum +1
		end
	end
    for heroid,_ in pairs(obj._newExTeam) do
         addHeroCard(heroid)
    end
    for idx,cap in pairs(obj._capTb) do
         for key,heroid in ipairs(obj._capHashTb[cap]) do
             addHeroCard(heroid)
         end
    end
    local neww = kCardW * loadedNum
    local size = listview:getSize()
    if neww > size.width then
        listview:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
end
--�󶨿�Ƭ���Ƶ���¼�
function __exteamlayer.bindJoinTeamCallback(obj,herocard)
    local function callback(sender)
        local heroid = sender:getprop("heroid")
		local hp = sender:getprop("maxHp")
        obj._newExTeam[heroid] = RiskHelper.calHPPower(hp,0)
        obj._emptyItems[1]:updateHeroInfo(heroid,obj._newExTeam[heroid])
        table.insert(obj._heroItems,obj._emptyItems[1])
        table.remove(obj._emptyItems,1)
        obj:reOrderExTeamItem()
        obj:reOrderEmptytem()
        obj:reorderHeroCard()
        local heroAtk = obj._heroAtkList[heroid]
		obj._teamAtk = obj._teamAtk + heroAtk
		obj:egSetLabelStr(kLblAttack,obj._teamAtk)
		obj:egSetWidgetEnabled(kBtnGo,#obj._heroItems > 0)--ûѡ��Ӣ��ʱ���ܳ���
		--�ھ���־������̸��� ����С�ӳ�Ա
		--task.updateTaskStatus(account_data,task.client_event_id.team_add,{heroid})	
		----------------------
    end
    herocard:onJoinClicked(callback)
end
--���¶�Ӣ�ۿ�Ƭ��������
function __exteamlayer.reorderHeroCard(obj)
    local loadedNum = 0
	local function moveHeroCard(heroid)
		local herocard =  obj._heroCards[heroid]
		herocard:egNode():stopAllActions()
        local moveto = CCMoveTo:create(0.2,ccp(loadedNum*kCardW,0))
        herocard:egNode():runAction(moveto)

		herocard:updateJoinState(obj._newExTeam[heroid],#obj._emptyItems<=0)
        loadedNum = loadedNum +1
	end
     for heroid,_ in pairs(obj._newExTeam) do
        moveHeroCard(heroid) 
    end
    for idx,cap in pairs(obj._capTb) do
         for key,heroid in ipairs(obj._capHashTb[cap]) do
             if not obj._newExTeam[heroid] then
                moveHeroCard(heroid)
             end
         end
    end
end
function __exteamlayer.reOrderExTeamItem(obj)
    local colNum = math.ceil(numDef.maxExTeamCnt/2)
    for idx,heroitem in ipairs(obj._heroItems) do
        heroitem:setItemTouchEnabled(true)
        local x = kMarginX + ((idx -1)%colNum)*kCellW
        local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-idx)/colNum)
        heroitem:egSetPosition(x,y)
    end
end
function __exteamlayer.reOrderEmptytem(obj)
    local colNum = math.ceil(numDef.maxExTeamCnt/2)
    local cnt = #obj._heroItems
    for idx,heroitem in ipairs(obj._emptyItems) do
         heroitem:setItemTouchEnabled(true)
         local x = kMarginX + ((cnt+idx -1)%colNum)*kCellW
         local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-cnt-idx)/colNum)
         heroitem:egSetPosition(x,y)
    end
end
function __exteamlayer.reLoadExTeamItem(obj)
    local colNum = math.ceil(numDef.maxExTeamCnt/2)
    local removeIdx = 0
    for idx,heroitem in ipairs(obj._heroItems) do
        heroitem:setItemTouchEnabled(true)
        local heroid =  heroitem:getprop("heroid")
        if heroid == 0 then
            removeIdx = idx
        elseif removeIdx~=0  then
             idx = idx - 1 
            local x = kMarginX + ((idx -1)%colNum)*kCellW
            local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-idx)/colNum)
            heroitem:egSetPosition(x,y)
        end
    end
    if removeIdx > 0 then
        table.remove(obj._heroItems,removeIdx)
    end
end
--����Զ����Ӣ��
function  __exteamlayer.loadHeroItems(obj)
    local listview= obj:egGetWidgetByName(kPanelItem)
	local colNum = math.ceil(numDef.maxExTeamCnt/2)
	local loadNum = 0
	local function getHeroItem(heroid)
	    local heroitem = ExpeditionItem.new(heroid,obj._newExTeam[heroid])
		local x = kMarginX + (loadNum%colNum)*kCellW
		local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-loadNum-1)/colNum)
        heroitem:egSetPosition(x,y)
        listview:addChild(heroitem:egNode())
        obj:bindItemClickEvent(heroitem)
        loadNum = loadNum + 1
        return heroitem
	end
    for heroid,_ in pairs(obj._newExTeam) do
       local heroitem =  getHeroItem(heroid)
       table.insert(obj._heroItems,heroitem)
       if loadNum >= numDef.maxExTeamCnt then return end
    end
    while loadNum < numDef.maxExTeamCnt do
         local heroitem =  getHeroItem(0)
        table.insert(obj._emptyItems,heroitem)
    end
end
--Ӣ�ۿ����¼�
function __exteamlayer.bindItemClickEvent(obj,heroitem)
    local function clickCallback(sender)
        local heroid = sender:getprop("heroid")
        if heroid > 0 then
           sender:updateHeroInfo(0,0)
           obj._newExTeam[heroid] = nil
           table.insert(obj._emptyItems,sender)
           obj:reLoadExTeamItem()
           obj:reOrderEmptytem()
           obj:reorderHeroCard()
           local heroAtk = obj._heroAtkList[heroid]
           obj._teamAtk = obj._teamAtk - heroAtk
           obj:egSetLabelStr(kLblAttack,obj._teamAtk)
		   obj:egSetWidgetEnabled(kBtnGo,#obj._heroItems > 0)--ûѡ��Ӣ��ʱ���ܳ���
		end
    end
    heroitem:onItemClicked(clickCallback)    
end

--�󶨷��ذ���������
function __exteamlayer.bindBackListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --����
		if not obj._d_data.expedition then
			local scene = TownScene.new()
			scene:egReplace()
		else
			--������ͼ
			local scene =ExMissionScene.new()
			scene:egReplace()
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end 
function __exteamlayer.bindGoListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --����
        obj._d_data.expedition = obj._newExTeam
		local heroteam = {}
		for key,val in pairs(obj._d_data.expedition) do
			table.insert(heroteam,key)
		end
        --��ʼ��Զ������
		--��ȡ�µ�Զ����������
		SendMsg[934012](farpveCalc.initExMission(account_data),heroteam )
		local scene =ExpeditionLoadScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGo,nil,nil,touchEnded,touchCanceled)
end
ExpeditionTeamlayer={}
function ExpeditionTeamlayer.new(d_data)
    local obj = TouchWidget.new(JsonList.expeditionLayer)
    table_aux.unpackTo(__exteamlayer, obj)
    obj:init(d_data)
    obj:bindBackListener()
	obj:bindGoListener()
    return obj
end
local __teamscene = {}
ExMissionScene = {}
function ExMissionScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__teamscene, obj)
    obj._layer = ExMissionlayer.new(account_data)
    obj._layer:egAttachTo(obj)
    --showEmDialog(obj,GuideScene.def.kTeamScene) --����������Ϣ
    
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
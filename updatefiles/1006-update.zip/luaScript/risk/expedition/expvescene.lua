local kGroundOrder = 1
local kAtkOrder = 2
local kScoreOrder = 6
local __expvescene={}
function __expvescene.init(obj,stageid)
    obj._d_data = RiskHelper.getExPveSceneData(stageid)
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._atklayer = PvpLayer.new(obj._d_data,obj)
        obj._atklayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene(callback)
	obj._groundlayer:onHeroShown(callback)
end
function __expvescene.stopBattle(obj)
    SendMsg[934013](battleProgress,obj._d_data.totalLv)
	AccountHelper:unlock(kStateBpResult)
	BPResult ={}
    BPResult.elo = 0
    BPResult.stars =  battleProgress.stars 
	for key,val in pairs(obj._d_data.awardRes) do
		if key=="exp" then
			BPResult.teamExp =baseCalc.getTeamExp( math.floor( BPResult.stars / numDef.starsPerStage * val), obj._d_data.teamList, obj._d_data.heroList) 
		else
			BPResult[key] = math.floor(val * BPResult.stars /numDef.starsPerStage)
			account_data[key] = account_data[key] + BPResult[key]
		end
	end
	
    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end

ExPveScene={}
function ExPveScene.new(stageid)
    SoundHelper.playBGM(SoundList.atk_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__expvescene, obj)
    obj:init(stageid)
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
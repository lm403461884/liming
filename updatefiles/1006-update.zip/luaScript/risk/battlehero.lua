--=================================
--2014-4-25:ȡ��С�Ӷӳ����ȥ��Captain��ش���
--=================================
--=================================
--2014-5-26:���뼼�ܸ�����Ӽ�����ش���
--=================================
local kImgBg = "btn_hero_bg"
local kBarHp = "bar_hero_hp"
local kBarPower = "bar_hero_power"
local kImgHero = "img_hero"
local kImgFull = "img_full_bg" --ŭ��ֵ������ʾͼƬ

local kImgLv = "img_lv"
local kLabelLv = "lbl_lv"
local kImgGo = "img_go"
local kLabelCost = "lbl_enter"
--[[
local kparticleReady = "particle/battle/skill_ready.plist"
local kparticleFire = "particle/battle/skill_fire.plist"
--]]
local kGreenColor = ccc3(0,255,0)
local kRedColor = ccc3(255,0,0)
local kGrayColor = ccc3(64,64,64)
local kWhiteColor = ccc3(255,255,255)
local kCellW = 72
local kSpeed = 200
local __battlehero = {}
function __battlehero.init(obj,heroObj)
    obj._heroObj = heroObj
    obj._isDead = false
    obj._isEntered = false
    obj._isAIActived = false
	obj._survivalTime = 0 --����ս����Ĵ��ʱ��
	obj._heroid = heroObj:getprop("type")
	obj._lv = heroObj:getprop("level")
    obj._consume = heroObj:getprop("consume")
    obj._maxHp = heroObj:getprop("maxHP")
    obj._hp = heroObj:getprop("hp")
    obj._power = heroObj:getprop("powerBar")
    obj._maxPower = heroObj:getprop("maxPower")
	obj._skillReady = false

    obj:egChangeImg(kImgHero,hero_data.getConfig(obj._heroid).headPic,UI_TEX_TYPE_PLIST)
    obj:egSetBarPercent(kBarHp,obj._hp*100/obj._maxHp)
    obj:egSetBarPercent(kBarPower,obj._power*100/obj._maxPower)
	if obj._heroObj:isEmemy() then
	    obj:egSetWidgetColor(kBarHp,kRedColor)
		obj:egChangeImg(kImgLv,ImageList.risk_lv_red,UI_TEX_TYPE_PLIST)
	else
		obj:egSetWidgetColor(kBarHp,kGreenColor)
		obj:egChangeImg(kImgLv,ImageList.risk_lv_green,UI_TEX_TYPE_PLIST)
	end
    obj:egSetBMLabelStr(kLabelLv,obj._lv)
    obj:egSetLabelStr(kLabelCost,string.format("cost %d",obj._consume))
    obj:egHideWidget(kImgFull)
    obj:showScaleAction(kImgGo,1,0.8,1)
end
--��ʾ���Ŷ���
function __battlehero.showScaleAction(obj,widgetName,s,scale1,scale2)
    local widget = obj:egGetWidgetByName(widgetName)
    local scaleto1 = CCScaleTo:create(s,scale1)
    local scaleto2 = CCScaleTo:create(s,scale2)
    local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
    local repeatever = CCRepeatForever:create(sequence)
    widget:runAction(repeatever)
end
--���ز������Ŷ����Ŀؼ�
function __battlehero.hideScaleWidget(obj,widgetName)
    local widget = obj:egGetWidgetByName(widgetName)
    widget:stopAllActions()
    widget:setVisible(false)
end
--����Ѫ��ŭ����ʾ��ʱ��,ͬʱ����������ʾ
function __battlehero.activeHeroTimer(obj)
    obj:egHideWidget(kLabelCost)
    obj:hideScaleWidget(kImgGo)
    obj:bindFocusListener() --��touch�¼�
    local function callback(delta)
        local curhp = obj._heroObj:getprop("hp")
        if curhp <= 0 then
            obj:killHero()
        else
            obj._survivalTime = obj._survivalTime + delta
            --Ѫ����ʾ
            if curhp ~= obj._hp then
                obj._hp = curhp
                obj:egSetBarPercent(kBarHp,curhp*100/obj._maxHp)
                obj:egSetWidgetColor(kImgHero,kWhiteColor)
            end
            --ŭ����ʾ
			if not obj._skillReady  then
				local curPower = obj._heroObj:getprop("powerBar")
				obj._power= math.min(curPower,obj._maxPower)
				obj:egSetBarPercent(kBarPower,math.min(obj._power*100/obj._maxPower,100))
				if obj._power >= obj._maxPower then
					obj._skillReady = true
					obj:egShowWidget(kImgFull)
					SoundHelper.playEffect(SoundList.energe_ready)
					obj:egSetWidgetTouchEnabled(kImgBg,false)
					if obj._skillReadyCallback then obj._skillReadyCallback(obj) end
					obj:showScaleAction(kImgFull,1,0.95,1)
				end
			 end
        end
    end
    obj:egBindWidgetUpdate(kImgHero,callback)
end
--ǿ�ƽ�Ӣ��Ѫ��Ϊ0
function __battlehero.killHero(obj)
    obj:egUnbindWidgetUpdate(kImgHero)
    obj:egSetWidgetTouchEnabled(kImgBg,false)
    obj:egSetWidgetTouchEnabled(kImgFull,false)
    if obj._heroObj then
        obj._heroObj:setprop("hp",0)
        obj._heroObj = nil
    end
    obj._hp = 0
    obj._isDead = true
    obj:egSetWidgetColor(kImgHero,kGrayColor)
    obj:egSetBarPercent(kBarHp,0)
    obj:egSetBarPercent(kBarPower,0)
    obj:hideScaleWidget(kImgFull)
    if obj._diedCallback then obj._diedCallback(obj) end
end
function __battlehero.getHeroID(obj)
    return obj._heroid
end
function __battlehero.getHP(obj)
    return obj._hp
end
function __battlehero.getPower(obj)
    return obj._power
end
function __battlehero.getPerOfHP(obj)
	return obj:egGetBarPercent(kBarHp)
end
function __battlehero.getPerOfPower(obj)
	return obj:egGetBarPercent(kBarPower)
end
--�ܼ�������ֵ
function __battlehero.getTotalConsume(obj)
    local total = math.floor(obj._consume * obj._survivalTime)
    return total
end

function __battlehero.getHeroObj(obj)
	return obj._heroObj
end
--ƽ������
function __battlehero.getConsume(obj)
    return obj._consume
end
--����ս��
function __battlehero.enterBattle(obj)
    obj:hideScaleWidget(kImgGo) --����GO��ʶ
    SoundHelper.playEffect(SoundList.hero_go)
	if obj._isEntered then return end
	if obj._enterCallback then obj._enterCallback(obj) end
    obj:egSetWidgetTouchEnabled(kImgBg,false)
    obj._isEntered = true --��ǽ���ս��
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local x,y = creaturelayer:getPosByIdx(obj._heroObj:getprop("birthPlace"))
    local function callback2()
        if obj._heroObj then
            if obj._activeCallback then obj._activeCallback(obj) end
            obj._heroObj:openAi()
            obj._isAIActived = true
             obj:activeHeroTimer()--������ʱ��
            obj:egSetWidgetTouchEnabled(kImgBg,true)
        end
    end
    local function callback1()
        if obj._heroObj then
            obj._heroObj:moveToPos(180,x,y,0.5,callback2)
        end
    end
    local sec = (x - obj._heroObj:egGetPosX())/kSpeed
    obj._heroObj:moveToPos(90,x,obj._heroObj:egGetPosY(),sec,callback1)
end
--����AI
function __battlehero.activeAI(obj)
    obj:hideScaleWidget(kImgGo) --����GO��ʶ
    if obj._isAIActived then return end
    obj._isEntered = true
    obj._heroObj:egNode():stopAllActions()
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local x,y = creaturelayer:getPosByIdx(obj._heroObj:getprop("birthPlace"))
    obj._heroObj:openAi()
    obj._isAIActived = true
    obj._heroObj:egSetPosition(x,y)
    obj:activeHeroTimer()--������ʱ��
end
--Ӣ������
function __battlehero.onHeroDied(obj,callback)
    obj._diedCallback = callback
end
--����Ӣ��AI
function __battlehero.onHeroActived(obj,callback)
    obj._activeCallback = callback
   -- obj._heroObj:setprop("powerBar",100)
end
--Ӣ��׼���볡
function __battlehero.onHeroEntering(obj,callback)
    obj._enterCallback = callback
end
function __battlehero.onSkillReady(obj,callback)
	obj._skillReadyCallback = callback
end
--׼��ʹ�ü���
function __battlehero.onUsingSkill(obj,callback)
    obj._skillCallback = callback
end
--����볡
function __battlehero.bindEnterListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:enterBattle()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgBg,nil,nil,touchEnded,touchCanceled)
end
--�л���ͷ
function __battlehero.bindFocusListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if not obj._heroObj then return end
        obj:egSetWidgetTouchEnabled(kImgBg,false)
        local holelayer = AccountHelper:get(kHoleLayer)
        local creaturelayer = holelayer._creaturelayer
        local herox = obj._heroObj:egGetPosX()
        local heroy = obj._heroObj:egGetPosY()
        local poscenter = creaturelayer:egPosInNode(640,360)
        local x =poscenter.x -  herox
        local y = poscenter.y - heroy
        if x ==0 and y == 0 then
            obj:egSetWidgetTouchEnabled(kImgBg,true)
        else
            local function callback()
                obj:egSetWidgetTouchEnabled(kImgBg,true)
            end
            holelayer:moveInnerBy(0.5,x,y,callback)
        end
    end
    obj:egSetWidgetTouchEnabled(kImgBg,true)
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgBg,nil,nil,touchEnded,touchCanceled)
end
--ʹ�ü��ܺ�Ĳ�������
function __battlehero.afterUseSkill(obj)
	if obj._heroObj then
	   obj._heroObj:useActiveSkill()
	   obj._heroObj:setprop("powerBar",0)
	end
	local holelayer = AccountHelper:get(kHoleLayer)
	local creaturelayer = holelayer._creaturelayer
	creaturelayer:focusHero(obj._heroObj,false)
    obj._skillReady = false
end
--�����������
function __battlehero.showLightBarFadeOut(obj)
	local widget = obj:egGetWidgetByName(kImgFull)
    widget:setTouchEnabled(false)
    widget:stopAllActions()
    local scaleto = CCScaleTo:create(0.5,1.2)
    local fadeout = CCFadeOut:create(0.5)
    local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
    local function callback1()
        widget:setTouchEnabled(true)
        obj:egSetWidgetTouchEnabled(kImgBg,true)
		--obj:showSkillFire(false)
        widget:setOpacity(255)
        widget:setEnabled(false)
        widget:setVisible(false)
    end
    local callfunc = CCCallFunc:create(callback1)
    local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
    widget:runAction(sequence)
end
function __battlehero.showUsingSkillEffect(obj)
	if not obj._heroObj then return end
	local sprite = CCSprite:createWithSpriteFrameName("effect_activeskill01_010101.png")
	local prefix = "effect_activeskill01"
	local act = 1
    local dir = obj._heroObj:getDir()
	local name = graphicLoader.animaName(prefix, 1, dir)
	local anima = graphicLoader.getAnimation(name)
	local delay = graphicLoader.animaDelay(prefix, act)
	anima:setDelayPerUnit((1 / (rate or 1)) * delay)
	local animate = CCAnimate:create(anima)
	local function callback ()
		if obj._heroObj then
			obj._heroObj:egNode():removeChild(sprite,true)
		end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(animate,callfunc)
	obj._heroObj:egAddChild(sprite)
	local size = obj._heroObj:egNode():getContentSize()
	sprite:setPosition(ccp(size.width/2,size.height/2))
	sprite:runAction(sequence)
end
--ʹ�ü���
function __battlehero.doUseSkill(obj)
	--obj:showSkillReady(false)
	SoundHelper.playEffect(SoundList.energe_fire)
    if obj._heroObj then
		--obj:showSkillFire(true)
		if obj._skillCallback then obj._skillCallback(obj) end
		obj:showLightBarFadeOut()
		obj:showUsingSkillEffect()
		local holelayer = AccountHelper:get(kHoleLayer)
		local creaturelayer = holelayer._creaturelayer
		creaturelayer:focusHero(obj._heroObj,true)
		--holelayer:setPosFocused(1.2,obj._heroObj:egGetPosX(),obj._heroObj:egGetPosY(),640,360,creaturelayer:egNode())
		
        local herox = obj._heroObj:egGetPosX()
        local heroy = obj._heroObj:egGetPosY()
        local poscenter = creaturelayer:egPosInNode(640,360)
        local x =poscenter.x -  herox
        local y = poscenter.y - heroy
        if x ~=0 or y ~= 0 then
            holelayer:moveInnerBy(0.1,x,y)
        end
		obj:showSkillAction()
	end
end
function __battlehero.showSkillAction(obj)
	if obj._heroObj then
		local showObj = obj._heroObj:getActionUnit()
		local act = obj._heroObj:getStanbyAction()
		local prefix = showObj:getprop('graphName')
		local dir = obj._heroObj:getDir()
		local name = graphicLoader.animaName(prefix, act, dir)
		obj._heroObj:egNode():stopAllActions()
		if showObj ~= obj._heroObj then
			showObj:egNode():stopAllActions()
		end
		local anima = graphicLoader.getAnimation(name)
		local delay = graphicLoader.animaDelay(prefix, act)
		anima:setDelayPerUnit((1 / (rate or 1)) * delay)
		local animate = CCAnimate:create(anima)
		showObj:egNode():runAction(animate)
	end
end
--���ܵ���¼�
function __battlehero.bindSkillListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if not  obj._disableTouch then obj:doUseSkill() end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgFull,nil,nil,touchEnded,touchCanceled)
end
--����¼�������ε���볡�ͼ���ʹ�ò���
function __battlehero.disableTouch(obj)
    obj._disableTouch = true
    obj:egSetWidgetTouchEnabled(kImgBg,false)
end
BattleHero = {}
function BattleHero.new(heroObj)
    local obj = {}
    CocosWidget.install(obj,JsonList.battleHero)
    table_aux.unpackTo(__battlehero, obj)
    obj:init(heroObj)
	obj:bindEnterListener()
	obj:bindSkillListener()
    return obj
end

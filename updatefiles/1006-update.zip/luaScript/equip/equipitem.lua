local kBtnItem = "btn_equip_bg"
local kImgItem = "img_item"
local kLblLv = "lbl_lv"
local kImgLv = "img_lv"
local kImgColorBg = "img_color_bg"
local kImgColorBar = "img_light_bar"
local kImgSelected = "img_equip_selected"
local __equipitem={}
function __equipitem.init(obj,equipid)
	obj:egHideWidget(kImgSelected)
   obj:setEquipID(equipid)
end
--������Ҫ��ʾ������ID
function __equipitem.setEquipID(obj,equipid)
    obj._equipid = equipid
    obj:addprop("eid",equipid)
    
    if obj._equipid > 0 then
        obj:egShowWidget(kImgItem)
        obj:egShowWidget(kImgLv)
        --�����ȼ���Ʒ��
        obj._curlv,obj._curqa = equipFuncs.getEquipQL(obj._equipid, account_data)
        local s_cfg = equipCfg[obj._equipid]
        obj:egChangeImg(kImgItem,s_cfg.icon,UI_TEX_TYPE_PLIST)
        obj:egSetBMLabelStr(kLblLv,obj._curlv) --��ʾ�����ȼ�
        --��ʾ����Ʒ��
		obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[obj._curqa])
		obj:egSetWidgetColor(kImgColorBar,KVariantList.equipColor[obj._curqa])
		
        obj:egSetWidgetTouchEnabled(kBtnItem,true)
    else
        obj:egHideWidget(kImgItem)
        obj:egHideWidget(kImgLv)
        obj:egSetWidgetTouchEnabled(kBtnItem,false)
    end
    imgbar = obj:egGetWidgetByName(kImgColorBar)
    imgbar:setVisible(false)
end
function __equipitem.showWithAction(obj)
	local widget = obj:egGetWidgetByName(kImgItem)
	widget:setScale(0)
	local scaleto = CCScaleTo:create(0.5,0.72)
	local backout = CCEaseBackOut:create(scaleto)
	widget:runAction(backout)
	local imgbar = obj:egGetWidgetByName(kImgColorBar)
	imgbar:setVisible(true)
	imgbar:setScale(1.1)
	imgbar:setOpacity(255)
	local scaleto = CCScaleTo:create(0.3,1)
	local fadeout = CCFadeOut:create(0.3)
	imgbar:runAction(CCSequence:createWithTwoActions(scaleto,fadeout))
end
function __equipitem.setSelected(obj,selected)
	local widget = obj:egGetWidgetByName(kBtnItem)
    widget:setFocused(selected)
	if selected then
		obj:egShowWidget(kImgSelected)
	else
		obj:egHideWidget(kImgSelected)
	end
end
--ˢ��װ���ȼ�
function __equipitem.updateEquipLv(obj)
    obj:egSetBMLabelStr(kLblLv,account_data.equipments[obj._equipid][1])
end
function __equipitem.updateEquipQa(obj)
	obj._curlv,obj._curqa = equipFuncs.getEquipQL(obj._equipid, account_data)
    obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[obj._curqa])
	obj:egSetWidgetColor(kImgColorBar,KVariantList.equipColor[obj._curqa])
end
--�󶨵���¼�
function __equipitem.onClicked(obj,callback)
    obj._clickCallback = callback
end
--װ������¼�
function __equipitem.doClickItem(obj,sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickCallback then obj._clickCallback(obj) end
        sender:setTouchEnabled(true)
end
function __equipitem.bindClickListener(obj)
    
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickItem(sender)
    end
	local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnItem,nil,nil,touchEnded,touchCanceled)
end
EquipItem={}
function EquipItem.new(equipid)
    local obj = {}
    CocosWidget.install(obj,JsonList.equipItem)
    table_aux.unpackTo(__equipitem, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(equipid)
    obj:bindClickListener()
    return obj
end
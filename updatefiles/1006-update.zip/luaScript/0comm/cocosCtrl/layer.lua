local __layer={}

function __layer.egLayer(obj)
	return obj._egObj
end
Layer={}

function Layer.install(obj)
	obj._egObj = CCLayer:create()
	CocosNode.install(obj)
	TouchDelegate.install(obj)
	for name, func in pairs(__layer) do
		obj[name] = func
	end
end


local fx_risk = "GUIRes/PvrCcz/m_bg/"
local fx_sprite = "GUIRes/image/sprite/"
local fx_train = "GUIRes/PvrCcz/train/"

ImageList = {
comm_timer_front = "time_pg_front.png",
comm_button = "button.png",
comm_button_bg = "buttonBackground.png",
comm_button_s = "buttonHighlighted.png",
comm_bar_bg_load = "bar_bg_load.png",
comm_bar_ft_load = "bar_ft_load.png",
comm_cd = "pic_cd_00.png",
comm_res_bg = "res_bg.png",

comm_gold = "icon_gold.png",
comm_oil = "icon_oil.png",
comm_dig = "bar_icon_dig.png",
comm_jewel = "icon_jewel.png",
comm_iron = "icon_iron.png",
comm_copper = "icon_copper.png",
comm_stoneR = "icon_stoneR.png",
comm_stoneB = "icon_stoneB.png",
comm_stoneD = "icon_stoneD.png",
comm_exp = "icon_exp.png",

comm_lv = "digLv.png",
comm_time = "bar_icon_timer.png",
comm_elo = "elo.png",
comm_note_lvup = "note_lvup.png",
comm_note_func = "note_func.png",

comm_load_bg = "time_bg.png",
comm_load_bar = "time_pg_front.png",
comm_load_front = "time_pg_bg.png",
comm_focus_button = "btn_brown.png",
comm_focus = "red_circle.png",
comm_focus_hand = "hand.png",

comm_box_gold = "box_gold_0.png",
comm_box_gold_open ="box_gold_3.png",

comm_box_copper = "box_copper_0.png",
comm_box_copper_open = "box_copper_3.png",

comm_box_silver = "box_silver_0.png",
comm_box_silver_open = "box_silver_3.png",

btn_brown_n = "btn_brown.png",
btn_brown_s = "btn_brown_pressed.png",
btn_brown_d = "btn_brown_disabled.png",

btn_fat_n = "btn_fat.png",
btn_fat_s = "btn_fat_pressed.png",
btn_fat_d = "btn_fat_disabled.png",

btn_pvp_n = "btn_fight.png",
btn_pvp_s = "btn_fight_pressed.png",
btn_pvp_d = "btn_fight_disabled.png",

btn_expedition_n = "btn_exfight.png",
btn_expedition_s = "btn_exfight_pressed.png",
btn_expedition_d = "btn_exfight_disabled.png",

btn_invite_n = "btn_invite.png",
btn_invite_s = "btn_invite_pressed.png",
btn_invite_d = "btn_invite_disabled.png",

btn_grow_n = "btn_grow.png",
btn_grow_s = "btn_grow_pressed.png",
btn_grow_d = "btn_grow_disabled.png",

btn_def_n = "btn_def.png",
btn_def_s = "btn_def_pressed.png",
btn_def_d = "btn_def_disabled.png",

btn_arrow_n = "btn_putaway.png",
btn_arrow_s ="btn_putaway_pressed.png",


pve_atk = "icon_atk.png",
pve_atk2 = "icon_atk1.png",
pve_dfs = "icon_def.png",
pve_boss = "icon_boss.png",

cofc_showbox = "showbox.png",
cofc_selectbox = "select_box.png",
cofc_unknownhero = "hero_00.png",

lvup_star = "star_full.png",
lvup_starnull = "star_null.png",
star = "star.png",

risk_lv_green = "lv_green.png",
risk_lv_red ="lv_red.png",
risk_name_green ="name_green.png",
risk_name_red ="name_red.png",

other_tile = fx_sprite.."tile.pvr.ccz",
risk_mask_atk = fx_risk.."atk_mask.pvr.ccz",
risk_mask_def = fx_risk.."def_mask.pvr.ccz",
town_train_updating = fx_train.."train_updating.pvr.ccz",
town_train_head_updating = fx_train.."train_head_updating.pvr.ccz",

mail_opened = fx_risk.."mail_opened.pvr.ccz",
mail_closed = fx_risk.."mail_closed.pvr.ccz",
box_light_bg = fx_risk.."box_light_1.pvr.ccz",
ex_map_bg = fx_risk.."exmap.pvr.ccz",
}

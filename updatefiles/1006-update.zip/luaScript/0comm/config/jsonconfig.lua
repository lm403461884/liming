JsonList={

 atkLayer = "GUIRes/02atkLayer.json",
 bagItem = "GUIRes/02bagItem.json",
 shopLayer = "GUIRes/02shopLayer.json",
 battleHero = "GUIRes/02battleHero.json",
 battleResult = "GUIRes/02battleResult.json",
 cofcLayer="GUIRes/02cofcLayer.json",
 --cofcDefMission = "GUIRes/02cofc_def_mission.json", --暂时没有防御关卡
 --cofcMission = "GUIRes/02cofc_mission.json", --取消列表显示方式
 digLayer = "GUIRes/02digLayer.json",
 digHeadLayer = "GUIRes/02digHeadLayer.json",
 heroInfo = "GUIRes/02heroinfo_layer.json",
 --inviteLayer = "GUIRes/02inviteLayer.json",---- 修改招募后取消
 lvupHero = "GUIRes/02hero_lvup.json",
 loadingLayer = "GUIRes/02loadingLayer.json",
 
 loginLayer = "GUIRes/02loginLayer.json",
 logoLayer = "GUIRes/02logoLayer.json",
 battleWaitLayer = "GUIRes/battle_wait_layer.json",
 lvupLayer = "GUIRes/02lvupLayer.json",
 postLayer = "GUIRes/02postlayer.json",
 --noteItem = "GUIRes/02post_noteitem.json",
 pvpItem = "GUIRes/02post_pvpitem.json",
 mailItem = "GUIRes/02mailitem.json",
 mailInfo = "GUIRes/02mail_info.json",
 propLayer = "GUIRes/02propLayer.json",
 propLayerDig = "GUIRes/02propLayer_dig.json",
--preparePvp = "GUIRes/02pvpLayer_pre.json", --PVP改为进攻方式后,防御方式的界面不用了
 storyLayer = "GUIRes/02storyLayer.json",
 townTrain = "GUIRes/02town_train.json",
 
 msglayer ="GUIRes/msgLayer.json",
 worldmapScene = "GUIRes/worldmap.json", 
 digmapLayer = "GUIRes/02dig_map_layer.json",
 
 -- 怪物车箱
 monsterLayer ="GUIRes/02monsterlayer.json",
 monsterCard = "GUIRes/02monstercard.json",
 popMonsterCard = "GUIRes/02popmonstercard.json",
 --monsterLayer = "GUIRes/02monster_train_layer.json", 修改生物车箱后替换
 --monsterkind = "GUIRes/02monster_kind_item1.json",修改生物车箱后删除
 monsterInfo = "GUIRes/02monster_info_item.json",
 trainingInfo = "GUIRes/02training_info.json",
 
 digPrompt = "GUIRes/02digPrompt.json",
 chemyPromt = "GUIRes/02promptLayer0.json",
 pvpPromt = "GUIRes/02promptLayer1.json",
 licencePromt = "GUIRes/02promptLayer2.json",
 trainPromt = "GUIRes/02promptLayer3.json",
 teamMember = "GUIRes/02member.json",
 teamLayer = "GUIRes/02exteamLayer.json",
 teamRightNow = "GUIRes/02memberItem.json",
 monsterItem = "GUIRes/02monsterItem.json",
 
 menuLayer = "GUIRes/02menuLayer.json",
 trainFuncLayer = "GUIRes/02trainFuncLayer.json",
 trainBgLayer = "GUIRes/02trainBgLayer.json",
 trainSubUpdate = "GUIRes/02trainSubUpdate.json",
 battleTool = "GUIRes/02BattleTool.json",
 trainBuyLayer = "GUIRes/02trainBuyLayer.json",
 trainInfo = "GUIRes/02trainInfo.json",
 
 shopItem = "GUIRes/02shopItem.json",
 shopItemDetail = "GUIRes/02shopItemDetail.json",
--previewPvp = "GUIRes/02pvpLayer_view.json", --PVP改为进攻方式后,防御方式的界面不用了
 monsterHead="GUIRes/02monsterHead.json",
 toolHead = "GUIRes/02toolHead.json",
 pvpPrompt = "GUIRes/02pvpPrompt.json",
 heroHead = "GUIRes/02heroHead.json",
 --heriItemBtn="GUIRes/02heroitembtn.json",-- 修改招募后取消
 
 growLayer="GUIRes/02growlayer.json",
 growRate="GUIRes/02growrate.json",
 growInfo="GUIRes/02growinfo.json",
 growHero="GUIRes/02growHero.json",
 growBg="GUIRes/02growbg.json",
 growMonster="GUIRes/02growMonster.json",
 
 guildLayer = "GUIRes/guild_bg_layer.json",
 setupLayer = "GUIRes/guild_setup_layer.json",
 searchLayer = "GUIRes/guild_search_layer.json",
 guildMemberItem = "GUIRes/guild_item.json",
 guildInfo = "GUIRes/guild_info.json",
 chatLayer = "GUIRes/guild_chat_layer.json",
 msgItem = "GUIRes/guild_inter_msg.json",
 pubMsgItem = "GUIRes/chat_pub_msg.json",
 msgExtend  = "GUIRes/pub_msg_extend.json",
 guildView = "GUIRes/guildview.json",
 
 popTxt = "GUIRes/02popTxt.json",
 mineFlag = "GUIRes/02MineFlag.json",
 popSign = "GUIRes/02popsign.json",
 --PVP改为进攻方式后新增
 pvpAtkPre="GUIRes/02pvpatk_pre.json",
 pvpAtkView="GUIRes/02pvpatk_view.json",
 cofcAtkMission="GUIRes/02cofc_atk_mission.json",
 
 defTaskLayer = "GUIRes/02def_task_layer.json",
 defTaskItem="GUIRes/02def_task_item.json",
 defTaskPre="GUIRes/02def_task_pre.json",
 defAward="GUIRes/02def_award.json",
 defAwardItem="GUIRes/02def_award_item.json",
 
 videoLayer = "GUIRes/02videolayer.json",
 blood = "GUIRes/02blood.json",
 rankLayer = "GUIRes/02ranklayer.json",
 rankItem = "GUIRes/02rankitem.json",
 quitLayer = "GUIRes/02quitPrompt.json",
 
 --装备相关
 imgProp = "GUIRes/02imgprop.json", --装备升级所需属性项
 equipItem = "GUIRes/02equip_item.json",
 equipLayer = "GUIRes/equipLayer.json",
 equipHeroItem = "GUIRes/02equip_hero_item.json",
 --任务
 pveMission = "GUIRes/02pvemission.json",
 pveMap = "GUIRes/02pvemap.json",
 
 pubLayer="GUIRes/02publayer.json",
 pubHero="GUIRes/02pubhero.json",
 heroMsg="GUIRes/02heromsg.json",
 popHeroCard="GUIRes/02popherocard.json",
 popMail="GUIRes/02popmail.json",
 popCharge="GUIRes/02popcharge.json",
 
 heroMsgAward = "GUIRes/02awardhero.json",
 resAward = "GUIRes/02awardres.json",
 
 pubUserInfo = "GUIRes/02pubUserInfo.json",
 pubHeroCard = "GUIRes/02pubHeroCard.json",
  
 digJournal= "GUIRes/dig_journal_layer.json",
 taskItem = "GUIRes/dig_journal_item.json",
 equipQa = "GUIRes/02equip_qa.json",
 nickNameLayer = "GUIRes/02nicknamelayer.json",
 verctrlayer = "GUIRes/02verCtrlayer.json",
 ---------------
 expeditionItem = "GUIRes/02expeditionItem.json",
 expeditionCard= "GUIRes/02expeditionCard.json",
 expeditionLayer= "GUIRes/02expeditionlayer.json",
 expeditionMap = "GUIRes/02expeditionmap.json",
 expeditionLoad =  "GUIRes/02expeditionload.json",
 
}

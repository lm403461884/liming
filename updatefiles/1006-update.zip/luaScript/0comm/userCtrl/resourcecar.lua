
--local kImageResbg = {ImageList.comm_res_bg}
local kactStand = "grab_stand"
local kactGrab = "grab_action"
local kFlagW = 22
local kFlagH = 23
local kCellW = 72
local kGreenColor = ccc3(144,238,144)--ccc3(40,200,150)
local __resourceCar={}
function __resourceCar.initprop(obj,prop,idx)
	obj._s_data = collectorCfg[prop.lv]
	obj._d_data= prop
	obj._standAct = nil
	obj._grabAct = nil
	for name,val in pairs(obj._s_data) do
		obj:addprop(name,val)
	end
	if not prop.st then prop.st = 0 end
	if not prop.elapsed then prop.elapsed = 0 end
	if not prop.coin then prop.coin = 1 end
	obj:addprop('mainType', 4)
	obj:addprop('idx', idx) --���ʺ��е�����λ��
	obj:addprop("level", prop.lv)
	obj:addprop("coin", prop.coin)
	obj:addprop('lastDigTime',prop.st) --最后一次采集时�?
	obj:addprop("birthPlace", prop.pos)
	obj:addprop('graphName',obj._s_data.img)
	obj:addprop('actStand',kactStand)
	obj:addprop('actGrab',kactGrab)
	obj:addprop("aiEntryName", "ResourceCar")			--null ai entry table
	obj:addprop("skillNames", {})				--null skill list
	obj:addprop("hp", obj:getprop("maxHP"))
end
function __resourceCar.init(obj,btdata)
	obj._activeAI = false
	obj._btdata = btdata
	obj:egChangeFrame(obj._s_data.img)
	obj:egNode():setAnchorPoint(ccp(0.5,0.5))
	obj:loadCDBar()
	obj:loadResFlag() --������Դ��ʾ��ʶ
	targetMine = obj._btdata.mileSpread[obj._d_data.pos]
	obj:showCoin(false)
	if targetMine then --�ж��Ƿ���ڿ��ϣ��������ɼ���ʱ��
		if not targetMine.dt then targetMine.dt = 0 end
        obj:bindMileTimer()
	else  --û�з��ڿ���
		obj:playActionByName(kactStand)	
	end
end
--����ȴ��ʱ��
function __resourceCar.bindMileTimer(obj)	
	local targetMine = obj._btdata.mileSpread[obj._d_data.pos]
	if targetMine then
        if targetMine.dt > 0 then
            obj:playActionByName(kactGrab)	
            local mine_cfg = mile_data.get(targetMine.type, targetMine.lv)
            local per = math.max(targetMine.dt,0)*100/mine_cfg.gainInt
            obj._leftTime,obj._timeUnit = Funs.formmatTimeCh2(targetMine.dt,true)
            obj._lblNum:setText(obj._leftTime)
            obj._lblCH:setText(obj._timeUnit)
            obj._cdsprite:setPercentage(per)
            obj._cdsprite:setVisible(true)
            obj._cdsprite:runAction(CCProgressFromTo:create(targetMine.dt,per,0))
            local function callback(delta)
                if targetMine.dt <= 0 then
                    obj:showCoin(true)
                    obj:playActionByName(kactStand)	
                    obj:unBindMileTimer()
                else
                    local leftTime,timeUnit = Funs.formmatTimeCh2(targetMine.dt,true)
                    if leftTime ~= obj._leftTime then
                        obj._leftTime = leftTime
                        obj._lblNum:setText(obj._leftTime)
                    end
                    if obj._timeUnit~=timeUnit then
                        obj._timeUnit = timeUnit
                        obj._lblCH:setText(obj._timeUnit)
                    end
                end
            end
            obj:egBindUpdateWithPriorityLua(callback)	
        else
            obj:showCoin(true)	
            obj:playActionByName(kactStand)	
        end
	end
end
function __resourceCar.unBindMileTimer(obj)
	obj._cdsprite:setVisible(false)
	obj:egUnbindUpdateWithPriorityLua() --�رղɼ���ʱ��
end
--���Ųɼ�����
function __resourceCar.playActionByName(obj,actName)
	 local animaCache = CCAnimationCache:sharedAnimationCache()
	local anima = animaCache:animationByName(actName)
    local animate = CCAnimate:create(anima)
	local action = CCRepeat:create(animate, 10000000)
	if obj._standAct then
		obj:egNode():stopAction(obj._standAct)
		obj._standAct = nil
	end
	if obj._grabAct then
		obj:egNode():stopAction(obj._grabAct)
		obj._standAct = nil	
	end
	if actName == kactStand then
		obj._standAct = action
	else
		obj._grabAct = action
	end
    obj:egRunAction(action)
end
--������Դͼ��
function __resourceCar.loadResFlag(obj)
	local cointype = math.max(obj._d_data.coin,1) 
	obj._coin = ImageView:create()
    obj._coin:loadTexture(ImageList[string.format("comm_%s",KVariantList.coinType[cointype])],UI_TEX_TYPE_PLIST)
    obj._coin:setScaleX(kFlagW/obj._coin:getSize().width)
	 obj._coin:setScaleY(kFlagH/obj._coin:getSize().height)
	 obj._coin:setPosition(ccp(2,2))
    obj._coinBg = ImageView:create()
    obj._coinBg:loadTexture(ImageList.comm_res_bg,UI_TEX_TYPE_PLIST)
    obj._coinBg:setScale(0.6)
	obj._coinBg:setColor(kGreenColor)
    obj._coinObj = Widget:create()
    local size = obj:egNode():getContentSize()
    obj._coinObj:addChild(obj._coinBg,1,1)
    obj._coinObj:addChild(obj._coin,2,2)
    obj._coinObj:setAnchorPoint(ccp(0.5,0))
    obj._coinObj:setPosition(ccp(size.width/2,size.height/2 + 15))
	
    obj:egAddChild(obj._coinObj)
    obj._coinObj:setVisible(false)
end
	--������ȴ��ʾ�ؼ�
function __resourceCar.loadCDBar(obj)
    local sprite = CCSprite:createWithSpriteFrameName(ImageList.comm_cd)
    local size = sprite:getContentSize()
    local scale = kCellW/size.width
    
    obj._cdsprite = CCProgressTimer:create(sprite)
    obj._cdsprite:setScale(scale)
    local carSize = obj:egNode():getContentSize()
    obj._cdsprite:setPosition(ccp(carSize.width/2,carSize.height/2))
	obj._cdsprite:setType(kCCProgressTimerTypeRadial)
	obj:egAddChild(obj._cdsprite)

	obj._lblNum = LabelBMFont:create()
	obj._lblNum:setFntFile(FNList.BlackNum)
	obj._lblNum:setScale(0.6)
	obj._lblNum:setPosition(ccp(size.width/4,size.height/2))
	obj._cdsprite:addChild(obj._lblNum)
	
	obj._lblCH = LabelBMFont:create()
	obj._lblCH:setFntFile(FNList.BlackTime)
	obj._lblCH:setScale(0.65)
	obj._lblCH:setPosition(ccp(size.width*3/4,size.height/2))
	obj._cdsprite:addChild(obj._lblCH)
	
	obj._cdsprite:setVisible(false)
end
--��ʾ��������Դ��ʶ
function __resourceCar.showCoin(obj,show)
	if show then
		local scaleto1 = CCScaleTo:create(1,1)
		local scaleto2 = CCScaleTo:create(1,0.9)
		local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
		local repeatever = CCRepeatForever:create(sequence)
		local cointype = math.max(obj._d_data.coin,1) 
        obj._coinObj:setVisible(true)
        obj._coin:loadTexture(ImageList[string.format("comm_%s",KVariantList.coinType[cointype])],UI_TEX_TYPE_PLIST)
		obj._coin:setScaleX(kFlagW/obj._coin:getSize().width)
		obj._coin:setScaleY(kFlagH/obj._coin:getSize().height)
		obj._coin:setPosition(ccp(2,2))
        obj._coinObj:runAction(repeatever)
	else
       obj._coinObj:stopAllActions()
       obj._coinObj:setVisible(false)
	end
end
--�ƶ���������
function __resourceCar.moveToMine(obj,idx)
    local gainVal,coinType = obj:doCollectRes() 
	obj:unBindMileTimer()
    local old_targetMine = obj._btdata.mileSpread[obj._d_data.pos]
    local mineIdx = obj._d_data.pos
    local targetMine = obj._btdata.mileSpread[idx]
	obj._d_data.st = os.time()
	obj._d_data.elapsed = 0
    obj._d_data.pos=idx
	targetMine.st = os.time()
    obj._d_data.coin = targetMine.type
	if old_targetMine then
	   
	    local holelayer = AccountHelper:get(kHoleLayer)
		blocklayer = holelayer._blocklayer
		blocklayer._mineFlags[mineIdx]:updateMineFlag()
		old_targetMine.st = nil
	end
	
	
	obj:setprop("birthPlace", obj._d_data.pos)
	obj:setprop("lastDigTime", obj._d_data.st)
	local holelayer = AccountHelper:get(kHoleLayer)
	blocklayer = holelayer._blocklayer
	blocklayer._mineFlags[obj._d_data.pos]:updateMineFlag()
    obj:bindMileTimer()
	return gainVal,coinType
end
function __resourceCar.moveToBlank(obj,idx)
	local gainVal,coinType = obj:doCollectRes() 
	local targetMine = obj._btdata.mileSpread[obj._d_data.pos]
	local mineIdx = obj._d_data.pos
	obj._d_data.st = os.time()
	obj._d_data.elapsed = 0
    obj._d_data.pos=idx
    obj._d_data.coin = 0
	if targetMine then
	   
	    local holelayer = AccountHelper:get(kHoleLayer)
		blocklayer = holelayer._blocklayer
		blocklayer._mineFlags[mineIdx]:updateMineFlag()
		targetMine.st = nil
	end

	obj:setprop("birthPlace", obj._d_data.pos)
	obj:setprop("lastDigTime", obj._d_data.st)
	return gainVal,coinType
end
--�Ƿ�����Դ
function __resourceCar.hasRes(obj)
	local targetMine = obj._btdata.mileSpread[obj._d_data.pos]
	if targetMine and targetMine.dt <= 0 then return true end
	return false
end
--�ռ���Դ����ʾ��ʾ��Ϣ
function __resourceCar.doCollectRes(obj)
	local targetMine = obj._btdata.mileSpread[obj._d_data.pos]
	obj._d_data.st=os.time()
	obj._d_data.elapsed = 0
	obj:setprop('lastDigTime',obj._d_data.st) --���²ɼ�ʱ��
	obj:showCoin(false)
	obj:unBindMileTimer()
	obj:playActionByName(kactStand)	
	local gainval = 0
	local cointype = 1
	if targetMine and targetMine.dt <= 0 then
		local holelayer = AccountHelper:get(kHoleLayer)
		blocklayer = holelayer._blocklayer
		local mine_cfg = mile_data.get(targetMine.type, targetMine.lv)
		cointype = targetMine.type
		gainval = mine_cfg.gainVal
		targetMine.cnt = targetMine.cnt -gainval
		targetMine.st = os.time()
		targetMine.dt = mine_cfg.gainInt
		if targetMine.cnt > 0 then
				obj:bindMileTimer()
		else
				blocklayer._minerals[obj._d_data.pos]:showBrokenActions()
		end
		blocklayer._mineFlags[obj._d_data.pos]:updateMineFlag()
		local coinName = KVariantList.coinType[cointype]
		account_data[coinName] = account_data[coinName] + gainval --�޸��ʻ�����
		SendMsg[932007](obj:getprop("idx"),gainval)
	end
	--�ھ���־������̸���,�ռ���Դ
	if gainval > 0 then
		task.updateTaskStatus(account_data,task.client_event_id.getdig_mile,{cointype,gainval})	
	end
	----------------------------------------------------------
	return  gainval,cointype
end

function __resourceCar.setSelected(obj,selected)
	if selected then
		obj:egSetAlpha(160)
	else
		obj:egSetAlpha(255)
	end
end
function __resourceCar.openAi(obj)
	obj._activeAI = true
	ai_module.add(obj)
	obj:unBindMileTimer()
	obj:showCoin(false)
	obj:showHP()
end
ResourceCar={}
function ResourceCar.new(prop,idx,btdata)
	local obj = {}
    table_aux.unpackTo(__resourceCar, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
	Blood.install(obj)
    sprite.install(obj)
	obj:initprop(prop,idx)
	obj:init(btdata)
    return obj
end
function ResourceCar.init(ai) ai:wakeup() ai:showHP()  end
function ResourceCar.policy() end
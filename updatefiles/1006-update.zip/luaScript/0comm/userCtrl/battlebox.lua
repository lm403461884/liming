local kCellW = 110
local __battlebox={}
function __battlebox.init(obj)
	obj._imgarrow = CCSprite:createWithSpriteFrameName(ImageList.comm_note_lvup)
	local w = obj:egNode():getContentSize().width
	local h = obj:egNode():getContentSize().height
	obj._imgarrow :setPosition(ccp(-30 + w/2,80 + h/2))
	obj._imgarrow :setScale(0.8)
	obj._imgarrow:setFlipY(true)
	obj:egAddChild(obj._imgarrow )
	obj._scale = kCellW/w
	obj:egNode():setScale(obj._scale)
end
function __battlebox.runStandAction(obj)
	obj:egNode():setScale(0)
	local scaleIn = CCScaleTo:create(0.5,obj._scale)
	local backout =CCEaseBackOut:create(scaleIn)
	local function callback()
		local moveby1 = CCMoveBy:create(1,ccp(0,-5))
		local scale1 = CCScaleTo:create(1,obj._scale - 0.02)
		local spawn1= CCSpawn:createWithTwoActions(moveby1,scale1)
		local moveby2 = CCMoveBy:create(1,ccp(0,5))
		local scale2 = CCScaleTo:create(1,obj._scale + 0.02)
		local spawn2= CCSpawn:createWithTwoActions(moveby2,scale2)
		local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
		local repeatever = CCRepeatForever:create(sequence)
		obj:egRunAction(repeatever)
	end
	local callfunc = CCCallFunc:create(callback)
	local sequenceshow = CCSequence:createWithTwoActions(backout,callfunc)
	obj:egRunAction(sequenceshow)
	
	local scale11 = CCScaleTo:create(0.5,0.9)
	local scale12 = CCScaleTo:create(0.5,0.8)
	local sequence11 = CCSequence:createWithTwoActions(scale11,scale12)
	local repeatever11 = CCRepeatForever:create(sequence11)
	obj._imgarrow:runAction(repeatever11)
	
end
function __battlebox.removeWithAction(obj,offsetx,offsety)
	obj._imgarrow:stopAllActions()
	obj._imgarrow:setVisible(false)
	local jumpby = CCJumpBy:create(0.3,ccp(offsetx,offsety),kCellW/2,1)
	local function callback()
		obj:egRemoveSelf()
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(jumpby,callfunc)
	obj:egRunAction(sequence)
end
BattleBox={}

--�����������
function BattleBox.new(pos,mtype)
	local obj = {}
    table_aux.unpackTo(__battlebox, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
	sprite.install(obj,ImageList[string.format("comm_box_%s",KVariantList.boxType[mtype])],true)
	
 	obj:addprop("birthPlace", pos)
	obj:addprop("boxType", mtype)
	obj:init()
	return obj
end


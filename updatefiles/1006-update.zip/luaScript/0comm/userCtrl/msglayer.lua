local kBtnOk = "Button_ok"
local kBtnCancel ="Button_cancel"
local kLblTitle = "Label_title"
local kLblContext = "Label_content"
_msglayer={}
btnYesNo=2

function _msglayer.show(obj)
    local scene = CCDirector:sharedDirector():getRunningScene()
     scene:addChild(obj:egNode(),UILv.msgLayer,UILv.msgLayer)
end
function _msglayer.bindOkListener(obj)
    local function touchEnd(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods) --确认
        if obj._callback1 then obj._callback1(sender) end
        obj:egRemoveSelf()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnd,nil) 
end
function _msglayer.bindCancelListener(obj)
    local function touchEnd(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods) --确认
        if obj._callback2 then obj._callback2(sender) end
        obj:egRemoveSelf()
    end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnd,nil) 
end
function _msglayer.init(obj)
------------------------------------------button 
		if obj._msgbtn~=btnYesNo then
		    obj:egGetWidgetByName(kBtnOk):setPosition(ccp(640,246))
 		    obj:egHideWidget(kBtnCancel)
		end
-------------------------------------------label
        if obj._msg1 then
            obj:egSetLabelStr(kLblTitle, obj._msg1)            
		else 
            obj:egHideWidget(kLblTitle)
		end
		if obj._msg2 then
		    obj:egSetLabelStr(kLblContext,obj._msg2)
        else  
            obj:egHideWidget(kLblContext)
		end
end

MsgLayer={}
function MsgLayer.new(msg1,msg2,msgbtn,callback1,callback2)
     local obj=TouchWidget.new(JsonList.msglayer)
	 table_aux.unpackTo(_msglayer,obj)
	 obj._msg1=msg1
	 obj._msg2=msg2
	 obj._msgbtn=msgbtn
	 obj._callback1=callback1
	 obj._callback2=callback2
	 obj:egSetTouchPriority(-256)
	 obj:init()
	 obj:bindOkListener()
	 obj:bindCancelListener()
	 return obj
	end

local kPanelMember = "member_panel"
local kPanelCard = "hero_list"
local kPanelItem = "item_list"
local kBtnBack = "btn_back"
local kImgBack = "img_back"
local kLblTrain ="lbl_train"  --̽�ն�
local kLblAttack = "lbl_attack"
local kLblConsume = "lbl_material"  --��ս���ʣ�ս��������������
local kCellW1 = 150
local kCellW2 = 200
local kMarginX1 = 10
local kMaxNum = 7
local __teamlayer = {}
function __teamlayer.init(obj)
    obj._selectedCardIdx = nil
    obj._selectedItemIdx = nil
    obj._heroItems = {} --Ӣ�ۿ�
    obj._heroCards = {} --Ӣ�ۿ�Ƭ
    obj._oldTeam = Funs.copy(obj._d_data.team)
    obj:initHeroBp()
    obj._heroIdList = obj:getOrderdHeroList()
    obj._trainLv = 1
	obj._loadCnt = 0
    if obj._d_data.train[train.def.anteroom] then
        obj._trainLv = obj._d_data.train[train.def.anteroom].lv
    end
    obj:egSetLabelStr(kLblTrain,string.format("%s LV%d",TxtList.riskTeam,obj._trainLv))
    obj:egSetLabelStr(kLblConsume,obj._d_data.consume)--��ս����
    obj:refreshTeamAtkCap()
	obj:doLoading()
    obj:loadHeroItems()
end
--����ļ������Ӣ��ս�������ݱ�
function __teamlayer.initHeroBp(obj)
	obj._heroBpTb={}
    for heroid,heroprop in pairs(obj._d_data.heroList) do
		obj._heroBpTb[heroid] = RiskHelper.getHeroBp(heroprop,obj._d_data)
    end
end
--��ȡ��ս���������Ӣ���б�
function __teamlayer.getOrderdHeroList(obj)
	local teamHash = {}
	local memberTb = {}
	local teamTb = {}
	for key,heroid in ipairs(obj._d_data.team) do
		teamHash[heroid] = 1
		table.insert(teamTb,heroid)
	end
	for heroid,herobp in pairs(obj._heroBpTb) do
		if not teamHash[heroid] then table.insert(memberTb,heroid) end
	end
	table.sort(teamTb,function(a,b) return obj._heroBpTb[a] > obj._heroBpTb[b] or (obj._heroBpTb[a]==obj._heroBpTb[b] and a > b) end)
	table.sort(memberTb,function(a,b) return obj._heroBpTb[a] > obj._heroBpTb[b] or (obj._heroBpTb[a]==obj._heroBpTb[b] and a > b) end)
	for idx = #teamTb,1,-1 do
		table.insert(memberTb,1,teamTb[idx])
	end
	return memberTb
end
--����С��ս������ֵ��ʾ
function __teamlayer.refreshTeamAtkCap(obj)
    local teamAtk = 0
    for key,heroid in ipairs(obj._d_data.team) do
        teamAtk = teamAtk + obj._heroBpTb[heroid]
    end
    obj:egSetLabelStr(kLblAttack,teamAtk)
end

function __teamlayer.addHeroCard(obj,num)
	local scrollview = obj:egGetScrollView(kPanelCard)
	if obj._loadCnt >= #obj._heroIdList then return end
	local startIdx = math.min(obj._loadCnt + 1,#obj._heroIdList)
	local endIdx = math.min(obj._loadCnt+num,#obj._heroIdList)
	for idx = startIdx,endIdx do
		local heroid = obj._heroIdList[idx]
		local herocard =  HeroCard.new(heroid)
        scrollview:addChild(herocard:egNode())
        herocard:egSetPosition(obj._loadCnt*kCellW2,0)
        obj._heroCards[heroid] = herocard
        obj:bindJoinTeamCallback(herocard)
		obj._loadCnt = idx
	end
end
--�󶨿�Ƭ���Ƶ���¼�
function __teamlayer.bindJoinTeamCallback(obj,herocard)
    local function callback(sender)
        local heroid = sender:getHeroID()
        table.insert(account_data.team,heroid)
        obj:reorderHeroCard()

        local pos = #account_data.team
        local heroitem = obj._heroItems[pos]
        heroitem:loadHeroAtPos(pos)
        obj:refreshTeamAtkCap()
		--�ھ���־������̸��� ����С�ӳ�Ա
		task.updateTaskStatus(account_data,task.client_event_id.team_add,{heroid})
		----------------------
    end
    herocard:onJoinClicked(callback)
end
--���¶�Ӣ�ۿ�Ƭ��������
function __teamlayer.reorderHeroCard(obj)
	 obj._heroIdList = obj:getOrderdHeroList()
	 local scrollview = obj:egGetScrollView(kPanelCard)
	 for key,heroid in ipairs(obj._heroIdList) do
		if key <= obj._loadCnt then
			if obj._heroCards[heroid] then
				obj._heroCards[heroid]:egSetPosition((key-1)*kCellW2,0)
				obj._heroCards[heroid]:updateJoinState()
			else
				local herocard =  HeroCard.new(heroid)
				scrollview:addChild(herocard:egNode())
				herocard:egSetPosition((key-1)*kCellW2,0)
				obj._heroCards[heroid] = herocard
				obj:bindJoinTeamCallback(herocard)
			end
		else
			if  obj._heroCards[heroid] then
				scrollview:removeChild(obj._heroCards[heroid]:egNode(),true)
				obj._heroCards[heroid] = nil
			end
		end
	 end
end
function __teamlayer.reOrderHeroItem(obj)
    for idx,heroitem in ipairs(obj._heroItems) do
        heroitem:loadHeroAtPos(idx)
        heroitem:setItemTouchEnabled(false)
        local function callback()
            heroitem:setItemTouchEnabled(true)
        end
        local callfunc = CCCallFunc:create(callback)
        local moveto = CCMoveTo:create(0.2,ccp((idx-1)*(kCellW1+kMarginX1),0))
        local sequence = CCSequence:createWithTwoActions(moveto,callfunc)
        heroitem:egNode():runAction(sequence)
    end
end
--����С��Ӣ��
function  __teamlayer.loadHeroItems(obj)
    local listview= obj:egGetWidgetByName(kPanelItem)
    for idx=1,obj._d_data.maxTeam do
        local heroitem = TeamNow.new(idx)
        heroitem:egSetPosition((idx-1)*(kCellW1+kMarginX1),0)
        listview:addChild(heroitem:egNode())
        table.insert(obj._heroItems,heroitem)
        obj:bindItemClickEvent(heroitem)
    end
end
--Ӣ�ۿ����¼�
function __teamlayer.bindItemClickEvent(obj,heroitem)
    local function clickCallback(sender)
        local heroid = sender:getHeroID()
        local oldCnt = #account_data.team
        local pos = sender:getHeroPos()
        table.remove(account_data.team,pos)
        if pos == oldCnt then
            obj:refreshTeamAtkCap()
            obj:reOrderHeroItem()
            obj:reorderHeroCard()
        else
            table.insert(obj._heroItems,sender)
            table.remove(obj._heroItems,pos)
            local x = oldCnt*(kCellW1+kMarginX1)
            sender:egSetPosition(x,0)
            obj:refreshTeamAtkCap()
            obj:reOrderHeroItem()
            obj:reorderHeroCard()
        end
    end
    heroitem:onItemClicked(clickCallback)
end
function __teamlayer.bindScrollListener(obj)
	 local scrollview = obj:egGetScrollView(kPanelCard)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadCnt >=  #obj._heroIdList then return end
            local innerContainer = scrollview:getInnerContainer()
            local posX = innerContainer:getPositionX()
            if (obj._loadCnt * kCellW2) + posX  < scrollview:getSize().width then
                obj:addHeroCard(1)
            end
        end
    end
    scrollview:addEventListenerScrollView(scrollEvent)
end
--�󶨷��ذ���������
function __teamlayer.bindBackListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBack,1.1)
    end
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        obj:egSetWidgetScale(kImgBack,1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --����
         if not Funs.isTbEqual(obj._oldTeam,obj._d_data.team)  then
            SendMsg[934003](obj._d_data.team)
        end
        graphicLoader.removeCreatureAnima()
        local scene = TownScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBack,1)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
function __teamlayer.loadHeroCards(obj)
	local scrollview = obj:egGetScrollView(kPanelCard)
    local neww = kCellW2 * #obj._heroIdList
    local size = scrollview:getSize()
    if neww > size.width then
        scrollview:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
	while obj._loadCnt < kMaxNum do
		obj:addHeroCard(1)
		coroutine.yield()
	end
	obj:bindScrollListener()
end
function __teamlayer.doLoading(obj)
	local function coFunc()
		obj:loadHeroCards()
	end
	local coLoad = coroutine.create(coFunc)
	local function callback()
		local f1,f2 = coroutine.resume(coLoad)
		if not f1 then
			obj:egUnbindWidgetUpdate(kLblTrain)
			if type(f2) == "string" then print(f2) end
		end
	end
	obj:egBindWidgetUpdate(kLblTrain,callback)
end
TeamLayer={}
function TeamLayer.new(d_data)
	graphicLoader.removeCreatureAnima(true)
    local obj = TouchWidget.new(JsonList.teamLayer)
    table_aux.unpackTo(__teamlayer, obj)
    obj._d_data=d_data
    obj:init()
    obj:bindBackListener()
    return obj
end

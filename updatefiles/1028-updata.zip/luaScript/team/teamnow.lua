local kImgHero = "img_hero"
local kImgLv = "img_lv"
local kLabelLv = "lbl_lv"
local kLabelCost = "lbl_cost"
local kBtnItem = "btn_heroitem"
local kImgBar = "img_bar"

local __teamNow = {}
function __teamNow.init(obj,pos)
    obj._pos = pos
    obj._heroid = account_data.team[obj._pos] or 0
    obj:egHideWidget(kImgBar)
    obj:changeHeroId(obj._heroid)
end
function __teamNow.changeHeroId(obj,heroid)
    obj._heroid = heroid
    if obj._heroid == 0 then 
        obj._herodata = nil
        obj:egHideWidget(kLabelCost)
        obj:egHideWidget(kImgLv)
        obj:egHideWidget(kImgHero)
        obj:egSetWidgetEnabled(kBtnItem,false)
        local widget = obj:egGetWidgetByName(kImgHero)
        local sprite = tolua.cast(widget:getVirtualRenderer(),"CCSprite")
        sprite:stopAllActions()
    else
        obj:egSetWidgetEnabled(kBtnItem,true)
        obj._herodata = account_data.heroList[obj._heroid]
        obj._herolv = obj._herodata.lv
        ----------------------------------------------------------------------------
        local s_cfg = hero_data.getConfig(obj._heroid)
        local s_data = hero_data.get(obj._heroid,obj._herodata.lv)
        ----------------------------------------------------------------------------
        --����������ʾ
        obj:egShowWidget(kLabelCost)
        obj:egShowWidget(kImgLv)
        obj:egShowWidget(kImgHero)
        if not obj._oldHeroid or obj._oldHeroid ~= heroid then
            graphicLoader.loadHeroAnima(obj._heroid,obj._herolv,false)
        end    
        obj:walkAction()
        obj:egSetBMLabelStr(kLabelLv,obj._herodata.lv)
        obj:egSetLabelStr(kLabelCost,string.format(string.format("%s%d","COST",s_data.consume)))
        obj._oldHeroid = heroid
    end
end
function __teamNow.walkAction(obj)
    local heroCfg =assert(hero_data.getConfig(obj._heroid))
    local heroDataAtLv =assert(hero_data.get(obj._heroid,obj._herolv))
    local graphName = heroCfg.graphList[heroDataAtLv.graphLV]
    
    local dir = 270
    local animaName = string.format('%s_02%02d',graphName,dir/90)
	local anima = graphicLoader.getAnimation(animaName)
	if not anima then print('engine: can not find anima ' .. animaName) return end
	anima:setRestoreOriginalFrame(true)
	local animate = CCAnimate:create(anima)
	local action = CCRepeat:create(animate,1000000)
	
	local hero = obj:egGetWidgetByName(kImgHero)
	local sprite = tolua.cast(hero:getVirtualRenderer(),"CCSprite") 
	sprite:runAction(action)

end
function __teamNow.loadHeroAtPos(obj,pos)
    obj._pos = pos
    obj:egHideWidget(kImgBar)
    local heroid = account_data.team[obj._pos] or 0
    if heroid ~= obj._heroid then
        obj:changeHeroId(heroid)
    end
end
function __teamNow.getHeroID(obj)
    return obj._heroid
end
function __teamNow.getHeroPos(obj)
    return obj._pos
end

function __teamNow.setItemTouchEnabled(obj,enabled)
    obj:egSetWidgetTouchEnabled(kBtnItem,enabled)
end
function __teamNow.onItemClicked(obj,onclicked)
    obj._itemCallback = onclicked
end
function __teamNow.bindItemListener(obj)
    local function touchBegan(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_rescar_dig)
        local imgbar = obj:egGetWidgetByName(kImgBar)
        imgbar:setScale(1)
        imgbar:setOpacity(255)
        obj:egShowWidget(kImgBar)
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        if obj._pos == 1 and #account_data.team == 1 then
			local pos = sender:convertToWorldSpace(ccp(sender:getPositionX(),sender:getPositionY()))
			showPopTxt(TxtList.needMember,pos.x,pos.y,ccp(0.5,1))
            obj:egHideWidget(kImgBar)
            sender:setTouchEnabled(true)
        else
            local imgbar = obj:egGetWidgetByName(kImgBar)
            local scaleto = CCScaleTo:create(0.2,1.1)
            local fadeout = CCFadeOut:create(0.2)
            local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
            local function callback()
                if obj._itemCallback then obj._itemCallback(obj) end
            end
            local callfunc = CCCallFunc:create(callback)
            local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
            imgbar:runAction(sequence)
        end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			obj:egHideWidget(kImgBar)
		end
    end
	
    obj:egBindTouch(kBtnItem,touchBegan,nil,touchEnded,touchCanceled)
end
TeamNow = {}
function TeamNow.new(pos)
    local obj = {}
    CocosWidget.install(obj,JsonList.teamRightNow)
    table_aux.unpackTo(__teamNow, obj)
    obj:init(pos)
    obj:bindItemListener()
    return obj
end

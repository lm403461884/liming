local __layercolor={}

function __layercolor.egLayer(obj)
	return obj._egObj
end

LayerColor={}

function LayerColor.install(obj,color)
	obj._egObj = CCLayerColor:create(color)
    CocosNode.install(obj)
	TouchDelegate.install(obj)
	for name, func in pairs(__layercolor) do
		obj[name] = func
	end
end

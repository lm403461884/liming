FNList=
{
    STENCIL="Britannic Bold.ttf",
    STHUPO="FZDaBiaoSong-B06S.ttf",
    BlackNum="GUIRes/fonts/blackNumber.fnt",
}

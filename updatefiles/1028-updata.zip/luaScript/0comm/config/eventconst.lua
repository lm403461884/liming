--region eventconst.lua
--Author : Yanlee
--Date   : 2014/12/2
--事件常量

kEventAcctDownLoad = "s_acct_download"
kEventScriptDownLoad = "s_script_download"
kEventClubDownLoad = "s_club_download"
kEventClubWarDownLoad = "s_clubwar_download"

kEventClubSearch = "s_clubsearch_data"--公会关键字搜索
kEventGetClubView = "s_lookClub_data" -- 查看公会数据


kEventLicenceUpStart = "s_licenceup_start"
kEventLicenceUpEnd = "s_licenecup_end"
kEventTrainUpStart = "s_trainup_start"
kEventTrainUpEnd = "s_trainup_end"
kEventBuyNewTrain = "s_buy_newtrain"

kEventNoticeMail = "s_newmail_vedios"--主界面邮件监听
kEventNoticeTask = "s_task_finished"--主界面挖掘日志监听
kEventNoticeMission = "s_new_mission" --主界面冒险任务监听
kEventChatNotice = "s_chat_newnotice"--主界面聊天按钮监听

kEventBeenAttack = "s_been_attacking"--正在被攻打
kEventRelogin = "s_login_twice" --重复登陆
kEventNetDown = "s_network_down" --网络连接断开
kEventCloseQuitPrompt = "s_close_quit_prompt" --关闭退出提示窗口
kEventOpenQuitPrompt = "s_open_quit_prompt"--打开退出提示窗口
kEventRequestTimeOut = "s_request_timeout" --请求数据超时


kEventAcctNotExist = "s_acct_not_exist" --帐号不存在
kEventRSAuthorized = "s_rs_authorized" --RS验证通过
kEventAcctExist = "s_acct_exist" --帐号已存在
kEventPwdNotMatch = "s_pwd_not_match" --密码不正确

kEventSDKAuthorized = "s_sdk_authorized" --SDK第三方登陆验证通过
--endregion

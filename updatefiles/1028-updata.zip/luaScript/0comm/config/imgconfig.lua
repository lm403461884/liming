
local fx_risk = "GUIRes/PvrCcz/m_bg/"
local fx_sprite = "GUIRes/image/sprite/"
local fx_train = "GUIRes/PvrCcz/train/"

ImageList = {
comm_timer_front = "time_pg_front.png",
comm_button = "button.png",
comm_button_bg = "buttonBackground.png",
comm_button_s = "buttonHighlighted.png",
comm_bar_bg_load = "bar_bg_load.png",
comm_bar_ft_load = "bar_ft_load.png",
comm_cd = "pic_cd_00.png",
comm_res_bg = "res_bg.png",
comm_blank = "blank.png",

comm_gold = "icon_gold.png",
comm_oil = "icon_oil.png",
comm_dig = "bar_icon_dig.png",
comm_jewel = "icon_jewel.png",
comm_iron = "icon_iron.png",
comm_copper = "icon_copper.png",
comm_stoneR = "icon_stoneR.png",
comm_stoneB = "icon_stoneB.png",
comm_stoneD = "icon_stoneD.png",
comm_exp = "icon_exp.png",
comm_speed_1 = "icon_play.png",
comm_speed_2 = "icon_speed_2.png",
comm_speed_3 = "icon_speed_3.png",
comm_pvpGuard = "icon_guard.png",


comm_lv = "digLv.png",
comm_time = "bar_icon_timer.png",
comm_elo = "elo.png",
comm_honor = "club_honor.png",--暂时使用elo图片代替
comm_club_elo = "club_elo.png",
comm_note_lvup = "note_lvup.png",
comm_note_func = "note_func.png",
comm_kinfe = "icon_kinfe.png",

comm_load_bg = "time_bg.png",
comm_load_bar = "time_pg_front.png",
comm_load_front = "time_pg_bg.png",
comm_focus_button = "btn_brown.png",
comm_focus = "red_circle.png",
comm_focus_hand = "hand.png",

comm_box_gold = "box_gold_0.png",
comm_box_gold_open ="box_gold_11.png",

comm_box_copper = "box_copper_0.png",
comm_box_copper_open = "box_copper_7.png",

comm_box_silver = "box_silver_0.png",
comm_box_silver_open = "box_silver_7.png",

comm_box_equip = "box_equip_0.png",
comm_box_equip_open = "box_equip_3.png",

comm_box_mystery = "box_mystery_0.png",
comm_box_mystery_open = "box_mystery_3.png",

comm_robber_atk = "robbers_raid.png",
comm_hero_atk = "robbers_attack.png",

btn_brown_n = "btn_brown.png",
btn_brown_s = "btn_brown_pressed.png",
btn_brown_d = "btn_brown_disabled.png",

btn_fat_n = "btn_fat.png",
btn_fat_s = "btn_fat_pressed.png",
btn_fat_d = "btn_fat_disabled.png",

btn_fight_n = "btn_fight_n.png",
btn_fight_d = "btn_fight_d.png",

btn_risk_n = "btn_risk_n.png",
btn_risk_d = "btn_risk_d.png",

btn_far_n = "btn_far_n.png",
btn_far_d = "btn_far_d.png",

btn_bar_n = "btn_bar_n.png",
btn_bar_d = "btn_bar_d.png",

btn_log_n = "btn_log_n.png",
btn_log_d = "btn_log_d.png",

btn_rank_n = "btn_rank_s.png",
btn_rank_d = "btn_rank_d.png",

btn_sign_n = "btn_sign_n.png",
btn_sign_d = "btn_sign_d.png",

btn_def_n = "btn_def_n.png",
btn_def_d = "btn_def_d.png",

btn_paper_n = "btn_paper.png",
btn_paper_s = "btn_paper_pressed.png",
btn_paper_d = "btn_paper_disabled.png",

btn_arrow_n = "btn_putaway.png",
btn_arrow_s ="btn_putaway_pressed.png",

btn_red_n = "btn_red_n.png",
btn_red_s = "btn_red_s.png",

btn_flag_g_n = "flag_green_n.png",
btn_flag_g_s = "flag_green_s.png",
btn_flag_d = "flag_d.png",
btn_flag_r_n = "flag_red_n.png",
btn_flag_r_s = "flag_red_s.png",
icon_war_atk = "war_atk.png",
icon_war_def = "war_def.png",

pve_atk = "icon_atk.png",
pve_atk2 = "icon_atk1.png",
pve_dfs = "icon_def.png",
pve_boss = "icon_boss.png",

cofc_showbox = "showbox.png",
cofc_selectbox = "select_box.png",
cofc_unknownhero = "hero_00.png",

lvup_star = "star.png",
lvup_starnull = "star_null.png",
star = "star.png",
star_cato = "star_cato.png",

risk_lv_green = "lv_green.png",
risk_lv_red ="lv_red.png",
risk_name_green ="name_green.png",
risk_name_red ="name_red.png",

other_tile = fx_sprite.."tile.pvr.ccz",
risk_mask_atk = fx_risk.."atk_mask.pvr.ccz",
risk_mask_def = fx_risk.."def_mask.pvr.ccz",
town_train_updating = fx_train.."train_updating.pvr.ccz",
town_train_head_updating = fx_train.."train_head_updating.pvr.ccz",

mail_opened = fx_risk.."mail_opened.pvr.ccz",
mail_closed = fx_risk.."mail_closed.pvr.ccz",
box_light_bg = fx_risk.."box_light_1.pvr.ccz",
ex_map_bg = fx_risk.."exmap.pvr.ccz",
}

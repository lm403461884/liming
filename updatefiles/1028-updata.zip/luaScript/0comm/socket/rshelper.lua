local kLatestVer = "latest-version-code"
local local_rs = {host = "127.0.0.1",port = 10001}
local company_rs = {host = "192.168.1.11",port = 10001}
local public_rs = {host = "1up.linkpc.net",port = 5000}
local public_rs1 = {host = "1up.linkpc.net",port = 6000}
local public_cloud = {host = '118.192.87.41', port = 5000}
local public_cloud_asian = {host = '203.90.236.226', port = 5000}
--update for ch
local verFileUrl = "https://github.com/lm403461884/liming/blob/master/version"
local downLoadPath ="https://github.com/lm403461884/liming/tree/master/updatefiles/"
--update for jp
--[[
local verFileUrl = "https://raw.githubusercontent.com/alidalee/jpduobaolianmeng/master/version"
local downLoadPath ="https://raw.githubusercontent.com/alidalee/jpduobaolianmeng/master/updatefiles/"
--]]
--update for test
--[[
local verFileUrl = "https://raw.githubusercontent.com/alidalee/UpdateEngine/master/version"
local downLoadPath ="https://raw.githubusercontent.com/alidalee/UpdateEngine/master/updatefiles/"
--]]
local subDir = "duobaolianmeng"

rs_config = local_rs
local rsMsgParser = {}
--==========================
--291001 ��½�ɹ�
--==========================
--guid���û�Ψһ��Ƿ�
--ip:    ������IP
--prot:    �������˿ں�
--==========================
rsMsgParser[291001] = function(rsconn)
    local port = rsconn:readInt()
    local host,_ = rsconn:readStr()
	rsconn:disconnect()
    SocketHelper.connect(host,port)
	print(host,port)
    --���͵�½�ɹ��¼���ʶ
     postEventSignal(kEventRSAuthorized)
end
--==========================
--291002 �ʺŲ����ڵ�½ʧ��
--==========================
rsMsgParser[291002] = function(rsconn)
	rsconn:disconnect()
	postEventSignal(kEventAcctNotExist)

end
--==========================
--291003 ע��ʧ�� �ʺ���ռ��
--==========================
rsMsgParser[291003] = function(rsconn)
    rsconn:disconnect()
    --�����ʺű�ռ�ñ�ʶ
    postEventSignal(kEventAcctExist)
end
--==========================
--291004 ��½ʧ�� �������
--==========================
rsMsgParser[291004] = function(rsconn)
	rsconn:disconnect()
    --������������ʶ
    postEventSignal(kEventPwdNotMatch)
end

--==========================
--291007 �汾����
--==========================
rsMsgParser[291007] = function(rsconn)
	local latestVer = rsconn:readInt()
	CCUserDefault:sharedUserDefault():setIntegerForKey(kLatestVer,latestVer)
	rsconn:disconnect()
    local scene = VerCtrScene.new()
	scene:egReplace()
end
RSHelper={}
function RSHelper:connect()
	self._conn = SyncSocket:connect(rs_config.host,rs_config.port,128,128)
end
function RSHelper:disconnect()
	self._conn:disconnect()
end

function RSHelper:initUpdateEngine()
	UpdateEngine:setStoragePath(CCFileUtils:sharedFileUtils():getWritablePath().. subDir)
	UpdateEngine:setVerFileUrl(verFileUrl)
	UpdateEngine:setDownLoadPath(downLoadPath)
	UpdateEngine:setTimeOut(60)
end
function RSHelper:sendRegMsg(account,pwd)
	local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd + 4
	self._conn:write(len_msg,921002,0,__version)
    self._conn:writeStr(account,len_account)
    self._conn:writeStr(pwd,len_pwd)
	self._conn:writeInt(len_msg)
	self._conn:send()

end
function RSHelper:sendLogMsg(account,pwd)
	local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd + 4
	self._conn:write(len_msg,921001,0,__version)
    self._conn:writeStr(account,len_account)
    self._conn:writeStr(pwd,len_pwd)
	self._conn:writeInt(len_msg)
	self._conn:send()
end

function RSHelper:getState()
	return self._conn:socketState()
end
function RSHelper:handleRSMsg()
	 local msglen,msgcode,msgguid,opstate = self._conn:read(4)
	 guid = msgguid
	 rsMsgParser[msgcode](self._conn)
end

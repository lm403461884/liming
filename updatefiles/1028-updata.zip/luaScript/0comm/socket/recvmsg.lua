--key发生器生成器
local function randfunc(seed)
	local mul = assert(seed)
	return function(l, h)
		l = l or 0
		h = h or 0x7fffffff
		mul = mul * 0xefff % 0x7fffffff
		return l + mul % (h-l+1)
	end
end
--定义包体类型
local datatype = {
	string = 1,
	bson = 2,
	binary = 3,
}

local function getTableFromMsg()
    local strVal,_ = RecvQueue:readStr()
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function getBattleSumaryFromMsg()
	local strVal,_ = RecvQueue:readStr()
	strVal = string.gsub(strVal, "\\", "")
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function getTableFromPaser()
    local strVal,_ = StreamPaser:readStr()
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function getZipTableFromMsg(len)
    local srcBytes = RecvQueue:readUserData(len)
    local desBytes,deslen =HOGZip:decompress(srcBytes,len)
    StreamPaser:init(desBytes,deslen)
    local strVal,_ = StreamPaser:readStr()
    ----------
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function protocol2table(dtype,bComp,len)
	if dtype == datatype.string then
		if bComp == 1
			then return getZipTableFromMsg(len)
			else return getTableFromPaser()
		end
	elseif dtype == datatype.bson then
		local buf = RecvQueue:readUserData(len)
		if bComp == 1 then
			buf = HOGZip:decompress(buf,len)
		end
		return HOAux:bson2table(buf)
	end
end

local _socketParser = {}

function RecvMsg()
    if not RecvQueue:hasData() then  return end
    RecvQueue:lock()
    if RecvQueue:hasData() then
      local msglen,msgcode,msgguid,opstate = RecvQueue:read(4)
      guid = msgguid
      print("msglen,msgcode,guid,opstate:",msglen,msgcode,guid,opstate)
      _socketParser[msgcode](msglen,msgguid,opstate)
    end
    RecvQueue:refresh()
    RecvQueue:unlock()
end

--==========================
--391001 帐号数据
--==========================
--account_data：帐号数据
--==========================

_socketParser[391001] = function(msglen)
	local onlinedt = RecvQueue:readInt()
	local dtype = RecvQueue:readInt()
	local bComp = RecvQueue:readInt()
	account_data = protocol2table(dtype,bComp,msglen-28)
	account_data.onlinedt = onlinedt
	dataTranform.equipments(account_data)
	dataTranform.unlockedPVE(account_data.unlockedPVE)
	dataTranform.pveGuardQuest(account_data.pveGuardQuest)
	dataTranform.mileSpread(account_data.mileSpread, account_data.mileInCD)
	dataTranform.rewardMails(account_data.rewardMails)
    if not account_data then return end
	print('pve guard stars', account_data.pveGuardStars)
	g_keygen = randfunc(account_data.lastOffline)
	if account_data.cbName then account_data.cbName = HOAux:hexstr2str(account_data.cbName) end
	 AccountHelper:setLogInfo(account_data.user,account_data.password)
    postEventSignal(kEventAcctDownLoad) --通知帐号数据接收完毕
    if not scriptDownloaded then
        SendMsg[931002]() --获取脚本文件
        SendMsg[931003]() --获取录像摘要数据
    else
		postEventSignal(kEventScriptDownLoad) --通知脚本文件数据接收完毕
        resetRTInfo()
		if account_data.cid then
			SendMsg[938002]() --获取公会数据
		else
			postEventSignal(kEventClubDownLoad) --通知公会数据接收完毕
			postEventSignal(kEventClubWarDownLoad) --通知公会战数据接收完毕
		end
    end
end

--==========================
 --391002 脚本文件
 --==========================
 --fileCount:    脚本文件数量
 --type:        文件类型
 --filename:    文件名称
 --filedata:    文件内容
 --==========================
_socketParser[391002] = function(msglen)
    local filecount = RecvQueue:readInt()
    local srclen = msglen - 20
    local srcBytes = RecvQueue:readUserData(srclen)
    local desBytes,deslen =HOGZip:decompress(srcBytes,srclen)
    StreamPaser:init(desBytes,deslen)
    if filecount > 0 then
        for i = 1,filecount do
            local flag,_ = StreamPaser:readStr()
            if flag ~= "9" then
                return
            else
                local filename,_ = StreamPaser:readStr()
                local filedata,_ = StreamPaser:readStr()
                local chunck, err = loadstring(filedata,filename)
                if not chunck then print(err) return end
                local succ, err = pcall(chunck)
                if not succ then print(err) return end
            end
        end
    end
	postEventSignal(kEventScriptDownLoad) --通知脚本文件数据接收完毕
	if not scriptDownloaded then
		scriptDownloaded = true
		resetRTInfo()
		if account_data.cid then
			SendMsg[938002]() --获取公会数据
		else
			postEventSignal(kEventClubDownLoad) --通知公会数据接收完毕
			postEventSignal(kEventClubWarDownLoad) --通知公会战数据接收完毕
		end
	else
		scriptDownloaded = true
	end
end

--==========================
 --391003 录像信息列表
 --==========================
 --recordStr:录像列表字符串
 --[[sumary={}
	sumary.time = os.time()
	sumary.atk_gold = m_gold
	sumary.atk_oil = m_oil
	sumary.atk_elo = m_elo
	sumary.atkName = m_user
	sumary.def_gold = f_gold
	sumary.def_oil = f_oil
	sumary.def_elo = f_elo
	sumary.defName = f_user
	sumary.stars = stars
	sumary.hero = hero
	--]]
 --==========================
local function __getbattleheader()--{{{
	local cnt = RecvQueue:readInt()
	if cnt == 0 then return end
	local ret = {}
	for idx=1, cnt do
		ret[idx] = {vid=RecvQueue:readInt(), sumzlen=RecvQueue:readInt()}
	end
	return ret
 end--}}}

 local function __getbattlesumary(ud, ul)--{{{
	 StreamPaser:init(ud, ul)
	 local sumary = {
		atk_oil = 0,
		def_oil = 0,
		time = StreamPaser:readInt(),
		atkGuid = StreamPaser:readInt(),
		defGuid = StreamPaser:readInt(),
		atk_gold = StreamPaser:readInt(),
		def_gold = StreamPaser:readInt(),
		atk_iron = StreamPaser:readInt(),
		atk_copper = StreamPaser:readInt(),
		atk_stoneR = StreamPaser:readInt(),
		atk_stoneB = StreamPaser:readInt(),
		atk_stoneD = StreamPaser:readInt(),
		atk_elo = StreamPaser:readInt(),
		def_elo = StreamPaser:readInt(),
		stars = StreamPaser:readInt(),
		atkName = StreamPaser:readStr(),
		defName = StreamPaser:readStr(),
	 }
	 sumary.needRevenged = math.floor(sumary.stars/256)
	 sumary.stars = sumary.stars%256
	 sumary.isDefencer = true
	 sumary.atkName = HOAux:hexstr2str(sumary.atkName)
	 sumary.defName = HOAux:hexstr2str(sumary.defName)
	 if sumary.atkGuid == account_data.guid or (sumary.atkGuid ~= account_data.guid and sumary.defGuid ~=account_data.guid and club_data and club_data.members[sumary.atkGuid])  then
		sumary.isDefencer = false
	 end
	 --[[
	 if sumary.atkGuid == account_data.guid then
		sumary.atkName = account_data.nickName
	 elseif sumary.defGuid == account_data.guid then
		sumary.defName = account_data.nickName
	 end
	 --]]

	 --read hero data
	 local hero = {}
	 local team = {}
	 local heroList = {}
	 local equipments = {}
	 for i=1, StreamPaser:readInt() do
		 local ctx = StreamPaser:readInt()
		 local equip = StreamPaser:readInt()
		 local sub1 = StreamPaser:readInt()
		 local sub2 = StreamPaser:readInt()
		 local id = math.floor(ctx / 100) % 100
		 local grade = math.floor(ctx / 10000) % 100
		 local lv = math.floor(ctx / 1000000)
		 local eid = ctx % 10000
		 hero[id] = lv
		 table.insert(team, id)
		 heroList[id] = {type=id,lv=lv,eid=eid,grade=grade,eid_s1=sub1,eid_s2=sub2}
		 local elv = equip % 256
		 local eqa = math.floor(equip / 256)
		 equipments[eid] = {elv, eqa}
	 end
	 sumary.hero = hero
	 sumary.team = team
	 sumary.heroList = heroList
	 sumary.equipments = equipments
	 return sumary
 end--}}}

 local function __getbattledetail(ud, ul)--{{{
	 StreamPaser:init(ud, ul)
	 --get attacker data
	 local atk = {
		stars = StreamPaser:readInt(),
		consume = StreamPaser:readInt(),
		startTime = StreamPaser:readInt(),
		endTime = StreamPaser:readInt(),
		frameCnt = StreamPaser:readInt(),
		heroEnterFrame = {},
		heroCreatedFrame = {},
		skillUsageFrame = {},
	 }

	 for i=1, StreamPaser:readInt() do
		 table.insert(atk.heroEnterFrame, StreamPaser:readInt())
	 end

	 for i=1, StreamPaser:readInt() do
		 table.insert(atk.heroCreatedFrame, StreamPaser:readInt())
	 end

	 for i=1, StreamPaser:readInt() do
		 local hid = StreamPaser:readInt()
		 local cnt = StreamPaser:readInt()
		 atk.skillUsageFrame[hid] = {}
		 for p=1, cnt do
			 table.insert(atk.skillUsageFrame[hid], StreamPaser:readInt())
		 end
	 end

	 --get defencer data
		--skip useless data
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 local collectorList = {}
	 local monsterLvLook = {}
	 local creatureList = {}
	 local digTrace = {}
	 local mileSpread = {}
	 local def = {
		 sceneID = StreamPaser:readInt(),
		 sceneLv = StreamPaser:readInt(),
		 collectorList = collectorList,
		 monsterLvLook = monsterLvLook,
		 creatureList = creatureList,
		 digTrace = digTrace,
		 mileSpread = mileSpread
	 }
	 --read collector list and mile spread
	 for idx=1, StreamPaser:readInt() do
		 local coll = {
			 lv = StreamPaser:readInt(),
			 st = StreamPaser:readInt(),
			 elapsed = StreamPaser:readInt(),
			 pos = StreamPaser:readInt(),
			 coin = StreamPaser:readInt(),
			 mileLv = StreamPaser:readInt(),
			 mileCnt = StreamPaser:readInt()
		 }
		 table.insert(collectorList, coll)
		 if coll.coin ~= 0 then
			 mileSpread[coll.pos] = {type=coll.coin, lv=coll.mileLv, cnt=coll.mileCnt}
		 end
	 end
	 --read monster level look
	 for idx=1, StreamPaser:readInt() do
		 local mid = StreamPaser:readInt()
		 local mlv = StreamPaser:readInt()
		 monsterLvLook[mid] = mlv
	 end
	 --read creature list
	 for idx=1, StreamPaser:readInt() do
		 local combineddata = StreamPaser:readInt()
		 local pos = math.floor(combineddata / 10000)
		 local mid = combineddata % 10000
		 creatureList[pos] = mid
	 end
	 --read dig trace
	 for idx=1, StreamPaser:readInt() do
		 local combinedpos = StreamPaser:readInt()
		 local pos1 = math.floor(combinedpos / 10000)
		 local pos2 = combinedpos % 10000
		 if pos1 > 0 then
			 digTrace[pos1] = 1
		 end
		 if pos2 > 0 then
			 digTrace[pos2] = 1
		 end
	 end

	 return atk, def
 end--}}}

_socketParser[391003] = function(msglen)
	local ret = __getbattleheader()
	if ret then
		for _, hdr in ipairs(ret) do
			local ud = RecvQueue:readUserData(hdr.sumzlen)
			local sumary = __getbattlesumary(ud, hdr.sumzlen)
			sumary.vid = hdr.vid
			videomanager.addsumary(sumary)
		end
	end
	account_data.battleSumaries = videomanager.getsumaries()
    AccountHelper:unlock(kStateVideoList)
    --postEventSignal(kEventVideoList)
end

--==========================
 --391004 录像信息明细
 --==========================
 --atk: 进攻方数据
 --dfs: 防守方数据
 --==========================
_socketParser[391004] = function(msglen,guid,opstate)
	if opstate == -1 then
	else
		local vid = RecvQueue:readInt()
		local sl = RecvQueue:readInt()
		local dl = RecvQueue:readInt()

		local ud_sum = RecvQueue:readUserData(sl)
		local sumary = __getbattlesumary(ud_sum, sl)

		local ud_detail = RecvQueue:readUserData(dl)
		local atk, def = __getbattledetail(ud_detail, dl)

		atk.team = sumary.team
		atk.heroList = sumary.heroList
		atk.equipments = sumary.equipments

		videomanager.addvideo(vid, {bpresult=sumary, atk=atk, def=def})
	end
    AccountHelper:unlock(kStateVideo)
    --postEventSignal(kEventVideoDetail)
end

--==========================
 --391006 ELO排名信息
 --==========================
_socketParser[391006] = function(msglen)
	local bodylen = RecvQueue:readInt()
	if bodylen > 0 then
	    local selfIdx,totalPage,curPage,startIdx,endIdx = RecvQueue:read(5)
	    local byteLen  = msglen - 40
	    local srcBytes = RecvQueue:readUserData(byteLen)
	    StreamPaser:init(srcBytes,byteLen)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(2,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.guid,tb.digLv,tb.elo = StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			ELORankHelper:addRankData(totalPage,curPage,tb)
		end
		ELORankHelper:finishDownLoad(true)
	else
		ELORankHelper:finishDownLoad()
	end
end
--==========================
 --391007 矿洞正在被攻打
 --==========================
_socketParser[391007] = function(msglen)
	local flag = RecvQueue:readInt()
	if flag == 1 then
		postEventSignal(kEventBeenAttack)
	else
		postEventSignal(kEventRelogin)
	end
end

--==========================
 --391008 公共聊天信息
 --==========================
_socketParser[391008] = function(msglen)
	local userGuid = RecvQueue:readInt()
	local userDigLv = RecvQueue:readInt()
	local userName = RecvQueue:readStr()
    userName = HOAux:hexstr2str(userName)
	local userclubid = RecvQueue:readInt()
	local userclubname  = RecvQueue:readStr()
    local userMsg  = RecvQueue:readStr()
	ChatHelper.addPubMsg(userGuid,userDigLv,userName,userclubid,userclubname,userMsg)
end
--==========================
 --391009 某GUID对应的帐号摘要数据
 --==========================
_socketParser[391009] = function(msglen)
	local dtype = RecvQueue:readInt()
	if dtype == datatype.binary then
		local userbrief = {}
		userbrief.guid,userbrief.diglv,userbrief.digPt,userbrief.elo,userbrief.teamCnt= RecvQueue:read(5)
		userbrief.heroList = {}
		userbrief.equipments = {}
		if userbrief.teamCnt > 0 then
			for idx=1,userbrief.teamCnt do
	            local tb = {}
		        local heroctx,equipmain,equipsub1,equipsub2 = RecvQueue:read(4)
				tb.eid,tb.type,tb.grade,tb.lv = Funs.deComposeInt(heroctx,100,4)
				tb.eid = tb.type*100 + tb.eid
				userbrief.equipments[tb.eid] = {}
			    userbrief.equipments[tb.eid][1],userbrief.equipments[tb.eid][2] = Funs.deComposeInt(equipmain,256,2)
				tb.eid_s1 = equipsub1
				tb.eid_s2 = equipsub2
				userbrief.heroList[tb.type] = tb
			end
		end
		userbrief.cid = RecvQueue:readInt()
		userbrief.cbName = RecvQueue:readStr()
		userbrief.nickName = RecvQueue:readStr()
		userbrief.nickName = HOAux:hexstr2str(userbrief.nickName)
		userbrief.cbName = HOAux:hexstr2str(userbrief.cbName)
		userbrief.refreshTime = os.time()--做个时间标记,2分钟内不重新获取
		ChatHelper.addUserBrief(userbrief)
	elseif dtype == datatype.bson then
		local ud = RecvQueue:readUserData(msglen-20)
		local raw = HOAux:bson2table(ud)
		local heroList = {}
		local equipments = {}
		for _,hero in pairs(raw.teamInfo) do
			heroList[hero.type] = hero
			equipments[hero.eid] = {hero.equ%256, math.floor(hero.equ/256)}
		end
		raw.diglv = raw.digLv
		raw.digPt = raw.maxDigPt
		raw.teamCnt = #raw.teamInfo
		raw.heroList = heroList
		raw.equipments = equipments
		raw.cbName = HOAux:hexstr2str(raw.cbName)
		raw.nickName = HOAux:hexstr2str(raw.nickName)
		raw.refreshTime = os.time()
		ChatHelper.addUserBrief(raw)
	end
end
--==========================
 --391014 私聊信息
 --==========================
_socketParser[391014] = function(msglen,guid,opstate)
	local userGuid = RecvQueue:readInt()
	local userDigLv = RecvQueue:readInt()
	local userName = RecvQueue:readStr()
	userName = HOAux:hexstr2str(userName)
	local userclubid = RecvQueue:readInt()
	local userclubname  = RecvQueue:readStr()
	local userMsg  = RecvQueue:readStr()
	ChatHelper.addPrivateMsg(1,userGuid,userDigLv,userName,userclubid,userclubname,userMsg)
end
--==========================
 --391015 英雄战力排行榜单
 --==========================
_socketParser[391015] = function(msglen)
	local bodylen = RecvQueue:readInt()
	if bodylen > 0 then
		local selfIdx,totalPage,curPage,startIdx,endIdx = RecvQueue:read(5)
		local byteLen = msglen - 40
		local srcBytes = RecvQueue:readUserData(byteLen)
		StreamPaser:init(srcBytes,byteLen)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(1,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.guid,tb.digLv,tb.teamBp= StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			TeamBpRankHelper:addRankData(totalPage,curPage,tb)
		end

		TeamBpRankHelper:finishDownLoad(true)
	else
		TeamBpRankHelper:finishDownLoad()
	end
end
--==========================
 --391017 PVE成就排行榜单
 --==========================
_socketParser[391017] = function(msglen)
	local bodylen = RecvQueue:readInt()
	if bodylen > 0 then
		local selfIdx,totalPage,curPage,startIdx,endIdx = RecvQueue:read(5)
		local byteLen = msglen - 40
		local srcBytes = RecvQueue:readUserData(byteLen)
		StreamPaser:init(srcBytes,byteLen)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(3,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.guid,tb.digLv,tb.stars= StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			PveRankHelper:addRankData(totalPage,curPage,tb)
		end
		PveRankHelper:finishDownLoad(true)
	else
		PveRankHelper:finishDownLoad()
	end
end
--==========================
 --392001 地穴资源分布
 --==========================
 --aid:        地形编号
 --sid:        场景ID
 --en:         入口位置
 --cs:         生物资源分布
 --ms:         未暴露的矿脉分布
 --em:         已暴露的矿脉分布
 --==========================
_socketParser[392001] = function()
    local scenetb = getTableFromMsg()
    if not scenetb then return end
    account_data.sceneID =scenetb.aid
    account_data.sceneLv = scenetb.sid
    account_data.creatureList = {}

	dataTranform.mileSpread(scenetb.ms)
    account_data.mileSpread = scenetb.ms

    account_data.digPt = account_data.maxDigPt
    account_data.digTrace = scenetb.dt
    account_data.collectorList = scenetb.cl
    for key,item in pairs(account_data.monsterPool) do
        item.n = item.N
    end
    AccountHelper:unlock(kStateNewHole)
end

--读取消息中的帐号数据
local function getTargetHoleData(byteLen,curTime)
	 local srcBytes = RecvQueue:readUserData(byteLen)
    StreamPaser:init(srcBytes, byteLen)
    local target_data = {}
	target_data.guid = StreamPaser:readInt()
    target_data.elo = StreamPaser:readInt()
    target_data.gold = StreamPaser:readInt()
    target_data.oil = StreamPaser:readInt()
    target_data.digLv = StreamPaser:readInt()
    target_data.sceneID = StreamPaser:readInt()
    target_data.sceneLv = StreamPaser:readInt()
    target_data.collectorList = {}
    target_data.mileSpread = {}
	target_data.resVal = {0,0,0,0,0,0,0} --{gold,oil,iron,copper,sR,sB,sD}
	target_data.carRes = {}
    local rescarCnt = StreamPaser:readInt()
    for idx = 1,rescarCnt do
		local lv,st,elapsed,pos,coin,minelv,minecnt = StreamPaser:read(7)
        local tb = {}
        tb.lv = lv
        tb.st = st
        tb.elapsed = curTime-st
        tb.pos = pos
        tb.coin = coin
		table.insert(target_data.collectorList,tb)
		if tb.coin > 0 then
			 local tbmine = {}
			tbmine.type = coin
			tbmine.lv = minelv
			tbmine.cnt = minecnt
			target_data.mileSpread[pos] = tbmine
			local mine_cfg = mile_data.get(tbmine.type, tbmine.lv)
			target_data.resVal[coin] = target_data.resVal[coin] + mine_cfg.gainVal
		else
			table.insert(target_data.carRes,0)
		end

    end
    --monsterLvLook
    local monsterCnt = StreamPaser:readInt()
    target_data.monsterLvLook = {}
    for idx=1,monsterCnt do
		local monsterid,monsterlv = StreamPaser:read(2)
        target_data.monsterLvLook[monsterid] = monsterlv
    end
    --creatureList
    local creatureCnt = StreamPaser:readInt()
    target_data.creatureList = {}
    for idx=1,creatureCnt do
		local combineddata = StreamPaser:readInt()
		local pos = math.floor(combineddata / 10000)
		local id = combineddata % 10000
		target_data.creatureList[pos] = id
    end
    --digTrace
	local blankCnt = StreamPaser:readInt()
    target_data.holeDeep = blankCnt * 2
    target_data.digTrace = {}
    for idx=1,blankCnt do
		local combinedpos = StreamPaser:readInt()
		local pos1 = math.floor(combinedpos / 10000)
		local pos2 = combinedpos % 10000
		if pos1 > 0 then
		    target_data.digTrace[pos1] = 1
		end
		if pos2 > 0 then
			target_data.digTrace[pos2] = 1
		end
    end

	local defName = StreamPaser:readStr()
    target_data.user = HOAux:hexstr2str(defName)
	return target_data
end
--==========================
--395001 PVP匹配对象数据
--==========================
--pvpaccount_data：匹配的帐号信息
--==========================
_socketParser[395001] = function(msglen)
	local curTime = RecvQueue:readInt()
    pvpaccount_data = getTargetHoleData(msglen - 20,curTime)
    AccountHelper:unlock(kStateSearchPvp)
end

--==========================
--395005 复仇对象数据
--==========================
--pvpaccount_data：复仇对象帐号信息
--==========================
_socketParser[395005] = function(msglen)
	local flag = RecvQueue:readInt()
	if flag > 0 then
		local curTime = RecvQueue:readInt()
		pvpaccount_data = getTargetHoleData(msglen - 24,curTime)
	else
		pvpaccount_data = nil
	end
    AccountHelper:unlock(kStateSearchPvp)
    --postEventSignal(kEventSearchPvp)
end
--==========================
--398001 新建公会回复
--==========================
_socketParser[398001] = function(msglen,guid,opstate)
  --local issuccsed =RecvQueue:readInt()
  if opstate==0 then
	  ChatHelper.setNewCreated(true)
      SendMsg[938002]()
      --postEventSignal(kEventClubSetUp)
  else
      AccountHelper:unlock(kStateSetupGuild)
      --postEventSignal(kEventClubSetUpFalse)
  end
end
--==========================
--398003 搜索公会 返回公会摘要
--==========================
--club_search :公会摘要信息表
--==========================
_socketParser[398003] = function (msglen,guid,opstate)
    local bytelen = msglen - 24
    if AccountHelper:isLocked(kStateGuildData) then --更新公会数据
        AccountHelper:unlock(kStateGuildData)
		local dtype = RecvQueue:readInt()
		local bComp = RecvQueue:readInt()
        local tb = protocol2table(dtype,bComp,bytelen)
        club_data.honor = tb.honor
        club_data.rank = tb.rank
        club_data.reward = tb.reward or 0
        club_data.members = tb.members
        club_data.elo = tb.elo
        club_data.coe = tb.coe
        club_data.membersCount= tb.membersCount
		    for uid, mbr in pairs(club_data.members) do
			     mbr.name = HOAux:hexstr2str(mbr.name)
		    end
		--postEventSignal(kEventNewClubData)    
		elseif AccountHelper:isLocked(kStateToViewGuild) then--查看公会信息
		     if opstate == 0 then
				local dtype = RecvQueue:readInt()
				local bComp = RecvQueue:readInt()
		         club_cid = {}
		         club_cid[-1] = protocol2table(dtype,bComp,bytelen)
		         club_cid[-1].clubName = HOAux:hexstr2str(club_cid[-1].clubName)
			       club_cid[-1].clubDesc = HOAux:hexstr2str(club_cid[-1].clubDesc)
			       club_cid[-1].manager = HOAux:hexstr2str(club_cid[-1].manager)
			       for uid, mbr in pairs(club_cid[-1].members) do
				        mbr.name = HOAux:hexstr2str(mbr.name)
			       end
			   else
			       club_cid = {}
			   end
			   postEventSignal(kEventGetClubView)
			   AccountHelper:unlock(kStateToViewGuild)
    else --搜索公会
        if opstate == 0 then
			local dtype = RecvQueue:readInt()
			local bComp = RecvQueue:readInt()
            club_search = protocol2table(dtype,bComp,bytelen)
			club_search.clubName = HOAux:hexstr2str(club_search.clubName)
			club_search.clubDesc = HOAux:hexstr2str(club_search.clubDesc)
			club_search.manager = HOAux:hexstr2str(club_search.manager)
			for uid, mbr in pairs(club_search.members) do
				mbr.name = HOAux:hexstr2str(mbr.name)
			end
        else
            club_search = nil
            print("search false")
        end
        --AccountHelper:unlock(kStateSearch)
        postEventSignal(kEventClubSearch)
        --if not club_search then print("search false") return end
        --print("club_search:",table_aux.serial(club_search))
   end
end

local function __formatWarData(cd)
	cd.warData.st = os.time()
	cd.defClub = cd.warData.cb_atk
	if cd.cid == cd.defClub.cid then
		cd.defClub = cd.warData.cb_def
	end
	local atk = cd.warData.cb_atk
	local def = cd.warData.cb_def
	atk.clubName = HOAux:hexstr2str(atk.clubName)
	def.clubName = HOAux:hexstr2str(def.clubName)
	for key,items in pairs(atk.targets) do
		items.nickName = HOAux:hexstr2str(items.nickName)
		items.atkerName =  HOAux:hexstr2str(items.atkerName)
	end
	for key,items in pairs(def.targets) do
		items.nickName = HOAux:hexstr2str(items.nickName)
		items.atkerName =  HOAux:hexstr2str(items.atkerName)
	end
end
--==========================
--398002 公会数据
--==========================
--club_data:公会数据
--==========================
_socketParser[398002] = function(msglen,guid,opstate)
    if opstate == 0 then
		local dtype = RecvQueue:readInt()
		local bComp = RecvQueue:readInt()
		club_data = protocol2table(dtype,bComp,msglen-24)
		--挖掘日志任务进程更新,加入公会
		task.updateTaskStatus(account_data,task.client_event_id.enter_guild)
		----------------------------------------------------------
		--字符串字段转码
		club_data.clubName = HOAux:hexstr2str(club_data.clubName)
		club_data.clubDesc = HOAux:hexstr2str(club_data.clubDesc)
		club_data.manager = HOAux:hexstr2str(club_data.manager)
		account_data.cid = club_data.cid
		account_data.cbName = club_data.clubName
		if club_data.lastWarResult then
			club_data.lastWarResult.atkName = HOAux:hexstr2str(club_data.lastWarResult.atkName)
			club_data.lastWarResult.defName = HOAux:hexstr2str(club_data.lastWarResult.defName)
		end
		for uid, mbr in pairs(club_data.members) do
			mbr.name = HOAux:hexstr2str(mbr.name)
		end
		club_data.startRefreshTime  = os.time()
		--整理公会聊天信息
		ChatHelper.clearGuildMsg()
		for mid, msg in pairs(club_data.message) do
			if msg.name then
				msg.name = HOAux:hexstr2str(msg.name)
			end
			if msg.content then
				msg.content = HOAux:hexstr2str(msg.content)
			end
			ChatHelper.addGuildMsg(msg.type,msg._mid,msg.guid,msg.content,msg.state,msg.name,msg.date)
		end
		ChatHelper.reOrderGuildMsg()
		--探险队公会消息
		for guid,item in pairs(club_data.teamMsg) do
		    if item.content then
		        --print(item.content)
				item.content = HOAux:hexstr2str(item.content)
				--print(item.content)
			end
		    ChatHelper.addGuildMsg(4,-guid,guid,item.content,nil,nil,item.date,item.cur,item.limit)
		end

  		--护盾相关
		if club_data.guardSt > 0 then
			club_data.guardSt = club_data.guardSt + account_data.scOffsetTime --调整公会护盾失效时间
		end
		--战争倒时计相关
		if club_data.cbwid then
			SendMsg[9311010](club_data.cbwid)
			SendMsg[9311007](club_data.cbwid)
		else
			postEventSignal(kEventClubWarDownLoad) --通知公会战数据接收完毕
			if club_data.lastWarResult then
				if not club_data.lastWarResult.endTime then club_data.lastWarResult.endTime = 0 end
				if club_data.lastWarResult.endTime > account_data.lastOffline then
				   if not account_data.joinClubTime or club_data.lastWarResult.endTime>account_data.joinClubTime then
						 --公会战结束消息提示
						 local tb = {}
						 tb.type = 5
						 tb.data = {type=1,}
						 tb.data.clubName = club_data.clubName
						 tb.data.atkClubName = club_data.lastWarResult.atkName
						 tb.data.defClubName = club_data.lastWarResult.defName
						 tb.data.atkEloDlt = club_data.lastWarResult.atkEloDlt
						 tb.data.defEloDlt = club_data.lastWarResult.defEloDlt
						 AccountHelper:addNewPrompt(tb)
					end
				end
			end
		end
		--90为客户端自定义标记类型,标记创建公会成功的消息
		if ChatHelper.isNewCreated() then --是新创建的公会
			--type,msgid,userid,msg,state,username
			ChatHelper.addGuildMsg(90,0,-1,string.format(TxtList.guildMsg[5],club_data.clubName),nil,TxtList.systemCH)
		elseif ChatHelper.isNewJoin() then --新加入公会
			ChatHelper.addGuildMsg(90,0,club_data.managerID,string.format(TxtList.guildMsg[7],club_data.clubName),nil,club_data.manager)
		end
		ChatHelper.setNewCreated(false)
		ChatHelper.setNewJoin(false)
        --print("club_data:",table_aux.serial(club_data))
    else
        club_data = nil
		ChatHelper.clearGuildMsg()
        print("no join club")
		postEventSignal(kEventClubWarDownLoad) --通知公会战数据接收完毕
    end
	postEventSignal(kEventClubDownLoad) --通知公会数据接收完毕
end
--===========================
--398005 已加入公会回复
--===========================
_socketParser[398005] = function()
    local guid = RecvQueue:readInt()
	local digLvs = RecvQueue:readInt()
	local elos = RecvQueue:readInt()
	local names = RecvQueue:readStr()
	names = HOAux:hexstr2str(names)
	if guid == account_data.guid then
	    ChatHelper.setNewJoin(true)
		account_data.joinClubTime = os.time()
        SendMsg[938002]()
    else
   	    club_data.members[guid]={name = names,digLv = digLvs,elo = elos,guid= guid,honor=0,atkCount=0}
   	    club_data.membersCount = club_data.membersCount+1
    end
end

--===========================
--398008 会内聊天广播
--===========================
_socketParser[398008]= function(msglen)
    print("receve chat infomation")
    local userguid = RecvQueue:readInt()
    local mid = RecvQueue:readInt()
    local usermsg  = RecvQueue:readStr()
	ChatHelper.addGuildMsg(3,mid,userguid,usermsg)
end
--==========================
--398009 被踢出公会
--==========================
_socketParser[398009] = function()
	ChatHelper.setHasGuildMsg(false)
	if club_data then
		ChatHelper.addPubMsg(0,0,TxtList.systemCH..TxtList.msg,0,"",string.format(TxtList.guildMsg[4],club_data.manager,club_data.clubName))
	end
	ChatHelper.clearGuildMsg()
    club_data = nil
end
--==========================
--398010 广播解散公会
--==========================
_socketParser[398010] = function()
	ChatHelper.setHasGuildMsg(false)
	if club_data then
		ChatHelper.addPubMsg(0,0,TxtList.systemCH..TxtList.msg,0,"",string.format(TxtList.guildMsg[8],club_data.manager,club_data.clubName))
	end
	ChatHelper.clearGuildMsg()
	account_data.cid = 0
	account_data.cbName = ""
	club_data=nil
end

--==========================
--398004 广播申请加入公会
--==========================
_socketParser[398004] = function(msglen,guid)
    local byteLen = msglen - 16
    local tableTemp = getTableFromMsg(byteLen)
	tableTemp.name = HOAux:hexstr2str(tableTemp.name)
	ChatHelper.addGuildMsg(tableTemp.type,tableTemp._mid,tableTemp.guid,tableTemp.content,tableTemp.state,tableTemp.name,tableTemp.date)
end
--===========================
--398012 全服公会排位数据
--===========================
_socketParser[398012] = function (msglen)
	local bodylen = RecvQueue:readInt()
	if bodylen > 0 then
	    local selfIdx,totalPage,curPage,startIdx,endIdx = RecvQueue:read(5)
	    local byteLen  = msglen - 40
	    local srcBytes = RecvQueue:readUserData(byteLen)
	    StreamPaser:init(srcBytes,byteLen)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(4,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.cid,tb.elo,tb.jewel = StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			ClubRankHelper:addRankData(totalPage,curPage,tb)
		end
		ClubRankHelper:finishDownLoad(true)
	else
		ClubRankHelper:finishDownLoad()
	end
end
--==========================
 --398013 公会ELO奖励
 --==========================
_socketParser[398013] = function(msglen)
	account_data.jewel = account_data.jewel + RecvQueue:readInt()
end
--==========================
--398014 指定GUID帐号对应的公会信息摘要
--==========================
_socketParser[398014] = function (msglen,guid,opstate)
    local bytelen = msglen - 24
    if opstate == 0 then
		local dtype = RecvQueue:readInt()
		local bComp = RecvQueue:readInt()
        local club = protocol2table(dtype,bComp,bytelen)
		club.clubName = HOAux:hexstr2str(club.clubName)
		club.clubDesc = HOAux:hexstr2str(club.clubDesc)
		club.manager = HOAux:hexstr2str(club.manager)
		for uid, mbr in pairs(club.members) do
			mbr.name = HOAux:hexstr2str(mbr.name)
		end
        if not club_cid then
            club_cid={}
            club_cid[club.cid]=club
        else
            club_cid[club.cid]=club
        end
        club_cid[-1] = club --当前搜索的公会
        --AccountHelper:unlock(kStateToViewGuild)
        postEventSignal(kEventGetClubView)
    else
        if not club_cid then club_cid={}end
        --AccountHelper:unlock(kStateToViewGuild)
        postEventSignal(kEventGetClubView)
    end
end
--==========================
-- 398015 模糊查找返回的公会结果
--==========================
_socketParser[398015] = function (msglen,guid,opstate)
	local Count = RecvQueue:readInt()
	if Count > 0 then
		  club_search = {}
		  for idx=1,Count do
		      local tb ={}
		      tb = {cid=RecvQueue:readInt(),elo=RecvQueue:readInt(), membersCount=RecvQueue:readInt(),clubName=RecvQueue:readStr()}
		      tb.clubName = HOAux:hexstr2str(tb.clubName)
		      table.insert(club_search,tb)
		  end
	end
	postEventSignal(kEventClubSearch)
end
--==========================
-- 398016 默认显示公会列表
--==========================
_socketParser[398016] = function (msglen,guid,opstate)
	local Count = RecvQueue:readInt()
	if Count > 0 then
		  club_search = {}
		  for idx=1,Count do
		      local tb ={}
		      tb = {cid=RecvQueue:readInt(),elo=RecvQueue:readInt(), membersCount=RecvQueue:readInt(),clubName=RecvQueue:readStr()}
		      tb.clubName = HOAux:hexstr2str(tb.clubName)
		      table.insert(club_search,tb)
		  end
		   table.sort(club_search,function(a,b) return a.membersCount>b.membersCount end )
	end
	postEventSignal(kEventClubSearch)
end
--==========================
--3911001 搜索对战公会结果信息
--isSucc  --搜索结果 0：没有匹配的公会  >0 有匹配公会
--warData --对战双方数据
--==========================
_socketParser[3911001] = function (msglen,guid,opstate)
	local isSucc = RecvQueue:readInt()
	if isSucc > 0 then
		local dtype = RecvQueue:readInt()
		local bComp = RecvQueue:readInt()
		local warData = protocol2table(dtype,bComp,msglen-28)
		videomanager.clearwarvideo() --公会战开始时，清除公会战录像记录
		if club_data then
			club_data.warData = warData
			club_data.guardSt = 0
			club_data.members[account_data.guid].atkCount = numDef.cbWarAtkCount
			__formatWarData(club_data)
			--开战提示
             local tb = {}
             tb.type = 5
             tb.data = {type=0,}
             tb.data.clubName = club_data.clubName
             tb.data.atkClubName = club_data.warData.cb_atk.clubName
             tb.data.defClubName = club_data.warData.cb_def.clubName
             tb.data.atkStars = club_data.warData.cb_atk.sumStars
             tb.data.defStars = club_data.warData.cb_def.sumStars
             AccountHelper:addNewPrompt(tb)
		end
	end
	AccountHelper:unlock(kStateClubPvp)
end
--==========================
--3911002 公会对战防御方玩家及坑道信息
--isSucc  --可否开战 0：当前坑道正在初攻击  >0 可以开战
--lastStars --目标被我方获取过的最大星星
--clubpvpacct_data -- 目标坑道数据
--==========================
_socketParser[3911002] = function (msglen,guid,opstate)

	local isSucc = RecvQueue:readInt()
	if isSucc > 0 then
		local lastStars = RecvQueue:readInt()
		clubpvpacct_data = getTargetHoleData(msglen - 24,os.time())
		clubpvpacct_data.lastStars = lastStars
		local defencer = club_data.defClub.targets[clubpvpacct_data.guid]
		defencer.digLv = clubpvpacct_data.digLv
		defencer.elo = clubpvpacct_data.elo
		defencer.nickName = clubpvpacct_data.user
		defencer.stars = lastStars
	else
		clubpvpacct_data = nil
	end
	AccountHelper:unlock(kStateWarHole)
end
--==========================
--3911004 1v1战况广播
--cidOfTag(int) 被攻击者所属公会ID
--tagID(int)	被攻击者的GUID
--tagStars(int) 被攻击者最新星星数
--cidOfAtker(int) 攻击者所属公会ID
--sumStarsOfCbAtker(int) 攻击者所属公会最新累计星星数
--sumAtkCountOfCbAtker(int) 攻击者所属公会最新累计进攻计数
--atkerName(hexstr) 攻击者名字
--==========================
_socketParser[3911004] = function (msglen,guid,opstate)
	local cidOfTag =  RecvQueue:readInt()
	local tagID =  RecvQueue:readInt()
	local tagStars =  RecvQueue:readInt()
	local cidOfAtker =  RecvQueue:readInt()
	local sumStarsOfCbAtker = RecvQueue:readInt()
	local sumAtkCountOfCbAtker = RecvQueue:readInt()
	local atkerName,_ = RecvQueue:readStr()
	atkerName = HOAux:hexstr2str(atkerName)
	if club_data and club_data.warData then
		local atk_club = club_data.warData.cb_atk
		local def_club = club_data.warData.cb_def
		if cidOfTag == club_data.warData.cb_atk.cid then
			atk_club = club_data.warData.cb_def
			def_club = club_data.warData.cb_atk
		end
		local defencer = def_club.targets[tagID]
		defencer.stars = tagStars
		defencer.atkerName = atkerName
		atk_club.sumStars = sumStarsOfCbAtker
		atk_club.sumAtkCount = sumAtkCountOfCbAtker
	end
end
--==========================
--3911005 录像摘要广播
--==========================
_socketParser[3911005] = function(msglen,guid,opstate)
	local ret = __getbattleheader()
	if ret then
		for _, hdr in ipairs(ret) do
			local ud = RecvQueue:readUserData(hdr.sumzlen)
			local sumary = __getbattlesumary(ud, hdr.sumzlen)
			sumary.vid = hdr.vid
			videomanager.addwarsumary(sumary)
		end
	end
	club_data.battleSumaries = videomanager.getwarsumaries()
end
--==========================
--3911006 公会战结束广播
--atkEloDlt  攻方公会ELO变化
--defEloDlt	  防守公会ELO变化
--atkSumStars 攻方公会得到的星星总数
--defSumStars 防守公会得到的星星总数
--==========================
_socketParser[3911006] = function (msglen,guid,opstate)
	local atkEloDlt =  RecvQueue:readInt()
	local defEloDlt =  RecvQueue:readInt()
	local atkSumStars =  RecvQueue:readInt()
	local defSumStars =  RecvQueue:readInt()
	videomanager.clearwarvideo() --公会战结束时，清除公会战录像记录
	if club_data then
		club_data.lastWarResult ={}
		club_data.lastWarResult.atkName = club_data.warData.cb_atk.clubName
		club_data.lastWarResult.defName = club_data.warData.cb_def.clubName
		club_data.lastWarResult.atkEloDlt =  atkEloDlt
		club_data.lastWarResult.defEloDlt = defEloDlt
		club_data.lastWarResult.atkSumStars =  atkSumStars
		club_data.lastWarResult.defSumStars =  defSumStars
		club_data.lastWarResult.endTime = os.time()
		--公会战结束消息提示
		local tb = {}
		tb.type = 5
		tb.data = {type=1,}
		tb.data.clubName = club_data.clubName
		tb.data.atkClubName = club_data.lastWarResult.atkName
		tb.data.defClubName = club_data.lastWarResult.defName
		tb.data.atkEloDlt = club_data.lastWarResult.atkEloDlt
		tb.data.defEloDlt = club_data.lastWarResult.defEloDlt
		AccountHelper:addNewPrompt(tb)

		if club_data.cid == club_data.warData.cb_atk.cid then
			club_data.elo = math.max(club_data.elo + atkEloDlt,0)
			if atkEloDlt < defEloDlt then
				club_data.guardSt = os.time() + numDef.clubPvpGuardInt
			end
		else
			club_data.elo = math.max(club_data.elo + defEloDlt,0)
			if atkEloDlt >= defEloDlt  then
				club_data.guardSt = os.time() + numDef.clubPvpGuardInt
			end
		end

		club_data.warData = nil
	end
end
--==========================
--3911007 公会录像摘要信息
--==========================
_socketParser[3911007] = function(msglen)
	local ret = __getbattleheader()
	videomanager.clearwarvideo()
	if ret then
		for _, hdr in ipairs(ret) do
			local ud = RecvQueue:readUserData(hdr.sumzlen)
			local sumary = __getbattlesumary(ud, hdr.sumzlen)
			sumary.vid = hdr.vid
			videomanager.addwarsumary(sumary)
		end
	end
	club_data.battleSumaries = videomanager.getwarsumaries()
end
--==========================
 --3911008 公会战录像信息明细
 --==========================
 --atk: 进攻方数据
 --dfs: 防守方数据
 --==========================
_socketParser[3911008] = function(msglen,guid,opstate)
	if opstate == -1 then
	else
		local vid = RecvQueue:readInt()
		local sl = RecvQueue:readInt()
		local dl = RecvQueue:readInt()

		local ud_sum = RecvQueue:readUserData(sl)
		local sumary = __getbattlesumary(ud_sum, sl)

		local ud_detail = RecvQueue:readUserData(dl)
		local atk, def = __getbattledetail(ud_detail, dl)

		atk.team = sumary.team
		atk.heroList = sumary.heroList
		atk.equipments = sumary.equipments

		videomanager.addwarvideo(vid, {bpresult=sumary, atk=atk, def=def})
	end
    AccountHelper:unlock(kStateWarVideo)
end
--==========================
 --3911010 公会战数据
 --==========================
 --==========================
_socketParser[3911010] = function(msglen,guid,opstate)
	if opstate == -1 then
		club_data.warData = nil
	else
		local dtype = RecvQueue:readInt()
		local bComp = RecvQueue:readInt()
		club_data.warData = protocol2table(dtype,bComp,msglen-24)
		__formatWarData(club_data)
		if club_data.warData.expire -numDef.cbWarInterval  > account_data.lastOffline then
			 --交战中提示
			local tb = {}
			tb.type = 5
			tb.data = {type=0,}
			tb.data.clubName = club_data.clubName
			tb.data.atkClubName = club_data.warData.cb_atk.clubName
			tb.data.defClubName = club_data.warData.cb_def.clubName
			tb.data.atkStars = club_data.warData.cb_atk.sumStars
			tb.data.defStars = club_data.warData.cb_def.sumStars
			AccountHelper:addNewPrompt(tb)
		end
		club_data.warData.expire = club_data.warData.expire + account_data.scOffsetTime
	end
	postEventSignal(kEventClubWarDownLoad) --通知公会战数据接收完毕
end
--==========================
--3912001  排行榜奖励
--=========================
_socketParser[3912001] = function(msglen)
    local key = RecvQueue:readInt()
		local id = RecvQueue:readInt()
		local val = RecvQueue:readInt()
    account_data.rewardMails[key]={id=id,val=val}
    postEventSignal(kEventNoticeMail)
end
--===========================
--3913001 广播 创建的探险队
--===========================
_socketParser[3913001] = function(msglen)
    local tid = RecvQueue:readInt()
		local limit = RecvQueue:readInt()
		local date = RecvQueue:readInt()
		local content = RecvQueue:readStr()
    content = HOAux:hexstr2str(content)

    ChatHelper.updateGuildMsg(4,-tid)
    ChatHelper.addGuildMsg(4,-tid,tid,content,nil,nil,date,1,limit)
    club_data.teamMsg[tid]={guid=tid,limit=limit,date=date,content = content,cur=1 }
    AccountHelper:unlock(kStateAdventureTeam)
    --postEventSignal(kEventAdventureTeam)
end
--==========================
--3913002 查看的探险队数据
--==========================
_socketParser[3913002] = function(msglen)
    local op = RecvQueue:readInt()
    if op > 0 then
		local dtype = RecvQueue:readInt()
		if dtype == datatype.binary then
		    account_data.lookCbTeam = {}
	        account_data.lookCbTeam.tid = RecvQueue:readInt()
			account_data.lookCbTeam.bp = RecvQueue:readInt()
			account_data.lookCbTeam.consume = RecvQueue:readInt()
			account_data.lookCbTeam.ed = RecvQueue:readInt()
		    account_data.lookCbTeam.startEd = account_data.lookCbTeam.ed + os.time()
	        account_data.lookCbTeam.team = {}
		    local cnts = RecvQueue:readInt()
	        local cnt= cnts%256
			account_data.lookCbTeam.wins = math.floor(cnts/256)
		    for idx=1,cnt do
	            local tb = {}
				tb.guid =RecvQueue:readInt()
			    local heroCtx  = RecvQueue:readInt()
		        tb.heroid = math.floor(heroCtx/100)%100
	            tb.herolv = math.floor(heroCtx/1000000)
				table.insert(account_data.lookCbTeam.team,tb)
			end
		elseif dtype == datatype.bson then
			local ud = RecvQueue:readUserData(msglen-24)
			local raw = HOAux:bson2table(ud)
			raw.startEd = raw.ed
			raw.ed = raw.ed - os.time()
			raw.team = raw.heros
			for idx,hero in ipairs(raw.heros) do
				hero.guid = hero.sender
				hero.heroid = math.floor(hero.hctx/100)%100
				hero.herolv = math.floor(hero.hctx/1000000)
			end
			account_data.lookCbTeam = raw
		end
         ChatHelper.updateGuildMsg(4,-account_data.lookCbTeam.tid,#account_data.lookCbTeam.team)
    else
        account_data.lookCbTeam = nil
    end
    AccountHelper:unlock(kStateAdventureTeam)
    --postEventSignal(kEventAdventureTeam)
end
--===========================
--3913003 加入探险对回复
--===========================
_socketParser[3913003] = function(msglen,guid)
    local opstate = RecvQueue:readInt()
    if opstate == 0 then
        local tid = RecvQueue:readInt()
		    local ed = RecvQueue:readInt()
		    local heroid = RecvQueue:readInt()
		    account_data.cbTeam[heroid]={tid=tid,ed=os.time()+ed}
		    ChatHelper.updateGuildMsg(4,-account_data.lookCbTeam.tid,#account_data.lookCbTeam.team+1)
    elseif opstate == 1 then  --重复加入
        print("false")
    elseif opstate == 2 then  --满员
        print("false")
    end
    AccountHelper:unlock(kStateAdventureTeam)
    --postEventSignal(kEventAdventureTeam)
end
--===========================
--3913004 探险队到期英雄回归
--===========================
_socketParser[3913004]= function()
	local heroInfo = {}
	local heroList = {}
    local heroid,gainGold,gainExp,gainBox,winCnt = RecvQueue:read(5)
	table.insert(heroInfo,heroid)
	local newExp,newLv,expChange = RiskHelper.getHeroExpAndLv( gainExp,account_data.digLv,account_data.heroList[heroid])
	heroList[heroid] = {fexp =gainExp,gold = gainGold,boxid = gainBox,wins = winCnt,newExp =newExp,newLv = newLv,expChange = expChange }
	 --有宝箱
	if gainBox > 0 then
		heroList[heroid].awardRes =  baseCalc.treasureBox(account_data,gainBox)
	end
	local guid = account_data.cbTeam[heroid].tid
    club_data.teamMsg[guid]=nil
    account_data.cbTeam[heroid]=nil
     -- 英雄回归提示
    local tb = {}
    tb.type = 6
    tb.data = {}
    tb.data.team = heroInfo
    tb.data.heroList = heroList
    AccountHelper:addNewPrompt(tb)
	SendMsg[9313007](heroInfo,heroList)
end
--============================
--3913005 匹配探险队回复
--============================
_socketParser[3913005]= function()
    local cntOfTeam = RecvQueue:readInt()
    DefTaskHelper.removeAllTeam()
    for idx=1,cntOfTeam,1 do
        local tb = {
            heroList = {},
            equipments = {},
            team = {},
        }
        tb.tid = RecvQueue:readInt()
        tb.bp = RecvQueue:readInt()
        tb.consume =RecvQueue:readInt()
        local cnt = RecvQueue:readInt()
        for idx=1,cnt do
            local heroCtx  = RecvQueue:readInt()
            local eid = heroCtx % 10000
            local heroid = math.floor(heroCtx/100)%100
            local herograde = math.floor(heroCtx/10000)%100
            local herolv = math.floor(heroCtx/1000000)

            local eqCtx = RecvQueue:readInt()
            local eid_lv = eqCtx % 256
            local eid_qa = math.floor(eqCtx/256)

            local seid1 = RecvQueue:readInt()
            local seid2 = RecvQueue:readInt()

            table.insert(tb.team,heroid)
            local heroprop = {type=heroid,lv=herolv,grade=herograde,enterTime=1000,eid=eid,equip={eid_lv,eid_qa},eid_s1=seid1,eid_s2=seid2,}
            table.insert(tb.heroList,heroprop)
            --tb.equipments ={[eid]={eid_lv,eid_qa},}
        end
        tb.name = RecvQueue:readStr()
        tb.name = HOAux:hexstr2str(tb.name)
        tb.costAct = numDef.cbTeamBattleAp
        DefTaskHelper.addTeam(tb)
    end
    AccountHelper:unlock(kStateDefExplore)
end
--==========================
--990001 服务器断开连接
--==========================
_socketParser[990001] = function()
	AccountHelper:reLoadGame()
end
--==========================
--990002 网络异常
--==========================
_socketParser[990002] = function()
	postEventSignal(kEventNetDown)
end


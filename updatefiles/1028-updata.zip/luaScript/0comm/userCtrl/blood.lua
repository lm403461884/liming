local kBarBlood = "bar_blood"
local kImgBarBg = "img_bg"
local kLblLv = "lbl_lv"
local kImgLv = "img_lv"
local kRedColor = ccc3(255,0,0)
local kGreenColor = ccc3(0,255,0)
local kJumpDis =64
local kRandomM = 36
local kRandomN = -36
local kFlagH = 1 -- ��ͨ����
local kFlagC = 2 -- ����
local kFlagD = 3 --����
local kFlagS = 4 --�����˺�
local __blood ={}

--���õ�ǰѪ��
--val Ѫ���仯ֵ
--flag �������� 1 - ��ͨ���У�2 - ����,3 -����
function __blood.updateHP(obj,val,flag)
    if not obj._blood then  return end
	if not val or not flag then
		local oldhp = obj._curhp
		local newhp = obj:getprop("hp")
		if newhp < 0 then newhp = 0 end
		val = newhp-oldhp
		flag = 1
	end
	obj._curhp = obj:getprop("hp")
	obj._blood:egSetBarPercent(kBarBlood,obj._curhp*100/obj:getprop("maxHP"))
	local holelayer = AccountHelper:get(kHoleLayer)
	local damagelayer = holelayer._damagelayer
	if damagelayer then 
		local x = obj:egNode():getPositionX()
		local y = obj:egNode():getPositionY()
		local size = obj:egNode():getContentSize()
		local isEnemy = obj:getprop("isEmemy")
		if flag == kFlagH and val ~= 0 then -- ��ͨ����
			damagelayer:showDamage(val,x+size.width/2,y,isEnemy)
		elseif flag == kFlagC  and val ~= 0  then  -- ����
			damagelayer:showCriticalStrike(val,x+size.width/2,y,isEnemy)
		elseif flag == kFlagD then --����
			damagelayer:showDodge(x+size.width/2,y,isEnemy)
		elseif flag == kFlagS then --�����˺�
			damagelayer:showSkillDamage(val,x+size.width/2,y,isEnemy)
		end
	end
end
--��ʾѪ���͵ȼ�
function __blood.showHP(obj)
    if not obj._blood then return end
	obj._blood:egShowWidget(kImgBarBg)
	obj._blood:egShowWidget(kImgLv)
	local imglv = obj._blood:egGetWidgetByName(kImgLv)
	local imgsize = imglv:getSize()
	imglv:setPosition(ccp(imgsize.width/2,imgsize.height/2))
end
--����Ѫ���͵ȼ�
function __blood.hideHP(obj)
    if not obj._blood then return end
    obj._blood:egHideWidget(kImgBarBg)
    obj._blood:egHideWidget(kImgLv)
end
--���صȼ�
function __blood.hideLV(obj)
    if not obj._blood then return end
    obj._blood:egHideWidget(kImgLv)
end
--��ʾ�ȼ�
function __blood.showLV(obj)
    if not obj._blood then return end
    obj._blood:egShowWidget(kImgLv)
end
--��ʾѪ��
function __blood.showHPBar(obj)
    if not obj._blood then return end
	obj._blood:egShowWidget(kImgBarBg)
	local imglv = obj._blood:egGetWidgetByName(kImgLv)
	local imgsize = imglv:getSize()
	imglv:setPosition(ccp(imgsize.width/2,imgsize.height/2))
end
--����Ѫ��
function __blood.hideHPBar(obj)
    if not obj._blood then return end
    obj._blood:egHideWidget(kImgBarBg)
	local imglv = obj._blood:egGetWidgetByName(kImgLv)
	local imgsize = imglv:getSize()
	imglv:setPosition(ccp(obj._hpsize.width/2,imgsize.height/2))
end

--�ж��Ƿ��ǵз�����
function __blood.isEmemy(obj)
	return obj:getprop("isEmemy")
end
function __blood.bindBlood(obj,creaturelayer,zorder)
    obj._blood = {}
    CocosWidget.install(obj._blood,JsonList.blood)
    obj._hpsize = obj._blood:egNode():getSize()
    obj._curhp = obj:getprop("hp")
    obj._blood:egSetBarPercent(kBarBlood,obj._curhp*100/obj:getprop("maxHP"))
    obj._blood:egSetBMLabelStr(kLblLv,obj:getprop("level"))
    if obj:getprop("isEmemy") then
        obj._blood:egSetWidgetColor(kBarBlood,kRedColor)
		obj._blood:egChangeImg(kImgLv,ImageList.risk_lv_red,UI_TEX_TYPE_PLIST)
    else
        obj._blood:egSetWidgetColor(kBarBlood,kGreenColor)
		obj._blood:egChangeImg(kImgLv,ImageList.risk_lv_green,UI_TEX_TYPE_PLIST)
    end
    obj._blood:egAttachTo(creaturelayer,zorder,zorder)
    obj:activePosTimer()
    obj:hideHPBar()--Ĭ������Ѫ��
end
function __blood.unBindBlood(obj)
    if obj._blood then
        obj._blood:egUnbindWidgetUpdate(kBarBlood)
        obj._blood:egRemoveSelf()
    end
end
function __blood.activePosTimer(obj)
    local function callback()
		if obj:egNode() ~= nil then
			local size = obj:egNode():getContentSize()
			local x = obj:egGetPosX() - obj._hpsize.width/2
			local y = obj:egGetPosY() + size.height/2 - obj._hpsize.height/4
			obj._blood:egNode():setPosition(ccp(x,y))
		end
	end
	obj._blood:egBindWidgetUpdate(kBarBlood,callback)
end
Blood={}
function Blood.install(obj)
	table_aux.unpackTo(__blood,obj)
end


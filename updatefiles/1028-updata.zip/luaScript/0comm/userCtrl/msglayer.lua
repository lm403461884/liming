local kBtnOk = "Button_ok"
local kBtnCancel ="Button_cancel"
local kLblTitle = "Label_title"
local kLblContext = "Label_content"
local kImgBg = "img_dialog_bg"
_msglayer={}
local kPosCenterX = 0
local kMaxW = 610
local kOffsetY = 40
local kOffsetH = 13

function _msglayer.show(obj)
    local scene = CCDirector:sharedDirector():getRunningScene()
     scene:addChild(obj:egNode(),UILv.msgLayer,UILv.msgLayer)
end
function _msglayer.bindOkListener(obj)
    local function touchEnd(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods) --确认
        if obj._callback1 then obj._callback1(sender) end
        obj:egRemoveSelf()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnd,nil) 
end
function _msglayer.bindCancelListener(obj)
    local function touchEnd(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods) --确认
        if obj._callback2 then obj._callback2(sender) end
        obj:egRemoveSelf()
    end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnd,nil) 
end
function _msglayer.init(obj)
		local btnyes = tolua.cast(obj:egGetWidgetByName(kBtnOk),"Button")
		local btnno = tolua.cast(obj:egGetWidgetByName(kBtnCancel),"Button")
		local context =  tolua.cast(obj:egGetWidgetByName(kLblContext),"Label");
		local title =  tolua.cast(obj:egGetWidgetByName(kLblTitle),"Label");
		------------------------------------------button 
		if obj._btnCnt==1 then
		    btnyes:setPosition(ccp(kPosCenterX,btnyes:getPositionY()))
 		    btnno:setVisible(false)
			btnno:setEnabled(false)
		end
-------------------------------------------label
        if obj._title then
			title:setText(obj._title)         
		else 
			obj._maxRow = 2
            title:setVisible(false)
			context:setPosition(ccp(context:getPositionX(),context:getPositionY() + kOffsetY))
		end
		if obj._context then
			context:setText(obj._context)
		end
		if obj._btnTxt1 then btnyes:setTitleText(obj._btnTxt1) end
		if obj._btnTxt2 then btnno:setTitleText(obj._btnTxt2) end
		local txtlen = context:getSize().width
		if txtlen > kMaxW then
			local row = math.ceil(txtlen/kMaxW)
			local cellH = context:getSize().height
			context:setTextAreaSize(CCSizeMake(kMaxW,row*( cellH+ kOffsetH)))
			local addH = math.max((row-obj._maxRow),0)*cellH
			local imgbg = obj:egGetWidgetByName(kImgBg)
			imgbg:setSize(CCSizeMake(imgbg:getSize().width,imgbg:getSize().height + addH))
			btnyes:setPosition(ccp(btnyes:getPositionX(),btnyes:getPositionY() - addH/2))
			btnno:setPosition(ccp(btnno:getPositionX(),btnno:getPositionY() - addH/2))
			title:setPosition(ccp(title:getPositionX(),title:getPositionY() + addH/2))
			context:setPosition(ccp(context:getPositionX(),context:getPositionY() + addH/2))
		end
end

MsgLayer={}
function MsgLayer.new(title,context,btnCnt,callback1,callback2,btnTxt1,btnTxt2)
    local framebtn = CCSpriteFrameCache:sharedSpriteFrameCache():spriteFrameByName(ImageList.btn_brown_n)
    if not framebtn then
         graphicLoader.loadFrame("button")
    end
	local obj=TouchWidget.new(JsonList.msglayer)
	 table_aux.unpackTo(_msglayer,obj)
	 obj._title=title
	 obj._context=context
	 obj._btnCnt=btnCnt
	 obj._callback1=callback1
	 obj._callback2=callback2
	 obj._btnTxt1 = btnTxt1
	 obj._btnTxt2 = btnTxt2
	 obj._maxRow = 1
	 obj:egSetTouchPriority(-256)
	 obj:init()
	 obj:bindOkListener()
	 obj:bindCancelListener()
	 return obj
	end

local kSpeed = 200
local kSecForFrame = 0.016
local __hero = {}

function __hero.openAi(obj)
	obj:setprop('aiActived',true)
    ai_module.add(obj)
    obj:showHP()
end
--[[
function __hero.moveToPos(obj,dir,x,y,sec,callback)
    local moveto = CCMoveTo:create(sec,ccp(x,y))
    local function callbackfunc()
        obj:egNode():stopAllActions()
        obj:egChangeFrame(obj._startFrame)
        if callback then callback() end
    end
    local action_callback = CCCallFuncN:create(callbackfunc)
    local sequence = CCSequence:createWithTwoActions(moveto,action_callback)
    local animaName = string.format('%s_02%02d', obj:getprop('graphName'),dir/90)
    local anima = graphicLoader.getAnimation(animaName)
    if not anima then print('engine: can not find anima ' .. animaName) return end
    anima:setRestoreOriginalFrame(true)
    local animate = CCAnimate:create(anima)
    local action = CCRepeat:create(animate,1000000)
    local spawn = CCSpawn:createWithTwoActions(sequence,action)
    obj:egRunAction(spawn)
end
--]]
function __hero.runWalkAction(obj,dir)
	local animaName = string.format('%s_02%02d', obj:getprop('graphName'),dir/90)
	local anima = graphicLoader.getAnimation(animaName)
	if not anima then print('engine: can not find anima ' .. animaName) return end
	anima:setRestoreOriginalFrame(true)
	local animate = CCAnimate:create(anima)
	local action = CCRepeat:create(animate,1000000)
	obj:egNode():stopAllActions()
	obj:egNode():runAction(action)
end
function __hero.moveToPos(obj,desPos,callback)
	local posx = obj:egGetPosX()
	local posy = obj:egGetPosY()
	local offsetx = desPos.x - posx
    local offsety = desPos.y - posy
	local speedx = kSpeed
	local speedy = kSpeed
	local dirActX = 0
	local dirActY = 0
	if offsetx > 0 then dirActX = 90 
	elseif offsetx < 0  then dirActX = 270  speedx = -kSpeed end
	if offsety > 0 then dirActY = 360 
	elseif offsety < 0 then dirActY = 180  speedy = -kSpeed end
	if dirActX~=0 then
		obj:runWalkAction(dirActX)
	elseif dirActY~=0 then
		obj:runWalkAction(dirActY)
	end
	local function update(dt)
		if math.abs(posx)< math.abs(desPos.x) then
			posx = posx + speedx * kSecForFrame*CCDirector:sharedDirector():getScheduler():getTimeScale()
			if math.abs(posx) >= math.abs(desPos.x) then 
				posx = desPos.x 
				if dirActY~=0 then	obj:runWalkAction(dirActY) end
			end
			obj:egSetPosition(posx,posy)
		else
			posy = posy + speedy * kSecForFrame*CCDirector:sharedDirector():getScheduler():getTimeScale()
			if math.abs(posy) <= math.abs(desPos.y) then 	
				posy = desPos.y 
				obj:egSetPosition(posx,posy)
				if obj._scripEntryId then
					CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(obj._scripEntryId)
				end
				obj:egNode():stopAllActions()
				obj:egChangeFrame(obj._startFrame)
				if callback then callback() end
			else
				obj:egSetPosition(posx,posy)
			end
			
		end
	end
	obj._scripEntryId = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update, 0.0, false)
	local function exitFuns(eventType)
       if obj._scripEntryId then
			CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(obj._scripEntryId)
		end
    end
    obj._egObj:registerScriptHandler(exitFuns)
end
function __hero.moveToward(obj,dir,disance,sec)
    local x = 0
    local y = 0
    if dir == 90 then x = disance 
    elseif dir == 270 then x = -disance 
    elseif dir == 180 then y = -disance 
    elseif dir == 360 then y = disance end
    local moveby = CCMoveBy:create(sec,ccp(x,y))
    local function callbackfunc()
        obj:egNode():stopAllActions()
        obj:egChangeFrame(obj._startFrame)
    end
    local action_callback = CCCallFuncN:create(callbackfunc)
    local sequence = CCSequence:createWithTwoActions(moveby,action_callback)
    local animaName = string.format('%s_02%02d', obj:getprop('graphName'),dir/90)
    local anima = graphicLoader.getAnimation(animaName)
    if not anima then print('engine: can not find anima ' .. animaName) return end
    anima:setRestoreOriginalFrame(true)
    local animate = CCAnimate:create(anima)
    local action = CCRepeat:create(animate,1000000)
    local spawn = CCSpawn:createWithTwoActions(sequence,action)
    obj:egRunAction(spawn)
end

	Hero={}

function Hero.new(prop, pos,equipinfo)

    local obj = {}
    BaseProp.install(obj)
    InnerProp.install(obj)
    sprite.install(obj)
	obj:egChangeFrame(ImageList.comm_blank)
    Blood.install(obj)
    table_aux.unpackTo(__hero, obj)
	if not equipinfo then equipinfo = {1,1} end
	--read various config data
    local heroCfg = assert(hero_data.getConfig(prop.type))
    local heroDataAtLv = assert(hero_data.get(prop.type, prop.lv))
	local equipLv = assert(equipinfo[1])
	local equipQualityLv = assert(equipinfo[2])
	local equipCfgOfEid = assert(equipCfg[prop.eid] or {skill=heroCfg.skillNames[1]})
	graphicLoader.loadHeroAnima(prop.type, prop.lv,true)
	obj._s_data = heroDataAtLv
    obj._d_data = prop
    
	--add static properties
    for name, val in pairs(heroDataAtLv) do
		obj:addprop(name, val)
    end
	--main
	obj:addprop('mainType', 1)
    obj:addprop('type', prop.type)
    obj:addprop("level", prop.lv)
    
	--about equipment
	obj:addprop('equipID', prop.eid)
	obj:addprop('equipLv', equipLv)
	local maxHP,power,critical,dodge = RiskHelper.getHeroPropWithEquip(prop,equipLv)
	if not prop.ignoreEquip then prop.hp =  maxHP end
	obj:setprop('maxHP', maxHP)
	obj:setprop('hp', prop.hp)
	obj:setprop('power', power)
	obj:setprop('critical', critical)
	obj:setprop('dodge', dodge)
	obj:setprop('activeSkill', equipCfgOfEid.skill)
	obj:setprop('activeSkillPowerPlus', equipEvoData[prop.eid][equipQualityLv]["powerPlus"])

	--ai
    obj:addprop('aiEntryName', heroCfg.aiEntryName)
    obj:addprop('skillNames', heroCfg.skillNames)
    obj:addprop("zorder", 0)
    obj:addprop("birthPlace",pos)
	obj:addprop("powerBar",prop.power)
	obj:addprop("maxPower",numDef.maxPower)
    obj:addprop('graphName', heroCfg.graphList[heroDataAtLv.graphLV])
    obj._startFrame = string.format('%s_010201.png',heroCfg.graphList[heroDataAtLv.graphLV])
    obj:egChangeFrame(obj._startFrame)
    obj:addprop('aiActived',false)
    return obj
end

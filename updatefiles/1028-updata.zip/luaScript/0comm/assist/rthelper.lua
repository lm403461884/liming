local kTrainPrompt = 2
local kLicencePrompt = 3
local kChemyPrompt = 4
local kGvgPrompt = 5
--��ȡ��������ֵ
local function countTrainProps(trainid)
    if not train.props[trainid] then return {} end
    local tb = {}
    for key,_ in pairs(train.props[trainid]) do
        tb[key] = account_data[key]
    end
    return tb
end
local function countTrainPropChanges(oldtb,newtb)
    local tb = {}
    for key,val in pairs(oldtb) do
        tb[key] = {val,newtb[key]}
    end
    return tb
end
local function isHeroInTeam(heroid)
    for key,val in ipairs(account_data.team)do
        if val == heroid then return true end
    end
    return false
end

----------------------------------
--��������
--account_data.train = {[1] = {lv,exp}
--����ID={��ǰ�ȼ���������Ϣ��{Ŀ��ȼ���ʣ��ʱ��,��ʼʱ��}}
----------------------------------
local function resetTrainLvUp()
    for idx,item in pairs (account_data.train) do
        if item.exp > 0 and item.exp <= os.time() then
            local oldtb = countTrainProps(idx) --��ȡ����ǰ����
			local tlv = item.lv + 1
            account_data.train[idx].lv = tlv
            SendMsg[937003](idx,tlv)
			--�ھ���־������̸���,������
			task.updateTaskStatus(account_data,task.client_event_id.update_train,{idx,tlv})
			----------------------------------------------------------
            train.levelup(account_data,idx, tlv)
            account_data.train[idx].exp = -1
            postEventSignal(kEventTrainUpEnd..idx)
            local newtb = countTrainProps(idx) --��ȡ����������
            --��Ϣ��ʾ---------------
            local tb = {}
            tb.type = kTrainPrompt
            tb.data={}
            tb.data.trainid = idx
            tb.data.from = tlv - 1
            tb.data.to = tlv
            tb.data.changes = countTrainPropChanges(oldtb,newtb)
            AccountHelper:addNewPrompt(tb)
            -----------------------------
        end
    end
end

--------------------------
--ִ������ diggingLvContext��{st ��ʼʱ��,left ʣ��ʱ��}
--------------------------
local function resetLicenceLvUp()
    if account_data.diggingLvContext and account_data.diggingLvContext> 0 and account_data.diggingLvContext<= os.time() then --����-1ʱ��ʾû������
        local lv = account_data.digLv
        local tlv = lv + 1
        account_data.digLv = tlv
        SendMsg[932005](lv,tlv)
			--�ھ���־������̸���,���ִ������
		task.updateTaskStatus(account_data,task.client_event_id.diglv_update,{tlv})
			----------------------------------------------------------
        licenceLevelup.onLvUp(account_data)
        account_data.diggingLvContext = -1
        postEventSignal(kEventLicenceUpEnd)
        postEventSignal(kEventNoticeMission)
            --��Ϣ��ʾ-----------------------
        local tb = {}
        tb.type = kLicencePrompt
        tb.data = {from = lv,to = tlv}
        AccountHelper:addNewPrompt(tb)
            --------------------------
   end
end
--ˢ�¿�����ȴʱ��
local function resetResCar()
	for key,item in ipairs(account_data.collectorList) do
		local targetMine = account_data.mileSpread[item.pos]
		if targetMine and targetMine.dt>0 then
			local passed = os.time() - targetMine.st
			if passed > 0 then
				targetMine.dt = targetMine.dt - passed
				targetMine.st = os.time() --������Ե�ǰʱ��ˢ��ST
			end
        end
    end
end
--�ھ���־�������
local function resetTaskList()
	if os.time() >= account_data.taskRt then
		account_data.taskRt =  Funs.getTimeWithHMS(numDef.dayTaskRefreshUTH,numDef.dayTaskRefreshUTM,0,account_data.scOffsetTime)
		local today_taskid = task.refresh(account_data)
		if today_taskid then
			for key, taskid in ipairs(today_taskid) do
				local taskinfo = taskQuery.getName(taskid)
				if taskinfo then
					taskinfo.taskrefresh(account_data)
				else
					print('tid ' .. taskid .. ', do not exsit')
				end
			end
			--������Ϣ��������
			SendMsg[9310001](today_taskid)
		end
	end
end
-----------------------
--�����ж����ظ�ʱ��,�������ˢ��ʱ�䣬ʹ֮��ͻ���ʱ��һ��
-----------------------
local function fitAP()
    account_data.rcAP = account_data.rcAP + account_data.scOffsetTime
	--�ж����ظ�ʱ��,�ÿͻ���ʼ�ձȷ�������һ������
	if not account_data.apBoughtCnt then account_data.apBoughtCnt = 0 end
	if not account_data.actPtSt then
		account_data.actPtSt = os.time()
		account_data.actPtNextSt = Funs.getTimeWithHMS(numDef.actPtUTH,numDef.actPtUTM,0,account_data.scOffsetTime)
	else
		account_data.actPtSt = account_data.actPtSt + account_data.scOffsetTime
		account_data.actPtNextSt = account_data.actPtNextSt + account_data.scOffsetTime
	end
end
------------------------
--�����󳵲ɼ�ʱ��(������ȴʱ��)
-------------------------
local function fitResCar()
    for key,item in ipairs(account_data.collectorList) do
		item.st = item.st + account_data.scOffsetTime
		local targetMine = account_data.mileSpread[item.pos]
		if targetMine then
			targetMine.dt = math.max(targetMine.dt - (os.time()- item.st),0)
			targetMine.st = os.time()
			--��ȴʱ�� ��  ԭ������ȴʱ�� �� (��ǰʱ������Ͽ�ʱ���ʱ���)
        end
    end
end
local function fitRefreshTime()
		--�����ھ���־�������ʱ��
	if account_data.taskRt >= 0 then 
		account_data.taskRt = account_data.taskRt  + account_data.scOffsetTime 
	else
		account_data.taskRt = Funs.getTimeWithHMS(numDef.dayTaskRefreshUTH,numDef.dayTaskRefreshUTM,0,account_data.scOffsetTime)
	end
	--������һ��Զ������ʼʱ��
	if  account_data.exMission then
		account_data.exMission.nextSt = account_data.exMission.nextSt + account_data.scOffsetTime
	end
	if account_data.revengeNextSt and account_data.revengeNextSt >= 0 then
		account_data.revengeNextSt = account_data.revengeNextSt + account_data.scOffsetTime
	else
		account_data.revengeNextSt = Funs.getTimeWithHMS(numDef.revengeRefreshUTH,numDef.revengeRefreshUTM,0,account_data.scOffsetTime)
	end
	--��ҹ������
	if not account_data.goldBoughtCnt then account_data.goldBoughtCnt = 0 end
	if account_data.goldNextSt and account_data.goldNextSt >= 0 then 
		account_data.goldNextSt = account_data.goldNextSt  + account_data.scOffsetTime 
	else
		account_data.goldNextSt = Funs.getTimeWithHMS(numDef.goldRefreshUTH,numDef.goldRefreshUTM,0,account_data.scOffsetTime)
	end
	--PVE����ʹ�ô���
	if not account_data.pveUsedCnt then account_data.pveUsedCnt = 0 end
	if account_data.pveNextSt and account_data.pveNextSt >= 0 then 
		account_data.pveNextSt = account_data.pveNextSt  + account_data.scOffsetTime 
	else
		account_data.pveNextSt = Funs.getTimeWithHMS(numDef.pveRefreshUTH,numDef.pveRefreshUTM,0,account_data.scOffsetTime)
	end
	--����ʹ�ô���
	if not account_data.chatUsedCnt then account_data.chatUsedCnt = 0 end
	if account_data.chatNextSt and account_data.chatNextSt >= 0 then 
		account_data.chatNextSt = account_data.chatNextSt  + account_data.scOffsetTime 
	else
		account_data.chatNextSt = Funs.getTimeWithHMS(numDef.chatRefreshUTH,numDef.chatRefreshUTM,0,account_data.scOffsetTime)
	end
end
--------------------------------
--̽�ն�ʣ��ʱ��
--------------------------------
local function resetExploreTime()
    for heroid,item in pairs(account_data.cbTeam) do
        local leftTime = item.ed - os.time()
        if leftTime<=0 and not item.timeOver and not item.reward then
            SendMsg[9313004](item.tid)
            item.timeOver = true
        end
    end
end

--------------------------------
--ȷ��Ӣ�۴�̽�նӻع�
--------------------------------
local function isCbTeamBack ()
	local heroList = {}
	local heroInfo ={}
    for heroid,item in pairs(account_data.cbTeam) do
        if item.reward then
			table.insert(heroInfo,heroid)
			heroList[heroid]={}
			heroList[heroid].fexp = item.reward.fexp
			heroList[heroid].gold = item.reward.fgold
			heroList[heroid].boxid = item.reward.boxid
			heroList[heroid].wins =  item.reward.wins
			heroList[heroid].newExp,heroList[heroid].newLv,heroList[heroid].expChange =RiskHelper.getHeroExpAndLv( item.reward.fexp,account_data.digLv,account_data.heroList[heroid])
			if item.reward.boxid > 0 then
				heroList[heroid].awardRes =  baseCalc.treasureBox(account_data,item.reward.boxid)
			end --�б���
			local guid = account_data.cbTeam[heroid].tid
		    account_data.cbTeam[heroid]=nil
			--club_data.teamMsg[guid]=nil
        end
    end
	local idx = 0
	while idx < #heroInfo do
		local tb = {}
		tb.type = 6
		tb.data={}
		local startIdx = idx + 1
		local endIdx = math.min(#heroInfo,idx+5)
		tb.data.team = {}
		for i = startIdx,endIdx do
			table.insert(tb.data.team,heroInfo[i])
		end
		tb.data.heroList = heroList
		idx = idx + 5
		AccountHelper:addNewPrompt(tb)
	end
	if #heroInfo > 0 then
	    SendMsg[9313007](heroInfo,heroList)
	end
end
--------------------------------
--�����лظ�ʱ��ת���ɿͻ���ʱ��
--------------------------------
function resetRTInfo()
    if not account_data or not scriptDownloaded then return end
	account_data.scOffsetTime = os.time() - account_data.onlinedt
	--������ļˢ��ʱ��
	account_data.freeMsgExpire = (account_data.freeMsgExpire or (os.time()-account_data.scOffsetTime)) + account_data.scOffsetTime
	account_data.freeBoxExpire = (account_data.freeBoxExpire or (os.time()-account_data.scOffsetTime)) + account_data.scOffsetTime
	--����PVP����ʱ��
	account_data.shellPvp = account_data.shellPvp + account_data.scOffsetTime
	--����̽�նӻع�ʱ��
	for heroid,item in pairs(account_data.cbTeam) do
	    item.ed = item.ed + account_data.scOffsetTime
	end
	--����ִ������ʱ��
	if account_data.diggingLvContext > 0 then account_data.diggingLvContext = account_data.diggingLvContext + account_data.scOffsetTime end
	--�������¿�ʱ��
	if account_data.openHoleContext > 0 then account_data.openHoleContext = account_data.openHoleContext + account_data.scOffsetTime end
	--������������ʱ��
	for idx,item in pairs(account_data.train) do
		if not item.exp then item.exp = -1 end
		if item.exp > 0 then item.exp = item.exp + account_data.scOffsetTime end
    end
    --����ǩ��ʱ��
    if account_data.signInExp_d then
        account_data.signInExp_d = account_data.signInExp_d + account_data.scOffsetTime
    end
    if account_data.signInExp_m then
        account_data.signInExp_m = account_data.signInExp_m + account_data.scOffsetTime
    end
	fitRefreshTime()
    isCbTeamBack()
    fitAP()
    fitResCar()
	--�ط����б�����Ϣ����
	NotifyHelper.showAll()
end


---------------------
--�������ж�ʱ����
--ÿ������
---------------------
function UpdateProp()
    if not account_data or not scriptDownloaded then return end
    --�ظ��ж���
    baseCalc.resetActPt(account_data,os.time()-1)
    resetTrainLvUp()
    resetLicenceLvUp()
	resetResCar()
	resetTaskList()
	resetExploreTime()
end

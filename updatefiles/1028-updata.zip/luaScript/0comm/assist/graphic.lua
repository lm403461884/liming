
local faceAnimaList = {
	['eps_go01'] = { frames = 2 , delay = 0.1 },
	['eps_easy01'] = { frames = 9 , delay = 0.1 },
	['eps_thank01'] = { frames = 2 , delay = 0.1 },
	['eps_scare02'] = { frames = 4 , delay = 0.1 },
	['eps_thank02'] = { frames = 6 , delay = 0.1 },
	['eps_scare01'] = { frames = 5 , delay = 0.1 },
	['eps_tension01'] = { frames = 4 , delay = 0.1 },
	['eps_ok01'] = { frames = 2 , delay = 0.1 },
	['eps_taunt01'] = { frames = 6 , delay = 0.1 },
	['eps_win01'] = { frames = 7 , delay = 0.1 },
	['eps_query01'] = { frames = 4 , delay = 0.1 },
	['eps_however01'] = { frames = 9 , delay = 0.1 },
	['eps_exciting01'] = { frames = 4 , delay = 0.1 },
	['eps_proud01'] = { frames = 5 , delay = 0.1 },
	['eps_anger01'] = { frames = 4 , delay = 0.1 },
	['eps_battel01'] = { frames = 4 , delay = 0.1 },
	['eps_exciting03'] = { frames = 4 , delay = 0.1 },
	['eps_maze01'] = { frames = 3 , delay = 0.1 },
	['eps_help01'] = { frames = 3 , delay = 0.1 },
	['eps_dialogue01'] = { frames = 3 , delay = 0.1 },
	['eps_exciting02'] = { frames = 4 , delay = 0.1 },
}

local kResSpritePath = "GUIRes/image/sprite/" --����ͼ·��
local kResAnimaPath = "GUIRes/image/other/"--�򵥶���·��
local kResHeroPath = "GUIRes/PvrCcz/hero/"--Ӣ����Դ·��
local kResMapPath = "GUIRes/PvrCcz/worldmap/"--��ͼ��Դ·��
local kResBgPath = "GUIRes/PvrCcz/m_bg/"--���Ŵ�ͼ·��
local kParticlePath = "particle/shader_texture/thunder1.png"--���Ŵ�ͼ·��
local kMapRes = {"map_1","map_2","map_3","map_4","map_5","map_6"}
local kBasicImgList = {"tile","button","icon","grab","s_bg_1","s_bg_2","s_bg","hero_head","monster_head","tool","selected_state","herocard_1","herocard_2","herocard_3","herocard_4","herocard_5","herocard_6","herocard_7","herocard_8","resbox","trainupdate","headupdate","guild_blink","toolsmoke","traintool_fire","trainlvup","licence_blink","digfog","diglight","machine_flash","machine_fog",
"bar","thumb_bg","herotitle"}
local kMonsterCardList = {"monstercard_1","monstercard_2","monstercard_3","monstercard_4","monstercard_5","monstercard_6",}
local kBasicAnimaList={"box_silver_open","box_gold_open","box_copper_open","anima_block_0101","anima_block_0102","anima_block_0103","anima_block_0104","anima_block_0105","anima_mine_0101","anima_mine_0201","grab_action","grab_stand","toolsmoke_act","traintool_fire_act","trainlvup_act","trainupdate_act","headupdate_act","guild_blink_act","licence_blink_act",
"digfog_act","diglight_act","machine_flash_act","machine_fog_act","selected_state_act",}
--��������ԭʼ֡������ұ�
--key: anima name
--val: orignal delay
local _animaOrigDelayLook = {}
local _animaContext = {}
local _animaCache = {}
local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
local textureCache = CCTextureCache:sharedTextureCache()
local plist = ".plist"
local pvrccz = ".pvr.ccz"
------------------------------------------------------------------

--! @module graphicLoader
graphicLoader = {}
function graphicLoader.clearAllRes()
	frameCache:removeSpriteFrames()
	textureCache:removeAllTextures()
	_animaOrigDelayLook = {}
	_animaContext = {}
	_animaCache={}
	CCAnimationCache:purgeSharedAnimationCache()
end
function graphicLoader.loadFrame(filename,path)--{{{
	if not path then path = kResSpritePath end
	if not textureCache:textureForKey(path..filename..pvrccz) then
		frameCache:addSpriteFramesWithFile(path..filename..plist,path..filename..pvrccz)
	end
end--}}}
--======================================================
--���ػ���ͼƬ�Ͷ�����Դ��Դ,logo����
--======================================================
function graphicLoader.loadBasicFrame()
	for key,val in ipairs(kBasicImgList) do
		if key < #kBasicImgList then
			graphicLoader.loadFrame(val)
		else
			graphicLoader.loadFrame(val,kResHeroPath)
		end
		coroutine.yield()
	end
	for key,val in ipairs(kMapRes) do
		graphicLoader.loadFrame(val,kResMapPath)
		coroutine.yield()
	end
	for key,val in ipairs(kBasicAnimaList) do
		CCAnimationCache:sharedAnimationCache():removeAnimationByName(val)
		CCAnimationCache:sharedAnimationCache():addAnimationsWithFile(kResAnimaPath..val..plist)
		coroutine.yield()
	end
	graphicLoader.loadFaceAnima()
	
end
function graphicLoader.loadMonsterCardFrame()
	for key,val in ipairs(kMonsterCardList) do
		graphicLoader.loadFrame(val)
		coroutine.yield()
	end
end
function graphicLoader.removeMonsterCardFrame()
	for key,val in ipairs(kMonsterCardList) do
		frameCache:removeSpriteFramesFromFile(kResSpritePath..val..plist)
		textureCache:removeTextureForKey(kResSpritePath..val..pvrccz)
	end
end
--����Ӣ����Դ
function graphicLoader.loadHeroFrame(heroid,lv)
	local creature_cfg = assert(hero_data.getConfig(heroid))
	local creature_data = assert(hero_data.get(heroid,lv))
	local graphicName = creature_cfg.graphList[creature_data.graphLV]
	graphicLoader.loadFrame(graphicName)
	creature_cfg = nil
	creature_data = nil
end
--����Ӣ�۶�����Դ
function graphicLoader.loadHeroAnima(heroid,lv,withEffect,needCache)
	local creature_cfg = assert(hero_data.getConfig(heroid))
	local creature_data = assert(hero_data.get(heroid, lv))
	local graphicName = creature_cfg.graphList[creature_data.graphLV]
	creature_cfg = nil
	creature_data = nil
	graphicLoader.loadFrame(graphicName)
	graphicLoader.getAnimaCfg(animaBattleUnit[graphicName],graphicName) --���ض���
	if needCache then _animaCache[graphicName] = 1 end
	if withEffect then
		if SoundHelper.isEffectOn() then addUnitSoundEffect(graphicName) end
		for key,effectName in ipairs(animaEffectUnit[graphicName]) do
			graphicLoader.loadFrame(effectName)
			graphicLoader.getAnimaCfg(animaBattleUnit[effectName],effectName)--������Ч
		end
	end
end
--���ع�����Դ
function graphicLoader.loadMonsterFrame(monsterid,lv)
	local creature_cfg = assert(monster_data.getConfig(monsterid))
	local creature_data = assert(monster_data.get(monsterid, lv))
	local graphicName = creature_cfg.graphList[creature_data.graphLV]
	graphicLoader.loadFrame(graphicName)
	creature_cfg = nil
	creature_data = nil
end
--���ع��ﶯ����Դ
function graphicLoader.loadMonsterAnima(monsterid,lv,withEffect)
	local creature_cfg = assert(monster_data.getConfig(monsterid))
	local creature_data = assert(monster_data.get(monsterid, lv))
	local graphicName = creature_cfg.graphList[creature_data.graphLV]
	creature_cfg = nil
	creature_data = nil
	graphicLoader.loadFrame(graphicName)
	graphicLoader.getAnimaCfg(animaBattleUnit[graphicName],graphicName) --���ض���
	if withEffect then
		if SoundHelper.isEffectOn() then addUnitSoundEffect(graphicName) end
		for key,effectName in ipairs(animaEffectUnit[graphicName]) do
			graphicLoader.loadFrame(effectName)
			graphicLoader.getAnimaCfg(animaBattleUnit[effectName],effectName)--������Ч
		end
	end
end
--�Ƴ����鶯��
function graphicLoader.removeCreatureAnima(clearCache)
	if not _animaContext then return end
	for graphicName,item in pairs(_animaContext) do
		if (not _animaCache[graphicName] and not clearCache) or clearCache then 
			for actionId,animainfo in pairs(item) do
				for key,val in pairs(animainfo) do
					if type(key) =="number" and type(val) == "string" then
						CCAnimationCache:sharedAnimationCache():removeAnimationByName(val)
					end
				end
				_animaContext[graphicName][actionId] = nil
			end
			_animaContext[graphicName] = nil
			removeUnitSoundEffect(graphicName)
			frameCache:removeSpriteFramesFromFile(kResSpritePath..graphicName..plist)
			textureCache:removeTextureForKey(kResSpritePath..graphicName..pvrccz)
		else
			removeUnitSoundEffect(graphicName)
		end
	end
	--textureCache:dumpCachedTextureInfo()
end
--���ر��鶯��
function graphicLoader.loadFaceAnima()
	local animaCache = CCAnimationCache:sharedAnimationCache()
	for animaName,animaCfg in pairs(faceAnimaList) do
		graphicLoader.loadFrame(animaName)
		coroutine.yield()
		local anima = CCAnimation:create()
		anima:setDelayPerUnit(animaCfg.delay)
		for idx = 1,animaCfg.frames do
			local frameName = string.format('%s_%02d.png', animaName,idx)
			local frame = assert(graphicLoader.getFrame(frameName), 'can not find frame with name: ' .. frameName)
			anima:addSpriteFrame(frame)
		end
		animaCache:removeAnimationByName(animaName)
		animaCache:addAnimation(anima, animaName)
		_animaOrigDelayLook[animaName] = animaCfg.delay
		coroutine.yield()
	end
end
function graphicLoader.getAnimaCfg(anima_cfg,graphicName)
	if _animaContext[graphicName] then return end
	_animaContext[graphicName] = {}
	for actionID,action_cfg in pairs(anima_cfg) do
		if not	_animaContext[graphicName][actionID] then
			_animaContext[graphicName][actionID] ={f = action_cfg.frames,d = action_cfg.delay,s = action_cfg.frames*action_cfg.delay,ms = action_cfg.frames*action_cfg.delay*1000}
			for dir=1,4 do
				local animaName = string.format('%s_%02d%02d', graphicName, actionID, dir)
				if not CCAnimationCache:sharedAnimationCache():animationByName(animaName) then
					local anima = CCAnimation:create()
					anima:setDelayPerUnit(action_cfg.delay)
					for idx=1, action_cfg.frames do
						local frameName = string.format('%s_%02d%02d%02d.png', graphicName, actionID, dir, idx)
						local frame = assert(graphicLoader.getFrame(frameName), 'can not find frame with name: ' .. frameName)
						anima:addSpriteFrame(frame)
					end
					 CCAnimationCache:sharedAnimationCache():addAnimation(anima, animaName)
					_animaOrigDelayLook[animaName] = action_cfg.delay
					_animaContext[graphicName][actionID][(dir-1)*90] = animaName
				end
			end
		end
	end
end
function graphicLoader.getFrame(frameName)--{{{
    local frame = frameCache:spriteFrameByName(frameName)
    if frame == nil then
        print("Can not find frame " ..frameName)
		return nil
    end
    return frame
end--}}}

function graphicLoader.getAnimation(animaName)--{{{
    local anima =  CCAnimationCache:sharedAnimationCache():animationByName(animaName)
    if not anima then
        print("Can not find animation " .. animaName)
        assert(nil,"")
    end
    return anima
end--}}}

function graphicLoader.animaName(prefix, action, dir) --dir is in degree
	--print(prefix,action,dir)
    return _animaContext[prefix][action][dir or 90]
end

function graphicLoader.animaFrames(prefix, action)
    return _animaContext[prefix][action].f
end

function graphicLoader.animaDelay(prefix, action)
    return _animaContext[prefix][action].d
end

function graphicLoader.animaDurS(prefix, action)
    return _animaContext[prefix][action].s
end

function graphicLoader.animaDurMS(prefix, action)
    return _animaContext[prefix][action].ms
end

function graphicLoader.getOrigUnitDelay(animaName)--{{{
    return _animaOrigDelayLook[animaName] or 0
end--}}}




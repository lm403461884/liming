--region sdkhelper.lua
--Author : Yanlee
--Date   : 2014/12/1
--anysdk 接入辅助
require "anysdkConst"
local appKey = "1C80A50D-69CA-9681-8373-A0F1DCAA3225"
local appSecret = "cfa40fb55178a8d3d1f22660f87cc491"
local privateKey = "94784BF78137AD323A570C8E2AE8FE7A"
local oauthLoginServer = "http://oauth.anysdk.com/api/OauthLoginDemo/Login.php"
local loginHander = {}
local function openLogoScene()
    AccountHelper:reLoadGame()
end
local function openNetScene()
    HOAux:openNetSetting()
    AccountHelper:reLoadGame()
end
loginHander[UserActionResultCode.kInitSuccess]=function(pPlugin,msg)   
	print("kInitSuccess ",msg)
end
loginHander[UserActionResultCode.kInitFail]=function(pPlugin,msg)
	print("kInitFail ",msg)
    MsgLayer.new(nil,"Init Failed",1,openLogoScene):show()
end
loginHander[UserActionResultCode.kLoginSuccess]=function(pPlugin,msg)
	print("kLoginSuccess ",msg)
    SDKHelper:setAuthorized()
end
loginHander[UserActionResultCode.kLoginNetworkError]=function(pPlugin,msg)
	print("kLoginNetworkError ",msg)
    MsgLayer.new(nil,TxtList.netOff,1,openNetScene)
end
loginHander[UserActionResultCode.kLoginNoNeed]=function(pPlugin,msg)
	print("kLoginNoNeed ",msg)
    loginHander[UserActionResultCode.kLoginSuccess](pPlugin,msg)
end
loginHander[UserActionResultCode.kLoginFail]=function(pPlugin,msg)
    print("kLoginFail ",msg)
	SDKHelper:login()--重新登陆
end
loginHander[UserActionResultCode.kLoginCancel]=function(pPlugin,msg)
    print("kLoginCancel ",msg)
	SDKHelper:login()--重新登陆
end
loginHander[UserActionResultCode.kLogoutSuccess]=function(pPlugin,msg)
     print("kLogoutSuccess ",msg)
end
loginHander[UserActionResultCode.kLogoutFail]=function(pPlugin,msg)
    print("kLogoutFail ",msg)
end
loginHander[UserActionResultCode.kPlatformEnter]=function(pPlugin,msg)
    print("kPlatformEnter ",msg)
end
loginHander[UserActionResultCode.kPlatformBack]=function(pPlugin,msg)
    print("kPlatformBack ",msg)
end
loginHander[UserActionResultCode.kPausePage]=function(pPlugin,msg)
     print("kPausePage ",msg)
end
loginHander[UserActionResultCode.kExitPage]=function(pPlugin,msg)
     print("kExitPage ",msg)
end
loginHander[UserActionResultCode.kAntiAddictionQuery]=function(pPlugin,msg)
    print("kAntiAddictionQuery ",msg)
end
loginHander[UserActionResultCode.kRealNameRegister]=function(pPlugin,msg)
     print("kRealNameRegister ",msg)
end
loginHander[UserActionResultCode.kAccountSwitchSuccess]=function(pPlugin,msg)
     print("kAccountSwitchSuccess ",msg)
end
loginHander[UserActionResultCode.kAccountSwitchFail]=function(pPlugin,msg)
    print("kAccountSwitchFail ",msg)
end
SDKHelper={}
function SDKHelper:init()
	if CCApplication:sharedApplication():getTargetPlatform() == kTargetAndroid then
		self._agent = AgentManager:getInstance()
		self._agent:init(appKey,appSecret,privateKey,oauthLoginServer)
		self._agent:loadALLPlugin()
		self._user = self._agent:getUserPlugin() 
		self._iap = self._agent:getIAPPlugin()
		self._share = self._agent:getSharePlugin()
		self._ads = self._agent:getAdsPlugin()
		self._social = self._agent:getSocialPlugin()
		self._push = self._agent:getPushPlugin()
		self._analytics = self._agent:getAnalyticsPlugin()
		self._channelId = self._agent:getChannelId()
		if not self._logCnt then
			self._logCnt = true
			self._analytics:startSession()
		end
		self:activeLogListener()
	end
end
function SDKHelper:destory()
	if CCApplication:sharedApplication():getTargetPlatform() == kTargetAndroid then
		self._analytics:stopSession()
		self._agent:unloadALLPlugin();
		self._logCnt = nil
	end
end
function SDKHelper:getAgent()
    return  self._agent
end
--用户系统
function SDKHelper:getUserPlugin()
    return  self._user
end
--支付系统
function SDKHelper.getIAPPlugin()
    return   self._iap
end
--分享系统
function SDKHelper:getSharePlugin()
    return   self._share
end
--广告系统
function SDKHelper.getAdsPlugin()
    return   self._ads
end
--社交系统
function SDKHelper:getSocialPlugin()
    return  self._social  
end
--推送系统
function SDKHelper:getPushPlugin()
    return  self._push  
end
--统计系统
function SDKHelper:getAnalyticsPlugin()
    return  self._analytics
end
--获取渠道ID
function SDKHelper:getChannelID()
     return  self._channelId
end
function SDKHelper:getUserId()
    return self._userid
end
------------------------------------
------------------------------------
--统计玩家帐户信息
function SDKHelper:setAccount(acct,optype)
    if self._analytics and self._analytics:isFunctionSupported("setAccount") then
        local paramMap = {
            Account_Id = acct.user,
            Account_Name = acct.nickName,
            Account_Type = string.format( acct.acctType or AccountType.ANONYMOUS),
            Account_Level = string.format(acct.digLv),
            Account_Age = string.format(acct.age or 1),
            Account_Operate = string.format(optype or AccountOperate.LOGIN),
            Account_Gender = string.format(acct.gender or AccountGender.UNKNOWN),
            Server_Id = "1"
        }
        local data = PluginParam:create(paramMap)
        self._analytics:callFuncWithParam("setAccount",data)
    end
end
function SDKHelper:login()
    self._userid = nil
	self._adkAuthorized = nil
    if self._user:isLogined() then
        self:setAuthorized()
    else
        if ( self._user:isFunctionSupported("login") ) then
             self._user:callFuncWithParam("login")
        end
    end
end
function SDKHelper:setAuthorized()
	self._userid = self._user:getUserID()
	self._adkAuthorized = true
	--触发SDK登陆成功事件
    postEventSignal(kEventSDKAuthorized)
end
function SDKHelper:isSDKAuthorized()
	return self._adkAuthorized
end
--绑定用户系统相关事件
function SDKHelper:activeLogListener()
    local function onActionListener( pPlugin, code, msg )
       loginHander[code](pPlugin,msg)
   end
   self._user:setActionListener(onActionListener)
end
--endregion

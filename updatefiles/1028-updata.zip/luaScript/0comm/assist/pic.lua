Pic={}
--��ȡ��ͨ����ͼƬ��Դ����
function Pic.getBlock(area,deep)
	
	local imgs = BlockImages[area][deep]
	if not imgs then print(string.format("can not find imgs with area %d and deep %d",area,deep)) return end
	local img = imgs[math.random(#imgs)]
	return img
end
--��ȡ���鶯��
function Pic.getBlockAnima(srcid)
	local animaName = BlockAnimas[srcid]
	if not animaName then print(string.format("can not find anima %s from BlockAnimas",animaName)) end
	return animaName
end
--��ȡ������������
function Pic.getMineAnima(mtype,lv)
	--if lv == 0 then lv = 1 end
	return string.format("anima_mine_%02d%02d",1,1)
end
--��ȡ�������Ѷ�����һ��ͼ
function Pic.getBrokenBlock()
	return "anima_block_010101.png"
end

--��ȡ�յ�ͼƬ��Դ����
function Pic.getBlank(area,sur)
	area = 1
    return string.format("pic_block_%02d00%d.png",area,sur)
end

--��ȡ��ҰͼƬ��Դ����
function Pic.getView(num)
	return string.format("pic_view_%02d.png",num)
end
--��ȡ����ͼƬ��Դ����
function Pic.getMineral(mtype,areaid,deep,lv)
	--do return "pic_oil_0501.png" end
	if lv == 0 then lv = 1 end
	local mineImgs = mileImages[mtype]
	if not mineImgs then print("can not fine mineImags with mtype:",mtype) return end
	local areaImgs = mineImgs[areaid]
	if not areaImgs then print(string.format("can not find mine images for areaid %d",areaid)) return end
	local deepImgs = areaImgs[deep]
	if not deepImgs then print(string.format("can not find mine images for deep %d",deep)) return end
	local img = deepImgs[lv]
	if not img then print(string.format("can not find mine images for lv %d",lv)) return end 
	return img
end


--��ȡ������Դ����ͼƬ
function Pic.getNutrient(mtype)
	return string.format("pic_nutrient_%02d.png",  mtype)
end
--��ȡ����ͼƬ
function Pic.getCoin(coin)
	return coin..".png"
end

--��ȡӢ��ͼƬ
function Pic.getHero(mtype,lv,act,dir,idx)
	local orient = dir/90 + 1
	return string.format("pic_hero_%02d%02d%02d%d%02d",mtype,lv,act,orient,idx)
end

--��ȡ����ͼƬ
function Pic.getMonster(mtype,lv,act,dir,idx)
	local orient = dir/90 + 1
	return string.format("pic_monster_%02d%02d%02d%d%02d",mtype,lv,act,orient,idx)
end

--��ȡӢ�۶���
function Pic.getHeroAnima(mtype,lv,act,dir)
	local orient = dir/90 + 1
	return string.format("anima_hero_%02d%02d%02d%d",mtype,lv,act,orient)
end

--��ȡ���ﶯ��
function Pic.getMonsterAnima(mtype,lv,act,dir)
	local orient = dir/90 + 1
	return string.format("anima_monster_%02d%02d%02d%d",mtype,lv,act,orient)
end

--��ȡ����Ѫ��ͼƬ��Դ
function Pic.getBlood()
	local pic_fore = "GUIRes/image/comm/pic_hp_fore.png"
	local pic_bg = "GUIRes/image/comm/pic_hp_bg.png"
	local pic_thumb = "GUIRes/image/comm/pic_hp_thumb.png"
	return pic_bg,pic_fore,pic_thumb
end






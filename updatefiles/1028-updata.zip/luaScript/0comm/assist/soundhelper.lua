SoundHelper = {}
local BGM = nil
local kKeyOfBGM = "S_BGM_STATE_OFF"
local kKeyOfEffect = "S_EFFECT_STATE_OFF"
local m_BGM_off = CCUserDefault:sharedUserDefault():getBoolForKey(kKeyOfBGM)
local m_Effect_off = CCUserDefault:sharedUserDefault():getBoolForKey(kKeyOfEffect)
function SoundHelper.playBGM(filename)
	if (not m_BGM_off) and  BGM ~= filename then
		BGM = filename
		AudioEngine.playMusic(BGM, true)
		--print("BGM switch to "..filename)
	end
end
function SoundHelper.playBGMOnce(filename)
    if (not m_BGM_off) and  BGM ~= filename then
        BGM = filename
        AudioEngine.playMusic(BGM, false)
        --print("BGM switch to "..filename)
    end
end
function SoundHelper.stopBGM()
	BGM = nil
	AudioEngine.stopMusic()
end
function SoundHelper.playEffect(filename)
	if not m_Effect_off then
		AudioEngine.playEffect(filename, false)
	end
    --print("Effect played  "..filename)
end
function SoundHelper.preLoadEffect(filename)
    AudioEngine.preloadEffect(filename)
end
function SoundHelper.unloadEffect(filename)
	AudioEngine.unloadEffect(filename)
end
--是否开启背景音乐
function SoundHelper.isBGMOn()
	return not m_BGM_off
end
--是否开启音效
function SoundHelper.isEffectOn()
	return not m_Effect_off
end
--打开背景音乐
function SoundHelper.turnOnBGM(filename,playOnce)
	if filename then
		BGM = filename
		if not playOnce then 
			AudioEngine.playMusic(BGM, true)
		else
			AudioEngine.playMusic(BGM, false)
		end
	end
	m_BGM_off = false
	CCUserDefault:sharedUserDefault():setBoolForKey(kKeyOfBGM,m_BGM_off)
end
--关闭背景音乐
function SoundHelper.turnOffBGM()
	BGM = nil
	AudioEngine.stopMusic()
	m_BGM_off = true
	CCUserDefault:sharedUserDefault():setBoolForKey(kKeyOfBGM,m_BGM_off)
end
--开关背景音效
function SoundHelper.turnOffEffect(turnoff)
	if not turnoff then turnoff = false end
	m_Effect_off = turnoff
	CCUserDefault:sharedUserDefault():setBoolForKey(kKeyOfEffect,turnoff)
end
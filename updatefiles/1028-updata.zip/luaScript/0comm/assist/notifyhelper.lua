
NotifyCode={}
NotifyCode.actPtFull = 1
NotifyCode.teamReturn = 2

local m_NotifyMessage={
	[1] = "您的体力值回复满了！",
	[2] = "您的冒险队回归了！",
}
local m_NotifyStateKey = 
{
	[1] = "S_ACTPT_NOTIFY_OFF",
	[2] ="S_TEAMRETURN_NOTIFY_OFF",
}
local m_NotifyStateVal = {
	[1] = CCUserDefault:sharedUserDefault():getBoolForKey(m_NotifyStateKey[1]),
	[2] = CCUserDefault:sharedUserDefault():getBoolForKey(m_NotifyStateKey[2]),
}
--添加本地定时推送信息
local function f_show(msg,interval,tag)
	HOAux:showLocalNotification(msg,"HO",interval,tag)
end
--取消本地定时推送信息
local function f_cancel(tag)
	HOAux:cancelLocalNotification(tag)
end
--添加体力值满消息推送
local _innerNotifySender={}
--行动力
_innerNotifySender[1] = function(acct)
	if m_NotifyStateVal[1] then return end
	baseCalc.resetActPt(acct,os.time()-1)
	if acct.actPt >= acct.maxActPt then 
		f_cancel(1)
	else
		local totalSec = math.ceil((acct.maxActPt - acct.actPt)/numDef.valAP)*numDef.durAP
		f_show(m_NotifyMessage[1],totalSec,1)
	end
end
--自己探险队回归
_innerNotifySender[2]=function(acct)
	if m_NotifyStateVal[2] then return end
	 for heroid,item in pairs(acct.cbTeam) do
		if item.tid == acct.guid then
			local totalSec = item.ed - os.time()
			if totalSec > 0 then f_show(m_NotifyMessage[2],totalSec,2) end
			return
		end
	 end
end
NotifyHelper={}

--关闭指定类型的消息推送
function NotifyHelper.turnOff(tag)
	m_NotifyStateVal[tag] = true
	CCUserDefault:sharedUserDefault():setBoolForKey(m_NotifyStateKey[tag],true)
	f_cancel(tag)
end
--开启指定类型的消息推送
function NotifyHelper.turnOn(tag)
	m_NotifyStateVal[tag] = false
	CCUserDefault:sharedUserDefault():setBoolForKey(m_NotifyStateKey[tag],false)
	_innerNotifySender[tag](account_data)
end
--添加所有本地消息推送
function NotifyHelper.showAll()
	for key,tag in pairs(NotifyCode) do
		f_cancel(tag)
		_innerNotifySender[tag](account_data)
	end
end
--发送指定类型的消息推送
function NotifyHelper.show(tag)
	_innerNotifySender[tag](account_data)
end
--消息推送状态
function NotifyHelper.isTurnOn(tag)
	return not m_NotifyStateVal[tag]
end
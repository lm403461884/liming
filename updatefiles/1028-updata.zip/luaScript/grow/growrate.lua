local kPanelLayer = "grow_panel"
local kImgItem = "img_item"
local kLblName = "lbl_name"
local kLblHP="lbl_hp"
local kLblLV = "lbl_lv"
local kLblATK ="lbl_atk"
local kLblHPNew="lbl_hp_new"
local kLblLVNew = "lbl_lv_new"
local kLblATKNew ="lbl_atk_new"

local kLblTime = "lbl_left"
local kBarTime = "bar_cd"
local kLblResult = "lbl_result"

local kPanelNote = "info_panel"
local kPanelGrow = "train_panel"

--��ť
local kBtnBack = "btn_back"
local kTypeHero = 1
local kTime = 2
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local __growrate={}
function __growrate.init(obj,heroid)  
   obj._id = heroid
   obj._utype= kTypeHero
   obj._touchEnabled = false
   local herodata = account_data.heroList[obj._id]
   obj._lv = herodata.lv
   herodata.lv = herodata.lv + 1
   obj._s_cfg = hero_data[obj._id]
   obj._name = obj._s_cfg.heroName
   graphicLoader.loadHeroAnima(obj._id, obj._lv)
   obj:initItem()
   obj:egHideWidget(kBtnBack)
   
   obj:showWithAction()
end
--������ʾ����
function __growrate.initItem(obj)
    obj:egHideWidget(kPanelNote)
   
    local curData = obj._s_cfg[obj._lv]
    local newData = obj._s_cfg[obj._lv+1]
    obj._curData = curData
    if newData then
        obj:egSetLabelStr(kLblLVNew,string.format("%s%d", obj:egGetLabelStr(kLblLVNew),obj._lv+1))
        obj:egSetLabelStr(kLblHPNew,string.format("%s%d", obj:egGetLabelStr(kLblHPNew),newData.maxHP))
        obj:egSetLabelStr(kLblATKNew,string.format("%s%d", obj:egGetLabelStr(kLblATKNew),newData.power))
    else
        obj:egHideWidget(kLblHPNew)
        obj:egHideWidget(kLblLVNew) 
        obj:egHideWidget(kLblATKNew)    
    end
    obj:egSetLabelStr(kLblLV,string.format("%s%d", TxtList.charLv,obj._lv))
    obj:egSetLabelStr(kLblHP,string.format("%s%d", TxtList.charHP,curData.maxHP))
    obj:egSetLabelStr(kLblATK,string.format("%s%d", TxtList.charATK,curData.power))
    obj:egSetLabelStr(kLblName,obj._name)
    obj:activeItemAction()
end
function __growrate.bindTrainTimer(obj)
	local left = kTime
	obj:egSetLabelStr(kLblTime,Funs.formatTimeCh(left,true,true,true,true,true) )
	obj:egSetBarPercent(kBarTime,0)
	local function update(delta)
		left = left - delta
		if left <= 0 then
			obj:egUnbindWidgetUpdate(kLblTime)
			obj:showGrowFinished()
		else
			obj:egSetLabelStr(kLblTime,Funs.formatTimeCh(math.ceil(left),true,true,true,true,true) )
			obj:egSetBarPercent(kBarTime,math.floor((1-left/kTime)*100))
		end
	end
	obj:egBindWidgetUpdate(kLblTime,update)
end
function __growrate.activeItemAction(obj)
    local widget = obj:egGetWidgetByName(kImgItem)
    local sprite = tolua.cast(widget:getVirtualRenderer(),"CCSprite") 
    local graphName = obj._s_cfg.graphList[ obj._curData.graphLV]
    local img = string.format('%s_020201.png',graphName)
    obj:egChangeImg(kImgItem,img,UI_TEX_TYPE_PLIST)
    local animaName= string.format('%s_%02d%02d', graphName, 10, 1)
    local anima = graphicLoader.getAnimation(animaName)
    local orgUnitDelay = graphicLoader.getOrigUnitDelay(animaName)
    anima:setRestoreOriginalFrame(true)
    anima:setDelayPerUnit((1 / (rate or 1)) * orgUnitDelay)
    local animate = CCAnimate:create(anima)
    local action = CCRepeat:create(animate, 1000)
    sprite:runAction(action)
end
function __growrate.disActiveItemAction(obj)
    local widget = obj:egGetWidgetByName(kImgItem)
    local sprite = tolua.cast(widget:getVirtualRenderer(),"CCSprite") 
    local graphName = obj._s_cfg.graphList[ obj._curData.graphLV]
    local img = string.format('%s_020201.png',graphName)
    sprite:stopAllActions()
    obj:egChangeImg(kImgItem,img,UI_TEX_TYPE_PLIST)
end
function __growrate.hideWithAction(obj,callbackfunc)
    local function callback()
            AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __growrate.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
function __growrate.doClickBack(obj,sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
        obj:hideWithAction()
        local growlayer = AccountHelper:get(kGrowLayer)
        if growlayer then
            showGrowInfo(obj._id,obj._lv)
        end
end
--�رձ�ҳ��
function __growrate.bindBackListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickBack(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
--�رձ�ҳ��
function __growrate.bindCloseListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._touchEnabled then
			obj:doClickBack(sender)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end
function __growrate.showGrowFinished(obj)
    obj:disActiveItemAction()
    obj._lv = obj._lv + 1
    local curData = obj._s_cfg[obj._lv]
    obj:egSetLabelStr(kLblLV,string.format("%s%d", TxtList.charLv,obj._lv))
    obj:egSetLabelStr(kLblHP,string.format("%s%d", TxtList.charHP,curData.maxHP))
    obj:egSetLabelStr(kLblATK,string.format("%s%d", TxtList.charATK,curData.power))
    obj:egSetLabelStr(kLblResult,string.format("%s:LV%d",TxtList.trainFinished,obj._lv))
    --obj:egShowWidget(kBtnBack)
    obj._touchEnabled = true
    obj:egShowWidget(kPanelNote)
    obj:egHideWidget(kPanelGrow)
    obj:egHideWidget(kLblHPNew)
    obj:egHideWidget(kLblLVNew)
    obj:egHideWidget(kLblATKNew)
end

GrowRate={}
function GrowRate.new(heroid,onloaded)
    local obj = TouchWidget.new(JsonList.growRate)
    table_aux.unpackTo(__growrate, obj)
    obj._onloaded = onloaded
    obj:init(heroid)
	obj:bindTrainTimer()
    obj:bindBackListener()
	obj:bindCloseListener()
    return obj
end
function showGrowRate(heroid,onloaded)
    local layer = GrowRate.new(heroid,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

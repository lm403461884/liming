local kBtnBack = "btn_back"
local kImgBack = "img_back"
local __growbg = {}
function __growbg.init(obj)
end
--���ذ����¼�
function __growbg.bindBackListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBack,1.1)
    end
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_back_button)
		obj:egSetWidgetScale(kImgBack,1)
       sender:setTouchEnabled(false)
	   if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
	   local totalBp = RiskHelper.getTotalBp()
		if account_data.teamBp ~= totalBp then
			account_data.teamBp = totalBp
			SendMsg[934018](totalBp)
		end
       local scene = TownScene.new()
	   scene:egReplace()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBack,1)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
GrowBg={}
function GrowBg.new()
    local obj = TouchWidget.new(JsonList.growBg)
    table_aux.unpackTo(__growbg, obj)
    obj:init()
    obj:bindBackListener()
    return obj
end
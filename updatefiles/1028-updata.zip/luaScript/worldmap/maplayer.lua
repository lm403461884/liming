local kBtnBack = "btn_back"
local kPanelTouch = "map_touch_panel"
local kPanelLbl = "num_panel"
local kPanelShow = "panel_show"
local kImgArrowLeft = "img_arrow_left"
local kImgArrowRight = "img_arrow_right"
local kPanelTouchLeft = "panel_touch_left"
local kMapImgLeft = "img_map_left"

local kYellowColor = ccc3(255,255,0)
local kBrownColor = ccc3(63,38,38)
local kNeedLv = 8
--local kWhiteColor = ccc3(255,255,255)
local __maplayer={}
local function __getUncompletedStageCount(areaid,pveArea)--{{{
	local nmData = MissionHelper.getNormalMission(areaid)
	local dmData = MissionHelper.getResMission(areaid)
	local cnt = 0
	for key,stageid in ipairs(nmData) do
		local stageinfo = pveArea[stageid]
		if  stageinfo and stageinfo.stars == 0 then
			cnt = cnt + 1
		end
	end
	for key,stageid in ipairs(dmData) do
		local stageinfo = pveArea[stageid]
		if stageinfo and stageinfo.stars == 0 then
			cnt = cnt + 1
		end
	end
	return cnt
end--}}}
function __maplayer.init(obj)
    obj._touchAreaID = 0
    obj._areaSprites = {}
    if account_data.digLv>kNeedLv then
        local mapLeft = {}
        CocosWidget.install(mapLeft,JsonList.mapLeftLayer)
        mapLeft:egNode():setPosition(ccp(-1245,0))
        obj:egGetWidgetByName(kPanelShow):addChild(mapLeft:egNode(),2,2)
        
        obj:egShowWidget(kPanelTouchLeft)
        obj:egShowWidget(kImgArrowLeft)
        obj:fadeWidget(obj:egGetWidgetByName(kImgArrowLeft))
        obj:egHideWidget(kImgArrowRight)
        obj:bindTouchLeftListener()
        obj:egSetWidgetTouchEnabled(kPanelTouchLeft,false)
        
        local imgWidget = obj:egGetWidgetByName(kMapImgLeft)
        local sprite =  tolua.cast(imgWidget:getVirtualRenderer(),"CCSprite")
        sprite:getTexture():setAliasTexParameters()
    end
	--����PVE��� ���������ͼ
	for areaID, area in pairs(account_data.unlockedPVE) do
		--����ѽ�������Ľ��沼��
		if area[1] then
		    local widgetName = 'touch_area_'..areaID
		    local img = tolua.cast(obj:egGetWidgetByName(widgetName),"ImageView")
		    local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
		    obj._areaSprites[areaID] = sprite
			--�޳���������
			local maskCtrl = obj:egGetWidgetByName('mask_'..areaID)
			maskCtrl:runAction(CCFadeOut:create(1))
			obj:showMissionNum(areaID,area)
		end
	end
end
--��ʾ����δ������۵Ĺؿ���
function __maplayer.showMissionNum(obj,areaID,area)
	--��ʾ��ǰ����δ��������ǵĹؿ�����
	local cnt = __getUncompletedStageCount(areaID,area)
	if cnt > 0 then
		local text = Label:create()
		text:setText(tonumber(cnt))
		text:setFontName(FNList.STENCIL)
		text:setFontSize(30)
		text:setColor(kBrownColor)
		local labelCtrl = obj:egGetWidgetByName('label_'..areaID)
		if areaID == licenceLevelup[account_data.digLv].areaID then
		    labelCtrl:setColor(kYellowColor) 
		   -- text:setColor(kWhiteColor)
		--else
		   --s text:setColor(kBrownColor)
		end
		local x = labelCtrl:getPositionX()
		local y = labelCtrl:getPositionY()
		if areaID> 8 then
		    text:setPosition(ccp(x+3-1244,y))
		else
		    text:setPosition(ccp(x+3,y))
		end    
		obj:egAddChildTo(kPanelLbl,text)   
		labelCtrl:setVisible(true)
		labelCtrl:runAction(CCFadeIn:create(1.5))
		text:runAction(CCFadeIn:create(1.5))
		local scaleAction1 = CCRepeatForever:create(CCSequence:createWithTwoActions(CCScaleTo:create(0.8, 0.8), CCScaleTo:create(0.8, 0.73)))
		local scaleAction2 = CCRepeatForever:create(CCSequence:createWithTwoActions(CCScaleTo:create(0.8, 0.8), CCScaleTo:create(0.8, 0.73)))
		labelCtrl:runAction(scaleAction1)
		text:runAction(scaleAction2)
	end
end
--��ȡ��ǰ���������ID,�޵������ʱ����0
function __maplayer.getTouchedAreaID(obj,pos)
    for areaid,sprite in pairs(obj._areaSprites) do
        local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
        if not isalpha then
            return areaid
        end
	end
	return 0
end
function __maplayer.fadeWidget(obj,widget)
	local scaleto1 = CCFadeTo:create(1,100)
	local scaleto2 = CCFadeTo:create(1,200)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end
--��ͼ�����������¼�
function __maplayer.bindTouchListener(obj)
    local beginPos = nil
    local moved = false
    local panelShow = obj:egGetWidgetByName(kPanelShow)
    local posx,posy = panelShow:getPosition()
    local function touchBegan(sender)
		--sender:setTouchEnabled(false)
		obj:egSetWidgetTouchEnabled(kPanelTouch,false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		local pos =sender:getTouchStartPos()
		beginPos = pos
		moved = false
		obj._touchAreaID = obj:getTouchedAreaID(pos)
		if obj._touchAreaID > 0 then
		    obj._areaSprites[obj._touchAreaID]:setScale(1.05)
		end
    end
    local function touchMoved(sender)
        local movePos = sender:getTouchMovePos()
        if account_data.digLv>kNeedLv and movePos.x - beginPos.x>5 then
            if movePos.x - beginPos.x<1244 then
                local cell = movePos.x-beginPos.x
                panelShow:setPosition(ccp(posx+cell,posy))
                moved = true
            end   
        else
            panelShow:setPosition(ccp(posx,posy))
            moved = false
        end 
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if moved then 
		    local function callback() obj:egSetWidgetTouchEnabled(kPanelTouchLeft,true) end
		    local callFunc = CCCallFunc:create(callback)
		    local move = CCMoveTo:create(0.5,ccp(1244,0))
		    local sequece = CCSequence:createWithTwoActions(move,callFunc)
		    panelShow:runAction(sequece)
		    obj:egHideWidget(kImgArrowLeft)
		    obj:egGetWidgetByName(kImgArrowLeft):stopAllActions()
		    obj:egShowWidget(kImgArrowRight)
		    obj:fadeWidget(obj:egGetWidgetByName(kImgArrowRight))
		    if obj._touchAreaID > 0 then
                obj._areaSprites[obj._touchAreaID]:setScale(1)
            end  
		else
		    if obj._touchAreaID > 0 then
                local scaleto = CCScaleTo:create(0.3, 1.2)
                local fadeout = CCFadeOut:create(0.3)
                local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
                local transcation = CCSequence:createWithTwoActions(
                                spawn,
                                CCCallFunc:create(function()
                                    sender:setTouchEnabled(true)
                                    local scene = MissionScene.new(obj._touchAreaID)
                                    scene:egReplace()
                                    obj._touchAreaID = 0
                                end))
                local sprite = obj._areaSprites[obj._touchAreaID]
                sprite:runAction(transcation)
            else
                sender:setTouchEnabled(true)
		    end
		end    
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			if obj._touchAreaID > 0 then
				obj._areaSprites[obj._touchAreaID]:setScale(1)
			end
			obj._touchAreaID = 0
		end
    end
    obj:egBindTouch(kPanelTouch,touchBegan,touchMoved,touchEnded,touchCanceled)
end
function __maplayer.bindTouchLeftListener(obj)
    local beginPos = nil
    local moved = false
    local panelShow = nil
    local posx,posy = nil
    local function touchBegan(sender)
		--sender:setTouchEnabled(false)
		obj:egSetWidgetTouchEnabled(kPanelTouchLeft,false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		local pos =sender:getTouchStartPos()
		beginPos = pos
		moved=false
		obj._touchAreaID = obj:getTouchedAreaID(pos)
		if obj._touchAreaID > 0 then
		    obj._areaSprites[obj._touchAreaID]:setScale(1.05)
		end
		panelShow = obj:egGetWidgetByName(kPanelShow)
        posx,posy = panelShow:getPosition()
    end
    local function touchMoved(sender)
        local movePos = sender:getTouchMovePos()
        if beginPos.x - movePos.x>5 then
            if beginPos.x - movePos.x < 1244 then
                local cell = movePos.x-beginPos.x
                panelShow:setPosition(ccp(posx+cell,posy))
                moved = true
            end    
        else
            panelShow:setPosition(ccp(posx,posy))
            moved = false
        end 
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if moved then 
		    local function callback() obj:egSetWidgetTouchEnabled(kPanelTouch,true) end
		    local callFunc = CCCallFunc:create(callback)
		    local move = CCMoveTo:create(0.5,ccp(0,0))
		    local sequece = CCSequence:createWithTwoActions(move,callFunc)
		    panelShow:runAction(sequece)
		    obj:egHideWidget(kImgArrowRight)
		    obj:egGetWidgetByName(kImgArrowRight):stopAllActions()
		    obj:egShowWidget(kImgArrowLeft)
		    obj:fadeWidget(obj:egGetWidgetByName(kImgArrowLeft))
		    if obj._touchAreaID > 0 then
                obj._areaSprites[obj._touchAreaID]:setScale(1)
            end  
		else
		    if obj._touchAreaID > 0 then
                local scaleto = CCScaleTo:create(0.3, 1.2)
                local fadeout = CCFadeOut:create(0.3)
                local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
                local transcation = CCSequence:createWithTwoActions(
                                spawn,
                                CCCallFunc:create(function()
                                    sender:setTouchEnabled(true)
                                    local scene = MissionScene.new(obj._touchAreaID)
                                    scene:egReplace()
                                    obj._touchAreaID = 0
                                end))
                local sprite = obj._areaSprites[obj._touchAreaID]
                sprite:runAction(transcation)
            else
                sender:setTouchEnabled(true)
		    end
		end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			if obj._touchAreaID > 0 then
				obj._areaSprites[obj._touchAreaID]:setScale(1)
			end
			obj._touchAreaID = 0
		end
    end
    obj:egBindTouch(kPanelTouchLeft,touchBegan,touchMoved,touchEnded,touchCanceled)
end
function __maplayer.bindBackListener(obj)
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
		local scene = TownScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
MapLayer = {}
function MapLayer.new()
	local obj =  TouchWidget.new(JsonList.worldmapScene)
    table_aux.unpackTo(__maplayer, obj)
    obj:init()
	obj:bindBackListener()
	obj:bindTouchListener()
	return obj
end
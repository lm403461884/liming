local kPanelInfo = "panel_training"
local kImgBg = "img_bg"
local kImgLight = "img_light"
local kImgMask = "img_dark_mask"
local kLblName = "lbl_monster_name"
local kLblLv = "lbl_lv"
local kImgMonster = "img_monstercard"
local kLblAtkVal = "lbl_atk_val"
local kLblHpVal = "lbl_hp_val"
local kPanelStars = "star_list"
--local kBtnBack = "btn_back"

local __traininginfo={}
function __traininginfo.init(obj,monsterid,monsterlv,monstergrade)  
    local s_cfg = monster_data.getConfig(monsterid)
    local s_data = monster_data.get(monsterid,monsterlv)
    local s_datas = monster_data.get(monsterid,monsterlv+1)
	obj:egSetLabelStr(kLblName,s_cfg.name)
    obj:egSetLabelStr(kLblLv,string.format("LV%d%sLV%d",monsterlv,TxtList.arrowSymbol,monsterlv+1))
    obj:egSetLabelStr(kLblAtkVal,string.format("%d%s%d",s_data.power,TxtList.arrowSymbol,s_datas.power))
    obj:egSetLabelStr(kLblHpVal,string.format("%d%s%d",s_data.maxHP,TxtList.arrowSymbol,s_datas.maxHP))
    obj:egChangeImg(kImgMonster,s_cfg.photo,UI_TEX_TYPE_PLIST)
	obj:loadMonsterGrade(monstergrade)
    obj:showWithAction()
end
--���ػ�е�ȼ�
function __traininginfo.loadMonsterGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
function __traininginfo.showWithAction(obj)
    local cardbg = obj:egGetWidgetByName(kImgBg)
    cardbg:setScale(0)
    local scaleto = CCScaleTo:create(0.5,0.85)
    local backout = CCEaseBackOut:create(scaleto)
    local function callback()
        local moveby1 = CCMoveBy:create(1,ccp(0,-10))
        local moveby2 = CCMoveBy:create(1,ccp(0,10))
        local sequence1 = CCSequence:createWithTwoActions(moveby1,moveby2)
        local repeatever = CCRepeatForever:create(sequence1)
        cardbg:runAction(repeatever)
		obj:bindBackListener()
        if obj._onloaded then obj._onloaded() end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(backout,callfunc)
    cardbg:runAction(sequence)
    
    local lightbg = obj:egGetWidgetByName(kImgLight)
    local rotateby1 = CCRotateBy:create(2,37.2)
    local scaleto1 = CCScaleTo:create(2,1)
    local rotateby2 = CCRotateBy:create(2,37.2)
    local scaleto2 = CCScaleTo:create(2,1.2)
    local spawn1 = CCSpawn:createWithTwoActions(rotateby1,scaleto1)
    local spawn2 = CCSpawn:createWithTwoActions(rotateby2,scaleto2)
    local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
    local repeatever = CCRepeatForever:create(sequence)
    lightbg:runAction(repeatever)
    
    local widget = obj:egGetWidgetByName(kImgMask)
    widget:setOpacity(0)
    widget:runAction(CCFadeTo:create(0.2,180))
end
--�رձ�ҳ��
function __traininginfo.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,touchCanceled)
end
function __traininginfo.btnBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

TrainingInfo={}
function TrainingInfo.new(monsterid,monsterlv,monstergrade,onloaded)
    local obj = TouchWidget.new(JsonList.trainingInfo)
    table_aux.unpackTo(__traininginfo, obj)
    obj._onloaded = onloaded
    obj:init(monsterid,monsterlv,monstergrade)
    return obj
end
function showTrainingInfo(itemid,itemlv,monstergrade,onloaded)
    local layer = TrainingInfo.new(itemid,itemlv,monstergrade,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

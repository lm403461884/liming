local kBtnAdd = "btn_add" --����
local kBtnGrow = "btn_grow"--ѵ��
local kPanelGrow = "growbtn_panel"
local kPanelNeed = "need_panel"
local kLblNeedLv = "lbl_need"
local kLblNeedLvs = "lbl_need_s"
local kImgPhoto = "btn_photo"
local kLblName = "lbl_name"
local kLblMsgNum = "lbl_msg_num"
local kLblHp = "lbl_hp_val"
local kLblAtk = "lbl_atk_val"
local kLblCost = "lbl_cost_val"
local kImgLv = "img_lv"
local kLblLv = "lbl_lv"
local kLblGrowCost = "lbl_val_train"
local kPanelStars = "star_list"
local kGrayColor = ccc3(32,32,32)
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local __monstercard={}

function __monstercard.init(obj,monsterid)
    
    obj._monsterid = monsterid
    
	obj._trainlv = account_data.train[train.def.monster].lv
	obj._maxLv = obj._trainlv*numDef.unitLvFactor
	obj._mixVal = account_data.monsterLvLook[obj._monsterid] or 1
	obj._monsterlv = obj._mixVal%256
	obj._grade = math.floor(obj._mixVal/256)
	-----��ȡ��ǰ���й������������ɳ��еĹ�������
	obj._ownNum = 0
	obj._maxNum = MonsterTrain[obj._monsterid][obj._trainlv] or 0
	local N_data = account_data.monsterPool[obj._monsterid]
	if N_data then obj._ownNum = N_data.N end
	--------------------------------------
    local s_cfg =  monster_data.getConfig(obj._monsterid)
	
	
    obj:egChangeBtnImg(kImgPhoto,s_cfg.photo,"","",UI_TEX_TYPE_PLIST)
	
    obj:addprop("monsterid",obj._monsterid)
	obj:addprop("lv",obj._monsterlv)
	obj:addprop("grade",obj._grade)
	obj:addprop("name",s_cfg.name)
	obj:addprop("ownNum",obj._ownNum)
	obj:loadMonsterGrade(obj._grade)
    if obj._maxNum == 0 then
		obj:egSetLabelStr(kLblName,"???")
		obj:egSetLabelStr(kLblHp,"???")
		obj:egSetLabelStr(kLblAtk,"???")
		obj:egSetLabelStr(kLblCost,"???")
		obj:egSetLabelStr(kLblMsgNum,"00/??")
		obj:egHideWidget(kImgLv)
        obj:egSetWidgetColor(kImgPhoto,kGrayColor)
        obj:egSetWidgetTouchEnabled(kImgPhoto,false)
        obj:egSetWidgetEnabled(kBtnAdd,false)
		obj:egSetWidgetEnabled(kBtnGrow,false)
		
		local unlocklv = obj:getUnLockLv()
		obj:egShowWidget(kPanelNeed)
		obj:egHideWidget(kPanelGrow)
		obj:egSetLabelStr(kLblNeedLv,string.format("%s%d",TxtList.trainLvTxt,unlocklv))
		obj:egSetLabelStr(kLblNeedLvs,string.format("%s%d",TxtList.trainLvTxt,unlocklv))
    else
		obj:egSetLabelStr(kLblName,s_cfg.name)
		obj:egSetLabelStr(kLblMsgNum,string.format("%02d/%02d",obj._ownNum,obj._maxNum))
		obj:loadMonsterInfo(obj._monsterlv)
		if obj._ownNum >= obj._maxNum then
			obj:egSetWidgetEnabled(kBtnAdd,false)
		end
   end 
end
--���ػ�е�ȼ�
function __monstercard.loadMonsterGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
--���ع�����ϸ��Ϣ
function __monstercard.loadMonsterInfo(obj,monsterlv)
	obj._curData =  monster_data.get(obj._monsterid,monsterlv )
    obj:egSetBMLabelStr(kLblLv,monsterlv)
	obj:egSetLabelStr(kLblHp,obj._curData.maxHP)
	obj:egSetLabelStr(kLblAtk,obj._curData.power)
	obj:egSetLabelStr(kLblCost,obj._curData.consume)
	if monsterlv <obj._maxLv then
		obj:egHideWidget(kPanelNeed)
		obj:egShowWidget(kPanelGrow)
		obj:egSetWidgetEnabled(kBtnGrow,true)
		obj:egSetBMLabelStr(kLblGrowCost,obj._curData.tValue)
		obj:changeGrowBtnState()
	else
		obj:egSetWidgetEnabled(kBtnGrow,false)
		obj:egShowWidget(kPanelNeed)
		obj:egHideWidget(kPanelGrow)
		obj:egSetLabelStr(kLblNeedLv,string.format("%s%d",TxtList.trainLvTxt,obj._trainlv+1))
		obj:egSetLabelStr(kLblNeedLvs,string.format("%s%d",TxtList.trainLvTxt,obj._trainlv+1))
	end
end
--���ݽ������޸�ѵ����ť�������
function __monstercard.changeGrowBtnState(obj)
    local curData = monster_data.get(obj._monsterid,obj._monsterlv )
	local cost = curData.tValue
	local coin = curData.tCoin
	if account_data[coin]< cost then
		obj:egSetWidgetTouchEnabled(kBtnGrow,false)
		obj:egSetWidgetColor(kLblGrowCost,kRedColor)
	else
		obj:egSetWidgetTouchEnabled(kBtnGrow,true)
		obj:egSetWidgetColor(kLblGrowCost,kWhiteColor)
	end
end
function __monstercard.setAddBtnEnabled(obj)
	obj:egSetWidgetTouchEnabled(kBtnAdd,true)
end
--�޸�������ʾ����
function __monstercard.doMonsterNumUp(obj)
	obj._ownNum = math.min(obj._ownNum + 1,obj._maxNum)
	local N_data = account_data.monsterPool[obj._monsterid]
	if not N_data then 
		N_data = {n=obj._ownNum,N=obj._ownNum} 
	else
		N_data.N = obj._ownNum
		N_data.n = N_data.n + 1
	end
	account_data.monsterPool[obj._monsterid] = N_data --�޸��ʻ��г��еĹ�������
	if not account_data.monsterLvLook[obj._monsterid] then account_data.monsterLvLook[obj._monsterid]=obj._monsterlv end
	obj:addprop("ownNum",obj._ownNum)
	obj:egSetLabelStr(kLblMsgNum,string.format("%02d/%02d",obj._ownNum,obj._maxNum))
	if obj._ownNum >= obj._maxNum then
		obj:egSetWidgetEnabled(kBtnAdd,false)
	else
		obj:egSetWidgetTouchEnabled(kBtnAdd,true)
	end 
end
--�޸ĵȼ���ʾ����
function __monstercard.doMonsterLvUp(obj)
	local newLv = math.min(obj._monsterlv + 1,obj._maxLv)
	local offset = newLv - obj._monsterlv
	obj._monsterlv = newLv
	account_data.monsterLvLook[obj._monsterid] = (account_data.monsterLvLook[obj._monsterid] or 1) + offset--�޸Ĺ���ȼ�
	obj:setprop("lv",obj._monsterlv)
	obj:loadMonsterInfo(obj._monsterlv)
end
--
function __monstercard.getUnLockLv(obj)
	local unlockinfo = MonsterTrain[obj._monsterid]
	local minLv = 99
	if unlockinfo then
		for trainlv,num in pairs(unlockinfo) do
			if trainlv < minLv then minLv = trainlv end
		end
	end
	return minLv
end

--�����ص�����
function __monstercard.onMonsterGrow(obj,callback)
    obj._growCallback = callback
end
--����ص�����
function __monstercard.onMonsterAdd(obj,callback)
    obj._addCallback = callback
	
end
--�鿴��Ϣ��ϸ
function __monstercard.bindCardListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
		local function gradeChangedCallBack()
			obj._mixVal = account_data.monsterLvLook[obj._monsterid] or 1
			obj._grade = math.floor(obj._mixVal/256)
			obj:addprop("grade",obj._grade)
			obj:loadMonsterGrade(obj._grade)
		end
        --����Ϣͨ��Ԥ��ҳ��
		local layer = MonsterInfo.new(obj._monsterid,function() sender:setTouchEnabled(true) end)
		layer:onGradeChanged(gradeChangedCallBack)
		local scene = CCDirector:sharedDirector():getRunningScene()
		scene:removeChildByTag(UILv.popLayer,true)
		scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
		
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgPhoto,nil,nil,touchEnded,touchCanceled)
end
--�������
function __monstercard.bindGrowListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.monsterupdate)
		
        if obj._growCallback then obj._growCallback(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGrow,nil,nil,touchEnded,touchCanceled)
end
--�������
function __monstercard.bindAddListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        if obj._addCallback then 
			obj._addCallback(obj,sender:getTouchEndPos()) 
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAdd,nil,nil,touchEnded,touchCanceled)
end

MonsterCard={}
function MonsterCard.new(heroid)
    local obj = {}
    CocosWidget.install(obj,JsonList.monsterCard)
    table_aux.unpackTo(__monstercard, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(heroid)
    obj:bindCardListener()
    obj:bindAddListener()
    obj:bindGrowListener()
    return obj
end


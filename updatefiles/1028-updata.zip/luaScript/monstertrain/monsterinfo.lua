local kLabelName = "lbl_name"
local kLabelLv = "lbl_lv_val"
local kLabelAtk = "lbl_atkcap_val"
local kLabelHp = "lbl_hp_val"
local kLabelConsume = "lbl_consume_val"
local kLabelIntro = "lbl_introduce"
local kImgMonsterInfo = "img_big_monster"
local kImgMapBg = "map_bg"
local kPanelMonsterInfo = "Panel_monster_info"
local kBtnBack = "btn_back"

local kLblCritical = "lbl_critical_val"
local kLblDodge = "lbl_dodge_val"
local kLblAlertDis = "lbl_alertdis_val"
local kLblSpeed = "lbl_speed_val"
local kLblAct = "lbl_act_val"
local kPanelStars = "star_list"

local kLblCost = "lbl_upgrade_cost"
local kImgCoin = "img_upgrade_coin"
local kBtnUpgrade = "btn_upgrade"

local kPropX= 105
local kPropY = 91
local KMonsterMaxLv = 100
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)
local kGreenColor = ccc3(0,128,0)
local __monsterinfo={}
function __monsterinfo.init(obj,monsterid)
    obj._monsterid = monsterid
	obj._mixVal = account_data.monsterLvLook[obj._monsterid] or 1
    obj._lv = obj._mixVal%256
	obj._grade = math.floor(obj._mixVal/256)
	
    local s_cfg = monster_data.getConfig(obj._monsterid)
    local s_data = monster_data.get(obj._monsterid,obj._lv)
	obj._coin,obj._coinval =  baseCalc.upgradeMonsterCost(obj._grade,obj._monsterid)
	obj._coinname = KVariantList.coinType[obj._coin]
	obj:egChangeImg(kImgCoin,ImageList[string.format("comm_%s",obj._coinname)],UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblCost,obj._coinval)
    obj:egSetLabelStr(kLabelName,s_cfg.name)
    obj:egSetBMLabelStr(kLabelLv,obj._lv)
    obj:egSetLabelStr(kLabelAtk,s_data.power)
    obj:egSetLabelStr(kLabelHp,s_data.maxHP)
    obj:egSetLabelStr(kLabelConsume,s_data.consume)
	obj:egSetLabelStr(kLblAlertDis,s_data.alertDis)
	obj:egSetLabelStr(kLblSpeed,string.format("%0.1f",s_data.speed))
	obj:egSetLabelStr(kLblAct,s_data.charCost)
    obj:egSetLabelStr(kLabelIntro,s_cfg.info)
	local critical,dodge = baseCalc.upgradeMonsterAtt(obj._grade,obj._monsterid)
	obj:egSetLabelStr(kLblCritical,string.format("%0.1f%s",critical/10,"%"))
	obj:egSetLabelStr(kLblDodge,string.format("%0.1f%s",dodge/10,"%"))
    obj:egChangeImg(kImgMonsterInfo,s_cfg.photo,UI_TEX_TYPE_PLIST) 
	obj:loadMonsterGrade(obj._grade)
	if obj._coinval > account_data[obj._coinname] then
		obj:egSetWidgetColor(kLblCost,kRedColor)
		obj:egSetWidgetEnabled(kBtnUpgrade,false)
	end
	obj:showWithAction()
end
function __monsterinfo.doMonsterUpgrade(obj)
	SendMsg[936006](obj._monsterid)
	obj._grade = obj._grade+1
	account_data.monsterLvLook[obj._monsterid] = obj._grade * 256 + obj._lv
	account_data[obj._coinname] = account_data[obj._coinname] - obj._coinval
	if  obj._gradeChangeCallBack then obj._gradeChangeCallBack() end
	local img = ImageView:create()
	img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
	local panel = obj:egGetWidgetByName(kPanelStars)
	panel:addChild(img,1,obj._grade)
	img:setScale(5)
	img:runAction(CCEaseBackOut:create(CCScaleTo:create(0.5,1)))
	
	local critical,dodge = baseCalc.upgradeMonsterAtt(obj._grade,obj._monsterid)
	obj:blinkToShow(kLblCritical,critical)
	obj:blinkToShow(kLblDodge,dodge)
	obj._coin,obj._coinval =  baseCalc.upgradeMonsterCost(obj._grade,obj._monsterid)
	obj._coinname = KVariantList.coinType[obj._coin]
	obj:egChangeImg(kImgCoin,ImageList[string.format("comm_%s",obj._coinname)],UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblCost,obj._coinval)
	if obj._coinval > account_data[obj._coinname] then
		obj:egSetWidgetColor(kLblCost,kRedColor)
		obj:egSetWidgetEnabled(kBtnUpgrade,false)
	else
		obj:egSetWidgetColor(kLblCost,kWhiteColor)
		obj:egSetWidgetEnabled(kBtnUpgrade,true)
	end
end
function __monsterinfo.blinkToShow(obj,widgetname,val)
	local widget = obj:egGetWidgetByName(widgetname)
	widget:setColor(kGreenColor)
	obj:egSetLabelStr(widgetname,string.format("%0.1f%s",val/10,"%"))
	local function callback()
		widget:setColor(kBrownColor)
	end
	local blink = CCBlink:create(1,3)
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(blink,callfunc)
	widget:runAction(sequence)
end
--���ػ�е�ȼ�
function __monsterinfo.loadMonsterGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
function __monsterinfo.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelInfo)
    widget:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveTo:create(0.3,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	local function callback()
		obj:bindBackListener()
		obj:bindUpgradeListener()
		if obj._onloaded then obj._onloaded() end
	end
    local callfunc = CCCallFunc:create(callback)
    local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
    widget:runAction(sequece)
end
function __monsterinfo.bindBackListener(obj)
    local function touchEnded(sender)
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __monsterinfo.onGradeChanged(obj,callback)
	obj._gradeChangeCallBack = callback
end
function __monsterinfo.bindUpgradeListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local layer = ConfirmUpGrade.new(obj._monsterid,function() sender:setTouchEnabled(true) end)
		local function callback()
			obj:doMonsterUpgrade()
		end
		layer:onConfirmed(callback)
		local scene = CCDirector:sharedDirector():getRunningScene()
		scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnUpgrade,touchBegan,nil,touchEnded,touchCanceled)
end
MonsterInfo={}
function MonsterInfo.new(monsterid,onloaded)
    local obj = TouchWidget.new(JsonList.monsterInfo)
    table_aux.unpackTo(__monsterinfo, obj)
	obj._onloaded = onloaded
    obj:init(monsterid)
    return obj
end
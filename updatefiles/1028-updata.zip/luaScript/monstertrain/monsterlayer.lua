local kBtnBack = "btn_back"
local kImgBack = "img_back"
local kLabelCnt = "lbl_monstercnt"
local kLabelDig = "lbl_digcnt"
local kLabelGold = "own_gold_val"
local kBarGold = "own_gold_bar"
local kBtnGoldadd = "btn_gold_add"
local kPanelGold = "own_gold"
local KLblTrainLv = "lbl_train"
--������Ϣ���
local kPanelNote = "notice_panel"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kPanelTxt = "txt_panel"
local kLblTxt1 = "lbl_note_txt1"
local kLblCoinRes = "lbl_coin_res"
local kImgNoteCoin = "img_note_coin"
local kLblNoteTxt = "lbl_note_txt2"
local kImgTxtBg = "img_note_bg"
--�����б�
local kItemList = "itemlist"
local kCellW = 200
local kPanelW = 710
local kUtype = 2
local kRedColor = ccc3(255,0,0)
local kMaxNum = 7
local kMaxGoldN = 99999999

local __monsterlayer={}
function __monsterlayer.init(obj)
	obj._trainLv= account_data.train[train.def.monster].lv
	obj._monsterItems = {}
    obj:showNotePanel(false)
    obj._selectedmonster = nil
	obj:egSetLabelStr(kLabelDig,account_data.maxDigPt or 0)
	obj:egSetLabelStr(KLblTrainLv,string.format("%s%d","LV",obj._trainLv))
	obj:refreshMonsterNum()
	obj:refreshGold()
    obj._itemlist = obj:egGetScrollView(kItemList)
    obj._startIdx = 1
    obj._oldW = 0
	obj._orgX = obj:egGetWidgetByName(kPanelTxt):getPositionX()
end
--ˢ�¹���������ʾ
function __monsterlayer.refreshMonsterNum(obj)
	local cnt = 0
	for monsterid ,data in  pairs(account_data.monsterPool) do
		cnt = cnt + data.N
	end
	obj:egSetLabelStr(kLabelCnt,cnt)
end
--ˢ�½�������ʾ
function __monsterlayer.refreshGold(obj)
	local gold = account_data.gold
	local maxgold = account_data.maxGold
	obj:egSetBarPercent(kBarGold,math.min(gold*100/maxgold,100))
	obj:egSetBMLabelStr(kLabelGold,Funs.getBouncedNum(gold,kMaxGoldN,true))
end
function __monsterlayer.bindGoldListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj:onAddGoldClicked(kBtnGoldadd)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGoldadd,nil,nil,touchEnded,touchCanceled)
end

function __monsterlayer.bindGoldPanelListener(obj)
    local btn = tolua.cast(obj:egGetWidgetByName(kBtnGoldadd),"Button")
	local function touchBegin(sender)
		btn:setFocused(true)
	end
	local function touchEnded(sender)
		--local btn = obj:egGetWidgetByName(kBtnActadd)
		btn:setFocused(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		local function callback()
			sender:setTouchEnabled(true)
		end
		obj:onAddGoldClicked(kBtnGoldadd,callback)
    end
	local function touchCanceled(sender)
	    btn:setFocused(false)
		if AccountHelper:isLocked(kStateGuide) then --引导状�?
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelGold,touchBegin,nil,touchEnded,touchCanceled)
end
function __monsterlayer.onAddGoldClicked(obj,widgetName,callback)
	local widget = obj:egGetWidgetByName(widgetName)
	local posx = widget:getPositionX() + widget:getSize().width/2
	local posy = widget:getPositionY() + widget:getSize().height/2
	if widgetName == kBtnGoldadd then
		local panel = obj:egGetWidgetByName(kPanelGold)
		posx = panel:getPositionX() + widget:getPositionX()
		posy = panel:getPositionY() + widget:getPositionY()  - widget:getSize().height*widget:getAnchorPoint().y
	end
	if os.time() >= account_data.goldNextSt then
		account_data.goldBoughtCnt = 0
		account_data.goldNextSt = Funs.getTimeWithHMS(numDef.goldRefreshUTH,numDef.goldRefreshUTM,0,account_data.scOffsetTime)
	end
	local maxBoughtCnt = VipLvUp[account_data.vip or 0].goldCnt or 0
	if account_data.goldBoughtCnt >= maxBoughtCnt then
		showPopTxt(TxtList.maxBoughtCnt,posx,posy,ccp(0.5,1))
		widget:setTouchEnabled(true)
	else
		local apPirce,_ =  jewelCalc.getPriceForGold(account_data.digLv)
		if apPirce > account_data.jewel then
			showPopCharge(apPirce,function() widget:setTouchEnabled(true) end)
		else
			showApMarket(1,function() widget:setTouchEnabled(true) end)
		end
	end
	if callback then callback() end
end
--����ȷ�Ͽ���ʾ
function __monsterlayer.showNotePanel(obj,show)
    if show then
        obj:egShowWidget(kPanelNote)
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        obj:egSetWidgetTouchEnabled(kBtnYes,true)
        obj:egSetWidgetTouchEnabled(kBtnNo,true)
    else
        obj:egHideWidget(kPanelNote)
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
    end
end

--��ȡ����С���������Ĺ���ID�б�
function __monsterlayer.getOrderedMonsterList(obj)
    local tbUnlocked = {}
    local tbLocked = {}
    for monsterid,item in pairs(MonsterTrain) do  --monsterid����
       if item[obj._trainLv] then 
          table.insert(tbUnlocked,monsterid) 
       else
          table.insert(tbLocked,monsterid)
       end 
    end
    table.sort(tbUnlocked)
    table.sort(tbLocked)
    for key,val in ipairs(tbLocked) do
        table.insert(tbUnlocked,val)
    end
    tbLocked = nil
    return tbUnlocked
end
function __monsterlayer.addMonsterItem(obj,num)
    local monsterList = obj:getOrderedMonsterList()
    obj._maxMonsterNum = #monsterList
    local size = obj._itemlist:getSize()
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num - 1,obj._maxMonsterNum)
    for idx = startIdx,obj._maxMonsterNum,1 do
        if idx>endIdx then break end
        local monsterid = monsterList[idx] 
        local monstercard = MonsterCard.new(monsterid)
        monstercard:egSetPosition((idx-1)*kCellW,0)
        obj:bindAddCallBack(monstercard)
        obj:bindGrowCallBack(monstercard)
        obj._itemlist:addChild(monstercard:egNode())
        table.insert(obj._monsterItems,monstercard)
    end
    local neww = endIdx*kCellW
    if neww > size.width then
        obj._itemlist:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __monsterlayer.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType == SCROLLVIEW_EVENT_SCROLL_TO_RIGHT then
            local curW = obj._itemlist:getInnerContainerSize().width
            if obj._oldW<curW then
                obj:addMonsterItem(1)
                obj._oldW = curW
            end
        end
    end
    obj._itemlist:addEventListenerScrollView(scrollEvent) 
end
function __monsterlayer.getMonsterPrice(obj,monsterid,ownNum)
	for key,val in pairs(MonsterCost[monsterid][ownNum]) do
		return key,val
	end
end
function __monsterlayer.getpanelW(obj)
    local w1 = obj:egGetWidgetByName(kLblTxt1):getSize().width
    local w2 = obj:egGetWidgetByName(kLblCoinRes):getSize().width
    local w3 = obj:egGetWidgetByName(kImgNoteCoin):getSize().width
    local w4 = obj:egGetWidgetByName(kLblNoteTxt):getSize().width
    return w1 + w2 + w3 + w4
end
--������ص�����
function __monsterlayer.bindAddCallBack(obj,monstercard)
	local function addCallBack(sender,pos)
		obj._selectedmonster = sender
        
        local monsterid = sender:getprop("monsterid")
		local ownNum = sender:getprop("ownNum")
		local coinName,coinVal = obj:getMonsterPrice(monsterid,ownNum)
		if account_data[coinName] < coinVal then
			showPopTxt(string.format("%s %d",TxtList["need"..coinName],coinVal),pos.x,pos.y,ccp(0.5,0.5))
			sender:setAddBtnEnabled()
		else
			obj:showNotePanel(true)
			obj:egChangeImg(kImgNoteCoin,ImageList[string.format("comm_%s",coinName)],UI_TEX_TYPE_PLIST)
			obj:egSetLabelStr(kLblCoinRes,coinVal) 
			obj:egSetLabelStr(kLblNoteTxt,string.format("%s %s ?",TxtList.addMonster,sender:getprop("name")))
			local w = obj:getpanelW()
			local panel = obj:egGetWidgetByName(kPanelTxt)
			panel:setSize(CCSizeMake(w,panel:getSize().height))
			panel:setPosition(ccp(obj._orgX + (kPanelW-w)/2,panel:getPositionY()))
			local imgmask = obj:egGetWidgetByName(kImgTxtBg)
			imgmask:setScale(0)
			local scaleto = CCScaleTo:create(0.2,1)
			local backout = CCEaseBackOut:create(scaleto)
			imgmask:runAction(backout)
		end
	end
	monstercard:onMonsterAdd(addCallBack)
end
--��ѵ���ص�����
function __monsterlayer.bindGrowCallBack(obj,monstercard)
	local function growCallback(sender)
		local monsterlv = sender:getprop("lv")
		local monsterid = sender:getprop("monsterid")
		local monstergrade = sender:getprop("grade")
		local monsterdata =  monster_data.get(monsterid,monsterlv )
		local coinName = monsterdata.tCoin
		local coinVal = monsterdata.tValue
		local isjewel = 0
		if coinName==KVariantList.coinType[99] then isjewel = 1 end
		account_data[coinName] = account_data[coinName] - coinVal --�ۼ��ʻ�
		SendMsg[936005](kUtype,monsterid,isjewel,0)--����ѵ����Ϣ��������
		--�ھ���־������̸���,��������
		task.updateTaskStatus(account_data,task.client_event_id.update_monster,{monsterid,monsterlv+1})
		----------------------------------------------------------
		local function loadedCallback()
			sender:doMonsterLvUp()
			obj:refreshGold()
			obj:changeAllGrowBtnState()
		end
		showTrainingInfo(monsterid,monsterlv,monstergrade,loadedCallback)
	end
	monstercard:onMonsterGrow(growCallback)
end
--��������䶯���޸����п�Ƭ��ť����
function __monsterlayer.changeAllGrowBtnState(obj)
	for key,monstercard in ipairs(obj._monsterItems) do
		monstercard:changeGrowBtnState()
	end
end
--ȷ������
function __monsterlayer.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.monster_get)
        obj:showNotePanel(false)--�ر���ʾ��
		
		local monsterid = obj._selectedmonster:getprop("monsterid")
		local ownNum = obj._selectedmonster:getprop("ownNum")
		local coinName,coinVal = obj:getMonsterPrice(monsterid,ownNum)
		account_data[coinName] = account_data[coinName] - coinVal --�ۼ��ʻ�
		SendMsg[936004](monsterid)--����������Ϣ��������
		--�ھ���־������̸���,�������
		task.updateTaskStatus(account_data,task.client_event_id.buy_monster,{monsterid})
		----------------------------------------------------------
        -----------------------
        local popmonstercard =PopMonsterCard.new(monsterid)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmonstercard:egNode(),UILv.popLayer,UILv.popLayer)
        local function onclosedCallback()
			obj._selectedmonster:doMonsterNumUp()
			obj:refreshMonsterNum()
			obj:refreshGold()
			obj:changeAllGrowBtnState()
			obj._selectedmonster = nil
		end
		popmonstercard:onPopCardClosed(onclosedCallback)
		--]]
	end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end

--ȡ������
function __monsterlayer.bindNoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
       local imgmask = obj:egGetWidgetByName(kImgTxtBg)
        local scaleto = CCScaleTo:create(0.2,0)
        local function callback()
            sender:setTouchEnabled(true)
			obj._selectedmonster:setAddBtnEnabled()
            obj:showNotePanel(false)
			obj._selectedmonster = nil
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(scaleto,callfunc)
        imgmask:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end

--���ذ�ť
function __monsterlayer.bindBackListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBack,1.1)
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetScale(kImgBack,1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
		obj:egNode():removeAllChildrenWithCleanup(true)
		graphicLoader.removeMonsterCardFrame()
        local scene = TownScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBack,1)
		if AccountHelper:isLocked(kStateGuide) then --����״̬		
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
function __monsterlayer.doLoading(obj)
	local function coFunc()
		graphicLoader.loadMonsterCardFrame()
		for idx = 1,kMaxNum do
			obj:addMonsterItem(1)
			coroutine.yield()
		end
		obj:bindScrollListener()
	end
	local coLoad = coroutine.create(coFunc)
	local function callback()
		local f1,f2 = coroutine.resume(coLoad)
		if not f1 then
			obj:egUnbindWidgetUpdate(KLblTrainLv)
			if type(f2) == "string" then print(f2) end
		end
	end
	obj:egBindWidgetUpdate(KLblTrainLv,callback)
end
MonsterLayer={}
function MonsterLayer.new()
    local obj =  TouchWidget.new(JsonList.monsterLayer)
    table_aux.unpackTo(__monsterlayer, obj)
    obj:init()
    obj:bindGoldListener()
    obj:bindGoldPanelListener()
    obj:bindBackListener()
    obj:bindYesListener()
    obj:bindNoListener()
	obj:doLoading()
    return obj
end


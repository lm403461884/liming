--������Ϣ���
local kPanelNote = "notice_panel"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kPanelTxt = "txt_panel"
local kLblUpgrade = "lbl_note_upgrade"

local kLblTxt1 = "lbl_note_txt1"
local kLblCoinRes = "lbl_coin_res"
local kImgNoteCoin = "img_note_coin"
local kLblNoteTxt = "lbl_note_txt2"

local kImgGray = "img_gray"
local kImgBg="img_note_bg"
local kPanelW = 710
local kOffsetY = -30
local __confirmupgrade={}
function __confirmupgrade.init(obj,monsterid)
	obj._monsterid = monsterid
	obj:loadConfirmInfo()
	local bg = obj:egGetWidgetByName(kImgBg)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	obj:egSetWidgetTouchEnabled(kBtnYes,false)
	obj:egSetWidgetTouchEnabled(kBtnNo,false)
	obj:egSetLabelStr(kLblCoinRes,needVal)
	bg:setScale(0)
	local scaleto = CCScaleTo:create(0.3,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		obj:egSetWidgetTouchEnabled(kBtnYes,true)
		obj:egSetWidgetTouchEnabled(kBtnNo,true)
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	bg:runAction(sequence)
	graylayer:setOpacity(0)
	graylayer:runAction(CCFadeTo:create(0.3,128))
end
function __confirmupgrade.getpanelW(obj)
    local w1 = obj:egGetWidgetByName(kLblTxt1):getSize().width
    local w2 = obj:egGetWidgetByName(kLblCoinRes):getSize().width
    local w3 = obj:egGetWidgetByName(kImgNoteCoin):getSize().width
    local w4 = obj:egGetWidgetByName(kLblNoteTxt):getSize().width
    return w1 + w2 + w3 + w4
end
function __confirmupgrade.loadConfirmInfo(obj)
    obj._mixVal = account_data.monsterLvLook[obj._monsterid] or 1
    obj._lv = obj._mixVal%256
	obj._grade = math.floor(obj._mixVal/256)
    local s_cfg = monster_data.getConfig(obj._monsterid)
	obj._coin,obj._coinval =  baseCalc.upgradeMonsterCost(obj._grade,obj._monsterid)
	obj._coinname = KVariantList.coinType[obj._coin]
	print(obj._coinname)
	obj:egShowWidget(kLblUpgrade)
	obj:egSetLabelStr(kLblUpgrade,TxtList.upgradeMonsterAtt)
	obj:egChangeImg(kImgNoteCoin,ImageList[string.format("comm_%s",obj._coinname)],UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblCoinRes,obj._coinval )
	obj:egSetLabelStr(kLblNoteTxt,string.format("%s %s ?",TxtList.upgradeMonster,s_cfg.name))

    local w = obj:getpanelW()
    local panel = obj:egGetWidgetByName(kPanelTxt)
    panel:setSize(CCSizeMake(w,panel:getSize().height))
    panel:setPosition(ccp(panel:getPositionX() + (kPanelW-w)/2,panel:getPositionY() + kOffsetY))
end
function __confirmupgrade.onConfirmed(obj,callback)
	obj._confirmCallback = callback
end
--ȷ�ϰ�ť
function __confirmupgrade.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
		SoundHelper.playEffect(SoundList.buy_hero_01)
		if obj._confirmCallback then obj._confirmCallback() end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __confirmupgrade.bindNoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end

ConfirmUpGrade={}
function ConfirmUpGrade.new(monsterid,onloaded)
    local obj =  TouchWidget.new(JsonList.confirmHire)
    table_aux.unpackTo(__confirmupgrade, obj)
    obj._onloaded = onloaded
    obj:init(monsterid)
    obj:bindYesListener()
    obj:bindNoListener()
    return obj
end

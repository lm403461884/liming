local kImgCoin = "img_icon"
local kLblVal = "lbl_val"
local kLblArea = "lbl_area"
local kPanelLayer = "panel_icon"
local __lvupicon = {}
function __lvupicon.init(obj,trainid,imgsrc,val1,val2,area)--(val1.��Ҫֵ��val2.ʵ��ֵ)
    obj:egChangeImg(kImgCoin,imgsrc,UI_TEX_TYPE_PLIST)
    if trainid==0 then
        if val2 > val1 then val2=val1 end
        obj:egSetLabelStr(kLblVal,string.format("%d%s%d",val2,"/",val1))
    else
        obj:egSetLabelStr(kLblVal,val1)
    end    
    if area then obj:egSetLabelStr(kLblArea,area) end
    --local panelLayer = obj:egGetWidgetByName(kPanelLayer)
    local img = obj:egGetWidgetByName(kImgCoin)
    local imgsize = img:getSize()
    local posy = img:getPositionY()
    local panelsize = obj:egNode():getSize()
    local height = posy+imgsize.height*0.7/2
    obj:egNode():setSize(CCSizeMake(panelsize.width,height))
end
function __lvupicon.setTxtColor(obj,color)
    obj:egSetWidgetColor(kLblVal,color)
end
LvupIcon={}
function LvupIcon.new(trainid,imgsrc,val1,val2,area)
    local obj = {}
    CocosWidget.install(obj,JsonList.lvupitem)
    table_aux.unpackTo(__lvupicon, obj)
    obj:init(trainid,imgsrc,val1,val2,area)
    return obj
end

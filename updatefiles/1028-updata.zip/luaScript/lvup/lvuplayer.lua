--[[
train.config[1].research = {            --1�ų����о�����������Դ�����������������
    [2] = {gold,licence,oil,duration,
bodyImage={"",""} 
unlockItem={[1]='���С��', [2]='С����001.png'}},
 --1 ���������� 2������ͼƬ ��ÿ��������������һ�������� �����ڶ�������� �򰴴˸�ʽ˳�����������
--]]
local kNextLv = "ask_lv_val"
local kCostTime = "up_time_val"
local kUpItemImg = "up_item_img"
local kLiceneVal = "cost_licene_val"--
local kGoldVal = "cost_gold_val"--
local kOilVal = "cost_oil_val"--

local kBtnConfirm = "confirm_btn"
local kBtnCancel = "close_btn"
local kLblUnlock = "lbl_unlock"
local kPanelMask = "mask_panel"--
local kPanelBg = "lvup_bg"
local kActionShow = "show"--
local kActionHide = "hide"--
local kPanelLayer = "lvup_panel"
local kLblComfirm="comfirm_lbl"
local kImgCoins = {"img_1","img_2","img_3"}
local kLblVals = {"lbl_1","lbl_2","lbl_3"}
local kPanelVal = "val_panel"
local kImgTrainLv ="img_train_lv"
--local kLblTrainLv = "lbl_train_lv"
local kLblArea = "lbl_area"

local kRedColor = ccc3(255,0,0)
local kBrownColor = ccc3(83,49,22)
local kCellW = 720
local kCellH = 106
local kMovedes=80
local kTotal = 3
local __lvuplayer={}
function __lvuplayer.confirmLvUp(obj,onclosed)
    SoundHelper.playEffect(SoundList.click_shop_goods)
    if obj._trainid==train.def.head then obj:trainHeadLvUp() return end
    local d_data = account_data.train[obj._trainid]
    SendMsg[937002](obj._trainid,d_data.lv +1)
    account_data.train[obj._trainid].exp = os.time() + obj._s_data.duration
    obj:lvUpResult()
    postEventSignal(kEventTrainUpStart..obj._trainid)
    obj:hideWithAction(onclosed)
end
--��ͷ����
function __lvuplayer.trainHeadLvUp(obj,onclosed)
    local lv = account_data.digLv
    local s_data = licenceLevelup[lv]
    SendMsg[932004](lv, lv + 1)
	--�ھ���־������̸���,ִ������
	task.updateTaskStatus(account_data,task.client_event_id.update_train_head,{lv})
	----------------------------------------------------------
	local cost = licenceLevelup[lv]
	--account_data.gold = account_data.gold - (cost.gold or 0)
	obj:lvUpResult()
	account_data.diggingLvContext = os.time() +  cost.duration
	postEventSignal(kEventLicenceUpStart)
    obj:hideWithAction(onclosed)
end
--������Դ����
function __lvuplayer.lvUpResult(obj)
    local s_data = nil
    if obj._trainid == train.def.head then
        s_data = licenceLevelup[account_data.digLv]
    else
        s_data = obj._s_data
    end
    for id,name in pairs(KVariantList.coinType) do
        if s_data[name] and s_data[name]> 0 then
            account_data[name] = account_data[name] - s_data[name]
        end
    end
end
--ȷ������
function __lvuplayer.bindConfirmListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:confirmLvUp()
    end

	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnConfirm,nil,nil,touchEnded,touchCanceled)
end
--�ر�����ҳ��
function __lvuplayer.bindCancelListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnded,touchCanceled)
end

function __lvuplayer.init(obj,idx)
    obj._trainid = idx
    if obj._trainid == train.def.head then--��ͷ���
        obj:showTrainHead()
    else
		obj:showCommTrain()
    end
	obj:loadParams() 
	obj:resizeValPanel()
	if obj._s_data.unlockItem=="" then
        obj:egHideWidget(kLblUnlock)
    else	
		obj:egShowWidget(kLblUnlock)
        local widget = obj:egGetWidgetByName(kLblUnlock)
        local lbl =  tolua.cast(widget,"Label")
        lbl:setText(obj._s_data.unlockItem)
        local size = lbl:getSize()
        if size.width > kCellW then
            lbl:setTextAreaSize(CCSizeMake(kCellW,kCellH))
        end
    end
    obj:showWithAction()
end
function __lvuplayer.showCommTrain(obj)
	obj._params = {}
    local d_data = account_data.train[obj._trainid]
    local train_cfg = train.config[obj._trainid]
    local nextlv = d_data.lv + 1
    obj._s_data = train_cfg.research[nextlv]
     obj._licence = obj._s_data.licence or 1
    table.insert(obj._params,{ImageList.comm_lv,obj._licence,account_data.digLv,nil})
    --if obj._gold > 0 then table.insert(obj._params,{ImageList.comm_gold,obj._gold,account_data.gold,nil}) end
    for id,name in pairs(KVariantList.coinType) do
        local imgName = ImageList[string.format("comm_%s",name)]
        if obj._s_data[name] and obj._s_data[name]> 0 then table.insert(obj._params,{imgName,obj._s_data[name],account_data[name],nil})end
    end
    obj:egChangeImg(kUpItemImg,obj._s_data.bodyImage[1])
    obj:egSetLabelStr(kNextLv,nextlv)
    obj:egSetLabelStr(kCostTime,Funs.formatTimeCh(obj._s_data.duration,true,true,true,true,true))
    obj:egHideWidget(kImgTrainLv)
end
--��ͷ��������
function __lvuplayer.showTrainHead(obj)
    obj:egShowWidget(kImgTrainLv)
    obj:egChangeImg(kUpItemImg,train.config[obj._trainid].research[account_data.digLv+1].bodyImage[1])
    obj:egSetLabelStr(kNextLv,account_data.digLv+1)
	obj._s_data = licenceLevelup[account_data.digLv]
    obj:egSetLabelStr(kCostTime,Funs.formatTimeCh(obj._s_data.duration,true,true,true,true,true))
    
    obj._params={} 
    local areaName = string.format(TxtList.needArea,scene_data[obj._s_data.areaID].name)
    obj._star = obj._s_data.stars
    obj._curstar = account_data.unlockedPVE[obj._s_data.areaID].areaStars
    --if obj._gold > 0 then table.insert(obj._params,{ImageList.comm_gold,obj._gold,account_data.gold,nil})end
    for id,name in pairs(KVariantList.coinType) do
        local imgName = ImageList[string.format("comm_%s",name)]
        if obj._s_data[name] and obj._s_data[name]> 0 then table.insert(obj._params,{imgName,obj._s_data[name],account_data[name],nil})end
    end
    if obj._star > 0 then table.insert(obj._params,{ImageList.star,obj._star,obj._curstar,areaName})end
end
function __lvuplayer.resizeValPanel(obj)
    local cnt = #obj._params
    local widget = obj:egGetWidgetByName(kPanelVal)
    if cnt < kTotal then
        local offseth = widget:getSize().height * (kTotal-cnt)/kTotal/2
        widget:setPosition(ccp(widget:getPositionX(),widget:getPositionY() - offseth))
    end
    if obj._trainid  == train.def.head then
        widget:setPosition(ccp(widget:getPositionX()-35,widget:getPositionY()))
    end
end
function __lvuplayer.loadParams(obj)
	obj:egSetWidgetEnabled(kBtnConfirm,true)
	local iconPanel = obj:egGetWidgetByName(kPanelVal)
    for idx,item in ipairs(obj._params) do
        local color = kBrownColor
        if item[2] > item[3] then 
            color = kRedColor 
			obj:egSetWidgetEnabled(kBtnConfirm,false)
        end
        local iconitem = LvupIcon.new(obj._trainid,item[1],item[2],item[3],item[4])
        iconitem:setTxtColor(color)
        iconPanel:addChild(iconitem:egNode())
    end
    
    if account_data.train[obj._trainid].exp > os.time() then
        obj:egSetWidgetEnabled(kBtnConfirm,false)
    elseif obj._trainid == train.def.head and account_data.diggingLvContext>os.time() then
        obj:egSetWidgetEnabled(kBtnConfirm,false)
    end
end
function __lvuplayer.hideWithAction(obj,onclosed)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
        if onclosed then onclosed() end
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __lvuplayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
LvUpLayer={}
function LvUpLayer.new(idx,callback)
   local obj =  TouchWidget.new(JsonList.lvupLayer)
    table_aux.unpackTo(__lvuplayer, obj)
    obj._onloaded = callback
    obj:init(idx)
    obj:bindConfirmListener()
    obj:bindCancelListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end
function showLvUp(idx,callback)
    local layer = LvUpLayer.new(idx,callback)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
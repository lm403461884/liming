local kLblTxt = "lbl_txt"
local kPanelDialog = "dialog_panel"
local kbtnOver = "btn_over"
local kbtnTxt = "btn_txt"
local __dialoglayer = {}
function __dialoglayer.init(obj,data,dialogIdx)
    obj._d_data = data
    obj:egSetLabelStr(kLblTxt,obj._d_data.txt)
	obj:egSetLabelStr(kbtnTxt,dialogData.overtxt)
	if dialogIdx >= 10000 then
		obj:egShowWidget(kbtnOver)
	else
		obj:egHideWidget(kbtnOver)
	end  
	obj:showWithAction()
end
function __dialoglayer.showWithAction(obj)
	local layout = Layout:create()
	layout:setTouchEnabled(true)
	layout:ignoreContentAdaptWithSize(false)
	layout:setSize(obj:egNode():getContentSize())
	local widget = obj:egGetWidgetByName(kPanelDialog)
	widget:addChild(layout)
	local fadein = CCFadeIn:create(0.5)
	local function callback()
		layout:setTouchEnabled(false)
		if obj._onShown then obj._onShown() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(fadein,callfunc)
	widget:runAction(sequence)
end
function __dialoglayer.bindDialogListener(obj)
    local function touchEnded(sender)
		obj:egSetWidgetTouchEnabled(kPanelDialog,false)
		obj:egRemoveSelf()
		if obj._d_data.guideIdx then  
			GuideScene[obj._d_data.sceneCode][obj._d_data.guideIdx].unLockNext(account_data)
			SendMsg[931005](obj._d_data.sceneCode,obj._d_data.guideIdx) 
		end
		if obj._d_data.callbackIdx then
		    local callbackFunc = DialogCallback[obj._d_data.callbackIdx]
		    if callbackFunc then callbackFunc() end
		end
		if obj._d_data.focusIdx then
			showFocus(obj._d_data.focusIdx)
		elseif obj._d_data.dialogIdx then
			showDialog(obj._d_data.dialogIdx)
		else
			AccountHelper:unlock(kStateGuide)
		end
		
    end
    obj:egBindTouch(kPanelDialog,nil,nil,touchEnded,nil)
end

function __dialoglayer.bindOverListener(obj,dialogIdx)
    local function touchEnded(sender)
		obj:egSetWidgetTouchEnabled(kPanelDialog,false)
		obj:egRemoveSelf()
        SoundHelper.playEffect(SoundList.click_paper_open)
		if obj._d_data.dialogOver then
			local dialogOverfunc = obj._d_data.dialogOver
			if dialogOverfunc then dialogOverfunc(dialogIdx) end
		end
		AccountHelper:unlock(kStateGuide)
    end
    obj:egBindTouch(kbtnOver,nil,nil,touchEnded,nil)   
end


EmDialogLayer={}
function EmDialogLayer.new(dialogIdx,onShown)
    local data =  dialogData[dialogIdx]
	local obj = nil
	if data then
		AccountHelper:lock(kStateGuide)
		obj = TouchWidget.new(data.jsonFile)
		table_aux.unpackTo(__dialoglayer, obj)
		obj._onShown = onShown
		obj:init(data,dialogIdx)
		obj:bindDialogListener()
		obj:bindOverListener(dialogIdx)
		obj:egSetTouchPriority(TouchLv.guidLayer)
	else
		print("can not find dialog data with idx ",dialogidx)
	end
    return obj
end
--idx :�Ի�������ID
function showDialog(dialogidx,onShown)
    if AccountHelper:isLocked(kStateGuide) then
        local scene = CCDirector:sharedDirector():getRunningScene()
		if scene:getChildByTag(UILv.guidLayer) then
			scene:removeChildByTag(UILv.guidLayer,true)
        end
    end
    local layer = EmDialogLayer.new(dialogidx,onShown)
	if layer then
		local scene = CCDirector:sharedDirector():getRunningScene()
		scene:addChild(layer:egNode(),UILv.guidLayer,UILv.guidLayer)
	else
	    AccountHelper:unlock(kStateGuide)
	end
end
function showEmDialog(owner,sceneCode)
	if not account_data.guideList then return end
    local subidx = account_data.guideList[sceneCode]
    if not subidx  then return end
    local guidItem = GuideScene[sceneCode][subidx]
	if guidItem then
		local layer =guidItem.getActivedDialog(account_data)
		if layer then 
            owner._dialogWidget = layer
            owner._dialogWidget:egAttachTo(owner,UILv.guidLayer,UILv.guidLayer)  
		end
	end
end

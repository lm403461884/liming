local __testscene={}
function __testscene.bindTouchEvent(obj)
    
	local function onTouch(eventType, x,y)
        if eventType == "began" then
			obj:bindSDKObserver()
            SDKHelper:login()
        end
	end
	obj._layer:registerScriptTouchHandler(onTouch,false,0,true)
	obj._layer:setTouchEnabled(true)
end
function __testscene.bindSDKObserver(obj)
	local function onEventActived(eventName)
		removeAllObserver(obj:egNode())
		if eventName == kEventSDKAuthorized then
		   CCMessageBox(kEventSDKAuthorized,"kEventSDKAuthorized")
		end
	end
	bindObserver(obj:egNode(),onEventActived,kEventSDKAuthorized)
end
TestScene = {}
function TestScene.new()
	local obj = {}
	Scene.install(obj)
	table_aux.unpackTo(__testscene, obj)
	obj._layer = CCLayerColor:create(ccc4(255,255,255,255))
	obj:egAddChild(obj._layer)
    obj:bindTouchEvent()
    return obj
end

local kBtnClick = "btn_invite"
local kLblClick = "lbl_invite"
local kLblClicks = "lbl_invite_s"
local kImgReady = "img_light_border"
local kBtnPhoto = "btn_photo"
local kImgEquip = "img_equip"
local kLblName = "lbl_name"
local kLblMsgNum = "lbl_msg_num"
local kPanelStars = "star_list"

local kImgHeroLv = "img_lv"
local kLblHeroLv = "lbl_lv"
local kImgEquipLv = "img_equip_lv"
local kLblEquipLv = "lbl_equip_lv"
local kBtnEquip = "btn_equip_bg"
local kImgEquipBg = "img_color_bg"
local kImgMember = "img_member"
local kLblMember = "lbl_member"

local kBlackColor = ccc3(0,0,0)
local kGrayColor = ccc3(32,32,32)
local kGreenColor = ccc3(0,128,0)
local kRedColor = ccc3(255,0,0)
local __pubhero={}

function __pubhero.init(obj,heroid)
    obj:addprop("heroid",heroid)
    obj._heroid = heroid
    obj._s_cfg =  hero_data.getConfig(obj._heroid)
	obj._msgNum = account_data.heroInfoList[obj._heroid] or 0
	obj._herodata = account_data.heroList[obj._heroid]
	obj:egChangeBtnImg(kBtnPhoto,obj._s_cfg.photo,"","",UI_TEX_TYPE_PLIST)
   
	obj:egSetWidgetTouchEnabled(kBtnEquip,false)
	if obj._herodata then --����ļ
		obj:egChangeImg(kImgEquip,equipCfg[obj._herodata.eid].icon,UI_TEX_TYPE_PLIST)
		local curGrade = obj._herodata.grade or 0 --��ǰ���׵ȼ�
		obj:loadHeroGrade(curGrade) --����Ӣ�۽��׵ȼ�
		obj._maxInfoCnt = jewelCalc.getUpGradeMsg(curGrade)--�´ν���������Ϣ����
		obj:egSetLabelStr(kLblName, obj._s_cfg.heroName)
		obj:egSetLabelStr(kLblMsgNum,string.format("%02d/%02d",obj._msgNum,obj._maxInfoCnt))
		obj:egSetWidgetTouchEnabled(kBtnPhoto,true)
		obj:egSetWidgetEnabled(kBtnClick,true)
		obj:egShowWidget(kImgMember)
		obj:egShowWidget(kLblMember)
		obj:egShowWidget(kImgHeroLv)
		obj:egShowWidget(kImgEquipLv)
		obj:egShowWidget(kBtnEquip)
		obj:egShowWidget(kImgEquipBg)
		obj:egSetBMLabelStr(kLblHeroLv,obj._herodata.lv)
		local equiplv,equipqa = equipFuncs.getEquipQL(obj._herodata.eid, account_data)
		obj:egSetBMLabelStr(kLblEquipLv,equiplv)
		obj:egSetWidgetColor(kImgEquipBg,KVariantList.equipColor[equipqa])
		if obj._msgNum < obj._maxInfoCnt then --���ܽ���
			obj:egHideWidget(kImgReady)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[8]) --�ؽ����
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[8])
		else --���Խ���
			obj:egShowWidget(kImgReady)--��ʾ��ʾ�߿�
			obj:egSetWidgetColor(kImgReady,kRedColor)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[7]) --����
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[7])
			local imgborder = obj:egGetWidgetByName(kImgReady)
			local fadeout = CCFadeTo:create(1,64)
			local fadein = CCFadeTo:create(1,255)
			local sequence = CCSequence:createWithTwoActions(fadeout,fadein)
			local repeatever = CCRepeatForever:create(sequence)
			imgborder:runAction(repeatever)
		end
	else --δ��ļ
		obj._maxInfoCnt = obj._s_cfg.infoCnt
		obj:egHideWidget(kImgMember)
		obj:egHideWidget(kLblMember)
		obj:egHideWidget(kImgHeroLv)
		obj:egHideWidget(kImgEquipLv)
		obj:egHideWidget(kBtnEquip)
		obj:egHideWidget(kImgEquipBg)
		obj:egChangeImg(kImgEquip,equipCfg[obj._heroid*100+1].icon,UI_TEX_TYPE_PLIST)
		if obj._msgNum == 0 then --δ����
			obj:egSetLabelStr(kLblName, "???")
			obj:egSetLabelStr(kLblMsgNum,string.format("%s:00/??",TxtList.msg))
			obj:egSetWidgetColor(kBtnPhoto,kGrayColor)
			obj:egSetWidgetColor(kImgEquip,kBlackColor)
			obj:egSetWidgetTouchEnabled(kBtnPhoto,false)--���ܲ鿴��ϸ��Ϣ
			obj:egSetWidgetEnabled(kBtnClick,false) --���ܹ�Ӷ�����
			obj:egHideWidget(kImgReady) --û�б߿���ʾ
		elseif obj._msgNum < obj._maxInfoCnt then --��Ϣ�����������ļ
			obj:egHideWidget(kImgReady)--����ʾ��ʾ�߿�
			obj:egSetLabelStr(kLblName, obj._s_cfg.heroName)
			obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,obj._msgNum,obj._maxInfoCnt))
			obj:egSetWidgetTouchEnabled(kBtnPhoto,true)
			obj:egSetWidgetEnabled(kBtnClick,true)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[6]) --�ؽ��Ӷ
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[6])
		else--������ļ
			obj:egSetLabelStr(kLblName, obj._s_cfg.heroName)
			obj:egShowWidget(kImgReady)--��ʾ��ʾ�߿�
			obj:egSetWidgetColor(kImgReady,kGreenColor)
			obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,obj._msgNum,obj._maxInfoCnt))
			obj:egSetWidgetTouchEnabled(kBtnPhoto,true)
			obj:egSetWidgetEnabled(kBtnClick,true)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[5]) --��ļ
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[5])
			local imgborder = obj:egGetWidgetByName(kImgReady)
			local fadeout = CCFadeTo:create(1,64)
			local fadein = CCFadeTo:create(1,255)
			local sequence = CCSequence:createWithTwoActions(fadeout,fadein)
			local repeatever = CCRepeatForever:create(sequence)
			imgborder:runAction(repeatever)
		end
	end 
end
--����Ӣ�۽��׵ȼ�
function __pubhero.loadHeroGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
--��ʾ�߿��£Ч��
function __pubhero.showReadyAction(obj,color)
    obj:egSetWidgetTouchEnabled(kBtnClick,false)
    local imgborder = obj:egGetWidgetByName(kImgReady)
	imgborder:setColor(color)
	imgborder:setVisible(true)
    imgborder:setScale(1.3)
    imgborder:setOpacity(0)
    local fadeout1 = CCFadeIn:create(0.5)
    local scaleto1 = CCScaleTo:create(0.5,1)
    local spawn = CCSpawn:createWithTwoActions(fadeout1,scaleto1)
    local function callback()
        obj:egSetWidgetTouchEnabled(kBtnClick,true)
        local fadeout = CCFadeTo:create(1,64)
        local fadein = CCFadeTo:create(1,255)
        local sequence = CCSequence:createWithTwoActions(fadeout,fadein)
        local repeatever = CCRepeatForever:create(sequence)
        imgborder:runAction(repeatever)
    end
    local callfunc = CCCallFunc:create(callback)
    
    local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
    imgborder:runAction(sequence)
end
--��Ϣ�����仯ʱ���ã�publayer.lua��
function __pubhero.updateHeroMsg(obj)
    obj._msgNum = account_data.heroInfoList[obj._heroid] or 0
	if obj._msgChangedCallback then  obj._msgChangedCallback(obj) end
	if obj._herodata then
		local curGrade = obj._herodata.grade or 0 --��ǰ���׵ȼ�
		--obj:loadHeroGrade(curGrade) --����Ӣ�۽��׵ȼ�
		obj._maxInfoCnt = jewelCalc.getUpGradeMsg(curGrade)--�´ν���������Ϣ����
		obj:egSetLabelStr(kLblMsgNum,string.format("%02d/%02d",obj._msgNum,obj._maxInfoCnt))
		if obj._msgNum >= obj._maxInfoCnt then
			obj:showReadyAction(kRedColor)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[7]) --����
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[7])
		else
			local imgborder = obj:egGetWidgetByName(kImgReady)
			imgborder:stopAllActions()
			imgborder:setVisible(false)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[8]) --�ؽ����
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[8])
		end
	else
		obj._maxInfoCnt = obj._s_cfg.infoCnt
		obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,obj._msgNum,obj._maxInfoCnt))
		if obj._msgNum >= obj._maxInfoCnt then
			obj:showReadyAction(kGreenColor)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[5]) --��ļ
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[5])
		else
			local imgborder = obj:egGetWidgetByName(kImgReady)
			imgborder:stopAllActions()
			imgborder:setVisible(false)
			obj:egSetLabelStr(kLblClick,TxtList.btnTxt[6]) --�ؽ��Ӷ
			obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[6])
		end
	end   
end
--��һ�λ��Ӣ����Ϣʱ���ã���publayer.lua��
function __pubhero.unlockHeroInfo(obj)
    local photo = obj:egGetWidgetByName(kBtnPhoto)
    local equip = obj:egGetWidgetByName(kImgEquip)
    photo:runAction(CCTintTo:create(0.3,255,255,255))
    equip:runAction(CCTintTo:create(0.3,255,255,255))
    obj._msgNum = account_data.heroInfoList[obj._heroid] or 0
	if obj._msgChangedCallback then  obj._msgChangedCallback(obj) end
    obj:egSetLabelStr(kLblName, obj._s_cfg.heroName)
    obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,obj._msgNum,obj._maxInfoCnt))
    obj:egSetWidgetTouchEnabled(kBtnPhoto,true)
    obj:egSetWidgetEnabled(kBtnClick,true)
    if obj._msgNum >= obj._maxInfoCnt then
        obj:showReadyAction(kGreenColor)
		obj:egSetLabelStr(kLblClick,TxtList.btnTxt[5]) --��ļ
		obj:egSetLabelStr(kLblClicks,TxtList.btnTxt[5])
    end    
end
function __pubhero.onHeroMsgChanged(obj,callback)
    obj._msgChangedCallback = callback
end
--�鿴��Ϣ��ϸ
function __pubhero.bindCardListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
        --����Ϣͨ��Ԥ��ҳ��
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnPhoto,nil,nil,touchEnded,touchCanceled)
end
--������ס���ļ
function __pubhero.bindClickListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if account_data.heroList[obj._heroid] then --����
			if obj._msgNum >= obj._maxInfoCnt then
				SoundHelper.playEffect(SoundList.buy_hero_01)
				--���ͽ������������
				SendMsg[934016](obj._heroid)
				obj:doAfterHeroUpGrade()
			else
				SoundHelper.playEffect(SoundList.click_shop_goods)
				local cost = jewelCalc.getUpGradeJewel(obj._msgNum,obj._maxInfoCnt)
				if cost > account_data.jewel then
					showPopCharge(cost,function()sender:setTouchEnabled(true) end)
				else
					local layer = ConfirmHire.new(obj._heroid,function()sender:setTouchEnabled(true) end)
					obj:bindUpgradeCallback(layer)
					local scene = CCDirector:sharedDirector():getRunningScene()
					scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
				end
			end
		else --��ļ
			if obj._msgNum >= obj._maxInfoCnt then
				SoundHelper.playEffect(SoundList.buy_hero_01)
				--�������������
				SendMsg[934005](obj._heroid)
				obj:doAfterHeroInvited()
			else
				SoundHelper.playEffect(SoundList.click_shop_goods)
				local cost = jewelCalc.getMsgforHero(obj._msgNum,obj._maxInfoCnt)
				if cost > account_data.jewel then
					showPopCharge(cost,function()sender:setTouchEnabled(true) end)
				else
					local layer = ConfirmHire.new(obj._heroid,function()sender:setTouchEnabled(true) end)
					obj:bindHireCallback(layer)
					local scene = CCDirector:sharedDirector():getRunningScene()
					scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
				end
				
			end
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClick,nil,nil,touchEnded,touchCanceled)
end
function __pubhero.bindUpgradeCallback(obj,layer)
	local function callback()
		local cost = jewelCalc.getUpGradeJewel(obj._msgNum,obj._maxInfoCnt)
		--�����ؽ����������������
		SendMsg[934017](obj._heroid)
		account_data.jewel = account_data.jewel - cost
		obj:doAfterHeroUpGrade()
	end
	layer:onConfirmed(callback)
end
function __pubhero.bindHireCallback(obj,layer)
	local function callback()
		local cost = jewelCalc.getMsgforHero(obj._msgNum,obj._maxInfoCnt)
		SendMsg[934008](obj._heroid,cost)
		account_data.jewel = account_data.jewel - cost
		obj:doAfterHeroInvited()
	end
	layer:onConfirmed(callback)
end
--������Ӣ�ۺ��޸��ʻ�����
function __pubhero.doAfterHeroInvited(obj)
    --�ھ���־������̸���,�����ļ
	task.updateTaskStatus(account_data,task.client_event_id.buy_hero,{obj._heroid})
	local herodata = hero_data.get(obj._heroid,1)
	local tb = {type =obj._heroid,lv = 1,eid = obj._heroid*100 + 1,exp=herodata.exp,grade = 0}
	account_data.heroList[obj._heroid] = tb
	account_data.equipments[tb.eid]={1,1}
	obj._herodata = account_data.heroList[obj._heroid]
	account_data.heroInfoList[obj._heroid] = math.max(obj._msgNum - obj._maxInfoCnt,0)
	
	obj:egShowWidget(kImgMember)
	obj:egShowWidget(kLblMember)
	obj:egShowWidget(kImgHeroLv)
	obj:egShowWidget(kImgEquipLv)
	obj:egShowWidget(kBtnEquip)
	obj:egShowWidget(kImgEquipBg)
	obj:egSetBMLabelStr(kLblHeroLv,obj._herodata.lv)
	local equiplv,equipqa = equipFuncs.getEquipQL(obj._herodata.eid, account_data)
	obj:egSetBMLabelStr(kLblEquipLv,equiplv)
	obj:egSetWidgetColor(kImgEquipBg,KVariantList.equipColor[equipqa])
	----------------------------------------------------------
	local popherocard = PopHeroCard.new(obj._heroid,function() obj:egSetWidgetTouchEnabled(kBtnClick,true) end)
	local scene = CCDirector:sharedDirector():getRunningScene()
	scene:addChild(popherocard:egNode(),UILv.popLayer,UILv.popLayer)
	obj:updateHeroMsg()
end
function __pubhero.doAfterHeroUpGrade(obj)
	account_data.heroInfoList[obj._heroid] = math.max(obj._msgNum - obj._maxInfoCnt,0)
	account_data.heroList[obj._heroid].grade = (account_data.heroList[obj._heroid].grade or 0) + 1
	obj:loadHeroGrade(account_data.heroList[obj._heroid].grade)
	obj._maxInfoCnt = jewelCalc.getUpGradeMsg(account_data.heroList[obj._heroid].grade)--�´ν���������Ϣ����
	-----------------
	local popherocard = PopHeroCard.new(obj._heroid,function() obj:egSetWidgetTouchEnabled(kBtnClick,true) end)
	local scene = CCDirector:sharedDirector():getRunningScene()
	scene:addChild(popherocard:egNode(),UILv.popLayer,UILv.popLayer)
	obj:updateHeroMsg()
end
PubHero={}
function PubHero.new(heroid)
    local obj = {}
    CocosWidget.install(obj,JsonList.pubHero)
    table_aux.unpackTo(__pubhero, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(heroid)
    obj:bindCardListener()
    obj:bindClickListener()
    return obj
end


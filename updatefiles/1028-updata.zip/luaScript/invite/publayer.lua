local kBtnBack = "btn_return"
local kImgBack = "img_return"
local kBtnClose = "btn_close"
local kLblPub = "lbl_pub"
--��Ϣ��̽���
local kBtnAsk= "btn_askmsg"
local kLblAskVal = "lbl_ask_coin"
local kLblTime="lbl_note_ask"
local kImgAskCoin = "img_ask_coin"
local kPanelFree = "free_panel"
--���б������
local kBtnBox = "btn_box"
local kLblBoxVal = "lbl_box_coin"
local kPanelFree1 = "free_panel1"
local kLblTime1 = "lbl_note_box"
local kImgBoxCoin = "img_box_coin"
--���ر������
local kBtnBuy = "btn_buymsg"
local kLblBuyVal = "lbl_buy_coin"
--��ʯ�������
local kBtnRes = "btn_res"
local kLblResVal = "lbl_res_coin"

--Ӣ���б�
local kItemList = "itemlist"
local kCellW = 160
local kMaxNum = 7
local kRedColor = ccc3(255,0,0)

local __publayer={}
function __publayer.init(obj,areaid)
    obj._pubherolist = {}
    obj._freeCounter = obj:egGetLabelStr(kLblTime)
	local btnbuy = tolua.cast(obj:egGetWidgetByName(kBtnBuy),"Button")
	btnbuy:setPressedActionEnabled(true)
	local btnbox = tolua.cast(obj:egGetWidgetByName(kBtnBox),"Button")
	btnbox:setPressedActionEnabled(true)
	local btnres = tolua.cast(obj:egGetWidgetByName(kBtnRes),"Button")
	btnres:setPressedActionEnabled(true)
    obj:changeAskBtnState()
    obj:changeBuyBtnState()
    obj:changeBoxBtnState()
	obj:changeResBtnState()
    obj:doLoading()
end
--�޸���Ϣ��̽��ť״̬
function __publayer.changeAskBtnState(obj)
    if account_data.freeMsgExpire > os.time() then
        obj:egShowWidget(kImgAskCoin)
        obj:egShowWidget(kLblAskVal)
		obj:egHideWidget(kPanelFree)
        obj:egSetLabelStr(kLblTime,string.format("%s%s",Funs.formatTime(account_data.freeMsgExpire-os.time()),obj._freeCounter))
        obj:egSetLabelStr(kLblAskVal,numDef.askMsgPrice)
        if account_data.jewel < numDef.askMsgPrice then
            obj:egSetWidgetColor(kLblAskVal,kRedColor)
            obj:egSetWidgetEnabled(kBtnAsk,false)
        end
        obj:bindMsgTimer()
    else
		obj:egShowWidget(kPanelFree)
        obj:egSetLabelStr(kLblTime,TxtList.heroMsgBoxNote)
        obj:egHideWidget(kImgAskCoin)
        obj:egHideWidget(kLblAskVal)
        obj:egSetWidgetEnabled(kBtnAsk,true)
    end
end
--�޸ĺ��б��䰴ť״̬
function __publayer.changeBoxBtnState(obj)
	if account_data.freeBoxExpire > os.time() then
		obj:egShowWidget(kImgBoxCoin)
        obj:egShowWidget(kLblBoxVal)
		obj:egHideWidget(kPanelFree1)
        obj:egSetLabelStr(kLblTime1,string.format("%s%s",Funs.formatTime(account_data.freeBoxExpire-os.time()),obj._freeCounter))
        obj:egSetBMLabelStr(kLblBoxVal,numDef.openBoxPrice)
        if account_data.jewel < numDef.openBoxPrice then
            obj:egSetWidgetColor(kLblBoxVal,kRedColor)
			obj:egSetWidgetTouchEnabled(kBtnBox,false)
        end
        obj:bindBoxTimer()
	else
		obj:egShowWidget(kPanelFree1)
        obj:egSetLabelStr(kLblTime1,TxtList.gEquipBoxNote)
        obj:egHideWidget(kImgBoxCoin)
        obj:egHideWidget(kLblBoxVal)
        obj:egSetWidgetEnabled(kBtnBox,true)
	end
	
end
--�޸����ر��䰴ť״̬
function __publayer.changeBuyBtnState(obj)
    obj:egSetBMLabelStr(kLblBuyVal,numDef.buyMsgPrice)
    if account_data.jewel < numDef.buyMsgPrice then
        obj:egSetWidgetColor(kLblBuyVal,kRedColor)
        obj:egSetWidgetTouchEnabled(kBtnBuy,false)
    end
end
--�޸ı�ʯ���䰴ť״̬
function __publayer.changeResBtnState(obj)
    obj:egSetBMLabelStr(kLblResVal,numDef.openResBoxPrice)
    if account_data.jewel < numDef.openResBoxPrice then
        obj:egSetWidgetColor(kLblResVal,kRedColor)
        obj:egSetWidgetTouchEnabled(kBtnRes,false)
    end
end
--��ʯ���ݱ仯���޸İ�ť�������
function __publayer.changeAllBtnState(obj,clickedBtn)
	obj:egSetWidgetTouchEnabled(clickedBtn,true)
	if account_data.jewel < numDef.openResBoxPrice then
		obj:egSetWidgetColor(kLblResVal,kRedColor)
		obj:egSetWidgetEnabled(kBtnRes,false)
	else
		obj:egSetWidgetEnabled(kBtnRes,true)
	end
	if account_data.jewel < numDef.buyMsgPrice then
		obj:egSetWidgetColor(kLblBuyVal,kRedColor)
		obj:egSetWidgetEnabled(kBtnBuy,false)
	else
		obj:egSetWidgetEnabled(kBtnBuy,true)
	end
	 if account_data.freeMsgExpire > os.time() then
		if account_data.jewel < numDef.askMsgPrice then
			obj:egSetWidgetColor(kLblAskVal,kRedColor)
			obj:egSetWidgetEnabled(kBtnAsk,false)
		else
			obj:egSetWidgetEnabled(kBtnAsk,true)
		end
	end
	if account_data.freeBoxExpire> os.time() then
		if account_data.jewel < numDef.openBoxPrice then
			obj:egSetWidgetColor(kLblBoxVal,kRedColor)
			obj:egSetWidgetEnabled(kBtnBox,false)
		else
			obj:egSetWidgetEnabled(kBtnBox,true)
		end
	end
end
--��ȡ����Ϣ��������Ӣ���б�
function __publayer.getOrderedHeroId(obj)
    local canInviteTb = {}
	local canNotInviteTb={}
	local canUpgradeTb = {}
	local canNotUpgradeTb = {}
	local msglist = {}
	local gradelist = {}
    for heroid ,_ in pairs(heroNumData) do
		local cfg = hero_data.getConfig(heroid)
		if cfg then --��������Ӧ����ʾ���Ե�Ӣ��
			local herodata = account_data.heroList[heroid]
			local msgNum = account_data.heroInfoList[heroid] or 0
			if herodata then --����ļ
				local curGrade = herodata.grade or 0
				local maxInfoCnt = jewelCalc.getUpGradeMsg(curGrade)--�´ν���������Ϣ����
				if msgNum - maxInfoCnt >= 0 then --�ɽ���
					gradelist[heroid] = curGrade
					msglist[heroid] = msgNum
					table.insert(canUpgradeTb,heroid) --�ɽ����б�
				else --���ɽ���
					gradelist[heroid] = curGrade
					msglist[heroid] = maxInfoCnt - msgNum
					table.insert(canNotUpgradeTb,heroid)
				end
			else --δ��ļ
				local maxInfoCnt = cfg.infoCnt --��ļ������Ϣ��
				if msgNum - maxInfoCnt >= 0 then --����ļ
					msglist[heroid] = msgNum
					table.insert(canInviteTb,heroid) --����ļ�б�
				else --������ļ
					if msgNum > 0 then
						msglist[heroid] = maxInfoCnt - msgNum
					else
						msglist[heroid] = 10000 + maxInfoCnt
					end
					
					table.insert(canNotInviteTb,heroid)
				end
			end
		end
    end
    table.sort(canInviteTb,function(a,b) return msglist[a] > msglist[b] end)
	table.sort(canNotInviteTb,function(a,b) return msglist[a] < msglist[b] end)
	table.sort(canUpgradeTb,function(a,b) return (gradelist[a] > gradelist[b])or(gradelist[a] == gradelist[b] and msglist[a] > msglist[b]) end)
	table.sort(canNotUpgradeTb,function(a,b) return (gradelist[a] > gradelist[b])or(gradelist[a] == gradelist[b] and msglist[a] < msglist[b]) end)
	for _,val in ipairs(canUpgradeTb) do
		table.insert(canInviteTb,val)
	end
	for _,val in ipairs(canNotUpgradeTb) do
		table.insert(canInviteTb,val)
	end
	for _,val in ipairs(canNotInviteTb) do
		table.insert(canInviteTb,val)
	end
	canUpgradeTb = nil
	canNotUpgradeTb = nil
	canNotInviteTb = nil
	msglist = nil
	gradelist = nil
	return canInviteTb
end
--����Ӣ�ۿ�Ƭ��Ϣ
function __publayer.loadHeroCard(obj)
    local itemlist = obj:egGetScrollView(kItemList)
    local size = itemlist:getSize()
	obj._loadedCnt = 0
	obj._loadedW = 0
    obj._orderedHeroId = obj:getOrderedHeroId()
    local cnt = #obj._orderedHeroId
    local neww = cnt * kCellW
    if neww > size.width then
        itemlist:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
	while obj._loadedCnt < kMaxNum do
		obj:addPubHero(1)
		coroutine.yield()
	end
	obj:bindScrollListener()
end
function __publayer.doLoading(obj)
	local function coFunc()
		obj:loadHeroCard()
	end
	local coLoad = coroutine.create(coFunc)
	local function callback()
		local f1,f2 = coroutine.resume(coLoad)
		if not f1 then
			obj:egUnbindWidgetUpdate(kLblPub)
			if type(f2) == "string" then	print(f2) end
		end
	end
	obj:egBindWidgetUpdate(kLblPub,callback)
end
--������Ӧ�¼�
function __publayer.bindScrollListener(obj)
   local scrollview =  obj:egGetScrollView(kItemList)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadedCnt >= #obj._orderedHeroId then return end
            local innerContainer = scrollview:getInnerContainer()
            local posX = innerContainer:getPositionX()
            if obj._loadedW + posX  < scrollview:getSize().width then
                obj:addPubHero(1)
            end
        end
    end
    scrollview:addEventListenerScrollView(scrollEvent)
end
--����ָ��������Ӣ�ۿ�Ƭ
function __publayer.addPubHero(obj,num)
	 local itemlist = obj:egGetScrollView(kItemList)
	for idx = 1,num do
		local heroid = obj._orderedHeroId[obj._loadedCnt + 1] 
		if not heroid then return end
		local pubhero = PubHero.new(heroid)
        pubhero:egSetPosition(obj._loadedW,0)
        obj._pubherolist[heroid] = pubhero
        itemlist:addChild(pubhero:egNode())
		obj._loadedCnt = obj._loadedCnt +1
		obj._loadedW = obj._loadedCnt*kCellW
		obj:bindHeroMsgChangedCallback(pubhero)
	end
end
--���µ���Ӣ�ۿ�Ƭλ��,�������Ϣ����ļ�����
function __publayer.reOrderPubHeros(obj)
	local itemlist = obj:egGetScrollView(kItemList)
	obj._orderedHeroId = obj:getOrderedHeroId()
	for idx,heroid in ipairs(obj._orderedHeroId) do
		if idx > obj._loadedCnt then return end
		local pubhero = obj._pubherolist[heroid]
		if pubhero then
			pubhero:egSetPosition((idx-1)*kCellW,0)
		else
			local pubhero = PubHero.new(heroid)
			pubhero:egSetPosition((idx-1)*kCellW,0)
			obj._pubherolist[heroid] = pubhero
			itemlist:addChild(pubhero:egNode())
			obj._loadedCnt = obj._loadedCnt +1
			obj._loadedW = obj._loadedCnt*kCellW
			obj:bindHeroMsgChangedCallback(pubhero)
		end
	end
end
--Ӣ����Ϣ���������䶯��Ĵ�������
function __publayer.bindHeroMsgChangedCallback(obj,pubhero)
    local function callback(heroid)
        obj:reOrderPubHeros()
    end
    pubhero:onHeroMsgChanged(callback)
end
--�󶨺��б��䰴ť��ʱ��
function __publayer.bindBoxTimer(obj)
    local function update(delta)
        if account_data.freeBoxExpire > os.time() then
            obj:egSetLabelStr(kLblTime1,string.format("%s%s",Funs.formatTime(account_data.freeBoxExpire-os.time()),obj._freeCounter))
        else
            obj:egUnbindWidgetUpdate(kBtnBox)
			obj:changeBoxBtnState()
        end
    end
    obj:egBindWidgetUpdate(kBtnBox,update)
end
--����Ϣ��̽��ť��ʱ��
function __publayer.bindMsgTimer(obj)
    local function update(delta)
        if account_data.freeMsgExpire > os.time() then
            obj:egSetLabelStr(kLblTime,string.format("%s%s",Funs.formatTime(account_data.freeMsgExpire-os.time()),obj._freeCounter))
        else
            obj:egUnbindWidgetUpdate(kBtnAsk)
			obj:changeAskBtnState()
        end
    end
    obj:egBindWidgetUpdate(kBtnAsk,update)
end
--��һ�λ��Ӣ����Ϣ�Ĵ�������
function __publayer.bindFirstGainCallback(obj,popmail)
    local function callback(heroid)
        if obj._pubherolist[heroid] then 
            obj._pubherolist[heroid]:unlockHeroInfo()
		else
			 obj:reOrderPubHeros()
        end
    end
    popmail:onFirstGainHeroMsg(callback)
end
--���Ӣ����Ϣʱ�Ĵ�������
function __publayer.bindGainMsgCallback(obj,popmail)
    local function callback(heroid)
        if obj._pubherolist[heroid] then
            obj._pubherolist[heroid]:updateHeroMsg()
		else
			 obj:reOrderPubHeros()
        end
    end
    popmail:onGainHeroMsg(callback)
end

--�ֽ⽱����Ϣ��ϸ��ΪӢ����Ϣ����Դ
function __publayer.splitAwardinfo(obj,res,heromsg,equip)
    local msglist = {}
	local reslist = {}
	local equiplist = {}
	for heroid,msgnum in pairs(heromsg or {}) do
		if msgnum > 0 then
			table.insert(msglist,heroid)
			table.insert(msglist,msgnum)
		end
	end
	for cointype,coinval in pairs(res or {}) do
		if coinval > 0 then
			table.insert(reslist,KVariantList.coinName[cointype])
			table.insert(reslist,coinval)
		end
	end
	for key,equipinfo in ipairs(equip or {}) do
		table.insert(equiplist,equipFuncs.getSubEquipId(equipinfo[1],equipinfo[2],equipinfo[3]))
	end
	return reslist,msglist,equiplist
end
--��Ϣ��̽��ť
function __publayer.bindAskMsgListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
        local reslist,msglist,equiplist = obj:splitAwardinfo(jewelCalc.getMsgPrize(account_data))
        if account_data.freeMsgExpire > os.time() then--��Ǯ
			account_data.jewel = account_data.jewel - numDef.askMsgPrice
			--������Ϣ��������
			SendMsg[934007](numDef.askMsgPrice,msglist,reslist,equiplist)
		else --���
			account_data.freeMsgExpire = os.time()+ numDef.inviteInterval --�޸����ˢ��ʱ��
			obj:changeAskBtnState()--�޸İ�ť״̬
			--������Ϣ��������
			SendMsg[934006](1,msglist,reslist,equiplist)
		end
		--�ھ���־������̸���,��Ϣ��̽
		task.updateTaskStatus(account_data,task.client_event_id.use_message_box)
		----------------------------------------------------------
        local function onPopMailLoaded()
			obj:changeAllBtnState(kBtnAsk)
        end
        local popmail = PopMail.new(reslist,msglist,equiplist,sender:getPositionX(),sender:getPositionY(),onPopMailLoaded,1)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmail:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindGainMsgCallback(popmail)
        obj:bindFirstGainCallback(popmail)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAsk,nil,nil,touchEnded,touchCanceled)
end
--���б���
function __publayer.bindBoxListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_buy_button)
        local reslist,msglist,equiplist = obj:splitAwardinfo(jewelCalc.getJewelChest(account_data))
		 if account_data.freeBoxExpire > os.time() then--��Ǯ
			account_data.jewel = account_data.jewel - numDef.openBoxPrice
			--������Ϣ��������
			SendMsg[934007](numDef.openBoxPrice,msglist,reslist,equiplist)
		else --���
			account_data.freeBoxExpire = os.time()+ numDef.boxInterval --�޸����ˢ��ʱ��
			obj:changeBoxBtnState()--�޸İ�ť״̬
			--������Ϣ��������
			SendMsg[934006](2,msglist,reslist,equiplist)
		end
        local function onPopMailLoaded()
			obj:changeAllBtnState(kBtnBox)
        end
        local popmail = PopMail.new(reslist,msglist,equiplist,sender:getPositionX(),sender:getPositionY(),onPopMailLoaded,2)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmail:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindGainMsgCallback(popmail)
        obj:bindFirstGainCallback(popmail)
    end
    obj:egBindTouch(kBtnBox,nil,nil,touchEnded,nil)
end
--���ر��䰴��
function __publayer.bindBuyMsgListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
        account_data.jewel = account_data.jewel - numDef.buyMsgPrice --��Ǯ
        local function onPopMailLoaded()
			obj:changeAllBtnState(kBtnBuy)
        end
        local reslist,msglist,equiplist = obj:splitAwardinfo(jewelCalc.getMsglargePrize(account_data))
        --������Ϣ��������
        SendMsg[934007](numDef.buyMsgPrice,msglist,reslist,equiplist)
        local popmail = PopMail.new(reslist,msglist,equiplist,sender:getPositionX(),sender:getPositionY(),onPopMailLoaded,3)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmail:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindGainMsgCallback(popmail)
        obj:bindFirstGainCallback(popmail)
        --����Ϣ��������
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBuy,nil,nil,touchEnded,touchCanceled)
end
--��ʯ�����ھ�
function __publayer.bindResBoxListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
        local reslist,msglist,equiplist = obj:splitAwardinfo(jewelCalc.getResBoxPrize(account_data))
		account_data.jewel = account_data.jewel - numDef.openResBoxPrice
			--������Ϣ��������
		SendMsg[934007](numDef.openResBoxPrice,msglist,reslist,equiplist)
		----------------------------------------------------------
        local function onPopMailLoaded()
			obj:changeAllBtnState(kBtnRes)
        end
        local popmail = PopMail.new(reslist,msglist,equiplist,sender:getPositionX(),sender:getPositionY(),onPopMailLoaded,3)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmail:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindGainMsgCallback(popmail)
        obj:bindFirstGainCallback(popmail)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnRes,nil,nil,touchEnded,touchCanceled)
end
--���ذ�ť
function __publayer.bindBackListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBack,1.1)
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetScale(kImgBack,1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
		local totalBp = RiskHelper.getTotalBp()
		if account_data.teamBp ~= totalBp then
			account_data.teamBp = totalBp
			SendMsg[934018](totalBp)
		end
        local scene = TownScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBack,1)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
PubLayer={}
function PubLayer.new()
    local obj =  TouchWidget.new(JsonList.pubLayer)
    table_aux.unpackTo(__publayer, obj)
    obj:init()
    obj:bindBackListener()
    obj:bindBuyMsgListener()
    obj:bindAskMsgListener()
    obj:bindBoxListener()
	obj:bindResBoxListener()
    return obj
end


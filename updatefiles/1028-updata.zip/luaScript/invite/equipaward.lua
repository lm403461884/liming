local kImgBg = "img_equip_bg"
local kImgItem = "img_item"
local kLblLv = "lbl_lv"
local kImgColorBg = "img_color_bg"
local kSx = 640
local kSy = 345
local __equipaward = {}
function __equipaward.init(obj,equpid)
	local subid,sublv,subseed,subqa = Funs.deComposeInt(equpid,256,4)
    obj:egChangeImg(kImgItem, equipFuncs.getSubEquipCfg(subid,"icon"),UI_TEX_TYPE_PLIST)
	 obj:egSetBMLabelStr(kLblLv,sublv) --显示武器等级
     --显示武器品质
	obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[subqa])
end
function __equipaward.scaleAndShow(obj,callbackfunc)
	obj:scaleAndShowWithSrc(kSx,kSy,callbackfunc)
end
function __equipaward.scaleAndShowWithSrc(obj,srcx,srcy,callbackfunc)
	local widget = obj:egGetWidgetByName(kImgBg)
	local x = obj:egNode():getPositionX()
	local oldx = widget:getPositionX()
	local oldy = widget:getPositionY()
	local sx = srcx - x
	widget:setPosition(ccp(sx,srcy))
	local scaleto = CCScaleTo:create(0.2,1.5)
	local moveto = CCMoveTo:create(0.2,ccp(oldx,oldy))
	local array = CCArray:create()
	array:addObject(scaleto)
	array:addObject(moveto)
	local spawn = CCSpawn:create(array)
	local function callback()
	    callbackfunc()
	end
	local callfunc = CCCallFunc:create(callback)
	local scaleto1 = CCScaleTo:create(0.1,1)
	--local bouceout = CCEaseBounceOut:create(scaleto1)
	local delay = CCDelayTime:create(0.3)
	local array1 = CCArray:create()
	array1:addObject(spawn)
	array1:addObject(scaleto1)
	array1:addObject(delay)
	array1:addObject(callfunc)
	local sequence = CCSequence:create(array1)
	widget:runAction(sequence)
end
function __equipaward.blinkItemImg(obj,s,t)
	local widget = obj:egGetWidgetByName(kImgItem)
	widget:stopAllActions()
	widget:setVisible(true)
	widget:setOpacity(255)
	widget:runAction(CCBlink:create(s,t))
end
function __equipaward.blinkItemLbl(obj,s,t)
	local widget = obj:egGetWidgetByName(kLblLv)
	widget:stopAllActions()
	widget:setVisible(true)
	widget:setOpacity(255)
	widget:runAction(CCBlink:create(s,t))
end
EquipAward={}
function EquipAward.new(equipid)
    local obj = {}
    CocosWidget.install(obj,JsonList.equipAward)
    table_aux.unpackTo(__equipaward, obj)
    obj:init(equipid)
    return obj
end

local kBtnClose="btn_close"
local kCardPanel = "card_panel"
local kImgLight = "img_light"
local kImgMask = "img_dark_mask"
local kLblName = "lbl_name"
local kImgPhoto = "img_photo"
local kImgEquip = "img_item"
local kLblAtk = "lbl_atk_val"
local kImgCard = "member_bg"
local kLblMsg = "lbl_msg"
local kImgEquipBg = "img_color_bg"
local kLblEquipLv = "lbl_equip_lv"
local kLblLv = "lbl_lv"
local kPanelStars = "star_list"
local __popherocard={}
function __popherocard.init(obj,heroid)
  --��ʾ�ŷ���ʾ��
    obj._heroid = heroid
	obj._herodata = account_data.heroList[obj._heroid]
	local s_cfg =  hero_data.getConfig(obj._heroid)
	obj:egSetLabelStr(kLblName,s_cfg.heroName)
	obj:egChangeImg(kImgPhoto,s_cfg.photo,UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblLv,obj._herodata.lv)
	local equiplv,equipqa = equipFuncs.getEquipQL(obj._herodata.eid, account_data)
	obj:egSetBMLabelStr(kLblEquipLv,equiplv)
	obj:egSetWidgetColor(kImgEquipBg,KVariantList.equipColor[equipqa])
	obj:egChangeImg(kImgEquip,equipCfg[obj._herodata.eid].icon,UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblAtk,RiskHelper.getHeroBp( obj._herodata,account_data))
	obj._herodata.grade = obj._herodata.grade or 0
	if obj._herodata.grade > 0 then
		obj:egSetLabelStr(kLblMsg,string.format(TxtList.succPromoteHero,obj._herodata.grade or 0))
	else
		obj:egSetLabelStr(kLblMsg,TxtList.succInviteHero)
	end
    obj:egHideWidget(kBtnClose)
    obj:showWidthAction()
end
function __popherocard.loadHeroGrade(obj)
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx = 1,obj._herodata.grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
		if idx == obj._herodata.grade then
			img:setScale(5)
			local backout = CCEaseBackOut:create(CCScaleTo:create(0.5,1))
			local function callback()
				obj:egShowWidget(kBtnClose)
			end
			local callfunc = CCCallFunc:create(callback)
			local sequence = CCSequence:createWithTwoActions(backout,callfunc)
			img:runAction(sequence)
		end
	end
end
function __popherocard.showWidthAction(obj)
    local cardbg = obj:egGetWidgetByName(kImgCard)
    cardbg:setScale(0)
    local scaleto = CCScaleTo:create(0.5,1)
    local backout = CCEaseBackOut:create(scaleto)
    local function callback()
		if  obj._herodata.grade > 0 then
			obj:loadHeroGrade()
		else
			obj:egShowWidget(kBtnClose)
		end
        local moveby1 = CCMoveBy:create(1,ccp(0,-10))
        local moveby2 = CCMoveBy:create(1,ccp(0,10))
        local sequence1 = CCSequence:createWithTwoActions(moveby1,moveby2)
        local repeatever = CCRepeatForever:create(sequence1)
        cardbg:runAction(repeatever)
        if obj._onloaded then obj._onloaded() end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(backout,callfunc)
    cardbg:runAction(sequence)
    
    local lightbg = obj:egGetWidgetByName(kImgLight)
    local rotateby1 = CCRotateBy:create(2,37.2)
    local scaleto1 = CCScaleTo:create(2,0.8)
    local rotateby2 = CCRotateBy:create(2,37.2)
    local scaleto2 = CCScaleTo:create(2,1)
    local spawn1 = CCSpawn:createWithTwoActions(rotateby1,scaleto1)
    local spawn2 = CCSpawn:createWithTwoActions(rotateby2,scaleto2)
    local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
    local repeatever = CCRepeatForever:create(sequence)
    lightbg:runAction(repeatever)
    
    local widget = obj:egGetWidgetByName(kImgMask)
    widget:setOpacity(0)
    widget:runAction(CCFadeTo:create(0.2,180))
    local lblmsg = obj:egGetWidgetByName(kLblMsg)
    lblmsg:setScale(0)
    lblmsg:runAction(CCEaseBackOut:create(CCScaleTo:create(0.5,1)))
end
--�رհ�ť
function __popherocard.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

PopHeroCard={}
function PopHeroCard.new(heroid,onloaded)
    local obj =  TouchWidget.new(JsonList.popHeroCard)
    table_aux.unpackTo(__popherocard, obj)
    obj._onloaded = onloaded
    obj:init(heroid)
    obj:bindCloseListener()
    return obj
end

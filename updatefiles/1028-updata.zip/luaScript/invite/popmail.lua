local kBtnClose="btn_close"
local kImgMail = "img_mail"
local kImgMask = "img_dark_mask"
local kImgLight = "img_light"
local kAwardList = "award_list"

local kPoint0 = ccp(640,409)
local kPoint1=ccp(-25,-230)
local kStartW = 190
local kJumpH = 300
local kCardW = 150
local kItemW = 142
local kEquipW = 142
local kMargin1 = 10
local kMargin2 = 15
local kMargin3 = 15
local __popmail={}
function __popmail.init(obj,reslist,msglist,equiplist,x,y)
  --��ʾ�ŷ���ʾ��
    obj._reslist = reslist
	obj._msglist = msglist
	obj._equiplist = equiplist
	obj._loadW = 0
    obj:egHideWidget(kBtnClose)
	obj:egHideWidget(kImgLight)
	if obj._boxType == 1 then --�ŷ�
		 obj:egChangeImg(kImgMail,ImageList.mail_closed)
	elseif obj._boxType == 2 then --���б���
	    obj:egChangeImg(kImgMail,ImageList.comm_box_equip,UI_TEX_TYPE_PLIST)
	else --���ر���
        obj:egChangeImg(kImgMail,ImageList.comm_box_mystery,UI_TEX_TYPE_PLIST)
    end
    local mail = obj:egGetWidgetByName(kImgMail)
    mail:setTouchEnabled(false)
    mail:setPosition(ccp(x,y))
    mail:setScale(kStartW/mail:getSize().width)
    obj:showWidthAction()
end
function __popmail.showWidthAction(obj)
     local mail = obj:egGetWidgetByName(kImgMail)
    local scaleto = CCScaleTo:create(0.5,1)
    local jumpto = CCJumpTo:create(0.5,kPoint0,kJumpH,1)
    local spawn = CCSpawn:createWithTwoActions(scaleto,jumpto)
    local function callback()
        mail:setTouchEnabled(true)
        local moveby1 = CCMoveBy:create(1,ccp(0,-20))
        local moveby2 = CCMoveBy:create(1,ccp(0,20))
        local sequence1 = CCSequence:createWithTwoActions(moveby1,moveby2)
        local repeatever = CCRepeatForever:create(sequence1)
        mail:runAction(repeatever)
        if obj._onloaded then obj._onloaded() end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
    mail:runAction(sequence)
    local widget = obj:egGetWidgetByName(kImgMask)
    widget:setOpacity(0)
    widget:runAction(CCFadeTo:create(0.2,180))
end
function __popmail.rotateAndShow(obj,awardItem,margin,callbackfunc)
	local panel = obj:egGetWidgetByName(kAwardList)
	local panelH = panel:getSize().height
	local panelW = panel:getSize().width
	local widget = awardItem:egNode()
	local widgetW = widget:getSize().width
	local widgetH = widget:getSize().height
	widget:setPosition(ccp(obj._loadW ,(panelH - widgetH)/2)) --���������ʾλ��
	awardItem:scaleAndShow(callbackfunc)
	panel:addChild(widget)	
	obj._loadW  = obj._loadW + (widgetW + margin)
end
function __popmail.loadResAward(obj)
	local function loadAwardByIdx(idx)
	    local cnt = idx * 2
        if cnt <=  #obj._reslist then
			SoundHelper.playEffect(SoundList.buy_message_01)
            local cointype = KVariantList.coinType[obj._reslist[cnt-1]]
            local num = obj._reslist[cnt]
            local resaward = ResAward.new(cointype,Funs.signedNum(num))
			account_data[cointype] = account_data[cointype] + num
            local function callback()
                idx = idx + 1
                loadAwardByIdx(idx)
            end
            obj:rotateAndShow(resaward,kMargin2,callback)
        else
            obj:egShowWidget(kBtnClose)
        end
	end
	loadAwardByIdx(1)
end
--����װ������,����ʾ����ǰ�޸��ʻ�
function __popmail.loadEquipAward(obj)
	local function loadAwardByIdx(idx)
        if idx <=  #obj._equiplist then
			SoundHelper.playEffect(SoundList.buy_message_01)
			local equipid = obj._equiplist[idx]
			account_data.equipSub[equipid] = (account_data.equipSub[equipid] or 0) + 1
            local equipaward = EquipAward.new(obj._equiplist[idx])
            obj:rotateAndShow(equipaward,kMargin3, function() loadAwardByIdx(idx + 1) end)
        else
           obj:loadResAward()
        end
		
	end
	loadAwardByIdx(1)
end
--���ػ�õ���Դ
function __popmail.loadAwardItems(obj)
    local cnt1 =#obj._msglist/2
    local cnt2 = #obj._reslist/2
	local cnt3 = #obj._equiplist
	local newW = cnt1*(kCardW + kMargin1) + cnt2*(kItemW +kMargin2 ) + cnt3*(kEquipW +kMargin3)
	local panel = obj:egGetWidgetByName(kAwardList)
	local size = panel:getSize()
	obj._loadW  = (size.width - newW)/2	
	local function loadAwardByIdx(idx)
	    local cnt = idx * 2
        if cnt <=  #obj._msglist then
            local heroid = obj._msglist[cnt-1]
            local msgnum = obj._msglist[cnt]
            local heromsg = HeroMsgAward.new(heroid,msgnum)
			SoundHelper.playEffect(SoundList.buy_message_01)
 			if not account_data.heroInfoList[heroid] or account_data.heroInfoList[heroid]==0 then --����û��ù�Ӣ����Ϣ
                account_data.heroInfoList[heroid] = msgnum
                if obj._firstGainCallback then obj._firstGainCallback(heroid) end
            else --��ù�Ӣ����Ϣ
                account_data.heroInfoList[heroid] =  account_data.heroInfoList[heroid] + msgnum
                if obj._gainHeroMsgCallback then obj._gainHeroMsgCallback(heroid) end
			end
            obj:rotateAndShow(heromsg,kMargin1, function()  loadAwardByIdx(idx + 1) end)
        else
             obj:loadEquipAward()
        end
    end
    loadAwardByIdx(1)
end
function __popmail.onFirstGainHeroMsg(obj,callback)
    obj._firstGainCallback = callback
end
function __popmail.onGainHeroMsg(obj,callback)
    obj._gainHeroMsgCallback = callback
end
function __popmail.showLight(obj)
	local lightbg = obj:egGetWidgetByName(kImgLight)
	lightbg:setVisible(true)
	lightbg:setEnabled(true)
    local rotateby1 = CCRotateBy:create(2,37.2)
    local scaleto1 = CCScaleTo:create(2,0.55)
    local rotateby2 = CCRotateBy:create(2,37.2)
    local scaleto2 = CCScaleTo:create(2,0.45)
    local spawn1 = CCSpawn:createWithTwoActions(rotateby1,scaleto1)
    local spawn2 = CCSpawn:createWithTwoActions(rotateby2,scaleto2)
    local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
    local repeatever = CCRepeatForever:create(sequence)
    lightbg:runAction(repeatever)
end
--�ŷ����¼�
function __popmail.bindMailListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_letter_open)
		
		sender:stopAllActions()
		sender:setScale(0.4)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		local lightbg = obj:egGetWidgetByName(kImgLight)
		local newpoint = ccp(lightbg:getPositionX(),lightbg:getPositionY())
		local jumpto = CCJumpTo:create(0.5,newpoint,100,1)
		local function callback()
			obj:showLight()
			if obj._boxType == 1 then --�ŷ�
				 obj:egChangeImg(kImgMail,ImageList.mail_opened)
			elseif obj._boxType == 2 then --���б���
				obj:egChangeImg(kImgMail,ImageList.comm_box_equip_open,UI_TEX_TYPE_PLIST)
			else --���ر���
				obj:egChangeImg(kImgMail,ImageList.comm_box_mystery_open,UI_TEX_TYPE_PLIST)
			end 
			obj:loadAwardItems()
		end
		local callfunc = CCCallFunc:create(callback)
		local sequence = CCSequence:createWithTwoActions(jumpto,callfunc)
		sender:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgMail,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __popmail.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_back_button)
        obj._reslist = nil
		obj._msglist = nil
		obj._equiplist = nil
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

PopMail={}
function PopMail.new(reslist,msglist,equiplist,x,y,onloaded,boxType)
    local obj =  TouchWidget.new(JsonList.popMail)
    table_aux.unpackTo(__popmail, obj)
    obj._onloaded = onloaded
    obj._boxType = boxType
    obj:init(reslist,msglist,equiplist,x,y)
    obj:bindMailListener()
    obj:bindCloseListener()
    return obj
end

local kBtnOk = "btn_ok"
local kBtnBack = "btn_back"
local kLblTitle = "lbl_title"
local kImgState = "img_item"
local kLblAtkName = "lbl_atk_name"
local kLblAtkElo = "lbl_atk_elo"
local kImgElo = "img_elo"
local kImgElo2 = "img_elo_Copy0"

local kLblDefName = "lbl_def_name"
local kLblDefElo = "lbl_def_elo"
local kPanelInfo = "panel_info"
local kPanelLayer = "panel_gvg_prompt"

local kPoint = ccp(-259,-213)
local __gvgprompt = {}
function __gvgprompt.init(obj,data)
    obj._data = data
    if obj._data.type == 0 then --��ʼ
	    obj:egSetLabelStr(kLblAtkElo,obj._data.atkStars)
	    obj:egSetLabelStr(kLblDefElo,obj._data.defStars)
	elseif obj._data.type == 1 then--����
	     obj:egSetLabelStr(kLblTitle,TxtList.gvgEnded)
	     obj:egHideWidget(kBtnOk)
	     local panelInfo = obj:egGetWidgetByName(kPanelInfo)
	     panelInfo:setPosition(kPoint)
	     obj:egChangeImg(kImgElo,ImageList.comm_club_elo,UI_TEX_TYPE_PLIST)
	     obj:egChangeImg(kImgElo2,ImageList.comm_club_elo,UI_TEX_TYPE_PLIST)
	     obj:egSetLabelStr(kLblAtkElo,obj._data.atkEloDlt)
	     obj:egSetLabelStr(kLblDefElo,obj._data.defEloDlt)
	elseif obj._data.type == 2 then--��ս��
	     obj:egSetLabelStr(kLblTitle,TxtList.gvgFighting)
	     obj:egSetLabelStr(kLblAtkElo,obj._data.atkStars)
	     obj:egSetLabelStr(kLblDefElo,obj._data.defStars)
	end
	obj:egSetLabelStr(kLblAtkName,obj._data.atkClubName)
	obj:egSetLabelStr(kLblDefName,obj._data.defClubName)

    if obj._data.atkClubName == obj._data.clubName then
		obj:egChangeImg(kImgState,ImageList.pve_atk,UI_TEX_TYPE_PLIST)
	else
		obj:egChangeImg(kImgState,ImageList.pve_dfs,UI_TEX_TYPE_PLIST)
	end
	

end
function __gvgprompt.bindOkListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __gvgprompt.bindGoListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnOk,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        local scene = GvgMissionScene.new()
	    scene:egReplace()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __gvgprompt.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
        AccountHelper:unlock(kStatePrompt)
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __gvgprompt.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
GvgPrompt={}
function GvgPrompt.new(data,onloaded)
   local obj =  TouchWidget.new(JsonList.gvgPromt)
    table_aux.unpackTo(__gvgprompt,obj)
    obj._onloaded = callback
    obj:init(data)
    obj:bindOkListener()
    obj:bindGoListener()
    return obj
end
function showGvgPrompt(data,onloaded)
    local layer = GvgPrompt.new(data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end

--local kBtnOk = "btn_ok"
local kBtnBack = "btn_back"
local kLabelLv = "lbl_lv_change"
local kLabelUnlock = "lbl_change"
local kImgItem = "img_item"
local kCellW = 400
local kCellH = 250
local __licenceprompt = {}
function __licenceprompt.init(obj,from,to)
    obj:egSetLabelStr(kLabelLv,string.format("LV%d%sLV%d",from,TxtList.arrowSymbol,to))
	local s_cfg = train.config[train.def.head]
    obj:egChangeImg(kImgItem,s_cfg.research[to].bodyImage[1])
    local widget = obj:egGetWidgetByName(kLabelUnlock)
    local lbl =  tolua.cast(widget,"Label")
    local str = licenceLevelup[from].unlockItem
    lbl:setText(str)
    local size = lbl:getSize()
    if size.width > kCellW then
        lbl:setTextAreaSize(CCSizeMake(kCellW,kCellH))
    end
end
function __licenceprompt.bindOkListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __licenceprompt.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
        AccountHelper:unlock(kStatePrompt)
		if account_data.digLv == 2 and account_data.train[2] ==nil then
			showDialog(1086)
		end
		if account_data.digLv == 3 and account_data.train[7] ==nil then
			showDialog(400)
		end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __licenceprompt.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
LicencePrompt={}
function LicencePrompt.new(from,to,onloaded)
   local obj =  TouchWidget.new(JsonList.licencePromt)
    table_aux.unpackTo(__licenceprompt, obj)
    obj._onloaded = callback
    obj:init(from,to)
    obj:bindOkListener()
    return obj
end
function showLicencePrompt(from,to,onloaded)
    local layer = LicencePrompt.new(from,to,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end
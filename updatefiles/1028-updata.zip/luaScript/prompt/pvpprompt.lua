--local kBtnOk = "btn_ok"
local kBtnBack = "btn_back"
local kPanelLayer = "prompt_panel"
local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"
local kLabelState = "lbl_state"
local kLabelAtk = "lbl_atk"

local __pvpprompt = {}
function __pvpprompt.init(obj,summarydata)
    if summarydata.stars and summarydata.stars > 0 then
        obj:egSetLabelStr(kLabelState,string.format("%s%s",obj:egGetLabelStr(kLabelState),TxtList.failTxt))
    else
        obj:egSetLabelStr(kLabelState,string.format("%s%s",obj:egGetLabelStr(kLabelState),TxtList.succTxt))
		--挖掘日志任务进程更新,PVP防守胜利
		task.updateTaskStatus(account_data,task.client_event_id.finished_defend,{summarydata.stars})
		----------------------------------------------------------
    end
    obj:egSetLabelStr(kLabelAtk,string.format("%s%s",obj:egGetLabelStr(kLabelAtk),summarydata.atkName))
    obj:loadAward(summarydata)
end
function __pvpprompt.loadAward(obj,summarydata)
	 local panel1 = obj:egGetWidgetByName(kPanelAward1)
	 local panel2 = obj:egGetWidgetByName(kPanelAward2)
	 local panel1size = panel1:getSize()
	 local panel2size = panel2:getSize()
	 local actW1 = 0
	 local actW2 = 0
	 local changeRow = false
	 if summarydata.elo then
		local eloAward = AwardItem.new("elo",Funs.signedNum(summarydata.elo))
		panel1:addChild(eloAward:egNode())
		actW1 = eloAward:egNode():getSize().width
	 end
	 for idx,coinname in pairs(KVariantList.coinType) do
        local coinval = summarydata[coinname] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
			local item_w = awarditem:egNode():getSize().width
			if not changeRow and actW1 + item_w <= panel1size.width then
				 actW1 = actW1 + item_w
				 panel1:addChild(awarditem:egNode())
			else
				changeRow = true
				actW2 = actW2 + item_w
				panel2:addChild(awarditem:egNode())
			end
        end
    end
	if actW2 > 0 then
		panel1:setPosition(ccp(panel1:getPositionX() + (panel1size.width-actW1)/2,panel1:getPositionY()))
		panel2:setPosition(ccp(panel2:getPositionX() + (panel2size.width-actW2)/2,panel2:getPositionY()))
	else
		panel1:setPosition(ccp(panel1:getPositionX() + (panel1size.width-actW1)/2,panel1:getPositionY() - 30))
	end
end
function __pvpprompt.bindOkListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __pvpprompt.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
        AccountHelper:unlock(kStatePrompt)
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __pvpprompt.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
PvpPrompt={}
function PvpPrompt.new(summarydata,onloaded)
   local obj =  TouchWidget.new(JsonList.pvpPromt)
    table_aux.unpackTo(__pvpprompt, obj)
    obj._onloaded = callback
    obj:init(summarydata)
    obj:bindOkListener()
    return obj
end
function showPvpPrompt(summarydata,onloaded)
    local layer = PvpPrompt.new(summarydata,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end
local kPanelLayer = "post_panel"
local kPanelWait = "wait_panel"
local kImgLoading = "loading"
local kPanelItem = "item_list"

local kBtnBack = "btn_back"
local kBtnNote = "note_btn"
local kBtnHistory = "history_btn"
local kImgNewMail = "img_new_mail"
local kImgNewVideo = "img_new_video"
local kImgMail = "img_mail"
local kImgVideo = "img_video"

local kLabelNoInfo = "noinfo_lbl"
local kMaxLoadNum = 6
local kHideZorder = 0
local kShowZorder = 2
local kShownHistory = 1
local kShownNote = 2
local kGrayColor = ccc3(128,128,128)
local kWhiteColor = ccc3(255,255,255)

local __postlayer={}

function __postlayer.init(obj,d_data)
   obj._d_data = d_data
   obj._loadItem = 0
   obj._itemlist = obj:egGetListView(kPanelItem)
   obj._oldH = 0
   obj._btnHistory = obj:egGetWidgetByName(kBtnHistory)
   obj._btnNote= obj:egGetWidgetByName(kBtnNote)
   obj:egHideWidget(kImgNewMail)
   if not account_data.battleSumaries or (videomanager.hasNewVideo() == true) then
        AccountHelper:lock(kStateVideoList)
        SendMsg[931003]()
   end
   obj:activeWaitTimer()
   obj:showWithAction()
end
---------------
--��ʾ¼���¼��
-----------------
function __postlayer.showHistory(obj)
	obj:setHistoryClicked()
    videomanager.markNewVideo(false)
    if not account_data.battleSumaries then account_data.battleSumaries= {} end
    if #account_data.battleSumaries == 0 then
       obj:egShowWidget(kLabelNoInfo)
       obj:egSetLabelStr(kLabelNoInfo,TxtList.noHistory)
    else
		obj:addPvpItem(kMaxLoadNum)
    end
	obj:showNewMailFlag(true)
	obj:showNewVideoFlag(true)
end
--����¼���¼
function __postlayer.addPvpItem(obj,num)
	local totalCnt = #account_data.battleSumaries
	if obj._loadItem >= totalCnt then return end
	local left = totalCnt - obj._loadItem
	local endIdx =  math.max(left - num+1,1)
	local startIdx =left
	for idx = startIdx,endIdx,-1 do
		local pvpItem = PvpItem.new(idx)
		obj:bindPvpItemClickEvent(pvpItem)
		obj._itemlist:pushBackCustomItem(pvpItem:egNode())
		obj._loadItem = obj._loadItem + 1
	end
	
end
--¼����Ϣ��ϸ��ȡ��ʱ��
function __postlayer.activeDetailTimer(obj,pvpItemIdx)
	local passedTime = 0
	obj:egShowWidget(kPanelWait)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
	AccountHelper:lock(kStateVideo)
	SendMsg[931004](pvpItemIdx)
	local  function callback(delta)
		passedTime = passedTime + delta
			if not  AccountHelper:isLocked(kStateVideo) then
				obj:egUnbindWidgetUpdate(kPanelWait)
				if videomanager.getvideo(pvpItemIdx) then
					VideoDetail = videomanager.getvideoDetail(pvpItemIdx)
					local scene = ReplayPvpScene.new()
					scene:egReplace()
				else
					--¼�����ݲ�����
					local function callback()
						local scene = TownScene.new()
						scene:egReplace()
					end
					local msglayer = MsgLayer.new(nil,TxtList.inValidVideo,1,callback)
					msglayer:show()
				end
			elseif passedTime > numDef.clientTimeOut then
				obj:egUnbindWidgetUpdate(kPanelWait)
				imgWidget:stopAllActions()
				postEventSignal(kEventRequestTimeOut)
			end
	end
	obj:egBindWidgetUpdate(kPanelWait,callback)
end
--¼��طŵ���ص�����
function __postlayer.bindPvpItemClickEvent(obj,pvpItem)
	local function callback(sender)
		local vid = sender:getItemIdx()
		if videomanager.getvideo(vid) then
		    VideoDetail = videomanager.getvideoDetail(vid)
			local scene = ReplayPvpScene.new()
			scene:egReplace()
		else
			obj:activeDetailTimer(vid)
		end
	end
	pvpItem:onClicked(callback)
end
---------------
--��ʾ�������
-----------------
function __postlayer.showNote(obj)
	obj:setNoteClicked()
	obj:getMailOrder()
    if #obj._mailOrder == 0 then
        obj:egShowWidget(kLabelNoInfo)
		obj:egSetLabelStr(kLabelNoInfo,TxtList.noNote)
    else
        obj:addMailItem(kMaxLoadNum)
    end
	obj:showNewMailFlag(true)
	obj:showNewVideoFlag(true)
end
function __postlayer.hasUnReadMail(obj)
	 for msgid,item in pairs (account_data.msgBoxList) do
		if item[1] == 0 then return true end
	 end
	 for msgid,item in pairs(account_data.rewardMails) do
	     if msgid and item then return true end
	 end
	 return false
end
--��ʾ���������ʼ���ʶ
function __postlayer.showNewMailFlag(obj,show)
	local imgNew = obj:egGetWidgetByName(kImgNewMail)
	if show == true and obj:hasUnReadMail() == true then
		imgNew:setVisible(true)
		local scaleto1 = CCScaleTo:create(1,0.8)
		local scaleto2 = CCScaleTo:create(1,1)
		local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
		local repeatever = CCRepeatForever:create(sequence)
		imgNew:runAction(repeatever)
	else
		imgNew:setVisible(false)
		imgNew:stopAllActions()
	end
end
--��ʾ��������¼���ʶ
function __postlayer.showNewVideoFlag(obj,show)
	local imgNew = obj:egGetWidgetByName(kImgNewVideo)
	if show == true and videomanager.hasNewDefVideo() == true then
		imgNew:setVisible(true)
		local scaleto1 = CCScaleTo:create(1,0.8)
		local scaleto2 = CCScaleTo:create(1,1)
		local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
		local repeatever = CCRepeatForever:create(sequence)
		imgNew:runAction(repeatever)
	else
		imgNew:setVisible(false)
		imgNew:stopAllActions()
	end
end
--�ʼ�����
function __postlayer.getMailOrder(obj)
    obj._mailOrder = {}
    for msgid,item in pairs (account_data.msgBoxList) do
        if item[1]~= 2 then
            table.insert(obj._mailOrder,{msgid,item[2]})
        end    
    end
    for msgid,item in pairs (account_data.rewardMails) do
        table.insert(obj._mailOrder,{msgid,msgid})
    end
    table.sort(obj._mailOrder,function(a,b) return a[2]>b[2] end)
end
--�����ʼ�
function __postlayer.addMailItem(obj,num)
    local totalCnt = #obj._mailOrder
    if obj._loadItem >= totalCnt then return end
    local left = totalCnt - obj._loadItem
    local startIdx = obj._loadItem + 1
    local endIdx = math.min(obj._loadItem + num,totalCnt)
    for idx = startIdx,endIdx,1 do
        local msgid = obj._mailOrder[idx][1]
        local mailItem = MailItem.new(msgid)
        obj:mailBack(mailItem)
        obj._itemlist:pushBackCustomItem(mailItem:egNode())
        obj._loadItem = obj._loadItem + 1 
    end
end
--�ʼ�����¼��ص�
function __postlayer.mailBack(obj,item)
    local function mailCallback(onload)
        SoundHelper.playEffect(SoundList.click_paper_open)
        local msgid = item:getprop("msgid")
        local mailinfo = MailInfo.new(msgid,onload)
        obj:mailInfoBack(mailinfo)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(mailinfo:egNode(),UILv.popLayer,UILv.popLayer)
    end
    item:onClicked(mailCallback)
end
--�ʼ��콱����¼��ص�
function __postlayer.mailInfoBack(obj,item)
    local function callback()
        obj:showNote()
    end
    item:onClicked(callback)
end

--����¼���¼Ϊ��ǰѡ����
function __postlayer.setHistoryClicked(obj)
	obj:clearItems()
	obj._showType = kShownHistory
	obj._btnNote:setFocused(false)
    obj._btnNote:setTouchEnabled(true)
	obj._btnHistory:setFocused(true)
    obj._btnHistory:setTouchEnabled(false)
    local parentNode = obj._btnHistory:getParent()
    parentNode:reorderChild(obj._btnHistory,kShowZorder)
    parentNode:reorderChild(obj._btnNote,kHideZorder)
	obj:egSetWidgetColor(kImgVideo,kWhiteColor)
	obj:egSetWidgetColor(kImgMail,kGrayColor)
end
--���ù���Ϊ��ǰѡ����
function __postlayer.setNoteClicked(obj)
	obj:clearItems()
	obj._showType = kShownNote
	obj._btnNote:setFocused(true)
    obj._btnNote:setTouchEnabled(false)
	obj._btnHistory:setFocused(false)
    obj._btnHistory:setTouchEnabled(true)
    local parentNode = obj._btnNote:getParent()
    parentNode:reorderChild(obj._btnNote,kShowZorder)
    parentNode:reorderChild(obj._btnHistory,kHideZorder)
	obj:egSetWidgetColor(kImgVideo,kGrayColor)
	obj:egSetWidgetColor(kImgMail,kWhiteColor)
end
--���б������¼�
function __postlayer.bindScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._itemlist:getInnerContainerSize().height
            if obj._oldH  < curH then
                if obj._showType == kShownHistory then
                    obj:addPvpItem(kMaxLoadNum)
                elseif obj._showType == kShownNote then 
                    --obj:addNoteItem(kMaxLoadNum)
                    obj:addMailItem(kMaxLoadNum)
                end
                 obj._oldH  = curH
			end
        end
    end
    obj._itemlist:addEventListenerScrollView(scrollEvent)
end
--¼���¼����¼�
function __postlayer.bindHistoryListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgVideo):setScale(1.1)
	end
    local function touchEnded(sender)
		obj:egGetWidgetByName(kImgVideo):setScale(1)
        SoundHelper.playEffect(SoundList.click_shop_goods)
       obj:showHistory()
    end
	local function touchCanceled(sender)
		obj:egGetWidgetByName(kImgVideo):setScale(1)
	end
    obj:egBindTouch(kBtnHistory,touchBegan,nil,touchEnded,touchCanceled)
end
--�����¼����¼�
function __postlayer.bindNoteListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgMail):setScale(1.1)
	end
    local function touchEnded(sender)
		obj:egGetWidgetByName(kImgMail):setScale(1)
        SoundHelper.playEffect(SoundList.click_shop_goods)
       obj:showNote()
    end
	local function touchCanceled(sender)
		obj:egGetWidgetByName(kImgMail):setScale(1)
	end
    obj:egBindTouch(kBtnNote,touchBegan,nil,touchEnded,touchCanceled)
end
--�رյ���¼�
function __postlayer.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
        postEventSignal(kEventNoticeMail)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __postlayer.hideWithAction(obj)
    local function callback()
		AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __postlayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
function __postlayer.clearItems(obj)
    for idx = 1,obj._loadItem  do
       local item = obj._itemlist:getItem(idx-1)
        obj._itemlist:removeChildByTag(item:getTag(),true)
    end
    obj._oldH =0
	obj._itemlist:removeAllItems()
	obj._loadItem  = 0
	obj._itemlist:jumpToTop()
	obj:egHideWidget(kLabelNoInfo)
end
function __postlayer.activeWaitTimer(obj)
    obj:clearItems()
    obj:egShowWidget(kPanelWait)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
	local passedTime = 0
    local function callback(delta)
		passedTime = passedTime + delta
        if not AccountHelper:isLocked(kStateVideoList) then
            obj:egHideWidget(kPanelWait)
            obj:egUnbindWidgetUpdate(kPanelWait)
            obj:showNote()
		elseif passedTime > numDef.clientTimeOut then
			obj:egUnbindWidgetUpdate(kPanelWait)
			imgWidget:stopAllActions()
			AccountHelper:reLoadGame()
        end
    end
    obj:egBindWidgetUpdate(kPanelWait,callback)
end

PostLayer={}
function PostLayer.new(onloaded)
    local obj =  TouchWidget.new(JsonList.postLayer)
    table_aux.unpackTo(__postlayer, obj)
    obj._onloaded  = onloaded
    obj:init()
    obj:bindNoteListener()
    obj:bindHistoryListener()
    obj:bindBackListener()
	obj:bindScrollListener()
    return obj
end

function showPost(onloaded)
    local layer = PostLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

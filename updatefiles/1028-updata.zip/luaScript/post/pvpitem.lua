local kTypeImg = {[0]=ImageList.pve_atk,[1]=ImageList.pve_dfs}--��������ͼƬ��Դ����0:������1������
local kPanelAward = "award_panel"
local kImgPvpType = "pvp_type_img"
local kLabelUserType = "pvp_user_lbl"
local kLabelUserName = "lbl_user_name"
local kLabelTime = "time_lbl"
local kBtnPlay = "play_btn"
local kBtnRevenge = "revenge_btn"
local kPanelHero = "hero_list"
local kLabelState = "lbl_state"
local kImgStamp = "img_stamp"
local kImgUser = "img_user"
local kRedColor = ccc3(128,0,0)
local kGreenColor = ccc3(0,128,0)
local __pvpitem={}
function __pvpitem.init(obj,idx)
    obj._idx = idx
    obj._videoinfo = account_data.battleSumaries[obj._idx]
    obj._vid = obj._videoinfo.vid
    obj._ptime = Funs.formatTimeCh(os.time() -  obj._videoinfo.time,true,true,true,nil,true)
	
    if  obj._videoinfo.isDefencer then
		obj:loadDefInfo()
		obj:loadHeros( obj._videoinfo.hero,true)
	else
		obj:loadAtkInfo()
		obj:loadHeros( obj._videoinfo.hero,false)
	end
end
function __pvpitem.loadAward(obj,atkflag)
    local panel = obj:egGetWidgetByName(kPanelAward)
    local eloaward = AwardItem.new("elo",Funs.signedNum(obj._videoinfo[string.format("%s_%s",atkflag,"elo")]))
    panel:addChild(eloaward:egNode())
    for idx,coinname in pairs(KVariantList.coinType) do
        local coinval = obj._videoinfo[string.format("%s_%s",atkflag,coinname)] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
            panel:addChild(awarditem:egNode())
        end
    end
end
--Ϊ������ʱ��¼������
function __pvpitem.loadAtkInfo(obj)
	obj:egChangeImg(kImgPvpType,ImageList.pve_atk,UI_TEX_TYPE_PLIST)
	obj:egChangeImg(kImgUser,ImageList.btn_def_n,UI_TEX_TYPE_PLIST)
	obj:egHideWidget(kBtnRevenge)
	obj:loadAward("atk")
    obj:egSetLabelStr(kLabelTime,string.format("%s%s",obj._ptime,TxtList.ago))
	obj:egSetLabelStr(kLabelUserType,TxtList.defUserTxt)
	obj:egSetLabelStr(kLabelUserName,obj._videoinfo.defName)
	if obj._videoinfo.stars > 0 then
		obj:egSetWidgetColor(kLabelState,kGreenColor)
		obj:egSetWidgetColor(kImgStamp,kGreenColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.succTxt))
	else
		obj:egSetWidgetColor(kLabelState,kRedColor)
		obj:egSetWidgetColor(kImgStamp,kRedColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.failTxt))
	end
end
--Ϊ���ط�ʱ��¼������
function __pvpitem.loadDefInfo(obj)
	obj:egChangeImg(kImgPvpType,ImageList.btn_def_n,UI_TEX_TYPE_PLIST)
	obj:egChangeImg(kImgUser,ImageList.pve_atk,UI_TEX_TYPE_PLIST)
	obj:loadAward("def")
    obj:egSetLabelStr(kLabelTime,string.format("%s%s",obj._ptime,TxtList.ago))
	obj:egSetLabelStr(kLabelUserType,TxtList.atkUserTxt)
	obj:egSetLabelStr(kLabelUserName, obj._videoinfo.atkName)
	if obj._videoinfo.stars == 0 then
		obj:egHideWidget(kBtnRevenge) --�����ɹ����ܸ���
		obj:egSetWidgetColor(kLabelState,kGreenColor)
		obj:egSetWidgetColor(kImgStamp,kGreenColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.succTxt))
	else
		 --ֻ�ܸ���һ��
		if obj._videoinfo.needRevenged <= 0 then --����Ҫ����
			obj:egHideWidget(kBtnRevenge)
		else --��û����
			obj:egShowWidget(kBtnRevenge)
			obj:bindRevengeListener()
		end
		obj:egSetWidgetColor(kLabelState,kRedColor)
		obj:egSetWidgetColor(kImgStamp,kRedColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.failTxt))
	end
end
function __pvpitem.getValTxt(obj,val)
	local txt = math.abs(val)
	if val > 0 then txt = string.format("+%s",txt)
	elseif val <0 then txt = string.format("-%s",txt) end
	return txt
end
function __pvpitem.loadHeros(obj,herolist,isememy)
	local listview =obj:egGetListView(kPanelHero)
    for heroid,herolv in pairs(herolist)do
        local heroHead  = HeroHead.new(heroid,herolv,isememy)
        listview:pushBackCustomItem(heroHead:egNode())
    end
end
--��ȡ��ƵID
function __pvpitem.getItemIdx(obj)
	return obj._vid
end
function __pvpitem.onClicked(obj,callback)
	obj._clickCallback = callback
end
function __pvpitem.bindPlayListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_shop_goods)  --�����Ŀ
       obj:egSetWidgetTouchEnabled(kBtnPlay,false)
       if obj._clickCallback then obj._clickCallback(obj) end
    end
    obj:egBindTouch(kBtnPlay,nil,nil,touchEnded,nil)
end
function __pvpitem.bindRevengeListener(obj)
	 local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_shop_goods)  --�����Ŀ
        sender:setTouchEnabled(false)
		 if os.time() >= account_data.revengeNextSt then
			account_data.revengeCnt  = 0
			account_data.revengeNextSt = Funs.getTimeWithHMS(numDef.revengeRefreshUTH,numDef.revengeRefreshUTM,0,account_data.scOffsetTime)
		end
        if numDef.pvpBattleAP > account_data.actPt then
			 local text = string.format("%s %d",TxtList.needActPt,numDef.pvpBattleAP)
			 local pos = sender:convertToWorldSpace(ccp(sender:getPositionX(),sender:getPositionY()))
			 showPopTxt(text,pos.x,pos.y,ccp(0.5,0.5))
			 sender:setTouchEnabled(true)
			 return
		end
		local maxRevengeCnt = VipLvUp[account_data.vip or 0].revengeCnt or 0
		if account_data.revengeCnt >= maxRevengeCnt then
			local jewelval = jewelCalc.getPriceForRevenge(account_data.revengeCnt,maxRevengeCnt)
			if jewelval > account_data.jewel then
				showPopCharge(apPirce,function() sender:setTouchEnabled(true) end)
				return
			end
		end
		if account_data.shellPvp > os.time() then
			showPvpCDInfo(obj._videoinfo,function() sender:setTouchEnabled(true)  end)
	    else
			showRevengePreview(obj._videoinfo,function() sender:setTouchEnabled(true) end)
		end
    end
    obj:egBindTouch(kBtnRevenge,nil,nil,touchEnded,nil)
end
PvpItem={}
function PvpItem.new(idx)
    local obj = {}
    CocosWidget.install(obj,JsonList.pvpItem)
    table_aux.unpackTo(__pvpitem, obj)
    obj:init(idx)
    obj:bindPlayListener()
    return obj
end

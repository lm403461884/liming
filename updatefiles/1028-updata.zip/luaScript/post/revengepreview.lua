local kLblTitle = "lbl_title"
local kImgStar1 = "img_star1"
local kImgStar2 = "img_star2"
local kImgStar3 = "img_star3"
local kLblHard = "lbl_degree"
local kLblAtk = "lbl_atk"
local kLblAtkVal = "lbl_atk_val"
local kPanelHero = "hero_list"
local kPanelAward1 = "panel_award1"
local kPanelAward2 = "panel_award2"
local kPanelAward3 = "panel_award3"
local kLblActPt = "lbl_c_act"
local kImgActPt = "img_c_act"
local kLblJewel = "lbl_c_jewel"
local kImgJewel = "img_c_jewel"
local kPanelBtn = "btn_panel"
local kBtnStart = "btn_start"
local kBtnBack = "btn_back"
local kImgBg = "img_bg"
local kLblTimeRes = "lbl_time_res"
local kLblPromp = "lbl_promp"

local kPanelLayer = "panel_gvg_pre"
local kPanelInfo = "info_panel"
local kPanelWait = "wait_panel"

local kImgLoading = "img_loading"
local kLblPrepare = "lbl_prepare"
local kLblNoMatch = "lbl_nomatch"
local kLblSearch = "lbl_search"
local kImgLoadBar = "img_bar"
local kImgFight = "img_fight"
local kImgScene = "img_area"
local kPanelMonster = "monster_list"
--Ӣ��ѡ��
local kPanelSelect = "img_hero_select_bg"
local kHeroList = "scrollview"
local kImgMark = "img_mark"
local kLblChangHero = "lbl_change_hero"
local kBtnChangeHero = "btn_change_hero"

local kCellW = 110
local kCellW1 = 150
local kCellH = 160
local kMaxMonster = 5
local kWaitTime = 30 --����ʱ30��
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)
local __revengepreview={}
function __revengepreview.init(obj,videoinfo)
	obj._videoinfo = videoinfo
	obj._guid = obj._videoinfo.atkGuid
	local maxRevengeCnt = VipLvUp[account_data.vip or 0].revengeCnt or 0
	obj._battleJewel = jewelCalc.getPriceForRevenge(account_data.revengeCnt,maxRevengeCnt)
	obj._oldTeam = Funs.copy(account_data.team)
	 obj._panel1 = obj:egGetWidgetByName(kPanelAward1)
    obj._panel2 = obj:egGetWidgetByName(kPanelAward2)
    obj._panel3 = obj:egGetWidgetByName(kPanelAward3)
    
    obj._panel1X = obj._panel1:getPositionX()
    obj._panel1Y = obj._panel1:getPositionY()
    obj._panel1W = obj._panel1:getSize().width
    obj._panel2X = obj._panel2:getPositionX()
    obj._panel2Y = obj._panel2:getPositionY()
    obj._panel2W = obj._panel2:getSize().width
	obj:egHideWidget(kImgStar1)
	obj:egHideWidget(kImgStar2)
	obj:egHideWidget(kImgStar3)
	AccountHelper:lock(kStateSearchPvp)
	SendMsg[935005](obj._guid)
	obj:egHideWidget(kPanelInfo)
	obj:showWaitPanel()
    obj:showWithAction()
end
--��ʾ�ȴ�����
function __revengepreview.showWaitPanel(obj,show)
	obj:egShowWidget(kPanelWait)
	local widget1 = obj:egGetWidgetByName(kImgFight)
	local scaleto1 = CCScaleTo:create(1,1.3)
	local scaleto2 = CCScaleTo:create(1,1.5)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatforever1 = CCRepeatForever:create(sequence)
	widget1:runAction(repeatforever1)
        
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
	local rotateby = CCRotateBy:create(1,360)
	local repeatforever2 = CCRepeatForever:create(rotateby)
	imgWidget:runAction(repeatforever2) 
	obj:bindLoadTimer()
end
--ֹͣ�ͷŵȴ�����
function __revengepreview.stopWaitAct(obj)
	local widget1 = obj:egGetWidgetByName(kImgFight)
    local widget2 = obj:egGetWidgetByName(kImgLoading)
    widget1:stopAllActions()
    widget2:stopAllActions()
end
--�����ݼ��صȴ���ʱ��
function __revengepreview.bindLoadTimer(obj)
	local passed = 0
    local  function callback(delta)
		passed = passed + delta
        if not  AccountHelper:isLocked(kStateSearchPvp) and passed >= numDef.searchInterval then
            obj:egUnbindWidgetUpdate(kLblPrepare)
			obj:stopWaitAct()
			if pvpaccount_data then
				 obj:egHideWidget(kPanelWait)
				 obj:showPreView()
			else
				obj:egHideWidget(kLblPrepare)
				obj:egHideWidget(kImgLoading)
				obj:egHideWidget(kImgLoadBar)
				obj:egShowWidget(kLblNoMatch)
				obj:egSetLabelStr(kLblNoMatch,TxtList.playerOnline)
				obj:egSetLabelStr(kLblSearch,TxtList.pvpSearchEnd)
			end
        else
            if passed >= numDef.clientTimeOut then
                obj:egUnbindWidgetUpdate(kLblPrepare)
                obj:stopWaitAct()
                obj:egHideWidget(kLblPrepare)
				obj:egHideWidget(kImgLoading)
				obj:egHideWidget(kImgLoadBar)
				obj:egShowWidget(kLblNoMatch)
				obj:egSetLabelStr(kLblNoMatch,TxtList.playerOnline)
				obj:egSetLabelStr(kLblSearch,TxtList.pvpSearchEnd)
            end
         end
    end
    obj:egBindWidgetUpdate(kLblPrepare,callback)
end
function __revengepreview.showPreView(obj)
    obj:egShowWidget(kPanelInfo)
    obj:egHideWidget(kPanelSelect)
	obj:egHideWidget(kHeroList)
    obj:egSetLabelStr(kLblTimeRes,kWaitTime)
	obj:egSetWidgetTouchEnabled(kPanelInfo,false)
	if obj._battleJewel > 0 then
		local actImg = obj:egGetWidgetByName(kImgActPt)
		local actLbl = obj:egGetWidgetByName(kLblActPt)
		actImg:setPosition(ccp(21,-16))
		actImg:setScale(0.5)
		actLbl:setPosition(ccp(56,-16))
		actLbl:setScale(0.65)
		obj:egShowWidget(kImgJewel)
		obj:egShowWidget(kLblJewel)
		obj:egSetBMLabelStr(kLblJewel,obj._battleJewel)
	end
	obj._battleAp = numDef.pvpBattleAP
	obj:egSetBMLabelStr(kLblActPt,obj._battleAp)
    local pic = scene_data[pvpaccount_data.sceneID].thumbPic
    local ownEloWin,pvpEloLose = pvpCalc.elo(account_data.elo, pvpaccount_data.elo, 3)
    
    obj:egChangeImg(kImgScene,pic,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblTitle,string.format("%s%s",pvpaccount_data.user,TxtList.pvpHoleEx))
    obj:egSetLabelStr(kLblHard,pvpaccount_data.digLv)
    obj:egSetLabelStr(kLblAtkVal,RiskHelper.getTeamBp())
    local goldDlt,oilDlt,_,_ = pvpCalc.judge( ownEloWin, pvpEloLose,3, account_data.digLv, pvpaccount_data.digLv, pvpaccount_data.gold, pvpaccount_data.oil)
	obj:loadAward1(math.floor(pvpaccount_data.resVal[1] + goldDlt),math.floor(ownEloWin - account_data.elo))
	obj:loadAward2()
	if account_data.digLv < pvpaccount_data.digLv then
		obj:egSetWidgetColor(kLblHard,kRedColor)
	else
		obj:egSetWidgetColor(kLblHard,kBrownColor)
	end
	obj._passedTime = 0
    obj:activeTimeUpdate()
    obj:loadMonsters()
    obj:loadHeros()
end
--���ع���
function __revengepreview.getMonsters(obj)
    local tb = {}
    for pos,monsterid in pairs(pvpaccount_data.creatureList) do
        if not tb[monsterid] then tb[monsterid] = 1 
        else tb[monsterid] = tb[monsterid] + 1 end
    end
    return tb
end
function __revengepreview.loadMonsters(obj)
    local monsters = obj:getMonsters()
    local panel =obj:egGetWidgetByName(kPanelMonster)
    local cnt = 0
    for monsterid,num in pairs(monsters) do
		cnt = cnt + 1
        local monsterHead = MonsterHead.new(monsterid,num,pvpaccount_data)
        panel:addChild(monsterHead:egNode())
		if cnt >= kMaxMonster then break end
    end
    local size = panel:getSize()
    local neww = cnt*kCellW
	panel:setPosition(ccp((size.width - neww)/2 + panel:getPositionX(),panel:getPositionY()))
    panel:setSize(CCSizeMake(neww,size.height))
end
--����Ӣ��ͷ���С��ս����
function __revengepreview.loadHeros(obj)
    obj._teamheroitem = {}
    local panel  = obj:egGetWidgetByName(kPanelHero)
	for idx = 1,account_data.maxTeam do
		local heroid = account_data.team[idx] or 0
		local herolv = 0
		if heroid > 0 then herolv = account_data.heroList[heroid].lv end
		local heroHead = ExpeditionItem.new(heroid,nil,herolv)
		heroHead:setItemTouchEnabled(false)
		table.insert(obj._teamheroitem,heroHead)
		 panel:addChild(heroHead:egNode())
		if heroid > 0 then
			obj:teamMemberClicked(heroHead)
		end
	end
	local neww = account_data.maxTeam * kCellW1
	local size = panel:getSize()
	if size.width > neww then
		panel:setPosition(ccp((size.width - neww )/2*panel:getScale() + panel:getPositionX(),panel:getPositionY()))
		panel:setSize(CCSizeMake(neww,size.height))
	end
end
function __revengepreview.loadAward1(obj,goldval,eloval)
    for idx = 1,obj._panel1:getChildrenCount() do
        obj._panel1:removeChildByTag(idx,true)
    end
    local margin = 0
    local goldAward = AwardItem.new("gold",string.format("%s%d",TxtList.numSymbol,goldval))
    local goldsize = goldAward:egNode():getSize()
    goldAward:egNode():setSize(CCSizeMake(goldsize.width + margin,goldsize.height))
    obj._panel1:addChild(goldAward:egNode(),1,1)
    local eloAward = AwardItem.new("elo",string.format("%s%d",TxtList.numSymbol,eloval))
    obj._panel1:addChild(eloAward:egNode(),1,2)
    local actW = goldAward:egNode():getSize().width + eloAward:egNode():getSize().width + margin
    if actW> obj._panel1W then
        obj._panel1:setScale(obj._panel1W/actW)
    end
end
function __revengepreview.loadAward2(obj)
    for idx = 1,obj._panel2:getChildrenCount() do
        obj._panel2:removeChildByTag(idx,true)
    end
    obj._panel2:setPosition(ccp(obj._panel2X,obj._panel2:getPositionY()))
    local actW = 0
    local tagidx = 0
    for idx = 2,7 do
        local coinname = KVariantList.coinType[idx]
        local coinval = pvpaccount_data.resVal[idx]
        if coinval~=0 then
            tagidx = tagidx + 1
            local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,coinval))
            obj._panel2:addChild(awarditem:egNode(),0,tagidx)
            actW = actW + awarditem:egNode():getSize().width
        end
    end
    if actW > obj._panel2W then
        obj._panel2:setScale(obj._panel2W/actW)
    end
end
--ȡ��С��Ӣ��
function __revengepreview.removeTeamHero(obj,heroid,posx,posy)
    if #account_data.team == 1 then
        showPopTxt(TxtList.teamEmpty,posx,posy,ccp(0.6,0.6))
    else
		panel=obj:egGetWidgetByName(kPanelHero)
        for idx,Theroid in ipairs(account_data.team) do
            if Theroid == heroid then
                table.remove(account_data.team,idx)
                 panel:removeChild(obj._teamheroitem[idx]:egNode(),true)
                table.remove(obj._teamheroitem,idx)
                local heroHead = ExpeditionItem.new(0)
                table.insert(obj._teamheroitem,heroHead)
                panel:addChild(heroHead:egNode())
                obj._heroitem[heroid]:showJoinFlag(false)
           end
       end
	   local teamCap = obj:getTeamAtkCap()--����С��ս����
       obj:egSetLabelStr(kLblAtkVal,teamCap)
    end   
end
--����С��Ӣ��
function __revengepreview.insertTeamHero(obj,heroid)
    table.insert(account_data.team,heroid)
	local heroitem = obj._teamheroitem[#account_data.team]
	heroitem:updateHeroInfo(heroid,nil,account_data.heroList[heroid].lv)
	heroitem:setItemTouchEnabled(true)
	obj:teamMemberClicked(heroitem)
    local teamCap = RiskHelper.getTeamBp()--����С��ս����
    obj:egSetLabelStr(kLblAtkVal,teamCap)
end
--���С��Ӣ��
function __revengepreview.teamMemberClicked(obj,heroHead)
    local function callback(sender,posx,posy)
        local heroid = sender:getprop("heroid")
        obj:removeTeamHero(heroid,posx,posy)
    end
    heroHead:onItemClicked(callback)
end
--��ʾӢ��ѡ�����
function __revengepreview.showPanelSelect(obj)
	obj:egShowWidget(kPanelSelect)
	obj:egShowWidget(kHeroList)
	if obj._selected then return end
    obj._selected = true
    obj._heroitem = {}
    local herolist = obj:egGetScrollView(kHeroList)
    local size = herolist:getSize()
    local heroAtkList = obj:getHeroAtkOrder()
    local maxRow = math.ceil(#heroAtkList/2)
    local newH = maxRow * kCellH
    if newH> size.height then
        herolist:setInnerContainerSize(CCSizeMake(size.width,newH))
    else
        newH = size.height    
    end
	herolist:jumpToTop()
    for idx,item in ipairs (heroAtkList) do
        local heroid = item[1]
        local heroitem = ExpeditionItem.new(heroid,nil,account_data.heroList[heroid].lv)
        obj._heroitem[heroid] = heroitem 
        local itemsize = heroitem:egNode():getSize()
        local row = math.ceil(idx/2)
        if idx%2 == 1 then
            heroitem:egNode():setPosition(ccp(0,newH-row*kCellH)) 
        else
            heroitem:egNode():setPosition(ccp(size.width-itemsize.width,newH-row*kCellH)) 
        end  
        obj:panelHeroClicked(heroitem)  
        herolist:addChild(heroitem:egNode())
    end
    for key,heroid in ipairs (account_data.team) do
        obj._heroitem[heroid]:showJoinFlag(true)
    end   
end
--Ӣ��ս��������
function __revengepreview.getHeroAtkOrder(obj)
    local tb = {}
    for heroid,heroprop in pairs(account_data.heroList) do
        if not account_data.cbTeam[heroid] then
            table.insert(tb,{heroid, RiskHelper.getHeroBp(heroprop,account_data)})
        end 
    end
    table.sort(tb,function(a,b) return a[2]>b[2] end)
    return tb
end
--���ѡ�����Ӣ��
function __revengepreview.panelHeroClicked(obj,heroitem)
    local function callback(sender,posx,posy)
        local isJoin = sender:getprop("joined")
        local heroid = sender:getprop("heroid")
        if isJoin then
            obj:removeTeamHero(heroid,posx,posy)
        else
            if #account_data.team == account_data.maxTeam then
                showPopTxt(TxtList.teamLimited,posx,posy,ccp(0.5,0.5))
            else
                 obj._heroitem[heroid]:showJoinFlag(true)
                 obj:insertTeamHero(heroid)
            end
        end
    end
    heroitem:onItemClicked(callback)
end
function __revengepreview.hideWithAction(obj)--{{{
    local function callback()
      obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.5,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end--}}}
function __revengepreview.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kImgBg)
    widget:runAction(CCFadeIn:create(0.4))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(baseWidget:getPositionX(),720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(baseWidget:getPositionX(),0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    local function callback()
        if obj._onloaded then obj._onloaded()end
    end
    local callfunc = CCCallFunc:create(callback)
	local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
	baseWidget:runAction(sequece)
end
--�ر�ҳ��
function __revengepreview.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SendMsg[935003]()
		for idx,heroids in ipairs(obj._oldTeam) do
            if heroids ~= account_data.team[idx] or #obj._oldTeam ~= #account_data.team then
                 SendMsg[934003](account_data.team)
                 obj._oldTeam = Funs.copy(account_data.team)
                 break
            end
        end   
        obj:egSetWidgetTouchEnabled(kBtnStart,false)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

--��ʼ��ť
function __revengepreview.bindStartListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:egUnbindWidgetUpdate(kLblTimeRes)
        SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:egRemoveSelf()
		account_data.jewel = account_data.jewel - obj._battleJewel
		AccountHelper:useActPt(obj._battleAp)
		----------------------------------------------------------
        local scence = RevengeScene.new(obj._videoinfo.vid)
        scence:egReplace()
    end  
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end  
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
function __revengepreview.getTeamAtkCap(obj)
    local tb = {}
	local teamAtk = 0
    for key,heroprop in pairs(account_data.heroList) do
        tb[heroprop.type] = RiskHelper.getHeroBp(heroprop,account_data)
    end
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk + tb[heroid]
    end
	tb = nil
    return teamAtk
end
function __revengepreview.bindChangeListener(obj)
    local function touchEnded(sender)
        if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
		sender:setTouchEnabled(false)
		
		 if obj:egGetLabelStr(kLblChangHero) == TxtList.btnOK then
			obj:egSetWidgetTouchEnabled(kPanelInfo,false)
			obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
			for idx,herodata in ipairs(obj._teamheroitem) do 
                herodata:setItemTouchEnabled(false)
            end
			if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
				SendMsg[934003](account_data.team)
                obj._oldTeam = Funs.copy(account_data.team)
			end
            obj:egHideWidget(kPanelSelect)
			obj:egHideWidget(kHeroList)
			obj:egShowWidget(kBtnBack)
		 else
			obj:egSetWidgetTouchEnabled(kPanelInfo,true)
			obj:egSetLabelStr(kLblChangHero,TxtList.btnOK)
			for idx,herodata in ipairs(obj._teamheroitem) do 
                herodata:setItemTouchEnabled(true)
            end
			obj:egHideWidget(kBtnBack)
			obj:showPanelSelect()
		 end  
		 sender:setTouchEnabled(true)
    end
    local function touchCanceled(sender)
        if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end	
    end
    obj:egBindTouch(kBtnChangeHero,nil,nil,touchEnded,touchCanceled)
end
--ѡС��ʱ�󱳾�ͼƬ����¼�
function __revengepreview.bindBgListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		obj:egShowWidget(kBtnBack)
		obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
		for idx,herodata in ipairs(obj._teamheroitem) do 
            herodata:setItemTouchEnabled(false)
        end
		if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
			SendMsg[934003](account_data.team)
            obj._oldTeam = Funs.copy(account_data.team)
		end
        obj:egHideWidget(kPanelSelect)
		obj:egHideWidget(kHeroList)
    end
    local function touchCanceled(sender)
        if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end	
    end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,touchCanceled)
end
--����ʱ����
function __revengepreview.activeTimeUpdate(obj)  
    local function callback(delta)
        obj._passedTime = obj._passedTime + delta
        if obj._passedTime < kWaitTime then
           obj:egSetLabelStr(kLblTimeRes,math.ceil(kWaitTime-obj._passedTime))
        end
        if obj._passedTime >= kWaitTime then
			obj:egUnbindWidgetUpdate(kLblTimeRes)
			obj:egSetWidgetTouchEnabled(kBtnChangeHero,false)
			obj:egSetWidgetTouchEnabled(kPanelInfo,false)
            SoundHelper.playEffect(SoundList.click_shop_goods)
            
			if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
				SendMsg[934003](account_data.team)
				obj._oldTeam = Funs.copy(account_data.team)
			end	
			account_data.jewel = account_data.jewel - obj._battleJewel
			AccountHelper:useActPt(obj._battleAp)
			obj:egRemoveSelf()
			local scene = RevengeScene.new(obj._videoinfo.vid)
			scene:egReplace()
		elseif obj._passedTime + 1 >= kWaitTime then
            obj:egSetWidgetTouchEnabled(kBtnStart,false)
            obj:egSetWidgetTouchEnabled(kBtnChangeHero,false)
            obj:egSetWidgetTouchEnabled(kBtnBack,false)   			
        end
    end
    obj:egBindWidgetUpdate(kLblTimeRes,callback)
end
RevengePreView={}
function RevengePreView.new(videoinfo,onload)
    local obj =  TouchWidget.new(JsonList.gvgpreview)
    table_aux.unpackTo(__revengepreview, obj)
    obj._onloaded = onload
    obj:init(videoinfo)
    obj:bindStartListener()
    obj:bindChangeListener()
    obj:bindBackListener()
	obj:bindBgListener()
    return obj
end

function showRevengePreview(videoinfo,onload)
	local layer =  RevengePreView.new(videoinfo,onload)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

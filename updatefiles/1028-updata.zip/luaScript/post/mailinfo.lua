local kImgBg = "img_bg"
local kLblTitle = "lbl_title"
local kLblInfo = "lbl_info"
local kLblPerson = "lbl_person"
local kImgLine = "img_line"
local kLblAttach= "lbl_attachment"
local kLblReward = "lbl_reward"
local kPanel1 = "panel_award1"
local kPanel2 = "panel_award2"
local kBtnReward = "btn_reward"
local kPanelLayer = "panel_info"

local __mailinfo={}
function __mailinfo.init(obj,msgid)
    obj._msgid = msgid
    obj._kind = nil
    obj._kind = obj:getMailKind()
    if obj._kind == 1 then
        obj._msgdata = msgQuery.getName(msgid)
        obj:egSetLabelStr(kLblTitle,obj._msgdata.msgName)
        obj:egSetLabelStr(kLblInfo,obj._msgdata.msgtext)
        obj:egSetLabelStr(kLblPerson,obj._msgdata.msgPerson)
        if obj._msgdata.type == 1 then 
            obj._award = false
        elseif obj._msgdata.type == 2 then
            obj._award = true
        end
        if not obj._award then
            obj:egSetLabelStr(kLblReward,TxtList.btnOK)
            obj:egHideWidget(kLblAttach)
            obj:egHideWidget(kImgLine)
        else
            obj:loadAward()    
        end
    elseif obj._kind == 2 then
        local id = account_data.rewardMails[obj._msgid].id
        local mail_Cfg = msgRankList[id]
        obj:loadAward()
        obj:egSetLabelStr(kLblTitle,mail_Cfg.msgName)
        obj:egSetLabelStr(kLblInfo,mail_Cfg.msgtext)
        obj:egSetLabelStr(kLblPerson,mail_Cfg.msgPerson)
    end    
    obj:showWidthAction()
end
function __mailinfo.getMailKind(obj) --����ʼ����࣬1.���õ��ʼ���1.�����ʼ�
    for msgid,item in pairs (account_data.rewardMails) do
        if obj._msgid == msgid then
            return 2
        end
    end
    return 1
end
function __mailinfo.loadAward(obj)
    obj._reward1 = obj:egGetWidgetByName(kPanel1)
    local size1 = obj._reward1:getSize()
    obj._reward2 = obj:egGetWidgetByName(kPanel2)
    local size2 = obj._reward2:getSize()
    local count = 0
    local max_1 =0
    local max_2 = 0
    local icon = {}
    if obj._kind == 1 then
         icon_data = obj._msgdata.accessory(account_data)
    elseif obj._kind == 2 then
         local name = "jewel"
         local val = account_data.rewardMails[obj._msgid].val
         icon_data = {[name] = val}
    end    
    for name,val in pairs (icon_data) do
        count = count +1
        if count <=3 then
            local iconitem = TheAward.new(name,val)
            obj._reward1:addChild(iconitem:egNode())
            max_1 = max_1 +iconitem:egNode():getSize().width
        else
            local iconitem = TheAward.new(name,val)
            obj._reward2:addChild(iconitem:egNode())
            max_2 = max_2 +iconitem:egNode():getSize().width
        end   
    end
    if max_1>0 then  --����������ʾ
        local posX,posY = obj._reward1:getPosition()
        obj._reward1:setPosition(ccp(posX+(size1.width-max_1)/2,posY))
    end
    if max_2 >0 then
        local posX,posY = obj._reward2:getPosition()
        obj._reward2:setPosition(ccp(posX+(size2.width-max_2)/2,posY))
    end    
end
--[[function __mailinfo.loadMailAward(obj)
    obj._reward1 = obj:egGetWidgetByName(kPanel1)
    local size1 = obj._reward1
    local name = "jewel" --Ŀǰ����ֻ������
    local val = account_data.rewardMails[obj._msgid].val
    local iconitem = TheAward.new(name,val)
    obj._reward1:addChild(iconitem:egNode())

end--]]
function __mailinfo.showWidthAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))

    local cardbg = obj:egGetWidgetByName(kImgBg)
    cardbg:setScale(0)
    local scaleto = CCScaleTo:create(0.5,1)
    local backout = CCEaseBackOut:create(scaleto)
    local function callback()
        if obj._onloaded then obj._onloaded() end
        obj:bindCloseListener()
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(backout,callfunc)
    cardbg:runAction(sequence)
end
function __mailinfo.onClicked(obj,callback)
    obj._callback = callback
end
--�ر�ҳ��
function __mailinfo.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
        if obj._kind ==1 then
            if account_data.msgBoxList[obj._msgid][1]==0 and obj._callback and obj._msgdata.type~=2 then 
                 message.onRead(account_data,obj._msgid)
                 SendMsg[931011](obj._msgid)
                 obj._callback() 
            end
        elseif obj._kind == 2 then
            --obj:clickGetMailAward()
        end     
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end
--����콱�¼�
function __mailinfo.clickGetAward(obj)
    if not obj._award then
            SoundHelper.playEffect(SoundList.click_paper_close)
            SendMsg[931011](obj._msgid)
            obj:egRemoveSelf()
            if account_data.msgBoxList[obj._msgid][1]==0 and obj._callback then 
                message.onRead(account_data,obj._msgid)
                obj._callback() 
            end    
    else
            SoundHelper.playEffect(SoundList.click_buy_button)
            SendMsg[931011](obj._msgid)
            message.onRead(account_data,obj._msgid)
            obj:egRemoveSelf()
            if obj._callback then obj._callback(obj._msgid) end
    end

end
function __mailinfo.clickGetMailAward(obj) --���а���
    account_data.jewel = account_data.jewel + account_data.rewardMails[obj._msgid].val
    SoundHelper.playEffect(SoundList.click_buy_button)
    --������Ϣ
    SendMsg[9312001](obj._msgid)
    account_data.rewardMails[obj._msgid]=nil
    if obj._callback then obj._callback(obj._msgid) end
    obj:egRemoveSelf()
end
--��ȡ��ť
function __mailinfo.bindBtnListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if obj._kind == 1 then
            obj:clickGetAward()
        elseif obj._kind == 2 then
            obj:clickGetMailAward()
        end
    end    
    obj:egBindTouch(kBtnReward,nil,nil,touchEnded,nil)
end

MailInfo={}
function MailInfo.new(msgid,onload)
    local obj =  TouchWidget.new(JsonList.mailInfo)
    table_aux.unpackTo(__mailinfo, obj)
    obj._onloaded = onload
    obj:init(msgid)
    obj:bindBtnListener()
    return obj
end

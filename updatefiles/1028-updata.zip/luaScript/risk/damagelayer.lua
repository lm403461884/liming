local kRedColor = ccc3(255,0,0)
local kGreenColor = ccc3(0,255,0)
local kYellowColor = ccc3(255,255,0)
local kJumpDis =64
local kRandomM = 36
local kRandomN = -36
local __damagelayer={}
--普通掉血
function __damagelayer.showDamage(obj,damage,x,y,isEmemy)
    local lbl = LabelBMFont:create()
    --local offsetx = math.random(kRandomM-kRandomN)+kRandomN
    --x = offsetx + x
    local offsety = math.random(kJumpDis)
    y=offsety+y
	lbl:setFntFile(FNList.BlackNum)
	lbl:setPosition(ccp(x,y))
	lbl:setScale(0.4)
	obj:egNode():addChild(lbl)
	local damageTxt = math.abs(damage)
	local color = kRedColor
	if damage >0 then 
        damageTxt = string.format("%s%d","+",damage) 
        color = kGreenColor
    end
	lbl:setText(damageTxt)
	if not isEmemy then lbl:setColor(color) end
	
	local jumpto = CCJumpTo:create(0.3,ccp(x,y+kJumpDis),kRandomM,1)
	local scaleto = CCScaleTo:create(0.3,0.7)
	local spawn = CCSpawn:createWithTwoActions(jumpto,scaleto)
	local delay = CCDelayTime:create(0.4)
	local function callbackfunc()
        obj:egNode():removeChild(lbl,true)
	end
	local callfunc = CCCallFuncN:create(callbackfunc)
	local array = CCArray:create()
	array:addObject(spawn)
	array:addObject(delay)
	array:addObject(callfunc)
	local action = CCSequence:create(array)
	lbl:runAction(action)
end
--技能伤害
function __damagelayer.showSkillDamage(obj,damage,x,y,isEmemy)
	 local lbl = LabelBMFont:create()
    local offsety = math.random(kJumpDis)
    y=offsety+y
	lbl:setFntFile(FNList.BlackNum)
	lbl:setPosition(ccp(x,y))
	lbl:setScale(0.5)
	obj:egNode():addChild(lbl)
	local damageTxt = math.abs(damage)
	local color = kRedColor
	if damage >0 then 
        damageTxt = string.format("%s%d","+",damage) 
        color = kGreenColor
    end
	lbl:setText(damageTxt)
	if not isEmemy then lbl:setColor(color) 
	else
		lbl:setColor(kYellowColor) 
	end
	
	local jumpto = CCJumpTo:create(0.2,ccp(x,y+kJumpDis),kRandomM,1)
	local scaleto = CCScaleTo:create(0.2,1.2)
	local spawn = CCSpawn:createWithTwoActions(jumpto,scaleto)
	local delay = CCDelayTime:create(0.8)
	local function callbackfunc()
        obj:egNode():removeChild(lbl,true)
	end
	local callfunc = CCCallFuncN:create(callbackfunc)
	local array = CCArray:create()
	array:addObject(spawn)
	array:addObject(delay)
	array:addObject(callfunc)
	local action = CCSequence:create(array)
	lbl:runAction(action)
end
--暴击
function __damagelayer.showCriticalStrike(obj,damage,x,y,isEmemy)
	 local lbl = LabelBMFont:create()
    local offsety = math.random(kJumpDis)
    y=offsety+y
	lbl:setFntFile(FNList.BlackNum)
	lbl:setPosition(ccp(x,y))
	lbl:setScale(0.4)
	obj:egNode():addChild(lbl)
	local damageTxt = math.abs(damage)
	local color = kRedColor
	if damage >0 then 
        damageTxt = string.format("%s%d","+",damage) 
        color = kGreenColor
    end
	lbl:setText(damageTxt)
	if not isEmemy then lbl:setColor(color) end
	
	local jumpto = CCJumpTo:create(0.2,ccp(x,y+kJumpDis),kRandomM,1)
	local scaleto = CCScaleTo:create(0.2,1)
	local spawn = CCSpawn:createWithTwoActions(jumpto,scaleto)
	local delay = CCDelayTime:create(0.5)
	local function callbackfunc()
        obj:egNode():removeChild(lbl,true)
	end
	local callfunc = CCCallFuncN:create(callbackfunc)
	local array = CCArray:create()
	array:addObject(spawn)
	array:addObject(delay)
	array:addObject(callfunc)
	local action = CCSequence:create(array)
	lbl:runAction(action)
end
--闪避
function __damagelayer.showDodge(obj,x,y,isEmemy)
	 local lbl = Label:create()
    local offsety = math.random(kJumpDis)
    y=offsety+y
	lbl:setFontName(FNList.STHUPO)
	lbl:setFontSize(24)
	lbl:setScale(0.5)
	lbl:setPosition(ccp(x,y))
	obj:egNode():addChild(lbl)
	lbl:setText("Miss")
	if not isEmemy then lbl:setColor(kRedColor) end
	local jumpto = CCJumpTo:create(0.3,ccp(x,y+kJumpDis),kRandomM,1)
	local scaleto = CCScaleTo:create(0.3,1)
	local spawn = CCSpawn:createWithTwoActions(jumpto,scaleto)
	local delay = CCDelayTime:create(0.4)
	local function callbackfunc()
        obj:egNode():removeChild(lbl,true)
	end
	local callfunc = CCCallFuncN:create(callbackfunc)
	local array = CCArray:create()
	array:addObject(spawn)
	array:addObject(delay)
	array:addObject(callfunc)
	local action = CCSequence:create(array)
	lbl:runAction(action)
end 
DamageLayer={}
function DamageLayer.new()
    local obj={}
    table_aux.unpackTo(__damagelayer, obj)
    Layer.install(obj)
    return obj
end
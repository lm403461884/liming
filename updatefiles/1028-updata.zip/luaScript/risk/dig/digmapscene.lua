
local __digmapscene={}
function __digmapscene.init(obj,sceneID)
    obj._digmaplayer = DigMapLayer.new(sceneID)
    obj._digmaplayer:egAttachTo(obj,1,1)
end
DigMapScene={}
function DigMapScene.new(sceneID)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__digmapscene, obj)
    obj:init(sceneID)
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
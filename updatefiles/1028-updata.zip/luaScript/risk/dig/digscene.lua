
local kGroundOrder = 1
local kPropOrder = 3
local kBaseOrder = 2

local __digscene={}

function __digscene.init(obj)
    obj._d_data = RiskHelper.getDigSceneData()
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)

	local function callback()
        obj._baseWidget = DigLayer.new(obj._d_data)
		obj._baseWidget:egAttachTo(obj,kBaseOrder,kBaseOrder)
		obj._propWidget = PropLayer.new(account_data)
		obj._propWidget:egAttachTo(obj,kPropOrder,kPropOrder)
		local posx,posy = obj._propWidget:egNode():getPosition()
		obj._propWidget:egNode():setPosition(ccp(posx-50,posy))
		showEmDialog(obj,GuideScene.def.kDigScene) --����������Ϣ
    end
    obj._groundlayer:showInDigScene()
	obj._groundlayer:onHeroShown(callback)
	
    

end
DigScene={}
function DigScene.new()
    SoundHelper.playBGM(SoundList.dig_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__digscene, obj)
    obj:init()
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
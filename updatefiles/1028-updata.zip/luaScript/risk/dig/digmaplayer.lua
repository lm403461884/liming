local kBtnBack = "btn_back"
local kImgTrain = "train"
local kPanelTouch = "map_touch_panel"
local kPanelMask = "mask_panel"
local kImgArrowLeft = "img_arrow_left"
local kImgArrowRight = "img_arrow_right"
local kPanelShow = "panel_show"

local kPanelLeft = "panel_touch_left"
local kMapImgLeft = "img_map_left"


local kPanelNotice = "notice_panel"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnNo2 = "btn_no_2"

local __digmaplayer={}
function __digmaplayer.init(obj)
    obj._touchAreaID = 0
    obj._areaSprites = {}
    obj:showPromptPanel(false)
    if account_data.digLv > 8 then
        local mapLeft = {}
        CocosWidget.install(mapLeft,JsonList.mapLeftLayer)
        mapLeft:egNode():setPosition(ccp(-1246,0))
        obj:egGetWidgetByName(kPanelShow):addChild(mapLeft:egNode())
        obj:egShowWidget(kPanelLeft)
        obj:egShowWidget(kImgArrowLeft)
        obj:fadeWidget(obj:egGetWidgetByName(kImgArrowLeft))
        obj:egSetWidgetTouchEnabled(kPanelLeft,false)
        obj:bindTouchLeftListener()
        
        local imgWidget = obj:egGetWidgetByName(kMapImgLeft)
        local sprite =  tolua.cast(imgWidget:getVirtualRenderer(),"CCSprite")
        sprite:getTexture():setAliasTexParameters()
    end    
    obj:showTrain()--��ʾС��
	--����PVE��� ���������ͼ
	for areaID,area in pairs(account_data.unlockedPVE) do
		--����ѽ�������Ľ��沼��
		if area[1] then
		    local widgetName = 'touch_area_'..areaID
		    local img = tolua.cast(obj:egGetWidgetByName(widgetName),"ImageView")
		    local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
		    obj._areaSprites[areaID] = sprite
			obj:loadLocalSpec(areaID)
			--�޳���������
			local maskCtrl = obj:egGetWidgetByName('mask_'..areaID)
			maskCtrl:runAction(CCFadeOut:create(1))
		end
	end
end
--�ڵ�ǰ������ʾС��
function __digmaplayer.showTrain(obj)	
    local touchArea = obj:egGetWidgetByName('touch_area_'..account_data.worldAreaID)
    local size = touchArea:getSize()
    local anchor = touchArea:getAnchorPoint()
    local x=0
    local y=0
    if account_data.worldAreaID> 8 then
        x = touchArea:getPositionX() + (0.5-anchor.x)*size.width-1244
        y = touchArea:getPositionY()+ (0.5-anchor.y)*size.height
    else
        x = touchArea:getPositionX() + (0.5-anchor.x)*size.width
        y = touchArea:getPositionY()+ (0.5-anchor.y)*size.height
    end    
	local train = obj:egGetWidgetByName(kImgTrain)
	train:setPosition(ccp(x,y))
	local moveAction = CCRepeatForever:create(CCSequence:createWithTwoActions(CCMoveBy:create(0.5, ccp(-10, 0)), CCMoveBy:create(0.5, ccp(10, 0))))
	train:runAction(moveAction)
end
--���ص����ز�
function __digmaplayer.loadLocalSpec(obj,areaid)
	local respanel = obj:egGetWidgetByName('res_'..areaid)
	local margin = 10
	local cellw = 48
	for key,coinIdx in ipairs(scene_data[areaid].localSpec) do
		local imgSrc = ImageList["comm_"..KVariantList.coinType[coinIdx]]
		local img = ImageView:create()
		img:loadTexture(imgSrc,UI_TEX_TYPE_PLIST)
		img:ignoreContentAdaptWithSize(false)
		img:setSize(CCSizeMake(cellw,cellw))
		img:setAnchorPoint(ccp(0,0))
		img:setPosition(ccp((key-1)*(cellw + margin),0))
		respanel:addChild(img)
	end
end
--��ȡ��ǰ���������ID,�޵������ʱ����0
function __digmaplayer.getTouchedAreaID(obj,pos)
    for areaid,sprite in pairs(obj._areaSprites) do
        local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
        if not isalpha then
            return areaid
        end
	end
	return 0
end
--��ͼ�����������¼�
function __digmaplayer.bindTouchListener(obj)
    local beginPos = nil
    local moved = false
    local panelShow = obj:egGetWidgetByName(kPanelShow)
    local posx,posy = panelShow:getPosition()
    local function touchBegan(sender)
		--sender:setTouchEnabled(false)
		obj:egSetWidgetTouchEnabled(kPanelTouch,false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		local pos =sender:getTouchStartPos()
		beginPos = pos
		moved=false
		obj._touchAreaID = obj:getTouchedAreaID(pos)
		if obj._touchAreaID > 0 then
		    obj._areaSprites[obj._touchAreaID]:setScale(1.05)
		end
    end
    local function touchMoved(sender)
        local movePos = sender:getTouchMovePos()
        if account_data.digLv>8 and movePos.x - beginPos.x>5 then
            if movePos.x-beginPos.x<1244 then
                local cell = movePos.x-beginPos.x
                panelShow:setPosition(ccp(posx+cell,posy))
                moved = true
            end    
        else
            panelShow:setPosition(ccp(posx,posy))
            moved = false
        end 
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if moved then
		    local function callback() obj:egSetWidgetTouchEnabled(kPanelLeft,true) end
		    local callFunc = CCCallFunc:create(callback)
		    local move = CCMoveTo:create(0.5,ccp(1244,0))
		    local sequece = CCSequence:createWithTwoActions(move,callFunc)
		    panelShow:runAction(sequece)
		    obj:egHideWidget(kImgArrowLeft)
		    obj:egGetWidgetByName(kImgArrowLeft):stopAllActions()
		    obj:egShowWidget(kImgArrowRight)
		    obj:fadeWidget(obj:egGetWidgetByName(kImgArrowRight))
		    if obj._touchAreaID > 0 then
                obj._areaSprites[obj._touchAreaID]:setScale(1)
            end    
		else
		    if obj._touchAreaID > 0 then
                obj._areaSprites[obj._touchAreaID]:setScale(1)
                sender:setTouchEnabled(true)
                obj:showPromptPanel(true)
            else
                sender:setTouchEnabled(true)
		    end
		end    
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			if obj._touchAreaID > 0 then
				obj._areaSprites[obj._touchAreaID]:setScale(1)
			end
			obj._touchAreaID = 0
		end
    end
    obj:egBindTouch(kPanelTouch,touchBegan,touchMoved,touchEnded,touchCanceled)
end
function __digmaplayer.bindTouchLeftListener(obj)
    local beginPos = nil
    local moved = false
    local panelShow = nil
    local posx,posy = nil
    local function touchBegan(sender)
		--sender:setTouchEnabled(false)
		obj:egSetWidgetTouchEnabled(kPanelLeft,false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		local pos =sender:getTouchStartPos()
		beginPos = pos
		moved=false
		obj._touchAreaID = obj:getTouchedAreaID(pos)
		if obj._touchAreaID > 0 then
		    obj._areaSprites[obj._touchAreaID]:setScale(1.05)
		end
	    panelShow = obj:egGetWidgetByName(kPanelShow)
        posx,posy = panelShow:getPosition()
    end
    local function touchMoved(sender)
        local movePos = sender:getTouchMovePos()
        if beginPos.x - movePos.x>5 then
            if beginPos.x - movePos.x<1244 then
                local cell = movePos.x-beginPos.x
                panelShow:setPosition(ccp(posx+cell,posy))
                moved = true
            end    
        else
            panelShow:setPosition(ccp(posx,posy))
            moved = false
        end 
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if moved then
		    local function callback() obj:egSetWidgetTouchEnabled(kPanelTouch,true) end
		    local callFunc = CCCallFunc:create(callback)
		    local move = CCMoveTo:create(0.5,ccp(0,0))
		    local sequece = CCSequence:createWithTwoActions(move,callFunc)
		    panelShow:runAction(sequece)
		    obj:egHideWidget(kImgArrowRight)
		    obj:egGetWidgetByName(kImgArrowRight):stopAllActions()
		    obj:egShowWidget(kImgArrowLeft)
		    obj:fadeWidget(obj:egGetWidgetByName(kImgArrowLeft))
		    if obj._touchAreaID > 0 then
                obj._areaSprites[obj._touchAreaID]:setScale(1)
            end  
		else
		    if obj._touchAreaID > 0 then
                obj._areaSprites[obj._touchAreaID]:setScale(1)
                sender:setTouchEnabled(true)
                obj:showPromptPanel(true)
            else
                sender:setTouchEnabled(true)
		    end
		end    
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			if obj._touchAreaID > 0 then
				obj._areaSprites[obj._touchAreaID]:setScale(1)
			end
			obj._touchAreaID = 0
		end
    end
    obj:egBindTouch(kPanelLeft,touchBegan,touchMoved,touchEnded,touchCanceled)
end
function __digmaplayer.bindBackListener(obj)
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
        local scene = DigScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __digmaplayer.fadeWidget(obj,widget)
	local scaleto1 = CCFadeTo:create(1,50)
	local scaleto2 = CCFadeTo:create(1,200)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end

function __digmaplayer.activeNewHoleTimer(obj)
    local cnt = 0
    local function callback(delta)
		cnt = cnt + delta
        if not AccountHelper:isLocked(kStateNewHole) then
            local scene = DigScene.new()
            scene:egReplace()
		elseif cnt >numDef.clientTimeOut then
            obj:egUnbindWidgetUpdate(kImgTrain)
			postEventSignal(kEventRequestTimeOut)
        end
    end
    obj:egBindWidgetUpdate(kImgTrain,callback)
end
--���¿���ʾ��
function __digmaplayer.showPromptPanel(obj,show)
    if show then
        obj:egShowWidget(kPanelNotice)
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
    else
        obj:egHideWidget(kPanelNotice)
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
    end
end

--ȷ�Ͽ��¿�
function __digmaplayer.bindYesListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:showPromptPanel(false)
        obj:egSetWidgetTouchEnabled(kPanelTouch,false)
        obj:egHideWidget(kBtnBack)
        SoundHelper.playEffect(SoundList.click_shop_goods)
		if obj._touchAreaID ~= account_data.worldAreaID then
			--������������л������������Ϣ
			--���¿ͻ��˱�����������ID
			SendMsg[934004](obj._touchAreaID)
			account_data.worldAreaID = obj._touchAreaID
		end
		AccountHelper:lock(kStateNewHole)--�������¿�״̬
		SendMsg[932002]()
		--�ھ���־������̸���,���¿�
		task.updateTaskStatus(account_data,task.client_event_id.new_dig,{obj._touchAreaID})
		----------------------------------------------------------
		AccountHelper:useActPt(numDef.openHole)
		----------------------------------------------------------
		--���¿��¿���ȴʱ��
		account_data.openHoleContext=os.time()+numDef.openHoleInterval
		for areaid,_ in pairs(obj._areaSprites) do
		    local maskCtrl = obj:egGetWidgetByName('mask_'..obj._touchAreaID)
		    if areaid == obj._touchAreaID then
		        local fadeto1 = CCFadeTo:create(1.5,255)
		        local fadeto2 = CCFadeTo:create(1.5,100)
		        local sequence = CCSequence:createWithTwoActions(fadeto1,fadeto2)
		        local repeatever = CCRepeatForever:create(sequence)
		        maskCtrl:runAction(repeatever)
		    else
		        maskCtrl:runAction(CCFadeIn:create(0.5))
		    end
		end
		obj:activeNewHoleTimer()
    end
	 local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--ȡ�����¿�
function __digmaplayer.bindNoListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj._touchAreaID = 0
        obj:showPromptPanel(false)
        SoundHelper.playEffect(SoundList.click_back_button)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end
DigMapLayer = {}
function DigMapLayer.new(sceneID)
	local obj =  TouchWidget.new(JsonList.digmapLayer)
    table_aux.unpackTo(__digmaplayer, obj)
    obj:init(sceneID)
	obj:bindBackListener()
	obj:bindTouchListener()
	obj:bindYesListener()
	obj:bindNoListener()
	return obj
end
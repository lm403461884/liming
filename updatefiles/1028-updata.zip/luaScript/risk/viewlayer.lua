local kcellW = 72
local kcellH = 72 
local kTileImg = ImageList.other_tile
local __viewlayer = {}
function __viewlayer.initlayer(obj,d_data)
    obj._d_data = d_data
    obj._w = obj._d_data.w + 1
    obj._h = obj._d_data.h + 1
    obj._areaid = obj._d_data.sceneID
    obj._batchnodes =  CCSpriteBatchNode:create(kTileImg,obj._w*obj._h)
    obj:egAddChild(obj._batchnodes)
    obj._lightedIdxs = {}
	obj._viewList = {}
end
function __viewlayer.showViewArroundDigTrace(obj)

    local openedView = Funs.getIdxInVision(obj._d_data.digTrace,obj._d_data.w,obj._d_data.h,obj._d_data.digVision,nil)--�ھ���Ұ
	local cnt = 0
    for idx,cnt in pairs(openedView) do
        obj._lightedIdxs[idx] = 1
        local y = Funs.getY(obj._d_data.w,idx)
        obj:lightTopLeft(idx,y)
        obj:lightTopRight(idx,y)
        obj:lightBottomLeft(idx,y)
        obj:lightBottomRight(idx,y)
		cnt = cnt + 1
		if cnt%10 == 0 then
			coroutine.yield()
		end
    end

end
function __viewlayer.hideViewArroundDigTrace(obj)
    local openedView = Funs.getIdxInVision(obj._d_data.digTrace,obj._d_data.w,obj._d_data.h,obj._d_data.digVision,nil)--�ھ���Ұ
    obj._viewList = {}
	local cnt = 0
    for idx,_ in pairs(openedView) do
        local y = Funs.getY(obj._d_data.w,idx)
        local topleft = idx + y
        local topright = idx + y + 1
        local bottomleft = idx + y + obj._w
        local bottomright = idx + y + obj._w + 1
		
		obj:insertViewAt(topleft)
        obj:insertViewAt(topright)
        obj:insertViewAt(bottomleft)
        obj:insertViewAt(bottomright)
		cnt = cnt + 1
		if cnt%10 == 0 then
			coroutine.yield()
		end
    end
end
function __viewlayer.showMineViewOutOfDigTrace(obj)
	for key,idx in ipairs(obj._d_data.mineOutRange) do
	    obj._lightedIdxs[idx] = 1
        local y = Funs.getY(obj._d_data.w,idx)
        obj:lightTopLeft(idx,y)
        obj:lightTopRight(idx,y)
        obj:lightBottomLeft(idx,y)
        obj:lightBottomRight(idx,y)
		coroutine.yield()
    end
end
function __viewlayer.showViewInVision(obj,idx,visionlen)

    local openedView = Funs.getIdxInVision(idx,obj._d_data.w,obj._d_data.h,visionlen,nil)--��Ұ��Χ�ڵ�����
    for idx,r in pairs(openedView) do
		
        obj._lightedIdxs[idx] = 1
        local y = Funs.getY(obj._d_data.w,idx)
        obj:lightTopLeft(idx,y)
        obj:lightTopRight(idx,y)
        obj:lightBottomLeft(idx,y)
        obj:lightBottomRight(idx,y)
    end
    
end
function __viewlayer.lightTopLeft(obj,idx,y)
    local viewIdx = idx + y
    obj:insertViewAt(viewIdx)
    obj._viewList[viewIdx]:lightBottomRight()
end
function __viewlayer.lightTopRight(obj,idx,y)
    local viewIdx = idx + y + 1
    obj:insertViewAt(viewIdx)
    obj._viewList[viewIdx]:lightBottomLeft()
end
function __viewlayer.lightBottomLeft(obj,idx,y)
    local viewIdx = idx + y + obj._w
    obj:insertViewAt(viewIdx)
    obj._viewList[viewIdx]:lightTopRight()
end
function __viewlayer.lightBottomRight(obj,idx,y)
    local viewIdx = idx + y + obj._w + 1
    obj:insertViewAt(viewIdx)
    obj._viewList[viewIdx]:lightTopLeft()
end
function __viewlayer.insertViewAt(obj,idx)
    if not obj._viewList[idx] then
        local block = Viewblock.new(obj._areaid)
        local x,y = obj:getPosByIdx(idx)
        block:egSetPosition(x,y)
        obj._batchnodes:addChild(block:egNode(),1,idx)
        obj._viewList[idx] = block
		if idx <= obj._w then
			obj._viewList[idx]:lightTop()
		end
    end
end
function __viewlayer.getPosByIdx(obj,idx)
    local x = kcellW*( Funs.getX(obj._w,idx)+ 0.5)
    local y = kcellH*(Funs.getViewY(obj._w,obj._h,idx)+0.5)
    return x,y
end
function __viewlayer.getOpendView(obj)
    return obj._lightedIdxs
end
function __viewlayer.isLighted(obj,idx)
	if  obj._lightedIdxs[idx] then 
		return true 
	else
		return false
	end
end
ViewLayer={}
function ViewLayer.new(d_data)
    local obj={}
    table_aux.unpackTo(__viewlayer, obj)
    Layer.install(obj)
    obj:initlayer(d_data)
    return obj
end
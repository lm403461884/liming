local kPanelLayer = "panel_rule"
local kScrollView = "scrollview_rule"
local kBtnBack = "btn_back"

local __expeditionrule={}
function __expeditionrule.init(obj)
    obj:loadRule()
end

function __expeditionrule.loadRule(obj)
    local cnt = #farPveDesc
    local scrollview = obj:egGetScrollView(kScrollView)
    local totalH = 0
    local layouttype = scrollview:getLayoutType()
    local w = scrollview:getSize().width
    for idx=1,cnt do
        local txtInfo = farPveDesc[idx]
        local lbl = Label:create()
        lbl:setText(txtInfo.txt)
        lbl:setFontSize(txtInfo.fontSize or 24 ) 
        if txtInfo.fontName then lbl:setFontName(txtInfo.fontName) end
		if txtInfo.color then lbl:setColor(ccc3(txtInfo.color[1],txtInfo.color[2],txtInfo.color[3])) end
		
		local lblW = lbl:getSize().width
		local lblH = lbl:getSize().height
		
		if lblW >= w then
			local rows = math.ceil(lblW/w) + 1
			lblW = w
			lblH = rows*lblH
			lbl:setTextAreaSize(CCSizeMake(lblW,lblH))
		else
			lbl:setTextAreaSize(CCSizeMake(w,lblH))
			lbl:setTextHorizontalAlignment(txtInfo.align or 0)
		end 
		scrollview:addChild(lbl,0,idx)
		local layoutparameter = lbl:getLayoutParameter(layouttype)
		layoutparameter:setMarginTo(0,txtInfo.margin_top or 0,0,txtInfo.margin_bottom or 0)
		lbl:setLayoutParameter(layoutparameter)
		totalH = totalH + lblH
    end
    scrollview:setInnerContainerSize(CCSizeMake(w,totalH))
end

function __expeditionrule.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelLayer)
    widget:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveTo:create(0.3,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end

function __expeditionrule.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __expeditionrule.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end
ExpeditionRule={}
function ExpeditionRule.new()
    local obj = TouchWidget.new(JsonList.expeditionRule)
    table_aux.unpackTo(__expeditionrule, obj)
    obj:init()
    obj:bindBackListener()
    obj:bindPanelListener()
    return obj
end
function ShowExpeditionRule(callback)
    local layer = ExpeditionRule.new()
    local scene = CCDirector:sharedDirector():getRunningScene()
	scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction(callback)    
end

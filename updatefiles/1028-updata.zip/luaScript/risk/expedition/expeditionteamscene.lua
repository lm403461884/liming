local __teamscene = {}
ExpeditionTeamScene = {}
function ExpeditionTeamScene.new(mapid)
	 SoundHelper.playBGM(SoundList.rish_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__teamscene, obj)
    obj._layer = ExpeditionTeamlayer.new(mapid)
    obj._layer:egAttachTo(obj)
    --showEmDialog(obj,GuideScene.def.kTeamScene) --����������Ϣ
    
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
local kPanelCard = "hero_list"
local kPanelItem = "item_list"
local kBtnBack = "btn_back"
local kBtnGo = "btn_go"
local kBtnSee = "btn_see"
local kPanelAward = "award_list"
local kLblAttack = "lbl_attack"
local kImgCardBg = "img_hero_bg"
local kImgSee = "img_see"
local kImgGo = "img_go"
local kImgBack = "img_back"
local kCellW = 145
local kCellH = 160
local kMarginX = 10
local kMarginY = 5
local kCardW = 210
local kMaxNum = 7
local __exteamlayer = {}
function __exteamlayer.init(obj,mapid)
    obj._heroItems = {} --Ӣ�ۿ�
    obj._emptyItems = {} --�հ׿�
    obj._heroCards = {} --Ӣ�ۿ�Ƭ
    obj._d_data=account_data
	obj._newMapId = mapid --��ǰѡ��ĵ�ͼID
    obj:initHeroBp()
	obj._newExTeam =  {} --̽�ն�Ӣ������
	obj._heroIdList = obj:getOrderdHeroList()
	obj:initExTeam()
	obj._teamAtk = obj:getExTeamAtkCap() --Զ����ս����
	obj:egSetLabelStr(kLblAttack,obj._teamAtk)
    obj:loadHeroItems()
	obj:doLoading()
	obj:loadAwards()
end
--��ʼ��Զ��������
function __exteamlayer.initExTeam(obj)
    local teamCnt = math.min(numDef.maxExTeamCnt,#obj._heroIdList)
	for idx = 1, teamCnt do
		local heroid = obj._heroIdList[idx]
		local herodata = obj._d_data.heroList[heroid]
		local hp = RiskHelper.getHeroMaxHpWithEquip(herodata,obj._d_data.equipments[herodata.eid])
		obj._newExTeam[heroid] = RiskHelper.calHPPower(hp,numDef.expeditionPower)
	end
end
--����ļ������Ӣ��ս�������ݱ�
function __exteamlayer.initHeroBp(obj)
	obj._heroBpTb={}
    for heroid,heroprop in pairs(obj._d_data.heroList) do
		obj._heroBpTb[heroid] = RiskHelper.getHeroBp(heroprop,obj._d_data)
    end
end
--��ȡ��ս���������Ӣ���б�
function __exteamlayer.getOrderdHeroList(obj)
	local teamTb = {}
	local memberTb = {}
	for heroid,heroprop in pairs(obj._d_data.heroList) do
		if obj._newExTeam[heroid] then
			table.insert(teamTb,heroid)
		else
			table.insert(memberTb,heroid)
		end
	end
	table.sort(teamTb,function(a,b) return obj._heroBpTb[a] > obj._heroBpTb[b] or (obj._heroBpTb[a]==obj._heroBpTb[b] and a > b) end)
	table.sort(memberTb,function(a,b) return obj._heroBpTb[a] > obj._heroBpTb[b] or (obj._heroBpTb[a]==obj._heroBpTb[b] and a > b) end)
    for idx = #teamTb,1,-1 do 
		table.insert(memberTb,1,teamTb[idx])
	end
	return memberTb
end
--Զ����ս����
function __exteamlayer.getExTeamAtkCap(obj)
	local atk = 0
	for heroid,_ in pairs(obj._newExTeam) do
		atk = atk + obj._heroBpTb[heroid]
	end
	return atk
end
function __exteamlayer.addHeroCard(obj,num)
	if obj._loadCnt >= #obj._heroIdList then return end
	local listview = obj:egGetScrollView(kPanelCard)
	local startIdx = math.min(obj._loadCnt + 1,#obj._heroIdList)
	local endIdx = math.min(obj._loadCnt+num,#obj._heroIdList)
	for idx = startIdx,endIdx do
		local heroid = obj._heroIdList[idx]
		local herocard =  ExHeroCard.new(heroid,obj._newExTeam[heroid],#obj._emptyItems<=0)
		listview:addChild(herocard:egNode())
		herocard:egSetPosition(obj._loadCnt*kCardW,0)
		obj._heroCards[heroid] = herocard
		obj:bindJoinTeamCallback(herocard)
		obj._loadCnt = obj._loadCnt + 1
	end
end
--����Ӣ�ۿ�Ƭ
function __exteamlayer.loadHeroCards(obj)
    obj._loadCnt = 0
    local neww = kCardW * #obj._heroIdList
	local listview = obj:egGetScrollView(kPanelCard)
    local size = listview:getSize()
    if neww > size.width then
        listview:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
	while obj._loadCnt < kMaxNum do
		obj:addHeroCard(1)
		coroutine.yield()
	end
	obj:bindScrollListener()
end
function __exteamlayer.doLoading(obj)
	local function coFunc()
		obj:loadHeroCards()
	end
	local coLoad = coroutine.create(coFunc)
	local function callback()
		local f1,f2 = coroutine.resume(coLoad)
		if not f1 then
			obj:egUnbindWidgetUpdate(kImgCardBg)
			if type(f2) == "string" then print(f2) end
		end
	end
	obj:egBindWidgetUpdate(kImgCardBg,callback)
end
function __exteamlayer.bindScrollListener(obj)
	local scrollview = obj:egGetScrollView(kPanelCard)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadCnt >=  #obj._heroIdList then return end
            local innerContainer = scrollview:getInnerContainer()
            local posX = innerContainer:getPositionX()
            if (obj._loadCnt * kCardW) + posX  < scrollview:getSize().width then
                obj:addHeroCard(1)
            end
        end
    end
    scrollview:addEventListenerScrollView(scrollEvent)
end
--�󶨿�Ƭ���Ƶ���¼�
function __exteamlayer.bindJoinTeamCallback(obj,herocard)
    local function callback(sender)
		local heroid = sender:getprop("heroid")
		local herodata = obj._d_data.heroList[heroid]
		local hp = RiskHelper.getHeroMaxHpWithEquip(herodata,obj._d_data.equipments[herodata.eid])
		
        obj._newExTeam[heroid] = RiskHelper.calHPPower(hp,numDef.expeditionPower)
        obj._emptyItems[1]:updateHeroInfo(heroid,obj._newExTeam[heroid])
        table.insert(obj._heroItems,obj._emptyItems[1])
        table.remove(obj._emptyItems,1)
        obj:reOrderExTeamItem()
        obj:reOrderEmptytem()
        obj:reorderHeroCard()
        local heroAtk = obj._heroBpTb[heroid]
		obj._teamAtk = obj._teamAtk + heroAtk
		obj:egSetLabelStr(kLblAttack,obj._teamAtk)
		obj:egSetWidgetEnabled(kBtnGo,#obj._heroItems > 0)--ûѡ��Ӣ��ʱ���ܳ���
		--�ھ���־������̸��� ����С�ӳ�Ա
		--task.updateTaskStatus(account_data,task.client_event_id.team_add,{heroid})	
		----------------------
    end
    herocard:onJoinClicked(callback)
end
--���¶�Ӣ�ۿ�Ƭ��������
function __exteamlayer.reorderHeroCard(obj)
	obj._heroIdList = obj:getOrderdHeroList()
	 local scrollview = obj:egGetScrollView(kPanelCard)
	 for key,heroid in ipairs(obj._heroIdList) do
		if key <= obj._loadCnt then
			if obj._heroCards[heroid] then
				obj._heroCards[heroid]:egSetPosition((key-1)*kCardW,0)
				obj._heroCards[heroid]:updateJoinState(obj._newExTeam[heroid],#obj._emptyItems<=0)
			else
				local herocard =  ExHeroCard.new(heroid)
				scrollview:addChild(herocard:egNode())
				herocard:egSetPosition((key-1)*kCardW,0)
				obj._heroCards[heroid] = herocard
				obj:bindJoinTeamCallback(herocard)
			end
		else
			if  obj._heroCards[heroid] then
				scrollview:removeChild(obj._heroCards[heroid]:egNode(),true)
				obj._heroCards[heroid] = nil
			end
		end
	 end
end
function __exteamlayer.reOrderExTeamItem(obj)
    local colNum = math.ceil(numDef.maxExTeamCnt/2)
    for idx,heroitem in ipairs(obj._heroItems) do
        heroitem:setItemTouchEnabled(true)
        local x = kMarginX + ((idx -1)%colNum)*kCellW
        local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-idx)/colNum)
        heroitem:egSetPosition(x,y)
    end
end
function __exteamlayer.reOrderEmptytem(obj)
    local colNum = math.ceil(numDef.maxExTeamCnt/2)
    local cnt = #obj._heroItems
    for idx,heroitem in ipairs(obj._emptyItems) do
         heroitem:setItemTouchEnabled(true)
         local x = kMarginX + ((cnt+idx -1)%colNum)*kCellW
         local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-cnt-idx)/colNum)
         heroitem:egSetPosition(x,y)
    end
end
function __exteamlayer.reLoadExTeamItem(obj)
    local colNum = math.ceil(numDef.maxExTeamCnt/2)
    local removeIdx = 0
    for idx,heroitem in ipairs(obj._heroItems) do
        heroitem:setItemTouchEnabled(true)
        local heroid =  heroitem:getprop("heroid")
        if heroid == 0 then
            removeIdx = idx
        elseif removeIdx~=0  then
             idx = idx - 1 
            local x = kMarginX + ((idx -1)%colNum)*kCellW
            local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-idx)/colNum)
            heroitem:egSetPosition(x,y)
        end
    end
    if removeIdx > 0 then
        table.remove(obj._heroItems,removeIdx)
    end
end
--����Զ����Ӣ��
function  __exteamlayer.loadHeroItems(obj)
    local listview= obj:egGetWidgetByName(kPanelItem)
	local colNum = math.ceil(numDef.maxExTeamCnt/2)
	local loadNum = 0
	local function getHeroItem(heroid)
	    local heroitem = ExpeditionItem.new(heroid,obj._newExTeam[heroid])
		local x = kMarginX + (loadNum%colNum)*kCellW
		local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-loadNum-1)/colNum)
        heroitem:egSetPosition(x,y)
        listview:addChild(heroitem:egNode())
        obj:bindItemClickEvent(heroitem)
        loadNum = loadNum + 1
        return heroitem
	end
    for heroid,_ in pairs(obj._newExTeam) do
       local heroitem =  getHeroItem(heroid)
       table.insert(obj._heroItems,heroitem)
       if loadNum >= numDef.maxExTeamCnt then return end
    end
    while loadNum < numDef.maxExTeamCnt do
         local heroitem =  getHeroItem(0)
        table.insert(obj._emptyItems,heroitem)
    end
end
function __exteamlayer.loadAwards(obj)
	local panel = obj:egGetWidgetByName(kPanelAward)
	local stageList = assert(farpveCalc.stageArrcount[obj._newMapId].stage)
    local tbAwards = {}
    for key,stageid in ipairs(stageList) do
        local stageAward = farpveCalc.getAwardRes(account_data,stageid)
        for key,coinname in ipairs(KVariantList.coinType) do
			if stageAward[coinname] and stageAward[coinname]>0 then
				tbAwards[coinname] = (tbAwards[coinname] or 0) + stageAward[coinname]
			end
		end
    end
	for key,coinname in ipairs(KVariantList.coinType) do
		if tbAwards[coinname] and tbAwards[coinname]>0 then
			local item = ImgPropItem.new(coinname,tbAwards[coinname])
			panel:addChild(item:egNode())
		end
	end
end
--Ӣ�ۿ����¼�
function __exteamlayer.bindItemClickEvent(obj,heroitem)
    local function clickCallback(sender)
        local heroid = sender:getprop("heroid")
        if heroid > 0 then
           sender:updateHeroInfo(0,0)
           obj._newExTeam[heroid] = nil
           table.insert(obj._emptyItems,sender)
           obj:reLoadExTeamItem()
           obj:reOrderEmptytem()
           obj:reorderHeroCard()
           local heroAtk = obj._heroBpTb[heroid]
           obj._teamAtk = obj._teamAtk - heroAtk
           obj:egSetLabelStr(kLblAttack,obj._teamAtk)
		   obj:egSetWidgetEnabled(kBtnGo,#obj._heroItems > 0)--ûѡ��Ӣ��ʱ���ܳ���
		end
    end
    heroitem:onItemClicked(clickCallback)    
end

--�󶨷��ذ���������
function __exteamlayer.bindBackListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgBack):setScale(1.1)
	end
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:egGetWidgetByName(kImgBack):setScale(1)
        SoundHelper.playEffect(SoundList.click_back_button) --����
		if not obj._d_data.exMission then
			local scene = TownScene.new()
			scene:egReplace()
		else
			--������ͼ
			local scene =ExMissionScene.new()
			scene:egReplace()
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgBack):setScale(1)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end 
--��ʼ��Զ������
function __exteamlayer.initExMission(obj)
	local stageid = farpveCalc.stageArrcount[obj._newMapId].stage[1]
	local t_next = Funs.getTimeWithHMS(numDef.expeditionUTH,numDef.expeditionUTM,0,account_data.scOffsetTime)
	obj._d_data.exMission={stages={[stageid]=0},creatureList={},nextSt=t_next,mapID = obj._newMapId }
	local stageinfo = farpveQuery.queryStage(stageid)
	for pos,monsterid in pairs(stageinfo.creatureList) do
		 obj._d_data.exMission.creatureList[pos] = monsterid
	end
end
function __exteamlayer.bindGoListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgGo):setScale(1.1)
	end
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:egGetWidgetByName(kImgGo):setScale(1)
        SoundHelper.playEffect(SoundList.click_back_button) --����
        obj._d_data.expedition = obj._newExTeam
		local heroteam = {}
		for key,val in pairs(obj._d_data.expedition) do
			table.insert(heroteam,key)
		end
		--��ȡ�µ�Զ����������
		obj:initExMission()
		SendMsg[934012](obj._newMapId,heroteam )
		local scene =ExpeditionLoadScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgGo):setScale(1)
		end
	end
    obj:egBindTouch(kBtnGo,touchBegan,nil,touchEnded,touchCanceled)
end
function __exteamlayer.bindSeeListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgSee):setScale(1.1)
	end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgSee):setScale(1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        local function callback() sender:setTouchEnabled(true) end
        ShowExpeditionRule(callback)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgSee):setScale(1)
		end
	end
    obj:egBindTouch(kBtnSee,touchBegan,nil,touchEnded,touchCanceled)
end
ExpeditionTeamlayer={}
function ExpeditionTeamlayer.new(mapid)
    local obj = TouchWidget.new(JsonList.expeditionLayer)
    table_aux.unpackTo(__exteamlayer, obj)
    obj:init(mapid)
    obj:bindBackListener()
	obj:bindGoListener()
	obj:bindSeeListener()
    return obj
end
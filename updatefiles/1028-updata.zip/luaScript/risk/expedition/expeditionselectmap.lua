local kPanelLayer = "panel_select"
local kBtnBack = "btn_back"
--local kPanelMap = "panel_map"
local kScrollMap = "scroll_map"
local kImgArrow = "img_arrow"
local kImgBg = "img_bg"

local kLblName = "lbl_map_name"
local kLblCheckNum = "lbl_check_num"
local kLblBossNum = "lbl_boss_num"
local kPanelAward1 = "panel_reward1"
local kPanelAward2 = "panel_reward2"
local kBtnEdit = "btn_edit"
local kImgMap = "img_normal_map"

local kCellH = 150
local kCellW = 220
local __expeditionselectmap={}
function __expeditionselectmap.init(obj)
    obj._idx = nil
    obj:egHideWidget(kImgArrow)
    obj:loadAreas()
end
function __expeditionselectmap.loadAreas(obj)
    local scrollview = obj:egGetWidgetByName(kScrollMap)
    local size = scrollview:getSize()
    local maxCount = #farpveCalc.stageArrcount
    local newW = maxCount/2*kCellW
    if newW > size.width then
        scrollview:setInnerContainerSize(CCSizeMake(newW,size.height))
    end
    for idx,item in ipairs(farpveCalc.stageArrcount) do
        local unlock = false
        if item.unlockLv <= account_data.digLv then unlock = true end
        local mapItem = ExpeditionMapItem.new(idx,unlock)
        local maxRowCount = math.floor((maxCount+1)/2)
        if unlock then 
            obj._idx = idx
            obj._selectedItem = mapItem 
        end
        if idx <= maxRowCount then
            mapItem:egNode():setPosition(ccp((idx-1)*kCellW,kCellH))
        else
            mapItem:egNode():setPosition(ccp((idx-maxRowCount-1)*kCellW,0))
        end    
        scrollview:addChild(mapItem:egNode())
        obj:bindItemListener(mapItem)
    end 
    obj:loadInfo(obj._idx)
    obj._selectedItem:setItemFocuse(true)
    if maxCount>8 then obj:egShowWidget(kImgArrow) end
end

function __expeditionselectmap.loadInfo(obj,idx)
    local area_data = farpveCalc.stageArrcount[idx]
    obj:egSetLabelStr(kLblName,area_data.areaname)
    obj:egSetLabelStr(kLblCheckNum,#area_data.stage)
    obj:egSetLabelStr(kLblBossNum,area_data.bossCnt)
    local imgStr = string.format("GUIRes/PvrCcz/m_bg/abbr_map_%d.pvr.ccz",area_data.scene)
    obj:egChangeImg(kImgMap,imgStr)
    local awardList = obj:getAwardList(area_data)
    obj:loadAward(awardList)
end
function __expeditionselectmap.loadAward(obj,awardList)
    if obj._awardCnt then obj:clearAward() end
    local panel1 = obj:egGetWidgetByName(kPanelAward1)
    local panel2 = obj:egGetWidgetByName(kPanelAward2)
    obj._awardCnt = #awardList
    for idx ,item in ipairs(awardList) do
        local awarditem = AwardItem.new(item[1],item[2])
        if idx<=3 then
            panel1:addChild(awarditem:egNode(),1,idx)
        else
            panel2:addChild(awarditem:egNode(),1,idx)
        end
    end
end
function __expeditionselectmap.clearAward(obj)
    local panel1 = obj:egGetWidgetByName(kPanelAward1)
    local panel2 = obj:egGetWidgetByName(kPanelAward2)
    for idx=1,obj._awardCnt,1 do
        if idx<=3 then
            panel1:removeChildByTag(idx,true)
        else
            panel2:removeChildByTag(idx,true)
        end
    end
end
function __expeditionselectmap.getAwardList(obj,area_data)
    local awardList ={}
    local stageList = area_data.stage
    local tbAwards = {}
    for key,stageid in ipairs(stageList) do
        local stageAward = farpveCalc.getAwardRes(account_data,stageid)
        for key,coinname in ipairs(KVariantList.coinType) do
			if stageAward[coinname] and stageAward[coinname]>0 then
				tbAwards[coinname] = (tbAwards[coinname] or 0) + stageAward[coinname]
			end
		end
    end
    for idx=1,7 do
        local name = KVariantList.coinType[idx]
        if tbAwards[name] and tbAwards[name]>0 then
            table.insert(awardList,{name,tbAwards[name]})
        end
    end
    return awardList
end
function __expeditionselectmap.bindItemListener(obj,item)
    local function callback()
         obj._selectedItem:setItemFocuse(false)
         obj._selectedItem = item
         obj._selectedItem:setItemFocuse(true)
         local selectedIdx = item:getprop("idx")
         if obj._idx == selectedIdx then
             return
         else
             obj._idx = selectedIdx
             obj:loadInfo(obj._idx)
         end    
    end
    item:onItemClicked(callback)
end
function __expeditionselectmap.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kImgBg)
    widget:setPosition(ccp(660,720))  
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(660,357))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end
function __expeditionselectmap.hideWithAction(obj,callbackfunc)
    local function callback()
        obj:egRemoveSelf()
        if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.5,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __expeditionselectmap.bindEditListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)

		local scene =ExpeditionTeamScene.new(obj._idx)
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnEdit,nil,nil,touchEnded,touchCanceled)
end

function __expeditionselectmap.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        --obj:egRemoveSelf()
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

function __expeditionselectmap.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        --obj:egRemoveSelf()
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end

ExpeditionSelectMap={}
function ExpeditionSelectMap.new()
    local obj = TouchWidget.new(JsonList.expeditionSelectMap)
    table_aux.unpackTo(__expeditionselectmap, obj)
    obj:init()
    obj:bindEditListener()
    --obj:bindPanelListener()
    obj:bindBackListener()
    return obj
end
function showExpeditionSelectMap(callback)
    local layer = ExpeditionSelectMap.new()
    local scene = CCDirector:sharedDirector():getRunningScene()
	scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction(callback)
end

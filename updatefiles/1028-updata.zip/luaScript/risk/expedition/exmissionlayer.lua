local kPanelItem = "item_list"
local kImgItemBg = "item_bg"
local kBtnBack = "btn_back"
local kBtnGo = "btn_go"
local kBtnSee = "btn_see"
local kLblAttack = "lbl_attack"
local kPanelAward = "award_list"
local kPanelStageAward = "award_panel"

local kPanelSelect = "select_panel"
local kPanelTeam = "team_item_list"
local kLblTeamAtk = "lbl_team_atk"
local kBtnCancel = "btn_cancel"
local kBtnStart = "btn_start"
local kImgTeamBg = "img_team_bg"
local kImgMask = "img_select_mask"
local kImgBar = "img_car_bar"
local kLblAct = "lbl_act_val"

local kPanelMap = "map_scroll"
local kImgMap = "img_map"
local kImgNew = "img_new_far"

local kImgSee = "img_see"
local kImgGo = "img_go"
local kImgBack = "img_back"

local kCellW0 = 160
local kMarginX0 = 20
local kCellW = 145
local kCellH = 160
local kMarginX = 10
local kMarginY = 5
local kScale = 0.8
local kMaskOpacity = 100
local kMaxTeamNum = 4
local kWhiteColor = ccc3(255,255,255)
local kGrayColor = ccc3(128,128,128)
local kBrownColor = ccc3(83,49,22)
local kRedColor = ccc3(255,0,0)
local __exmissionlayer = {}
function __exmissionlayer.init(obj,d_data)
    obj._heroItems = {} --Ӣ�ۿ�
    obj._teamItems = {} --С�ӳ�Ա��
	obj._heroAtkList ={} --Զ����ս�������ݱ�
	obj._teamAtk = 0 --С��ս����
	obj._memberCnt = 0 --С��Ա����
	obj._selectedStage = 0 --ѡ�е�����ؿ�ID
	obj._costAct = 0 --��Ҫ���ĵ��ж���
    obj._d_data=d_data
	
	local totalAtk= obj:getExTeamAtkCap() --Զ����ս����
	obj:egSetLabelStr(kLblAttack,totalAtk)
	obj:egSetLabelStr(kLblTeamAtk,obj._teamAtk)--��ս����
    obj:loadHeroItems()
	obj:loadAwards()
	obj:loadExMission()
	obj:bindNewExpTimer() --��Զ����ʱ��	
	obj:hideTeamEditPanel()
end
--��Զ����ʱ��
function __exmissionlayer.bindNewExpTimer(obj)
	obj:egChangeImg(kImgGo,ImageList.btn_far_d,UI_TEX_TYPE_PLIST)
	obj:egHideWidget(kImgNew)
	local function update()
		if os.time() >= account_data.exMission.nextSt then
			obj:egUnbindWidgetUpdate(kBtnGo)
			obj:egChangeImg(kImgGo,ImageList.btn_far_n,UI_TEX_TYPE_PLIST)
			obj:egShowWidget(kImgNew)
			local scaleto1 = CCScaleTo:create(1,0.8)
			local scaleto2 = CCScaleTo:create(1,1)
			local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
			local repeatever = CCRepeatForever:create(sequence)
			obj:egGetWidgetByName(kImgNew):runAction(repeatever)
		end
	end
	obj:egBindWidgetUpdate(kBtnGo,update)
end
function __exmissionlayer.loadExMission(obj)
	local imgmap = obj:egGetWidgetByName(kImgMap)
	local stageList = assert(farpveCalc.stageArrcount[account_data.exMission.mapID].stage)
	for key,stageid in ipairs(stageList) do
		local mission =  ExMission.new(stageid,account_data.exMission.stages[stageid])
		local size = mission:egNode():getSize()
		mission:egSetPosition(mission:getprop("x") - size.width/2,mission:getprop("y") - size.height/2)
		imgmap:addChild(mission:egNode())
		obj:bindMissionEvent(mission)
	end
end
function __exmissionlayer.bindMissionEvent(obj,mission)
	local function clickCallBack(sender)
		obj._selectedStage = sender:getprop("stageid")
		obj:egShowWidget(kPanelSelect)
		obj:egShowWidget(kBtnCancel)
		obj:egShowWidget(kBtnStart)
		local stageinfo = farpveQuery.queryStage(obj._selectedStage )
		
		obj._costAct = stageinfo.costAct
		obj:egSetBMLabelStr(kLblAct,obj._costAct)
		if obj._costAct <= account_data.actPt  then
			obj:egSetWidgetColor(kLblAct,kWhiteColor)
		else
			obj:egSetWidgetColor(kLblAct,kRedColor)
		end
		obj:egSetWidgetEnabled(kBtnStart,false)
		
		obj:egSetWidgetTouchEnabled(kImgBar,false)--ȡ��̽�նӵ������
		obj:egSetWidgetTouchEnabled(kBtnCancel,true)
		obj:loadTeamItems() --����С��Ӣ�ۣ��տ�
		obj:loadStageAward(obj._selectedStage)
		local imgmask = obj:egGetWidgetByName(kImgMask)
		imgmask:runAction(CCFadeTo:create(0.2,kMaskOpacity))
		local teambg = obj:egGetWidgetByName(kImgTeamBg) --С�ӳ�Աģ��
		teambg:setScale(0)
		teambg:runAction(CCEaseBackOut:create(CCScaleTo:create(0.5,1)))
		local itembg = obj:egGetWidgetByName(kImgItemBg) --̽�ն�ģ��
		local backout = CCEaseBackOut:create(CCScaleTo:create(0.5,1))
		local function callback()
			sender:enableTouch(true)
		end
		local callfunc = CCCallFunc:create(callback)
		itembg:runAction(CCSequence:createWithTwoActions(backout,callfunc))
	end
	mission:onItemClicked(clickCallBack)
end
--����ѡ�йؽ�����Ϣ
function __exmissionlayer.loadStageAward(obj,stageid)
	local panel = obj:egGetWidgetByName(kPanelStageAward)
	local teampanel = obj:egGetWidgetByName(kPanelTeam)
	local cnt = panel:getChildrenCount()
	for idx =1,cnt do
		panel:removeChildByTag(idx,true)
	end
	local awardtb = farpveCalc.getAwardRes(account_data,stageid)
	local resCnt = 0
	local w = 0
	for key,coinname in ipairs(KVariantList.coinType) do
		if awardtb[coinname] and awardtb[coinname] > 0 then
			resCnt = resCnt + 1
			local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,awardtb[coinname]))
			panel:addChild(awarditem:egNode(),0,resCnt)
			w = awarditem:egNode():getSize().width + w
		end
	end
	if awardtb.exp > 0 then
		resCnt = resCnt + 1
		local awarditem = AwardItem.new("exp",string.format("%s%d",TxtList.numSymbol,awardtb.exp))
		panel:addChild(awarditem:egNode(),0,resCnt)
		w = awarditem:egNode():getSize().width + w
	end
	local oldw = teampanel:getSize().width*teampanel:getScale()
	panel:setPosition(ccp((oldw - w)/2 + teampanel:getPositionX(),panel:getPositionY()))
end
function __exmissionlayer.hideTeamEditPanel(obj)
	obj:egHideWidget(kPanelSelect)
	obj:egHideWidget(kBtnCancel)
	obj:egHideWidget(kBtnStart)
	obj._selectedStage = 0
	obj:clearTeamItems() --���С��Ӣ�۳�Ա
end
--Զ����ս����
function __exmissionlayer.getExTeamAtkCap(obj)
	local atk = 0
	for heroid,_ in pairs(obj._d_data.expedition) do
        obj._heroAtkList [heroid] = RiskHelper.getHeroBp( obj._d_data.heroList[heroid],obj._d_data)
		atk = atk + obj._heroAtkList[heroid]
	end
	return atk
end
--����Զ����Ӣ��
function  __exmissionlayer.loadHeroItems(obj)
    local listview= obj:egGetWidgetByName(kPanelItem)
	local colNum = math.ceil(numDef.maxExTeamCnt/2)
	local loadNum = 0
	local function addHeroItem(heroid)
	    local heroitem = ExpeditionItem.new(heroid,obj._d_data.expedition[heroid])
		local x = kMarginX + (loadNum%colNum)*kCellW
		local y = kMarginY + kCellH*math.floor((numDef.maxExTeamCnt-loadNum-1)/colNum)
        heroitem:egSetPosition(x,y)
        listview:addChild(heroitem:egNode())
		if heroid > 0 and heroitem:getprop("hp") > 0 then
			obj:bindItemClickEvent(heroitem)
			obj._heroItems[heroid] = heroitem
		else
			heroitem:setItemTouchEnabled(false)
		end
        loadNum = loadNum + 1
	end
    for heroid,_ in pairs(obj._d_data.expedition) do
       addHeroItem(heroid)
    end
    while loadNum < numDef.maxExTeamCnt do
        addHeroItem(0)
    end
end
function __exmissionlayer.loadAwards(obj)
	local panel = obj:egGetWidgetByName(kPanelAward)
	local stageList = assert(farpveCalc.stageArrcount[account_data.exMission.mapID].stage)
	local tbAwards = {}
	for key,stageid in ipairs(stageList) do
		local star = account_data.exMission.stages[stageid] or 0
		if star == 0  then
			local stageAward = farpveCalc.getAwardRes(account_data,stageid)
			for key,coinname in ipairs(KVariantList.coinType) do
				if stageAward[coinname] and stageAward[coinname]>0 then
					tbAwards[coinname] = (tbAwards[coinname] or 0) + stageAward[coinname]
				end
			end
		end
	end
	for key,val in pairs(tbAwards) do
		local item = ImgPropItem.new(key,val)
		panel:addChild(item:egNode())
	end
end
--Ӣ�ۿ����¼�
function __exmissionlayer.bindItemClickEvent(obj,heroitem)
    local function clickCallback(sender,x,y)
        local heroid = sender:getprop("heroid")
        local joined = sender:getprop("joined")
        if joined then
           obj:removeHeroItem(heroid)
		   sender:showJoinFlag(false)
		   obj._memberCnt = obj._memberCnt - 1
           obj._teamAtk = obj._teamAtk -obj._heroAtkList[heroid]
           obj:egSetLabelStr(kLblTeamAtk,obj._teamAtk)
        else
			if obj._memberCnt>= kMaxTeamNum then
				showPopTxt(TxtList.teamLimited,x,y,ccp(0.5,0.5))
			else
				sender:showJoinFlag(true)
				obj._memberCnt = obj._memberCnt + 1
				obj._teamItems[obj._memberCnt]:updateHeroInfo(heroid,account_data.expedition[heroid])
				obj._teamAtk = obj._teamAtk +obj._heroAtkList[heroid]
				obj:egSetLabelStr(kLblTeamAtk,obj._teamAtk)
		   end
		end
		 obj:changeStartState()
		sender:setItemTouchEnabled(true)
    end
    heroitem:onItemClicked(clickCallback)    
end

--����������ʾ��ѡ���Ӣ��С��
function __exmissionlayer.removeHeroItem(obj,heroid)
	local removeIdx = 0
    for idx,heroitem in ipairs(obj._teamItems) do
        heroitem:setItemTouchEnabled(true)
        local tmp_heroid =  heroitem:getprop("heroid")
        if tmp_heroid == heroid then
            removeIdx = idx
        elseif removeIdx > 0 then
            idx = idx - 1
            heroitem:egSetPosition(kMarginX0 + (idx -1)*kCellW0,0)
        end
    end
	local removeItem = obj._teamItems[removeIdx]
	removeItem:updateHeroInfo(0,0)
	table.insert(obj._teamItems,removeItem)
	table.remove(obj._teamItems,removeIdx)
	 removeItem:egSetPosition(kMarginX0 + (#obj._teamItems -1)*kCellW0,0)
end
--�����ѡ���С��Ӣ��
function __exmissionlayer.clearTeamItems(obj)
	local panel = obj:egGetWidgetByName(kPanelTeam)
	for key,_ in ipairs(obj._teamItems) do
		panel:removeChildByTag(key)
	end
	obj._teamAtk = 0
	obj._memberCnt = 0
	obj:egSetLabelStr(kLblTeamAtk,obj._teamAtk)--��ս����
	obj._teamItems = {}
	for heroid,heroitem in pairs(obj._heroItems) do
	    heroitem:showJoinFlag(false)
	end
end
--����С�ӳ�Ա��,�տ�
function __exmissionlayer.loadTeamItems(obj)
	local panel = obj:egGetWidgetByName(kPanelTeam)
	for idx = 1,kMaxTeamNum do
		local teamitem = ExpeditionItem.new(0,0)
		table.insert(obj._teamItems,teamitem)
		panel:addChild(teamitem:egNode(),1,idx)
        teamitem:egSetPosition(kMarginX0 + (idx-1)*kCellW0,0)
        obj:bindTeamItemClickEvent(teamitem)
	end
end
--С��Ӣ�ۿ����¼�
function __exmissionlayer.bindTeamItemClickEvent(obj,heroitem)
    local function clickCallback(sender)
        local heroid = sender:getprop("heroid")
        if heroid > 0 then
		   obj:removeHeroItem(heroid)
		   obj._heroItems[heroid]:showJoinFlag(false)
		   obj._memberCnt = obj._memberCnt - 1
           obj._teamAtk = obj._teamAtk -obj._heroAtkList[heroid]
           obj:egSetLabelStr(kLblTeamAtk,obj._teamAtk)
		   obj:changeStartState()
		end
    end
    heroitem:onItemClicked(clickCallback)    
end
function __exmissionlayer.changeStartState(obj)
	local btn = obj:egGetWidgetByName(kBtnStart)
	if obj._costAct <= account_data.actPt  then
		btn:setTouchEnabled(true)
		obj:egSetWidgetColor(kLblAct,kWhiteColor)
	else
		btn:setTouchEnabled(false)
		obj:egSetWidgetColor(kLblAct,kRedColor)
	end
	btn:setEnabled(obj._memberCnt > 0)
end
--�󶨷��ذ���������
function __exmissionlayer.bindBackListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgBack):setScale(1.1)
	end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:egGetWidgetByName(kImgBack):setScale(1)
        SoundHelper.playEffect(SoundList.click_back_button) --����
		obj:egNode():removeAllChildrenWithCleanup(true)
		local scene = TownScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgBack):setScale(1)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end 
--�µ�Զ��
function __exmissionlayer.bindGoListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgGo):setScale(1.1)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:egGetWidgetByName(kImgGo):setScale(1)
        SoundHelper.playEffect(SoundList.click_back_button)
		sender:setTouchEnabled(false)
		if os.time() >= account_data.exMission.nextSt  then
			showExpeditionSelectMap(function() sender:setTouchEnabled(true) end)
		else
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.needRest,pos.x,pos.y,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		end
		
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgGo):setScale(1)
		end
	end
    obj:egBindTouch(kBtnGo,touchBegan,nil,touchEnded,touchCanceled)
end
--����
function __exmissionlayer.bindStartListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --����
        --��¼ѡ���Ӣ�۲���Զ��
		account_data.exMission.team={}
		for key,teamItem in ipairs(obj._teamItems) do
			local heroid = teamItem:getprop("heroid")
			if heroid > 0 then table.insert(account_data.exMission.team,heroid) end
		end
		AccountHelper:useActPt(obj._costAct)
		obj:egNode():removeAllChildrenWithCleanup(true)
		local scene = ExPveScene.new(obj._selectedStage)
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
--�رն���ѡ�����
function __exmissionlayer.bindCancelListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetTouchEnabled(kImgBar,true)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --ȡ���༭
        local imgmask = obj:egGetWidgetByName(kImgMask)
		imgmask:runAction(CCFadeTo:create(0.2,0))
		local itembg = obj:egGetWidgetByName(kImgItemBg) --̽�ն�ģ��
		itembg:runAction(CCScaleTo:create(0.2,kScale)) 
		local teambg = obj:egGetWidgetByName(kImgTeamBg) --С�ӳ�Աģ��
		local scaleto = CCScaleTo:create(0.2,0)
		local function callback()
			obj:hideTeamEditPanel()
		end
		local callfunc = CCCallFunc:create(callback)
		local sequence = CCSequence:createWithTwoActions(scaleto,callfunc)
		teambg:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnded,touchCanceled)
end
function __exmissionlayer.bindSeeListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgSee):setScale(1.1)
	end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:egGetWidgetByName(kImgSee):setScale(1)
        SoundHelper.playEffect(SoundList.click_back_button)
        ShowExpeditionRule(function() sender:setTouchEnabled(true) end)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgSee):setScale(1)
		end
	end
    obj:egBindTouch(kBtnSee,touchBegan,nil,touchEnded,touchCanceled)
end
ExMissionlayer={}
function ExMissionlayer.new(d_data)
    local obj = TouchWidget.new(JsonList.expeditionMap)
    table_aux.unpackTo(__exmissionlayer, obj)
    obj:init(d_data)
    obj:bindBackListener()
	obj:bindGoListener()
	obj:bindStartListener()
	obj:bindCancelListener()
	obj:bindSeeListener()
    return obj
end
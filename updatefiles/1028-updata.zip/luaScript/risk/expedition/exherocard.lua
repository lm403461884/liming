local kBtnJoin = "btn_join"
local kBtnLeave = "btn_member"
local kBtnPhoto = "btn_photo"

local kLblName = "lbl_name"
local kLblLv = "lbl_lv"
local kLblAtk = "lbl_atk_val"
local kPanelStars = "star_list"

local __exherocard={}

function __exherocard.init(obj,heroid,ismember,isfull)
    obj:egSetWidgetTouchEnabled(kBtnLeave,false) --С�ӱ�ʶ��ť
    
    obj._heroid = heroid
    obj._herodata = account_data.heroList[obj._heroid]
	obj._s_cfg = hero_data.getConfig(obj._heroid)
    obj._s_herodata = obj._s_cfg[obj._herodata.lv]
	obj:addprop("heroid",obj._heroid)
	obj:addprop("maxHp",obj._s_herodata.maxHP)
    
    obj:egSetLabelStr(kLblName,obj._s_cfg.heroName)
    obj:egChangeBtnImg(kBtnPhoto,obj._s_cfg.photo,"","",UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblLv,obj._herodata.lv)
    obj:egSetLabelStr(kLblAtk,RiskHelper.getHeroBp( obj._herodata,account_data))
	obj:loadHeroGrade(obj._herodata.grade)
    obj:updateJoinState(ismember,isfull)
end
--����Ӣ�۽��׵ȼ�
function __exherocard.loadHeroGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
function __exherocard.updateJoinState(obj,ismember,isfull)
    if ismember then
        obj:egShowWidget(kBtnLeave)
		obj:egHideWidget(kBtnJoin)
    else
		obj:egHideWidget(kBtnLeave)
		if isfull then
			obj:egHideWidget(kBtnJoin)
		else
			obj:egShowWidget(kBtnJoin)
			obj:egSetWidgetTouchEnabled(kBtnJoin,true)
		end
    end
end

function __exherocard.onJoinClicked(obj,onclicked)
    obj._joinCallback = onclicked
end
function __exherocard.bindJoinListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_monster_menu)
        obj:egShowWidget(kBtnLeave)
        obj:egHideWidget(kBtnJoin)
        if obj._joinCallback then obj._joinCallback(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnJoin,nil,nil,touchEnded,touchCanceled)
end
function __exherocard.bindPhotoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
        --��ͨ��Ԥ������
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnPhoto,nil,nil,touchEnded,touchCanceled)
end

ExHeroCard={}
function ExHeroCard.new(heroid,ismember,isfull)
    local obj = {}
    CocosWidget.install(obj,JsonList.expeditionCard)
    table_aux.unpackTo(__exherocard, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
    obj:init(heroid,ismember,isfull)
    obj:bindPhotoListener()
    obj:bindJoinListener()
    return obj
end


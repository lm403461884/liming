local kBarLoad = "bar_mid"
local __loadscene = {}
function __loadscene.bindLoadTimer(obj)
	local passed = 0
	local total = 1.5
    local function callback(delta)
		passed = passed + delta
		local curper = math.min(passed*100/total,100)
		obj._baseWidget:egSetBarPercent(kBarLoad,curper)
		if curper ==100 then
			obj._baseWidget:egUnbindWidgetUpdate(kBarLoad)
			local scene = ExMissionScene.new()
			scene:egReplace()
		end
    end
    obj._baseWidget:egBindWidgetUpdate(kBarLoad,callback)
end
ExpeditionLoadScene = {}
function ExpeditionLoadScene.new()
	 SoundHelper.playBGM(SoundList.rish_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__loadscene, obj)
    obj._baseWidget = TouchWidget.new(JsonList.expeditionLoad)
    obj._baseWidget:egAttachTo(obj)
    obj:bindLoadTimer()
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
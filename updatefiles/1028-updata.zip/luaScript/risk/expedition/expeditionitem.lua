
--=================================
local kBtnItem = "btn_hero_bg"
local kBarHp = "bar_hero_hp"
local kBarPower = "bar_hero_power"
local kImgHp = "img_hero_hp"
local kImgPower = "img_hero_power"
local kImgHero = "img_hero"
local kImgBar = "img_bar"
local kImgJoin = "img_join"
local kPanelHero = "hero_panel"
local kPanelScale = "scale_panel"

local kImgLv = "img_lv"
local kLblLv = "lbl_lv"
local kLblDead = "lbl_dead"
local kBaseNum = 1000
local kGrayColor = ccc3(128,128,128)
local kWhiteColor = ccc3(255,255,255)
local __expeditionitem = {}
function __expeditionitem.updateHeroInfo(obj,heroid,hppower,herolv)
	if not hppower then hppower = 0 end
	obj._heroid = heroid
	obj._hppower = hppower
	obj:addprop("heroid",obj._heroid)
	obj:addprop("hp",0)
	obj:addprop("joined",false)
	if  obj._heroid > 0 then 
		if herolv then
			obj:egShowWidget(kImgHero)
			obj:egShowWidget(kImgLv)
			obj:egHideWidget(kLblDead)
			obj:egHideWidget(kImgHp)
			obj:egHideWidget(kImgPower)
			obj:egHideWidget(kImgBar)
			obj:egHideWidget(kImgJoin)
			obj:egSetBMLabelStr(kLblLv,herolv)
			local s_cfg = hero_data.getConfig(heroid)
			obj:egChangeImg(kImgHero,s_cfg.headPic,UI_TEX_TYPE_PLIST)
			obj:scaleAndShow(kImgLv,1,0.5)
			obj:scaleAndShow(kImgHero,1.2,0.5)
		else
			obj:showHeroInfo()
		end
	else
		obj:showEmptyBox()
	end
end
function __expeditionitem.showJoinFlag(obj,show)
	if show == obj:getprop("joined") then return end
	if show then
		obj:egShowWidget(kImgJoin)
		obj:egSetWidgetColor(kImgLv,kGrayColor)
		obj:egSetWidgetColor(kBtnItem,kGrayColor)
		obj:egSetWidgetColor(kImgHero,kGrayColor)
		obj:egSetWidgetColor(kImgHp,kGrayColor)
		obj:egSetWidgetColor(kImgPower,kGrayColor)
		--obj:egSetWidgetTouchEnabled(kBtnItem,false)
		obj:setprop("joined",true)
	else
		obj:egHideWidget(kImgJoin)
		obj:egSetWidgetColor(kImgLv,kWhiteColor)
		obj:egSetWidgetColor(kBtnItem,kWhiteColor)
		obj:egSetWidgetColor(kImgHero,kWhiteColor)
		obj:egSetWidgetColor(kImgHp,kWhiteColor)
		obj:egSetWidgetColor(kImgPower,kWhiteColor)
		--obj:egSetWidgetTouchEnabled(kBtnItem,true)
		obj:setprop("joined",false)
	end
	
end
function __expeditionitem.showEmptyBox(obj)
	obj:egHideWidget(kImgHp)
	obj:egHideWidget(kImgPower)
	obj:egHideWidget(kLblDead)
	obj:egHideWidget(kImgLv)
	obj:egHideWidget(kImgHero)
	obj:egHideWidget(kImgJoin)
end
function __expeditionitem.showHeroInfo(obj)
	obj._hero_prop =account_data.heroList[obj._heroid]
    local s_cfg = hero_data.getConfig(obj._heroid)
	local lv = obj._hero_prop.lv
    obj:egChangeImg(kImgHero,s_cfg.headPic,UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblLv,lv)
    local hp,power = RiskHelper.getHPPower(obj._hppower) 
	obj:setprop("hp",hp)
	obj:egHideWidget(kImgJoin)
	if hp<= 0 then
		obj:egHideWidget(kImgHp)
		obj:egHideWidget(kImgPower)
		obj:egShowWidget(kLblDead)
		obj:egShowWidget(kImgLv)
	    obj:egShowWidget(kImgHero)
		obj:egSetWidgetColor(kImgLv,kGrayColor)
		obj:egSetWidgetColor(kBtnItem,kGrayColor)
		obj:egSetWidgetColor(kImgHero,kGrayColor)
		obj:scaleAndShow(kImgLv,1,0.5)
		obj:scaleAndShow(kImgHero,1.2,0.5)
		obj:scaleAndShow(kLblDead,1,0.5)
	else
		obj:egShowWidget(kImgHp)
		obj:egShowWidget(kImgPower)
		obj:egHideWidget(kLblDead)
		obj:egShowWidget(kImgLv)
	    obj:egShowWidget(kImgHero)
		obj:egSetWidgetColor(kImgLv,kWhiteColor)
		obj:egSetWidgetColor(kBtnItem,kWhiteColor)
		obj:egSetWidgetColor(kImgHero,kWhiteColor)
		local hero_data = s_cfg[lv]
		local eid = account_data.heroList[obj._heroid].eid
		local equiplv,equipqa = equipFuncs.getEquipQL(eid,account_data)
		local equipdata = equipFuncs.getData(eid,equiplv)
		obj:egSetBarPercent(kBarHp,hp*100/(hero_data.maxHP+equipdata.maxHP))
		obj:egSetBarPercent(kBarPower,power*100/numDef.maxPower)
		obj:scaleAndShow(kImgLv,1,0.5)
		obj:scaleAndShow(kImgHero,1.2,0.5)
	end
end
function __expeditionitem.scaleAndShow(obj,widgetName,scale,s)
    local widget = obj:egGetWidgetByName(widgetName)
    widget:setScale(0)
    local scaleto = CCScaleTo:create(s,scale)
    local backout = CCEaseBackOut:create(scaleto)
    widget:runAction(backout)
end
--����¼��ص�����
function __expeditionitem.onItemClicked(obj,callback)
	obj._clickCallback = callback
end
function __expeditionitem.setItemTouchEnabled(obj,enabled)
	obj:egSetWidgetTouchEnabled(kBtnItem,enabled)
end
--���ø���
function __expeditionitem.setItemlight(obj)
    local btnWidget = obj:egGetWidgetByName(kBtnItem)
    local btn = tolua.cast(btnWidget,"Button")
    btn:setFocused(true)
    --obj:egShowWidget(kImgBar)
end
--�󶨵���¼� 
function __expeditionitem.bindClickListener(obj)
    local function touchBegan(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_rescar_dig)
        local imgbar = obj:egGetWidgetByName(kImgBar)
        imgbar:setScale(1.08)
        imgbar:setOpacity(255)
        obj:egShowWidget(kImgBar)
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end

        local imgbar = obj:egGetWidgetByName(kImgBar)
        local scaleto = CCScaleTo:create(0.2,1.15)
        local fadeout = CCFadeOut:create(0.2)
        local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
        local function callback()
			obj:egHideWidget(kImgBar)
			if obj._heroid > 0 then
				local pos = sender:getTouchEndPos()
				sender:setTouchEnabled(true)
                if obj._clickCallback then obj._clickCallback(obj,pos.x,pos.y) end
                
            else
                sender:setTouchEnabled(true)
            end
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
        imgbar:runAction(sequence)
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			obj:egHideWidget(kImgBar)
		end
    end
    obj:egBindTouch(kBtnItem,touchBegan,nil,touchEnded,touchCanceled)
end
ExpeditionItem = {}
function ExpeditionItem.new(heroid,hppower,herolv) --����herolvʱΪPVP��PVE����
    local obj = {}
    CocosWidget.install(obj,JsonList.expeditionItem)
    table_aux.unpackTo(__expeditionitem, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
    obj:updateHeroInfo(heroid,hppower,herolv)
	obj:bindClickListener()
    return obj
end

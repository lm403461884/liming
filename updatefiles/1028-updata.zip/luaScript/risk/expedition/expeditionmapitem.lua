local kBtnItem = "btn_item"
local kLblCheckName = "lbl_ex_name"
local kImgMiniMap = "img_mini_map"
--local kPanelLock = "panel_lock"
local kLblLock = "lbl_lock"

local kColorGray = ccc3(160,160,160)

local __expeditionmapitem = {}
function __expeditionmapitem.init(obj,idx,unlock)
    obj._data = farpveCalc.stageArrcount[idx]
    obj:addprop("idx",idx)
    --obj:egHideWidget(kPanelLock) 
    if unlock then
        obj:egSetLabelStr(kLblCheckName,obj._data.name)
        --obj:egHideWidget(kPanelLock)
        obj:egHideWidget(kLblLock)
    else
        obj:egSetLabelStr(kLblCheckName,"???")
        --obj:egShowWidget(kPanelLock)
        obj:egShowWidget(kLblLock)
        obj:egSetLabelStr(kLblLock,string.format("%s%d",TxtList.unlockLv,obj._data.unlockLv))
        obj:setItemTouchEnabled(false)
    end   
    local imgStr = string.format("mini_map_%d.png",obj._data.scene)
    obj:egChangeImg(kImgMiniMap,imgStr,UI_TEX_TYPE_PLIST)
end
function __expeditionmapitem.setItemTouchEnabled(obj,enabled)
    obj:egSetWidgetTouchEnabled(kBtnItem,enabled)
    obj:egSetWidgetColor(kImgMiniMap,kColorGray)
end
function __expeditionmapitem.onItemClicked(obj,onclicked)
    obj._itemCallback = onclicked
end
function __expeditionmapitem.setItemFocuse(obj,focus)
    local btn = tolua.cast(obj:egGetWidgetByName(kBtnItem),"Button")
    btn:setFocused(focus)
end
function __expeditionmapitem.bindItemListener(obj)
    local function touchEnded(sender)
		--obj:egSetWidgetTouchEnabled(kBtnItem,false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		if obj._itemCallback then obj._itemCallback() end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
    end
	
    obj:egBindTouch(kBtnItem,nil,nil,touchEnded,touchCanceled)
end
ExpeditionMapItem = {}
function ExpeditionMapItem.new(idx,unlock)
    local obj = {}
    CocosWidget.install(obj,JsonList.expeditionMapItem)
    table_aux.unpackTo(__expeditionmapitem, obj)
    BaseProp.install(obj)
	InnerProp.install(obj)
    obj:init(idx,unlock)
    obj:bindItemListener()
    return obj
end

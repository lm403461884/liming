local kblockZorder = 0
local knuritentZorder = 1
local kmineralZorder = 2
local kblankZorder = 3
local kBrokenZorder = 4
local kTotalPtl = {1,2,4,6,10}
local kbatchZorder = 1
--local kgoldbatchZorder = 2
--local koilbatchZorder = 2
local kflagZorder = 5
local kcellW = 72
local kcellH = 72
local kFadeInSec = 0.5
local __blocklayer={}
local kTileImg = ImageList.other_tile
--������ͨ����
function __blocklayer.initlayer(obj,d_data)
    obj._d_data = d_data
    obj._blockdp = {} --����ֲ�
    obj._blocks = {}
    obj._maplook = {}
    obj._minerals = {}
    obj._blanks = {}
	obj._mineFlags = {}
    obj._matrixW =obj._d_data .w
    obj._matrixH = obj._d_data .h
    ----���������ڵ�
    obj._batchnodes =  CCSpriteBatchNode:create(kTileImg,obj._matrixW*obj._matrixH)
    obj._batchnodes:getTexture():setAliasTexParameters()
    obj:egAddChild(obj._batchnodes,kbatchZorder,kbatchZorder)
	obj._flaglayer = CCLayer:create()
	obj:egAddChild(obj._flaglayer,kflagZorder,kflagZorder)

    obj._areaid = d_data.sceneID
    for posIdx,item in pairs(obj._d_data.spread) do
        for idx=item[1],item[2] do
            obj._blockdp[idx] = posIdx
        end
    end
    for idx,_ in pairs(obj._d_data.digTrace) do
        obj._maplook[idx] = 0
    end
end
function __blocklayer.downloadMap(obj)
    GPS:downloadMap(obj._maplook, obj._matrixW, obj._matrixH, kcellW,kcellH)
	if mapService then
		mapService.start(math.floor(obj._matrixW/2))
	end
    PathCache.build()
end
function __blocklayer.markResCar(obj)
    for key,item in ipairs(obj._d_data.collectorList) do
        obj._maplook[item.pos] = 0
    end
end
--��ʾ�ھ���Ұ��Χ�ڵ�����
function __blocklayer.showBlocksInVision(obj,idx,visionlen)
    local openedView = Funs.getIdxInVision(idx,obj._matrixW,obj._matrixH,visionlen,nil)--��Ұ��Χ�ڵ�����
	for idx,_ in pairs(openedView) do
		if obj._d_data.digTrace[idx] then
			obj:showBlankAt(idx)
		elseif obj._d_data.mileSpread[idx] then
			obj:showMineAt(idx)
		else
			obj:showBlockAt(idx)
		end
	end

end
--��ʾ�ھ���Ұ��Χ�ڵ�����
function __blocklayer.showBlocksArroundDigTrace(obj)
    local openedView = Funs.getIdxInVision(obj._d_data.digTrace,obj._matrixW,obj._matrixH,obj._d_data.digVision,nil)--�ھ���Ұ
	local cnt = 0
    for idx,_ in pairs(openedView) do
        if obj._d_data.digTrace[idx] then
            obj:showBlankAt(idx)
        elseif obj._d_data.mileSpread[idx] then
            obj:showMineAt(idx)
        else
            obj:showBlockAt(idx)
        end
		cnt = cnt + 1
		if cnt%20== 0 then  
			coroutine.yield() 
		end
    end
end
--��ʾ�ھ���Ұ��Χ��Ŀ���
function __blocklayer.showMinesOutOfDigTrace(obj)
    for key,idx in ipairs(obj._d_data.mineOutRange) do
        obj:showMineAt(idx)
    end
end
function __blocklayer.showBlockAt(obj,idx)
    if not obj._blocks[idx] then
        local block = Block.new()
        local x,y = obj:getPosByIdx(idx)
        block:init(obj._areaid,obj._d_data.spread[obj._blockdp[idx]][5])
        block:setprop("deep",obj._blockdp[idx])
        block:setprop("birthPlace",idx)
        block:setprop("leftDigCount",obj._d_data.spread[obj._blockdp[idx]][4])--��Ҫ���ھ����
        block:setprop("digCount",obj._d_data.spread[obj._blockdp[idx]][4])
        block:setprop("digTrainLv",obj._d_data.spread[obj._blockdp[idx]][3])
        block:egSetPos(x,y)
        obj._blocks[idx] = block
        obj._batchnodes:addChild(block:egNode(),kblockZorder,idx)
        block:egSetAlpha(0)
        block:egRunAction(CCFadeIn:create(kFadeInSec))
        --block:egNode():getTexture():setAntiAliasTexParameters()
        block:egNode():getTexture():setAliasTexParameters()
    end
end
function __blocklayer.showBlankAt(obj,idx)
    if not obj._blanks[idx] then
        local blank = Blankblock.new()
        obj._blanks[idx] = blank
        local x,y = obj:getPosByIdx(idx)
        local sur = obj:getBlankSur(idx)
        blank:init(obj._areaid,sur)
        blank:setprop("birthPlace",idx)
        blank:setprop("deep",obj._blockdp[idx])
        blank:setprop("digTrainLv",obj._d_data.spread[obj._blockdp[idx]][3])
        blank:egSetPos(x,y)
        obj._batchnodes:addChild(blank:egNode(),kblankZorder,idx)
        blank:egNode():getTexture():setAliasTexParameters()
    end
end

function __blocklayer.showMineAt(obj,idx)
    if not obj._minerals[idx]  then
       -- local mine = Mine.new(idx,obj._d_data.mileSpread[idx],obj._areaid,obj._blockdp[idx])--����ID+���
	    local mine = Mine.new(idx,obj._d_data.mileSpread[idx],obj._areaid,obj._d_data.spread[obj._blockdp[idx]][5])--����ID+��Դid
        local x,y = obj:getPosByIdx(idx)
        mine:egSetPos(x,y)
        mine:setprop("deep",obj._blockdp[idx])
        mine:setprop("birthPlace",idx)
        mine:setprop("leftDigCount",obj._d_data.spread[obj._blockdp[idx]][4])--��Ҫ���ھ����
        mine:setprop("digCount",obj._d_data.spread[obj._blockdp[idx]][4])
        mine:setprop("digTrainLv",obj._d_data.spread[obj._blockdp[idx]][3])
        --mine:egNode():getTexture():setAntiAliasTexParameters()
        mine:egNode():getTexture():setAliasTexParameters()
        obj._minerals[idx] = mine
        obj._batchnodes:addChild(mine:egNode(),kmineralZorder,idx)
        ------------------------�������
        obj:showMineFlag(idx,x,y)
        --������Ч
        --obj:showMineParticle(idx,x,y)
        ---------------------
    end
end
--���ز���ʾ������ʶ
function __blocklayer.showMineFlag(obj,idx,x,y)
    if obj._d_data.showFlag then
        local flag = MineFlag.new(idx,obj._d_data)
        flag:egSetPos(x,y)
		local flagZorder =  obj._matrixW - Funs.getX(obj._matrixW,idx)
		obj._flaglayer:addChild(flag:egNode(),flagZorder,idx)
        --flag:egAttachTo(obj,kflagZorder,idx)
		obj._mineFlags[idx] = flag
    end
end
function __blocklayer.showBlockBroken(obj,target)
    local x = target:egGetPosX()
    local y = target:egGetPosY()
    local srcid = target:getprop("srcid")

    local animaName = Pic.getBlockAnima(srcid)
    local brokenobj = BrokenBlock.new(animaName)
    brokenobj:egSetPosition(x,y)
    brokenobj:egAttachTo(obj,kBrokenZorder,kBrokenZorder)
    brokenobj:showEffect()
end
function __blocklayer.insertBlankAt(obj,idx)
    if not obj._blanks[idx] then
        local blank = Blankblock.new()
        obj._blanks[idx] = blank
        local x,y = obj:getPosByIdx(idx)
        local sur = obj:getBlankSur(idx)
        blank:init(obj._areaid,sur)
        blank:setprop("birthPlace",idx)
        blank:setprop("deep",obj._blockdp[idx])
        blank:setprop("digTrainLv",obj._d_data.spread[obj._blockdp[idx]][3])
        blank:egSetPos(x,y)
        obj._batchnodes:addChild(blank:egNode(),kblankZorder,idx)
       -- blank:egSetAlpha(0)
       -- blank:egRunAction(CCFadeIn:create(kFadeInSec))
        obj._maplook[idx] = 0
        obj._d_data.digTrace[idx] = 1
        obj:refreshSurBlanks(idx)
        PathCache.append(idx)
        --blank:egNode():getTexture():setAntiAliasTexParameters()
        blank:egNode():getTexture():setAliasTexParameters()
    end
end
function __blocklayer.removeBlockAt(obj,idx)
    if obj._blocks[idx] == nil then return end
    obj._blocks[idx]:egRemoveSelf()
    obj._blocks[idx] = nil
    obj:insertBlankAt(idx)
end

--�Ƴ�ָ������λ�õĿ���
function __blocklayer.removeMineralAt(obj,idx)
    if obj._minerals[idx] == nil then return end
    obj._minerals[idx]:egRemoveSelf()
    obj._minerals[idx] = nil
    obj._d_data.mileSpread[idx] = nil
    if obj._mineFlags[idx] then
        obj._mineFlags[idx]:egRemoveSelf()
        obj._mineFlags[idx] = nil
    end
    obj:insertBlankAt(idx)
end
--��ȡ������Χ�������
function __blocklayer.getBlankSur(obj,idx)
    local w = obj._matrixW
    local h = obj._matrixH
    local idx_t = Funs.getTop(idx,w)
    local sur_t = 0
    local sur_l = 0
    if idx_t > 0 and obj._d_data.digTrace[idx_t] == nil then
        sur_t = 2  --���Ϸ�������
    end
    local idx_l = Funs.getLeft(idx,w)

    if idx_l > 0 and obj._d_data.digTrace[idx_l] == nil then
        sur_l = 1 --���������
    end
    local sur = sur_t + sur_l
    if sur == 0 then
        local idx_lt = Funs.getLeftTop(idx,w)
        if idx_lt > 0 and obj._d_data.digTrace[idx_lt] == nil then
            sur = 4  --���Ϸ�������
        end
    end
    if( sur == 0 or sur == 1 ) and idx <= w then
        sur = sur + 5
    end
    return sur
end
function __blocklayer.refreshSurBlanks(obj,idx)
    local w = obj._matrixW
    local h = obj._matrixH
    local suridxs = {}
    table.insert(suridxs,Funs.getRightBottom(idx,w,h))
    table.insert(suridxs,Funs.getBottom(idx,w,h))
    table.insert(suridxs,Funs.getRight(idx,w,h))
    --table.insert(suridxs,idx)
    for _,idx in ipairs(suridxs) do
        local blank = obj._blanks[idx]
        if blank then
            blank:setprop("sur",obj:getBlankSur(idx))
            blank:updateSur()
        end
    end
    suridxs= nil

end
--�ƶ�����ǰ����
function __blocklayer.isDigged(obj,idx)
    if not idx then return false end
    if idx > 0 and obj._d_data.digTrace[idx] then return true end
    return false
end
--�Ƿ��ǿ��ھ������
function __blocklayer.isRemoveableBlock(obj,idx)
    if obj:isRemovable(idx) then
        if not obj._d_data.mileSpread[idx] then return true end
    end
    return false
end
--�Ƿ����ѱ�¶�Ŀ���
function __blocklayer.isExposedMine(obj,idx)
    if obj:isRemovable(idx) then
        if obj._d_data.mileSpread[idx] then return true end
    end
    return false
end
function __blocklayer.isRemovable(obj,idx)
    if not idx then return false end
    if idx > 0 and obj._d_data.digTrace[idx] then return false end
    local w = obj._matrixW
    local h = obj._matrixH

    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  obj._d_data.digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  obj._d_data.digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  obj._d_data.digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  obj._d_data.digTrace[idx_l] then  return true end--����������ھ�
    return false
end
function __blocklayer.getIdxByPos(obj,x,y)
    local px = Funs.getpX(x,kcellW)

    local py = Funs.getpY(y,kcellH)

    local idx = Funs.getIndex(px,py,obj._matrixW,obj._matrixH)
    return idx
end
--��ȡ��Ļ������blocklayer��Ӧ������ID
--���겻��blocklayer��ʱ����nil
function __blocklayer.getIdxByScreenPos(obj,posX,posY)
    local touchPos = obj:egPosInNode(posX,posY)
    local x = touchPos.x
    local y = touchPos.y
    if x < 0 or x > kcellW *  obj._matrixW then return nil end
    if y < 0 or y > kcellH *  obj._matrixH then return nil end
    return obj:getIdxByPos(x,y)
end
function __blocklayer.getPosByIdx(obj,idx)
    local x = kcellW*( Funs.getX(obj._matrixW,idx)+ 0.5)
    local y = kcellH*(Funs.getViewY(obj._matrixW,obj._matrixH,idx)+0.5)
    return x,y
end
function __blocklayer.getMapLook(obj)
    return obj._maplook
end
BlockLayer={}
function BlockLayer.new(d_data)
    local obj={}
    table_aux.unpackTo(__blocklayer, obj)
    Layer.install(obj)
    obj:initlayer(d_data)
    return obj
end


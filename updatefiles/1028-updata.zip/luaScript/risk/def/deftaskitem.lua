local kLblTitle = "lbl_def_title"
local kBtnClick = "btn_task"
local kLblAtkVal = "lbl_atk_val"
local kListHero = "list_hero"
local kImgNew = "img_new_flag"
local kStar = {"img_star1","img_star2","img_star3",}
local kStarNull1 = "img_star_null1"
local kStarNull2 = "img_star_null2"
local kStarNull3 = "img_star_null3"
local kGrayColor = ccc3(128,128,128)
local __deftaskitem = {}
function __deftaskitem.init(obj,idx,stageinfo)
	obj:egHideWidget(kImgNew)
    if stageinfo then
	    obj._idx = idx
	    obj._stageInfo = stageinfo
        obj._defdata = pveGuardQuery.getName(obj._idx) --��ȡ������Ϣ
	    obj._costAct = obj._defdata.costAct
        obj:egSetLabelStr(kLblTitle,obj._defdata.name)
        obj:egSetLabelStr(kLblAtkVal,RiskHelper.getBpOfHeros(obj._defdata.heroList,obj._defdata.equipments))
        obj:showStars()
        obj:loadHero()
		if obj._stageInfo.first then
			local img = obj:egGetWidgetByName(kImgNew)
			img:setVisible(true)
			img:setEnabled(true)
			local scaleto1 = CCScaleTo:create(1,0.9)
			local scaleto2 = CCScaleTo:create(1,1)
			local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
			img:runAction(CCRepeatForever:create(sequence))
		end
		if obj._stageInfo.locked then
			obj:egSetWidgetColor(kBtnClick,kGrayColor)
			obj:egSetWidgetTouchEnabled(kBtnClick,false)
		else
			obj:bindClickListener()
		end
    else
        obj._idx = idx
        obj._stageInfo = nil
        obj._defdata = DefTaskHelper.getTeam(idx)--ð��С����Ϣ
        obj._costAct = obj._defdata.costAct
        obj:egSetLabelStr(kLblTitle,string.format("%s%s",obj._defdata.name,TxtList.exploreTeam))
		obj:egHideWidget(kStarNull1)
		obj:egHideWidget(kStarNull2)
		obj:egHideWidget(kStarNull3)
        local title = obj:egGetWidgetByName(kLblTitle)
        local posx,posy = title:getPosition()
        title:setPosition(ccp(posx-80,posy))
        obj:egSetLabelStr(kLblAtkVal,obj._defdata.bp)
        obj:loadDefPvpHero()
		obj:bindClickListener()
    end
end
function __deftaskitem.loadHero(obj)
    local listview = obj:egGetWidgetByName(kListHero)
    for idx,heroid in ipairs(obj._defdata.team) do
        local herodata =obj._defdata.heroList[heroid]
        heroHead = HeroHead.new(heroid,herodata.lv)
        listview:addChild(heroHead:egNode())
    end
end
function __deftaskitem.loadDefPvpHero(obj)
    local listview = obj:egGetWidgetByName(kListHero)
    for idx,heroid in ipairs(obj._defdata.team) do
        local herodata =obj._defdata.heroList[idx]
        heroHead = HeroHead.new(heroid,herodata.lv)
        listview:addChild(heroHead:egNode())
    end
end
function __deftaskitem.showStars(obj)
    for idx=1,numDef.starsPerStage do
        if idx <= obj._stageInfo.stars then
            obj:egShowWidget(kStar[idx])
        else
            obj:egHideWidget(kStar[idx])
        end
    end
end
function __deftaskitem.bindClickListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_paper_open)
		sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._costAct > account_data.actPt then
			local pos = sender:getTouchEndPos()
			showPopTxt(string.format("%s %d",TxtList.needActPt,obj._costAct),pos.x,pos.y,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		else
			local defpreview = DefPreview.new(obj._idx,obj._stageInfo,function() sender:setTouchEnabled(true) end)
			local scene = CCDirector:sharedDirector():getRunningScene()
			scene:addChild(defpreview:egNode(),UILv.popLayer,UILv.popLayer)
		end
	end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClick,nil,nil,touchEnded,touchCanceled)
end
DefTaskItem={}
function DefTaskItem.new(idx,stageinfo)
    local obj = {}
    CocosWidget.install(obj,JsonList.defTaskItem)
    table_aux.unpackTo(__deftaskitem,obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(idx,stageinfo)
    return obj
end
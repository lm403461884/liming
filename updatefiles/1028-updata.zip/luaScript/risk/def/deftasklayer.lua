--ð�ն�Ϯ��
local kPanelExplore = "Panel_explore"
local kBtnMsg = "btn_msg"--ɢ����Ϣ
local kLblNoTeam = "lbl_no" --û��ð�ն�ʱ��ʾ
local kImgLoading = "img_loading"
local kListPvp = "List_def_task"
local kLblCounter = "lbl_counter_left"
--ǿ��ͻϮ
local kPanelDefTask = "panel_def_task"
local kLblStarNum = "lbl_star_num"
local kListPve = "List_def_pve"
local kLblClear = "lbl_def_clear"
--����
local kImgMark = "img_mark"
local kBtnBack = "btn_back"
local kBtnToDig = "btn_digscene"
local kBtnAdventure = "btn_adventure"
local kBtnDefTask = "btn_def_task"
local kPanelLayer = "panel_def"
local kMaxNum = 4
local kCellH = 131
local __deftasklayer={}

function __deftasklayer.init(obj,isPvp)
   obj._loadDef = false
   obj._loadPvp = false
   obj:egHideWidget(kImgLoading)
   obj:setPvpFocused(isPvp)
   print("isPvp:",isPvp)
   if isPvp then
	   obj:loadAdventure()
   else
	   obj:loadDefTask()
   end
   obj:showWithAction()
end
--�л�����
function __deftasklayer.setPvpFocused(obj,focused)
    local btnAdventure = tolua.cast(obj:egGetWidgetByName(kBtnAdventure),"Button")
    local btnDefTask = tolua.cast(obj:egGetWidgetByName(kBtnDefTask),"Button")
    if focused then
        btnAdventure:setFocused(true)
        btnAdventure:setTouchEnabled(false)
        btnDefTask:setFocused(false)
        btnDefTask:setTouchEnabled(true)
        obj:egShowWidget(kPanelExplore)
        obj:egHideWidget(kPanelDefTask)
        obj:egHideWidget(kListPve)
        obj:egShowWidget(kListPvp)
		obj:egShowWidget(kBtnMsg)
		obj:egSetWidgetEnabled(kBtnMsg,DefTaskHelper.canRefresh())
		obj:egChangeImg(kImgMark,ImageList.comm_hero_atk,UI_TEX_TYPE_PLIST)
    else
        btnAdventure:setFocused(false)
        btnAdventure:setTouchEnabled(true)
        btnDefTask:setFocused(true)
        btnDefTask:setTouchEnabled(false)
        obj:egHideWidget(kPanelExplore)
        obj:egShowWidget(kPanelDefTask)
        obj:egShowWidget(kListPve)
        obj:egHideWidget(kListPvp)
		obj:egHideWidget(kBtnMsg)
		obj:egChangeImg(kImgMark,ImageList.comm_robber_atk,UI_TEX_TYPE_PLIST)
    end
end
function __deftasklayer.loadAdventure(obj)
    local listview = obj:egGetListView(kListPvp)
	local teamList = DefTaskHelper.getAllTeam()

    if teamList and  #teamList > 0 then --�л�������
		obj:egHideWidget(kLblNoTeam)
		for idx,item in ipairs(teamList) do
			local taskitem = DefTaskItem.new(idx)
			listview:insertCustomItem(taskitem:egNode(),0)
		end
		if DefTaskHelper.canRefresh() then
			obj:egSetWidgetTouchEnabled(kBtnMsg,true)
			obj:egSetWidgetEnabled(kBtnMsg,true)
			obj:egHideWidget(kLblCounter)
		else
			obj:egSetWidgetEnabled(kBtnMsg,false)
			obj:activeSeachCounter()
		end
	elseif DefTaskHelper.canRefresh() then --û�л������ݣ������Բ�ѯ
		obj:activeSearchTimer() --�������������Ϣƥ�����

	else --û�л������ݣ�Ҳ�����Բ�ѯ
		obj:egShowWidget(kLblNoTeam)
		obj:activeSeachCounter()
		obj:egSetWidgetEnabled(kBtnMsg,false)
    end
	obj._loadPvp = true
end
function __deftasklayer.activeSearchTimer(obj)
	obj:egSetWidgetEnabled(kBtnMsg,false)
	obj:egHideWidget(kLblCounter)
	obj:egShowWidget(kImgLoading)
	obj:egHideWidget(kLblNoTeam)
	local imgLoading = obj:egGetWidgetByName(kImgLoading)
    local rotateBy = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateBy)
    imgLoading:runAction(repeatforever)
	obj:clearItems()
	AccountHelper:lock(kStateDefExplore)
	DefTaskHelper.refreshRtTime() --����ˢ��ʱ��
	obj:activeSeachCounter()
    SendMsg[9313005](DefTaskHelper.getSearchBp())
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if not AccountHelper:isLocked(kStateDefExplore) then
			obj:egUnbindWidgetUpdate(kBtnMsg)
            obj:egHideWidget(kImgLoading)
			imgLoading:stopAllActions()
			local listview = obj:egGetListView(kListPvp)
			local teamList = DefTaskHelper.getAllTeam()
			obj:egHideWidget(kLblNoTeam)
			for idx,item in ipairs(teamList) do
				local taskitem = DefTaskItem.new(idx)
				listview:insertCustomItem(taskitem:egNode(),0)
			end
			DefTaskHelper.setMinBp(teamList[#teamList].bp)
		elseif passed >= numDef.clientTimeOut then
			--���ڿ���Ҫ������������
			DefTaskHelper.removeAllTeam()
			DefTaskHelper.setMinBp(0)
			obj:egUnbindWidgetUpdate(kBtnMsg)
			obj:egHideWidget(kImgLoading)
			imgLoading:stopAllActions()
			obj:egShowWidget(kLblNoTeam)
        end
	end
	obj:egBindWidgetUpdate(kBtnMsg,callback)
end
function __deftasklayer.activeSeachCounter(obj)
	local function callback()
		local left = DefTaskHelper.getLeftTime()
		if left == 0 then
			obj:egUnbindWidgetUpdate(kLblCounter)
			obj:egHideWidget(kLblCounter)
			obj:egSetWidgetTouchEnabled(kBtnMsg,true)
			obj:egSetWidgetEnabled(kBtnMsg,true)
		else
			obj:egSetBMLabelStr(kLblCounter,Funs.formatTime(left))
		end
	end
	obj:egShowWidget(kLblCounter)
	obj:egBindWidgetUpdate(kLblCounter,callback)
end

function __deftasklayer.initValidStageList(obj)
	obj._stageIdList = {}
	local maxStageId = 0
	for stageid,stagedata in pairs(account_data.pveGuardQuest) do --����δͨ�صĹؿ�ID
		maxStageId = math.max(maxStageId,stageid)
		table.insert(obj._stageIdList,stageid)
	end
	if #obj._stageIdList==0 then return end
	local stageList = pveGuardQuery.getAllStageID()
	for key,stageid in ipairs(stageList) do
		if stageid > maxStageId then
			table.insert(obj._stageIdList,stageid)
		end
	end
	local function compareStar(stageA,stageB)
		local starA = 4
		local starB = 4
		if account_data.pveGuardQuest[stageA] then starA = account_data.pveGuardQuest[stageA].stars end
		if account_data.pveGuardQuest[stageB] then starB = account_data.pveGuardQuest[stageB].stars end
		return starA < starB or (starA==starB and stageA<stageB)
	end
    table.sort(obj._stageIdList,compareStar)
end
function __deftasklayer.loadDefTask(obj)
	obj:initValidStageList()
	obj:egSetLabelStr(obj:egSetLabelStr(kLblStarNum,account_data.pveGuardStars or 0))
	if #obj._stageIdList <=0 then
		obj:egShowWidget(kLblClear)
		print("--------------------------------out")
		return
	end
	print("--------------------------------in")
	obj._loadedCnt = 0

	local scrollview = obj:egGetScrollView(kListPve)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadedCnt >= #obj._stageIdList then return end
            local innerContainer = scrollview:getInnerContainer()
            local posY = innerContainer:getPositionY()
            if obj._loadedCnt * kCellH  - posY  < innerContainer:getSize().height then
                obj:addDefTaskItem(scrollview,1)
            end
        end
    end
	obj:addDefTaskItem(scrollview,kMaxNum)
	scrollview:addEventListenerScrollView(scrollEvent)
	obj._loadDef=true
	local cnt = #obj._stageIdList
	if cnt > kMaxNum then
		scrollview:setInnerContainerSize(CCSizeMake(scrollview:getSize().width,cnt * kCellH))
	end
end
function __deftasklayer.addDefTaskItem(obj,scrollview,num)
	if obj._loadedCnt >= #obj._stageIdList then return end
	local startIdx = obj._loadedCnt + 1
	local endIdx = math.min(obj._loadedCnt + num,#obj._stageIdList)
	for idx = startIdx,endIdx do
		local stageid = obj._stageIdList[idx]
		local stageInfo = account_data.pveGuardQuest[stageid]
		if not stageInfo then stageInfo={stars = 0,locked=1} end
		local taskitem = DefTaskItem.new(stageid,stageInfo)
        scrollview:addChild(taskitem:egNode())
		obj._loadedCnt = idx
	end
end
function __deftasklayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
function __deftasklayer.hideWithAction(obj)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __deftasklayer.clearItems(obj)
    local listview = obj:egGetListView(kListPvp)
    for idx = 1,listview:getChildrenCount() do
       local item = listview:getItem(idx-1)
        listview:removeChildByTag(item:getTag(),true)
    end
	listview:removeAllItems()
	listview:jumpToTop()
end
function __deftasklayer.bindAdventureListener(obj)
    local function touchEnded(sender)
		obj:setPvpFocused(true)
		if not obj._loadPvp then
			obj:loadAdventure()
		end
    end
    obj:egBindTouch(kBtnAdventure,nil,nil,touchEnded,nil)
end
function __deftasklayer.bindDefTaskListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:setPvpFocused(false)
        if not obj._loadDef then
            obj:loadDefTask()
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnDefTask,nil,nil,touchEnded,touchCanceled)
end
function __deftasklayer.bindMsgListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
        --������Ϣ
        obj:activeSearchTimer()
    end
    obj:egBindTouch(kBtnMsg,nil,nil,touchEnded,nil)
end
function __deftasklayer.bindDigListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        local scene = DigScene.new(obj._idx)
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnToDig,nil,nil,touchEnded,touchCanceled)
end
function __deftasklayer.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
DefTaskLayer={}
function DefTaskLayer.new(isPvp,onloaded)
    local obj =  TouchWidget.new(JsonList.defTaskLayer)
    table_aux.unpackTo(__deftasklayer, obj)
    obj._onloaded  = onloaded
    obj:init(isPvp)
    obj:bindBackListener()
    obj:bindMsgListener()
    obj:bindDigListener()
    obj:bindAdventureListener()
    obj:bindDefTaskListener()
    AccountHelper:lock(kStatePrompt)
	--��������

	if account_data.def_guide ~= nil then
		showDialog(301)
	end
    return obj
end

function showDef(isPvp,onloaded)
    local layer = DefTaskLayer.new(isPvp,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

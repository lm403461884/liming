
local kPanelHero = "panel_hero"

local kBtnOk = "btn_ok"
local kPanelLayer = "panel_result"
--����ģ��
local kPanleBox = "panel_showBox"
local kAwardList = "award_list"
local kBoxList = "panel_box"

local kBtnNext = "btn_next"
local kImgClicked = "img_clicked"
local kLblTime = "lbl_time"

local kBoxW = 240
local kHeroW = 140
local kMaxNum = 5

local __exploreresult = {}

function __exploreresult.init(obj,d_data)
    obj._d_data = d_data 
    obj:loadHero()
    if obj._d_data.battleBox then
        obj._inPanelBox = true --����ڱ������
        obj._unOpenBox = {}
	    obj._openBox = {}
	    obj._awardList = {}
	    
	    obj._awardItems = {}
	    obj._boxTypeList = {}
        obj:showBoxPanel(true)
    else
        obj:showBoxPanel(false)
    end
    obj:egHideWidget(kPanleBox)
    local function callback() 
        if obj._inPanelBox then
            obj:egShowWidget(kPanleBox) 
        end    
    end
    --obj:showWithAction(callback)
end
function __exploreresult.loadHero(obj)
    
    local panelhero = obj:egGetWidgetByName(kPanelHero)
    for idx,heroid in ipairs(obj._d_data.team) do
        local herodata = obj._d_data.heroList[heroid]
        local heroitem = ExploreLvUpHero.new(heroid,herodata)
        panelhero:addChild(heroitem:egNode())
        
        account_data.gold = account_data.gold + herodata.gold
        local hero = {heroid}
        local gainexp = {herodata.fexp}
        RiskHelper.updateHeroExp(gainexp,5,hero)
        
        if herodata.awardRes then
            if not obj._d_data.battleBox then 
                obj._d_data.battleBox = {{},{},{}}
                obj._d_data.battleBoxCnt = 0
            end    
            table.insert(obj._d_data.battleBox[herodata.boxid],herodata.awardRes)
            obj._d_data.battleBoxCnt = obj._d_data.battleBoxCnt + 1
        end
    end
    
    local panelSize = panelhero:getSize()
    local posx,posy = panelhero:getPosition()
    local heroW = #obj._d_data.team * kHeroW
    local newX = posx + (panelSize.width - heroW)/2
    panelhero:setPosition(ccp(newX,posy))
end

function __exploreresult.showBoxPanel(obj,show)
	if show then
	    obj._boxTimeCount = 0 --��������ҳ��
		obj:egShowWidget(kPanleBox)
		obj:egShowWidget(kBoxList)
		obj:egShowWidget(kImgClicked)
		obj:egHideWidget(kBtnNext)
		obj:egHideWidget(kBtnOk)
		--local imgblack = obj:egGetWidgetByName(kImgBlack)
		--imgblack:setOpacity(0)
		--imgblack:runAction(CCFadeTo:create(0.2,128))
		obj:loadBattleBox()
		obj:bindBoxListener()
		--obj:bindNextListener()
		obj:openBoxTimeUpdate()
	else
		obj:egHideWidget(kPanleBox)
		obj:egHideWidget(kBoxList)
		obj:egHideWidget(kBtnNext)
		obj:egHideWidget(kImgClicked)
		obj:egHideWidget(kLblTime)
	end
end
--�����䵹��ʱ
function __exploreresult.openBoxTimeUpdate(obj)
    obj:egShowWidget(kLblTime)
    obj._boxTimeCount = obj._boxTimeCount + 1 
    local count = 0
    local time = 10
    local function callback(delte)
        count = count + delte
        if count > 1 then
            count = 0
            time = time - 1
            obj:egSetLabelStr(kLblTime,time)
        end
        if time == -1 then
            obj:egUnbindWidgetUpdate(kLblTime)
            obj:openAllBoxs()
        elseif time==0 then
            obj:egSetWidgetTouchEnabled(kBoxList,false) 
            for cnt,item in pairs(obj._unOpenBox) do
                item:setEnabled(false)
            end
        end
        if (obj._openCnt%kMaxNum== 0 and obj._boxTimeCount == obj._openCnt/kMaxNum) or obj._openCnt == obj._d_data.battleBoxCnt then
            obj:egHideWidget(kLblTime)
            obj:egUnbindWidgetUpdate(kLblTime)
        end
    end
    obj:egBindWidgetUpdate(kLblTime,callback)
end
--�Զ��򿪵�ǰҳʣ�౦��
function __exploreresult.openAllBoxs(obj)
    obj:egHideWidget(kImgClicked)
    --local boxCounts = #obj._unOpenBox + obj._openCnt
    if obj._d_data.battleBoxCnt~= obj._openCnt and obj._openCnt < kMaxNum * obj._boxTimeCount then
        for idx=1,kMaxNum* obj._boxTimeCount,1 do
            if idx <= obj._d_data.battleBoxCnt and not obj._openBox[idx] then
                obj._openBox[idx] = obj._unOpenBox[idx]
			    obj._unOpenBox[idx]:setScale(1)
                obj:openBoxById(idx)
            end    
        end
    end
end
--����ս���õ�������
function __exploreresult.loadBattleBox(obj)
	local cnt = 0
	obj._openCnt = 0
	local boxlist = obj:egGetWidgetByName(kBoxList)
	local awardpanel = obj:egGetWidgetByName(kAwardList)
	for mtype,awardList in ipairs(obj._d_data.battleBox) do
		for key,awardInfo in ipairs(awardList) do
			local boxWidget = ImageView:create()
			boxWidget:loadTexture(ImageList[string.format("comm_box_%s",KVariantList.boxType[mtype])],UI_TEX_TYPE_PLIST)
			boxlist:addChild(boxWidget,1,cnt)
			boxWidget:setPosition(ccp((cnt + 0.5) * kBoxW,kBoxW/2))
			cnt = cnt + 1
			obj._awardList[cnt] = awardInfo
			obj._unOpenBox[cnt] = boxWidget
			obj._boxTypeList[cnt] = mtype
		end
	end
	if cnt < kMaxNum then
	    local neww = cnt * kBoxW
	    local oldw = boxlist:getSize().width
	    boxlist:setPosition(ccp(boxlist:getPositionX() + (oldw-neww)/2,boxlist:getPositionY()))
		awardpanel:setPosition(ccp(awardpanel:getPositionX() + (oldw-neww)/2,awardpanel:getPositionY()))
	end
end
--��ȡ���������ID
function __exploreresult.getTouchedBoxID(obj,pos)
	 for boxid,box in pairs(obj._unOpenBox) do
		if not obj._openBox[boxid] then
			local sprite = tolua.cast(box:getVirtualRenderer(),"CCSprite")
			local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
			if not isalpha then
				return boxid
			end
		end
	end
	return 0
end

--������ʾ������Ϣ
function __exploreresult.scaleAndShow(obj,awardItem,x,callbackfunc)
	local panel = obj:egGetWidgetByName(kAwardList)
	local panelH = panel:getSize().height
	local panelW = panel:getSize().width
	local widget = awardItem:egNode()
	local widgetW = widget:getSize().width
	local widgetH = widget:getSize().height
	widget:setPosition(ccp(x - widgetW/2,(panelH - widgetH)/2)) --���������ʾλ��
	awardItem:scaleAndShowWithSrc(x - widgetW/2,0,callbackfunc)
	panel:addChild(widget,1,panel:getChildrenCount() + 1)	
	table.insert(obj._awardItems,awardItem)
end

--�����ӵĶ���
function __exploreresult.showBoxOpenActions(obj,boxId)
	local mtype =  obj._boxTypeList[boxId]
	local boxWidget = obj._unOpenBox[boxId]
	local box_X = boxWidget:getPositionX()
	
	local actionName = KVariantList.boxAction[mtype]
    local anima = graphicLoader.getAnimation(actionName)
    if not anima then print("can not find ",actionName) end
    anima:setRestoreOriginalFrame(true)
    local animate = CCAnimate:create(anima)

    local function callback()
		boxWidget:loadTexture(ImageList[string.format("comm_box_%s_open",KVariantList.boxType[mtype])],UI_TEX_TYPE_PLIST)
		local awardinfo = obj._awardList[boxId]
		local function callbackfunc()
			if obj._openCnt == obj._d_data.battleBoxCnt then
				obj:egShowWidget(kBtnOk)
			elseif obj._openCnt%kMaxNum == 0 then
				obj:egShowWidget(kBtnNext)
			end
		end
		local awardtype = awardinfo[1]
		local subtype = awardinfo[2]
		local awardval = awardinfo[3]
		if awardtype == 1 then --��Դ����
			local cointype =  KVariantList.coinType[subtype]
			SoundHelper.playEffect(SoundList.buy_message_01)
			local resaward = ResAward.new(cointype,Funs.signedNum(awardval))
			account_data[cointype] = account_data[cointype] + awardval
			obj:scaleAndShow(resaward,box_X,callbackfunc)
		elseif awardtype == 2 then --Ӣ����Ϣ����
			local heromsg = HeroMsgAward.new(subtype,awardval)
			--��õ�Ӣ����Ϣ����������ļ�ͽ�������Ӱ��
			account_data.heroInfoList[subtype] = (account_data.heroInfoList[subtype] or 0) + awardval
			obj:scaleAndShow(heromsg,box_X,callbackfunc)
		elseif awardtype == 3 then --װ��
			local equipid = equipFuncs.getSubEquipId(subtype,awardval,equipFuncs.getSubEquipCfg(subtype,"quality"))
			account_data.equipSub[equipid] = (account_data.equipSub[equipid] or 0) + 1
			local equipaward = EquipAward.new(equipid)
			obj:scaleAndShow(equipaward,box_X,callbackfunc)
		end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(animate,callfunc)    
    
    local sprite = tolua.cast(boxWidget:getVirtualRenderer(),"CCSprite") 
    sprite:runAction(sequence)
end
--������
function __exploreresult.openBoxById(obj,boxId)
    obj._openCnt = obj._openCnt +1 --�Ѿ��򿪵�������
	SoundHelper.playEffect(SoundList.open_treasurebox)
	local boxWidget = obj._unOpenBox[boxId]
	local boxPanel = obj:egGetWidgetByName(kBoxList)
	local moveby1 = CCMoveBy:create(0.1,ccp(5,3))
    local moveby2 = CCMoveBy:create(0.1,ccp(-5,-3))
    local moveby3 = CCMoveBy:create(0.1,ccp(5,0))
    local moveby4 = CCMoveBy:create(0.1,ccp(-5,0))
	local function callback()
		obj:showBoxOpenActions(boxId)
	end
    local callfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(moveby1)
    array:addObject(moveby2)
    array:addObject(moveby3)
    array:addObject(moveby4)
    array:addObject(callfunc)
    local sequence = CCSequence:create(array)
    boxWidget:runAction(sequence)
end
function __exploreresult.bindBoxListener(obj)
	 local function touchBegan(sender)
	    obj:egHideWidget(kImgClicked)
		local pos =sender:getTouchStartPos()
		obj._touchBoxId = obj:getTouchedBoxID(pos)
		if obj._touchBoxId > 0 then
		    obj._unOpenBox[obj._touchBoxId]:setScale(1.1)
			--SoundHelper.playEffect(SoundList.click_shop_goods)
		end
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._touchBoxId > 0 then
			obj._openBox[obj._touchBoxId] = obj._unOpenBox[obj._touchBoxId]
			obj._unOpenBox[obj._touchBoxId]:setScale(1)
            obj:openBoxById(obj._touchBoxId)
			obj._touchBoxId = 0
		end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			if obj._touchBoxId > 0 then
				obj._unOpenBox[obj._touchBoxId]:setScale(1)
			end
			obj._touchBoxId = 0
		end
    end
    obj:egBindTouch(kBoxList,touchBegan,nil,touchEnded,touchCanceled)
end

function __exploreresult.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    local function callback() 
        if obj._inPanelBox then
            obj:egShowWidget(kPanleBox) 
        end    
    end
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequence)
    else
        baseWidget:runAction(spawn)
    end
end
--����
function __exploreresult.bindNextListener(obj)
	local function  touchEnded(sender)
	    obj:egSetLabelStr(kLblTime,10)
	    obj:openBoxTimeUpdate()
		obj:egHideWidget(kBtnNext)
		 obj:egSetWidgetTouchEnabled(kBoxList,true) 
		local leftCnt = obj._d_data.battleBoxCnt - obj._openCnt
		local offsetX = kMaxNum*kBoxW
		if leftCnt < kMaxNum then
			offsetX = leftCnt*kBoxW
		end
		for key,boxitem in pairs(obj._unOpenBox) do
			local oldx = boxitem:getPositionX()
			local oldy = boxitem:getPositionY()
			boxitem:setPosition(ccp(oldx - offsetX,oldy))
		end
		for key,awarditem in pairs(obj._awardItems) do
			local oldx = awarditem:egGetPosX()
			local oldy = awarditem:egGetPosY()
			awarditem:egSetPosition(oldx - offsetX,oldy)
		end
	end
	 obj:egBindTouch(kBtnNext,nil,nil,touchEnded,nil)
end
--ȷ��
function __exploreresult.bindOkListener(obj)
    local function touchEnded(sender)
         if obj._inPanelBox then
             obj._inPanelBox = false
             obj:egHideWidget(kPanleBox)
         else
             obj:egSetWidgetTouchEnabled(kBtnOk,false)
		     SoundHelper.playEffect(SoundList.click_paper_close)
		     obj:egRemoveSelf()
		     AccountHelper:unlock(kStatePrompt)
		end     
    end
     obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end

ExploreResult={}
function ExploreResult.new(d_data)
    local obj = TouchWidget.new(JsonList.exploreResult)
    table_aux.unpackTo(__exploreresult, obj)
    obj:init(d_data)
    obj:bindOkListener()
    return obj
end
function showExploreResultLayer(d_data)
    local layer = ExploreResult.new(d_data)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end

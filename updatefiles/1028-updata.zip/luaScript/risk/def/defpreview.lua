local kLblTitle = "mission_name_lbl"
local kImgStar={"img_star1","img_star2","img_star3"}
local kImgStarNull1 = "img_star_null1"
local kImgStarNull2 = "img_star_null2"
local kImgStarNull3 = "img_star_null3"
local kImgArea = "img_area"
local kBtnStart = "btn_start"
local kBtnBack = "btn_back" 

local kPanelMonster = "monster_list"
local kPanelHero = "hero_list"

local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"
local kPanelAward3 = "award_panel3"
local kPanelAward = "award_panels"
local kImgAwardBg = "img_award_bg"
local kImgAward = "img_award"
local kImgAwardQa = "img_equip_qa"
local kImgAwardBg2 = "img_award_bg2"
local kImgAward2 = "img_award2"
local kImgAwardQa2 = "img_equip_qa2"
local kImgEquipNote = "img_lbl_bgs"

local kLblCost = "lbl_cost"
local kLblTeamCap = "lbl_team_caps"

local kPanelLayer = "img_def_mission_bg"
local kMaxMonster = 5
local kCellW = 110
local kCellW1 = 150
local kMaxLoadNum = 2
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)

local __defpreview={}
function __defpreview.init(obj,idx,stageinfo)
	obj._idx = idx
    if stageinfo then --PVE��������
        obj._stageInfo = stageinfo
        obj._defdata = pveGuardQuery.getName(obj._idx)
        obj:showStars()
		obj:egSetLabelStr(kLblTitle,obj._defdata.name)
		obj._defdata.bp = RiskHelper.getBpOfHeros(obj._defdata.heroList,obj._defdata.equipments)
    else --PVP����
        obj._defdata = DefTaskHelper.getTeam(obj._idx)
		obj:egSetLabelStr(kLblTitle,string.format("%s%s",obj._defdata.name,TxtList.exploreTeam))
		obj:egHideWidget(kImgStarNull1)
		obj:egHideWidget(kImgStarNull2)
		obj:egHideWidget(kImgStarNull3)
    end   
	local pic = scene_data[account_data.sceneID].thumbPic
	obj:egChangeImg(kImgArea,pic,UI_TEX_TYPE_PLIST)	
    obj:egSetBMLabelStr(kLblCost,obj._defdata.costAct)
    obj:egHideWidget(kBtnBack)
    obj:egSetWidgetTouchEnabled(kBtnStart,false)
    if account_data.actPt < obj._defdata.costAct then
        obj:egSetWidgetColor(kLblCost,kRedColor)
        obj:egSetWidgetEnabled(kBtnStart,false)
    end
	obj:egSetWidgetColor(kLblTeamCap,kBrownColor)
	obj:egSetLabelStr(kLblTeamCap,obj._defdata.bp)
    obj:loadHeros()
	obj:loadMonsters()
    obj:loadAward()
	obj:loadProbableAward()
    obj:showWidthAction()
end
function __defpreview.getMonsters(obj)
    local tb = {}
    for pos,monsterid in pairs(account_data.creatureList) do
        if not tb[monsterid] then tb[monsterid] = 1 
        else tb[monsterid] = tb[monsterid] + 1 end
    end
    return tb
end
function __defpreview.loadMonsters(obj)
    local monsters = obj:getMonsters()
    local panel =obj:egGetWidgetByName(kPanelMonster)
    local cnt = 0
    for monsterid,num in pairs(monsters) do
		cnt = cnt + 1
        local monsterHead = MonsterHead.new(monsterid,num,account_data)
        panel:addChild(monsterHead:egNode())
		if cnt >= kMaxMonster then break end
    end
    local size = panel:getSize()
    local neww = cnt*kCellW
	panel:setPosition(ccp((size.width - neww)/2 + panel:getPositionX(),panel:getPositionY()))
    panel:setSize(CCSizeMake(neww,size.height))
end
function __defpreview.loadHeros(obj)
    local panel  = obj:egGetWidgetByName(kPanelHero)
	for idx,heroid in ipairs(obj._defdata.team) do
		local herodata = nil
		if obj._stageInfo then --PVE
            herodata =obj._defdata.heroList[heroid]
        else--PVP
			herodata = obj._defdata.heroList[idx]
        end
		local heroHead = ExpeditionItem.new(heroid,nil,herodata.lv)
		heroHead:setItemTouchEnabled(false)
		panel:addChild(heroHead:egNode())
	end
	local neww = #obj._defdata.team * kCellW1
	local size = panel:getSize()
	if size.width > neww then
		panel:setPosition(ccp((size.width - neww )/2*panel:getScale() + panel:getPositionX(),panel:getPositionY()))
		panel:setSize(CCSizeMake(neww,size.height))
	end
end

function __defpreview.loadAward(obj)
    local awardList = obj:getAwardList()
    if not awardList then return end
    local maxCount = #awardList
    local margin = 149 --��item��ľ���
    local panel1 = obj:egGetWidgetByName(kPanelAward1)
    local size1 = panel1:getSize()
    local panel2 = obj:egGetWidgetByName(kPanelAward2)
    local size2 = panel2:getSize()
    local count = 0
    for idx,award in ipairs (awardList) do
        local awarditem = AwardItem.new(award[1],string.format("%s%d",TxtList.numSymbol,award[2]))
        count = count  + 1 
        if count <= kMaxLoadNum then 
            panel1:addChild(awarditem:egNode())
            local posX,posY = awarditem:egNode():getPosition()
            awarditem:egNode():setPosition(ccp(posX + margin*(count-1),posY))
        elseif count<= kMaxLoadNum*2 then
            panel2:addChild(awarditem:egNode())
            local posX,posY = awarditem:egNode():getPosition()
            awarditem:egNode():setPosition(ccp(posX + margin*(count-4),posY))
        end           
    end
    if count <= kMaxLoadNum then  --����������ʾ
        local posX,posY = panel1:getPosition()
        panel1:setPosition(ccp(posX+size1.width/2-margin/2*count,posY))
    else
        local posX,posY = panel2:getPosition()
        panel2:setPosition(ccp(posX+size2.width/2-margin/2*(count-3),posY))
    end
end
--��ȡ������Ϣ
function __defpreview.getAwardList(obj)
    if not obj._stageInfo then
		local awardList = {}
       awardList.gold,awardList.iron,awardList.copper,awardList.stoneR,awardList.stoneB,awardList.stoneD = uniteTeamCalc.UTDefprize(account_data,obj._defdata.bp,numDef.starsPerStage)
		return awardList
    else
		return pveGuardQuest.pveGuardprize(account_data,obj._idx,numDef.starsPerStage)
    end
end
--���ص�һ�δ��������Ľ�����Ϣ
function __defpreview.loadAward(obj)
	local awardList = obj:getAwardList()
	obj._award1w = 0
	obj._award2w = 0
	obj._award3w = 0
	local loadCnt = 0
    for key,coinname in pairs(KVariantList.coinType) do
		if awardList[coinname] and awardList[coinname]  > 0 then
			loadCnt = loadCnt+1
			local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,awardList[coinname]))
			obj:addItemToAwardPanel(awarditem,loadCnt)
		end
	end
	if loadCnt <= kMaxLoadNum then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panel1:getSize().height
		panel2:setVisible(false)
		panel3:setVisible(false)
	elseif loadCnt <= kMaxLoadNum*2 then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panelsize.height - panel3:getSize().height
		panel3:setVisible(false)
	end
end
--���ؿ��ܵ���Ľ���
function __defpreview.loadProbableAward(obj)
    obj:egHideWidget(kImgAwardBg)
    obj:egHideWidget(kImgAward)
	obj:egHideWidget(kImgAwardQa)
    obj:egHideWidget(kImgAwardBg2)
    obj:egHideWidget(kImgAward2)
	obj:egHideWidget(kImgAwardQa2)
	obj:egHideWidget(kImgEquipNote)
    if obj._stageInfo and  obj._defdata.subequip then
		obj:egShowWidget(kImgEquipNote)
         local cnt = 0
         for key,item in ipairs(obj._defdata.subequip) do
             cnt = cnt + 1
			 local s_cfg = equipFuncs.getSubEquipCfg(item[1])
             if cnt == 1 then
                 obj:egShowWidget(kImgAwardBg)
                 obj:egShowWidget(kImgAward)
				 obj:egShowWidget(kImgAwardQa)
                 obj:egChangeImg(kImgAward,s_cfg.icon,UI_TEX_TYPE_PLIST)
				 obj:egSetWidgetColor(kImgAwardQa,KVariantList.equipColor[s_cfg.quality])
             elseif cnt==2 then
                 obj:egShowWidget(kImgAwardBg2)
                 obj:egShowWidget(kImgAward2)
				 obj:egShowWidget(kImgAwardQa2)
                 obj:egChangeImg(kImgAward2,s_cfg.icon,UI_TEX_TYPE_PLIST)
				 obj:egSetWidgetColor(kImgAwardQa2,KVariantList.equipColor[s_cfg.quality])
             end
         end  
    end   
end
function __defpreview.addItemToAwardPanel(obj,item,loadCnt)
    local margin = 0
	local awardsize = item:egNode():getSize()
	item:egNode():setSize(CCSizeMake(awardsize.width + margin,awardsize.height))
	if loadCnt <= kMaxLoadNum then
	    local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local size = panel1:getSize()
		panel1:addChild(item:egNode())
		obj._award1w = obj._award1w + awardsize.width
		if obj._award1w > size.width then
		    panel1:setScale(size.width/obj._award1w)
		end
	elseif loadCnt <= kMaxLoadNum*2 then
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local size = panel2:getSize()
		panel2:addChild(item:egNode())
		obj._award2w = obj._award2w + awardsize.width
		if obj._award2w > size.width then
		    panel2:setScale(size.width/obj._award2w)
		end
	else
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
	    local size = panel3:getSize()
		panel3:addChild(item:egNode())
		obj._award3w = obj._award3w + awardsize.width
		if obj._award3w > size.width then
		    panel3:setScale(size.width/obj._award3w)
		end
	end
end
function __defpreview.showStars(obj)
    for idx=1,numDef.starsPerStage do
        if idx <= obj._stageInfo.stars then
            obj:egShowWidget(kImgStar[idx])
        else
            obj:egHideWidget(kImgStar[idx])
        end
    end
end
function __defpreview.showWidthAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(baseWidget:getPositionX(),1085))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(baseWidget:getPositionX(),365))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    local function callback()
        if obj._onloaded then obj._onloaded()end
        obj:bindCloseListener()
        obj:egSetWidgetTouchEnabled(kBtnStart,true)
        obj:egShowWidget(kBtnBack)
    end
    local callfunc = CCCallFunc:create(callback)
	local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
	baseWidget:runAction(sequece)
end
function __defpreview.onClicked(obj,callback)
    obj._callback = callback
end
--�ر�ҳ��
function __defpreview.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,nil)
end
function __defpreview.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

--��ʼ��ť
function __defpreview.bindStartListener(obj)
    local function touchEnded(sender)
       
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
		AccountHelper:useActPt(obj._defdata.costAct)
        local scene = nil	
		if obj._stageInfo then
			 DefTaskHelper.markPveDef(true)
            scene = DefScene.new(obj._idx)
        else
			 DefTaskHelper.markPvpDef(true)
            scene = DefPvpScene.new(obj._idx)
        end    
        scene:egReplace()
    end  
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end  
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
DefPreview={}
function DefPreview.new(idx,stageinfo,onload)
    local obj =  TouchWidget.new(JsonList.defTaskPre)
    table_aux.unpackTo(__defpreview, obj)
    obj._onloaded = onload
    obj:init(idx,stageinfo)
    obj:bindStartListener()
    obj:bindBackListener()
    return obj
end

local kImgLv = "img_lv"
local kLabelLv = "lbl_lv"
local kImgHero = "img_item"
local kBarExp = "exp_bar"
local kBgExp = "exp_bg"
local kLblGold = "lbl_gold_val"
local kLblExp = "lbl_exp_val"
local kLblWin = "lbl_state"
local kPanelWin = "win_panel"

local __lvuphero = {}
function __lvuphero.init(obj,heroid,gainInfo)
	obj._heroid = heroid
	obj._gainInfo = gainInfo
	obj._herodata = account_data.heroList[heroid]
	obj._oldLv = obj._herodata.lv
    local s_cfg = hero_data.getConfig(obj._heroid)
    obj:egChangeImg(kImgHero,s_cfg.headPic,UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLabelLv,obj._oldLv) --����ʾԭ���ĵȼ�
	obj:egSetLabelStr(kLblGold,Funs.signedNum(obj._gainInfo.gold))
	obj:egSetLabelStr(kLblExp,Funs.signedNum(obj._gainInfo.fexp))
	if obj._gainInfo.wins == 0 then
		obj:egHideWidget(kPanelWin)
	else
		obj:egSetLabelStr(kLblWin,string.format("%s%s%s",obj:egGetLabelStr(kLblWin),TxtList.numSymbol,obj._gainInfo.wins))
	end
    obj:runExpProgress(obj._gainInfo.expChange)
	obj:showLvChangeWithAction()
end

function __lvuphero.runExpProgress(obj,expChange)
	if not expChange or #expChange < 2 then return end
	local idx = 1
	local from = expChange[1]
	local to = expChange[2]
	obj:egSetBarPercent(kBarExp,from)
    local function callbackFunc()
        from = from + 5
        if from >= to then 
            from = to 
			if idx >= #expChange/2 then
				obj:egUnbindWidgetUpdate(kBarExp)
			else
				idx = idx + 1
				from = expChange[idx*2-1]
				to = expChange[idx*2]
			end
        end
        obj:egSetBarPercent(kBarExp,from)
    end
    obj:egBindWidgetUpdate(kBarExp,callbackFunc)
end

function __lvuphero.showLvChangeWithAction(obj)
	if obj._oldLv >= obj._gainInfo.newLv then return end
	--挖掘日志任务更新
	task.updateTaskStatus(account_data,task.client_event_id.hero_levelup,{obj._heroid,obj._gainInfo.newLv})
	----------------------------------------------------------
	SoundHelper.playEffect(SoundList.up_level)
	obj:egSetBMLabelStr(kLabelLv,obj._gainInfo.newLv)
	local widget = obj:egGetWidgetByName(kImgLv)
	widget:setScale(5)
	widget:runAction(CCScaleTo:create(0.5,1))
end

ExploreLvUpHero = {}
function ExploreLvUpHero.new(heroid,gainInfo)
    local obj = {}
    CocosWidget.install(obj,JsonList.exploreHeroLvUp)
    table_aux.unpackTo(__lvuphero, obj)
    obj:init(heroid,gainInfo)
    return obj
end
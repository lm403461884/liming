local _nextRT = nil
local _teamlist = nil
local _markPvpDef = nil
local _markPveDef = nil
local _bpMin = 0
DefTaskHelper={}
function DefTaskHelper.markPvpDef(mark)
	_markPvpDef = mark
end
function DefTaskHelper.markPveDef(mark)
	_markPveDef = mark
end
function DefTaskHelper.isPvpDef()
	return _markPvpDef
end
function DefTaskHelper.isPveDef()
	return _markPveDef
end
--�Ƿ��������ð�ն�
function DefTaskHelper.canRefresh()
	if _nextRT == nil or _nextRT <= os.time() then
		return true
	else
		return false
	end
end
function DefTaskHelper.getLeftTime()
	if _nextRT then
		return math.max(_nextRT-os.time(),0)
	else
		return 0
	end
end
--�����´�ˢ��ʱ��
function DefTaskHelper.refreshRtTime()
	_nextRT = os.time() + numDef.defSearchInterval
end
--��ȡð�նӶ����б�
function DefTaskHelper.getAllTeam()
	return _teamlist
end
--����ð�ն���Ϣ
function DefTaskHelper.addTeam(team)
	if not _teamlist then _teamlist = {} end
	table.insert(_teamlist,team)
end
--ɾ��ð�ն���Ϣ
function DefTaskHelper.removeTeam(idx)
    if _teamlist then
        table.remove(_teamlist,idx)
	end
end
--������л���Ķ�����Ϣ
function DefTaskHelper.removeAllTeam()
	_teamlist=nil
end
--��ȡָ������λ�õ�С����Ϣ
function DefTaskHelper.getTeam(idx)
	if _teamlist then
		return _teamlist[idx]
	end
end
function DefTaskHelper.getSearchBp()
	local minBp,maxBp = uniteTeamCalc.guardUTsearch(account_data) 
	if _bpMin > minBp and  _bpMin < maxBp then
		minBp = _bpMin
	end
	return minBp,maxBp
end
function DefTaskHelper.setMinBp(val)
	_bpMin = val
end


local kImgHero = "img_hero"
local kImgLv = "img_lv"
local kLblLv = "lbl_lv"
local kBtnItem = "btn_heroitem"
local kImgBar = "img_bar"
local kLblCost = "lbl_cost"

local __exploreitem = {}
function __exploreitem.updateHeroInfo(obj,heroid,herolv,animal)
	obj._heroid = heroid
	obj._herolv = herolv
	obj:addprop("heroid",obj._heroid)
	obj:egHideWidget(kLblCost)
	--if heroid>0 and animal then 
   --      graphicLoader.loadHeroAnima(obj._heroid,obj._herolv,false)
   -- elseif heroid>0 then
    --     graphicLoader.loadHeroFrame(heroid,herolv) 
   -- end
	local imgWidget = obj:egGetWidgetByName(kImgHero)
	--local posx,posy = imgWidget:getPosition()
	imgWidget:setPosition(ccp(-5,5))
	if  obj._heroid > 0 then 
		obj:egShowWidget(kImgHero)
		obj:egShowWidget(kImgLv)
		obj:egShowWidget(kLblLv)
		obj:egHideWidget(kImgBar)
		obj:egSetBMLabelStr(kLblLv,herolv)
		local s_cfg = hero_data.getConfig(heroid)
		local s_data = hero_data.get(obj._heroid,herolv)
		local photo = string.format('%s_010201.png',s_cfg.graphList[s_data.graphLV])
		if not obj._oldHeroid or obj._oldHeroid ~= obj._heroid then
		    graphicLoader.loadHeroAnima(obj._heroid,obj._herolv,false)
		    obj:egChangeImg(kImgHero,photo,UI_TEX_TYPE_PLIST)
		end    
		obj:scaleAndShow(kImgLv,1.2,0.5)
		obj:scaleAndShow(kImgHero,1.2,0.5)
		obj._oldHeroid = obj._heroid
	else
		obj:showEmptyBox()
	end
	if animal then obj:walkAction() end
end
function __exploreitem.showEmptyBox(obj)
	--obj:egHideWidget(kLblLv)
	obj:egHideWidget(kImgLv)
	obj:egHideWidget(kImgHero)
	local widget = obj:egGetWidgetByName(kImgHero)
    local sprite = tolua.cast(widget:getVirtualRenderer(),"CCSprite") 
    sprite:stopAllActions()
end
--���ø���
function __exploreitem.setItemlight(obj)
    local btnWidget = obj:egGetWidgetByName(kBtnItem)
    local btn = tolua.cast(btnWidget,"Button")
    btn:setFocused(true)
    --obj:egShowWidget(kImgBar)
end
function __exploreitem.scaleAndShow(obj,widgetName,scale,s)
    local widget = obj:egGetWidgetByName(widgetName)
    widget:setScale(0)
    local scaleto = CCScaleTo:create(s,scale)
    local backout = CCEaseBackOut:create(scaleto)
    widget:runAction(backout)
end
function __exploreitem.setItemTouchEnabled(obj,enabled)
    obj:egSetWidgetTouchEnabled(kBtnItem,enabled)
end
function __exploreitem.onItemClicked(obj,onclicked)
    obj._itemCallback = onclicked
end
function __exploreitem.walkAction(obj)
    
    local heroCfg =assert(hero_data.getConfig(obj._heroid))
    local heroDataAtLv =assert(hero_data.get(obj._heroid,obj._herolv))
    local graphName = heroCfg.graphList[heroDataAtLv.graphLV]
    local startFrame = string.format('%s_010201.png',heroCfg.graphList[heroDataAtLv.graphLV])
    
    local dir = 270
    local animaName = string.format('%s_02%02d',graphName,dir/90)
	local anima = graphicLoader.getAnimation(animaName)
	if not anima then print('engine: can not find anima ' .. animaName) return end
	anima:setRestoreOriginalFrame(true)
	local animate = CCAnimate:create(anima)
	local action = CCRepeat:create(animate,1000000)
	
	local hero = obj:egGetWidgetByName(kImgHero)
	local sprite = tolua.cast(hero:getVirtualRenderer(),"CCSprite") 
	sprite:runAction(action)
end
function __exploreitem.bindItemListener(obj)
    local function touchBegan(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_rescar_dig)
        local imgbar = obj:egGetWidgetByName(kImgBar)
        imgbar:setScale(1)
        imgbar:setOpacity(255)
        obj:egShowWidget(kImgBar)
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        local imgbar = obj:egGetWidgetByName(kImgBar)
        local scaleto = CCScaleTo:create(0.2,1.1)
        local fadeout = CCFadeOut:create(0.2)
        local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
        local function callback()
            sender:setTouchEnabled(true)
            if obj._itemCallback then obj._itemCallback(obj) end
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
        imgbar:runAction(sequence)
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			obj:egHideWidget(kImgBar)
		end
    end
	
    obj:egBindTouch(kBtnItem,touchBegan,nil,touchEnded,touchCanceled)
end
ExploreItem = {}
function ExploreItem.new(heroid,herolv,animal)
    local obj = {}
    CocosWidget.install(obj,JsonList.teamRightNow)
    table_aux.unpackTo(__exploreitem, obj)
    BaseProp.install(obj)
	InnerProp.install(obj)
    obj:updateHeroInfo(heroid,herolv,animal)
    obj:bindItemListener()
    return obj
end

local kLblInvite = "lbl_invite"
local kLblName = "lbl_name"
local kImgTextBg = "img_text_bg"
local kTextField = "textfield"
local kLblTextInfo = "lbl_show_info"
local kPanelChatBg = "lblbg_panel"
local kLblInviteInfo = "lbl_invite_info"
local kLblConTxt = "lbl_consume"
local kLblAtkVal = "lbl_atk_val"
local kLblConsume = "lbl_con_val"
local kLblTime = "lbl_time"
local kLblTimeVal = "lbl_time_val"
local kImgArea = "img_area"
--local kScrollExTeam = "scroll_exteam"
local kPanelShowTeam = "panel_show_exteam"
local kBtnBack = "btn_back"
local kImgInfoBg = "img_info_bg"
local kPanelPrompt = "panel_prompt"
local kImgLoading = "img_loading"
local kPanelShow = "panel_show"
local kImgCornor = "cornor1"

--local kImgHeroBgs = "img_hero_bgs"
local kPanelHero = "panel_hero"
local kScrollHero = "scroll_hero"
local kPanelLayer = "panel_exteam"
local kImgArrow = "img_arrow_buttom"

local kPanelOk = "panel_ok"
local kImgPromptBg = "img_prompt_bg"
local kLblLvUpTime = "lbl_lvup_time"
local kBtnOk = "btn_ok"
local kBtnCancel = "btn_cancel"
local kPanelSelectHero = "panel_select_hero"

local kLblLong = 520 --�����ı�����
local kMaxTeam = 5 
local kMinRowCnt = 2
local kCellW =200
local kCellH = 160
local kColorGray = ccc3(128,128,128)
local kColorWhite = ccc3(255,255,255)
local __exploreteam={}
function __exploreteam.init(obj,kind)
    obj:egHideWidget(kPanelOk)
    obj:egShowWidget(kPanelHero)
    obj:egShowWidget(kPanelShow)
    obj:egHideWidget(kPanelPrompt)
    obj._textField = tolua.cast(obj:egGetWidgetByName(kTextField),"TextField")
    obj:egSetLabelStr(kLblTextInfo,TxtList.welcomeToTeam)
    obj:egSetWidgetColor(kLblTextInfo,kColorGray)
    if obj._kind == 1 then
        obj:egSetLabelStr(kLblName,string.format("%s%s%s",account_data.nickName," ",TxtList.exploreTeam))
         obj:egSetLabelStr(kLblAtkVal,0)
         obj:egSetLabelStr(kLblConTxt,TxtList.charCost)
         obj:egSetLabelStr(kLblConsume,account_data.cbTeamConsume)
         obj:egSetLabelStr(kLblTimeVal,Funs.formatTime(numDef.cbTeamInterval))
    elseif obj._kind == 2 or obj._kind == 3 then
        obj._data = account_data.lookCbTeam
        obj:egSetLabelStr(kLblAtkVal,obj._data.bp)
        obj:egSetLabelStr(kLblConTxt,TxtList.winsCount)
        obj:egSetLabelStr(kLblConsume,obj._data.wins)
        obj:egSetLabelStr(kLblTimeVal,Funs.formatTime(obj._data.ed))
        obj:egSetLabelStr(kLblName,string.format("%s%s",club_data.members[obj._data.tid].name,TxtList.exploreTeam))
        obj:egHideWidget(kImgTextBg)
        obj:egShowWidget(kLblInviteInfo)
        obj:egHideWidget(kLblInvite)
        obj:egSetLabelStr(kLblInviteInfo,club_data.teamMsg[obj._data.tid].content)
        obj:timeUpdate()
    end
    local imgStr=nil
    if obj._kind == 1 then
        local id = account_data.sceneID
        imgStr= string.format("GUIRes/PvrCcz/m_bg/abbr_map_%d.pvr.ccz",id)
    else
        local id = math.random(1,8)
        imgStr= string.format("GUIRes/PvrCcz/m_bg/abbr_map_%d.pvr.ccz",id)
    end    
    obj:egChangeImg(kImgArea,imgStr)
   
    obj:loadExploreTeam()
    obj:loadMyHeros()
end
--�������
function __exploreteam.textImgBgListener(obj)
     local lblTxt = obj:egGetWidgetByName(kLblTextInfo)
    local lblbg = obj:egGetWidgetByName(kPanelChatBg)
    local bgsize = lblbg:getSize()
    local txtsize = lblTxt:getSize()
    local y = lblTxt:getPositionY()
    local startX = 0
    local function touchBegan(sender)
        if txtsize.width > bgsize.width then
            startX =sender:getTouchStartPos().x
        end
    end
    local function touchMoved(sender)
        if txtsize.width > bgsize.width then
            local movedX = sender:getTouchMovePos().x - startX
            local oldx = lblTxt:getPositionX()
            local newx = oldx + movedX
            if newx > 0 then newx = 0
            elseif newx < bgsize.width - txtsize.width then newx =  bgsize.width - txtsize.width end
            lblTxt:setPosition(ccp(newx,y))
        end
    end
    local function touchEnded(sender)
         obj._textField:attachWithIME()
    end
    obj:egBindTouch(kImgTextBg,touchBegan,touchMoved,touchEnded,nil)
end
function __exploreteam.bindTextFieldListener(obj)
    local lblbg = obj:egGetWidgetByName(kPanelChatBg)
	local lblTxt = obj:egGetWidgetByName(kLblTextInfo)
	local y = lblTxt:getPositionY()
	local size = lblbg:getSize()
    local function textFieldEvent(sender, eventType)
        local text = obj._textField:getStringValue()
        if string.len(text) == 0 then
			obj:egSetLabelStr(kLblTextInfo,TxtList.welcomeToTeam)
            lblTxt:setColor(kColorGray)
			obj._inviteText = TxtList.welcomeToTeam
        else
			local utfTxt = Funs.subStr(text,numDef.cbTeamDescLen)
			obj._textField:setText(utfTxt)
            obj:egSetLabelStr(kLblTextInfo,utfTxt)
            lblTxt:setColor(kColorWhite)
			obj._inviteText = utfTxt
        end
        if lblTxt:getSize().width > size.width then
			lblTxt:setPosition(ccp(size.width -lblTxt:getSize().width,y))
		else
			lblTxt:setPosition(ccp(0,y))
		end
		
    end
    obj._textField:addEventListenerTextField(textFieldEvent)
end
--��ʾ�鿴ҳ��
function __exploreteam.showLookView(obj)
    obj:egShowWidget(kBtnBack)
    obj:egHideWidget(kPanelOk)
    obj:egHideWidget(kPanelHero)
    obj:egSetLabelStr(kLblConTxt,TxtList.winsCount)
    local wins = 0
    if obj._data then wins = obj._data.wins end
    obj:egSetLabelStr(kLblConsume,wins)
    
    local panelExteam = obj:egGetWidgetByName(kPanelShowTeam)
    local posx,posy = panelExteam:getPosition()
    panelExteam:setPosition(ccp(posx,posy-10))
    
    local imgWidget = obj:egGetWidgetByName(kImgInfoBg)
    local imgCornor = obj:egGetWidgetByName(kImgCornor)
    local btnBack = obj:egGetWidgetByName(kBtnBack)
    local btnx,btny = btnBack:getPosition()
    local imgx,imgy = imgWidget:getPosition()
    imgWidget:setPosition(ccp(imgx,imgy-50))
    btnBack:setPosition(ccp(btnx,btny-50))
    local sizeBg = imgWidget:getSize()
    local sizeCornor = imgCornor:getSize()
    imgWidget:setSize(CCSizeMake(sizeBg.width,sizeBg.height-285))
    imgCornor:setSize(CCSizeMake(sizeCornor.width,sizeCornor.height-300))
end
--����̽�նӳ�Ա
function __exploreteam.loadExploreTeam(obj)
    obj._teamhero = {}
    obj._userlbl = {}
    local kPanelExTeam = obj:egGetWidgetByName(kPanelShowTeam)
    local posx,posy = kPanelExTeam:getPosition()
    local size = kPanelExTeam:getSize()
    local cellw = 160
    local limit = account_data.cbTeamSize
    if obj._data then limit = club_data.teamMsg[obj._data.tid].limit end
    obj._newx = posx + (size.width - limit*cellw)/2
    local cnt = 0
    if obj._data then
        for key,item in ipairs(obj._data.team) do
            local heroitem = ExploreItem.new(item.heroid,item.herolv,true)
            cnt = cnt + 1
            heroitem:egNode():setPosition(ccp((cnt-1)*cellw,0))
            heroitem:setItemTouchEnabled(false)
            kPanelExTeam:addChild(heroitem:egNode())
            --obj._teamhero[key] = heroitem
            --local lblposx = (obj._newx + (cnt-1)*cellw*0.9 + cellw/2*0.9)
            local lblposx = ((cnt-1)*cellw + cellw/2)
            obj:setUserName(key,lblposx,club_data.members[item.guid].name)
        end
    end
    local leftCnt = limit - cnt
    for key=1,leftCnt do
        local heroitem = ExploreItem.new(0,nil)
        heroitem:setItemTouchEnabled(false)
        if obj._kind ~= 3 and (cnt ==0 or limit-cnt == leftCnt)then heroitem:setItemlight() end
        cnt = cnt + 1
        heroitem:egNode():setPosition(ccp((cnt-1)*cellw,0))
        kPanelExTeam:addChild(heroitem:egNode())
        obj._teamhero[key] = heroitem
    end
    kPanelExTeam:setPosition(ccp(obj._newx,posy))
    
end
function __exploreteam.setUserName(obj,idx,posx,name)
    local widget = obj:egGetWidgetByName(kPanelShowTeam)
    if name then
        local lbl = Label:create()
        lbl:setFontSize(22)
        lbl:setFontName(FNList.STHUPO)
        lbl:setColor(ccc3(83,49,22))
        lbl:setPosition(ccp(posx,-15))
        lbl:setText(name)
        widget:addChild(lbl)
        obj._userlbl[idx]=lbl
    else
        local parent = obj._userlbl[idx]:getParent()
        parent:removeChild(obj._userlbl[idx],true)
        obj._userlbl[idx]=nil
    end
end
--�����Լ�ӵ�еĳ�Ա
function __exploreteam.loadMyHeros(obj)
    if obj._kind == 3 then obj:egHideWidget(kPanelHero) return end
    obj._scrollView  = obj:egGetScrollView(kScrollHero)
    
    local size = obj._scrollView:getSize()
    obj._heroLvList = obj:getHeroLvOrder()
    obj._maxRow = math.ceil(#obj._heroLvList/kMaxTeam)
    local newH = obj._maxRow *kCellH
    if newH> size.height then
        obj._scrollView:setInnerContainerSize(CCSizeMake(size.width,newH))
        obj:bindItemScrollListener()
    else
        newH = size.height    
    end
    obj._newH = newH
    obj._loadedNum = 0
    obj._totalCnt = #obj._heroLvList
    obj:addHeroItem(kMinRowCnt*kMaxTeam)
    if obj._maxRow > 2 then obj:egShowWidget(kImgArrow) end
end
function  __exploreteam.addHeroItem(obj,num)
    local leftCnt = obj._totalCnt - obj._loadedNum
    if num > leftCnt then num = leftCnt end
    local startIdx = obj._loadedNum + 1
    local endIdx = obj._loadedNum + num 
    for idx=startIdx,endIdx do 
        obj._loadedNum = idx
        local curRow = math.ceil(obj._loadedNum/kMaxTeam)
        local y = obj._newH-curRow*kCellH
        local x = (obj._loadedNum-1)%kMaxTeam*kCellW+5
        local heroid = obj._heroLvList[idx][1]
        local herolv = obj._heroLvList[idx][2]
        --local heroitem = ExploreItem.new(heroid,herolv)
        local heroitem = ExpeditionItem.new(heroid,nil,herolv)
        heroitem:egSetPosition(x,y)
        obj:clickHeroItem(heroitem)
        obj._scrollView:addChild(heroitem:egNode(),idx,idx)
        obj._loadViewH = kCellH*curRow
    end
end
--��������
function __exploreteam.bindItemScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then 
            if obj._totalCnt <= obj._loadedNum then return end --�Ѽ�����
            local innerContainer = obj._scrollView:getInnerContainer()
            local posY = innerContainer:getPositionY()
            local size = innerContainer:getSize()
            if obj._loadViewH - posY  < size.height then
                obj:addHeroItem(kMinRowCnt*kMaxTeam)
            end
        end
    end
    obj._scrollView:addEventListenerScrollView(scrollEvent) 
end
--Ӣ�۰��ȼ�����
function __exploreteam.getHeroLvOrder(obj) 
    local tb={}
    for heroid,item in pairs(account_data.heroList) do
        if not account_data.cbTeam[heroid] and not obj:isTeamLastHero(heroid) then
           table.insert(tb,{heroid,item.lv})
        end   
    end
    table.sort(tb,function(a,b) return a[2]>b[2] end)
    return tb
end
function __exploreteam.isTeamLastHero(obj,heroid)
    if #account_data.team == 1 and account_data.team[1] == heroid then
        return true
    end
    return false
end
--Ӣ�۵���ص�
function __exploreteam.clickHeroItem(obj,heroitem)
    local function callback()
        local heroid = heroitem:getprop("heroid")
        local herolv = account_data.heroList[heroid].lv
        obj:egShowWidget(kPanelOk)
        local btnWidget = obj:egGetWidgetByName(kBtnOk)
        btnWidget:setTouchEnabled(true)
        obj:egSetLabelStr(kLblLvUpTime,0)
        local panelhero = obj:egGetWidgetByName(kPanelSelectHero)
        --local hero = ExploreItem.new(heroid,herolv)
        local hero = ExpeditionItem.new(heroid,nil,herolv)
        panelhero:addChild(hero:egNode())
        
        obj._teamhero[1]:updateHeroInfo(heroid,herolv,true)
        obj:changCbTeamInfo(true,heroid)
        local cellw = 150
        if obj._data then
            local cnt = #obj._data.team + 1
            local lblposx = ((cnt-1)*cellw + cellw/2)
            obj:setUserName(cnt,lblposx,account_data.nickName)
        else
            local cnt = 1
            local lblposx = (obj._newx + (cnt-1)*cellw + cellw/2)
            obj:setUserName(1,lblposx,account_data.nickName)
        end    
        obj._selectheroid = heroid
    end
    heroitem:onItemClicked(callback)
end
function __exploreteam.changCbTeamInfo(obj,show,heroid)
    local atkcap = 0
    if heroid then atkcap = RiskHelper.getHeroBp(account_data.heroList[heroid],account_data) end
    if obj._data then
        if show then
            local totelAtk = atkcap + obj._data.bp
            obj:egSetLabelStr(kLblAtkVal,totelAtk)
        else
            obj:egSetLabelStr(kLblAtkVal,obj._data.bp)
        end
    else
        if show then
            obj:egSetLabelStr(kLblAtkVal,atkcap)
            --obj:egSetLabelStr(kLblConsume,account_data.cbTeamConsume)
            --obj:egSetLabelStr(kLblTimeVal,Funs.formatTime(numDef.cbTeamInterval))
        else
            obj:egSetLabelStr(kLblAtkVal,0)
            --obj:egSetLabelStr(kLblConsume,0)
            --obj:egSetLabelStr(kLblTimeVal,0)
        end
    end
end

function __exploreteam.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelLayer)
    widget:setPosition(ccp(0,720))  
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end
function __exploreteam.hideLayer(obj)
    local function callback()
        graphicLoader.removeCreatureAnima()
        obj:egRemoveSelf()
    end    
    obj._masklayer:runAction(CCFadeTo:create(0.5,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __exploreteam.actionWait(obj,isWait)
    if isWait then
        obj:egShowWidget(kPanelPrompt)
        obj:egShowWidget(kImgLoading)
        local imgWidget = obj:egGetWidgetByName(kImgLoading)
        local rotateby = CCRotateBy:create(1,360)
        local repeatforever = CCRepeatForever:create(rotateby)
        imgWidget:runAction(repeatforever) 
    else
        obj:egHideWidget(kPanelPrompt)
        obj:egHideWidget(kImgLoading)
        local imgWidget = obj:egGetWidgetByName(kImgLoading)
        imgWidget:stopAllActions()
    end    
end

function __exploreteam.activeUpdate(obj)
   local startTime = os.time()
   local function callback()
       if not AccountHelper:isLocked(kStateAdventureTeam) then
		obj:egUnbindWidgetUpdate(kBtnOk)
		 obj:actionWait(false)
           if obj._kind == 1 then --����̽�ն�
               account_data.cbTeam[obj._selectheroid]={}
               account_data.cbTeam[obj._selectheroid].tid = account_data.guid
               account_data.cbTeam[obj._selectheroid].ed = club_data.teamMsg[account_data.guid].date + numDef.cbTeamInterval
               for idx,heroid in ipairs(account_data.team) do
                   if heroid == obj._selectheroid then
                       table.remove(account_data.team,idx)
                       SendMsg[934003](account_data.team)
                   end
               end
               NotifyHelper.show(NotifyCode.teamReturn)
               obj:hideLayer()
               showExploreTeam(nil,3)
           elseif obj._kind == 2  and obj._joinTeam then --����̽�ն�
               if not account_data.cbTeam[obj._selectheroid] then--����̽�ն�ʧ��
                   local msglayer = MsgLayer.new(nil,TxtList.joinCbTeamFalse,1,nil,nil)
                   msglayer:show()
                   obj:egShowWidget(kBtnBack)
               else
                   for idx,heroid in ipairs(account_data.team) do
                       if heroid == obj._selectheroid then
                           table.remove(account_data.team,idx)
                           SendMsg[934003](account_data.team)
                       end
                   end
                   obj:showLookView()
               end   
           elseif obj._kind ==2 or obj._kind==3 then --�鿴̽�ն�
               if account_data.lookCbTeam and account_data.lookCbTeam.ed>0 then
                   obj:init(obj._kind)
                   obj:bindTextFieldListener()
               elseif not account_data.lookCbTeam  or account_data.lookCbTeam.ed<0 then--�鿴̽�ն�ʧ��
                   obj:egShowWidget(kPanelPrompt)
                   local msgLayer = MsgLayer.new(nil,TxtList.cbTeamOver,1,nil,nil)
                   msgLayer:show()
                   ChatHelper.updateGuildMsg(4,-obj._tid)
                   obj:hideLayer()
               end  
           end  
       else
           if os.time() - startTime >numDef.clientTimeOut then
                obj:egUnbindUpdate()
                local imgWidget = obj:egGetWidgetByName(kImgLoading)
                imgWidget:stopAllActions()
		        postEventSignal(kEventRequestTimeOut)
            end   
       end    
       
   end    
    obj:egBindWidgetUpdate(kBtnOk,callback)
end
function __exploreteam.timeUpdate(obj)
    local function callback()
       local leftTime = obj._data.startEd - os.time()
       obj:egSetLabelStr(kLblTimeVal,Funs.formatTime(leftTime))
       if leftTime <=0 then
           obj:egUnbindWidgetUpdate(kLblTime)
       end
    end
    obj:egBindWidgetUpdate(kLblTime,callback)
end
function __exploreteam.bindOkListener(obj)
    local function touchEnd(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj:egShowWidget(kPanelPrompt)
        obj:egHideWidget(kBtnBack)
        local herolv = account_data.heroList[obj._selectheroid].lv
        local atkcap = RiskHelper.getHeroBp(account_data.heroList[obj._selectheroid],account_data)
        --local content = obj._textField:getStringValue()
        if obj._kind == 1 then
            SendMsg[9313001](obj._selectheroid,atkcap,obj._inviteText)
            AccountHelper:lock(kStateAdventureTeam)
            obj:activeUpdate()
            obj:actionWait(true)
        elseif obj._kind == 2 then
            SendMsg[9313003](obj._data.tid,obj._selectheroid,atkcap)
            AccountHelper:lock(kStateAdventureTeam)
            obj._joinTeam = true
            obj:activeUpdate()
            obj:actionWait(true)
        end    
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnd,nil)
end
function __exploreteam.bindCancelListener(obj)
    local function touchEnd(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj:egHideWidget(kPanelOk)
        obj:egShowWidget(kPanelHero)
        obj._teamhero[1]:updateHeroInfo(0,nil)
        if obj._data then 
            obj:setUserName(#obj._data.team + 1,nil,nil)
        else    
            obj:setUserName(1,nil,nil)
        end
        local panelhero = obj:egGetWidgetByName(kPanelSelectHero)
        panelhero:removeAllChildren()
        obj:changCbTeamInfo(false)
    end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnd,nil)    
end

function __exploreteam.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideLayer()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

function __exploreteam.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideLayer()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end

ExploreTeam={}
function ExploreTeam.new(kind,tid)--kind==1 ����̽�ն�;kind==2 ����̽�նӣ�kind==3 �鿴̽�ն�
    local obj = TouchWidget.new(JsonList.exploreTeamLayer)
    table_aux.unpackTo(__exploreteam, obj)
    obj._kind = kind
    obj._tid = tid
    if kind == 3 then obj:showLookView() end
    if kind == 2 or kind == 3 then
        if not tid then 
           SendMsg[9313002](account_data.guid)
           AccountHelper:lock(kStateAdventureTeam)
           obj._tid = account_data.guid
        end
        obj:egShowWidget(kPanelPrompt)
        obj:egHideWidget(kPanelShow)
        obj:activeUpdate()
        obj:actionWait(true)
    else
        obj:egHideWidget(kPanelPrompt)
        obj:init(kind)
        obj:bindTextFieldListener()
    end
    obj:textImgBgListener()
    
    obj:bindPanelListener()
    obj:bindOkListener()
    obj:bindCancelListener()
    obj:bindBackListener()
    return obj
end
function showExploreTeam(callback,kind,tid)
    local layer = ExploreTeam.new(kind,tid)
    local scene = CCDirector:sharedDirector():getRunningScene()
	scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction(callback)    
end

local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local __atkscene={}
function __atkscene.init(obj,areaid,stageid)
   -- SendMsg[934001]()
    SoundHelper.playBGM(SoundList.getBattleBGM(areaid,stageid))
    obj._d_data = RiskHelper.getAtkSceneData(areaid,stageid)
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._atklayer = PvpLayer.new(obj._d_data,obj)
        obj._atklayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
		showEmDialog(obj,GuideScene.def.kPveScene) --����������Ϣ
    end
    obj._groundlayer:showInAtkScene()
	obj._groundlayer:onHeroShown(callback)  
end
function __atkscene.getAtkAward(obj,areaid,stageid,gainStar)
	local resList={}
	local heroMsgList = {}
	local expVal = 0
	local teamExp = {0,0,0,0}
	if gainStar > 0 then
		local rate = gainStar/numDef.starsPerStage
		local mixStageid = areaid * 100 + stageid
		local stagedata = pveQuery.queryStage(areaid,stageid)
		if MissionHelper.groupIdx then
			resList.gold,resList.iron,resList.copper,resList.stoneR,resList.stoneB,resList.stoneD=baseCalc.getDayRes(mixStageid,obj._d_data.digLv, stagedata.gold,stagedata.iron,stagedata.copper,stagedata.stoneR,stagedata.stoneB,stagedata.stoneD)
			heroMsgList = stagedata.heromessage or {}
			expVal = baseCalc.getDaypveExp(mixStageid,obj._d_data.digLv,stagedata.exp*rate)
			teamExp = baseCalc.getTeamExp(expVal,obj._d_data.teamList,obj._d_data.heroList,obj._d_data.digLv)
		else
			expVal = stagedata.exp*rate
			teamExp = baseCalc.getTeamExp(expVal,obj._d_data.teamList,obj._d_data.heroList,obj._d_data.digLv)
			if account_data.unlockedPVE[areaid][stageid].first then
				for idx,coinname in pairs(KVariantList.coinType) do 
					resList[coinname] = stagedata[coinname]
				end
				heroMsgList = stagedata.heromessage or {}
			else --�ظ����Ѵ���Ĺؿ���ֻ�ܻ�ý�ң�������Դ�޷����
				resList.gold = stagedata.gold or 0
			end
		end
	end
	return resList,heroMsgList,teamExp
end
function __atkscene.stopBattle(obj)
    SendMsg[934002](battleProgress)
	AccountHelper:unlock(kStateBpResult)
    BPResult ={}
    BPResult.stars =  battleProgress.stars 
	local areaid = obj._d_data.areaid
	local stageid = obj._d_data.stageid
	local rate = BPResult.stars/numDef.starsPerStage
	local resList,heroMsgList,teamExp = obj:getAtkAward(areaid,stageid,BPResult.stars)
	----���»�õ�Ӣ����Ϣ
	BPResult.heroInfo=heroMsgList
	for heroid,msgnum in pairs(heroMsgList) do
		--�ѻ�õ���Ϣ���ݿ��Գ�����Ϣ����
		account_data.heroInfoList[heroid] = (account_data.heroInfoList[heroid] or 0 ) + msgnum
		print("pve gain heroid:",heroid,",heromsg:",msgnum)
	end
	for key,val in pairs(resList) do
		BPResult[key] = math.floor(val*rate)
		account_data[key] = (account_data[key] or 0) + BPResult[key]
		print("pve gain ",key,":",BPResult[key])
	end
	print("pve exp ",unpack(teamExp))
	--BPResult.teamExp ���¾���ֵ
	BPResult.teamExp = teamExp
	RiskHelper.updateHeroExp(teamExp)
	--------------------------------------
    --����PVE�ؿ� ���Ը���������
    --��������ر�ǽ����¹ؿ�
    local myArea = account_data.unlockedPVE[areaid]
    local myStage = myArea[stageid]
    if BPResult.stars > myStage.stars then
		if not MissionHelper.groupIdx  then
			 myArea.areaStars = myArea.areaStars - myStage.stars + BPResult.stars
		end
		account_data.stars = (account_data.stars or 0) - myStage.stars + BPResult.stars
        myStage.stars = BPResult.stars
        myStage.first = nil
        if  pveCalc.isStageClear(areaid,stageid,account_data) then
            pveCalc.unlockNext(areaid,stageid,account_data)
        end
    end
    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end
AtkScene={}
function AtkScene.new(areaid,stageid)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__atkscene, obj)
    obj:init(areaid,stageid)
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
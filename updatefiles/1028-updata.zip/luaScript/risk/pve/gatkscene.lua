local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local __atkscene={}
function __atkscene.init(obj)
    obj._d_data = RiskHelper.getGAtkSceneData()
	SoundHelper.playBGM(SoundList.getBattleBGM())
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
	obj._groundlayer:setOwner(obj)
    local function callback()
		showEmDialog(obj,GuideScene.def.kAtkScene) --����������Ϣ
        obj._atklayer = GAtkLayer.new(obj._d_data,obj)
        obj._atklayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene()
	obj._groundlayer:onHeroShown(callback)
    --��������ID
	--showDialog(1)
end
function __atkscene.stopBattle(obj)
	local colorLayer = CCLayerColor:create(ccc4(0,0,0,0))
	obj:egAddChild(colorLayer,kScoreOrder,kScoreOrder)
	
	local fadeIn = CCFadeTo:create(3,255)
	local function callback()
		local scene = ComicScene.new()
		scene:egReplace()
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(fadeIn,callfunc)
	colorLayer:runAction(sequence)
end
GAtkScene={}
function GAtkScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__atkscene, obj)
    obj:init()
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
local __battleground = {}
function __battleground.onGroundClicked(obj,callback)
    obj._groundClickCallback = callback
end
function __battleground.activeTouch(obj)
    local p_movedelta = 0
    local p_touchstart = 0
    local p_touches={count=0}

    local function onTouchesBegan(touches) --touch began
        for i = 1,#touches,3 do
            p_touches[touches[i+2]] = {x = touches[i],y =touches[i+1]}
            p_touches.count = p_touches.count + 1
        end

        if p_touches.count == 1 then    p_touchstart = os.clock() end
    end
    local function onTouchesMoved(touches)
		 if p_touches.count == 0 then return end
        local x = touches[1]
        local y = touches[2]
        local id = touches[3]

        p_movedelta = ccpDistance(ccp(x,y),ccp(p_touches[id].x,p_touches[id].y))
    end
    local function onTouchesEnded(touches)
        if p_touches.count == 0 then return end
        local touch_ms = (os.clock()-p_touchstart) * 1000
    
        if p_movedelta<=obj._egkmaxoffset and  touch_ms < obj._egkmaxtouchms and p_touches.count == 1 then
            p_touchstart = 0
            if obj._groundClickCallback then 
				local posx = touches[1]
				local posy = touches[2]
                local idx = obj._blocklayer:getIdxByScreenPos(posx,posy)
                obj._groundClickCallback(idx,posx,posy) 
            end
		else
			if AccountHelper:isLocked(kStateGuide) then
				p_touchstart = 0
				if obj._groundClickCallback then 
					local posx = touches[1]
					local posy = touches[2]
					local idx = obj._blocklayer:getIdxByScreenPos(posx,posy)
					obj._groundClickCallback(idx,posx,posy) 
				end
			end
        end
        p_movedelta = 0

        for i = 1,#touches,3 do
            p_touches[touches[i+2]] = nil
            p_touches.count = p_touches.count-1
        end
    end
    obj:egBindTouchesEvent(onTouchesBegan,onTouchesMoved,onTouchesEnded)
end

--������
function __battleground.touchAtPos(obj,posX,posY)
    local idx = obj._blocklayer:getIdxByScreenPos(posX,posY) --��ȡ��ǰ���������λ��
    local blocklayer = obj._blocklayer
    local viewlayer = obj._viewlayer
	if obj._owner._atklayer._selectedTool then 
		obj._owner._atklayer._selectedTool:setSelected(false) 
            if blocklayer:isDigged(idx) then
                if viewlayer:isLighted(idx) then
                    obj._owner._atklayer._selectedTool:doUseToolAt(idx,obj._frameID)
                else
                    obj:showPropMsg(TxtList.digPrompt[7],posX,posY)
                end
            else
                obj:showPropMsg(TxtList.digPrompt[2],posX,posY)
            end
    end

end

BattleGround={}
function BattleGround.install(obj)
    table_aux.unpackTo(__battleground, obj)
    obj._egkmaxtouchms = 350
    obj._egkmaxoffset = 36
    obj:activeTouch()
end
local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local __defscene={}
function __defscene.init(obj,stageid)
    obj._d_data = RiskHelper.getDefSceneData(stageid)
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._deflayer = DefLayer.new(obj._d_data,obj)
        obj._deflayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInDefScene()
	obj._groundlayer:onHeroShown(callback)
end
function __defscene.stopBattle(obj)
    SendMsg[934011]( battleProgress.stars,obj._d_data.stageid)
    BPResult ={}
    BPResult.stars =  battleProgress.stars 
	account_data.pveGuardQuest[obj._d_data.stageid].first = nil
    local gainStar = numDef.starsPerStage - BPResult.stars
	local oldStarCnt = account_data.pveGuardQuest[obj._d_data.stageid].stars 
	local awardRes = pveGuardQuest.pveGuardprize(account_data,obj._d_data.stageid,gainStar)
	for key,val in pairs(awardRes) do
		BPResult[key] = math.floor(val * gainStar /numDef.starsPerStage)
		account_data[key] = account_data[key] + BPResult[key]
	end
	if gainStar > 0 and account_data.pveGuardQuest[obj._d_data.stageid].nextUnlocked~=1 then
		pveGuardQuest.unlockNext(account_data,obj._d_data.stageid)
	end
	if oldStarCnt < gainStar then
		account_data.pveGuardQuest[obj._d_data.stageid].stars = gainStar
		account_data.pveGuardStars = (account_data.pveGuardStars or 0) - oldStarCnt + gainStar
		account_data.stars = (account_data.stars or 0) - oldStarCnt + gainStar
		if gainStar >= numDef.starsPerStage then
			account_data.pveGuardQuest[obj._d_data.stageid] = nil
		end
	end
    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end
DefScene={}
function DefScene.new(stageid)
    SoundHelper.playBGM(SoundList.def_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__defscene,obj)
    obj:init(stageid)
    --showEmDialog(obj,GuideScene.def.kAtkScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
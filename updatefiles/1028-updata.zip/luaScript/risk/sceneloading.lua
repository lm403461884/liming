local visibleSize = CCDirector:sharedDirector():getVisibleSize()
local kLblTps = "lbl_guild"
local kLblLoad = "lbl_load"
local kImgBarFront = "img_bar_front"
local kBarLoad = "bar_load"
local kBarLen = 900
local kSpeed = 500
local kHeroPosX = 290
local kHeroPosY = 152
local kResCarPosX = 640
local kResCarPosY = 169
local kSpriteW = 72
local kMaxLoadCnt = 4
local kMaxTipW = 1200
local kMaxTipH = 80
local __sceneloading = {}
function __sceneloading.init(obj,team,heroList)
	obj._spriteList = {}
	if not team then
		--team 为nil,heroList实际为collectorList
		local sprite = CCSprite:createWithSpriteFrameName("stand_01.png")
		obj:egAddChild(sprite)
		sprite:setPosition(ccp(kResCarPosX,kResCarPosY))
		local anima = CCAnimationCache:sharedAnimationCache():animationByName(collectorCfg[heroList[1].lv].actGrab)
		local animate = CCAnimate:create(anima)
		sprite:runAction(CCRepeat:create(animate, 10000))
		obj:egShowWidget(kImgBarFront)
		obj:egShowWidget(kBarLoad)
		obj:egSetBarPercent(kBarLoad,0)
	else
		obj._team = team
		obj._heroList = heroList
		obj._maxCnt = math.min(#obj._team,kMaxLoadCnt)
		obj:loadTeamHero()
		obj:egHideWidget(kImgBarFront)
		obj:egHideWidget(kBarLoad)
	end
	 --服务器配置 Tips显示
	local idx = 1
	if account_data.digLv == 1 then
		 idx = math.random(1,math.min(7,#TipsList))
	elseif account_data.digLv == 2 then
		 idx = math.random(1,math.min(12,#TipsList))
	else
		 idx = math.random(1,#TipsList)
	end
	local lbl = tolua.cast(obj:egGetWidgetByName(kLblTps),"Label")
	lbl:setText("Tips:"..TipsList[idx])
	if lbl:getSize().width > kMaxTipW then
		lbl:setTextAreaSize(CCSizeMake(kMaxTipW,kMaxTipH))
	end
end
function __sceneloading.loadTeamHero(obj)
		 for key,heroprop in pairs(obj._heroList) do
			local heroid = heroprop.type
			local herolv = heroprop.lv
			local creature_cfg = assert(hero_data.getConfig(heroid))
			local creature_data = assert(hero_data.get(heroid,herolv))
			local graphicName = creature_cfg.graphList[creature_data.graphLV]
			local frameName = string.format("%s_010201.png",graphicName)
			graphicLoader.loadHeroAnima(heroid,herolv,true)
			local heroSprite = CCSprite:createWithSpriteFrameName(frameName)
			obj:egAddChild(heroSprite)
			heroSprite:setPosition(ccp(kHeroPosX - (key-1)*kSpriteW,kHeroPosY))
			local anima = graphicLoader.getAnimation(string.format('%s_0201', graphicName))
			anima:setRestoreOriginalFrame(true)
			heroSprite:runAction(CCRepeat:create(CCAnimate:create(anima),10000))
			table.insert(obj._spriteList,heroSprite)
		end
end
function __sceneloading.start(obj)
	local passed = 0
	local function callback(delta)
		passed = passed + 0.016
		for key,herosprite in ipairs(obj._spriteList) do
			herosprite:setPosition(kHeroPosX - (key-1)*kSpriteW + math.min(passed*kSpeed,kBarLen),kHeroPosY)
		end
		obj:egSetBarPercent(kBarLoad,math.min(passed*kSpeed*100/kBarLen,100))
	end
	 obj:egBindWidgetUpdate(kLblLoad,callback)
end
function __sceneloading.stop(obj,isremove)
	obj:egUnbindWidgetUpdate(kLblLoad)
	for key,herosprite in ipairs(obj._spriteList) do
		herosprite:setPosition(kHeroPosX - (key-1)*kSpriteW + kBarLen,kHeroPosY)
	end
	obj:egSetBarPercent(kBarLoad,100)
	if isremove then
		local function callback()
			obj:egNode():removeAllChildrenWithCleanup(true)
			obj:egRemoveSelf()
		end
		local fadeout = CCFadeOut:create(0.2)
		local callfunc = CCCallFunc:create(callback)
		obj:egNode():runAction(CCSequence:createWithTwoActions(fadeout,callfunc))
	end
end
function __sceneloading.clean(obj)
	obj:egNode():removeAllChildrenWithCleanup(true)
	obj:egRemoveSelf()
end
SceneLoading ={}
function SceneLoading.new(team,heroList)
	graphicLoader.removeCreatureAnima(true)
	local obj = TouchWidget.new(JsonList.sceneLoading)
    table_aux.unpackTo(__sceneloading, obj)
	obj:init(team,heroList)
	return obj
end

--������ʾ
local kImgMask= "img_mask"
local kBtnOk = "btn_ok"
local kBtnClose = "btn_close"
local kPanelLayer = "result_panel"
local kInner1 = "inner_1"
local kInner2 = "inner_2"
local kInner3 = "inner_3"
local kLabelState = "lbl_state_war"
local kBtnJump = "btn_jump"
local kLblJump = "lbl_jump"
local kLblJumps = "lbl_jump_s"
--����ģ��
local kPanleBox = "box_panel"
local kAwardList = "award_list"
local kBoxList = "box_list"
local kImgBlack = "img_black"
local kBtnNext = "btn_next"
local kImgStateBox = "img_state_box"
local kLblTime = "lbl_time"

--���ݽ�������ʾ���
local kPanelLoad = "load_panel"
local kImgLoading = "img_loading"

--������ʾ���
local kPanelInfo = "info_panel"
local kListHero = "list_hero"
local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"

local kPosX = 640
local kPosY = 305
local kCellW = 160
local kBoxW = 240
local kCardW = 150
local kItemW = 142
local kMaxNum = 5
local kMargin1 = 10
local kMargin2 = 15
local kPosRight = 825
local __battleresultlayer = {}

function __battleresultlayer.init(obj,d_data)
    obj._d_data = d_data
	obj._unOpenBox = {}
	obj._openBox = {}
	obj._awardList = {}
	obj._awardItems={}
	obj._boxTypeList = {}
	obj._allStarLoaded = false
    if obj._d_data.type == 0 then --����
        obj:egChangeImg(kImgMask,ImageList.risk_mask_atk)
		if obj._d_data.btFlag == 0 or obj._d_data.btFlag ==4 then
			if battleProgress.stars > 0 then
				obj:egSetLabelStr(kLabelState,TxtList.winTxt)
			else
				obj:egSetLabelStr(kLabelState,TxtList.loseTxt)
			end
		else
			if battleProgress.stars > 0 then
				obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.succTxt))
			else
				obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.failTxt))
			end
		end
    else --����
        obj:egChangeImg(kImgMask,ImageList.risk_mask_def)
		 battleProgress.stars = numDef.starsPerStage - battleProgress.stars
		 if obj._d_data.btFlag ==3 then --��������
			if battleProgress.stars > 0 then
				obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.succTxt))
			else
				obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.failTxt))
			end
		 else --PVP����
			if battleProgress.stars <3 then
				obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.failTxt))
			else
				obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.succTxt))
			end
		end
    end
    obj:showInfoPanel(false)
    obj:showLoadPanel(true)
    obj:showStars(false)
    obj:showBoxPanel(false)
	local function callback()
	    obj:showStars(true)
	    obj:activeLoadTimer()
	end
    obj:showWithAction(callback)
end
--������ʾ����
function __battleresultlayer.bounceScaleWidget(obj,widgetName,s,from,to,callback)
    local widget = obj:egGetWidgetByName(widgetName)
    widget:setScale(from)
    local scaleto = CCScaleTo:create(s,to)
    local bounceout = CCEaseBounceOut:create(scaleto)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(bounceout,callfunc)
        widget:runAction(sequence)
    else
        widget:runAction(bounceout)
    end
end
function __battleresultlayer.showJumpBtn(obj)
	if obj._d_data.btFlag == 2 or  obj._d_data.btFlag == 2  then return end
	if obj._d_data.type == 0 then --����
		if BPResult.stars == 0 then
			obj:egSetLabelStr(kLblJump,TxtList.improveEquip)
			obj:egSetLabelStr(kLblJumps,TxtList.improveEquip) 
			obj:egShowWidget(kBtnJump)
			local btnok = obj:egGetWidgetByName(kBtnOk)
			btnok:setPosition(ccp(kPosRight,btnok:getPositionY()))
			obj:bindJumpEquipListener()
		end
	else --����
		if BPResult.stars == 3 then
			obj:egSetLabelStr(kLblJump,TxtList.improveMonster)
			obj:egSetLabelStr(kLblJumps,TxtList.improveMonster)
			obj:egShowWidget(kBtnJump)
			local btnok = obj:egGetWidgetByName(kBtnOk)
			btnok:setPosition(ccp(kPosRight,btnok:getPositionY()))
			obj:bindJumpMonsterListener()
		end
	end
end
function __battleresultlayer.showBoxPanel(obj,show)
	if show then
	    obj._boxTimeCount = 0 --��������ҳ��
		obj:egShowWidget(kPanleBox)
		obj:egShowWidget(kBoxList)
		obj:egShowWidget(kImgStateBox)
		obj:egHideWidget(kBtnNext)
		local imgblack = obj:egGetWidgetByName(kImgBlack)
		imgblack:setOpacity(0)
		imgblack:runAction(CCFadeTo:create(0.2,128))
		obj:loadBattleBox()
		obj:bindBoxListener()
		obj:bindNextListener()
		obj:openBoxTimeUpdate()
	else
		obj:egHideWidget(kPanleBox)
		obj:egHideWidget(kBoxList)
		obj:egHideWidget(kBtnNext)
		obj:egHideWidget(kImgStateBox)
		obj:egHideWidget(kLblTime)
	end
end
--�����䵹��ʱ
function __battleresultlayer.openBoxTimeUpdate(obj)
    obj:egShowWidget(kLblTime)
    obj._boxTimeCount = obj._boxTimeCount + 1 
    local count = 0
    local time = 10
    local function callback(delte)
        count = count + delte
        if count > 1 then
            count = 0
            time = time - 1
            obj:egSetLabelStr(kLblTime,time)
        end
        if time == -1 then
            obj:egUnbindWidgetUpdate(kLblTime)
            obj:openAllBoxs()
        elseif time==0 then
            obj:egSetWidgetTouchEnabled(kBoxList,false) 
            for cnt,item in pairs(obj._unOpenBox) do
                item:setEnabled(false)
            end
        end
        if (obj._openCnt%kMaxNum== 0 and obj._boxTimeCount == obj._openCnt/kMaxNum) or obj._openCnt == obj._d_data.battleBoxCnt then
            obj:egHideWidget(kLblTime)
            obj:egUnbindWidgetUpdate(kLblTime)
        end
    end
    obj:egBindWidgetUpdate(kLblTime,callback)
end
--�Զ��򿪵�ǰҳʣ�౦��
function __battleresultlayer.openAllBoxs(obj)
    obj:egHideWidget(kImgStateBox)
    --local boxCounts = #obj._unOpenBox + obj._openCnt
    if obj._d_data.battleBoxCnt~= obj._openCnt and obj._openCnt < kMaxNum * obj._boxTimeCount then
        for idx=1,kMaxNum* obj._boxTimeCount,1 do
            if idx <= obj._d_data.battleBoxCnt and not obj._openBox[idx] then
                obj._openBox[idx] = obj._unOpenBox[idx]
			    obj._unOpenBox[idx]:setScale(1)
                obj:openBoxById(idx)
            end    
        end
    end
end
--�Ƿ�Ϊδ�򿪵ı���
function __battleresultlayer.isUnOpenBox(obj,idx)
    for idxs,item in pairs(obj._openBox) do
        if idx == idxs then return false end 
    end
    return true
end
--����ս�����������
function __battleresultlayer.loadBattleBox(obj)
	local cnt = 0
	obj._openCnt = 0
	local boxlist = obj:egGetWidgetByName(kBoxList)
	local awardpanel = obj:egGetWidgetByName(kAwardList)
	for mtype, awardList in ipairs(obj._d_data.battleBox) do
		for key,awardInfo in ipairs(awardList) do
			local boxWidget = ImageView:create()
			boxWidget:loadTexture(ImageList[string.format("comm_box_%s",KVariantList.boxType[mtype])],UI_TEX_TYPE_PLIST)
			boxlist:addChild(boxWidget,1,cnt)
			boxWidget:setPosition(ccp((cnt + 0.5) * kBoxW,kBoxW/2))
			cnt = cnt + 1
			obj._awardList[cnt] = awardInfo
			obj._unOpenBox[cnt] = boxWidget
			obj._boxTypeList [cnt] = mtype
		end
	end
	if cnt < kMaxNum then
	    local neww = cnt * kBoxW
	    local oldw = boxlist:getSize().width
	    boxlist:setPosition(ccp(boxlist:getPositionX() + (oldw-neww)/2,boxlist:getPositionY()))
		awardpanel:setPosition(ccp(awardpanel:getPositionX() + (oldw-neww)/2,awardpanel:getPositionY()))
	end
end
--��ȡ���������ID
function __battleresultlayer.getTouchedBoxID(obj,pos)
	 for boxid,box in pairs(obj._unOpenBox) do
		if not obj._openBox[boxid] then
			local sprite = tolua.cast(box:getVirtualRenderer(),"CCSprite")
			local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
			if not isalpha then
				return boxid
			end
		end
	end
	return 0
end

--������ʾ������Ϣ
function __battleresultlayer.scaleAndShow(obj,awardItem,x,callbackfunc)
	local panel = obj:egGetWidgetByName(kAwardList)
	local panelH = panel:getSize().height
	local panelW = panel:getSize().width
	local widget = awardItem:egNode()
	local widgetW = widget:getSize().width
	local widgetH = widget:getSize().height
	widget:setPosition(ccp(x - widgetW/2,(panelH - widgetH)/2)) --���������ʾλ��
	awardItem:scaleAndShowWithSrc(x - widgetW/2,0,callbackfunc)
	panel:addChild(widget,1,panel:getChildrenCount() + 1)	
	table.insert(obj._awardItems,awardItem)
end
--�����ӵĶ���
function __battleresultlayer.showBoxOpenActions(obj,boxId)
	local mtype =  obj._boxTypeList[boxId]
	local boxWidget = obj._unOpenBox[boxId]
	local box_X = boxWidget:getPositionX()
	local actionName = KVariantList.boxAction[mtype]
    local anima = graphicLoader.getAnimation(actionName)
    if not anima then print("can not find ",actionName) end
    anima:setRestoreOriginalFrame(true)
    local animate = CCAnimate:create(anima)
    local sprite = tolua.cast(boxWidget:getVirtualRenderer(),"CCSprite") 
	local function animaCallback()
		boxWidget:loadTexture(ImageList[string.format("comm_box_%s_open",KVariantList.boxType[mtype])],UI_TEX_TYPE_PLIST)
	end
	local sequence = CCSequence:createWithTwoActions(animate,CCCallFunc:create(animaCallback))
	sprite:runAction(sequence)
	local counter = anima:getTotalDelayUnits()/2 * anima:getDelayPerUnit()
	
    local function update(delta)
		counter = counter - delta
		if counter > 0 then return end
		boxWidget:unscheduleUpdate()
		local particle = CCParticleSystemQuad:create("particle/battle/chestbox01.plist")
	    --particle:setAutoRemoveOnFinish(true)
		sprite:addChild(particle,1,1)
		local awardinfo = obj._awardList[boxId]
		local function callbackfunc()
			if obj._openCnt == obj._d_data.battleBoxCnt then
				obj:egShowWidget(kBtnOk)
				obj:showJumpBtn()
			elseif obj._openCnt%kMaxNum == 0 then
				obj:egShowWidget(kBtnNext)
			end
		end
		local awardtype = awardinfo[1]
		local subtype = awardinfo[2]
		local awardval = awardinfo[3]
		if awardtype == 1 then --��Դ����
			local cointype =  KVariantList.coinType[subtype]
			SoundHelper.playEffect(SoundList.buy_message_01)
			local resaward = ResAward.new(cointype,Funs.signedNum(awardval))
			account_data[cointype] = account_data[cointype] + awardval
			obj:scaleAndShow(resaward,box_X,callbackfunc)
		elseif awardtype == 2 then --Ӣ����Ϣ����
			local heromsg = HeroMsgAward.new(subtype,awardval)
			--��õ�Ӣ����Ϣ����������ļ�ͽ�������Ӱ��
			account_data.heroInfoList[subtype] = (account_data.heroInfoList[subtype] or 0) + awardval
			obj:scaleAndShow(heromsg,box_X,callbackfunc)
		elseif awardtype == 3 then --װ��
			local equipid = equipFuncs.getSubEquipId(subtype,awardval,equipFuncs.getSubEquipCfg(subtype,"quality"))
			account_data.equipSub[equipid] = (account_data.equipSub[equipid] or 0) + 1
			local equipaward = EquipAward.new(equipid)
			obj:scaleAndShow(equipaward,box_X,callbackfunc)
		end
	end
	local function exitFuns(eventType)
        if eventType == "exit" then  boxWidget:unscheduleUpdate() end
    end
    boxWidget:scheduleUpdateWithPriorityLua(update, 0)
    boxWidget:registerScriptHandler(exitFuns)
end
--������
function __battleresultlayer.openBoxById(obj,boxId)
    obj._openCnt = obj._openCnt +1 --�Ѿ��򿪵�������
	SoundHelper.playEffect(SoundList.open_treasurebox)
	--[[]]
	local boxWidget = obj._unOpenBox[boxId]
	local boxPanel = obj:egGetWidgetByName(kBoxList)
	local moveby1 = CCMoveBy:create(0.1,ccp(5,3))
    local moveby2 = CCMoveBy:create(0.1,ccp(-5,-3))
    local moveby3 = CCMoveBy:create(0.1,ccp(5,0))
    local moveby4 = CCMoveBy:create(0.1,ccp(-5,0))
	local function callback()
	--]]
		obj:showBoxOpenActions(boxId)
		--[[]]
	end
    local callfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(moveby1)
    array:addObject(moveby2)
    array:addObject(moveby3)
    array:addObject(moveby4)
    array:addObject(callfunc)
    local sequence = CCSequence:create(array)
    boxWidget:runAction(sequence)
	--]]
end
function __battleresultlayer.bindBoxListener(obj)
	 local function touchBegan(sender)
	    obj:egHideWidget(kImgStateBox)
		local pos =sender:getTouchStartPos()
		obj._touchBoxId = obj:getTouchedBoxID(pos)
		if obj._touchBoxId > 0 then
		    obj._unOpenBox[obj._touchBoxId]:setScale(1.1)
			--SoundHelper.playEffect(SoundList.click_shop_goods)
		end
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._touchBoxId > 0 then
			obj._openBox[obj._touchBoxId] = obj._unOpenBox[obj._touchBoxId]
			obj._unOpenBox[obj._touchBoxId]:setScale(1)
            obj:openBoxById(obj._touchBoxId)
			obj._touchBoxId = 0
		end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			if obj._touchBoxId > 0 then
				obj._unOpenBox[obj._touchBoxId]:setScale(1)
			end
			obj._touchBoxId = 0
		end
    end
    obj:egBindTouch(kBoxList,touchBegan,nil,touchEnded,touchCanceled)
end
--��������
function __battleresultlayer.showStars(obj,show)
    local function onAllStarShown()
		obj._allStarLoaded = true
    end
    if show then
        if battleProgress.stars==1 then
            obj:egShowWidget(kInner1)
            obj:bounceScaleWidget(kInner1,0.6,3,1,onAllStarShown)
        elseif battleProgress.stars==2 then
            local function showStar2()
                obj:egShowWidget(kInner2)
                 obj:bounceScaleWidget(kInner2,0.6,3,1,onAllStarShown)
            end
            obj:egShowWidget(kInner1)
            obj:bounceScaleWidget(kInner1,0.6,3,1,showStar2)
        elseif battleProgress.stars==3 then
            local function showStar3()
                obj:egShowWidget(kInner3)
                 obj:bounceScaleWidget(kInner3,0.6,3,1,onAllStarShown)
            end
            local function showStar2()
                obj:egShowWidget(kInner2)
                 obj:bounceScaleWidget(kInner2,0.6,3,1,showStar3)
            end
            obj:egShowWidget(kInner1)
            obj:bounceScaleWidget(kInner1,0.6,3,1,showStar2)
        else
            onAllStarShown()
        end
    else
        obj:egHideWidget(kInner1)
        obj:egHideWidget(kInner2)
        obj:egHideWidget(kInner3)
    end
end
--�������ݼ��ض�ʱ��
function __battleresultlayer.activeLoadTimer(obj)
    local cnt = 0
    local function callback(delta)
		cnt = cnt + delta
		if not AccountHelper:isLocked(kStateBpResult) and obj._allStarLoaded then
				obj:egUnbindWidgetUpdate(kLabelState)
				obj:updateTaskStatus()
				obj:showLoadPanel(false)
				obj:showInfoPanel(true)
				if (obj._d_data.btFlag == 0 or obj._d_data.btFlag == 4)  then
					RiskHelper.updateHeroHP(obj._d_data.oldheroList,account_data.heroList) --PVE���������Զ���������������
					if obj._d_data.battleBoxCnt > 0 then
						obj:egHideWidget(kBtnOk)
						obj:egHideWidget(kBtnJump)
						obj:showBoxPanel(true)
					else
						obj:egShowWidget(kBtnOk)
						obj:showJumpBtn()
					end
				else
					obj:egShowWidget(kBtnOk)
					obj:showJumpBtn()
				end
		elseif cnt >numDef.clientTimeOut then
				obj:egUnbindWidgetUpdate(kLabelState)
				postEventSignal(kEventRequestTimeOut)
		end
    end
    obj:egBindWidgetUpdate(kLabelState,callback)
end
--�����ھ���־�������
function __battleresultlayer.updateTaskStatus(obj)
	if obj._d_data.btFlag==0 then --PVE
		local tbParam = {}
		table.insert(tbParam,obj._d_data.sceneID)
		table.insert(tbParam,obj._d_data.stageid)
		table.insert(tbParam,BPResult.stars)
		if not MissionHelper.groupIdx then --PVE���̹ؿ�
			table.insert(tbParam,account_data.unlockedPVE[obj._d_data.sceneID].areaStars)
			task.updateTaskStatus(account_data,task.client_event_id.finished_PVE,tbParam)
		else --PVE�ճ��ؿ�
			task.updateTaskStatus(account_data,task.client_event_id.finished_day_PVE,tbParam)
		end
	elseif obj._d_data.btFlag == 1 then --PVP
		task.updateTaskStatus(account_data,task.client_event_id.finished_pvp,{BPResult.stars})
		task.updateTaskStatus(account_data,task.client_event_id.pvp_elo,{BPResult.elo})
	elseif obj._d_data.btFlag == 3 then --��������
		task.updateTaskStatus(account_data,task.client_event_id.finished_fpve,{obj._d_data.stageid,numDef.starsPerStage-BPResult.stars})
	elseif obj._d_data.btFlag == 4 then --Զ������
		task.updateTaskStatus(account_data,task.client_event_id.finished_farpve,{obj._d_data.stageid,BPResult.stars})
	end
end
--��ʾ���ݼ��ؽ���
function __battleresultlayer.showLoadPanel(obj,show)
    if show then
        obj:egShowWidget(kPanelLoad)
        --obj:activeItemAction()
        local imgWidget = obj:egGetWidgetByName(kImgLoading)
        local rotateby = CCRotateBy:create(1,360)
        local repeatforever = CCRepeatForever:create(rotateby)
        imgWidget:runAction(repeatforever) 
    else 
        obj:egHideWidget(kPanelLoad)
         local imgWidget = obj:egGetWidgetByName(kImgLoading)
         imgWidget:stopAllActions()
    end 
end

--��ʾ��������
function __battleresultlayer.showInfoPanel(obj,show)
    if show then
        obj:egShowWidget(kPanelInfo)
        obj:loadAward()
        obj:loadLvUpHeros()
    else
        obj:egHideWidget(kBtnOk)
		obj:egHideWidget(kBtnJump)
       -- obj:egHideWidget(kBtnClose)
    end
end
function __battleresultlayer.loadAward(obj)
	 local panel1 = obj:egGetWidgetByName(kPanelAward1)
	 local panel2 = obj:egGetWidgetByName(kPanelAward2)
	 local panel1size = panel1:getSize()
	 local panel2size = panel2:getSize()
	 local actW1 = 0
	 local actW2 = 0
	 local changeRow = false
	 if BPResult.elo then
		local eloAward = AwardItem.new("elo",Funs.signedNum(BPResult.elo))
		panel1:addChild(eloAward:egNode())
		actW1 = eloAward:egNode():getSize().width
	 end
	 if BPResult.honor then
		local honorAward = AwardItem.new("honor",Funs.signedNum(BPResult.honor))
		panel1:addChild(honorAward:egNode())
		actW1 = honorAward:egNode():getSize().width
	 end
	 for idx,coinname in pairs(KVariantList.coinType) do
        local coinval = BPResult[coinname] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
			local item_w = awarditem:egNode():getSize().width
			if not changeRow and actW1 + item_w <= panel1size.width then
				 actW1 = actW1 + item_w
				 panel1:addChild(awarditem:egNode())
			else
				changeRow = true
				actW2 = actW2 + item_w
				panel2:addChild(awarditem:egNode())
			end
        end
    end
	for heroid,msgnum in pairs(BPResult.heroInfo or {}) do
	    local heromsg = HeroMsg.new(heroid,msgnum)
		local item_w = heromsg:egNode():getSize().width
		if not changeRow and  actW1 + item_w <= panel1size.width then
			actW1 = actW1 + item_w
			panel1:addChild(heromsg:egNode())
		else
			changeRow = true
			actW2 = actW2 + item_w
			panel2:addChild(heromsg:egNode())
		end
	end
	if actW2 > 0 then
		panel1:setPosition(ccp(panel1:getPositionX() + (panel1size.width-actW1)/2,panel1:getPositionY()))
		panel2:setPosition(ccp(panel2:getPositionX() + (panel2size.width-actW2)/2,panel2:getPositionY()))
	else
		panel1:setPosition(ccp(panel1:getPositionX() + (panel1size.width-actW1)/2,panel1:getPositionY() - 30))
	end
end
--��ȡӢ�۾����б�
function __battleresultlayer.getHeroExpList(obj)
    local tb = {}
    if not BPResult.teamExp then BPResult.teamExp = {} end
    for idx,heroid in ipairs(obj._d_data.teamList) do
		tb[heroid] = BPResult.teamExp[idx] or 0
	end
	return tb
end
function __battleresultlayer.loadLvUpHeros(obj)
    local listView = obj:egGetListView(kListHero)
    local exptb = obj:getHeroExpList()
    local cnt = 0
    local lvMax = obj._d_data.digLv * numDef.unitLvFactor
    if obj._defMark then
        for idx,herodata in ipairs(obj._d_data.oldheroList) do
            local lvuphero = LvUpHero.new(Funs.copy(herodata),herodata.equipLv,exptb[herodata.type],lvMax,obj._d_data.type == 0)
            listView:pushBackCustomItem(lvuphero:egNode())
		    cnt = cnt + 1
        end
    else
        for idx,herodata in pairs(obj._d_data.oldheroList) do
            local lvuphero = LvUpHero.new(Funs.copy(herodata),obj._d_data.equipments[herodata.eid][1],exptb[herodata.type],lvMax,obj._d_data.type == 0)
            listView:pushBackCustomItem(lvuphero:egNode())
		    cnt = cnt + 1
        end
    end    
    local size = listView:getSize()
    local oldW = size.width
    local newW = kCellW * cnt
    if newW< oldW then 
        listView:setSize(CCSizeMake(newW,size.height)) 
        listView:setPosition(ccp(listView:getPositionX() + (oldW-newW)/2,listView:getPositionY()))
    end
end

function __battleresultlayer.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequence)
    else
        baseWidget:runAction(spawn)
    end
end
--����
function __battleresultlayer.bindNextListener(obj)
	local function  touchEnded(sender)
	    obj:egSetLabelStr(kLblTime,10)
	    obj:openBoxTimeUpdate()
		obj:egHideWidget(kBtnNext)
		 obj:egSetWidgetTouchEnabled(kBoxList,true) 
		local leftCnt = obj._d_data.battleBoxCnt - obj._openCnt
		local offsetX = kMaxNum*kBoxW
		if leftCnt < kMaxNum then
			offsetX = leftCnt*kBoxW
		end
		for key,boxitem in pairs(obj._unOpenBox) do
			local oldx = boxitem:getPositionX()
			local oldy = boxitem:getPositionY()
			boxitem:setPosition(ccp(oldx - offsetX,oldy))
		end
		for key,awarditem in pairs(obj._awardItems) do
			local oldx = awarditem:egGetPosX()
			local oldy = awarditem:egGetPosY()
			awarditem:egSetPosition(oldx - offsetX,oldy)
		end
	end
	 obj:egBindTouch(kBtnNext,nil,nil,touchEnded,nil)
end
--ȷ��
function __battleresultlayer.bindOkListener(obj)
    local function touchEnded(sender)
         obj:egSetWidgetTouchEnabled(kBtnOk,false)
		 SoundHelper.playEffect(SoundList.click_paper_close)
		local holelayer = AccountHelper:get(kHoleLayer)
		if holelayer then 
			holelayer:doCleanUp()
			graphicLoader.removeCreatureAnima()
			AccountHelper:bind(kDefLayer,nil)
			AccountHelper:bind(kAtkLayer,nil)
		end
		 if obj._d_data.btFlag == 0 and (not obj._backToTown) then
			local scene = MissionScene.new(obj._d_data.sceneID)
			scene:egReplace()
		 elseif obj._d_data.btFlag == 4 then
			local scene =ExMissionScene.new()
			scene:egReplace()
		elseif obj._d_data.btFlag == 6 then
			if club_data and club_data.warData then
				local scene = GvgMissionScene.new()
				scene:egReplace()
			else
				local scene = GuildScene.new()
				scene:egReplace()
			end
		elseif obj._d_data.btFlag == 7 then
			local scene = GuildScene.new()
			scene:egReplace()
		 else
			 local scene = TownScene.new()
			 scene:egReplace()
		 end
    end
     obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
--��ת��װ��ǿ������
function __battleresultlayer.bindJumpEquipListener(obj)
	 local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_paper_close)
        EquipScene.new():egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnJump,nil,nil,touchEnded,touchCanceled)
end
--��ת��������������
function __battleresultlayer.bindJumpMonsterListener(obj)
	 local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_paper_close)
        MonsterScene.new():egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnJump,nil,nil,touchEnded,touchCanceled)
end
--�ر�
function __battleresultlayer.bindCloseListener(obj)
    local function touchEnded(sender)
         obj:egSetWidgetTouchEnabled(kBtnClose,false)
		 SoundHelper.playEffect(SoundList.click_paper_close)
		 if obj._d_data.btFlag == 0 or obj._d_data.btFlag == 4 then
			 local totalBp = RiskHelper.getTotalBp()
			 if account_data.teamBp ~= totalBp then
				account_data.teamBp = totalBp
				SendMsg[934018](totalBp)
			 end
		 end
		local holelayer = AccountHelper:get(kHoleLayer)
		if holelayer then 
			holelayer:doCleanUp()
			graphicLoader.removeCreatureAnima()
			AccountHelper:bind(kDefLayer,nil)
			AccountHelper:bind(kAtkLayer,nil)
		end
         local scene = TownScene.new()
         scene:egReplace()
    end
     obj:egBindTouch(kBtnClose,nil,nil,touchEnded,nil)
end
function __battleresultlayer.setBackToTown(obj)
	obj._backToTown = true
end
BattleResultLayer={}
function BattleResultLayer.new(d_data,defMark)
    local obj = TouchWidget.new(JsonList.battleResult)
    table_aux.unpackTo(__battleresultlayer, obj)
    obj:init(d_data)
    obj._defMark = defMark
    obj:bindOkListener()
    return obj
end
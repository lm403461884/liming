local kBaseNum = 256
local kBehaviorDig = 0 --��Ϊ��ʶ �ھ�
local kBehaviorAtk = 1 --��Ϊ��ʶ ����
local kBehaviorDef = 2 --��Ϊ��ʶ ����
local kBehaviorVideo = 3 ----��Ϊ��ʶ ¼��
RiskHelper={}
--------------------------
--�ھ򳡾�����
--------------------------
function RiskHelper.getDigSceneData()
    enableExpandAI = false
	behaviorFlag = kBehaviorDig --��Ϊ��ʶ �ھ�
    local tb = {}
    local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
	tb.type = 1 --�ѷ�Ϊ������
	tb.isDefencer = true
	tb.showFlag = true
    tb.w = s_data.w
    tb.h = s_data.h
    tb.maxDigPt = account_data.maxDigPt
    tb.digVision = account_data.digVision --�ھ���Ұ
    tb.dfs = account_data.guid
	tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLv = account_data.sceneLv
    tb.digTrace = account_data.digTrace
    tb.mileSpread = account_data.mileSpread --�����ֲ�
    tb.collectorList = account_data.collectorList --�󳵷ֲ�
    tb.spread = s_data.spread
	tb.teamList = account_data.team
	tb.heroList = account_data.heroList
	tb.entraIdx = s_data.w/2
    if not tb.digTrace[tb.entraIdx] then
       tb.digTrace[tb.entraIdx] = 1
    end
    tb.creatureList = account_data.creatureList
    tb.monsterLvLook = account_data.monsterLvLook
    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/iceberg_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    tb.mineOutRange = RiskHelper.getMineOutOfDigTrance(tb) --��ȡ�ھ����������ʾ�Ŀ�
    return tb
end

--------------------------
--��ȡ������������
--------------------------
function RiskHelper.getAtkSceneData(areaid,stageid)
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
    local stagedata = pveQuery.queryStage(areaid,stageid)
    local tb = {}
    tb.type = 0 --�ѷ�Ϊ������
	tb.btFlag = 0
    tb.digVision = account_data.digVision
	tb.digLv = account_data.digLv
	tb.isDefencer = false
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
    tb.dfs = 0
    tb.dfsName = TxtList.pveDefName
    tb.areaid = areaid
    tb.stageid = stageid
    tb.sceneID = areaid
    tb.sceneLv = stageid
	tb.battleBox = {[1]={},[2]={},[3]={}}
	tb.battleBoxCnt = 0
	tb.consume = account_data.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.areaid,tb.stageid,tb.dfsName,tb.consume ) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ������ߣ��ڽ��յ�ս���ط����ݺ�ָ� 394001
    tb.w = stagedata.w
    tb.h = stagedata.h
    tb.digTrace = Funs.copy(stagedata.digTrace)
    tb.mileSpread = {}
	tb.boxList = stagedata.boxList
    tb.collectorList = stagedata.collectorList --�󳵷ֲ�
    tb.spread = stagedata.spread
	tb.bossCnt = stagedata.bossCnt
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(stagedata.creatureList)
	--�ճ����������ִ�յȼ���������ȼ�
	if MissionHelper.groupIdx then
		tb.monsterLvLook =  baseCalc.getMonsterLv(tb.areaid*100 + tb.stageid,tb.digLv, stagedata.monsterLvLook)
	else --��ͨ����ֱ�Ӷ�����
		tb.monsterLvLook = Funs.copy(stagedata.monsterLvLook)
	end
	tb.heroList = {}
	tb.teamList = account_data.team
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.heroList[heroid].hp= hero_data.getData(heroid, tb.heroList[heroid].lv, "maxHP")
		tb.heroList[heroid].power = numDef.originalPower
		tb.heroList[heroid].ignoreEquip = false
	end
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag

    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ����ս������(pvp)
--------------------------
function RiskHelper.getDefPvpSceneData(pidIdx)
    enableExpandAI = true
	behaviorFlag = kBehaviorDef --��Ϊ��ʶ ����

	local tb = {}
    tb.stageid = pidIdx
    local stagedata = DefTaskHelper.getTeam(pidIdx)

	local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
    tb.type = 1  --�ѷ�Ϊ������
    tb.btFlag = 3
    tb.digVision = account_data.digVision
	tb.isDefencer = true
    tb.atk = 0
    tb.digLv = account_data.digLv
    tb.atkName = stagedata.name
    tb.dfs = account_data.guid
    tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLV = account_data.sceneLV
	tb.consume = stagedata.consume
	tb.tid = stagedata.tid
	tb.bp = stagedata.bp

	RiskHelper.initBP(tb.type,tb.btFlag, tb.sceneID,tb.stageid,tb.dfsName,tb.consume)

    tb.w = s_data.w
    tb.h = s_data.h
	tb.entraIdx =  s_data.w/2
    tb.digTrace = Funs.copy(account_data.digTrace)
    tb.mileSpread = Funs.copy(account_data.mileSpread)
    tb.collectorList =  Funs.copy(account_data.collectorList)
	for idx,prop in ipairs(tb.collectorList) do
		 tb.mileSpread[prop.pos] = nil
		 tb.digTrace[prop.pos] = 1
	end
	tb.creatureList = Funs.copy(account_data.creatureList)
    tb.monsterLvLook = Funs.copy(account_data.monsterLvLook)
    tb.spread = s_data.spread

    tb.heroList = Funs.copy(stagedata.heroList)
    for idx,hero in pairs (tb.heroList) do
        hero.hp = hero_data.getData(hero.type,hero.lv,"maxHP")
		hero.power = numDef.originalPower
		hero.ignoreEquip = false
    end
    tb.teamList = Funs.copy(stagedata.team)
    --tb.equipments = Funs.copy(stagedata.equipments)
	tb.awardRes = {}
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end

--------------------------
--��ȡ����ս������(pve)
--------------------------
function RiskHelper.getDefSceneData(guardid)
    enableExpandAI = true
	behaviorFlag = kBehaviorDef --��Ϊ��ʶ ����
	local tb = {}

	tb.stageid = guardid
    local stagedata = pveGuardQuery.getName(tb.stageid)
	local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
    tb.type = 1  --�ѷ�Ϊ������
    tb.btFlag = 3
    tb.digVision = account_data.digVision
	tb.isDefencer = true
    tb.atk = 0
    tb.digLv = account_data.digLv
    tb.atkName = TxtList.pveAtkName
    tb.dfs = account_data.guid
    tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLV = account_data.sceneLV
	tb.consume = stagedata.consume

	RiskHelper.initBP(tb.type,tb.btFlag, tb.sceneID,tb.stageid,tb.dfsName,tb.consume)

    tb.w = s_data.w
    tb.h = s_data.h
	tb.entraIdx =  s_data.w/2
    tb.digTrace = Funs.copy(account_data.digTrace)
    tb.mileSpread = Funs.copy(account_data.mileSpread)
    tb.collectorList =  Funs.copy(account_data.collectorList)
	for idx,prop in ipairs(tb.collectorList) do
		 tb.mileSpread[prop.pos] = nil
		 tb.digTrace[prop.pos] = 1
	end
	tb.creatureList = Funs.copy(account_data.creatureList)
    tb.monsterLvLook = Funs.copy(account_data.monsterLvLook)
    tb.spread = s_data.spread

    tb.heroList = Funs.copy(stagedata.heroList)
    for idx,hero in pairs (tb.heroList) do
        hero.hp = hero_data.getData(hero.type,hero.lv,"maxHP")
		hero.power = numDef.originalPower
		hero.ignoreEquip = false
    end
    tb.teamList = Funs.copy(stagedata.team)
    
    tb.equipments = Funs.copy(stagedata.equipments)

    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ��ս��������
--------------------------
function RiskHelper.getPvpSceneData()
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
    local tb = {}
    tb.type = 0 --�ѷ�Ϊ������
	tb.btFlag = 1
    tb.digVision = account_data.digVision
	tb.isDefencer = false
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
	tb.digLv = account_data.digLv
    tb.dfs = pvpaccount_data.guid
	tb.dfsName = pvpaccount_data.user
    tb.sceneID = pvpaccount_data.sceneID
    tb.sceneLv = pvpaccount_data.sceneLv
	tb.consume = account_data.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName,tb.consume) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ�������,�ڽ��յ�ս���ط����ݺ�ָ� 395004
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(pvpaccount_data.digTrace)
    tb.mileSpread = Funs.copy(pvpaccount_data.mileSpread)
    tb.collectorList = Funs.copy(pvpaccount_data.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(pvpaccount_data.creatureList)
    tb.monsterLvLook = Funs.copy(pvpaccount_data.monsterLvLook)
    tb.teamList = account_data.team
	tb.heroList = {}
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.heroList[heroid].hp= hero_data.getData(heroid, tb.heroList[heroid].lv, "maxHP")
		tb.heroList[heroid].power = numDef.originalPower
		tb.heroList[heroid].ignoreEquip = false
	end
	tb.equipments = account_data.equipments
    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/grasslands_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ¼�񳡾�����
--------------------------
function RiskHelper.getVideoSceneData()
	 enableExpandAI = true
	 behaviorFlag = kBehaviorVideo --��Ϊ��ʶ ¼��
     local tb = {}
	 tb.videoStart = VideoDetail.atk.startTime
     tb.type = 0 --�ѷ�Ϊ������
	 tb.btFlag = VideoDetail.flag --2����PVP¼��7����ս¼��
     tb.old_acct = VideoDetail.atk
	 tb.isDefencer = VideoDetail.isDefencer
     if VideoDetail.isDefencer then
        tb.type = 1 --�ѷ�Ϊ������
        tb.old_acct = VideoDetail.def
    end
    tb.digVision = VideoDetail.atk.digVision or 2
    tb.atk = VideoDetail.atk.guid
	tb.atkName = VideoDetail.atk.userName
	tb.digLv = VideoDetail.atk.digLv or 1
    tb.dfs = VideoDetail.def.guid
	tb.dfsName = VideoDetail.def.userName
    tb.sceneID = VideoDetail.def.sceneID
    tb.sceneLv = VideoDetail.def.sceneLv
    tb.frameCnt = VideoDetail.atk.frameCnt
	tb.consume = VideoDetail.atk.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName,tb.consume) --��ʼ��ս������
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(VideoDetail.def.digTrace)
    tb.mileSpread =  Funs.copy(VideoDetail.def.mileSpread)
    tb.collectorList = Funs.copy(VideoDetail.def.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(VideoDetail.def.creatureList)
    tb.monsterLvLook = Funs.copy(VideoDetail.def.monsterLvLook)
    tb.heroList = VideoDetail.atk.heroList
	for idx,hero in pairs(tb.heroList) do
        hero.hp = hero_data.getData(hero.type, hero.lv, "maxHP")
		hero.power = numDef.originalPower
		hero.ignoreEquip = false
    end
    tb.teamList = Funs.copy(VideoDetail.atk.team )
	tb.equipments = VideoDetail.atk.equipments
    tb.teamBag = Funs.copy(VideoDetail.atk.teamBag)

    tb.itemFrame = Funs.copy(VideoDetail.atk.itemUsageFrame) or {} --ʹ��ʱ��
	tb.itemPos = Funs.copy(VideoDetail.atk.itemUsagePos) or {}--ʹ��λ��
    tb.heroEnterFrame = Funs.copy(VideoDetail.atk.heroEnterFrame) or {}
	tb.heroCreatedFrame = Funs.copy(VideoDetail.atk.heroCreatedFrame) or {}
	tb.skillFrame = Funs.copy(VideoDetail.atk.skillUsageFrame) or {}
    tb.bag = {}
    for itemid,usetb in pairs(tb.itemFrame) do
        tb.bag [itemid] = #usetb
    end
    --ս����ʧ��Ϣ�����������ʾ
	tb.atk_elo = VideoDetail.atk_elo
	tb.def_elo = VideoDetail.def_elo
	for idx,coinname in pairs(KVariantList.coinType) do
		local atkparam = string.format("atk_%s",coinname)
		local defparam = string.format("def_%s",coinname)
		tb[atkparam] = VideoDetail[atkparam]
		tb[defparam] = VideoDetail[defparam]
	end
    tb.stars = VideoDetail.stars
    ----------------------
    tb.headImg = scene_data[tb.sceneID].sub_img
    tb.entraImg =scene_data[tb.sceneID].enter_img
    tb.earthImg = EarthImages[tb.sceneID]
    return tb

end
--------------------------
--��ȡԶ����������
--------------------------
function RiskHelper.getExPveSceneData(stageid)
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
    local stagedata = farpveQuery.queryStage(stageid)
    local tb = {}
    tb.type = 0 --�ѷ�Ϊ������
	tb.btFlag = 4
    tb.digVision = account_data.digVision
	tb.digLv = account_data.digLv
	tb.isDefencer = false
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
    tb.dfs = 0
    tb.dfsName = TxtList.pveDefName
    tb.areaid = stagedata.areaid
    tb.stageid = stageid
    tb.sceneID = tb.areaid
    tb.sceneLv = stageid
	tb.battleBox = {[1]={},[2]={},[3]={}}
	tb.battleBoxCnt = 0
	tb.bossCnt = stagedata.bossCnt
	tb.consume = account_data.consume
	tb.awardRes=RiskHelper.getExpeditionAwardRes(tb.stageid)
    RiskHelper.initBP(tb.type,tb.btFlag,tb.areaid,tb.stageid,tb.dfsName,tb.consume ) --��ʼ��ս������
    tb.w = stagedata.w
    tb.h = stagedata.h
    tb.digTrace = Funs.copy(stagedata.digTrace)
    tb.mileSpread = {}
	tb.boxList = stagedata.boxList
    tb.collectorList = stagedata.collectorList --�󳵷ֲ�
    tb.spread = stagedata.spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(account_data.exMission.creatureList)
	--����ִ�յȼ���������ȼ�

	tb.monsterLvLook =  baseCalc.fargetMonsterLv(tb.stageid,tb.digLv, stagedata.monsterLvLook)
	tb.teamList = account_data.exMission.team
	tb.heroList = {}
	tb.totalLv = 0
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.totalLv = tb.totalLv + tb.heroList[heroid].lv
		tb.heroList[heroid].hp,tb.heroList[heroid].power =  RiskHelper.getHPPower(account_data.expedition[heroid])
		tb.heroList[heroid].ignoreEquip = true
	end
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag
    tb.entraImg =scene_data[tb.sceneID].enter_img
    tb.earthImg = EarthImages[tb.sceneID]
	
    return tb
end

--------------------------
--��ȡ����������������
--------------------------
function RiskHelper.getGAtkSceneData()
    enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
    local tb = {}
    tb.type = 0 --�ѷ�Ϊ������
	tb.btFlag = 5
    tb.digVision = account_data.digVision
	tb.digLv = account_data.digLv
	tb.isDefencer = false
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
    tb.dfs = 0
    tb.dfsName = TxtList.pveDefName
	tb.areaid = gscene_data.sceneID
    tb.sceneID = gscene_data.sceneID
    tb.sceneLv = gscene_data.sceneLv
	tb.battleBox = {[1]={},[2]={},[3]={}}
	tb.battleBoxCnt = 0
	tb.consume = gscene_data.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.areaid,tb.stageid,tb.dfsName,tb.consume ) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ������ߣ��ڽ��յ�ս���ط����ݺ�ָ� 394001
    tb.w = gscene_data.w
    tb.h = gscene_data.h
    tb.digTrace = Funs.copy(gscene_data.digTrace)
    tb.mileSpread = {}
	tb.boxList = gscene_data.boxList
    tb.collectorList = gscene_data.collectorList --�󳵷ֲ�
    tb.spread = gscene_data.spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(gscene_data.creatureList)
	tb.monsterLvLook = Funs.copy(gscene_data.monsterLvLook)
	tb.heroList = {}
	tb.teamList = gscene_data.team
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = gscene_data.heroList[heroid]
		tb.heroList[heroid].hp= hero_data.getData(heroid, tb.heroList[heroid].lv, "maxHP")
		tb.heroList[heroid].power = numDef.originalPower
		tb.heroList[heroid].ignoreEquip = false
	end
	tb.equipments = gscene_data.equipments
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--��ȡ�ֲ������ھ�������Ŀ�
function RiskHelper.getMineOutOfDigTrance(d_data)
    local openedView = Funs.getIdxInVision(d_data.digTrace,d_data.w,d_data.h,d_data.digVision,nil)--�ھ���Ұ
    local mineView =  Funs.getIdxInVision(d_data.entraIdx,d_data.w,d_data.h,d_data.maxDigPt,nil)--������Ұ
    local cnt = baseCalc.getVisibleMineCnt() --��ʾ����
    local tb = {}
    for idx,item in pairs(d_data.mileSpread) do
        if #tb>= cnt then return tb end
        if not openedView[idx] then
            if mineView[idx] and not d_data.digTrace[idx] then
                table.insert(tb,idx)
            end
        end
    end
    return tb
end

--------------------------
--��ȡ����ս��ս��������
--------------------------
function RiskHelper.getClubPvpSceneData()
	 enableExpandAI = true
	behaviorFlag = kBehaviorAtk --��Ϊ��ʶ ����
    local tb = {}
    tb.type = 0 --�ѷ�Ϊ������
	tb.btFlag = 6
    tb.digVision = account_data.digVision
	tb.isDefencer = false
	if club_data and club_data.warData and club_data.warData.expire > os.time() then
		tb.clubInWar = true
	else
		tb.clubInWar = false
	end
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
	tb.digLv = account_data.digLv
    tb.dfs = clubpvpacct_data.guid
	tb.dfsName = clubpvpacct_data.user
	tb.defencer = club_data.defClub.targets[tb.dfs]
    tb.sceneID = clubpvpacct_data.sceneID
    tb.sceneLv = clubpvpacct_data.sceneLv
	tb.consume = account_data.consume
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName,tb.consume) --��ʼ��ս������
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(clubpvpacct_data.digTrace)
    tb.mileSpread = Funs.copy(clubpvpacct_data.mileSpread)
    tb.collectorList = Funs.copy(clubpvpacct_data.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(clubpvpacct_data.creatureList)
    tb.monsterLvLook = Funs.copy(clubpvpacct_data.monsterLvLook)
    tb.teamList = account_data.team
	tb.heroList = {}
	for key,heroid in ipairs(tb.teamList) do
		tb.heroList[heroid] = account_data.heroList[heroid]
		tb.heroList[heroid].hp= hero_data.getData(heroid, tb.heroList[heroid].lv, "maxHP")
		tb.heroList[heroid].power = numDef.originalPower
		tb.heroList[heroid].ignoreEquip = false
	end
	tb.equipments = account_data.equipments
    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/grasslands_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png"
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--------------------------
--��ȡ����pvp�����б�
--------------------------
function RiskHelper.getDefPvpAwardRes(d_data,bp,stars)
    local tb = {}
    local reward = {}
    reward.gold,reward.iron,reward.copper,reward.stoneR,reward.stoneB,reward.stoneD = uniteTeamCalc.UTDefprize(d_data,bp,stars)
    for name,val in pairs(reward) do 
        if val > 0 then
            tb[name]=val
        end
    end
    return tb
end
----------------------------
--��ȡԶ������������б�
--------------------------
function RiskHelper.getExpeditionAwardRes(stageid)
    local tb={}
    local awarddata = farpveCalc.getAwardRes(account_data,stageid)
    if awarddata then
        for key,val in pairs(awarddata) do
            tb[key] = val
        end
    end
    return tb
end
--------------------------
--��ȡӢ�۶���
--------------------------
function RiskHelper.getHeroObj(heroid,heroObjs)
    if heroObjs then
        for _, hero in pairs(heroObjs) do
            if hero:getprop("type")== heroid then
                return hero
            end
        end
    end
   -- print("can not find HeroObj from heroObjs with heroid:",heroid)
    return nil
end
--��ȡԶ���ӳ�Ա����
function RiskHelper.getExTeamCnt()
    if not account_data.expedition then return 0 end
	local cnt = 0
	for key,val in pairs(account_data.expedition) do
		cnt = cnt+1
	end
	return cnt
end
--��ȡӢ������
function RiskHelper.getHeroCnt()
	local cnt = 0
	for key,val in pairs(account_data.heroList) do
		cnt = cnt+1
	end
	return cnt
end
--��ȡӢ��Ѫ����ŭ��ֵ
function RiskHelper.getHPPower(hpPower)
	if not hpPower then 
		print("Invalid expedition val")
		return 0,0 
	end
	local hp =math.floor(hpPower/kBaseNum)
	local power = math.min(hpPower%kBaseNum,100)
	return hp,power
end
--����Ӣ��Ѫ����ŭ��ֵ��Ӧ������
function RiskHelper.calHPPower(hp,Power)
	return hp*kBaseNum + Power
end

--------------------------
--��ȡӢ�۶�������ֵ
--------------------------
function RiskHelper.getHeroConsume(heroid,herolist)
    local hero = herolist[heroid]
    local s_data = hero_data.get(hero.type,hero.lv)
    return s_data.consume
end
--------------------------
--�жϿ����Ƿ���ھ�
--------------------------
function RiskHelper.isRemovable(idx,digTrace,w,h)
    if idx > 0 and digTrace[idx] then return false end
    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  digTrace[idx_l] then  return true end--����������ھ�
    return false
end
function RiskHelper.getHeroExpAndLv(gainExp,digLv,heroprop)
	if not gainExp or gainExp == 0 then return heroprop.exp,heroprop.lv end
	local lvMax = digLv * numDef.unitLvFactor
	local heroid = heroprop.type
	local curExp = heroprop.exp
	local curLv = heroprop.lv
	local dataAtNextLv = hero_data.get(heroid,curLv + 1)
	local expChange = {}
	while curExp <= gainExp and (curLv + 1) <= lvMax and dataAtNextLv  do
		local from = (dataAtNextLv.exp - curExp)*100/dataAtNextLv.exp
		local to = 100
        gainExp = gainExp - curExp
        curLv = curLv + 1
        curExp = dataAtNextLv.exp
        dataAtNextLv = hero_data.get(heroid,curLv + 1)
		table.insert(expChange,from)
		table.insert(expChange,to)
    end
    if dataAtNextLv and curExp > gainExp and (curLv + 1) <= lvMax then
		local from = (dataAtNextLv.exp - curExp)*100/dataAtNextLv.exp
        curExp = curExp - gainExp
		local to = (dataAtNextLv.exp - curExp)*100/dataAtNextLv.exp
		table.insert(expChange,from)
		table.insert(expChange,to)
    end
	return curExp,curLv,expChange
end
--����Ӣ�۾���͵ȼ�
function RiskHelper.updateHeroExp(gainExp,btFlag,heroteam)
	if not gainExp or #gainExp==0 then return end
	local heroexp = {}
	local lvMax = account_data.digLv * numDef.unitLvFactor
	local teamList = account_data.team
	if btFlag == 4 then   teamList = account_data.exMission.team end
	if btFlag == 5 then   teamList = heroteam end --̽�ն�Ӣ������
	for idx,heroid in ipairs(teamList) do
	    local expval = gainExp[idx] or 0
		local heroprop = account_data.heroList[heroid]
		 if expval > 0 then
	        local dataAtNextLv = hero_data.get(heroprop.type,heroprop.lv + 1)
	        while heroprop.exp <= expval and (heroprop.lv + 1) <= lvMax and dataAtNextLv  do
                expval = expval - heroprop.exp
                heroprop.lv = heroprop.lv + 1
                heroprop.exp = dataAtNextLv.exp
                dataAtNextLv = hero_data.get(heroprop.type,heroprop.lv + 1)
            end
            if dataAtNextLv and heroprop.exp > expval and (heroprop.lv + 1) <= lvMax then
                heroprop.exp = heroprop.exp - expval
            end
	    end
	end
end
function RiskHelper.updateHeroHP(oldHeroList,heroList)
	if not account_data.expedition then return end
	for heroid,heroprop in pairs(oldHeroList) do
		if heroList[heroid].lv > heroprop.lv and account_data.expedition[heroid] then
			local hp,power = RiskHelper.getHPPower( account_data.expedition[heroid])
			if hp > 0 then
				local oldMaxHP= hero_data.getData(heroid,heroprop.lv,"maxHP")
				local curMaxHP =  hero_data.getData(heroid,heroList[heroid].lv,"maxHP")
				hp = hp + math.max(curMaxHP-oldMaxHP,0)
				account_data.expedition[heroid] = RiskHelper.calHPPower(hp,power)
			end
		end
	end
end
--��ȡ����Ӣ��ս�����ܺ�
function RiskHelper.getTotalBp()
	local totalBp = 0
	for heorid,heroprop in pairs(account_data.heroList) do
        totalBp = totalBp + RiskHelper.getHeroBp(heroprop,account_data)
	end
	return totalBp
end
--��ȡӢ�۵�ս����
function RiskHelper.getHeroBp(heroprop,acct)
	local equiplv,equipqa =  equipFuncs.getEquipQL(heroprop.eid,acct)
    local sub1_id,sub1_lv,sub1_seed,sub1_qa = Funs.deComposeInt(heroprop.eid_s1,256,4)
	local sub2_id,sub2_lv,sub2_seed,sub2_qa = Funs.deComposeInt(heroprop.eid_s2,256,4)
    local heroBp = baseCalc.getBattlePoint(heroprop.lv,heroprop.grade,equiplv,equipqa,sub1_lv,sub1_qa,sub2_lv,sub2_qa)
	return heroBp
end
--��ȡ�����ʻ��е�С��Ӣ��ս�����ܺ�
function RiskHelper.getTeamBp()
	local teamAtk = 0
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk +  RiskHelper.getHeroBp( account_data.heroList[heroid],account_data)
    end
    return teamAtk
end
function RiskHelper.getBpOfHeros(heroList,equipments)
	local totalBp = 0
	for heroid,heroprop in pairs(heroList) do
		 local sub1_id,sub1_lv,sub1_seed,sub1_qa = Funs.deComposeInt(heroprop.eid_s1,256,4)
		 local sub2_id,sub2_lv,sub2_seed,sub2_qa = Funs.deComposeInt(heroprop.eid_s2,256,4)
		 local equiplv,equipqa = equipments[heroprop.eid][1],equipments[heroprop.eid][2]
		 local heroGrade = heroprop.grade or 0
		 local heroBp = baseCalc.getBattlePoint(heroprop.lv,heroGrade,equiplv,equipqa,sub1_lv,sub1_qa,sub2_lv,sub2_qa)
		 totalBp = totalBp + heroBp
	end
	return totalBp
end
function RiskHelper.getHeroMaxHpWithEquip(heroprop,equipinfo)
	local equiplv = equipinfo[1]
	local equipqa =  equipinfo[2]
	local equiprop = equipFuncs.getData(heroprop.eid,equiplv)
	local sub1_id,sub1_lv,sub1_seed,sub1_qa = Funs.deComposeInt(heroprop.eid_s1,256,4)
	local sub2_id,sub2_lv,sub2_seed,sub2_qa = Funs.deComposeInt(heroprop.eid_s2,256,4)
	local s_data = hero_data.get(heroprop.type,heroprop.lv)	
	
	local maxHP = s_data.maxHP+equiprop.maxHP

	if sub1_id > 0 then
		local subprop = equipFuncs.getSubEquip(sub1_id,sub1_lv)
		maxHP = maxHP + (subprop.maxHP or 0)
	end
	if sub2_id > 0 then
		local subprop = equipFuncs.getSubEquip(sub2_id,sub2_lv)
		maxHP = maxHP + (subprop.maxHP or 0)
	end
	return maxHP
end
--��ȡ�����ӳɺ��Ӣ������ֵ
function RiskHelper.getHeroPropWithEquip(heroprop,equiplv)
	local equiprop = equipFuncs.getData(heroprop.eid,equiplv)
	local addCritical,addDodge = baseCalc.promotionLvAtt(heroprop.grade or 0)
	local sub1_id,sub1_lv,sub1_seed,sub1_qa = Funs.deComposeInt(heroprop.eid_s1,256,4)
	local sub2_id,sub2_lv,sub2_seed,sub2_qa = Funs.deComposeInt(heroprop.eid_s2,256,4)
	local s_data = hero_data.get(heroprop.type,heroprop.lv)	
	
	local maxHP = s_data.maxHP+equiprop.maxHP
	local power = s_data.power + equiprop.power
      local critical = (s_data.critical or 0)+ (equiprop.critical or 0) + addCritical
	local dodge = (s_data.dodge or 0)+ (equiprop.dodge or 0) + addDodge
	if sub1_id > 0 then
		local subprop = equipFuncs.getSubEquip(sub1_id,sub1_lv)
		maxHP = maxHP + (subprop.maxHP or 0)
		power =  power + (subprop.power or 0)
		critical = critical + (subprop.critical or 0)
		dodge =dodge+ (subprop.dodge or 0)
	end
	if sub2_id > 0 then
		local subprop = equipFuncs.getSubEquip(sub2_id,sub2_lv)
		maxHP = maxHP + (subprop.maxHP or 0)
		power =  power + (subprop.power or 0)
		critical = critical + (subprop.critical or 0)
		dodge =dodge+ (subprop.dodge or 0)
	end
	return maxHP,power,critical,dodge
end
--��ʼ��ս������
function RiskHelper.initBP(mtype,btFlag,areaid,stageid,defUser,consume)
    battleAIData = {}
    battleProgress ={}
	battleProgress.user = defUser
    battleProgress.type = mtype
    battleProgress.btFlag = btFlag
    battleProgress.startTime = os.time()
	battleProgress.consume = consume
    battleProgress.areaID = areaid
    battleProgress.stageID = stageid
    battleProgress.heroDamage = {} --heroDamage={[heroid]={damage1,time1,damage2,time2...}}
    battleProgress.monsterDeath = {}
	battleProgress.heroHpPower={}--heroHpPower={heroid1,hp*256+power,...}
    battleProgress.gold = {}  --gold = {pos,pos2...} --posΪ����collectorList��������λ��
    battleProgress.oil = {}   --oil = {pos,pos2...}
	battleProgress.collector={}--collector={idx1,idx2...}idxΪ����collectorList��������λ��
    --battleProgress.itemUsage = {} --itemUsage = {[itemid]={time1,time2,...}}
    battleProgress.itemUsageFrame = {}--itemUsageFrame = {[itemid]={framid1,frameid2,...}}
	battleProgress.itemUsagePos = {}--itemUsagePos = {[itemid]={idx1,idx2,...}} --����ʹ��λ��
    battleProgress.heroEnterFrame = {} --heroEnterFrame={heroid,framid,}
    battleProgress.heroCreatedFrame = {} --heroCreatedFrame={heroid,framid,} --Ӣ��AI������
	battleProgress.skillUsageFrame = {} --skillUsageFrame={[heroid]={framid1,..frameidn},} --Ӣ�ۼ���ʹ��֡
    battleProgress.stars = 0
    battleProgress.frameCnt = 0
	battleProgress.gainRes = {} --gainRes={gold=0,stoneR = 0,...}
	battleProgress.gainHeroMsg={} --gainHeroMsg={[heroid] = msgNum,...}Ӣ��ID����õ���Ϣ��
	battleProgress.gainEquip={} --gainEquip={{subid,sublv,subqa},...}װ��ID,�ȼ���Ʒ��
end

local kImgLv = "img_lv"
local kLblUpNote = "lbl_up_note"
local kLabelLv = "lbl_lv_val"
local kImgHero = "img_hero"
local kLblHp = "hp_txt"
local kBarHp = "hp_bar"
local kBarExp = "exp_bar"
local kBgExp = "exp_bg"
local kBgHp = "hp_bg"
local kImgKill = "img_killed"
local kLblExpMax = "lbl_max_exp"
local kLblAddExp = "lbl_add_exp"
local kGreenColor = ccc3(0,255,0)
local kRedColor = ccc3(255,0,0)
local __lvuphero = {}
function __lvuphero.init(obj,herodata,equiplv,gainexp,maxlv,isatk)
    obj._heroid = herodata.type
	obj._oldLV = herodata.lv
	obj._herodata = herodata
	obj._gainexp = gainexp
	obj._isatk = isatk
    local s_cfg = hero_data.getConfig(obj._heroid)
    obj:egChangeImg(kImgHero,s_cfg.headPic,UI_TEX_TYPE_PLIST)
    obj:showKillImg(herodata,isatk)
    obj:egSetBMLabelStr(kLabelLv,obj._oldLV)
    obj:egSetBarPercent(kBarExp,0)
    obj:egSetBarPercent(kBarHp,0)
    obj:egHideWidget(kLblExpMax)
	obj:egHideWidget(kLblAddExp)
	obj:egHideWidget(kLblUpNote)
    if herodata.exp then
        local dataAtNextLv = hero_data.get(herodata.type,herodata.lv + 1)
        if gainexp > 0 then
            while herodata.exp <= gainexp and (herodata.lv + 1) <= maxlv and dataAtNextLv  do
                gainexp = gainexp - herodata.exp
                herodata.lv = herodata.lv + 1
                herodata.exp = dataAtNextLv.exp
                dataAtNextLv = hero_data.get(herodata.type,herodata.lv + 1)
            end
            if dataAtNextLv and herodata.exp > gainexp and (herodata.lv + 1) <= maxlv then
                herodata.exp = herodata.exp - gainexp
            end
			 if  dataAtNextLv and (herodata.lv + 1) <= maxlv then
				 local cur_data = hero_data.get(herodata.type,herodata.lv)
				 local to = 100-herodata.exp*100/cur_data.exp
				obj:runExpProgress(0,to,false)
			 elseif obj._oldLV == maxlv then
			     obj:runExpProgress(0,0,true)
			 else
				 obj:runExpProgress(0,100,true)
			 end
		elseif gainexp==0 and obj._oldLV == maxlv then --������ǰ��ߵȼ�
             --obj:runExpProgress(0,0,true) 
             obj:egSetBarPercent(kBarExp,0)	
             obj:egShowWidget(kLblExpMax) 
		else
			local cur_data = hero_data.get(obj._heroid,obj._oldLV)
			obj:egSetBarPercent(kBarExp,100-herodata.exp*100/cur_data.exp)
        end
     end
   if not equiplv and not isatk then
       obj:egHideWidget(kBgHp)
       obj:egHideWidget(kLblHp)
       obj:showLvChangeWithAction()
   else
       obj:showHpWithAction(herodata,equiplv)
       obj:showLvChangeWithAction()
   end    
end
function __lvuphero.showKillImg(obj,herodata,isatk)
	 obj:egHideWidget(kImgKill)
    if isatk then
        obj:egSetWidgetColor(kBarHp,kGreenColor)
        obj:egChangeImg(kImgLv,ImageList.risk_lv_green,UI_TEX_TYPE_PLIST)
    else
        obj:egSetWidgetColor(kBarHp,kRedColor)
        obj:egChangeImg(kImgLv,ImageList.risk_lv_red,UI_TEX_TYPE_PLIST)
		if herodata.curhp == 0 then
			obj:egShowWidget(kImgKill)
			local widget = obj:egGetWidgetByName(kImgKill)
			widget:setScale(2)
			local scaleto = CCScaleTo:create(0.5,1)
			local backout = CCEaseBackOut:create(scaleto)
			widget:runAction(backout)
		end
    end
end
function __lvuphero.runExpProgress(obj,from,to,reachMax)
    local function callbackFunc()
        from = from + 1
        if from >= to then 
            from = to 
            obj:egUnbindWidgetUpdate(kBarExp)
            if reachMax then 
				obj:egShowWidget(kLblExpMax)
			end
			if reachMax and from == 100 then from = 0 end--�ﵽmaxlv�󣬾���ֵΪ0
			obj:showAddExpWithAction() 
        end
        obj:egSetBarPercent(kBarExp,from)
    end
    obj:egBindWidgetUpdate(kBarExp,callbackFunc)
end
function __lvuphero.showAddExpWithAction(obj)
	obj:egShowWidget(kLblAddExp)
	obj:egSetBMLabelStr(kLblAddExp,Funs.signedNum(obj._gainexp))
	local widget = obj:egGetWidgetByName(kLblAddExp)
	local delay = CCDelayTime:create(1.5)
	local moveby = CCMoveBy:create(0.5,ccp(0,100))
	local fadeout = CCFadeOut:create(0.5)
	local spawn = CCSpawn:createWithTwoActions(moveby,fadeout)
	local array = CCArray:create()
	--local callfunc = CCCallFunc:create(function()  end)
	array:addObject(delay)
	array:addObject(spawn)
	--array:addObject(callfunc)
	local sequence = CCSequence:create(array)
	widget:runAction(sequence)
end
function __lvuphero.showLvChangeWithAction(obj)
	if obj._herodata.lv <= obj._oldLV then return end
	--挖掘日志任务更新
	task.updateTaskStatus(account_data,task.client_event_id.hero_levelup,{obj._heroid,obj._herodata.lv})
	----------------------------------------------------------
	SoundHelper.playEffect(SoundList.up_level)
	obj:egSetBMLabelStr(kLabelLv,obj._herodata.lv)
	local widget = obj:egGetWidgetByName(kImgLv)
	widget:setScale(5)
	local scaleto = CCScaleTo:create(0.3,1)
	local callfunc = CCCallFunc:create(function() obj:egShowWidget(kLblUpNote) end)
	local sequence = CCSequence:createWithTwoActions(scaleto,callfunc)
	widget:runAction(sequence)
end
function __lvuphero.showHpWithAction(obj,herodata,equiplv)
	local maxHP = RiskHelper.getHeroPropWithEquip(herodata,equiplv)
    local perStart = 0
    local perEnd =  math.min(herodata.curhp*100/maxHP,100)
    obj:egSetBarPercent(kBarHp,perStart)
    local function callback()
        perStart = perStart + math.floor((perEnd-perStart)/10)
        if perStart > perEnd then 
            perStart = perEnd 
            obj:egUnbindWidgetUpdate(kBarHp)
        end
        obj:egSetBarPercent(kBarHp,perStart)
    end
    obj:egBindWidgetUpdate(kBarHp,callback)
end
function __lvuphero.getTotalHpByHeroid(obj,heroid,herolv,eid,equiplv)
    if not herolv then herolv = d_data.heroList[heroid].lv end
        local heroHP = hero_data.get(heroid,herolv).maxHP
		local equipdata = equipFuncs.getData(eid,equiplv)
		local equipHP = equipdata.maxHP
        return heroHP + equipHP 
end

LvUpHero = {}
function LvUpHero.new(herodata,equiplv,exp,maxlv,isatk)
    local obj = {}
    CocosWidget.install(obj,JsonList.lvupHero)
    table_aux.unpackTo(__lvuphero, obj)
    obj:init(herodata,equiplv,exp,maxlv,isatk)
    return obj
end
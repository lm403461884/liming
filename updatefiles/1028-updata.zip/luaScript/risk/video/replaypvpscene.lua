local kGroundOrder = 1
local kAtkOrder = 2
local kScoreOrder = 6
local __replaypvpscene={}
function __replaypvpscene.init(obj)
    obj._d_data = RiskHelper.getVideoSceneData()
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._videolayer = VideoLayer.new(obj._d_data,obj)
        obj._videolayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
	if obj._d_data.type == 0 then
		obj._groundlayer:showInAtkScene(obj._d_data.videoStart)
	else
		obj._groundlayer:showInDefScene(obj._d_data.videoStart)
	end
	obj._groundlayer:onHeroShown(callback)
end
function __replaypvpscene.stopBattle(obj)
	VideoDetail = nil
	BPResult ={}
    if obj._d_data.type == 0 then
		if obj._d_data.btFlag == 2 then --����¼��
			BPResult.elo = obj._d_data.atk_elo
		else --����ս¼��
			BPResult.honor = obj._d_data.atk_elo
		end
        BPResult.stars = obj._d_data.stars
		for idx,coinname in pairs(KVariantList.coinType) do
			BPResult[coinname] = obj._d_data[string.format("atk_%s",coinname)]
		end
    else
		if obj._d_data.btFlag == 2 then
			BPResult.elo = obj._d_data.def_elo
		else
			BPResult.honor = obj._d_data.def_elo
		end
        BPResult.stars =  numDef.starsPerStage - obj._d_data.stars
		for idx,coinname in pairs(KVariantList.coinType) do
			BPResult[coinname] = obj._d_data[string.format("def_%s",coinname)]
		end
    end
    AccountHelper:unlock(kStateBpResult)
	obj._scoreLayer= BattleResultLayer.new(obj._d_data)
	obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end
ReplayPvpScene={}
function ReplayPvpScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__replaypvpscene, obj)
    SoundHelper.stopBGM()
    obj:init()
    --showEmDialog(obj,GuideScene.def.kVideoScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
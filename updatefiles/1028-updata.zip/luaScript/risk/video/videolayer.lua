--��������

local kPanelLayer= "video_panel"
local kPanelGo = "panel_go"
local kLblCount = "lbl_count_txt"
--����/����
local kBtnSpeed ="btn_speed"
local kImgPlay = "img_play"
local kImgGiveUp = "img_giveup"
local kImgChain = "img_chain_right"
local kImgBarRight = "img_bar_right"
local kBtnBack = "btn_giveup"

--��������
local kBarConsume = "bar_consume"
local kImgConsume = "img_bar_bg"
local kLabelLeftCost = "lbl_consume"
local kLabelPerCost = "lbl_cost_val"
local kLabelPerCosts = "lbl_cost_val_s"
--������Ч���
local kPanelSkill = "skill_panel"
local kImgEffect = "img_effect"
local kImgHead = "img_head"
--С��Ӣ��
local kListHero = "hero_list"

--��������Ϣ
local kLabelAtk = "lbl_atk" --����������
local kAtkStars = {"star_atk_1","star_atk_2","star_atk_3"}
local kImgAtkBg = "atk_bg"
--���ط���Ϣ
local kLabelDef = "lbl_def" --���ط�����
local kDefStars = {"def_star_1","def_star_2","def_star_3"}
local kImgDefBg = "def_bg"

local kParticleSrc = "particle/battle/ExplodingRing.plist.png"
local kParticleReady = "particle/battle/skill_ready.plist"
local kParticleFire = "particle/battle/skill_fire.plist"

local kMaxDamage = 99999
local kHeroW = 156
local kParticleCap = 240
local kMinSpeedScale = 1
local kMaxSpeedScale = 2
local kSecForFrame = 0.016
local kGreenColor = ccc3(0,128,0)
local kRedColor = ccc3(128,0,2)

local __videolayer={}

function __videolayer.init(obj,d_data,owner)
     obj._owner = owner
     obj._d_data = d_data
     obj._frameID = 0 --֡ID
	 obj._speedScale = kMinSpeedScale
	 obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMaxSpeedScale)],UI_TEX_TYPE_PLIST)
     obj._battleStoped = false
	 obj._useSkillCounter = nil
     obj._usedConsume = 0 --�ܼ�������
     obj._enteredHeros = {} --�ѽ���ս����Ӣ��
     obj._unenteredHeros = {}--δ����ս����Ӣ��
     obj._heroHeads = {}
     obj._skillQueen={}
     --����ս��˫��������Ϣ
     obj:loadBaseInfo()
     --����Ӣ��
     obj:loadHeroHeads()
     obj:egHideWidget(kPanelSkill)
     obj:showPanelGo(true)
	 --����¼��ʱ,�����Ƽ��ٹ��ܵ�ʹ��
	 obj:bindSpeedUpListener()

end
--ս��������Ϣ����
function __videolayer.loadBaseInfo(obj)
 --����������Ϣ
    obj:egSetBarPercent(kBarConsume,100)
    obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume)
    obj:egSetLabelStr(kLabelPerCost,"0/s")
    obj:egSetLabelStr(kLabelPerCosts,"0/s")
     --���ؽ���������
    obj:egSetLabelStr(kLabelAtk,obj._d_data.atkName)
	
     --���ط��ط�����
     obj:egSetLabelStr(kLabelDef,obj._d_data.dfsName)

	 if obj._d_data.isDefencer then --�Ƿ��Ƿ�����
	    obj:egChangeImg(kImgAtkBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST) 
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
		--obj:egSetWidgetColor(kLabelAtk,kRedColor)
		--obj:egSetWidgetColor(kLabelDef,kGreenColor)
	else
	    obj:egChangeImg(kImgAtkBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST)
		--obj:egSetWidgetColor(kLabelDef,kRedColor)
		--obj:egSetWidgetColor(kLabelAtk,kGreenColor)
	end
end
function __videolayer.showPanelGo(obj,show)
    local lblWidget = obj:egGetWidgetByName(kLblCount)
    if show then
        obj:egShowWidget(kPanelGo)
        local blink = CCBlink:create(1,2)
        local repeatforever1 = CCRepeatForever:create(blink)
        lblWidget:runAction(repeatforever1)
    else
        obj:egHideWidget(kPanelGo)
        lblWidget:stopAllActions()
    end
end
--����Ӣ��ͷ��
function __videolayer.loadHeroHeads(obj)
    local teamCnt = #obj._d_data.teamList
    local heroPanel = obj:egGetWidgetByName(kListHero)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    for key,heroObj in ipairs(creaturelayer._heros) do
        local heroHead = BattleHero.new(heroObj)
        heroHead:disableTouch()
        heroPanel:addChild(heroHead:egNode())
        table.insert(obj._unenteredHeros,heroHead)
        obj._heroHeads[heroObj:getprop('type')] = heroHead 
        obj:bindHeroEntering(heroHead)
        obj:bindHeroDied(heroHead)
        obj:bindHeroSkillReady(heroHead)
        obj:bindHeroUsingSkill(heroHead)
    end
    local size = heroPanel:getSize()
    local oldW = size.width
    local newW = kHeroW*teamCnt
    heroPanel:setSize(CCSizeMake(newW,size.height))
    heroPanel:setPosition(ccp((oldW-newW)/2,0))
end
--Ӣ��׼���볡�ص�����
function __videolayer.bindHeroEntering(obj,heroHead)
    local function callback(sender)
        --��Ӣ�������ѽ���ս���б�
        for key ,item in ipairs(obj._unenteredHeros) do
            if item == sender then
                if #obj._unenteredHeros == #obj._d_data.teamList then 
                     obj:showPanelGo(false)
                end
                table.remove(obj._unenteredHeros,key)
            end
        end
        table.insert(obj._enteredHeros,sender)
    end
    heroHead:onHeroEntering(callback)  
end
--Ӣ�������ص�����
function __videolayer.bindHeroDied(obj,heroHead)
    local function callback(sender)
        for key,item in ipairs(obj._enteredHeros) do
            if item == sender then
                table.remove(obj._enteredHeros,key)
                break
            end
        end
    end
    heroHead:onHeroDied(callback)
end
--Ӣ�ۼ���׼����ɻص�����
function __videolayer.bindHeroSkillReady(obj,heroHead)
    local function callback(sender)
        local particle = CCParticleSystemQuad:create(kParticleReady)
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
    end
    heroHead:onSkillReady(callback)
end
--Ӣ��ʹ�ü���ǰ�Ļص�����
function __videolayer.bindHeroUsingSkill(obj,heroHead)
    local function callback(sender)
        table.insert(obj._skillQueen,sender)
        local particle = CCParticleSystemQuad:create(kParticleFire)
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
        
        obj:egShowWidget(kPanelSkill)
        obj:egChangeImg(kImgHead,hero_data.getConfig(sender:getHeroID()).skillHeadPic,UI_TEX_TYPE_PLIST)
        local img = obj:egGetWidgetByName(kImgEffect)
        img:setScaleX(0)
        img:stopAllActions()
        local scaleto = CCScaleTo:create(0.5,1)
        local expOut = CCEaseExponentialOut:create(scaleto)
        img:runAction(expOut)
		obj._useSkillCounter = 1.0 --�ͷż��ܵ���ʱ
        
    end
    heroHead:onUsingSkill(callback)
end
--��ʾ�Ǽ����
function __videolayer.refreshStarChange(obj)
	local totalCount = #obj._d_data.collectorList
	local gainCount = #battleProgress.collector
	local stars = math.floor(gainCount / totalCount * numDef.starsPerStage)
	if gainCount > 0 and stars == 0 then
		stars = 1
	end
    if stars ~= battleProgress.stars  then 
        for idx = battleProgress.stars + 1,stars do
            local star1 = obj:egGetWidgetByName(kDefStars[idx])
            local star2 = obj:egGetWidgetByName(kAtkStars[idx])
            local blink1 = CCBlink:create(0.5,5)
            local blink2 = CCBlink:create(0.5,5)
            local function callbackfunc1()
                obj:egChangeImg(kDefStars[idx],ImageList.lvup_starnull,UI_TEX_TYPE_PLIST)
				obj:egGetWidgetByName(kDefStars[idx]):setScale(0.4)
            end
            local function callbackfunc2()
                obj:egChangeImg(kAtkStars[idx],ImageList.lvup_star,UI_TEX_TYPE_PLIST)
				obj:egGetWidgetByName(kAtkStars[idx]):setScale(0.5)
            end
            local action_callback1 = CCCallFuncN:create(callbackfunc1)
            local action_callback2 = CCCallFuncN:create(callbackfunc2)
            local sequence1 = CCSequence:createWithTwoActions(blink1,action_callback1)
            local sequence2 = CCSequence:createWithTwoActions(blink2,action_callback2)
            star1:runAction(sequence1)
            star2:runAction(sequence2)
        end
         battleProgress.stars  = stars
    end
end

--��ȡ�����ѽ���ӵ���Ӣ�۵�����ֵ�ܺ�
function __videolayer.getTotalConsume(obj)
    local val = 0
    for idx,hero in pairs(obj._heroHeads) do
        val = val + hero:getTotalConsume()
    end
    if val > obj._d_data.consume then val = obj._d_data.consume end
    return val
end
--��ȡ�ܼ�ÿ������
function __videolayer.getPerConsume(obj)
    local val = 0
    for idx,hero in ipairs(obj._enteredHeros) do
        val = val + hero:getConsume()
    end
    return val
end
--�ж����Ƿ�������
function __videolayer.refreshConsume(obj)
   local perConsume = obj:getPerConsume()
   obj:egSetLabelStr(kLabelPerCost,string.format("%d%s",perConsume,"/s"))
   obj:egSetLabelStr(kLabelPerCosts,string.format("%d%s",perConsume,"/s"))
   local usedConsume = obj:getTotalConsume()
   if usedConsume < obj._d_data.consume then
       if obj._usedConsume ~= usedConsume then
            obj._usedConsume = usedConsume
            local percent =100- usedConsume*100/obj._d_data.consume
            obj:egSetBarPercent(kBarConsume,percent)
            obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume - obj._usedConsume)
       end
   end
end
--���������������£�����Ӣ����������
function __videolayer.killAllHeros(obj)
    for _,heroid in ipairs(obj._d_data.teamList) do
        obj._heroHeads[heroid]:killHero()
    end
    obj._enteredHeros={}
    obj._unenteredHeros={}
end

--����ս��
function __videolayer.stopBattle(obj)
    ai_module.clear()
	CCDirector:sharedDirector():getScheduler():setTimeScale(kMinSpeedScale)
    obj._battleStoped = true
    obj:egSetWidgetTouchEnabled(kBtnBack,false)
    battleProgress.endTime = os.time()
    battleProgress.frameCnt = obj._frameID
    battleProgress.stars = obj._d_data.stars
    obj:egUnbindWidgetUpdate(kPanelLayer)
    if obj._d_data.type==1 then --����¼��
        if battleProgress.stars > 0 then
           SoundHelper.playBGMOnce(SoundList.battleLose)
        else
           SoundHelper.playBGMOnce(SoundList.battleWin)
		   obj:killAllHeros()
        end
    else
	    if battleProgress.stars > 0 then
           SoundHelper.playBGMOnce(SoundList.battleWin)
        else
           SoundHelper.playBGMOnce(SoundList.battleLose)
		   obj:killAllHeros()
        end
	end    
    obj._d_data.oldheroList = obj:copyHeroData()
    obj._owner:stopBattle() --�ص�����������stopBattle����
    obj:egHideWidget(kBtnBack)
    obj:egHideWidget(kImgBarRight)
	obj:egHideWidget(kImgChain)
	obj:egHideWidget(kBtnSpeed)
	obj:egHideWidget(kImgBarRight)
end
function __videolayer.copyHeroData(obj)
   local herolist ={}
    for heroid,item in pairs(obj._d_data.heroList) do
         
         local heroHead = obj._heroHeads[heroid]
         if heroHead then --�ų�heroList��û����Team��Ӣ��
            local tb =Funs.copy(item)
             tb.curhp = heroHead:getHP()
             herolist[heroid] = tb
         end
    end
    return herolist
end
--����Ӣ���Զ��볡
function __videolayer.recSendHero(obj)
        while #obj._d_data.heroEnterFrame >= 2 and obj._d_data.heroEnterFrame[2] <= obj._frameID do
            local heroid = obj._d_data.heroEnterFrame[1]
            local heroFrame = obj._d_data.heroEnterFrame[2]

            obj._heroHeads[heroid]:moveIntoBattle()
            table.remove(obj._d_data.heroEnterFrame,2)
            table.remove(obj._d_data.heroEnterFrame,1)
        end
end
--���ÿ���Ӣ��AI
function __videolayer.recActiveHeroAI(obj)
    while #obj._d_data.heroCreatedFrame >= 2 and obj._d_data.heroCreatedFrame[2]<=obj._frameID do
        local heroid = obj._d_data.heroCreatedFrame[1]
        local createFrame = obj._d_data.heroCreatedFrame[2]
        obj._heroHeads[heroid]:activeAI()
        table.remove(obj._d_data.heroCreatedFrame,2)
        table.remove(obj._d_data.heroCreatedFrame,1)
    end
end
--ʹ�ü���
function __videolayer.recUseSkill(obj)
     for heroid,useFrameList in pairs(obj._d_data.skillFrame) do
        if #useFrameList > 0 then
            local userFrame = useFrameList[1]
            if userFrame<=obj._frameID then
                obj._heroHeads[heroid]:doUseSkill()
                table.remove(useFrameList,1)
            end
        else
            obj._d_data.skillFrame[heroid] = nil
        end
    end
end
function __videolayer.clearUsedSkill(obj)
	if obj._useSkillCounter  then
		if obj._useSkillCounter > 0 then
			obj._useSkillCounter = obj._useSkillCounter - kSecForFrame
		else
			obj._useSkillCounter = nil
			obj:egHideWidget(kPanelSkill)
            for idx = #obj._skillQueen,1,-1 do
                obj._skillQueen[idx]:afterUseSkill()
                table.remove(obj._skillQueen,idx)
            end
		end
	end
end
function __videolayer.bindPanelUpdate(obj)
    local  function callback()
		for idx=1,obj._speedScale do
			if obj._battleStoped then return end
			if #obj._skillQueen== 0 then
				ai_module.update()
			end
			obj._frameID = obj._frameID + 1
			obj:clearUsedSkill()
			obj:recSendHero()--����Ӣ���Զ��볡
			obj:recActiveHeroAI()--���ÿ���Ӣ��AI
			obj:recUseSkill()--����ʹ�ü���
			obj:refreshConsume() --��������ֵ
			obj:refreshStarChange()
			if obj._frameID >= obj._d_data.frameCnt then
				obj:stopBattle()
			end
		end
    end
    obj:egBindWidgetUpdate(kPanelLayer,callback)
end
--����
function __videolayer.bindBackListener(obj)
     local function touchBegan()
         obj:egSetWidgetScale(kImgGiveUp,1)
     end
     local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        obj:egSetWidgetScale(kImgGiveUp,0.9)
        SoundHelper.playEffect(SoundList.click_back_button)
		obj:egUnbindWidgetUpdate(kPanelLayer)
		ai_module.clear()
		CCDirector:sharedDirector():getScheduler():setTimeScale(kMinSpeedScale)
        local scene = TownScene.new()
        scene:egReplace()
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgGiveUp,0.9)
    end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
function __videolayer.bindSpeedUpListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgPlay,1.1)
    end
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		obj:egSetWidgetScale(kImgPlay,1)
		if not obj._battleStoped then
			if obj._speedScale == kMaxSpeedScale then --ȡ������
				obj._speedScale = kMinSpeedScale
				obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMaxSpeedScale)],UI_TEX_TYPE_PLIST)
			else --����
				obj._speedScale = kMaxSpeedScale
				obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMinSpeedScale)],UI_TEX_TYPE_PLIST)
			end
			CCDirector:sharedDirector():getScheduler():setTimeScale(obj._speedScale)
		end
		sender:setTouchEnabled(true)
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgPlay,1)
    end
     obj:egBindTouch(kBtnSpeed,touchBegan,nil,touchEnded,touchCanceled)
end
function __videolayer.bindExitEvent(obj)
	local function clear()
		ai_module.clear()
	end
     obj:egOnExit(clear)
end
VideoLayer={}
function VideoLayer.new(d_data,owner)
    local obj = TouchWidget.new(JsonList.videoLayer)
    obj._particlelayer =  CCParticleBatchNode:create(kParticleSrc,kParticleCap)
	obj:egAddChild(obj._particlelayer,1,1)
    table_aux.unpackTo(__videolayer, obj)
    obj:init(d_data,owner)
    obj:bindBackListener()
    obj:bindPanelUpdate() 
	obj:bindExitEvent()
    return obj
end

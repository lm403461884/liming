--! local context
local sumaries = {} --using as array
local videos = {}  --using as hash, key is videoid(vid)
local __newVideo = false
local __newDef = false

local warsumaries = {} --using as array
local warvideos = {}  --using as hash, key is videoid(vid)

--! module videomanager
videomanager = {}
--=============================================================
function videomanager.getlastvid()
	if #sumaries == 0 then
		return -1
	end
	return sumaries[#sumaries].vid
end
function videomanager.markRevenged(vid)
	for key,item in ipairs(sumaries) do
		if item.vid == vid then
		item.needRevenged = 0 end
	end
end
function videomanager.addsumary(sum)
	table.insert(sumaries, sum)
	if sum.time > account_data.lastOffline and sum.defGuid == account_data.guid then
		__newDef = true
        local tb = {}
        tb.type = 1 --type定义参考TownScene
        tb.data = {}
        tb.data.atkName = sum.atkName
		for idx,coinname in pairs(KVariantList.coinType) do
			tb.data[coinname] = sum[string.format("def_%s",coinname)] or 0
		end
		tb.data.elo = sum.def_elo or 0
        tb.data.stars = sum.stars or 0
		task.updateTaskStatus(account_data,task.client_event_id.pvp_elo,{sum.def_elo or 0}) --日常任务进度，当前ELO值
        AccountHelper:addNewPrompt(tb)
     postEventSignal(kEventNoticeMail)   
	end
end
--获取新录像标识
function videomanager.hasNewVideo()
	return __newVideo
end
--获取新防御录像标识
function videomanager.hasNewDefVideo()
	return __newDef
end
--标记是否有新PVP录像
function videomanager.markNewVideo(hasNew)
	__newVideo = hasNew
	if not hasNew then
		__newDef = false
	end
end
function videomanager.addvideo(vid, vd)
	videos[vid] = vd
end

function videomanager.getsumaries()
	return sumaries
end
function videomanager.getvideo(vid)
	return videos[vid]
end
function videomanager.getvideoDetail(vid)
    local videoinfo = videos[vid]
    local videodetail = {}
	videodetail.flag = 2
    videodetail.atk = videoinfo.atk
    videodetail.def = videoinfo.def
	videodetail.atk.guid = videoinfo.bpresult.atkGuid
    videodetail.atk.userName = videoinfo.bpresult.atkName
	videodetail.def.guid = videoinfo.bpresult.defGuid
	videodetail.def.userName = videoinfo.bpresult.defName
	videodetail.atk_elo = videoinfo.bpresult.atk_elo
	videodetail.def_elo = videoinfo.bpresult.def_elo
	videodetail.isDefencer = videoinfo.bpresult.isDefencer
	for idx,coinname in pairs(KVariantList.coinType) do
        local atkparam = string.format("atk_%s",coinname)
        local defparam = string.format("def_%s",coinname)
        videodetail[atkparam] = videoinfo.bpresult[atkparam]
        videodetail[defparam] = videoinfo.bpresult[defparam]
	end
	videodetail.stars = videoinfo.bpresult.stars
    return videodetail
end
--=============================================

--club war related
function videomanager.addwarsumary(sum)
	table.insert(warsumaries, sum)
end

function videomanager.addwarvideo(vid, vd)
	warvideos[vid] = vd
end

function videomanager.getwarsumaries()
	return warsumaries
end
function videomanager.getwarvideo(vid)
	return warvideos[vid]
end
function videomanager.clearwarvideo()
	warsumaries={}
	warvideos={}
end
function videomanager.getwarvideoDetail(vid)
    local videoinfo = warvideos[vid]
    local videodetail = {}
	videodetail.flag = 7
    videodetail.atk = videoinfo.atk
    videodetail.def = videoinfo.def
	videodetail.atk.guid = videoinfo.bpresult.atkGuid
    videodetail.atk.userName = videoinfo.bpresult.atkName
	videodetail.def.guid = videoinfo.bpresult.defGuid
	videodetail.def.userName = videoinfo.bpresult.defName
	videodetail.atk_elo = videoinfo.bpresult.atk_elo
	videodetail.def_elo = videoinfo.bpresult.def_elo
	videodetail.isDefencer = videoinfo.bpresult.isDefencer
	for idx,coinname in pairs(KVariantList.coinType) do
        local atkparam = string.format("atk_%s",coinname)
        local defparam = string.format("def_%s",coinname)
        videodetail[atkparam] = videoinfo.bpresult[atkparam]
        videodetail[defparam] = videoinfo.bpresult[defparam]
	end
	videodetail.stars = videoinfo.bpresult.stars
    return videodetail
end
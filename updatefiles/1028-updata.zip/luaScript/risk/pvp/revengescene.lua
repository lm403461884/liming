local kGroundOrder = 1
local kAtkOrder = 2
local kScoreOrder = 6
local __revengescene={}
function __revengescene.init(obj,vid)
	obj._vid =  vid
	SendMsg[935007]()
    obj._d_data = RiskHelper.getPvpSceneData()
	
    obj._groundlayer = GroundLayer.new(obj._d_data)
     obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
		showEmDialog(obj,GuideScene.def.kPvpScene) --����������Ϣ
        obj._pvplayer = PvpLayer.new(obj._d_data,obj)
        obj._pvplayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene(battleProgress.startTime)
    obj._groundlayer:onHeroShown(callback)
end
function __revengescene.savePvpAward(obj)
	BPResult = {}
	BPResult.stars =  battleProgress.stars 
	local ownEloWin,pvpEloLose = pvpCalc.elo(account_data.elo, pvpaccount_data.elo,BPResult.stars)
	BPResult.elo = math.floor(ownEloWin - account_data.elo)
	print("gain elo:",BPResult.elo)
	account_data.elo = account_data.elo + BPResult.elo
	local resList = {}
	local goldDlt,oilDlt,_,_ = pvpCalc.judge( ownEloWin, pvpEloLose,BPResult.stars, account_data.digLv, pvpaccount_data.digLv,pvpaccount_data.gold, pvpaccount_data.oil)
	resList.gold = goldDlt
	for key,carIdx in ipairs(battleProgress.collector) do
		local resCardData = pvpaccount_data.collectorList[carIdx]
		local coin = resCardData.coin
		local coinname = KVariantList.coinType[coin]
		if coin > 0 then
			local tbmine = pvpaccount_data.mileSpread[resCardData.pos]
			local mine_cfg = mile_data.get(tbmine.type, tbmine.lv)
			resList[coinname] = (resList[coinname] or 0) + mine_cfg.gainVal	
		end
	end
	for key,val in pairs(resList) do
		BPResult[key] = val
		account_data[key] = account_data[key] + val
		print("gain ",key,":",val)
	end
end
function __revengescene.stopBattle(obj)
	
	SendMsg[935008](obj._vid,battleProgress)
	 AccountHelper:unlock(kStateBpResult)
	obj:savePvpAward()
	account_data.revengeCnt = account_data.revengeCnt+1
	videomanager.markRevenged(obj._vid)
	videomanager.markNewVideo(true)
    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end

RevengeScene={}
function RevengeScene.new(vid)
    SoundHelper.playBGM(SoundList.atk_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__revengescene, obj)
    obj:init(vid)
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
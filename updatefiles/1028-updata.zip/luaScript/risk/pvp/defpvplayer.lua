--��������
local kPanelLayer= "atk_panel"
local kPanelGo = "panel_go"
local kLblCount = "lbl_count"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnNo2 = "btn_no_2"
local kPanelConfirm = "giveup_panel"

local kLblNotice = "lbl_notice"
local kLblAsk = "lbl_ask"
--����/����
local kBtnSpeed ="btn_speed"
local kImgPlay = "img_play"
local kImgBarRight = "img_bar_right"

local kLblGiveUp = "lbl_giveup"
local kImgGiveUp = "img_giveup"
local kBtnBack = "btn_giveup"
local kImgChain = "img_chain_right"

--������Ч���
local kPanelSkill = "skill_panel"
local kImgEffect = "img_effect"
local kImgHead = "img_head"

--��������
local kBarConsume = "bar_consume"
local kImgConsume = "img_bar_bg"
local kLabelLeftCost = "lbl_consume"
local kLabelPerCost = "lbl_cost_val"
local kLabelPerCosts = "lbl_cost_val_s"
--С��Ӣ��
local kListHero = "hero_list"
--��������Ϣ
local kLabelAtk = "lbl_atk" --����������
local kAtkStars = {"star_atk_1","star_atk_2","star_atk_3"}
local kImgAtkBg = "atk_bg"
--���ط���Ϣ
local kLabelDef = "lbl_def" --���ط�����
local kDefStars = {"def_star_1","def_star_2","def_star_3"}
local kPanleBox = "box_list"
local kImgDefBg = "def_bg"

local kCounterNum0 = 20
local kCounterNum1 = 10
local kMaxDamage = 99999
local kCellW = 72
local kSpeed = 200
local kMinSpeedScale = 1
local kMaxSpeedScale = 2
local kSecForFrame = 0.016
local kGreenColor = ccc3(0,128,0)
local kRedColor = ccc3(128,0,2)
local __deflayer={}

function __deflayer.init(obj,d_data,owner)
     obj._owner = owner
     obj._d_data = d_data
     obj._startTime = os.clock()
	 obj._speedScale = kMinSpeedScale
	 obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMaxSpeedScale)],UI_TEX_TYPE_PLIST)
     obj._battleStoped = false
	 obj._useSkillCounter = nil
     obj._usedConsume = 0 --�ܼ�������
     obj._enteredHeros = {} --�ѽ���ս����Ӣ��
     obj._unenteredHeros = {}--δ����ս����Ӣ��
     obj._skillQueen = {}
     --����ս��˫��������Ϣ
     obj:loadBaseInfo()
	   --����Ӣ��
     obj:loadHeroHeads()
	 obj:egHideWidget(kPanelGo) --�������治��ʾ
	 obj:egHideWidget(kPanleBox)--���ر���ģ��

	 obj:egHideWidget(kPanelSkill)
     obj:showConfirmGiveUp(false)
	 obj:egSetLabelStr(kLblNotice,TxtList.defGiveUpNote) --������ʾ��Ϣ
     obj:egSetLabelStr(kLblAsk,TxtList.defGiveUpAsk)
     obj:egSetLabelStr(kLblGiveUp,TxtList.defGiveUp)
	 local vipLv = account_data.vip or 0
	 if numDef.unlockSpeedUpLv > vipLv then
		obj:bindSpeedLockedListener()
	 else
		obj:bindSpeedUpListener()
	 end
	 SoundHelper.playBGM(SoundList.def_bgm)
end
function __deflayer.loadBaseInfo(obj)
 --����������Ϣ
    obj:egSetBarPercent(kBarConsume,100)
    obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume)
    obj:egSetLabelStr(kLabelPerCost,"0/s")
    obj:egSetLabelStr(kLabelPerCosts,"0/s")
     --���ؽ���������
    obj:egSetLabelStr(kLabelAtk,obj._d_data.atkName)

     --���ط��ط�����
     obj:egSetLabelStr(kLabelDef,obj._d_data.dfsName)
	 
	 obj:egChangeImg(kImgAtkBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST)
	 obj:egChangeImg(kImgDefBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
	--obj:egSetWidgetColor(kLabelAtk,kRedColor)
	--obj:egSetWidgetColor(kLabelDef,kGreenColor)
end
--����Ӣ��
function __deflayer.loadHeroHeads(obj)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    for key,heroObj in ipairs(creaturelayer._heros) do
		local heroid = heroObj:getprop("type")
		--local heroprop =obj._d_data.heroList[heroid]
		local heroprop = obj._d_data.heroList[key]
		heroObj:addprop("enterTime",heroprop.enterTime)
		heroObj:addprop("survialTime",0)
		table.insert( obj._unenteredHeros,heroObj)
    end
end
--�볡����ʱ
function __deflayer.activeEnterCounter(obj)
    local passed = 0
    local function callback(delta)
        passed = passed + delta
		local leftCnt =  #obj._unenteredHeros
		if  leftCnt<= 0  then
			--����Ӣ�۶��Ѿ��볡
			obj:egUnbindWidgetUpdate(kLblCount)
		else
			for idx = leftCnt,1,-1 do
				local heroObj = obj._unenteredHeros[idx]
				if heroObj then
					local enterTime = heroObj:getprop("enterTime")
					if passed*1000 >= enterTime then
						table.insert( obj._enteredHeros,heroObj)
						table.remove(obj._unenteredHeros,idx)
						--�Զ��ַ�Ӣ�� �볡
						obj:enterBattle(heroObj)
					end
				end
			end
		end
    end
    obj:egBindWidgetUpdate(kLblCount,callback)
end
--����ս��
function __deflayer.enterBattle(obj,heroObj)
    --SoundHelper.playEffect(SoundList.hero_go)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local x,y = creaturelayer:getPosByIdx(heroObj:getprop("birthPlace"))
    local function callback2()
        if heroObj:egNode() then heroObj:openAi() end
    end
    heroObj:moveToPos(ccp(x,y),callback2)

end
--Ӣ��ʹ�ü���ǰ�Ļص�����
function __deflayer.doUseHeroSkill(obj,heroObj)
	local heroid = heroObj:getprop("type")
    table.insert(obj._skillQueen,heroObj)
    local holelayer = AccountHelper:get(kHoleLayer)
	local creaturelayer = holelayer._creaturelayer
	creaturelayer:focusHero(heroObj,true)

    local herox = heroObj:egGetPosX()
    local heroy = heroObj:egGetPosY()
    local poscenter = creaturelayer:egPosInNode(640,360)
    local x =poscenter.x -  herox
    local y = poscenter.y - heroy
    if x ~=0 or y ~= 0 then
        holelayer:moveInnerBy(0.1,x,y)
    end
    obj:egShowWidget(kPanelSkill)
    obj:egChangeImg(kImgHead,hero_data.getConfig(heroid).skillHeadPic,UI_TEX_TYPE_PLIST)
    local img = obj:egGetWidgetByName(kImgEffect)
    img:setScaleX(0)
    img:stopAllActions()
    local scaleto = CCScaleTo:create(0.5,1)
    local expOut = CCEaseExponentialOut:create(scaleto)
	obj._useSkillCounter = 1.0
    img:runAction(expOut)
	obj:showSkillEffect(heroObj)
	obj:showSkillAction(heroObj)
end
function __deflayer.clearUsedSkill(obj)
	if obj._useSkillCounter  then
		if obj._useSkillCounter > 0 then
			obj._useSkillCounter = obj._useSkillCounter -kSecForFrame
		else
			local holelayer = AccountHelper:get(kHoleLayer)
			local creaturelayer = holelayer._creaturelayer
			obj._useSkillCounter = nil
			obj:egHideWidget(kPanelSkill)
            for idx = #obj._skillQueen,1,-1 do
               local skillHero = obj._skillQueen[idx]
				skillHero:useActiveSkill()
				skillHero:setprop("powerBar",0)
				creaturelayer:focusHero(skillHero,false)
				table.remove(obj._skillQueen,idx)
            end
		end
	end
end
--��ʾ������Ч
function __deflayer.showSkillEffect(obj,heroObj)
	if not heroObj then return end
	local sprite = CCSprite:createWithSpriteFrameName("effect_activeskill01_010101.png")
	local prefix = "effect_activeskill01"
	local act = 1
    local dir = heroObj:getDir()
	local name = graphicLoader.animaName(prefix, 1, dir)
	local anima = graphicLoader.getAnimation(name)
	local delay = graphicLoader.animaDelay(prefix, act)
	anima:setDelayPerUnit((1 / (rate or 1)) * delay)
	local animate = CCAnimate:create(anima)
	local function callback ()
		if heroObj then
			heroObj:egNode():removeChild(sprite,true)
		end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(animate,callfunc)
	local size = heroObj:egNode():getContentSize()
	heroObj:egAddChild(sprite)
	sprite:setPosition(ccp(size.width/2,size.height/2))
	sprite:runAction(sequence)
end
--��ʾ���ж���
function __deflayer.showSkillAction(obj,heroObj)
	if heroObj then
		heroObj:beforeSkill()
		local showObj = heroObj:getActionUnit()
		local act = heroObj:getStanbyAction()
		local prefix = showObj:getprop('graphName')
		local dir = heroObj:getDir()
		local name = graphicLoader.animaName(prefix, act, dir)
		heroObj:egNode():stopAllActions()
		if showObj ~= heroObj then
			showObj:egNode():stopAllActions()
		end
		local anima = graphicLoader.getAnimation(name)
		local delay = graphicLoader.animaDelay(prefix, act)
		anima:setDelayPerUnit((1 / (rate or 1)) * delay)
		local animate = CCAnimate:create(anima)
		showObj:egNode():runAction(animate)
	end
end
--��ʾ�Ǽ����
function __deflayer.showStarChange(obj,stars)
    if stars ~= battleProgress.stars  then
        for idx = battleProgress.stars + 1,stars do
            local star1 = obj:egGetWidgetByName(kDefStars[idx])
            local star2 = obj:egGetWidgetByName(kAtkStars[idx])
            local blink1 = CCBlink:create(0.5,5)
            local blink2 = CCBlink:create(0.5,5)
            local function callbackfunc1()
				obj:egChangeImg(kDefStars[idx],ImageList.lvup_starnull,UI_TEX_TYPE_PLIST)
				obj:egGetWidgetByName(kDefStars[idx]):setScale(0.4)
            end
            local function callbackfunc2()
                obj:egChangeImg(kAtkStars[idx],ImageList.lvup_star,UI_TEX_TYPE_PLIST)
				obj:egGetWidgetByName(kAtkStars[idx]):setScale(0.5)
            end
            local action_callback1 = CCCallFuncN:create(callbackfunc1)
            local action_callback2 = CCCallFuncN:create(callbackfunc2)
            local sequence1 = CCSequence:createWithTwoActions(blink1,action_callback1)
            local sequence2 = CCSequence:createWithTwoActions(blink2,action_callback2)
            star1:runAction(sequence1)
            star2:runAction(sequence2)
        end
         battleProgress.stars  = stars
    end
end

--��ȡ�����ѽ���ӵ���Ӣ�۵�����ֵ�ܺ�
function __deflayer.getTotalConsume(obj)
    local val = 0
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local survialTime = heroObj:getprop("survialTime")
		local consume = heroObj:getprop("consume")
        val = val +survialTime*consume
    end
    val = math.floor(val)
    if val > obj._d_data.consume then val = obj._d_data.consume end
    return val
end
--��ȡ�ܼ�ÿ������
function __deflayer.getPerConsume(obj)
    local val = 0
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local hp = heroObj:getprop("hp")
		if hp > 0 then
			val = val +heroObj:getprop("consume")
		end
    end
    val = math.floor(val)
    return val
end

--�ж����Ƿ�������
function __deflayer.isTimeOut(obj)
   local perConsume = obj:getPerConsume()
   obj:egSetLabelStr(kLabelPerCost,string.format("%d%s",perConsume,"/s"))
   obj:egSetLabelStr(kLabelPerCosts,string.format("%d%s",perConsume,"/s"))
   local usedConsume = obj:getTotalConsume()
   if usedConsume == obj._d_data.consume then
       obj:egUnbindWidgetUpdate(kLblCount)
       for idx,heroObj in ipairs(obj._unenteredHeros) do
            table.insert(obj._enteredHeros,heroObj)
       end
       obj._unenteredHeros={}
       for idx,heroObj in ipairs(obj._enteredHeros) do
            heroObj:setprop("hp",0)
            heroObj:setprop("powerbar",0)
       end

       return true
   else
       if obj._usedConsume ~= usedConsume then
            obj._usedConsume = usedConsume
            local percent =100- usedConsume*100/obj._d_data.consume
            obj:egSetBarPercent(kBarConsume,percent)
            obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume - obj._usedConsume)
       end
       return false
   end
end
--�ж���Դ���Ƿ����
function __deflayer.isResCarClear(obj)
	local totalCount = #obj._d_data.collectorList
	local gainCount = #battleProgress.collector
	local stars = math.floor(gainCount / totalCount * numDef.starsPerStage)
	if gainCount > 0 and stars == 0 then
		stars = 1
	end
    obj:showStarChange(stars)
	if gainCount == totalCount  then
		return true
	else
		return false
	end
end

--�ж�Ӣ���Ƿ�����
function __deflayer.isHeroClear(obj)
    if #obj._unenteredHeros > 0 then return false end
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local hp = heroObj:getprop("hp")
		if hp > 0 then
			return false
		end
    end
	return true
end

--����ս��
function __deflayer.stopBattle(obj)
    ai_module.clear()
	CCDirector:sharedDirector():getScheduler():setTimeScale(kMinSpeedScale)
    obj._battleStoped = true
    obj:egUnbindWidgetUpdate(kLblCount)
    obj:egSetWidgetTouchEnabled(kBtnBack,false)
    obj:showConfirmGiveUp(false)
    obj:egUnbindWidgetUpdate(kPanelLayer)
    if battleProgress.stars < 3  then
	   SoundHelper.playBGMOnce(SoundList.battleWin)
    else
	   SoundHelper.playBGMOnce(SoundList.battleLose)
    end

    obj._d_data.oldheroList = obj:copyHeroData()--���ƽ�ս��ǰӢ������
    obj._owner:stopBattle() --�ص�����������stopBattle����
    obj:egHideWidget(kBtnBack)
    obj:egHideWidget(kImgBarRight)
	obj:egHideWidget(kImgChain)
	obj:egHideWidget(kBtnSpeed)
end
function __deflayer.copyHeroData(obj)
   local herolist ={}
   for idx,heroObj in ipairs(obj._unenteredHeros) do
       table.insert(obj._enteredHeros,heroObj)
   end
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local tb = {}
		tb.type = heroObj:getprop("type")
		tb.lv = heroObj:getprop("level")
		tb.curhp =  heroObj:getprop("hp")
		tb.hp =  heroObj:getprop("maxHP")
		tb.eid = heroObj:getprop("equipID")
		tb.equipLv = heroObj:getprop("equipLv")
		--herolist[tb.type] = tb
		table.insert(herolist,tb)
    end

    return herolist
end
--���ط�����ť
function __deflayer.hideGiveUp(obj,hide)
    if hide then
        obj:egHideWidget(kBtnBack)
		obj:egHideWidget(kImgBarRight)
    else
        obj:egShowWidget(kBtnBack)
		obj:egShowWidget(kImgBarRight)
    end
end
--��ʾ�������
function __deflayer.showConfirmGiveUp(obj,show)
    if show then
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        --obj:egShowWidget(kBtnNo2)
        obj:egShowWidget(kPanelConfirm)
    else
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
       -- obj:egHideWidget(kBtnNo2)
        obj:egHideWidget(kPanelConfirm)
    end
end
function __deflayer.refreshSurvivalTime(obj,delta)
	for idx,heroObj in ipairs(obj._enteredHeros) do
		local hp =  heroObj:getprop("hp")
		if hp > 0 then
			local survialTime = heroObj:getprop("survialTime")
			 heroObj:setprop("survialTime",survialTime + delta)
		end
    end
end
function __deflayer.bindPanelUpdate(obj)
    local  function callback(delta)
		for idx=1,obj._speedScale do
			if obj._battleStoped then return end
			if #obj._skillQueen== 0 then ai_module.update() end
			obj:clearUsedSkill()
			obj:refreshSurvivalTime(delta)
			if obj:isTimeOut() then
                obj:stopBattle()
			elseif obj:isResCarClear() then
                obj:stopBattle()
			elseif obj:isHeroClear() then
                obj:stopBattle()
			end
		end
    end
    obj:egBindWidgetUpdate(kPanelLayer,callback)
end
--����
function __deflayer.bindBackListener(obj)
     local function touchBegan()
         obj:egSetWidgetScale(kImgGiveUp,1)
     end
     local function touchEnded(sender)
        obj:egSetWidgetScale(kImgGiveUp,0.9)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:showConfirmGiveUp(true)
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgGiveUp,0.9)
    end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
--ȷ�Ϸ���
function __deflayer.bindYesListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
        if not obj._battleStoped  then
           -- battleProgress.stars = pveGuardQuest.pveGuardSkip(obj._d_data.stageid,account_data)
			battleProgress.collector = {}
		   for key,item in ipairs(obj._d_data.collectorList) do
				table.insert(battleProgress.collector,key)
		   end
		   battleProgress.stars = numDef.starsPerStage
           obj:stopBattle()
        end
    end
     obj:egBindTouch(kBtnYes,nil,nil,touchEnded,nil)
end
--ȡ������
function __deflayer.bindNoListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:egSetWidgetTouchEnabled(kBtnBack,true)
    end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,nil)
end
function __deflayer.bindSpeedUpListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgPlay,1.1)
    end
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		obj:egSetWidgetScale(kImgPlay,1)
		if not obj._battleStoped then 
			if obj._speedScale == kMaxSpeedScale then --ȡ������
				obj._speedScale = kMinSpeedScale
				obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMaxSpeedScale)],UI_TEX_TYPE_PLIST)
			else --����
				obj._speedScale = kMaxSpeedScale
				obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMinSpeedScale)],UI_TEX_TYPE_PLIST)
			end
			CCDirector:sharedDirector():getScheduler():setTimeScale(obj._speedScale)
		end
		sender:setTouchEnabled(true)
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgPlay,1)
    end
     obj:egBindTouch(kBtnSpeed,touchBegan,nil,touchEnded,touchCanceled)
end
function __deflayer.bindSpeedLockedListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgPlay,1.1)
    end
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		obj:egSetWidgetScale(kImgPlay,1)
		local text = string.format("%s LV%d",TxtList.needVIP,numDef.unlockSpeedUpLv)
		 showPopTxt(text,sender:getPositionX(),sender:getPositionY() + sender:getSize().height/2,ccp(0,0.5))
		sender:setTouchEnabled(true)
    end
     local function touchCanceled()
        obj:egSetWidgetScale(kImgPlay,1)
    end
     obj:egBindTouch(kBtnSpeed,touchBegan,nil,touchEnded,touchCanceled)
end
function __deflayer.bindExitEvent(obj)
	local function clear()
		ai_module.clear()
		obj:egNode():removeAllChildrenWithCleanup(true)
	end
     obj:egOnExit(clear)
end
DefPvpLayer={}
function DefPvpLayer.new(d_data,owner)
    local obj = TouchWidget.new(JsonList.atkLayer)
    table_aux.unpackTo(__deflayer, obj)
    obj:init(d_data,owner)
    obj:bindBackListener()
    obj:bindYesListener()
    obj:bindNoListener()
	obj:bindPanelUpdate()
	obj:activeEnterCounter()
	obj:bindExitEvent()
	AccountHelper:bind(kDefLayer,obj)
    return obj
end

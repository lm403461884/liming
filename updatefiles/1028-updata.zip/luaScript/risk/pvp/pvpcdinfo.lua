local kPanelLayer = "info_panel"
local kLblInfo = "lbl_info_1"
local kLblNotice = "lbl_info_2"
local kBtnBack = "btn_back"
local kPanelPrompt="prompt_layer"
local kBtnPvp = "btn_pvp"
local kImgBg = "img_bg"
local __promptlayer={}
function __promptlayer.init(obj,videoInfo)
	obj._videoInfo = videoInfo
	if obj._videoInfo then
		obj:egSetLabelStr(kLblInfo,TxtList.revengeInPK)
	end
	obj:showWithAction()
end

function __promptlayer.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __promptlayer.bindPvpListener(obj)
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		AccountHelper:lock(kStateSearchPvp)
		--更新PVP保护时间,扣减搜索PVP对手费用
		account_data.shellPvp = os.time()
		if obj._videoInfo then
			obj:egRemoveSelf()
			showRevengePreview(obj._videoInfo)
		else
			account_data.gold  = account_data.gold  - numDef.goldOfSearch 
			SendMsg[935001]()
			obj:egRemoveSelf()
			showPreviewPvp()
		end
    end
    obj:egBindTouch(kBtnPvp,nil,nil,touchEnded,nil)
end
function __promptlayer.hideWithAction(obj,callbackfunc)
    local function callback()
            AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.1,0))
    local actCallBack = CCCallFunc:create(callback)
    local scaleto = CCScaleTo:create(0.1,0)
    local squence = CCSequence:createWithTwoActions(scaleto,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kImgBg)
    baseWidget:runAction(squence)
end
function __promptlayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
	local baseWidget = obj:egGetWidgetByName(kImgBg)
    baseWidget:setScale(0)
    local scaleto = CCScaleTo:create(0.2,1)
    local backout = CCEaseBackOut:create(scaleto)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(backout,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(backout)
    end
end

PvpCDInfo={}
function PvpCDInfo.new(videoInfo,onloaded)
    local obj =  TouchWidget.new(JsonList.pvpPrompt)
    table_aux.unpackTo(__promptlayer, obj)
    obj._onloaded = onloaded
    obj:init(videoInfo)
    obj:bindBackListener()
    obj:bindPvpListener()
    return obj
end

function showPvpCDInfo(videoInfo,onloaded)
    local layer = PvpCDInfo.new(videoInfo,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
--��������
local kPanelLayer= "atk_panel"
local kPanelGo = "panel_go"
local kLblCount = "lbl_count"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnNo2 = "btn_no_2"
local kPanelConfirm = "giveup_panel"
--����/����
local kBtnSpeed ="btn_speed"
local kImgPlay = "img_play"
local kImgBarRight = "img_bar_right"

local kImgGiveUp = "img_giveup"
local kBtnBack = "btn_giveup"
local kImgChain = "img_chain_right"

--������Ч���
local kPanelSkill = "skill_panel"
local kImgEffect = "img_effect"
local kImgHead = "img_head"
--��������
local kBarConsume = "bar_consume"
local kImgConsume = "img_bar_bg"
local kLabelLeftCost = "lbl_consume"
local kLabelPerCost = "lbl_cost_val"
local kLabelPerCosts = "lbl_cost_val_s"
--С��Ӣ��
local kListHero = "hero_list"
--��������Ϣ
local kLabelAtk = "lbl_atk" --����������
local kAtkStars = {"star_atk_1","star_atk_2","star_atk_3"}
local kImgAtkBg = "atk_bg"
--���ط���Ϣ
local kLabelDef = "lbl_def" --���ط�����
local kDefStars = {"def_star_1","def_star_2","def_star_3"}
local kImgDefBg = "def_bg"

--������Ϣ
local kPanleBox = "box_list"
local kImgShelf = "img_shelf"

local kParticleSrc = "particle/battle/ExplodingRing.plist.png"
local kParticleReady = "particle/battle/skill_ready.plist"
local kParticleFire = "particle/battle/skill_fire.plist"

local kCounterNum0 = 20
local kCounterNum1 = 10
local kMaxDamage = 99999
local kMaxBoxNum = 6
local kHeroW = 156
local kParticleCap = 1200
local kOriginX = 220
local kMinSpeedScale = 1
local kMaxSpeedScale = 2
local kSecForFrame = 0.016
local kWarnPercent={100,50,15,0}
local kWarnS = {1.5,0.75,0.35,0.1}
local kWhiteColor = ccc3(255,255,255)
local kGreenColor = ccc3(0,128,0)
local kRedColor = ccc3(128,0,2)
local kGiveUpPos=ccp(1260,60)

local __pvplayer={}

function __pvplayer.init(obj,d_data,owner)
     obj._owner = owner
     obj._d_data = d_data
     obj._frameID = 0 --֡ID
	 obj._speedScale = kMinSpeedScale
	 obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMaxSpeedScale)],UI_TEX_TYPE_PLIST)
     obj._startTime = os.clock()
     obj._battleStoped = false
	 obj._useSkillCounter = nil
	 obj._warnLv = 1
     obj._usedConsume = 0 --�ܼ�������
     obj._enteredHeros = {} --�ѽ���ս����Ӣ��
     obj._unenteredHeros = {}--δ����ս����Ӣ��
     obj._heroHeads = {}
     obj._skillQueen = {}
     --obj._particleList = {}
     --����ս��˫��������Ϣ
     obj:loadBaseInfo()
     --����Ӣ��
     obj:loadHeroHeads()
	 
     obj:egShowWidget(kPanelGo)
     obj:activeEnterCounter(kCounterNum0)
     --
     obj:egHideWidget(kPanelSkill)
     obj:showConfirmGiveUp(false)
	 if obj._d_data.btFlag == 0 or obj._d_data.btFlag == 4 then --PVE���������Զ������
		obj:egShowWidget(kPanleBox)
		obj:bindGroundClickEvent()
	else
		obj:egHideWidget(kPanleBox)
		if obj._d_data.btFlag == 1 or obj._d_data.btFlag ==6 then --���˺͹���PVP����ʱ�رռ���
			obj:egHideWidget(kBtnSpeed)
			--obj:egHideWidget(kImgChain)
			--local widget = obj:egGetWidgetByName(kImgBarRight)
			--widget:setPosition(kGiveUpPos)
		end
	 end
	 local vipLv = account_data.vip or 0
	 if numDef.unlockSpeedUpLv > vipLv then
		obj:bindSpeedLockedListener()
	 else
		obj:bindSpeedUpListener()
	 end
end
function __pvplayer.loadBaseInfo(obj)
 --����������Ϣ
    obj:egSetBarPercent(kBarConsume,100)
    obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume)
    obj:egSetLabelStr(kLabelPerCost,"0/s")
    obj:egSetLabelStr(kLabelPerCosts,"0/s")
     --���ؽ���������
    obj:egSetLabelStr(kLabelAtk,obj._d_data.atkName)
     --���ط��ط�����
    obj:egSetLabelStr(kLabelDef,obj._d_data.dfsName)
	if obj._d_data.isDefencer then --�Ƿ��Ƿ�����
	    obj:egChangeImg(kImgAtkBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST) 
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
		--obj:egSetWidgetColor(kLabelAtk,kRedColor)
		--obj:egSetWidgetColor(kLabelDef,kGreenColor)
	else
	    obj:egChangeImg(kImgAtkBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST)
		--obj:egSetWidgetColor(kLabelDef,kRedColor)
		--obj:egSetWidgetColor(kLabelAtk,kGreenColor)
	end
end
function __pvplayer.collectAllBox(obj)
	local groundlayer = obj._owner._groundlayer
    local boxlayer = groundlayer._boxlayer
	local boxpanel = obj:egGetWidgetByName(kPanleBox)
	local boxlist = boxlayer:getAllBoxes()
	for idx=#boxlist,1,-1 do
		local boxitem = boxlist[idx]
		local boxtype = boxitem:getprop("boxType")
		obj:addBattleBoxNum(boxtype)
		boxitem:egRemoveSelf()
		table.remove(boxlist,idx)
	end
end
--�󶨳�������ص�����������ʹ�ã�
function __pvplayer.bindGroundClickEvent(obj)
    local groundlayer = obj._owner._groundlayer
    local shelfWidget = obj:egGetWidgetByName(kImgShelf)
    local shelfSize = shelfWidget:getSize()
    local boxlayer = groundlayer._boxlayer
	local boxpanel = obj:egGetWidgetByName(kPanleBox)
	local boxCount = 0
	local margin = 33
    local function clickCallback(idx,posx,posy)
        local boxitem = boxlayer:getBoxAt(idx)
		if boxitem then
		    boxCount = boxCount + 1
			local boxtype = boxitem:getprop("boxType")
			--local imgbox = obj:egGetWidgetByName(kImgBox[boxtype])
			local desx = 0
			local desy = 0
			if boxCount > 6 then
			     desx = boxpanel:getPositionX() + margin*(boxCount-6)+8
			     desy = boxpanel:getPositionY() + 40 + 28
			     shelfWidget:setSize(CCSizeMake(shelfSize.width,shelfSize.height+30))
			else
			     desx = boxpanel:getPositionX() + margin*boxCount+8
			     desy = boxpanel:getPositionY() + 40
			end
			obj:addBattleBoxNum(boxtype)
			obj:addBattleBox(boxtype,desx,desy,boxCount)
			boxlayer:removeBox(boxitem,desx - posx,desy-posy)
		end
    end
    groundlayer:onGroundClicked(clickCallback)
end
function __pvplayer.addBattleBox(obj,boxtype,posx,posy,count)
    local src = ImageList[string.format("comm_box_%s",KVariantList.boxType[boxtype])]
    local img = ImageView:create()
    img:loadTexture(src,UI_TEX_TYPE_PLIST)
   -- local sprite = CCSprite:createWithSpriteFrameName(src)
    local panelBox = obj:egGetWidgetByName(kPanleBox)
    img:setScale(0.25)
	if count <= kMaxBoxNum then
	    --obj:egAddChild(sprite,kMaxBoxNum-count,kMaxBoxNum-count)
	    panelBox:addChild(img,kMaxBoxNum-count,kMaxBoxNum-count)
	else
        --obj:egAddChild(sprite,kMaxBoxNum*2-count,kMaxBoxNum*2-count)
        panelBox:addChild(img,kMaxBoxNum*2-count,kMaxBoxNum*2-count)
    end    
    img:setPosition (ccp(posx,posy))
end

function __pvplayer.addBattleBoxNum(obj,boxtype)
	obj._d_data.battleBoxCnt = obj._d_data.battleBoxCnt + 1
	local awardRes = baseCalc.treasureBox(account_data,boxtype)
	
	local valnum = awardRes[3] or 0
	local awardtype = awardRes[1] or 0
	local subtype = awardRes[2] or 0
	if awardtype == 1 then
		local cointype = KVariantList.coinType[subtype]
		battleProgress.gainRes[cointype] = (battleProgress.gainRes[cointype] or 0 ) + valnum
	elseif awardtype == 2 then
		battleProgress.gainHeroMsg[subtype] = (battleProgress.gainHeroMsg[subtype] or 0) + valnum
	elseif awardtype == 3 then
		table.insert(battleProgress.gainEquip,equipFuncs.getSubEquipId(subtype,valnum,equipFuncs.getSubEquipCfg(subtype,"quality")))
	end	
	table.insert(obj._d_data.battleBox[boxtype],awardRes)
end
--�볡����ʱ
function __pvplayer.activeEnterCounter(obj,counter)
    local passed = 0
    local leftNum = counter
    local function callback(delta)
        passed = passed + kSecForFrame*obj._speedScale
        leftNum = counter - math.floor(passed)
        if leftNum <= 0 then
            obj:egUnbindWidgetUpdate(kLblCount)
            obj:egHideWidget(kPanelGo)
            local heroHead = obj._unenteredHeros[1]
			if heroHead then heroHead:enterBattle() end
        end
        obj:egSetLabelStr(kLblCount,leftNum )
    end
    obj:egBindWidgetUpdate(kLblCount,callback)
end
--���ٺ���Զ��볡
function __pvplayer.activeAutoEnter(obj)
    local function callback(delta)
		local leftCnt =  #obj._unenteredHeros
		if  leftCnt<= 0  then
			--����Ӣ�۶��Ѿ��볡
			obj:egUnbindWidgetUpdate(kLblCount)
		else
			local heroHead = obj._unenteredHeros[1]
			if heroHead then heroHead:enterBattle() end
		end
    end
	obj:egUnbindWidgetUpdate(kLblCount)
    obj:egBindWidgetUpdate(kLblCount,callback)
end
--����ս��,����ʱʹ��
function __pvplayer.enterBattle(obj,heroObj)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local x,y = creaturelayer:getPosByIdx(heroObj:getprop("birthPlace"))
    local function callback2()
        if heroObj:egNode() then heroObj:openAi() end
    end
    heroObj:moveToPos(ccp(x,y),callback2)
end
--����Ӣ��ͷ��
function __pvplayer.loadHeroHeads(obj)
    local teamCnt = #obj._d_data.teamList
    local heroPanel = obj:egGetWidgetByName(kListHero)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
	local cnt = #creaturelayer._heros
    for key,heroObj in ipairs(creaturelayer._heros) do
        local heroHead = BattleHero.new(heroObj)
        heroPanel:addChild(heroHead:egNode())
        table.insert(obj._unenteredHeros,heroHead)
        obj._heroHeads[heroObj:getprop('type')] = heroHead 
        obj:bindHeroEntering(heroHead)
        obj:bindHeroActived(heroHead)
        obj:bindHeroDied(heroHead)
        obj:bindHeroSkillReady(heroHead)
        obj:bindHeroUsingSkill(heroHead)
    end
    local size = heroPanel:getSize()
    obj._heroPanelW = size.width
    local newW = kHeroW*teamCnt
    heroPanel:setSize(CCSizeMake(newW,size.height))
    heroPanel:setPosition(ccp((obj._heroPanelW-newW)/2 + kOriginX,0))
end
function __pvplayer.addHeroHead(obj,heroObj)
	local heroPanel = obj:egGetWidgetByName(kListHero)
	local heroHead = BattleHero.new(heroObj)
    heroPanel:addChild(heroHead:egNode())
	if heroObj:getprop("aiActived") then
		table.insert(obj._enteredHeros,heroHead)
	else
		table.insert(obj._unenteredHeros,heroHead)
	end
    obj._heroHeads[heroObj:getprop('type')] = heroHead
    obj:bindHeroEntering(heroHead)
    obj:bindHeroActived(heroHead)
    obj:bindHeroDied(heroHead)
    obj:bindHeroSkillReady(heroHead)
    obj:bindHeroUsingSkill(heroHead)
	local size = heroPanel:getSize()
	local newW = size.width + kHeroW
    heroPanel:setSize(CCSizeMake(newW,size.height))
	heroPanel:stopAllActions()
	heroPanel:runAction(CCMoveTo:create(0.5,ccp((obj._heroPanelW-newW)/2 + kOriginX,0)))
end
--Ӣ��׼���볡�ص�����
function __pvplayer.bindHeroEntering(obj,heroHead)
    local function callback(sender)
		if obj._speedScale == kMinSpeedScale then obj:egUnbindWidgetUpdate(kLblCount) end
        obj:egHideWidget(kPanelGo)
        table.insert(battleProgress.heroEnterFrame,sender:getHeroID())
        table.insert(battleProgress.heroEnterFrame,obj._frameID)
        --��Ӣ�������ѽ���ս���б�
        for key ,item in ipairs(obj._unenteredHeros) do
            if item == sender then
                table.remove(obj._unenteredHeros,key)
            end
        end
        table.insert(obj._enteredHeros,sender)
    end
    heroHead:onHeroEntering(callback)
    
end
--Ӣ�ۿ���AIǰ�Ļص�����
function __pvplayer.bindHeroActived(obj,heroHead)
    local function callback(sender)
        table.insert(battleProgress.heroCreatedFrame,sender:getHeroID())
        table.insert(battleProgress.heroCreatedFrame,obj._frameID)
    end
     heroHead:onHeroActived(callback)
end
--Ӣ�������ص�����
function __pvplayer.bindHeroDied(obj,heroHead)
    local function callback(sender)
        for key,item in ipairs(obj._enteredHeros) do
            if item == sender then
                table.remove(obj._enteredHeros,key)
                break
            end
        end
        if #obj._unenteredHeros>0 and #obj._enteredHeros== 0 then
            obj:activeEnterCounter(kCounterNum1)
        end
    end
    heroHead:onHeroDied(callback)
end
--Ӣ�ۼ���׼����ɻص�����
function __pvplayer.bindHeroSkillReady(obj,heroHead)
    local function callback(sender)
        local particle = CCParticleSystemQuad:create(kParticleReady)
		particle:setAutoRemoveOnFinish(true)
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
    end
    heroHead:onSkillReady(callback)
end
function __pvplayer.doUseHeroSkill(obj,heroObj)
	if heroObj and heroObj:egNode() then
		local heroHead = obj._heroHeads[heroObj:getprop('type')]
		heroHead:doUseSkill()
	end
end
--Ӣ��ʹ�ü���ǰ�Ļص�����
function __pvplayer.bindHeroUsingSkill(obj,heroHead)
    local function callback(sender)
		local heroid = sender:getHeroID()
		if battleProgress.skillUsageFrame[heroid] then
			table.insert(battleProgress.skillUsageFrame[heroid],obj._frameID)
		else
			battleProgress.skillUsageFrame[heroid] = {obj._frameID}
		end
		table.insert(obj._skillQueen,sender)
		local particle = CCParticleSystemQuad:create(kParticleFire)
		particle:setAutoRemoveOnFinish(true)
		obj._particlelayer:addChild(particle,0)
		local objX = sender:egNode():getPositionX()
		local offsetx = sender:egNode():getSize().width/2
		local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
		particle:setPosition(ccp(objX+panelX+offsetx,78))
			
		obj:egShowWidget(kPanelSkill)
		obj:egChangeImg(kImgHead,hero_data.getConfig(heroid).skillHeadPic,UI_TEX_TYPE_PLIST)
		local img = obj:egGetWidgetByName(kImgEffect)
		img:setScaleX(0)
		img:stopAllActions()
		local scaleto = CCScaleTo:create(0.5,1)
		local expOut = CCEaseExponentialOut:create(scaleto)
		img:runAction(expOut)
		obj._useSkillCounter = 1.0 --�ͷż��ܵ���ʱ
    end
    heroHead:onUsingSkill(callback)
end
--��ʾ�Ǽ����
function __pvplayer.showStarChange(obj,stars)
    if stars ~= battleProgress.stars  then 
        for idx = battleProgress.stars + 1,stars do
            local star1 = obj:egGetWidgetByName(kDefStars[idx])
            local star2 = obj:egGetWidgetByName(kAtkStars[idx])
            local blink1 = CCBlink:create(0.5,5)
            local blink2 = CCBlink:create(0.5,5)
            local function callbackfunc1()
                obj:egChangeImg(kDefStars[idx],ImageList.lvup_starnull,UI_TEX_TYPE_PLIST)
				obj:egGetWidgetByName(kDefStars[idx]):setScale(0.4)
            end
            local function callbackfunc2()
                obj:egChangeImg(kAtkStars[idx],ImageList.lvup_star,UI_TEX_TYPE_PLIST)
				obj:egGetWidgetByName(kAtkStars[idx]):setScale(0.5)
            end
            local action_callback1 = CCCallFuncN:create(callbackfunc1)
            local action_callback2 = CCCallFuncN:create(callbackfunc2)
            local sequence1 = CCSequence:createWithTwoActions(blink1,action_callback1)
            local sequence2 = CCSequence:createWithTwoActions(blink2,action_callback2)
            star1:runAction(sequence1)
            star2:runAction(sequence2)
        end
         battleProgress.stars  = stars
    end
end

--��ȡ�����ѽ���ӵ���Ӣ�۵�����ֵ�ܺ�
function __pvplayer.getTotalConsume(obj)
    local val = 0
    for idx,hero in pairs(obj._heroHeads) do
        val = val + hero:getTotalConsume()
    end
    if val > obj._d_data.consume then val = obj._d_data.consume end
    return val
end
--��ȡ�ܼ�ÿ������
function __pvplayer.getPerConsume(obj)
    local val = 0
    for idx,hero in ipairs(obj._enteredHeros) do
        val = val + hero:getConsume()
    end
    return val
end
--�ж����Ƿ�������
function __pvplayer.isTimeOut(obj)
   local perConsume = obj:getPerConsume()
   obj:egSetLabelStr(kLabelPerCost,string.format("%d%s",perConsume,"/s"))
   obj:egSetLabelStr(kLabelPerCosts,string.format("%d%s",perConsume,"/s"))
   local usedConsume = obj:getTotalConsume()
   if usedConsume == obj._d_data.consume then
       obj:killAllHeros()
       return true
   else
       if obj._usedConsume ~= usedConsume then
            obj._usedConsume = usedConsume
            local percent =math.max(100- usedConsume*100/obj._d_data.consume,0)
            obj:egSetBarPercent(kBarConsume,percent)
            obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume - obj._usedConsume)
			if  percent < kWarnPercent[obj._warnLv] then
				print(kWarnPercent[obj._warnLv],obj._warnLv)
				local widget = obj:egGetWidgetByName(kBarConsume) 
				local s = kWarnS[obj._warnLv]
				local sequence = CCSequence:createWithTwoActions(CCTintTo:create(s,255,0,0),CCTintTo:create(s,255,255,255))
				widget:stopAllActions()
				widget:setColor(kWhiteColor)
				widget:runAction(CCRepeatForever:create(sequence))
				obj._warnLv = obj._warnLv + 1
			end
       end
       return false
   end
end
--�ж���Դ���Ƿ����
function __pvplayer.isResCarClear(obj)
	if obj._d_data.bossCnt then return false end --BOSS�ؿ�ֱ�ӷ���false
	local totalCount = #obj._d_data.collectorList
	local gainCount = #battleProgress.collector
	local stars = math.floor(gainCount / totalCount * numDef.starsPerStage)
	if gainCount > 0 and stars == 0 then
		stars = 1
	end
    obj:showStarChange(stars)
	if gainCount == totalCount  then
		return true
	else
		return false
	end
end
--���������������£�����Ӣ����������
function __pvplayer.killAllHeros(obj)
    for _,heroid in ipairs(obj._d_data.teamList) do
        obj._heroHeads[heroid]:killHero()
        if not battleProgress.heroDamage[heroid] then
            battleProgress.heroDamage[heroid] = {kMaxDamage,os.time()}
        else
            table.insert( battleProgress.heroDamage[heroid],kMaxDamage)
            table.insert( battleProgress.heroDamage[heroid],os.time())
        end
    end
    obj._enteredHeros={}
    obj._unenteredHeros={}
    obj:egUnbindWidgetUpdate(kLblCount)
end
--�ж�Ӣ���Ƿ�����
function __pvplayer.isHeroClear(obj)
    if #obj._enteredHeros==0 and #obj._unenteredHeros==0 then 
        return true
    else
        return false
    end
end
--����BOSS�����������������
function __pvplayer.updateStarByBossCnt(obj)
	if obj._d_data.bossCnt then
		local deadCnt = #battleProgress.collector
		local stars = math.floor(deadCnt / obj._d_data.bossCnt * numDef.starsPerStage)
		if deadCnt > 0 and stars == 0 then
			stars = 1
		end
		obj:showStarChange(stars)
	end
end
--����ս��
function __pvplayer.stopBattle(obj)
	if obj._battleStoped then return end
    ai_module.clear()
	obj:egGetWidgetByName(kBarConsume):stopAllActions()
	CCDirector:sharedDirector():getScheduler():setTimeScale(kMinSpeedScale)
	obj:collectAllBox()
	obj:saveCreatureInfo()
    obj._battleStoped = true
	AccountHelper:lock(kStateBpResult)
    obj:egSetWidgetTouchEnabled(kBtnBack,false)
    obj:showConfirmGiveUp(false)
    battleProgress.endTime = os.time()
    battleProgress.frameCnt = obj._frameID
    obj:egUnbindWidgetUpdate(kPanelLayer)
    if battleProgress.stars > 0 then
	   SoundHelper.playBGMOnce(SoundList.battleWin)
    else
	   SoundHelper.playBGMOnce(SoundList.battleLose)
    end
    
    obj._d_data.oldheroList = obj:copyHeroData()--���ƽ�ս��ǰӢ������
    obj._owner:stopBattle() --�ص�����������stopBattle����
    obj:egHideWidget(kBtnBack)
    obj:egHideWidget(kImgBarRight)
	obj:egHideWidget(kImgChain)
	obj:egHideWidget(kBtnSpeed)
end
function __pvplayer.copyHeroData(obj)
   local herolist ={}
    for heroid,item in pairs(obj._d_data.heroList) do
         local heroHead = obj._heroHeads[heroid]
         if heroHead then --�ų�heroList��û����Team��Ӣ��
            local tb =Funs.copy(item)
             tb.curhp = heroHead:getHP()
			 herolist[heroid] = tb
         end
    end
    return herolist
end
--��¼Զ������ս����ʣ��ֺ�Ӣ����Ϣ
function __pvplayer.saveCreatureInfo(obj)
	if obj._d_data.btFlag == 4 then
		for heroid,heroHead in pairs(obj._heroHeads) do
			account_data.expedition[heroid] = RiskHelper.calHPPower(heroHead:getHP(),heroHead:getPower())
			table.insert(battleProgress.heroHpPower,heroid)
			table.insert(battleProgress.heroHpPower,account_data.expedition[heroid])
		end
		for idx,pos in ipairs(battleProgress.monsterDeath) do
			account_data.exMission.creatureList[pos] = nil
		end
	end
end
--���ط�����ť
function __pvplayer.hideGiveUp(obj,hide)
    if hide then
        obj:egHideWidget(kBtnBack)
        obj:egHideWidget(kImgBarRight)
    else
        obj:egShowWidget(kBtnBack)
        obj:egHideWidget(kImgBarRight)
    end
end
--��ʾ�������
function __pvplayer.showConfirmGiveUp(obj,show)
    if show then
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        --obj:egShowWidget(kBtnNo2)
        obj:egShowWidget(kPanelConfirm)
    else
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
       -- obj:egHideWidget(kBtnNo2)
        obj:egHideWidget(kPanelConfirm)
    end
end
function __pvplayer.clearUsedSkill(obj)
	if obj._useSkillCounter  then
		if obj._useSkillCounter > 0 then
			obj._useSkillCounter = obj._useSkillCounter - kSecForFrame
		else
			obj._useSkillCounter = nil
			obj:egHideWidget(kPanelSkill)
            for idx = #obj._skillQueen,1,-1 do
                obj._skillQueen[idx]:afterUseSkill()
                table.remove(obj._skillQueen,idx)
            end
		end
	end
end
function __pvplayer.bindPanelUpdate(obj)
    local  function callback()
		for idx=1,obj._speedScale do
			if obj._battleStoped then return end
			if #obj._skillQueen== 0 then ai_module.update() end
			obj._frameID = obj._frameID + 1
			obj:clearUsedSkill()
			obj:updateStarByBossCnt()
			if obj:isTimeOut() then 
				obj:stopBattle()
			elseif obj:isResCarClear() then
				obj:stopBattle()
			elseif obj:isHeroClear() then
				obj:stopBattle()
			end
			if obj._d_data.btFlag == 6 then
				if not obj._d_data.clubInWar or(club_data and not club_data.warData and club_data.lastWarResult) then
					obj._d_data.clubInWar = false
					obj:stopBattle()
				end
			end
		end
    end
    obj:egBindWidgetUpdate(kPanelLayer,callback)
end
--����
function __pvplayer.bindBackListener(obj)
     local function touchBegan()
         obj:egSetWidgetScale(kImgGiveUp,1)
     end
     local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        obj:egSetWidgetScale(kImgGiveUp,0.9)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:showConfirmGiveUp(true)
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgGiveUp,0.9)
    end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
--ȷ�Ϸ���
function __pvplayer.bindYesListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
        if not obj._battleStoped  then
            obj:killAllHeros() --����ֱ��KILL����Ӣ��
        end
    end
     obj:egBindTouch(kBtnYes,nil,nil,touchEnded,nil)
end
--ȡ������
function __pvplayer.bindNoListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:egSetWidgetTouchEnabled(kBtnBack,true)
    end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,nil)
end
--ȡ������
function __pvplayer.bindNo2Listener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:egSetWidgetTouchEnabled(kBtnBack,true)
    end
    obj:egBindTouch(kBtnNo2,nil,nil,touchEnded,nil)
end
function __pvplayer.bindSpeedUpListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgPlay,1.1)
    end
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		obj:egSetWidgetScale(kImgPlay,1)
		if not obj._battleStoped then
			if obj._speedScale == kMaxSpeedScale then --ȡ������
				obj:egUnbindWidgetUpdate(kLblCount) --ȡ���Զ�����ӵ�
				obj._speedScale = kMinSpeedScale
				obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMaxSpeedScale)],UI_TEX_TYPE_PLIST)
				for key,herohead in pairs(obj._heroHeads) do
					herohead:autoUseSkill(false)
				end
			else --����
				obj._speedScale = kMaxSpeedScale
				obj:egChangeImg(kImgPlay,ImageList[string.format("comm_speed_%d",kMinSpeedScale)],UI_TEX_TYPE_PLIST)
				for key,herohead in pairs(obj._heroHeads) do
					herohead:autoUseSkill(true)
				end
				obj:activeAutoEnter() --����ʱ�Զ�����ӵ�
			end
			
			CCDirector:sharedDirector():getScheduler():setTimeScale(obj._speedScale)
		end
		sender:setTouchEnabled(true)
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgPlay,1)
    end
     obj:egBindTouch(kBtnSpeed,touchBegan,nil,touchEnded,touchCanceled)
end
function __pvplayer.bindSpeedLockedListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgPlay,1.1)
    end
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		obj:egSetWidgetScale(kImgPlay,1)
		 local text = string.format("%s LV%d",TxtList.needVIP,numDef.unlockSpeedUpLv)
		 showPopTxt(text,sender:getPositionX(),sender:getPositionY() + sender:getSize().height/2,ccp(0,0.5))
		sender:setTouchEnabled(true)
    end
    local function touchCanceled()
        obj:egSetWidgetScale(kImgPlay,1)
    end
     obj:egBindTouch(kBtnSpeed,touchBegan,nil,touchEnded,touchCanceled)
end
function __pvplayer.bindExitEvent(obj)
	local function clear()
		ai_module.clear()
		obj:egNode():removeAllChildrenWithCleanup(true)
	end
     obj:egOnExit(clear)
end
PvpLayer={}
function PvpLayer.new(d_data,owner)
    local obj = TouchWidget.new(JsonList.atkLayer)
	obj._particlelayer =  CCParticleBatchNode:create(kParticleSrc,kParticleCap)
	obj:egAddChild(obj._particlelayer,1,1)
    table_aux.unpackTo(__pvplayer, obj)
    obj:init(d_data,owner)
    obj:bindBackListener()
    obj:bindYesListener()
    obj:bindNoListener()
    --obj:bindNo2Listener()
	obj:bindPanelUpdate() 
	obj:bindExitEvent()
	AccountHelper:bind(kAtkLayer,obj)
    return obj
end

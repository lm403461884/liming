local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local kDefMark = 1

local __defpvpscene={}
function __defpvpscene.init(obj,pidIdx)
    obj._d_data = RiskHelper.getDefPvpSceneData(pidIdx)
    obj._groundlayer = GroundLayer.new(obj._d_data,kDefMark)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._deflayer = DefPvpLayer.new(obj._d_data,obj)
        obj._deflayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInDefPvpScene()
	obj._groundlayer:onHeroShown(callback)
end
function __defpvpscene.stopBattle(obj)
    SendMsg[9313006](obj._d_data.tid,obj._d_data.bp,battleProgress.stars)
    --table.remove(defaccount_data,obj._d_data.stageid)
    BPResult ={}
    BPResult.stars =  battleProgress.stars
    local gainStar = numDef.starsPerStage - BPResult.stars
	if gainStar > 0 then  DefTaskHelper.removeTeam(obj._d_data.stageid) end
    local awardRes = RiskHelper.getDefPvpAwardRes(account_data,obj._d_data.bp,gainStar)
	for key,val in pairs(awardRes) do
		BPResult[key] = math.floor(val * gainStar /numDef.starsPerStage)
		account_data[key] = account_data[key] + BPResult[key]
	end
    obj._scoreLayer= BattleResultLayer.new(obj._d_data,kDefMark)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end
DefPvpScene={}
function DefPvpScene.new(pidIdx)
    SoundHelper.playBGM(SoundList.def_bgm)
    local obj = {}
    obj._kind = kind
    Scene.install(obj)
    table_aux.unpackTo(__defpvpscene,obj)
    obj:init(pidIdx)
    --showEmDialog(obj,GuideScene.def.kAtkScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)

    return obj
end

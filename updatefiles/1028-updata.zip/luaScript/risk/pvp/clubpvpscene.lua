local kGroundOrder = 1
local kAtkOrder = 2
local kScoreOrder = 6
local __clubpvpscene={}
function __clubpvpscene.init(obj,areaid,stageid)
	 SendMsg[9311009]()
    obj._d_data = RiskHelper.getClubPvpSceneData()
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._pvplayer = PvpLayer.new(obj._d_data,obj)
        obj._pvplayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene(battleProgress.startTime)
    obj._groundlayer:onHeroShown(callback)
end
function __clubpvpscene.stopBattle(obj)
	if obj._d_data.clubInWar then
		BPResult ={}
		BPResult.stars =  battleProgress.stars 
		BPResult.gold,BPResult.jewel,BPResult.iron,BPResult.copper,BPResult.stoneR,BPResult.stoneB,BPResult.stoneD,BPResult.honor = baseCalc.SocietyWarPrize(account_data,BPResult.stars,obj._d_data.defencer.stars,obj._d_data.defencer.digLv)
		if BPResult.stars > obj._d_data.defencer.stars then
			obj._d_data.defencer.stars = BPResult.stars
		end
		SendMsg[9311004](battleProgress)
		AccountHelper:unlock(kStateBpResult)
		for key,coinname in pairs(KVariantList.coinType) do
			account_data[coinname] = account_data[coinname] + (BPResult[coinname] or 0)
		end
		if club_data  then
			local attacker = club_data.members[account_data.guid]
			if attacker then
				attacker.honor = attacker.honor + BPResult.honor
				attacker.atkCount = math.max(attacker.atkCount - 1,0)
			end
		end
		obj._scoreLayer= BattleResultLayer.new(obj._d_data)
		obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
	else
		 showGvgResultLayer(0)
	end
end

ClubPvpScene={}
function ClubPvpScene.new()
    SoundHelper.playBGM(SoundList.atk_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__clubpvpscene, obj)
    obj:init()
   -- showEmDialog(obj,GuideScene.def.kClubPvpScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
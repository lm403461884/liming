local kImgCoin = "img_coin"
local kLblVal = "lbl_coin_val"
local __imgpropitem = {}
function __imgpropitem.init(obj,name,val)
    local imgsrc = ImageList[string.format("comm_%s",name)]
    obj:egChangeImg(kImgCoin,imgsrc,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblVal,val)
end
function __imgpropitem.setTxtColor(obj,color)
    obj:egSetWidgetColor(kLblVal,color)
end
ImgPropItem={}
function ImgPropItem.new(name,val)
    local obj = {}
    CocosWidget.install(obj,JsonList.imgProp)
    table_aux.unpackTo(__imgpropitem, obj)
    obj:init(name,val)
    return obj
end

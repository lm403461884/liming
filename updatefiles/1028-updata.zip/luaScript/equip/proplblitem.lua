local kLblName = "lbl_prop_txt"
local kLblOld = "lbl_prop_old"
local kLblNew = "lbl_prop_new"
local kRedColor = ccc3(128,0,2)
local kGreenColor = ccc3(0,128,0)
local kBrownColor = ccc3(83,49,22)

local __proplblitem = {}
function __proplblitem.init(obj,prop,val_old,val_new)
	obj._propname = prop
	obj._oldVal = val_old
    obj:egSetLabelStr(kLblName,TxtList.propName[prop]..":")
	obj:formatAndShowVal(kLblOld,val_old)
	obj:formatAndShowVal(kLblNew,val_new)
	if val_new > val_old then
		obj:egSetWidgetColor(kLblNew,kGreenColor)
	elseif val_new < val_old  then
		obj:egSetWidgetColor(kLblNew,kRedColor)
	else
		obj:egSetWidgetColor(kLblNew,kBrownColor)
	end
end
function __proplblitem.setNewVal(obj,val_new)
    obj:formatAndShowVal(kLblNew,val_new)
	if val_new > obj._oldVal then
		obj:egSetWidgetColor(kLblNew,kGreenColor)
	elseif val_new < obj._oldVal  then
		obj:egSetWidgetColor(kLblNew,kRedColor)
	else
		obj:egSetWidgetColor(kLblNew,kBrownColor)
	end
end
function __proplblitem.formatAndShowVal(obj,widgetName,val)
	if obj._propname == "critical" or obj._propname == "dodge" then
		obj:egSetLabelStr(widgetName,string.format("%0.1f%s",val/10,"%")) 
	else
		obj:egSetLabelStr(widgetName,val) 
	end
end
function __proplblitem.getWidth(obj)
	local lbl = obj:egGetWidgetByName(kLblNew)
	local w = lbl:getSize().width + lbl:getPositionX()
	return w
end
PropLblItem={}
function PropLblItem.new(prop,val_old,val_new)
    local obj = {}
    CocosWidget.install(obj,JsonList.propLblItem)
    table_aux.unpackTo(__proplblitem, obj)
    obj:init(prop,val_old,val_new)
    return obj
end

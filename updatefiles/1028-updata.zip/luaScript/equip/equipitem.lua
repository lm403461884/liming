local kImgBg = "img_equip_b"
local kImgSelected = "img_equip_s"
local kImgItem = "img_item"
local kImgAdd = "img_add"
local kLblLv = "lbl_lv"
local kImgLv = "img_lv"
local kImgColorBg = "img_color_bg"
local kImgColorBar = "img_light_bar"
local kLblCnt = "lbl_cnt"
local __equipitem={}
--������Ҫ��ʾ������ID
function __equipitem.init(obj,equipid,heroid,equipPos)
	obj:egHideWidget(kImgSelected)
	obj:egHideWidget(kLblCnt) --Ӣ�����ϵ�װ��������ʾ����
	obj:addprop("heroid",heroid)
	obj:setEquipID(equipid,equipPos)
end
function __equipitem.updateWithAction(obj,equipid,equipPos)
	local oldeid = obj:getprop("equipid")
	obj:setEquipID(equipid,equipPos)
	if oldeid ~= equipid then
		local widget = obj:egGetWidgetByName(kImgItem)
		local imgbar = obj:egGetWidgetByName(kImgColorBar)
		if oldeid ~=0 and equipid == 0 then
			widget:setScale(0.72)
			widget:setVisible(true)
			imgbar:setVisible(true)
			imgbar:setScale(1.1)
			imgbar:setOpacity(255)
			obj:egHideWidget(kImgAdd)
			local scaleto = CCScaleTo:create(0.8,1)
			local fadeout = CCFadeOut:create(0.8)
			local function callback()
				obj:egShowWidget(kImgAdd)
				widget:setVisible(false)
			end
			local callfunc = CCCallFunc:create(callback)
			widget:runAction(CCSequence:createWithTwoActions( CCScaleTo:create(0.5,0),callfunc))
			imgbar:runAction(CCSequence:createWithTwoActions(scaleto,fadeout))
		else
			widget:setScale(0)
			imgbar:setVisible(true)
			imgbar:setScale(1)
			imgbar:setOpacity(255)
			local scaleto = CCScaleTo:create(1,1.1)
			local fadeout = CCFadeOut:create(1)
			local backout = CCEaseBackOut:create(CCScaleTo:create(1,0.72))
			widget:runAction(backout)
			imgbar:runAction(CCSequence:createWithTwoActions(scaleto,fadeout))
		end
	end
end
function __equipitem.setEquipID(obj,equipid,equipPos)
    obj._equipid = equipid
	obj._equipPos = equipPos
    obj:addprop("equipid",equipid)
	obj:addprop("equipPos",equipPos)
    if not obj._equipid or obj._equipid == 0 then  
        obj:egShowWidget(kImgAdd)
		obj:egHideWidget(kImgLv)
		obj:egHideWidget(kImgItem)
		obj:egHideWidget(kImgColorBg)
		obj:egHideWidget(kImgColorBar)
    else
		obj:egHideWidget(kImgAdd)
		obj:egShowWidget(kImgLv)
		obj:egShowWidget(kImgItem)
		obj:egShowWidget(kImgColorBg)
		obj:egHideWidget(kImgColorBar)
		if obj._equipPos then
			obj:loadAuxEquip()
		else
			obj:loadEquip()
		end
	end
end
function __equipitem.loadEquip(obj)
	 --�����ȼ���Ʒ��
     obj._curlv,obj._curqa = equipFuncs.getEquipQL(obj._equipid, account_data)
	 obj:addprop("curLv",obj._curlv)
	 obj:addprop("curQa",obj._curqa)
     local s_cfg = equipCfg[obj._equipid]
     obj:egChangeImg(kImgItem,s_cfg.icon,UI_TEX_TYPE_PLIST)
     obj:egSetBMLabelStr(kLblLv,obj._curlv) --��ʾ�����ȼ�
     --��ʾ����Ʒ��
	obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[obj._curqa])
	obj:egSetWidgetColor(kImgColorBar,KVariantList.equipColor[obj._curqa])
end
function __equipitem.loadAuxEquip(obj)
	obj._subid,obj._curlv,obj._seed,obj._curqa = Funs.deComposeInt(obj._equipid,256,4)
	obj:addprop("curLv",obj._curlv)
	obj:addprop("subid",obj._subid)
	obj:addprop("curQa",obj._curqa)
     obj:egChangeImg(kImgItem,equipFuncs.getSubEquipCfg(obj._subid,"icon"),UI_TEX_TYPE_PLIST)
	 obj:egSetBMLabelStr(kLblLv,obj._curlv) --��ʾ�����ȼ�
     --��ʾ����Ʒ��
	obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[obj._curqa])
	obj:egSetWidgetColor(kImgColorBar,KVariantList.equipColor[obj._curqa])
end
function __equipitem.showWithAction(obj)
	local widget = obj:egGetWidgetByName(kImgItem)
	widget:setScale(0)
	local scaleto = CCScaleTo:create(0.5,0.72)
	local backout = CCEaseBackOut:create(scaleto)
	widget:runAction(backout)
	local imgbar = obj:egGetWidgetByName(kImgColorBar)
	imgbar:setVisible(true)
	imgbar:setScale(1.1)
	imgbar:setOpacity(255)
	local scaleto = CCScaleTo:create(0.3,1)
	local fadeout = CCFadeOut:create(0.3)
	imgbar:runAction(CCSequence:createWithTwoActions(scaleto,fadeout))
end
function __equipitem.setSelected(obj,selected)
	obj._selected = selected
	if selected then
		obj:egShowWidget(kImgSelected)
		obj:selectedAction(true)
	else
		obj:egHideWidget(kImgSelected)
		obj:selectedAction(false)
	end
end
function __equipitem.selectedAction(obj,show)
    if not obj._selectedState then
        local img_equips = obj:egGetWidgetByName(kImgSelected)
        local btnSize = img_equips:getSize()
        local img = ImageView:create()
        img:loadTexture(ImageList.comm_blank,UI_TEX_TYPE_PLIST)
        img:setPosition(ccp(0,0))
        img_equips:addChild(img,3,3)
        obj._sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite") 
        obj._selectedState = true
    end    
	if show and not obj._showAnimation then
	    obj._showAnimation = true
		local anima = graphicLoader.getAnimation("selected_state_act")
		anima:setRestoreOriginalFrame(true)
		local animate = CCAnimate:create(anima)
		local action = CCRepeat:create(animate,1000000)
		obj._sprite:setVisible(true)
		obj._sprite:runAction(action) 
		print("runAnimation--------------",obj._equipid)
	elseif not show then
		obj._sprite:stopAllActions()
		obj._sprite:setVisible(false)
		obj._showAnimation = false
		print("stopAnimation--------------",obj._equipid)
		--img_equips:removeChildByTag(3,true)
	end
end
--�󶨵���¼�
function __equipitem.onClicked(obj,callback)
    obj._clickCallback = callback
end
function __equipitem.getTouchPos(obj)
	return obj._touchEndPos
end
function __equipitem.bindClickListener(obj)
    local function touchBegan(sender)
		obj:egGetWidgetByName(kImgAdd):setScale(0.9)
		obj:egShowWidget(kImgSelected)
	end
    local function touchEnded(sender)
		obj:egGetWidgetByName(kImgAdd):setScale(0.8)
		if not obj._selected then obj:egHideWidget(kImgSelected) end
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj._touchEndPos = sender:getTouchEndPos()
		if obj._clickCallback then obj._clickCallback(obj) end
		sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		obj:egGetWidgetByName(kImgAdd):setScale(0.8)
		if not obj._selected then obj:egHideWidget(kImgSelected) end
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		end
    end
    obj:egBindTouch(kImgBg,touchBegan,nil,touchEnded,touchCanceled)
end
EquipItem={}
function EquipItem.new(equipid,heroid,equipPos)
    local obj = {}
    CocosWidget.install(obj,JsonList.equipItem)
    table_aux.unpackTo(__equipitem, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(equipid,heroid,equipPos)
    obj:bindClickListener()
    return obj
end
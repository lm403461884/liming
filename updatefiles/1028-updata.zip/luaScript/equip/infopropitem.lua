local kLblName = "lbl_name"
local kLblVal = "lbl_val"
local kLblValUp = "lbl_val_up"
local __infopropitem = {}
function __infopropitem.init(obj,name,val,valup)
	obj._name = name
    obj:egSetLabelStr(kLblName,TxtList.propName[name]..":")
    if valup then 
		obj:formatAndShowVal(kLblVal,val)
		obj:formatAndShowVal(kLblValUp,valup)
		local lbl = obj:egGetWidgetByName(kLblVal)
		local w = lbl:getSize().width
		local lblup = obj:egGetWidgetByName(kLblValUp)
		lblup:setPosition(ccp(lbl:getPositionX() + w + 5,lblup:getPositionY()))
    else
		obj:formatAndShowVal(kLblVal,val)
        obj:egHideWidget(kLblValUp)
		local lbl1 = obj:egGetWidgetByName(kLblName)
		local lbl2 = obj:egGetWidgetByName(kLblVal)
		lbl2:setPosition(ccp(lbl1:getPositionX() + lbl1:getSize().width + 20,lbl2:getPositionY()))
    end
end
function __infopropitem.blinkValUp(obj,val,valup)
    local lbl = obj:egGetWidgetByName(kLblValUp)
    local blink = CCBlink:create(1,3)
    local function callback()
		 if valup then 
			obj:formatAndShowVal(kLblVal,val)
			obj:formatAndShowVal(kLblValUp,valup)
			local lbl = obj:egGetWidgetByName(kLblVal)
			local w = lbl:getSize().width
			local lblup = obj:egGetWidgetByName(kLblValUp)
			lblup:setPosition(ccp(lbl:getPositionX() + w + 5,lblup:getPositionY()))
		else
			obj:formatAndShowVal(kLblVal,val)
			obj:egHideWidget(kLblValUp)
		end
    end
    local ccallfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(blink)
    array:addObject(ccallfunc)
    local sequence = CCSequence:create(array)
    lbl:runAction(sequence)
end
function __infopropitem.formatAndShowVal(obj,widgetName,val)
	if obj._name == "critical" or obj._name == "dodge" then
		if val > 0 then
				obj:egSetLabelStr(widgetName,string.format("%s%0.1f%s","+",val/10,"%")) 
		else
				obj:egSetLabelStr(widgetName,string.format("%0.1f%s",val/10,"%")) 
		end
	else
		obj:egSetLabelStr(widgetName,Funs.signedNum(val)) 
	end
end
InfoPropItem={}
function InfoPropItem.new(name,val,valup)
    local obj = {}
    CocosWidget.install(obj,JsonList.infoProp)
    table_aux.unpackTo(__infopropitem, obj)
    obj:init(name,val,valup)
    return obj
end

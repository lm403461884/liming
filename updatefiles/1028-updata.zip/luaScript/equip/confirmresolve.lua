--������Ϣ���
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnClose = "btn_close"
local kPanelTxt = "txt_panel"
local kPanelRes = "award_panel"

local kLblTxt1 = "lbl_note_1"
local kLblTxt2 = "lbl_note_2"
local kLblTxt3 = "lbl_note_3"

local kImgGray = "img_gray"
local kImgBg="img_note_bg"
local kImgTxtBg = "img_note_bg"
local kColorRed = ccc3(255,0,0)

local __confirmresolve={}
function __confirmresolve.init(obj,equipid)
	obj:egHideWidget(kBtnNo)
	local btn = obj:egGetWidgetByName(kBtnYes)
	btn:setPosition(ccp(0,btn:getPositionY()))
	obj._equipid = equipid
	obj:initResList()
	obj:loadTxt(TxtList.exEquipNotify[3],obj._equipname,TxtList.exEquipNotify[5])
	obj:loadRes(obj._resList)
	obj:showWithAction()
end
function __confirmresolve.initResList(obj)
	obj._equipList = {}
	obj._resList = {}
	if obj._equipid then
		local subid,sublv,seed,subqa =  Funs.deComposeInt(obj._equipid,256,4)
		obj:egSetWidgetColor(kLblTxt2,KVariantList.equipColor[subqa])
		obj._equipname = equipFuncs.getSubEquipCfg(subid,"name")
		obj._resList = equipFuncs.subEquipToRes(subid,subqa,sublv)
		local cnt = account_data.equipSub[obj._equipid]
		for key,val in pairs(obj._resList) do
			obj._resList[key] = val * cnt
		end
		table.insert(obj._equipList,obj._equipid)
	else
		obj._equipname = TxtList.exEquipNotify[4]
		obj:egSetWidgetColor(kLblTxt2,kColorRed)
		local tb = {}
		for equipid,cnt in pairs(account_data.equipSub) do
			if cnt> 0 then
				local subid,sublv,seed,subqa =  Funs.deComposeInt(equipid,256,4)
				if sublv == 1 then
					tb = equipFuncs.subEquipToRes(subid,subqa,sublv)
					for cointype,coinval in pairs(tb) do
						obj._resList[cointype] = (obj._resList[cointype] or 0) + coinval*cnt
					end
					table.insert(obj._equipList,equipid)
				end
			else
				account_data.equipSub[equipid] = nil
			end
		end
	end
end
function __confirmresolve.showWithAction(obj)
	local bg = obj:egGetWidgetByName(kImgBg)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	obj:egSetWidgetTouchEnabled(kBtnYes,false)
	obj:egSetWidgetTouchEnabled(kBtnNo,false)
	bg:setScale(0)
	local scaleto = CCScaleTo:create(0.3,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		obj:egSetWidgetTouchEnabled(kBtnYes,true)
		obj:egSetWidgetTouchEnabled(kBtnNo,true)
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	bg:runAction(sequence)
	graylayer:setOpacity(0)
	graylayer:runAction(CCFadeTo:create(0.3,128))
end
function __confirmresolve.hideWithAction(obj)
	local bg = obj:egGetWidgetByName(kImgBg)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	obj:egSetWidgetTouchEnabled(kBtnYes,false)
	obj:egSetWidgetTouchEnabled(kBtnNo,false)
	obj:egSetLabelStr(kLblCoinRes,needVal)
	local scaleto = CCScaleTo:create(0.2,0)
	local backout =CCEaseBackIn:create(scaleto)
	local function callback()
		obj:egRemoveSelf()
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	bg:runAction(sequence)
	graylayer:setOpacity(0)
	graylayer:runAction(CCFadeTo:create(0.1,0))
end
function __confirmresolve.loadTxt(obj,txt1,txt2,txt3)
	obj:egSetLabelStr(kLblTxt1,txt1)
	obj:egSetLabelStr(kLblTxt2,txt2)
	obj:egSetLabelStr(kLblTxt3,txt3)
	local lbl1 = tolua.cast(obj:egGetWidgetByName(kLblTxt1),"Label")
	local lbl2 = tolua.cast(obj:egGetWidgetByName(kLblTxt2),"Label")
	local lbl3 = tolua.cast(obj:egGetWidgetByName(kLblTxt3),"Label")
	lbl1:setText(txt1)
	lbl2:setText(txt2)
	lbl3:setText(txt3)
	lbl2:setPosition(ccp(lbl1:getPositionX() + lbl1:getSize().width + 10,lbl2:getPositionY()))
	lbl3:setPosition(ccp(lbl2:getPositionX() + lbl2:getSize().width + 10,lbl3:getPositionY()))
	local w = lbl3:getPositionX() + lbl3:getSize().width
	local paneltxt = obj:egGetWidgetByName(kPanelTxt)
	local offsetx = (paneltxt:getSize().width - w)/2
	paneltxt:setPosition(ccp(paneltxt:getPositionX() + offsetx,paneltxt:getPositionY()))
end

function __confirmresolve.loadRes(obj,resList)
	 local panel = obj:egGetWidgetByName(kPanelRes)
	 local panelsize = panel:getSize()
	 local actW = 0
	 for idx,coinname in pairs(KVariantList.coinType) do
        local coinval = resList[coinname] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,TxtList.numSymbol..coinval)
			local item_w = awarditem:egNode():getSize().width
			actW = actW + item_w
			panel:addChild(awarditem:egNode())
        end
    end
	panel:setPosition(ccp(panel:getPositionX() + (panelsize.width-actW)/2,panel:getPositionY()))
end
--�ֽⰴť
function __confirmresolve.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.equipkeep)
		if obj._equipid then
			SendMsg[939007](obj._equipid)
		else
			SendMsg[939008]()
		end
		for key,equipid in ipairs(obj._equipList) do
			account_data.equipSub[equipid] = nil
		end
		for key,val in pairs(obj._resList) do
			account_data[key] = account_data[key] + val
		end
		if obj._closeCallback then obj._closeCallback(obj._equipList) end
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __confirmresolve.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
function __confirmresolve.onClosed(obj,callback)
	obj._closeCallback = callback
end
ConfirmResolve={}
function ConfirmResolve.new(equipid,onloaded)
    local obj =  TouchWidget.new(JsonList.confirmResolve)
    table_aux.unpackTo(__confirmresolve, obj)
    obj._onloaded = onloaded
    obj:init(equipid)
    obj:bindYesListener()
	obj:bindBackListener()
    return obj
end

local kImgHero = "btn_equip_hero"
local kLblHeroLv = "lbl_hero_lv"
local kImgBg = "img_hero_bg"
local kLblAtkVal = "lbl_atk_val"
local kPanelStars = "star_list"

local kPanelEquip = "panel_equip"
local kPanelAux = "panel_aux"
local kPosY = 125
local kPosX = 0
local kGreenColor = ccc3(0,255,0)
local kRedColor = ccc3(255,0,0)
local __equipheroitem={}
function __equipheroitem.init(obj,heroid)
    obj._heroid = heroid
	obj._heroData = account_data.heroList[heroid]
	obj._equipItem = nil
	obj._auxEquipItem1 = nil
	obj._auxEquipItem2 = nil
    obj:egChangeBtnImg(kImgHero,hero_data[heroid].photo,"","",UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblHeroLv,obj._heroData.lv)
	obj:loadHeroGrade(obj._heroData.grade)
	obj._heroBp = RiskHelper.getHeroBp(obj._heroData,account_data)
    obj._maxHP,obj._power,obj._critical,obj._dodge = RiskHelper.getHeroPropWithEquip(obj._heroData,account_data.equipments[obj._heroData.eid][1])
	obj:loadEquips()
	obj:addprop("heroid",obj._heroid)
	obj:addprop("heroBp",obj._heroBp)
	obj:addprop("maxHP",obj._maxHP)
	obj:addprop("power",obj._power)
	obj:addprop("critical",obj._critical)
	obj:addprop("dodge",obj._dodge)
    obj:egSetLabelStr(kLblAtkVal,obj._heroBp )
end
--����Ӣ�۽��׵ȼ�
function __equipheroitem.loadHeroGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
--����װ����Ϣ
function __equipheroitem.loadEquips(obj)
	local panel = obj:egGetWidgetByName(kPanelEquip)
	obj._equipItem = EquipItem.new(obj._heroData.eid,obj._heroid)
	panel:addChild(obj._equipItem:egNode())
	local panelaux =  obj:egGetWidgetByName(kPanelAux)
	obj._auxEquipItem1 = EquipItem.new(obj._heroData.eid_s1,obj._heroid,1)
	panelaux:addChild(obj._auxEquipItem1:egNode())
	obj._auxEquipItem2 = EquipItem.new(obj._heroData.eid_s2,obj._heroid,2)
	panelaux:addChild(obj._auxEquipItem2:egNode())
end
--Ӣ�ۿ�Ƭ����¼�
function __equipheroitem.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_paper_open)
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)  
    end
	local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kImgHero,nil,nil,touchEnded,touchCanceled)  
end
--����Ӣ�ۿ�,equiplayer����
function __equipheroitem.updateHeroEquip(obj)
	obj._heroBp = RiskHelper.getHeroBp(obj._heroData,account_data)
    obj._maxHP,obj._power,obj._critical,obj._dodge = RiskHelper.getHeroPropWithEquip(obj._heroData,account_data.equipments[obj._heroData.eid][1])
	obj:showPropChange()
	obj._equipItem:updateWithAction(obj._heroData.eid)
	obj._auxEquipItem1:updateWithAction(obj._heroData.eid_s1,1)
	obj._auxEquipItem2:updateWithAction(obj._heroData.eid_s2,2)
	obj:addprop("heroBp",obj._heroBp)
	obj:addprop("maxHP",obj._maxHP)
	obj:addprop("power",obj._power)
	obj:addprop("critical",obj._critical)
	obj:addprop("dodge",obj._dodge)
    obj:egSetLabelStr(kLblAtkVal,obj._heroBp )
	
end
function __equipheroitem.showPropChange(obj)
	local offset_hp = obj._maxHP - obj:getprop("maxHP")
	local offset_atk = obj._power - obj:getprop("power")
	local offset_cri = obj._critical - obj:getprop("critical")
	local offset_dge = obj._dodge - obj:getprop("dodge")
	local delay = 0
	if offset_atk~= 0 then
		obj:createLbl(string.format("ATK %s",Funs.signedNum(offset_atk)),offset_atk,delay)
		delay = delay + 0.3
	end
	if offset_hp~= 0 then
		obj:createLbl(string.format("HP %s",Funs.signedNum(offset_hp)),offset_hp,delay)
		delay = delay + 0.3
		----Զ����Ѫ������
		if  account_data.expedition and account_data.expedition[obj._heroid] then
			local hp,power = RiskHelper.getHPPower(account_data.expedition[obj._heroid])
			if hp > 0 then
				hp = math.max(hp + offset_hp,1) --��ֹ����жװ����Ѫ���
				account_data.expedition[obj._heroid] = RiskHelper.calHPPower(hp,power)
			end
		end
	end
	if offset_cri~= 0 then
		if offset_cri > 0 then
			obj:createLbl(string.format("CRI %s%0.1f%s","+",offset_cri/10,"%"),offset_cri,delay)
		else
			obj:createLbl(string.format("CRI %0.1f%s",offset_cri/10,"%"),offset_cri,delay)
		end
		
		delay = delay + 0.3
	end
	if offset_dge~= 0 then
		if offset_dge > 0 then
			obj:createLbl(string.format("DGE %s%0.1f%s","+",offset_dge/10,"%"),offset_dge,delay)
		else
			obj:createLbl(string.format("DGE %0.1f%s",offset_dge/10,"%"),offset_dge,delay)
		end
		delay = delay + 0.3
	end
end
function __equipheroitem.createLbl(obj,txt,val,delay)
		local bg = obj:egGetWidgetByName(kImgBg)
		local lbl = Label:create()
		lbl:setFontName(FNList.STENCIL)
		lbl:setFontSize(22)
		lbl:setText(txt)
		lbl:setPosition(ccp(kPosX,kPosY))
		if val > 0 then lbl:setColor(kGreenColor) 
		else lbl:setColor(kRedColor) end
		bg:addChild(lbl)
		lbl:setScale(0)
		local array = CCArray:create()
		if delay > 0 then 
			local delay = CCDelayTime:create(delay) 
			array:addObject(delay)
		end
		local scaleto = CCEaseBackOut:create(CCScaleTo:create(0.2,1))
		local moveby = CCMoveBy:create(0.5,ccp(0,40))
		local fadeout = CCFadeOut:create(0.3)
		local callfunc = CCCallFunc:create(function() lbl:removeFromParentAndCleanup(true)  end)
		
		array:addObject(scaleto)
		array:addObject(moveby)
		array:addObject(fadeout)
		array:addObject(callfunc)
		local sequence = CCSequence:create(array)
		lbl:runAction(sequence)
end
--����Ӣ��װ��Ϊѡ����,equiplayer����
function __equipheroitem.setEquipSelected(obj)
	obj._equipItem:setSelected(true)
	if obj._owner then obj._owner:changeSelectedEquip(obj._equipItem) end
end
--��������ҳ��,equiplayer����
function __equipheroitem.setOwner(obj,owner)
	obj._owner = owner
end
function __equipheroitem.onEquipClicked(obj,callback)
	obj._equipItem:onClicked(callback)
	obj._auxEquipItem1:onClicked(callback)
	obj._auxEquipItem2:onClicked(callback)
end
EquipHeroItem = {}
function EquipHeroItem.new(heroid)
   local obj ={}
   CocosWidget.install(obj,JsonList.equipHeroItem)
   BaseProp.install(obj)
   InnerProp.install(obj)
   table_aux.unpackTo(__equipheroitem,obj)
   obj:init(heroid)
   obj:bindClickListener()
   return obj
end
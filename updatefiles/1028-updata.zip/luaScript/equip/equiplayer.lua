local kLblTrainLv = "lbl_train_lv"
local kListview = "list_view"
local kBtnBack = "btn_return"
local kImgBack = "img_return"
local kPanelInfo = "panel_info"
local kPanelUpdate = "panel_update"
--------------------------icon
local kLblIron = "lbl_iron"
local kLblCopper = "lbl_copper"
local kLblStoneR = "lbl_stoneR"
local kLblStoneB = "lbl_stoneB"
local kLblStoneD = "lbl_stoneD"
local kLblGold = "own_gold_val"
local kBarGold = "own_gold_bar"
local kBtnGoldadd = "btn_gold_add"
local kPanelGold = "own_gold"
local kImgIconBg = "img_icon_bg"
---------------װ����Ϣ
local kLblEquipName = "lbl_equip_name"

local kImgEquip = "img_equip_show"
local kImgLv = "img_lv_show"
local kLblLv = "lbl_lv_show"

local kImgMaskBg = "img_mask_bg"
local kImgMaskBar = "img_mask_bar"
local kPanelProp = "prop_list"
--------------------װ������
local kItemList = "item_list"
local kImgResName = "img_lvup_res"
local kLblNotice = "lbl_notice"
local kPanelLv = "panel_lvup"
local kPanelArm = "panel_arm"
local kPanelQa = "panel_upgrade"

local kBtnLvup = "btn_lvup"
local kBtnUpgrade = "btn_upgrade"
local kBtnRemove = "btn_remove"
local kBtnArm = "btn_arm"

local kPosY1 = 50
local kPosY2 = 20
local kRedColor = ccc3(255,0,0)
local kBrownColor = ccc3(83,49,22)


local kMaxMetal = 9999
local kMaxStone = 999
local kMaxGoldN = 99999999
local kMaxNum = 5
local kCellW = 160
local kMaxqa = 5
local kPropKeys = {"power","maxHP","critical","dodge",}

local __equiplayer={}
--��ʽ�����
local function __getBouncedNum(val,maxVal)
	if val > maxVal then
		return string.format("%d%s",maxVal,"+")
	end
	return string.format("%d",val)
end
local function __getAddVal(old,new,step)
	local val = new-old
	if not step then step = 100 end
	if val > 0 then
		val = math.ceil(val/step)
	else
		val = math.floor(val/step)
	end
	return val
end
function __equiplayer.init(obj)
   obj._d_data = account_data
   obj._trainLv = account_data.train[train.def.equip].lv
   obj:egSetLabelStr(kLblTrainLv,string.format("LV %d",obj._trainLv))
   obj._selectedEquip =nil --ѡ�е�װ��
   obj._infopropitem = {}
   --Ǯ�ҡ���ʯ
   obj:loadIcon()
   --����Ӣ��
   obj:doLoading()
end
------------������Դ
function __equiplayer.loadIcon(obj)	
	obj._iron = obj._d_data.iron
    obj._copper = obj._d_data.copper
    obj._stoneR = obj._d_data.stoneR
    obj._stoneB = obj._d_data.stoneB
    obj._stoneD = obj._d_data.stoneD
    obj._gold = obj._d_data.gold
    --obj._jewel = obj._d_data.jewel
    obj._maxGold = obj._d_data.maxGold
     
    obj:egSetBMLabelStr(kLblGold,Funs.getBouncedNum(obj._gold,kMaxGoldN,true))
    obj:egSetBarPercent(kBarGold,obj._gold*100/obj._maxGold)
    --obj:egSetBMLabelStr(kLblJewel,Funs.formatNum(obj._jewel))
	obj:egSetBMLabelStr(kLblIron,__getBouncedNum(obj._iron,kMaxMetal))
	obj:egSetBMLabelStr(kLblCopper,__getBouncedNum(obj._copper,kMaxMetal))
	
	obj:egSetBMLabelStr(kLblStoneR,__getBouncedNum(obj._stoneR,kMaxStone))
	obj:egSetBMLabelStr(kLblStoneB,__getBouncedNum(obj._stoneB,kMaxStone))
	obj:egSetBMLabelStr(kLblStoneD,__getBouncedNum(obj._stoneD,kMaxStone))
end
-------------��ҡ���ʯ��������
--�޸Ŀ�ʯ��ֵ
function __equiplayer.refreshResVal(obj,paramName,coinName,widgetName,maxVal)
    local matched = false
    if obj[paramName] ~=obj._d_data[coinName] then
        obj[paramName] = obj[paramName]+__getAddVal(obj[paramName],obj._d_data[coinName])
        if obj[paramName] > maxVal and obj._d_data[coinName]<=maxVal then obj[paramName]=maxVal 
        elseif obj[paramName] >= maxVal and obj._d_data[coinName]>maxVal then obj[paramName] = obj._d_data[coinName]end
        obj:egSetBMLabelStr(widgetName,__getBouncedNum(obj[paramName],maxVal))
    else
        matched = true
    end
    return matched
end
--���¿�ʯ��ֵ
function __equiplayer.iconUpdate(obj)
    local gold = false
    local iron = false
    local copper = false
    local stoneR = false
    local stoneB = false
    local stoneD = false
    local function updateFunc()
        if obj._gold ~= obj._d_data.gold then
            obj._gold = obj._gold + __getAddVal(obj._gold,obj._d_data.gold,50)
			if obj._gold > kMaxGoldN and obj._d_data.gold <= kMaxGoldN then
				obj._gold = kMaxGoldN
			elseif obj._gold >= kMaxGoldN and obj._d_data.gold > kMaxGoldN then
				obj._gold = obj._d_data.gold
			end
            obj:egSetBMLabelStr(kLblGold,Funs.getBouncedNum(obj._gold,kMaxGoldN,true))
            obj:egSetBarPercent(kBarGold,obj._gold*100/obj._maxGold)
        else
            gold = true    
        end
		iron = obj:refreshResVal("_iron","iron",kLblIron,kMaxMetal)
		copper = obj:refreshResVal("_copper","copper",kLblCopper,kMaxMetal)
		stoneR = obj:refreshResVal("_stoneR","stoneR",kLblStoneR,kMaxMetal)
		stoneB = obj:refreshResVal("_stoneB","stoneB",kLblStoneB,kMaxMetal)
		stoneD = obj:refreshResVal("_stoneD","stoneD",kLblStoneD,kMaxMetal)
        if gold and iron and copper and stoneR and stoneB and stoneD then
            obj:egUnbindWidgetUpdate(kImgIconBg)
        end
    end
    obj:egBindWidgetUpdate(kImgIconBg,updateFunc)
end
function __equiplayer.bindGoldListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj:onAddGoldClicked(kBtnGoldadd)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGoldadd,nil,nil,touchEnded,touchCanceled)
end

function __equiplayer.bindGoldPanelListener(obj)
    local btn = tolua.cast(obj:egGetWidgetByName(kBtnGoldadd),"Button")
	local function touchBegin(sender)
		btn:setFocused(true)
	end
	local function touchEnded(sender)
		--local btn = obj:egGetWidgetByName(kBtnActadd)
		btn:setFocused(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		local function callback()
			sender:setTouchEnabled(true)
		end
		obj:onAddGoldClicked(kBtnGoldadd,callback)
    end
	local function touchCanceled(sender)
	    btn:setFocused(false)
		if AccountHelper:isLocked(kStateGuide) then --引导状�?
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelGold,touchBegin,nil,touchEnded,touchCanceled)
end
function __equiplayer.onAddGoldClicked(obj,widgetName,callback)
	local widget = obj:egGetWidgetByName(widgetName)
	local posx = widget:getPositionX() + widget:getSize().width/2
	local posy = widget:getPositionY() + widget:getSize().height/2
	if widgetName == kBtnGoldadd then
		local panel = obj:egGetWidgetByName(kPanelGold)
		posx = panel:getPositionX() + widget:getPositionX()
		posy = panel:getPositionY() + widget:getPositionY()  - widget:getSize().height*widget:getAnchorPoint().y
	end
	if os.time() >= account_data.goldNextSt then
		account_data.goldBoughtCnt = 0
		account_data.goldNextSt = Funs.getTimeWithHMS(numDef.goldRefreshUTH,numDef.goldRefreshUTM,0,account_data.scOffsetTime)
	end
	local maxBoughtCnt = VipLvUp[account_data.vip or 0].goldCnt or 0
	if account_data.goldBoughtCnt >= maxBoughtCnt then
		showPopTxt(TxtList.maxBoughtCnt,posx,posy,ccp(0.5,1))
		widget:setTouchEnabled(true)
	else
		local apPirce,_ =  jewelCalc.getPriceForGold(account_data.digLv)
		if apPirce > account_data.jewel then
			showPopCharge(apPirce,function() widget:setTouchEnabled(true) end)
		else
			showApMarket(1,function() widget:setTouchEnabled(true) end)
		end
	end
	if callback then callback() end
end
--��ʼ��Ӣ��ս������С��Ӣ�ۺͷ�С��Ӣ�۱�
function __equiplayer.initHeroBpInfoList(obj)
	for key,heroid in ipairs(obj._d_data.team) do
        obj._heroBpTb[heroid] = RiskHelper.getHeroBp(obj._d_data.heroList[heroid],obj._d_data)
		table.insert(obj._teamTb,heroid)
		
	end
    for heroid,heroprop in pairs(obj._d_data.heroList) do
		if not obj._heroBpTb[heroid] then
			obj._heroBpTb[heroid] = RiskHelper.getHeroBp(heroprop,obj._d_data)
			table.insert(obj._memberTb,heroid)
		end
    end
end
--��ȡ����Ӣ��ս��������������Ӣ��ID�б�
function __equiplayer.getOrderHeroList(obj)
	table.sort(obj._teamTb,function(a,b) return (obj._heroBpTb[a] > obj._heroBpTb[b] or (obj._heroBpTb[a] == obj._heroBpTb[b] and a > b)) end)
	table.sort(obj._memberTb,function(a,b) return (obj._heroBpTb[a] > obj._heroBpTb[b] or (obj._heroBpTb[a] == obj._heroBpTb[b] and a > b)) end)
	local tb ={}
	for key,val in ipairs(obj._teamTb) do
		table.insert(tb,val)
	end
	for key,val in ipairs(obj._memberTb) do
		table.insert(tb,val)
	end
	return tb
end
function __equiplayer.loadHeroItem(obj)
	obj._heroBpTb = {}
	obj._teamTb = {}
	obj._memberTb = {}
	obj._heroItems={}
	obj._loadCnt = 0
	obj:initHeroBpInfoList()
	obj._heroCnt = #obj._teamTb +#obj._memberTb
	obj._heroList = obj:getOrderHeroList()
	local scrollview = obj:egGetScrollView(kListview)
   	local size = scrollview:getSize()
	local neww = obj._heroCnt * kCellW
	if size.width < neww then
		scrollview:setInnerContainerSize(CCSizeMake(neww,size.height))
	end
	while obj._loadCnt < kMaxNum do
		obj:addHeroItem(1)
		coroutine.yield()
	end
	obj:bindScrollListener()
end
function __equiplayer.doLoading(obj)
	local function coFunc()
		obj:loadHeroItem()
	end
	local coLoad = coroutine.create(coFunc)
	local function callback()
		local f1,f2 = coroutine.resume(coLoad)
		if not f1 then
			obj:egUnbindWidgetUpdate(kLblLv)
			if type(f2) == "string" then	print(f2) end
		end
	end
	obj:egBindWidgetUpdate(kLblLv,callback)
end
function __equiplayer.bindScrollListener(obj)
	local scrollview = obj:egGetScrollView(kListview)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadCnt >= obj._heroCnt then return end
            local innerContainer = scrollview:getInnerContainer()
            local posX = innerContainer:getPositionX()
            if (obj._loadCnt * kCellW) + posX  < scrollview:getSize().width then
                obj:addHeroItem(1)
            end
        end
    end
    scrollview:addEventListenerScrollView(scrollEvent)
end
--����ָ��������Ӣ�ۿ�Ƭ
function __equiplayer.addHeroItem(obj,num)
	local scrollview = obj:egGetScrollView(kListview)
	if obj._loadCnt >=obj._heroCnt then return end
	local startIdx = obj._loadCnt +1
	local endIdx = math.min(obj._loadCnt + num,obj._heroCnt)
	for idx = startIdx,endIdx do
		local heroid = obj._heroList[idx]
		local heroItem = EquipHeroItem.new(heroid)
		heroItem:setOwner(obj)
		obj:bindHeroEquipEvent(heroItem)
        scrollview:addChild(heroItem:egNode())  
		heroItem:egSetPosition(obj._loadCnt*kCellW,0)
        obj._heroItems[heroid] = heroItem
		obj._loadCnt = idx
		if idx == 1 then
			heroItem:setEquipSelected()
		end
	end
end
--��������Ӣ�ۿ�Ƭ
function __equiplayer.reorderHeroItem(obj)
	obj._heroList = obj:getOrderHeroList()
	local scrollview = obj:egGetScrollView(kListview)
	for idx,heroid in ipairs(obj._heroList) do
		if idx > obj._loadCnt then return end
		if obj._heroItems[heroid] then
			obj._heroItems[heroid]:egSetPosition((idx-1)*kCellW,0)
		else
			local heroItem = EquipHeroItem.new(heroid)
			heroItem:setOwner(obj)
			obj:bindHeroEquipEvent(heroItem)
			scrollview:addChild(heroItem:egNode())  
			heroItem:egSetPosition(obj._loadCnt*kCellW,0)
			obj._heroItems[heroid] = heroItem
			obj._loadCnt = obj._loadCnt + 1
		end
	end
end
function __equiplayer.showEquipBag(obj,heroid,equipPos)
	local function closeCallback()
		obj._heroItems[heroid]:updateHeroEquip()
		local equipid = obj._selectingEquip:getprop("equipid")
		if equipid and equipid > 0 then
			obj._selectedEquip:setSelected(false)
			obj:changeSelectedEquip(obj._selectingEquip)
			obj._selectingEquip = nil
		else
			obj._selectingEquip:setSelected(false)
			obj._selectingEquip = nil
		end
		----------------------------------------------------------
        obj:iconUpdate() --������Դ����UI��ʾ
	end
	local layer = EquipBag.new(heroid,equipPos,function() obj:egSetWidgetTouchEnabled(kBtnArm,true) end)
	layer:onResolved(function() obj:iconUpdate() end)
	layer:onClosing(closeCallback)
	local scene = CCDirector:sharedDirector():getRunningScene()
	scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
function __equiplayer.bindHeroEquipEvent(obj,heroitem)
	local function clickCallback(equipitem)
		local equipid = equipitem:getprop("equipid")
		local equipPos = equipitem:getprop("equipPos")
		local heroid = equipitem:getprop("heroid")
		if  equipPos and ((not equipid) or equipid <= 0) then
			if obj:hasSubEquip() then
				obj._selectingEquip = equipitem
				obj._selectingEquip:setSelected(true)
				obj:showEquipBag(heroid,equipPos)
			else
				local pos = equipitem:getTouchPos()
				showPopTxt(TxtList.noSubEquip,pos.x,pos.y,ccp(0.5,0.5))
			end
		else
			obj:changeSelectedEquip(equipitem)
		end
	end
	heroitem:onEquipClicked(clickCallback)
end
--�л�ѡ��װ��
function __equiplayer.changeSelectedEquip(obj,equipitem)
	if obj._selectedEquip then obj._selectedEquip:setSelected(false) end
	obj._selectedEquip = equipitem
	obj._selectedEquip:setSelected(true)
	local equipid = obj._selectedEquip:getprop("equipid")
	local equipPos = obj._selectedEquip:getprop("equipPos")
	obj:egHideWidget(kImgMaskBg)
	obj:egHideWidget(kImgMaskBar)
	if equipPos then --����װ��
		local subid,curlv,seed,curqa = Funs.deComposeInt(equipid,256,4)
		local s_cfg = equipFuncs.getSubEquipCfg(subid)
		local equiprop = equipFuncs.getSubEquip(subid,curlv)
		local newprop = equipFuncs.getSubEquip(subid,curlv+1)
		obj:egSetLabelStr(kLblEquipName,s_cfg.name)
		obj:egChangeImg(kImgEquip,s_cfg.icon,UI_TEX_TYPE_PLIST)
		obj:egSetBMLabelStr(kLblLv,curlv)
		obj:loadEquipProp(equiprop,newprop,curlv)
		
		obj:egHideWidget(kPanelQa)
		obj:egHideWidget(kBtnUpgrade)
		obj:egShowWidget(kPanelArm)
		obj:egShowWidget(kBtnArm)
		obj:egShowWidget(kBtnRemove)
		
		obj:egSetWidgetColor(kImgMaskBg,KVariantList.equipColor[curqa])
		obj:egSetWidgetColor(kImgMaskBar,KVariantList.equipColor[curqa])
		obj:loadUpdateProp(equiprop,newprop,curlv)

	else --��װ��
		local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
		local s_cfg = equipCfg[equipid]
		local equiprop = equipFuncs.getData(equipid,curlv)
		local newprop = equipFuncs.getData(equipid,curlv+1)
		obj:egSetLabelStr(kLblEquipName,s_cfg.name)
		obj:egChangeImg(kImgEquip,s_cfg.icon,UI_TEX_TYPE_PLIST)
		obj:egSetBMLabelStr(kLblLv,curlv)
		obj:loadEquipProp(equiprop,newprop,curlv)
		
		obj:egShowWidget(kPanelQa)
		obj:egShowWidget(kBtnUpgrade)
		obj:egHideWidget(kPanelArm)
		obj:egHideWidget(kBtnArm)
		obj:egHideWidget(kBtnRemove)
		
		obj:egSetWidgetColor(kImgMaskBg,KVariantList.equipColor[curqa])
		obj:egSetWidgetColor(kImgMaskBar,KVariantList.equipColor[curqa])
		--�ж��Ƿ���Խ���
		if  math.floor(curlv* numDef.weaponQaFactor) > curqa  and curqa<kMaxqa then 
			obj:egChangeBtnImg(kBtnUpgrade,ImageList.btn_paper_n,ImageList.btn_paper_s,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
		else
			obj:egChangeBtnImg(kBtnUpgrade,ImageList.btn_paper_d,ImageList.btn_paper_d,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
		end
		obj:loadUpdateProp(equiprop,newprop,curlv)
	end
end
--��������������ز���
function __equiplayer.loadUpdateProp(obj,equiprop,newprop,curlv)
	local maxlv = obj._trainLv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
	obj._lvupEnabled = true
	if curlv <maxlv and newprop  then --���п������ռ�
		obj:egHideWidget(kLblNotice)
		obj:egShowWidget(kItemList)
		obj:egShowWidget(kImgResName)
		obj:loadNeedsProp(equiprop) --��������������Դ,ͬʱ�ж��Ƿ��������
		obj:egSetWidgetEnabled(kBtnLvup,obj._lvupEnabled)
	else --û�п������Ŀռ�
		obj:egHideWidget(kItemList)
		obj:egHideWidget(kImgResName)
		obj:egShowWidget(kLblNotice)
		obj:egSetWidgetEnabled(kBtnLvup,false)
		if curlv>=maxlv and newprop then
			obj:egSetLabelStr(kLblNotice,TxtList.needEquipTrainLv)
		else
			obj:egSetLabelStr(kLblNotice,TxtList.reachMaxLv)
		end
	end 
end
--����װ��������Ϣ
function __equiplayer.loadEquipProp(obj,equiprop,newprop,curlv)
	local panelprop = obj:egGetListView(kPanelProp)
	while panelprop:getChildrenCount() > 0 do
	    panelprop:removeLastItem()
	end
	panelprop:removeAllItems()
	obj._infopropitem = {}
	local maxlv = obj._trainLv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
	if newprop and curlv < maxlv then
		for idx,propname in ipairs(kPropKeys) do
			local propval = equiprop[propname]
			if propval and propval ~= 0 then 
				local propitem = InfoPropItem.new(propname,propval,newprop[propname]-propval)
				panelprop:pushBackCustomItem(propitem:egNode())
				obj._infopropitem[idx] = propitem
			end
		end
	else
		for idx,propname in ipairs(kPropKeys) do
			local propval = equiprop[propname]
			if propval and propval ~= 0 then 
				local propitem = InfoPropItem.new(propname,propval)
				panelprop:pushBackCustomItem(propitem:egNode())
				obj._infopropitem[idx] = propitem
			end
		end
	end
end
--��������������Դ
function __equiplayer.loadNeedsProp(obj,lvupdata)
    local listlayer = obj:egGetWidgetByName(kItemList)
    for idx=1,listlayer:getChildrenCount() do
        listlayer:removeChildByTag(idx,true)
    end
	local itemcnt = 0
    for cointype,val in pairs( lvupdata.cost) do
        local ownnum = account_data[cointype]
        local item = ImgPropItem.new(cointype,val)
        if val > ownnum then
            item:setTxtColor(kRedColor)
            obj._lvupEnabled = false
        end
		itemcnt = itemcnt +1
        listlayer:addChild(item:egNode(),0,itemcnt)
    end
end
--��ʾ�ȼ��䶯��������
function __equiplayer.showLvUpBGAction(obj,widgetName,opacity)
    local widget = obj:egGetWidgetByName(widgetName)
    widget:setVisible(true)
    widget:setScale(1.2)
	widget:setOpacity(0)
    local fadeto1 = CCFadeTo:create(0.6,opacity)
    local scaleto1 = CCScaleTo:create(0.6,1)
    local spawn1 = CCSpawn:createWithTwoActions(fadeto1,scaleto1)
    local fadeto2 = CCFadeTo:create(0.4,0)
    local callfunc = CCCallFunc:create( function()  widget:setVisible(false) end)
    local array = CCArray:create()
    array:addObject(spawn1)
    array:addObject(fadeto2)
    array:addObject(callfunc)
    widget:runAction(CCSequence:create(array))
end
function __equiplayer.showLvUpItemAction(obj)
    local widget = obj:egGetWidgetByName(kImgEquip)
    local scaleto1 = CCScaleTo:create(0.6,1.1)
    local scaleto2 = CCScaleTo:create(0.4,1)
    local backout = CCEaseBackOut:create(scaleto2)
    local squence=CCSequence:createWithTwoActions(scaleto1,backout)
    widget:runAction(squence)
end
function __equiplayer.showLvUpAction(obj,curlv)
    local lvwidget = obj:egGetWidgetByName(kImgLv) 
    lvwidget:setVisible(false)  
    obj:egSetBMLabelStr(kLblLv,curlv)
    lvwidget:setScale(5)
    local delay = CCDelayTime:create(0.6)
    local callfunc1 = CCCallFunc:create(function()  lvwidget:setVisible(true)   end)
    local scale = CCScaleTo:create(0.4,1)
    local backout = CCEaseBackOut:create(scale)
    local callfunc2 = CCCallFunc:create(function() obj:egSetWidgetTouchEnabled(kBtnLvup,true) end)
    local array = CCArray:create()
    array:addObject(delay)
    array:addObject(callfunc1)
    array:addObject(backout)
    array:addObject(callfunc2)
    lvwidget:runAction(CCSequence:create(array))
end
--��ʾ���豸������Ϣ
function __equiplayer.showUpdateEquip(obj,eid,curlv,curqa)
		local oldprop = equipFuncs.getData(eid,curlv)
		local newprop = equipFuncs.getData(eid,curlv + 1)
		local maxlv = obj._trainLv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
		if newprop and curlv < maxlv then
			for idx,propname in ipairs(kPropKeys) do
				if obj._infopropitem[idx] then
					obj._infopropitem[idx]:blinkValUp(oldprop[propname],newprop[propname]-oldprop[propname])
				end
			end
		else
			for idx,propname in ipairs(kPropKeys) do
				if obj._infopropitem[idx] then
					obj._infopropitem[idx]:blinkValUp(oldprop[propname])
				end
			end
		end
		obj:showLvUpAction(curlv)
		obj:showLvUpBGAction(kImgMaskBg,150)
		obj:showLvUpBGAction(kImgMaskBar,255)
		obj:showLvUpItemAction()
		--�ж��Ƿ���Խ���
		if  math.floor(curlv* numDef.weaponQaFactor) > curqa and curqa<kMaxqa then 
			obj:egChangeBtnImg(kBtnUpgrade,ImageList.btn_paper_n,ImageList.btn_paper_s,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
		else
			obj:egChangeBtnImg(kBtnUpgrade,ImageList.btn_paper_d,ImageList.btn_paper_d,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
		end
		obj:loadUpdateProp(oldprop,newprop,curlv)
end
--��ʾ�豸������Ϣ
function __equiplayer.showUpdateAux(obj,eid,curlv)
		local oldprop = equipFuncs.getSubEquip(eid,curlv)
		local newprop = equipFuncs.getSubEquip(eid,curlv + 1)
		local maxlv = obj._trainLv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
		if newprop and curlv < maxlv then
			for idx,propname in ipairs(kPropKeys) do
				if obj._infopropitem[idx] then
					obj._infopropitem[idx]:blinkValUp(oldprop[propname],newprop[propname]-oldprop[propname])
				end
			end
		else
			for idx,propname in ipairs(kPropKeys) do
				if obj._infopropitem[idx] then
					obj._infopropitem[idx]:blinkValUp(oldprop[propname])
				end
			end
		end
		obj:showLvUpAction(curlv)
		obj:showLvUpBGAction(kImgMaskBg,150)
		obj:showLvUpBGAction(kImgMaskBar,255)
		obj:showLvUpItemAction()
		obj:loadUpdateProp(oldprop,newprop,curlv)
end
--���ذ�ť
function __equiplayer.bindBackListener(obj) 
    local function touchBegan()
        obj:egSetWidgetScale(kImgBack,1.1)
    end
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_back_button)
		obj:egSetWidgetScale(kImgBack,1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		local totalBp = RiskHelper.getTotalBp()
		if account_data.teamBp ~= totalBp then
			account_data.teamBp = totalBp
			SendMsg[934018](totalBp)
		end
        local scene = TownScene.new()
        scene:egReplace()
    end
	 local function touchCanceled(sender)
	   obj:egSetWidgetScale(kImgBack,1)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
--��װ������
function __equiplayer.changeEquipLv(obj)
	local equipid = obj._selectedEquip:getprop("equipid")--ѡ�е�eid
	local curLv = obj._selectedEquip:getprop("curLv")
	local curQa = obj._selectedEquip:getprop("curQa")
	local heroid = equipFuncs.getHeroID(equipid)
	local lvupdata = equipFuncs.getData(equipid,curLv)
	for cointype,val in pairs (lvupdata.cost) do
		account_data[cointype]=math.min(account_data[cointype]-val)
	end
	account_data.equipments[equipid][1]=account_data.equipments[equipid][1]+1
	SendMsg[939002](heroid)
	--�ھ���־�������
	task.updateTaskStatus(account_data,task.client_event_id.equit_update,{equipid,curLv+1})  
	obj._heroItems[heroid]:updateHeroEquip() --����Ӣ�ۿ�Ƭ
	obj:showUpdateEquip(equipid,curLv+1,curQa)
end
--����װ������
function __equiplayer.changeAuxEuipLv(obj)
	local equipid = obj._selectedEquip:getprop("equipid")--ѡ�е�eid
	local equipPos = obj._selectedEquip:getprop("equipPos")
	local curLv = obj._selectedEquip:getprop("curLv")
	local heroid = obj._selectedEquip:getprop("heroid")
	local subid = obj._selectedEquip:getprop("subid")
	local curQa = obj._selectedEquip:getprop("curQa")
	local lvupdata = equipFuncs.getSubEquip(subid,curLv)
	for cointype,val in pairs (lvupdata.cost) do
		account_data[cointype]=math.min(account_data[cointype]-val)
	end
	SendMsg[939006](heroid,equipPos)
	if equipPos == 1 then
		account_data.heroList[heroid].eid_s1 = equipFuncs.getSubEquipId(subid,curLv+1,curQa)
	else
		account_data.heroList[heroid].eid_s2 = equipFuncs.getSubEquipId(subid,curLv+1,curQa)
	end
	--�ھ���־�������
	task.updateTaskStatus(account_data,task.client_event_id.equit_update,{subid,curLv+1})
	obj._heroItems[heroid]:updateHeroEquip() --����Ӣ�ۿ�Ƭ
	obj:showUpdateAux(subid,curLv+1)
end
-----------------װ������
function __equiplayer.bindLvUpListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.update_equip)
		local equipPos = obj._selectedEquip:getprop("equipPos")
        if equipPos then
			obj:changeAuxEuipLv()
		else
			obj:changeEquipLv()
		end
		----------------------------------------------------------
        obj:iconUpdate() --������Դ����UI��ʾ
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬		
			 touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnLvup,nil,nil,touchEnded,touchCanceled)  
end
--�ж��Ƿ��п���װ��
function __equiplayer.hasSubEquip(obj,subid)
	if subid then
		for equipid,cnt in pairs(account_data.equipSub) do
			if subid~=equipid and cnt > 0 then return true end
		end
		return false
	else
		for equipid,cnt in pairs(account_data.equipSub) do
			if cnt > 0 then return true end
		end
		return false
	end
end
--ж��
function __equiplayer.bindRemoveListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local equipPos = obj._selectedEquip:getprop("equipPos")
		local equipid = obj._selectedEquip:getprop("equipid")
		local heroid = obj._selectedEquip:getprop("heroid")
		local layer = ConfirmArm.new(equipid,nil,heroid,equipPos,function() sender:setTouchEnabled(true) end)
		--�ص���ʱ��װ���϶��б䶯������ˢ�½�����ʾ
		local function closeCallback()
			obj._selectedEquip:setSelected(false)
			obj._heroItems[heroid]:updateHeroEquip() --����Ӣ�ۿ�Ƭ
			obj._heroItems[heroid]:setEquipSelected()
			obj:iconUpdate() --������Դ����UI��ʾ
		end
		layer:onClosed(closeCallback)
		local scene = CCDirector:sharedDirector():getRunningScene()
		scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnRemove,nil,nil,touchEnded,touchCanceled)
end
--��װ
function __equiplayer.bindArmListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local selectedSubId = nil
		if obj._selectedEquip then
			selectedSubId =  obj._selectedEquip:getprop("equipid")
		end
		if obj:hasSubEquip(selectedSubId) then
			obj._selectingEquip = obj._selectedEquip
			local equipPos = obj._selectedEquip:getprop("equipPos")
			local heroid = obj._selectedEquip:getprop("heroid")
			obj:showEquipBag(heroid,equipPos)
		else
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.needSubEquip,pos.x,pos.y,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnArm,nil,nil,touchEnded,touchCanceled)
end
--����
function __equiplayer.bindUpgradeListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local oldlv = obj._selectedEquip:getprop("curLv")
		local oldqa = obj._selectedEquip:getprop("curQa")
		if math.floor(oldlv* numDef.weaponQaFactor) > oldqa and oldqa<kMaxqa then
			local equipid = obj._selectedEquip:getprop("equipid") --ѡ�е�eid
			local equipPos = obj._selectedEquip:getprop("equipPos")
			local function qaChangedCallBack()		
				local heroid = equipFuncs.getHeroID(equipid)
				obj._heroItems[heroid]:updateHeroEquip() --����Ӣ�ۿ�Ƭ
				local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
				obj:egSetWidgetColor(kImgMaskBg,KVariantList.equipColor[curqa])
				obj:egSetWidgetColor(kImgMaskBar,KVariantList.equipColor[curqa])
				if math.floor(curlv* numDef.weaponQaFactor) > curqa and curqa<kMaxqa then
					obj:egChangeBtnImg(kBtnUpgrade,ImageList.btn_paper_n,ImageList.btn_paper_s,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
				else
					obj:egChangeBtnImg(kBtnUpgrade,ImageList.btn_paper_d,ImageList.btn_paper_d,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
				end
				obj:iconUpdate() --����UI��ʾ
			end
			local qalayer = EquipQALayer.new(equipid,function() obj:egSetWidgetTouchEnabled(kBtnUpgrade,true) end )
			qalayer:onQAChanged(qaChangedCallBack)
			local scene = CCDirector:sharedDirector():getRunningScene()
			scene:addChild(qalayer:egNode(),UILv.popLayer,UILv.popLayer)
		elseif math.floor(oldlv* numDef.weaponQaFactor) > oldqa and oldqa>=kMaxqa then
             return	
		else
			local pos = sender:getTouchEndPos()
			local lv = math.floor((oldqa+1)/numDef.weaponQaFactor)
			showPopTxt(string.format(TxtList.needEquipLv,lv),pos.x,pos.y,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnUpgrade,nil,nil,touchEnded,touchCanceled)
end
EquipLayer={}
function EquipLayer.new()
   local obj = TouchWidget.new(JsonList.equipLayer)
   table_aux.unpackTo(__equiplayer,obj)
   obj:init()
   obj:bindBackListener()
   obj:bindLvUpListener()
   obj:bindUpgradeListener()
   obj:bindArmListener()
   obj:bindRemoveListener()
   obj:bindGoldListener()
   obj:bindGoldPanelListener()
   return obj
end

local kImgBg = "img_equip_b"
local kImgSelected = "img_equip_s"
local kImgItem = "img_item"
local kImgAdd = "img_add"
local kLblLv = "lbl_lv"
local kImgLv = "img_lv"
local kImgColorBg = "img_color_bg"
local kImgColorBar = "img_light_bar"
local kLblCnt = "lbl_cnt"
local __equipitem={}
--������Ҫ��ʾ������ID
function __equipitem.init(obj,equipPos,equipid)
	obj:egHideWidget(kImgSelected)
	obj:egHideWidget(kImgAdd)
	obj:setEquipID(equipPos,equipid)
end
function __equipitem.resolveWithAction(obj,onresolved)
	obj:setEquipID(obj._equipPos)
	local widget = obj:egGetWidgetByName(kImgItem)
	local imgbar = obj:egGetWidgetByName(kImgColorBar)
	widget:setScale(0.72)
	widget:setVisible(true)
	imgbar:setVisible(true)
	imgbar:setScale(1.1)
	imgbar:setOpacity(255)
	local scaleto = CCScaleTo:create(0.5,1)
	local fadeout = CCFadeOut:create(0.5)
	local function callback()
		obj:egSetWidgetEnabled(kImgBg,false)
		obj:egHideWidget(kImgSelected)
		if onresolved then onresolved() end
	end
	local callfunc = CCCallFunc:create(callback)
	local backin = CCEaseBackIn:create(CCScaleTo:create(0.5,0))
	widget:runAction(CCSequence:createWithTwoActions( backin,callfunc))
	imgbar:runAction(CCSequence:createWithTwoActions(scaleto,fadeout))
end
function __equipitem.setEquipID(obj,equipPos,equipid)
    obj._equipid = equipid
	obj._equipPos = equipPos
    obj:addprop("equipid",equipid)
	obj:addprop("equipPos",equipPos)
    if not obj._equipid or obj._equipid == 0 then  
		obj:egSetWidgetTouchEnabled(kImgBg,false)
		obj:egHideWidget(kImgLv)
		obj:egHideWidget(kImgItem)
		obj:egHideWidget(kLblCnt)
		obj:egHideWidget(kImgColorBg)
		obj:egHideWidget(kImgColorBar)
    else
		obj:egShowWidget(kImgLv)
		
		obj:egShowWidget(kImgItem)
		obj:egShowWidget(kImgColorBg)
		obj:egHideWidget(kImgColorBar)
		obj._subid,obj._curlv,obj._seed,obj._curqa = Funs.deComposeInt(obj._equipid,256,4)
		obj:addprop("curLv",obj._curlv)
		obj:addprop("subid",obj._subid)
		obj:addprop("curQa",obj._curqa)
		obj:egChangeImg(kImgItem,equipFuncs.getSubEquipCfg(obj._subid,"icon"),UI_TEX_TYPE_PLIST)
		obj:egSetBMLabelStr(kLblLv,obj._curlv) --��ʾ�����ȼ�
		local cnt = account_data.equipSub[obj._equipid]
		if cnt > 1 then
			obj:egSetBMLabelStr(kLblCnt,cnt) --��ʾ�����ȼ�
			obj:egShowWidget(kLblCnt)
		else
			obj:egHideWidget(kLblCnt)
		end
		 --��ʾ����Ʒ��
		obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[obj._curqa])
		obj:egSetWidgetColor(kImgColorBar,KVariantList.equipColor[obj._curqa])
	end
end
function __equipitem.setSelected(obj,selected)
	obj._selected = selected
	if selected then
		obj:egShowWidget(kImgSelected)
	else
		obj:egHideWidget(kImgSelected)
	end
end
--�󶨵���¼�
function __equipitem.onClicked(obj,callback)
    obj._clickCallback = callback
end
function __equipitem.getTouchPos(obj)
	return obj._touchEndPos
end
function __equipitem.bindClickListener(obj)
    local function touchBegan(sender)
		obj:egGetWidgetByName(kImgAdd):setScale(0.9)
		obj:egShowWidget(kImgSelected)
	end
    local function touchEnded(sender)
		obj:egGetWidgetByName(kImgAdd):setScale(0.8)
		if not obj._selected then obj:egHideWidget(kImgSelected) end
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj._touchEndPos = sender:getTouchEndPos()
		if obj._clickCallback then obj._clickCallback(obj) end
		sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		obj:egGetWidgetByName(kImgAdd):setScale(0.8)
		if not obj._selected then obj:egHideWidget(kImgSelected) end
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		end
    end
    obj:egBindTouch(kImgBg,touchBegan,nil,touchEnded,touchCanceled)
end
EquipBagItem={}
function EquipBagItem.new(equipPos,equipid)
    local obj = {}
    CocosWidget.install(obj,JsonList.equipItem)
    table_aux.unpackTo(__equipitem, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(equipPos,equipid)
    obj:bindClickListener()
    return obj
end
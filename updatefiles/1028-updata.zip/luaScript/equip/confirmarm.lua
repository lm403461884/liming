--������Ϣ���
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnClose = "btn_close"
local kPanelTxt = "txt_panel"
local kPanelRes = "award_panel"

local kLblTxt1 = "lbl_note_1"
local kLblTxt2 = "lbl_note_2"
local kLblTxt3 = "lbl_note_3"
local kLblJewel = "lbl_jewel"

local kImgGray = "img_gray"
local kImgBg="img_note_bg"
local kRedColor = ccc3(255,0,0)
local __confirmarm={}
function __confirmarm.init(obj,equipid,newEuipid,heroid,equipPos)
	obj._equipid = equipid
	obj._newequipid = newEuipid or 0
	obj._equipPos = equipPos
	obj._heroid = heroid
	local subid,sublv,seed,subqa =  Funs.deComposeInt(obj._equipid,256,4)
	obj._resList = equipFuncs.subEquipToRes(subid,subqa,sublv)
	obj._cost = jewelCalc.getPriceForKeepEquip(subid,subqa,sublv)
	obj:egSetWidgetColor(kLblTxt2,KVariantList.equipColor[subqa])
	obj:loadTxt(TxtList.exEquipNotify[1],equipFuncs.getSubEquipCfg(subid,"name"),TxtList.exEquipNotify[2])
	obj:loadRes(obj._resList)
	obj:egSetBMLabelStr(kLblJewel,obj._cost)
	if obj._cost > account_data.jewel then obj:egSetWidgetColor(kLblJewel,kRedColor) end
	obj:showWithAction()
end
function __confirmarm.showWithAction(obj)
	local bg = obj:egGetWidgetByName(kImgBg)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	obj:egSetWidgetTouchEnabled(kBtnYes,false)
	obj:egSetWidgetTouchEnabled(kBtnNo,false)
	obj:egSetLabelStr(kLblCoinRes,needVal)
	bg:setScale(0)
	local scaleto = CCScaleTo:create(0.3,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		obj:egSetWidgetTouchEnabled(kBtnYes,true)
		obj:egSetWidgetTouchEnabled(kBtnNo,true)
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	bg:runAction(sequence)
	graylayer:setOpacity(0)
	graylayer:runAction(CCFadeTo:create(0.3,128))
end
function __confirmarm.loadTxt(obj,txt1,txt2,txt3)
	obj:egSetLabelStr(kLblTxt1,txt1)
	obj:egSetLabelStr(kLblTxt2,txt2)
	obj:egSetLabelStr(kLblTxt3,txt3)
	local lbl1 = tolua.cast(obj:egGetWidgetByName(kLblTxt1),"Label")
	local lbl2 = tolua.cast(obj:egGetWidgetByName(kLblTxt2),"Label")
	local lbl3 = tolua.cast(obj:egGetWidgetByName(kLblTxt3),"Label")
	lbl1:setText(txt1)
	lbl2:setText(txt2)
	lbl3:setText(txt3)
	lbl2:setPosition(ccp(lbl1:getPositionX() + lbl1:getSize().width + 10,lbl2:getPositionY()))
	lbl3:setPosition(ccp(lbl2:getPositionX() + lbl2:getSize().width + 10,lbl3:getPositionY()))
	local w = lbl3:getPositionX() + lbl3:getSize().width
	local paneltxt = obj:egGetWidgetByName(kPanelTxt)
	local offsetx = (paneltxt:getSize().width - w)/2
	paneltxt:setPosition(ccp(paneltxt:getPositionX() + offsetx,paneltxt:getPositionY()))
end

function __confirmarm.loadRes(obj,resList)
	 local panel = obj:egGetWidgetByName(kPanelRes)
	 local panelsize = panel:getSize()
	 local actW = 0
	 for idx,coinname in pairs(KVariantList.coinType) do
        local coinval = resList[coinname] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,TxtList.numSymbol..coinval)
			local item_w = awarditem:egNode():getSize().width
			actW = actW + item_w
			panel:addChild(awarditem:egNode())
        end
    end
	panel:setPosition(ccp(panel:getPositionX() + (panelsize.width-actW)/2,panel:getPositionY()))
end
--�ֽ�ԭװ����װ��ť
function __confirmarm.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._equipPos == 1 then
			account_data.heroList[obj._heroid].eid_s1 = obj._newequipid
		else
			account_data.heroList[obj._heroid].eid_s2 = obj._newequipid
		end
		if obj._newequipid > 0 then
			SoundHelper.playEffect(SoundList.equipup)
			SoundHelper.playEffect(SoundList.equipword)
			--װ������װ����Ӧ����-1
			account_data.equipSub[obj._newequipid] = math.max(account_data.equipSub[obj._newequipid] - 1,0)
			if account_data.equipSub[obj._newequipid] == 0 then account_data.equipSub[obj._newequipid] = nil end
			SendMsg[939004](obj._heroid,obj._equipPos,obj._newequipid,0) --�ֽ�ԭװ��������װ��
		else
			SoundHelper.playEffect(SoundList.equipkeep)
			SendMsg[939005](obj._heroid,obj._equipPos,0) --ж�²��ֽ�ԭװ��
		end
		for key,val in pairs(obj._resList) do
			account_data[key] = account_data[key] + val
		end
		if obj._closeCallback then  obj._closeCallback() end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--����ԭװ����װ��ť
function __confirmarm.bindNoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._cost > account_data.jewel then
			--Ǯ����
			showPopCharge(obj._cost)
		else
			if obj._equipPos == 1 then
				account_data.heroList[obj._heroid].eid_s1 = obj._newequipid
			else
				account_data.heroList[obj._heroid].eid_s2 = obj._newequipid
			end
			if obj._newequipid > 0 then 
				SoundHelper.playEffect(SoundList.equipup)
				SoundHelper.playEffect(SoundList.equipword)
				--װ������װ����Ӧ����-1
				account_data.equipSub[obj._newequipid] = math.max(account_data.equipSub[obj._newequipid] - 1,0)
				if account_data.equipSub[obj._newequipid] == 0 then account_data.equipSub[obj._newequipid] = nil end
				SendMsg[939004](obj._heroid,obj._equipPos,obj._newequipid,1) --����ԭװ����װ
			else
				SoundHelper.playEffect(SoundList.equipup)
				SendMsg[939005](obj._heroid,obj._equipPos,1)--ж�²�����ԭװ��
			end
			--����ԭװ������ԭװ������+1
			account_data.equipSub[obj._equipid] = (account_data.equipSub[obj._equipid] or 0) + 1
			account_data.jewel = math.max(account_data.jewel - obj._cost,0)
			if obj._closeCallback then  obj._closeCallback() end
		end
        obj:egRemoveSelf()
		
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __confirmarm.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
function __confirmarm.onClosed(obj,callback)
	obj._closeCallback = callback
end
ConfirmArm={}
function ConfirmArm.new(equipid,newEuipid,heroid,equipPos,onloaded)
    local obj =  TouchWidget.new(JsonList.confirmResolve)
    table_aux.unpackTo(__confirmarm, obj)
    obj._onloaded = onloaded
    obj:init(equipid,newEuipid,heroid,equipPos)
    obj:bindYesListener()
    obj:bindNoListener()
	obj:bindBackListener()
    return obj
end

﻿local kPanelLayer = "img_bag_bg"
--当前选中装备
local kImgEquip ="img_equip_show"
local kLblEquipLv = "lbl_lv_show"
local kLblEquipName = "lbl_equip_name"
local kPanelProp = "equipprop_list"
local kImgEquipLv = "img_lv_show"
--主按钮
local kBtnResolveAll = "btn_resolve_all"
local kBtnResolve = "btn_resolve"
local kBtnArm = "btn_arm"
local kBtnClose = "btn_close"
--装备列表
local kPanelEquip = "equip_list"
--英雄信息
local kBtnHero = "btn_equip_hero"
local kPanelHero = "hero_prop_list"
local kLblHeroLv = "lbl_hero_lv"
local kPanelStars = "star_list"
local kColNum = 4
local kMinRow = 4
local kCellH = 140
local kPropKeys = {"power","maxHP","critical","dodge",}
local __equipbag = {}
function __equipbag.init(obj,heroid,equipPos)
	obj._heroid = heroid
	obj._equipPos = equipPos
	obj._heroprop = account_data.heroList[obj._heroid ]
	if obj._equipPos == 1 then
		obj._equipid = obj._heroprop.eid_s1 or 0
	else
		obj._equipid = obj._heroprop.eid_s2 or 0
	end
	obj._hasLv1Equip = nil
	obj:egSetWidgetTouchEnabled(kBtnHero,false)
	obj:loadHeroInfo()
	obj:initEquipList()
	obj:loadEquip()
	obj:showWithAction()
end
--加载英雄信息
function __equipbag.loadHeroInfo(obj)
	obj:egChangeBtnImg(kBtnHero,hero_data[obj._heroid].photo,"","",UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblHeroLv,obj._heroprop.lv)
	obj:loadHeroGrade(obj._heroprop.grade)
	obj._equiplv,obj._equipqa = equipFuncs.getEquipQL(obj._heroprop.eid, account_data)
	obj._sub1_id,obj._sub1_lv,obj._sub1_seed,obj._sub1_qa = Funs.deComposeInt(obj._heroprop.eid_s1,256,4)
	obj._sub2_id,obj._sub2_lv,obj._sub2_seed,obj._sub2_qa = Funs.deComposeInt(obj._heroprop.eid_s2,256,4)
    obj._heroBp = baseCalc.getBattlePoint(obj._heroprop.lv,obj._heroprop.grade,obj._equiplv,obj._equipqa,obj._sub1_lv,obj._sub1_qa,obj._sub2_lv,obj._sub2_qa)
	local equiprop = equipFuncs.getData(obj._heroprop.eid,obj._equiplv)
	local herodata = hero_data.get(obj._heroid, obj._heroprop.lv)
	local addCritical,addDodge = baseCalc.promotionLvAtt(obj._heroprop.grade or 0)
	obj._maxHP = herodata.maxHP + (equiprop.maxHP or 0)
	obj._power =  herodata.power +(equiprop.power or 0)
	obj._critical =  (herodata.critical or 0) + (equiprop.critical or 0) + addCritical
	obj._dodge = (herodata.dodge or 0) + (equiprop.dodge or 0) + addDodge
	obj._subprop1 = {}
	obj._subprop2={}
	if obj._sub1_id > 0 then obj._subprop1 =equipFuncs.getSubEquip(obj._sub1_id,obj._sub1_lv) end
	if obj._sub2_id > 0 then obj._subprop2=equipFuncs.getSubEquip(obj._sub2_id,obj._sub2_lv) end
	obj._maxHP = obj._maxHP + (obj._subprop1.maxHP or 0) + (obj._subprop2.maxHP or 0)
	obj._power =  obj._power + (obj._subprop1.power or 0) + (obj._subprop2.power or 0)
	obj._critical = obj._critical + (obj._subprop1.critical or 0) + (obj._subprop2.critical or 0)
	obj._dodge =obj._dodge + (obj._subprop1.dodge or 0) + (obj._subprop2.dodge or 0)
	local panel = obj:egGetListView(kPanelHero)
	obj._panelX = panel:getPositionX()
	obj._panelY = panel:getPositionY()
	obj._panelW = panel:getSize().width
	obj._BPItem = PropLblItem.new("battlePoint",obj._heroBp,obj._heroBp)
	obj._ATKItem = PropLblItem.new("power",obj._power,obj._power)
	obj._HPItem = PropLblItem.new("maxHP",obj._maxHP,obj._maxHP)
	obj._CTItem = PropLblItem.new("critical",obj._critical,obj._critical)
	obj._DGItem = PropLblItem.new("dodge",obj._dodge,obj._dodge)
	panel:pushBackCustomItem(obj._BPItem:egNode())
	panel:pushBackCustomItem(obj._ATKItem:egNode())
	panel:pushBackCustomItem(obj._HPItem:egNode())
	panel:pushBackCustomItem(obj._CTItem:egNode())
	panel:pushBackCustomItem(obj._DGItem:egNode())
	local propW = math.max(obj._BPItem:getWidth(),obj._ATKItem:getWidth(),obj._HPItem:getWidth(),obj._CTItem:getWidth(),obj._DGItem:getWidth())
	panel:setPosition(ccp(obj._panelX + (obj._panelW - propW)/2,obj._panelY))
	
end
--加载英雄进阶等级
function __equipbag.loadHeroGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
function __equipbag.initEquipList(obj)
	obj._equipList = {}
	for equipid,equipCnt in pairs(account_data.equipSub) do
		if equipCnt > 0 then	
			if equipid ~= obj._equipid then
				local subid,lv,seed,qa =  Funs.deComposeInt(equipid,256,4)
				table.insert(obj._equipList,{equipid,lv})
				if lv == 1 then obj._hasLv1Equip = true end
			end
		else
			account_data.equipSub[equipid] = nil
		end
	end
	table.sort(obj._equipList,function(a,b) return  a[1] > b[1] end)
end
--重排所有装备
function __equipbag.reorderEquips(obj,removeList)
	obj._hasLv1Equip = false
	obj:egSetWidgetTouchEnabled(kBtnResolveAll,false)
	obj:egSetWidgetTouchEnabled(kBtnResolve,false)
	obj:egSetWidgetTouchEnabled(kBtnArm,false)
	local selectEquipId = obj._selectedEquip:getprop("equipid")
	local scrollview = obj:egGetScrollView(kPanelEquip)
	local isCalled = false
	local function resolveCallback()
		for idx= #obj._equipList ,1,-1 do
			local equipid = obj._equipList[idx][1]
			if not account_data.equipSub[equipid] then
			    local newSelectEquipId =obj._selectedEquip:getprop("equipid")
			    if newSelectEquipId then selectEquipId = newSelectEquipId end
				if selectEquipId == equipid then obj._selectedEquip = nil end
				if obj._equipItems[equipid] then
					scrollview:removeChildByTag(idx)
					obj._equipItems[equipid] = nil
				end
				table.remove(obj._equipList,idx)
			else
				if obj._equipList[idx][2] == 1 then obj._hasLv1Equip = true end
			end
		end
		local itemCnt = #obj._equipList
		if itemCnt%kColNum == 0 then
			for key,equipitem in pairs(obj._blankEquip) do
				if key > kColNum*kMinRow then
					scrollview:removeChildByTag(key,true)
					obj._blankEquip[key] = nil
				end
			end
		end
		local loadCnt = scrollview:getChildrenCount()
		obj._totalRow = math.max(math.ceil(itemCnt/kColNum),kMinRow)
		obj._totalH = obj._totalRow*kCellH
		obj._loadRow = math.max(math.ceil(loadCnt/kColNum),kMinRow)
		local size = scrollview:getInnerContainerSize()
		if size.height > obj._totalH then
			scrollview:setInnerContainerSize(CCSizeMake(size.width,obj._totalH))
			scrollview:jumpToTop()
		end
		for idx = 1,obj._loadRow * kColNum do
			obj:addEquipItem(scrollview,idx)
		end
		if itemCnt == 0 then
			obj:removeSelectedEquip()
		else
			obj:changeSelectedEquip(obj._equipItems[obj._equipList[1][1]])
		end
		if obj._resolveCallback then obj._resolveCallback() end
		obj:egSetWidgetTouchEnabled(kBtnResolveAll,true)
		obj:egSetWidgetTouchEnabled(kBtnResolve,true)
		obj:egSetWidgetTouchEnabled(kBtnArm,true)
	end
	for key,equipid in ipairs(removeList) do
		if obj._equipItems[equipid] then
			if isCalled== false then 
				isCalled = true
				obj._equipItems[equipid]:resolveWithAction(resolveCallback)
			else
				obj._equipItems[equipid]:resolveWithAction()
			end
		end
	end
	if isCalled == false then	
		resolveCallback() 
	end
	
end
function __equipbag.loadEquip(obj)
	local scrollview = obj:egGetScrollView(kPanelEquip)
	local itemCnt = #obj._equipList
	obj._totalRow = math.max(math.ceil(itemCnt/kColNum),kMinRow)
	obj._totalH = obj._totalRow*kCellH
	obj._loadRow = 0
	obj._equipItems={}
	obj._blankEquip ={}
	local size = scrollview:getSize()
	if size.height<obj._totalH then
		scrollview:setInnerContainerSize(CCSizeMake(size.width,obj._totalH))
		scrollview:jumpToTop()
	end
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadRow >=  obj._totalRow then return end
            local innerContainer = scrollview:getInnerContainer()
            local posY = innerContainer:getPositionY()
            if (obj._loadRow*kCellH) - posY  < innerContainer:getSize().height then
                obj:addEquipRow(1)
            end
        end
    end
	obj:addEquipRow(kMinRow)
    scrollview:addEventListenerScrollView(scrollEvent)
end
function __equipbag.addEquipRow(obj,rowCnt)
	 if obj._loadRow >=  obj._totalRow then return end
	local startIdx = obj._loadRow*kColNum + 1
	local endIdx = math.min(obj._loadRow*kColNum + rowCnt*kColNum,obj._totalRow*kColNum)
	local scrollview = obj:egGetScrollView(kPanelEquip)
	for idx = startIdx,endIdx do
		obj:addEquipItem(scrollview,idx)
	end
	obj._loadRow = obj._loadRow + rowCnt
end
function __equipbag.addEquipItem(obj,scrollview,idx)
	local equipinfo = obj._equipList[idx]
	if equipinfo then
		local equipid = equipinfo[1]
		if obj._equipItems[equipid] then
			obj._equipItems[equipid]:egSetPosition((idx-1)%kColNum*kCellH + 5,(obj._totalRow-math.ceil(idx/kColNum))*kCellH + 10)
			obj._equipItems[equipid]:egNode():setTag(idx)
		else
			local equipitem =  EquipBagItem.new(obj._equipPos,equipid)
			scrollview:addChild(equipitem:egNode(),1,idx)
			equipitem:egSetPosition((idx-1)%kColNum*kCellH + 5,(obj._totalRow-math.ceil(idx/kColNum))*kCellH + 10)
			obj._equipItems[equipid]=equipitem
			if idx == 1 then
				obj:changeSelectedEquip(equipitem)
			end
			equipitem:onClicked(function(sender) obj:changeSelectedEquip(sender) end)
			
		end
	elseif not equipinfo then
		if not scrollview:getChildByTag(idx) then
			local equipitem =  EquipBagItem.new(obj._equipPos)
			scrollview:addChild(equipitem:egNode(),1,idx)
			obj._blankEquip[idx] = equipitem
			equipitem:egSetPosition((idx-1)%kColNum*kCellH + 5,(obj._totalRow-math.ceil(idx/kColNum))*kCellH + 10)
		end
	end
end
function __equipbag.changeSelectedEquip(obj,equipitem)
		if obj._selectedEquip then obj._selectedEquip:setSelected(false) end
		obj._selectedEquip = equipitem
		equipitem:setSelected(true)
		local subid = equipitem:getprop("subid")
		local sublv = equipitem:getprop("curLv")
		local subqa = equipitem:getprop("curQa")
		local subid = equipitem:getprop("subid")
		local s_cfg = equipFuncs.getSubEquipCfg(subid)
		local equiprop = equipFuncs.getSubEquip(subid,sublv)
		obj:egChangeImg(kImgEquip,s_cfg.icon,UI_TEX_TYPE_PLIST)
		obj:egSetBMLabelStr(kLblEquipLv,sublv)
		obj:egSetLabelStr(kLblEquipName,s_cfg.name)
		obj:loadEquipProp(equiprop)
		if obj._equipPos == 1 then
			local heroBp = baseCalc.getBattlePoint(obj._heroprop.lv,obj._heroprop.grade,obj._equiplv,obj._equipqa,sublv,subqa,obj._sub2_lv,obj._sub2_qa)
			obj._BPItem:setNewVal(heroBp)
			obj._ATKItem:setNewVal(obj._power - (obj._subprop1.power or 0) + (equiprop.power or 0))
			obj._HPItem:setNewVal(obj._maxHP - (obj._subprop1.maxHP or 0) + (equiprop.maxHP or 0))
			obj._CTItem:setNewVal(obj._critical - (obj._subprop1.critical or 0) + (equiprop.critical or 0))
			obj._DGItem:setNewVal(obj._dodge - (obj._subprop1.dodge or 0) + (equiprop.dodge or 0))
		else
			local heroBp = baseCalc.getBattlePoint(obj._heroprop.lv,obj._heroprop.grade,obj._equiplv,obj._equipqa,obj._sub1_lv,obj._sub1_qa,sublv,subqa)
			obj._BPItem:setNewVal(heroBp)
			obj._ATKItem:setNewVal(obj._power - (obj._subprop2.power or 0) + (equiprop.power or 0))
			obj._HPItem:setNewVal(obj._maxHP - (obj._subprop2.maxHP or 0) + (equiprop.maxHP or 0))
			obj._CTItem:setNewVal(obj._critical - (obj._subprop2.critical or 0) +(equiprop.critical or 0))
			obj._DGItem:setNewVal(obj._dodge - (obj._subprop2.dodge or 0) + (equiprop.dodge or 0))
		end
		local panel = obj:egGetListView(kPanelHero)
		local propW = math.max(obj._BPItem:getWidth(),obj._ATKItem:getWidth(),obj._HPItem:getWidth(),obj._CTItem:getWidth(),obj._DGItem:getWidth())
		panel:setPosition(ccp(obj._panelX + (obj._panelW - propW)/2,obj._panelY))
end
--加载装备属性
function __equipbag.loadEquipProp(obj,equiprop)
	local panelprop = obj:egGetListView(kPanelProp)
	while panelprop:getChildrenCount() > 0 do
	    panelprop:removeLastItem()
	end
	panelprop:removeAllItems()
	for idx,propname in ipairs(kPropKeys) do
		local propval = equiprop[propname]
		if propval and propval ~= 0 then 
			local propitem = InfoPropItem.new(propname,propval)
			panelprop:pushBackCustomItem(propitem:egNode())
		end
	end
end
function __equipbag.removeSelectedEquip(obj)
	local panelprop = obj:egGetListView(kPanelProp)
	while panelprop:getChildrenCount() > 0 do
	    panelprop:removeLastItem()
	end
	panelprop:removeAllItems()
	obj:egHideWidget(kImgEquip)
	obj:egHideWidget(kImgEquipLv)
	obj:egHideWidget(kLblEquipName)
	obj._BPItem:setNewVal(obj._heroBp)
	obj._ATKItem:setNewVal(obj._power)
	obj._HPItem:setNewVal(obj._maxHP)
	obj._CTItem:setNewVal(obj._critical)
	obj._DGItem:setNewVal(obj._dodge)
	
	local panel = obj:egGetListView(kPanelHero)
	local propW = math.max(obj._BPItem:getWidth(),obj._ATKItem:getWidth(),obj._HPItem:getWidth(),obj._CTItem:getWidth(),obj._DGItem:getWidth())
	panel:setPosition(ccp(obj._panelX + (obj._panelW - propW)/2,obj._panelY))
end
function __equipbag.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.2,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.2)
    local moveto = CCMoveBy:create(0.2,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __equipbag.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,160))
    
    local widget = obj:egGetWidgetByName(kPanelLayer)
    widget:setPosition(ccp(640,1080))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveBy:create(0.3,ccp(0,-720))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	local function callback()
		if obj._onloaded then obj._onloaded() end
	end
    local callfunc = CCCallFunc:create(callback)
    local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
    widget:runAction(sequece)

end
function __equipbag.onClosing(obj,callback)
	obj._closeCallback = callback
end
function __equipbag.onResolved(obj,callback)
	obj._resolveCallback = callback
end
--装备按钮
function __equipbag.bindArmListener(obj) 
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		if not obj._selectedEquip then
			SoundHelper.playEffect(SoundList.click_shop_goods)
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.noSubEquip,pos.x,pos.y,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		else
			if obj._equipid > 0 then --原来有装备
				SoundHelper.playEffect(SoundList.click_shop_goods)
				local equipid = obj._selectedEquip:getprop("equipid")
				local layer = ConfirmArm.new(obj._equipid,equipid,obj._heroid,obj._equipPos,function() sender:setTouchEnabled(true) end)
				local function closeCallback()
					if obj._closeCallback then obj._closeCallback() end
					obj:hideWithAction()
				end
				layer:onClosed(closeCallback)
				local scene = CCDirector:sharedDirector():getRunningScene()
				scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
			else --原来没有装备
				SoundHelper.playEffect(SoundList.equipup)
				SoundHelper.playEffect(SoundList.equipword)
				local equipid = obj._selectedEquip:getprop("equipid")
				if obj._equipPos == 1 then
					account_data.heroList[obj._heroid].eid_s1 = equipid
				else
					account_data.heroList[obj._heroid].eid_s2 = equipid
				end
				account_data.equipSub[equipid] = math.max(account_data.equipSub[equipid] - 1,0)
				if account_data.equipSub[equipid] == 0 then account_data.equipSub[equipid] = nil end
				SendMsg[939004](obj._heroid,obj._equipPos,equipid,1)
				if obj._closeCallback then obj._closeCallback() end
				obj:hideWithAction()
			end
		end
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --引导状态
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnArm,nil,nil,touchEnded,touchCanceled)
end
--分解按钮
function __equipbag.bindResolveListener(obj) 
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		if not obj._selectedEquip then
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.noSubEquip,pos.x,pos.y,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		else
			local equipid = obj._selectedEquip:getprop("equipid")
			local layer =  ConfirmResolve.new(equipid,function() sender:setTouchEnabled(true) end)
			layer:onClosed(function(removeList) obj:reorderEquips(removeList) end)
			local scene = CCDirector:sharedDirector():getRunningScene()
			scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
		end
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --引导状态
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnResolve,nil,nil,touchEnded,touchCanceled)
end
--分解所有一级装备按钮
function __equipbag.bindResAllListener(obj) 
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		if obj._hasLv1Equip==true then
			local layer =  ConfirmResolve.new(nil,function() sender:setTouchEnabled(true) end)
			layer:onClosed(function(removeList) obj:reorderEquips(removeList) end)
			local scene = CCDirector:sharedDirector():getRunningScene()
			scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
		else
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.needLv1Equip,pos.x,pos.y,ccp(0.5,0))
			sender:setTouchEnabled(true)
		end
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --引导状态
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnResolveAll,nil,nil,touchEnded,touchCanceled)
end
--返回按钮
function __equipbag.bindBackListener(obj) 
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_paper_close)
		if obj._closeCallback then obj._closeCallback() end
        obj:hideWithAction()
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --引导状态
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
EquipBag={}
function EquipBag.new(heroid,equipPos,onloaded)
     local obj =  TouchWidget.new(JsonList.equipBag)
    table_aux.unpackTo(__equipbag, obj)
    obj._onloaded = onloaded
    obj:init(heroid,equipPos)
    obj:bindBackListener()
	obj:bindArmListener()
	obj:bindResolveListener()
	obj:bindResAllListener()
    return obj
end

local kImgRecmd = "img_type_bg"
local kLblRecmd = "lbl_type"
local kLblDesc = "lbl_item_name"
local kImgCoin = "img_pay_icon"
local kLblCoin = "lbl_pay_val"
local kPanelItem = "item_box"
local kBtnRecharge = "btn_recharge"
local kImgLight = "img_light"
local kRedColor = ccc3(255,0,0)
local __shopitem = {}
function __shopitem.init(obj,itemdata)
	obj._itemdata = itemdata
	if obj._itemdata.recmdTxt then
		obj:egSetLabelStr(kLblRecmd,obj._itemdata.recmdTxt)
	else
		obj:egHideWidget(kImgRecmd)
		obj:egHideWidget(kLblRecmd)
	end
	if obj._itemdata.desc and string.len(obj._itemdata.desc)>0 then
		obj:egSetLabelStr(kLblDesc,obj._itemdata.desc)
	else
		obj:egHideWidget(kLblDesc)
	end
	obj._coinname = KVariantList.coinType[obj._itemdata.payCoin]
	obj:egChangeImg(kImgCoin,ImageList[string.format("comm_%s",obj._coinname)],UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblCoin,obj._itemdata.payVal)
	local panel = obj:egGetWidgetByName(kPanelItem)
	if obj._itemdata.mType == 1 then
		local cointype = KVariantList.coinType[obj._itemdata.sType]
		obj._awarditem = ResAward.new(cointype,Funs.signedNum(obj._itemdata.gainVal))
		panel:addChild(obj._awarditem:egNode())
	elseif obj._itemdata.mType==2 then
		obj._awarditem = HeroAward.new(obj._itemdata.sType,obj._itemdata.gainVal)
		panel:addChild(obj._awarditem:egNode())
	elseif obj._itemdata.mType == 3 then
		local equipid = equipFuncs.getSubEquipId(obj._itemdata.sType,obj._itemdata.lv,obj._itemdata.qa)
		obj._awarditem = EquipAward.new(equipid)
		panel:addChild(obj._awarditem:egNode())
	elseif obj._itemdata.mType == 4 then
		local timeVal,timeUnit = Funs.formatTimeEn(obj._itemdata.gainVal)
		obj._awarditem = ResAward.new("pvpGuard",timeVal..timeUnit)
		panel:addChild(obj._awarditem:egNode())
	end
	if account_data[obj._coinname] < obj._itemdata.payVal then
		obj:egSetWidgetColor(kLblCoin,kRedColor)
	else
		obj:bindUpdate()
	end
end
function __shopitem.showBoxLight(obj)
	local widget = obj:egGetWidgetByName(kImgLight)
	widget:stopAllActions()
	widget:setScale(1.4)
	widget:runAction(CCScaleTo:create(1,0.8))
end
function __shopitem.bindClickListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		if account_data[obj._coinname] < obj._itemdata.payVal then
			if obj._itemdata.payCoin == KVariantList.coinName.jewel then
				showPopCharge(obj._itemdata.payVal,function()  sender:setTouchEnabled(true) end)
			else
				local text = string.format("%s %d",TxtList.needgold,obj._itemdata.payVal)
				local pos = convertToWorldSpace(ccp(sender:getPositionX(),sender:getPositionY() + sender:getSize().height/2))
				showPopTxt(text,pos.x,pos.y,ccp(0,0.5))
				sender:setTouchEnabled(true)
			end
		else
			local layer =  ShopConfirm.new(obj._itemdata,function() sender:setTouchEnabled(true) end)
			local function clickCallback()
				obj:showBoxLight()
				obj._awarditem:blinkItemImg(1,4)
				obj._awarditem:blinkItemLbl(1,4)
				SendMsg[931020](obj._itemdata.itemid)--发送购买信息到服务器
				account_data[obj._coinname] = account_data[obj._coinname] - obj._itemdata.payVal
				if obj._itemdata.mType == 1 then
					local coinname = KVariantList.coinType[obj._itemdata.sType]
					account_data[coinname]=account_data[coinname] + obj._itemdata.gainVal
				elseif obj._itemdata.mType==2 then
					local heroid = obj._itemdata.sType
					account_data.heroInfoList[heroid] = (account_data.heroInfoList[heroid] or 0) + obj._itemdata.gainVal
				elseif obj._itemdata.mType == 3 then
					local equipid = equipFuncs.getSubEquipId(obj._itemdata.sType,obj._itemdata.lv,obj._itemdata.qa)
					account_data.equipSub[equipid] = (account_data.equipSub[equipid] or 0) + 1
				elseif obj._itemdata.mType == 4 then
					if account_data.shellPvp > os.time() then
						account_data.shellPvp = account_data.shellPvp + obj._itemdata.gainVal
					else
						account_data.shellPvp = os.time() + obj._itemdata.gainVal
					end
				end
				if account_data[obj._coinname] < obj._itemdata.payVal then
					obj:egSetWidgetColor(kLblCoin,kRedColor)
				end
			end
			layer:onPayClicked(clickCallback)
			local scene = CCDirector:sharedDirector():getRunningScene()
			scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnRecharge,nil,nil,touchEnded,touchCanceled)
end
function __shopitem.bindUpdate(obj)
	local function update()
		if account_data[obj._coinname] < obj._itemdata.payVal then
			obj:egSetWidgetColor(kLblCoin,kRedColor)
			obj:egUnbindWidgetUpdate(kLblCoin)
		end
	end
	obj:egBindWidgetUpdate(kLblCoin,update)
end
ShopItem={}
function ShopItem.new(itemdata)
	local obj = {}
    CocosWidget.install(obj,JsonList.shopItem)
    table_aux.unpackTo(__shopitem, obj)
    obj:init(itemdata)
	obj:bindClickListener()
    return obj
end
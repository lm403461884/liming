local kPanelLayer = "town_train"
local kImgTrain = "img_train"
local kMarkArrow = "img_arrow"
local kTrainName = "lbl_train_name"
local kTrainNames = "lbl_train_name_s"
local kBarLeft = "bar_left"
local kImgClick = "img_train_click"

local kBtnFight = "btn_fight"
local kBtnGold = "btn_gold"
local kBtnDig = "btn_dig"

local kPanelFight = "fight_panel"
local kPanelGold = "gold_panel"
local kPanelDig = "dig_panel"
local kImgNoteFunc = "img_note_func"
local kImgNote = "img_note"
local kLblLeft = "lbl_left"

local kScale1 = 1.3
local kScale2 = 1.5
local kInterval1 = 1

local __townTrain = {}
function __townTrain.init(obj,trainid)
	obj._trainid = trainid
	obj:egSetLabelStr(kTrainName,TxtList.TrainIntr[obj._trainid])
	obj:egSetLabelStr(kTrainNames,TxtList.TrainIntr[obj._trainid])
	obj:egHideWidget(kBtnFight)
	obj:egHideWidget(kBtnGold)
	obj:egHideWidget(kBtnDig)
	obj:egHideWidget(kPanelDig)
	obj:egHideWidget(kPanelGold)
	obj:egHideWidget(kPanelFight)
	obj:egHideWidget(kImgNoteFunc)
	obj:egHideWidget(kImgNote)
	obj:egHideWidget(kBarLeft)
	if account_data.diggingLvContext > os.time() and obj._trainid ~=train.def.head  then --��ͷ������
		obj:onTrainLicenceUpStaring()
	elseif account_data.diggingLvContext > os.time() and obj._trainid ==train.def.head then
	    obj:onLicenceUpStaring()
	elseif obj._trainid ~= train.def.head then
         obj:onTrainLicenceUpFinished()
    elseif obj._trainid == train.def.head then
        obj:onLicenceUpFinished()
	end
	
	if account_data.train[obj._trainid].exp > os.time() then --����������
		obj:onTrainUpStarting()
	elseif obj._trainid ~= train.def.head then
        obj:onTrainUpFinished()	
	end
end
--��ͷ��������ʱ
function __townTrain.bindLicenceUpCounter(obj)
	local s_data = licenceLevelup[account_data.digLv]
	local function update(delta)
		local left_sec =  math.max(math.ceil(account_data.diggingLvContext - os.time()),0)
		obj:egSetBMLabelStr(kLblLeft,Funs.formatTime(left_sec))
        obj:egSetBarPercent(kBarLeft,100- left_sec*100/s_data.duration)
		if left_sec == 0 then obj:egUnbindWidgetUpdate(kLblLeft) end
	end
	obj:egBindWidgetUpdate(kLblLeft,update)
end
--��ͨ������������ʱ
function __townTrain.bindTrainUpCounter(obj)
	local trainlv = account_data.train[obj._trainid].lv + 1
	local s_data = train.config[obj._trainid].research[trainlv]
	local function update(delta)
		local left_sec =  math.max(math.ceil(account_data.train[obj._trainid].exp - os.time()),0)
		obj:egSetBMLabelStr(kLblLeft,Funs.formatTime(left_sec))
        obj:egSetBarPercent(kBarLeft,100- left_sec*100/s_data.duration)
		if left_sec == 0 then obj:egUnbindWidgetUpdate(kLblLeft) end
	end
	obj:egBindWidgetUpdate(kLblLeft,update)
end

--��ͨ������������¼�����
function __townTrain.onTrainUpFinished(obj,eventName)
	if eventName then unBindObserver(obj:egNode(),eventName) end
	bindObserver(obj:egNode(),function(eName) obj:onTrainUpStarting(eName) end,kEventTrainUpStart..obj._trainid)
	local tarinlv = account_data.train[obj._trainid].lv
	local s_data = train.config[obj._trainid].research[tarinlv]
	
	obj:showLvUpFlag()--��ʾ������������ʶ
	obj:egHideWidget(kBarLeft)
	obj:egUnbindWidgetUpdate(kLblLeft)
	obj:showUpdateAnima(false) --�ر���������
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	obj:showAnimate()
	if  not obj._canLvUp then
		obj:showFuncFlag()
	else
    	local funcImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
        funcImg:setVisible(false)
		funcImg:stopAllActions()   
	end
	--[[if eventName then
	    local imgTrain = obj:egGetWidgetByName(kImgTrain)
    	local posy = imgTrain:getPositionY()
	    imgTrain:setPosition(ccp(imgTrain:getPositionX(),posy+2.5))
	end--]]
end
--��ͨ���Ὺʼ�����ص�����
function __townTrain.onTrainUpStarting(obj,eventName)
	if eventName then unBindObserver(obj:egNode(),eventName) end
	bindObserver(obj:egNode(),function(eName) obj:onTrainUpFinished(eName) end,kEventTrainUpEnd..obj._trainid)
	obj:egShowWidget(kBarLeft)
	obj:hideAnimate()
	obj:showUpdateAnima(true) --������������
	obj:bindTrainUpCounter()
	obj:showLvUpFlag()--��ʾ������������ʶ
	obj:showFuncFlag()
	
	 --local imgTrain = obj:egGetWidgetByName(kImgTrain)
     --local posy = imgTrain:getPositionY()
	 --imgTrain:setPosition(ccp(imgTrain:getPositionX(),posy+1.4))
end
--��ͨ������������
function __townTrain.showUpdateAnima(obj,show)
	local imgTrain = tolua.cast(obj:egGetWidgetByName(kImgTrain),"ImageView")
	local sprite = tolua.cast(imgTrain:getVirtualRenderer(),"CCSprite") 
	if show then
		local anima = graphicLoader.getAnimation(actList.trainUpdateAct)
		anima:setRestoreOriginalFrame(true)
		local animate = CCAnimate:create(anima)
		local action = CCRepeat:create(animate,1000000)
		sprite:runAction(action) 
	else
		sprite:stopAllActions()
	end
end
--ִ�յȼ�������� ��ͨ�������
function __townTrain.onTrainLicenceUpFinished(obj,eventName)
	if eventName then unBindObserver(obj:egNode(),eventName) end
	bindObserver(obj:egNode(),function(eName) obj:onTrainLicenceUpStaring(eName) end,kEventLicenceUpStart)
	obj:showLvUpFlag()--��ʾ������������ʶ
	if not obj._canLvUp then
	    obj:showFuncFlag()
	else
	    local funcImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
        funcImg:setVisible(false)
		funcImg:stopAllActions()    
	end
end
--��ʼִ������ ��ͨ�������
function __townTrain.onTrainLicenceUpStaring(obj,eventName)
	if eventName then unBindObserver(obj:egNode(),eventName) end
	bindObserver(obj:egNode(),function(eName) obj:onTrainLicenceUpFinished(eName) end,kEventLicenceUpEnd)
	obj:showLvUpFlag()--��ʾ������������ʶ
	if not obj._canLvUp then
	    obj:showFuncFlag()
	end    
end
--��ͷ��������
function __townTrain.showHeadUpdateAnima(obj,show)
	local imgTrain = tolua.cast(obj:egGetWidgetByName(kImgTrain),"ImageView")
	local sprite = tolua.cast(imgTrain:getVirtualRenderer(),"CCSprite") 
	if show then
		local anima = graphicLoader.getAnimation(actList.headUpdateAct)
		anima:setRestoreOriginalFrame(true)
		local animate = CCAnimate:create(anima)
		local action = CCRepeat:create(animate,1000000)
		sprite:runAction(action) 
	else
		sprite:stopAllActions()
	end
end
--��ʾ����������ʾ
function __townTrain.showLvUpFlag(obj)
	local flagImg = tolua.cast(obj:egGetWidgetByName(kImgNote),"ImageView")
	local trainlv = account_data.train[obj._trainid].lv 
	local rearchData = train.config[obj._trainid].research[trainlv+1]
	obj._canLvUp = rearchData and rearchData.licence <= account_data.digLv and (account_data.train[obj._trainid].exp < os.time())
	flagImg:setVisible(obj._canLvUp)
	if obj._canLvUp then
		obj:scaleWidget(flagImg,kScale1,kScale2,kInterval1)
	else
		flagImg:stopAllActions()
	end
end
--��ʾ��ͷ������ʾ
function __townTrain.showHeadLvUpFlag(obj)
	local flagImg = tolua.cast(obj:egGetWidgetByName(kImgNote),"ImageView")
	local rearchData = licenceLevelup[account_data.digLv+1]
	local s_data = licenceLevelup[account_data.digLv]
	obj._canLvUp = rearchData and s_data.stars<= account_data.unlockedPVE[s_data.areaID].areaStars and ( account_data.diggingLvContext < os.time())
	flagImg:setVisible(obj._canLvUp)
	if obj._canLvUp then
		obj:scaleWidget(flagImg,kScale1,kScale2,kInterval1)
	else
		flagImg:stopAllActions()
	end
end
function __townTrain.showAnimate(obj)
    if not trainAnima[obj._trainid] then return end
	local lv = account_data.train[obj._trainid].lv
	if obj._trainid == train.def.head then
		lv = account_data.digLv
	end
	local animaList = trainAnima[obj._trainid][lv]
	if not animaList or #animaList == 0 then return end
	obj._animaObjList = {}
    for idx,animaData in ipairs (animaList) do
        local graphName = animaData.name
        local imgTrain = obj:egGetWidgetByName(kPanelLayer)
        local img = ImageView:create()
		table.insert(obj._animaObjList,img)
        img:loadTexture(ImageList.comm_blank,UI_TEX_TYPE_PLIST)
        img:setScale(animaData.scale)
        img:setPosition(ccp(animaData.x,animaData.y))
        imgTrain:addChild(img,animaData.zorder or 2)
		if animaData.reCnt then
			local passed = 0
			local anima = graphicLoader.getAnimation(graphName)
			anima:setRestoreOriginalFrame(true)
			local delaySec = anima:getTotalDelayUnits() * anima:getDelayPerUnit()*animaData.reCnt + animaData.interval 
			local function update(delta)
				passed = passed + delta
				if passed >= delaySec then
					passed = 0
					local animate = CCAnimate:create(anima)
					local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite") 
					sprite:stopAllActions()
					if animaData.reCnt > 1 then 
						local action = CCRepeat:create(animate,animaData.reCnt)
						sprite:runAction(action)
					else
						sprite:runAction(animate)
					end
				end
			end
			local function exitFuns(eventType)
				if eventType == "exit" then  img:unscheduleUpdate() end
			end
			img:scheduleUpdateWithPriorityLua(update, 0)
			img:registerScriptHandler(exitFuns)
		else
			local anima = graphicLoader.getAnimation(graphName)
			anima:setRestoreOriginalFrame(true)
			local animate = CCAnimate:create(anima)
			local action = CCRepeat:create(animate,1000000)
		
			local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite") 
			sprite:runAction(action)
		end
		
    end  
end
function __townTrain.hideAnimate(obj)
	if not obj._animaObjList or #obj._animaObjList == 0 then return end
	for key,animaObj in ipairs(obj._animaObjList ) do
		local imgTrain = obj:egGetWidgetByName(kPanelLayer)
		imgTrain:removeChild(animaObj,true)
	end
	obj._animaObjList = nil
end
function __townTrain.showTrainClickAnima(obj)
    local img = obj:egGetWidgetByName(kImgClick)
	img:setPosition(ccp(31,-60))
    local anima = graphicLoader.getAnimation(actList.trainClickAct)
	anima:setRestoreOriginalFrame(true)
	local callfunc = CCCallFunc:create(function() obj:egChangeImg(kImgClick,ImageList.comm_blank,UI_TEX_TYPE_PLIST) end)
	local animate = CCAnimate:create(anima)
    local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite") 
	local sequence = CCSequence:createWithTwoActions(animate,callfunc)
	sprite:stopAllActions()
    sprite:runAction(sequence)
end
function __townTrain.scaleWidget(obj,widget,from,to,s)
	local scaleto1 = CCScaleTo:create(s,from)
	local scaleto2 = CCScaleTo:create(s,to)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end
function __townTrain.getTrainID(obj)
    return obj._trainid
end
function __townTrain.getTrain(obj)
    return obj:egGetWidgetByName(kImgTrain)
end

function __townTrain.setSelected(obj,selected)
	if selected then
		obj:egNode():setScale(1.1)
	else
		obj:egNode():setScale(1)
	end
end
function __townTrain.onClicked(obj,callback)
    obj._clickCallBack = callback
end
function __townTrain.bindClickListener(obj)
    local function touchEnded(sender)
		
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.Steam_update)
		obj:showTrainClickAnima()
		if obj._clickCallBack then obj._clickCallBack(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgTrain,nil,nil,touchEnded,touchCanceled)
end
function __townTrain.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
TownTrain = {}
function TownTrain.new(trainid)
    local obj = {}
    CocosWidget.install(obj,JsonList.townTrain)
    table_aux.unpackTo(__townTrain, obj)
	TrainInitial.install(obj,trainid) --加载各车箱自己的代码
	obj:init(trainid)
	obj:initSelfData(trainid)
	obj:bindClickListener()
	obj:autoUnbindObserver()
    return obj
end

local kImgPhoto = "img_hero"
local kLblMsgNum = "lbl_num"

local __heromsgaward={}
function __heromsgaward.init(obj,heroid,msgnum)
    obj._heroid = heroid
    local s_cfg =  hero_data.getConfig(obj._heroid)
    obj:egChangeImg(kImgPhoto,s_cfg.headPic,UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblMsgNum,Funs.signedNum(msgnum)) 
end
function __heromsgaward.blinkItemImg(obj,s,t)
	local widget = obj:egGetWidgetByName(kImgPhoto)
	widget:stopAllActions()
	widget:setVisible(true)
	widget:setOpacity(255)
	widget:runAction(CCBlink:create(s,t))
end
function __heromsgaward.blinkItemLbl(obj,s,t)
	local widget = obj:egGetWidgetByName(kLblMsgNum)
	widget:stopAllActions()
	widget:setVisible(true)
	widget:setOpacity(255)
	widget:runAction(CCBlink:create(s,t))
end
HeroAward={}
function HeroAward.new(heroid,msgnum)
    local obj = {}
    CocosWidget.install(obj,JsonList.heroAward)
    table_aux.unpackTo(__heromsgaward, obj)
    obj:init(heroid,msgnum)
    return obj
end


local kJewellbl = "own_jewel_val"
local kBtnJeweadd = "btn_jewel_add"
local kPanelJewel = "own_jewel"

local kGoldlbl = "own_gold_val"
--local kMaxGoldlbl = "own_gold_max"
local kBtnGoldadd = "btn_gold_add"
local kPanelGold = "own_gold"
local kGoldBar = "own_gold_bar"

local kActlbl = "own_act_val"

--local kMaxActlbl= "own_act_max"
local kActBar = "own_act_bar"
local kBtnActadd= "btn_act_add"
local kPanelAct = "own_act"

local kMaxNumDefault = 10000
local kActShowS = 15
local kTimeShowS = 5
local kFlagAct = 1
local kFlagTime = 2
local kMaxGoldN = 999999
local kMaxJewelN = 999999
local kMaxActN = 999
local __proplayer={}
function __proplayer.init(obj,d_data)
    if not d_data then d_data = account_data end
    obj._d_data = d_data
    obj._act =obj._d_data.actPt
    obj._jewel = obj._d_data.jewel
    obj._gold = obj._d_data.gold
     
    obj._maxAct = obj._d_data.maxActPt 
    obj._maxGold = obj._d_data.maxGold or kMaxNumDefault
    
    obj:egSetBMLabelStr(kActlbl,string.format("%s%s%d",Funs.getBouncedNum(obj._act,kMaxActN),"/",obj._maxAct))
    obj:egSetBMLabelStr(kJewellbl,Funs.getBouncedNum(obj._jewel,kMaxJewelN,true))
    obj:egSetBMLabelStr(kGoldlbl,Funs.getBouncedNum(obj._gold,kMaxGoldN,true))
   
    obj:egSetBarPercent(kGoldBar,obj._gold*100/obj._maxGold)
    obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
end
function __proplayer.getAddVal(obj,old,new)
	local val = new-old
	if val > 0 then
		val = math.ceil(val/10)
	else
		val = math.floor(val/10)
	end
	return val
end
function __proplayer.activeUpdate(obj)
	obj._flag = math.random(1,2)
	obj._counter = kActShowS
	if obj._flag == kFlagTime then obj._flag = kTimeShowS end
    local function updateFunc(delta)
    if obj._act ~= obj._d_data.actPt then
		obj._counter = kActShowS
		obj._flag = kFlagAct
        obj._act = obj._act + obj:getAddVal(obj._act,obj._d_data.actPt)
		if obj._act > kMaxActN and obj._d_data.actPt <= kMaxActN then
			obj._act = kMaxActN
		elseif obj._act >= kMaxActN and obj._d_data.actPt > kMaxActN then
			obj._act = obj._d_data.actPt
		end
        obj:egSetBMLabelStr(kActlbl,string.format("%s%s%d",Funs.getBouncedNum(obj._act,kMaxActN),"/",obj._maxAct))
        obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
    end
	if obj._act < obj._maxAct then
		obj._counter = obj._counter - delta
		if obj._flag == kFlagTime then
			local left = math.max(numDef.durAP-((os.time()-1) - account_data.rcAP),0)
			if obj._counter <= 0  or left<= 0 then
				obj._counter = kActShowS
				obj._flag = kFlagAct
				if left > 0 then
					obj:egSetBMLabelStr(kActlbl,string.format("%d%s%d",obj._act,"/",obj._maxAct))
					obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
				else
					obj:egSetBMLabelStr(kActlbl,string.format("%d%s%02d",math.floor(left/60),":",left%60))
					obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
				end
			else
				obj:egSetBMLabelStr(kActlbl,string.format("%d%s%02d",math.floor(left/60),":",left%60))
				obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
			end
		elseif obj._counter <= 0 then
			obj._counter = kTimeShowS
			obj._flag = kFlagTime
		end
	end
     
     if obj._jewel ~= obj._d_data.jewel then
        obj._jewel =  obj._jewel + obj:getAddVal(obj._jewel,obj._d_data.jewel)
		if obj._jewel > kMaxJewelN and obj._d_data.jewel <= kMaxJewelN then
			obj._jewel = kMaxJewelN
		elseif obj._jewel >= kMaxJewelN and obj._d_data.jewel > kMaxJewelN then
			obj._jewel = obj._d_data.jewel
		end
        obj:egSetBMLabelStr(kJewellbl,Funs.getBouncedNum(obj._jewel,kMaxJewelN,true))
     end
     if obj._gold ~= obj._d_data.gold then
		
        obj._gold = obj._gold + obj:getAddVal(obj._gold,obj._d_data.gold)
		if obj._gold > kMaxGoldN and obj._d_data.gold <= kMaxGoldN then
			obj._gold = kMaxGoldN
		elseif obj._gold >= kMaxGoldN and obj._d_data.gold > kMaxGoldN then
			obj._gold = obj._d_data.gold
		end
        obj:egSetBMLabelStr(kGoldlbl,Funs.getBouncedNum(obj._gold,kMaxGoldN,true))
        obj:egSetBarPercent(kGoldBar,obj._gold*100/obj._maxGold)
     end
    end
    obj:egBindUpdate(updateFunc)
end
function __proplayer.onAddApClicked(obj,widgetName)
	local widget = obj:egGetWidgetByName(widgetName)
	local posx = widget:getPositionX() + widget:getSize().width/2
	local posy = widget:getPositionY() + widget:getSize().height/2
	if widgetName == kBtnActadd then
		local panel = obj:egGetWidgetByName(kPanelAct)
		posx = panel:getPositionX() + widget:getPositionX()
		posy = panel:getPositionY() + widget:getPositionY()  - widget:getSize().height*widget:getAnchorPoint().y
	end
	if os.time() >= account_data.actPtNextSt then
		account_data.apBoughtCnt = 0
		account_data.actPtSt = os.time()
		account_data.actPtNextSt = Funs.getTimeWithHMS(numDef.actPtUTH,numDef.actPtUTM,0,account_data.scOffsetTime)
	end
	local maxBoughtCnt = VipLvUp[account_data.vip or 0].apCnt or 0
	if account_data.apBoughtCnt >= maxBoughtCnt then
		showPopTxt(TxtList.maxBoughtCnt,posx,posy,ccp(0.5,1))
		widget:setTouchEnabled(true)
	elseif account_data.actPt >= numDef.actPtCrestVal then
		showPopTxt(TxtList.actPtCrestVal,posx,posy,ccp(0.5,1))
		widget:setTouchEnabled(true)
	else
		local apPirce =  jewelCalc.getPriceForActPt(account_data.apBoughtCnt)
		if apPirce > account_data.jewel then
			showPopCharge(apPirce,function() widget:setTouchEnabled(true) end)
		else
			showApMarket(99,function() widget:setTouchEnabled(true) end)
		end
	end
end
--购买行动力按钮
function __proplayer.bindApListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj:onAddApClicked(kBtnActadd)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnActadd,nil,nil,touchEnded,touchCanceled)
end
function __proplayer.bindApPanelListener(obj)
	local function touchBegin(sender)
		obj:egGetWidgetByName(kBtnActadd):setFocused(true)
	end
	local function touchEnded(sender)
		obj:egGetWidgetByName(kBtnActadd):setFocused(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj:onAddApClicked(kPanelAct)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kBtnActadd):setFocused(false)
		end
	end
    obj:egBindTouch(kPanelAct,touchBegin,nil,touchEnded,touchCanceled)
end
function __proplayer.onAddGoldClicked(obj,widgetName)
	local widget = obj:egGetWidgetByName(widgetName)
	local posx = widget:getPositionX() + widget:getSize().width/2
	local posy = widget:getPositionY() + widget:getSize().height/2
	if widgetName == kBtnGoldadd then
		local panel = obj:egGetWidgetByName(kPanelGold)
		posx = panel:getPositionX() + widget:getPositionX()
		posy = panel:getPositionY() + widget:getPositionY()  - widget:getSize().height*widget:getAnchorPoint().y
	end
	if os.time() >= account_data.goldNextSt then
		account_data.goldBoughtCnt = 0
		account_data.goldNextSt = Funs.getTimeWithHMS(numDef.goldRefreshUTH,numDef.goldRefreshUTM,0,account_data.scOffsetTime)
	end
	local maxBoughtCnt = VipLvUp[account_data.vip or 0].goldCnt or 0
	if account_data.goldBoughtCnt >= maxBoughtCnt then
		showPopTxt(TxtList.maxBoughtCnt,posx,posy,ccp(0.5,1))
		widget:setTouchEnabled(true)
	else
		local apPirce,_ =  jewelCalc.getPriceForGold(account_data.digLv)
		if apPirce > account_data.jewel then
			showPopCharge(apPirce,function() widget:setTouchEnabled(true) end)
		else
			showApMarket(1,function() widget:setTouchEnabled(true) end)
		end
	end
end
--购买金币按钮
function __proplayer.bindGoldListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj:onAddGoldClicked(kBtnGoldadd)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGoldadd,nil,nil,touchEnded,touchCanceled)
end
function __proplayer.bindGoldPanelListener(obj)
	local function touchBegin(sender)
		obj:egGetWidgetByName(kBtnGoldadd):setFocused(true)
	end
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kBtnGoldadd):setFocused(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		obj:onAddGoldClicked(kPanelGold)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kBtnGoldadd):setFocused(false)
		end
	end
    obj:egBindTouch(kPanelGold,touchBegin,nil,touchEnded,touchCanceled)
end
--购买星钻按钮
function __proplayer.bindJewelListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		showPurchaseLayer(function() sender:setTouchEnabled(true) end)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnJeweadd,nil,nil,touchEnded,touchCanceled)
end
function __proplayer.bindJewelPanelListener(obj)
	local function touchBegin(sender)
		obj:egGetWidgetByName(kBtnJeweadd):setFocused(true)
	end
	local function touchEnded(sender)
		obj:egGetWidgetByName(kBtnJeweadd):setFocused(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		showPurchaseLayer(function() sender:setTouchEnabled(true) end)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --引导状态
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kBtnJeweadd):setFocused(false)
		end
	end
    obj:egBindTouch(kPanelJewel,touchBegin,nil,touchEnded,touchCanceled)
end
PropLayer = {}
function PropLayer.new(d_data)
    local obj = TouchWidget.new(JsonList.propLayer)
   -- CocosWidget.install(obj,JsonList.propLayer)
    table_aux.unpackTo(__proplayer, obj)
    obj:init(d_data)
    obj:activeUpdate()
	obj:bindApListener()
	obj:bindApPanelListener()
	obj:bindJewelListener()
	obj:bindJewelPanelListener()
	obj:bindGoldListener()
	obj:bindGoldPanelListener()
    return obj
end
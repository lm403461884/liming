local kPanelLayer = "panel_sign"
local kImgSignBg = "img_sign_bg"
local kBtnIntro = "btn_intro"
local kLblTitle = "lbl_title"
local kLblSignNum = "lbl_sign_num"
local kScrollItem = "scroll_item"
local kPanelAward = "panel_award"
local kLblAwardIntro = "lbl_award_intro"
local kLblGet = "lbl_get"
local kBtnGet = "btn_get"
local kBtnBack = "btn_back"
--����˵��
local kPanelIntro = "panel_intro"
local kPanelContent="panel_content"
local kLblIntro = {"lbl_intro1","lbl_intro2","lbl_intro3",}
local kBtnYes = "btn_yes"

local kCellW = 120
local kCellH = 110
local kMaxNum = 5

local __signinlayer={}
function __signinlayer.init(obj)
    obj._selectedIdx = nil
    obj._awardItem = {}
	if os.time() >= account_data.signInExp_m then
        account_data.signInExp_m = obj:getNextSignM()
		account_data.signInCnt = 0
	end
	local t_signM = os.date("*t",account_data.signInExp_m-account_data.scOffsetTime-100)
	obj._month = t_signM.month
    obj:egSetLabelStr(kLblTitle,string.format(TxtList.signInMouth,obj._month))
    obj:egSetLabelStr(kLblSignNum,string.format(TxtList.signInNum,account_data.signInCnt))
    obj:loadSignItem()
    obj:egHideWidget(kPanelIntro)
	obj:showWithAction() 
end
function __signinlayer.getNextSignM(obj)
	local t_day = os.date("*t",os.time())
    if t_day.month == 12 then 
        t_day.month =1
        t_day.year = t_day.year + 1
    else
        t_day.month = t_day.month + 1
    end    
    t_day.day =1
    t_day.hour =0
    t_day.min =0
    t_day.sec =0
    return os.time(t_day)
end
function __signinlayer.loadSignItem(obj)
    obj._scrollview = obj:egGetScrollView(kScrollItem)
    local size = obj._scrollview:getSize()
    local maxRow = math.ceil(#registration.data/kMaxNum)
    local totalCnt = #registration.data
	for idx = 1,totalCnt do 
		local curRow = math.ceil(idx/kMaxNum)
        local y = (maxRow-curRow)*kCellH
        local x = (idx-1)%kMaxNum*kCellW+5
        local awarditem = SignInItem.new(idx)
        awarditem:egSetPosition(x,y)
        awarditem:egNode():setScale(0.7)
        obj:clickAwardItem(awarditem)
        obj._scrollview:addChild(awarditem:egNode(),idx,idx)
        obj._awardItem[idx]=awarditem
        if obj:canGetAward(idx) then 
            obj:loadAwardInfo(awarditem)
            obj._selectedIdx = idx
            obj._selectedItem = awarditem
            awarditem:setWidgetTouchEnabled(false)
        elseif idx>account_data.signInCnt and not obj._selectedIdx then
            awarditem:setWidgetTouchEnabled(false)
            obj:loadAwardInfo(awarditem)
            obj._selectedIdx = idx
            obj._selectedItem = awarditem
            awarditem:setWidgetTouchEnabled(false)    
            obj:egSetWidgetEnabled(kBtnGet,false)
        end
	end
	obj._newH = maxRow*kCellH
    obj._scrollview:setInnerContainerSize(CCSizeMake(size.width,obj._newH))
	if account_data.signInCnt > 15 then
		obj._scrollview:scrollToBottom(0.1,false)
	else	
		obj._scrollview:jumpToTop()
	end
end
function __signinlayer.clickAwardItem(obj,item)
    local function callback()
        local idx = item:getprop("idx")
        if obj._selectedItem then obj._selectedItem:setWidgetTouchEnabled(true) end
        obj._selectedIdx = idx
        obj._selectedItem = item
        obj:loadAwardInfo(item)
    end
    item:onItemClicked(callback)
end
function __signinlayer.loadAwardInfo(obj,item)
    local panelaward = obj:egGetWidgetByName(kPanelAward)
    panelaward:removeAllChildren()
    local idx = item:getprop("idx")
    local iconitem =SignInItem.new(idx)
    obj._panelItem = iconitem
    iconitem:setTouchEnabled(false)
    panelaward:addChild(iconitem:egNode())
    local data = item:getprop("data")
    obj:egSetLabelStr(kLblAwardIntro,data.text)
    local canget = obj:canGetAward(idx)
    if not canget then
        obj:egSetWidgetEnabled(kBtnGet,false)
    else
        obj:egSetWidgetEnabled(kBtnGet,true)
    end
    if idx <= account_data.signInCnt then
        obj:egSetLabelStr(kLblGet,TxtList.received)
    else
        obj:egSetLabelStr(kLblGet,TxtList.receive)
    end
end
function __signinlayer.canGetAward(obj,idx)
    local canget = true
    if idx > account_data.signInCnt + 1 then
        canget = false
    elseif idx == account_data.signInCnt + 1  and os.time()< account_data.signInExp_d then
        canget = false
    elseif idx <= account_data.signInCnt then
        canget = false    
    end
    return canget
end
function __signinlayer.showWithAction(obj)
	obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kImgSignBg)
    widget:setPosition(ccp(640,720))  
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(640,360))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	local function callback()
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
    widget:runAction(sequece)
end
function __signinlayer.hideWithAction(obj,callbackfunc)
    local function callback()
        obj:egRemoveSelf()
        if callbackfunc then callbackfunc() end
    end
	obj:egSetWidgetEnabled(kBtnGet,false)
    obj._masklayer:runAction(CCFadeTo:create(0.5,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(640,1080))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kImgSignBg)
    baseWidget:runAction(squence)
end
function __signinlayer.showPanelIntro(obj)
    --[[local cnt = #registration.explaintext
    local panelWidget = obj:egGetWidgetByName(kPanelContent)
    local totalH = 0
    local w = panelWidget:getSize().width
    for idx=1,cnt do
        local lbl = Label:create()
        lbl:setText(registration.explaintext[idx])
        lbl:setFontSize(24) 
        lbl:setFontName(FNList.STHUPO)
		lbl:setColor(ccc3(83,49,22)) 
		
		local lblW = lbl:getSize().width
		local lblH = lbl:getSize().height
		
		if lblW >= w then
			local rows = math.ceil(lblW/w) + 1
			lblW = w
			lblH = rows*lblH
			lbl:setTextAreaSize(CCSizeMake(lblW,lblH))
		else
			lbl:setTextAreaSize(CCSizeMake(w,lblH))
		end 
		panelWidget:addChild(lbl,0,idx)
		totalH = totalH + lblH
    end--]]
    for idx = 1,3 do
        obj:egSetLabelStr(kLblIntro[idx],registration.explaintext[idx])
    end
    obj._shwoIntro = true
end
--��ȡ����
function __signinlayer.bindBtnGetListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_buy_button)
        obj:egSetWidgetEnabled(kBtnGet,false)
        obj:egSetLabelStr(kLblGet,TxtList.received)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SendMsg[931018]()
        account_data.signInCnt=account_data.signInCnt + 1
        account_data.signInExp_d = Funs.getTimeWithHMS(0,0,0,account_data.scOffsetTime,true) 
        local awarditem =obj._awardItem[obj._selectedIdx]
        awarditem:setBeGot()
		obj._panelItem:setBeGot()
        local data = obj._awardItem[obj._selectedIdx]:getprop("data")
        if data.type then
            name = KVariantList.coinType[data.type]
            account_data[name] = account_data[name] + data.val
        elseif data.heroid then
			account_data.heroInfoList[data.heroid] = (account_data.heroInfoList[data.heroid] or 0) + data.val
        elseif data.eid_s then
            local equipid = equipFuncs.getSubEquipId(data.eid_s,data.lv,data.qal)
			account_data.equipSub[equipid] = (account_data.equipSub[equipid] or 0) + data.val
        end
        obj:egSetLabelStr(kLblSignNum,string.format(TxtList.signInNum,account_data.signInCnt))
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGet,nil,nil,touchEnded,touchCanceled)
end
--�鿴����˵��
function __signinlayer.bindBtnIntroListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        if obj._shwoIntro then
            obj:egShowWidget(kPanelIntro)
        else
            obj:egShowWidget(kPanelIntro)
            obj:showPanelIntro()
        end    
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnIntro,nil,nil,touchEnded,touchCanceled)
end
function __signinlayer.bindBtnYesListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:egHideWidget(kPanelIntro)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __signinlayer.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		AccountHelper:unlock(kStatePrompt)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __signinlayer.timeUpdate(obj)
	local function update()
        if os.time() >= account_data.signInExp_m then
            obj:egUnbindWidgetUpdate(kBtnGet)
			obj:egRemoveSelf()
        end
	end
    obj:egBindWidgetUpdate(kBtnGet,update)
end

SignInLayer={}
function SignInLayer.new(onloaded,onclosed)
	AccountHelper:lock(kStatePrompt)
    local obj =  TouchWidget.new(JsonList.signInLayer)
    table_aux.unpackTo(__signinlayer, obj)
    obj._onloaded = onloaded
    obj:init()
    obj:bindBtnGetListener()
    obj:bindCloseListener()
    obj:bindBtnIntroListener()
    obj:bindBtnYesListener()
	obj:timeUpdate()
    return obj
end
function showSignLayer(onloaded)
    local layer = SignInLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

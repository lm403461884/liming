local kBtnClose="btn_close_charge"
local kBtnCharge="btn_charge"
local kImgBg = "img_charge_bar"
local kImgGray = "img_gray_layer"

local kLblTxt1 = "lbl_note_txt1"
local kLblJewel = "lbl_jewel"
local kImgCoin = "img_note_coin"
local kLblTxt2 = "lbl_note_txt2"
local kLblRes = "lbl_res"
local kImgRes = "img_icon_res"
local kLblSymbol = "lbl_note_txt3"
local kPanelW = 710
local kLblCnt = "lbl_counter"
local kPanelTxt = "txt_panel"
local __apmarket={}
function __apmarket.init(obj,cointype)
	
	obj:egSetWidgetTouchEnabled(kBtnCharge,false)
	obj:egSetWidgetTouchEnabled(kBtnClose,false)
	obj._cointype = cointype
	if cointype == 99 then
		obj:loadApMarktInfo() --�����ж���
	else
		obj:loadGoldMarktInfo() 
	end
	local w = obj:getPanelW()
	local panel = obj:egGetWidgetByName(kPanelTxt)
	local bgbar = obj:egGetWidgetByName(kImgBar)
	panel:setPosition(ccp(panel:getPositionX() + (kPanelW-w)/2,panel:getPositionY()))
	obj:showWithAction()
end
function __apmarket.loadApMarktInfo(obj)
	obj:egSetLabelStr(kLblRes,numDef.apPerJewel)
	local apPirce = jewelCalc.getPriceForActPt(account_data.apBoughtCnt)
	obj:egSetLabelStr(kLblJewel,apPirce)
	local maxBoughtCnt = VipLvUp[account_data.vip or 0].apCnt or 0
	obj:egSetLabelStr(kLblCnt,string.format("%s (%d/%d)",TxtList.boughtCntDay,account_data.apBoughtCnt,maxBoughtCnt))
	obj:bindAPClickListener()
end
function __apmarket.loadGoldMarktInfo(obj)
	local coinres = ImageList[string.format("comm_%s",KVariantList.coinType[obj._cointype])]
	obj:egChangeImg(kImgRes,coinres,UI_TEX_TYPE_PLIST)
	obj._goldPirce,obj._goldNum = jewelCalc.getPriceForGold(account_data.digLv)
	obj:egSetLabelStr(kLblRes,obj._goldNum)
	obj:egSetLabelStr(kLblJewel,obj._goldPirce)
	local maxBoughtCnt = VipLvUp[account_data.vip or 0].goldCnt or 0
	obj:egSetLabelStr(kLblCnt,string.format("%s (%d/%d)",TxtList.boughtCntDay,account_data.goldBoughtCnt,maxBoughtCnt))
	obj:bindGoldClickListener()
end
function __apmarket.getPanelW(obj)

	local w1 = obj:egGetWidgetByName(kLblTxt1):getSize().width
    local w2 = obj:egGetWidgetByName(kLblJewel):getSize().width
    local w3 = obj:egGetWidgetByName(kImgCoin):getSize().width
    local w4 = obj:egGetWidgetByName(kLblTxt2):getSize().width
	local w5 = obj:egGetWidgetByName(kLblRes):getSize().width
    local w6 = obj:egGetWidgetByName(kImgRes):getSize().width
    local w7 = obj:egGetWidgetByName(kLblSymbol):getSize().width
    return w1 + w2 + w3 + w4+ w5 + w6 + w7
end
function __apmarket.showWithAction(obj)
	local bg = obj:egGetWidgetByName(kImgBg)
	local scaleto = CCScaleTo:create(0.3,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		obj:egSetWidgetTouchEnabled(kBtnCharge,true)
		obj:egSetWidgetTouchEnabled(kBtnClose,true)
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	graylayer:setOpacity(0)
	graylayer:runAction(CCFadeTo:create(0.3,128))
	bg:setScale(0)
	bg:runAction(sequence)
end
--�����ж�����ť
function __apmarket.bindAPClickListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SendMsg[931012]() --���͹���������������
		local apPirce = jewelCalc.getPriceForActPt(account_data.apBoughtCnt)
		account_data.jewel = account_data.jewel - apPirce
		account_data.actPt = account_data.actPt + numDef.apPerJewel
		NotifyHelper.show(NotifyCode.actPtFull) --�ж����仯���޸�������Ϣ
		account_data.apBoughtCnt = account_data.apBoughtCnt + 1
        obj:egRemoveSelf()
		SoundHelper.playEffect(SoundList.click_buy_button)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCharge,nil,nil,touchEnded,touchCanceled)
end
--�����Ұ�ť
function __apmarket.bindGoldClickListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SendMsg[931019]() --���͹���������������
		account_data.jewel = account_data.jewel - obj._goldPirce
		account_data.gold = account_data.gold + obj._goldNum
		account_data.goldBoughtCnt = account_data.goldBoughtCnt + 1
        obj:egRemoveSelf()
		SoundHelper.playEffect(SoundList.click_buy_button)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCharge,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __apmarket.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

ApMarket={}
function ApMarket.new(cointype,onloaded)
    local obj =  TouchWidget.new(JsonList.apMarket)
    table_aux.unpackTo(__apmarket, obj)
    obj._onloaded = onloaded
    obj:init(cointype)
    obj:bindCloseListener()
    return obj
end

function showApMarket(cointype,onloaded)
	local layer =  ApMarket.new(cointype,onloaded)
	local scene = CCDirector:sharedDirector():getRunningScene()
	scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

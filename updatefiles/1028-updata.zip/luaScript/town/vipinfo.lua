local kLblVip = "lbl_vip_num"
local kPanelTxt = "desc_list"
local kPanelAward = "award_list"
local margin1 = 2
local margin2 = 10
local kCellW = 142
local kBrownColor = ccc3(83,49,22)
local __vipinfo = {}
function __vipinfo.init(obj,lv)
	obj._lv = lv
	obj._data = VipLvUp[obj._lv]
	obj:egSetLabelStr(kLblVip,string.format("VIP %d",obj._lv))
	obj:loadTxt()
	obj:loadAward()
end
function __vipinfo.loadTxt(obj)
	local txtList = obj._data.desc or {}
	if #txtList == 0 then return end
	local h = 0
	local w = 0
	local panel =  obj:egGetWidgetByName(kPanelTxt)
	for idx = #txtList,1,-1 do
		local lbl = Label:create()
		lbl:setAnchorPoint(ccp(0,0))
		lbl:setText(txtList[idx])
		lbl:setFontSize(32)
		lbl:setFontName(FNList.STHUPO)
		lbl:setColor(kBrownColor)
		panel:addChild(lbl)
		lbl:setPosition(ccp(0,h))
		w = math.max(w,lbl:getSize().width)
		h = h + lbl:getSize().height + margin1
	end
	if h > 0 then h = h - margin1 end
	local size = panel:getSize()
	local offsetX = math.max((size.width - w)/2,0)
	local offsetY = math.max((size.height - h)/2,0)
	panel:setPosition(ccp(panel:getPositionX() + offsetX,panel:getPositionY() + offsetY))
end
function __vipinfo.loadAward(obj)
	local awardList = obj._data.award or {}
	if #awardList == 0 then return end
	local w = 0
	local panel = obj:egGetWidgetByName(kPanelAward)
	for key,awardinfo in ipairs(awardList) do
		if awardinfo.mType == 1 then
			local cointype = KVariantList.coinType[awardinfo.sType]
			local awarditem = ResAward.new(cointype,Funs.signedNum(awardinfo.val))
			panel:addChild(awarditem:egNode())
			awarditem:egSetPosition(w,0)
			w = w + kCellW + margin2
		elseif awardinfo.mType==2 then
			local awarditem = HeroAward.new(awardinfo.sType,awardinfo.val)
			panel:addChild(awarditem:egNode())
			awarditem:egSetPosition(w,0)
			w = w + kCellW + margin2
		elseif awardinfo.mType == 3 then
			local equipid = equipFuncs.getSubEquipId(awardinfo.sType,awardinfo.lv,awardinfo.qa)
			local awarditem = EquipAward.new(equipid)
			panel:addChild(awarditem:egNode())
			awarditem:egSetPosition(w,0)
			w = w + kCellW + margin2
		end
	end
	if w > 0 then w = w - margin2 end
	local size = panel:getSize()
	panel:setPosition(ccp(panel:getPositionX() + (size.width - w)/2,panel:getPositionY()))
end
VipInfo={}
function VipInfo.new(lv)
	local obj = {}
    CocosWidget.install(obj,JsonList.purchaseVipInfo)
    table_aux.unpackTo(__vipinfo, obj)
    obj:init(lv)
    return obj
end
local kPanelLayer="img_pay_bg"
local kLblVip = "lbl_vip"
local kLblExp = "lbl_vip_exp"
local kBarExp = "bar_exp"
local kLblRecharge = "lbl_recharge"
local kImgJewel = "img_jewel_icon"
local kLblReach = "lbl_reach"
local kBtnClose = "btn_close"
local kBtnShow = "btn_show"
local kItemList = "item_list"
local kInfoList = "info_list"
local kImgLeft = "img_left"
local kImgRight = "img_right"
local kLblShow = "lbl_show"
local kLblShows = "lbl_show_s"

local kCellW = 260
local kMaxNum = 5

local __purchaselayer = {}
function __purchaselayer.init(obj)
	
	obj._lv = account_data.vip or 0
	local needExp = VipLvUp[obj._lv].exp
	local leftExp = account_data.vipExp or needExp
	obj:egSetLabelStr(kLblVip,string.format("VIP %d",obj._lv))
	obj:egSetLabelStr(kLblExp,(needExp - leftExp).."/"..needExp)
	obj:egSetBarPercent(kBarExp,math.min(math.ceil((needExp - leftExp)*100/needExp),100))
	if obj._lv == 0 or leftExp == needExp then 
		obj:egSetLabelStr(kLblRecharge,string.format("%s %d",TxtList.payTxt,leftExp))
	else
		obj:egSetLabelStr(kLblRecharge,string.format("%s %d",TxtList.payMore,leftExp))
	end
	obj:egSetLabelStr(kLblReach,string.format("%s VIP %d",TxtList.canReach,obj._lv+1))
	local lbl1 = obj:egGetWidgetByName(kLblRecharge)
	local img = obj:egGetWidgetByName(kImgJewel)
	local lbl2 = obj:egGetWidgetByName(kLblReach)
	img:setPosition(ccp(lbl1:getPosition() + lbl1:getSize().width + img:getSize().width/2 - 10,img:getPositionY()))
	lbl2:setPosition(ccp(img:getPosition() + img:getSize().width/2 - 10,lbl2:getPositionY()))
	obj:loadItems()
	obj._loadVip = {}
	obj._showLv = nil
	obj._maxLv = obj:getMaxLv()
	obj:showVipDesc(false)
	obj:showWithAction()
end
function __purchaselayer.getMaxLv(obj)
	local maxLv = 0
	for key,val in ipairs(VipLvUp) do
		maxLv = math.max(maxLv,key)
	end
	return maxLv
end
function __purchaselayer.showVipDesc(obj,show)
	obj._shownDesc = show
	
	if show then
		obj:egShowWidget(kInfoList)
		obj:egHideWidget(kItemList)
		obj:egSetLabelStr(kLblShows,TxtList.backToPay)
		obj:egSetLabelStr(kLblShow,TxtList.backToPay)
	else
		obj:egHideWidget(kInfoList)
		obj:egHideWidget(kImgLeft)
		obj:egHideWidget(kImgRight)
		obj:egShowWidget(kItemList)
		obj:egSetLabelStr(kLblShows,TxtList.showVipDesc)
		obj:egSetLabelStr(kLblShow,TxtList.showVipDesc)
	end
end
function __purchaselayer.showTurnFlag(obj,lv)
	if lv > 1 then 
		obj:egShowWidget(kImgLeft) 
	else
		obj:egHideWidget(kImgLeft) 
	end
	if lv < obj._maxLv then 
		obj:egShowWidget(kImgRight) 
	else
		obj:egHideWidget(kImgRight) 
	end 
end
function __purchaselayer.loadVipDesc(obj,lv)
	if lv > obj._maxLv or lv < 1 then return end
	local startIdx = math.max(lv-1,1)
	local endIdx= math.min(lv+1,obj._maxLv)
	local widget = obj:egGetWidgetByName(kInfoList)
	local pageview = tolua.cast(widget,"PageView")
	for idx = startIdx,endIdx do
		local vipinfo = VipInfo.new(idx)
		local layout = tolua.cast(vipinfo:egNode(),"Layout")
		pageview:addPage(layout)
		table.insert(obj._loadVip,idx)
	end
	local function pageViewEvent(sender, eventType)
		local tmp_pageview = tolua.cast(sender, "PageView")
		local idx = tmp_pageview:getCurPageIndex() + 1
		local lv = obj._loadVip[idx] or 0
        if eventType == PAGEVIEW_TOUCHLEFT then
			if obj._showLv < lv then
				obj:loadNextDesc(lv)
			elseif obj._showLv > lv then
				obj:loadPreDesc(lv)
			end
			obj._showLv = lv
			obj:showTurnFlag(lv)
        end 
	end
    pageview:addEventListenerPageView(pageViewEvent)
end
function __purchaselayer.loadPreDesc(obj,lv)
	local preLv = lv-1
	if preLv < 1 then return end
	for key,val in ipairs(obj._loadVip) do
		if val == preLv then return end
	end
	local widget = obj:egGetWidgetByName(kInfoList)
	local pageview = tolua.cast(widget,"PageView")
	local vipinfo = VipInfo.new(preLv)
	local layout = tolua.cast(vipinfo:egNode(),"Layout")
	pageview:insertPage(layout,0)
	table.insert(obj._loadVip,preLv,1)
end
function __purchaselayer.loadNextDesc(obj,lv)
	local nextLv = lv+1
	if nextLv > obj._maxLv then return end
	for key,val in ipairs(obj._loadVip) do
		if val == nextLv then return end
	end
	local widget = obj:egGetWidgetByName(kInfoList)
	local pageview = tolua.cast(widget,"PageView")
	local vipinfo = VipInfo.new(nextLv)
	local layout = tolua.cast(vipinfo:egNode(),"Layout")
	pageview:addPage(layout)
	table.insert(obj._loadVip,nextLv)
end
function __purchaselayer.loadItems(obj)
	obj._itemList={}
	obj._loadCnt = 0
	for key,val in pairs(purchaseCfg) do
		if val.et then
			local left = os.time(val.et) - os.time()
			if left > 0 then
				table.insert(obj._itemList,val)
			end
		elseif val.limitCnt then
			if account_data.purchaseInfo then
				val.usedCnt = account_data.purchaseInfo[key] or 0
			end
			table.insert(obj._itemList,val)
		else
			table.insert(obj._itemList,val)
		end
	end
	local scrollview = obj:egGetScrollView(kItemList)
	local cnt = #obj._itemList
	local neww = kCellW*cnt
	local size = scrollview:getSize()
	if neww > size.width then
		scrollview:setInnerContainerSize(CCSizeMake(neww,size.height))
		scrollview:jumpToTop()
	end
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadCnt >=  #obj._itemList then return end
            local innerContainer = scrollview:getInnerContainer()
            local posX = innerContainer:getPositionX()
            if (obj._loadCnt * kCellW) + posX  < scrollview:getSize().width then
                obj:addItem(scrollview,1)
            end
        end
    end
	obj:addItem(scrollview,kMaxNum)
    scrollview:addEventListenerScrollView(scrollEvent)
end
function __purchaselayer.addItem(obj,scrollview,num)
	if obj._loadCnt >= #obj._itemList then return end
	local startIdx = obj._loadCnt + 1
	local endIdx = math.min(obj._loadCnt + num,#obj._itemList)
	for idx = startIdx,endIdx do
		local item = PurchaseItem.new(obj._itemList[idx])
		scrollview:addChild(item:egNode())
	end
	obj._loadCnt= endIdx
end
function __purchaselayer.hideWithAction(obj)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(640,1080))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __purchaselayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(640,1080))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(640,360))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
--�ر�
function __purchaselayer.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
function __purchaselayer.bindShowListener(obj)
	local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
        if obj._shownDesc then
			obj:showVipDesc(false)
		else
			obj:showVipDesc(true)
			if #obj._loadVip == 0 then
				obj:loadVipDesc(obj._lv + 1)
			end
			for key,val in ipairs(obj._loadVip) do
				obj._showLv = obj._lv + 1
				if val == obj._showLv then
					local widget = obj:egGetWidgetByName(kInfoList)
					local pageview = tolua.cast(widget,"PageView")
					pageview:scrollToPage(key-1)
					obj:showTurnFlag(obj._showLv)
					break
				end
			end
		end
		 sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnShow,nil,nil,touchEnded,touchCanceled)
end
PurchaseLayer={}
function PurchaseLayer.new(onloaded)
   local obj =  TouchWidget.new(JsonList.purchaseLayer)
    table_aux.unpackTo(__purchaselayer, obj)
    obj._onloaded = onloaded
    obj:init()
	obj:bindCloseListener()
	obj:bindShowListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end
function showPurchaseLayer(onloaded)
    local layer = PurchaseLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
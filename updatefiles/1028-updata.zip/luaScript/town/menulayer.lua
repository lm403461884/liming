
local kBtnFar = "btn_far" --Զ��
local kBtnRisk = "btn_risk" --ð��
local kBtnDef = "btn_def" --�����
local kBtnFight = "btn_fight" --�Ӷ�

local kBtnMail = "btn_mail" --����
local kBtnGrow = "btn_grow" --ѵ��
local kBtnRank = "btn_rank" --PVP��λ
local kBtnTask = "btn_task" --����
local kBtnSign = "btn_sign" --ǩ��
local kBtnBar = "btn_bar" --��ļ
local kBtnShop = "btn_shop" --�̳�
local kBtnSet = "btn_set" --����

local kImgSelfInfo = "img_showself" --������Ϣ

local kImgMail = "img_mail"
local kImgBar = "img_bar"
local kImgRank = "img_rank"
local kImgTask = "img_task"
local kImgSign = "img_sign"
local kImgGrow = "img_grow"
local kImgRisk = "img_risk"
local kImgFar = "img_far"
local kImgFight = "img_fight"
local kImgDef = "img_def"
local kImgShop = "img_shop"
local kImgSet = "img_set"

local kNoticeMail = "notice_mail"
local kNoticeBar = "notice_bar"
local kNoticeRisk = "notice_risk"
local kNoticeDef = "notice_def"
local kNoticeTask = "notice_task"
local kNoticeFar = "notice_far"
local kNoticeSign = "notice_sign"

local kLblUserName = "lbl_user_name"
local kLblDigLv = "lbl_diglv"
local kLblVip = "lbl_VIP"
local kBtnExten = "btn_extension" --���밴ť
local kBtnPullDown = "btn_pulldown"
local kNoticeExtend = "notice_extension" --������ʾ
local kPanelMask = "touch_mask"

local kLabelPvp = "lbl_pvp" --PVP��λ
local kLabelStar = "lbl_star" --PVE�Ǽ�

local kLblPvpShellVal = "lbl_protect_val"
local kImgPvpShell = "img_protect"
local kPanelBtns = "panel_btns"

local kScale1 = 0.7
local kScale2 = 0.9
local kScale3 = 1.1
local kInterval1 = 1
local kGrayColor = ccc3(32,32,32)
local kWhiteColor = ccc3(255,255,255)
local __menulayer = {}
function __menulayer.init(obj,d_data)
    obj._d_data = d_data
    obj._noticePost = false
	obj:egHideWidget(kPanelMask)
	obj:egHideWidget(kBtnPullDown)
	obj:egSetLabelStr(kLblUserName,obj._d_data.nickName)
    obj:egSetBMLabelStr(kLblDigLv,obj._d_data.digLv)
    obj:egSetLabelStr(kLblVip,obj._d_data.vip)
	obj:egHideWidget(kPanelBtns)
    local h = obj:egGetWidgetByName(kPanelBtns):getSize().height
	local btnMail = obj:egGetWidgetByName(kBtnMail)
	local btnGrow = obj:egGetWidgetByName(kBtnGrow)
	local btnShop = obj:egGetWidgetByName(kBtnShop)
	local btnSet = obj:egGetWidgetByName(kBtnSet)
	btnMail:setPosition(ccp(btnMail:getPositionX(),btnMail:getPositionY() + h))
	btnGrow:setPosition(ccp(btnGrow:getPositionX(),btnGrow:getPositionY() + h))
	btnShop:setPosition(ccp(btnShop:getPositionX(),btnShop:getPositionY() + h))
	btnSet:setPosition(ccp(btnSet:getPositionX(),btnSet:getPositionY() + h))
    obj:bindLicenceTimer() --ִ��״̬����
    obj:bindMissionTimer()---ð���������
    obj:loadFarMenu()--Զ���������
	obj:loadDefMenu()--�����
    obj:loadPvpMenu()--�Ӷ����
    obj:loadMailTimer()--���䣨¼���ʼ�)���
    obj:loadBarMenu()--��ļ���
    obj:loadGrowMenu()--ѵ�����
    obj:loadSignMenu() --ǩ��
    obj:loadTaskMenuTimer()--�ھ���־�������
    obj:bindExtensionTimer()--��չ��ť���
	obj:loadPvpShellTimer()--pvp����ʱ��
    obj:onClubDataLoaded()
end
function __menulayer.loadSignMenu(obj)
	local imgWidget = obj:egGetWidgetByName(kNoticeSign)
	imgWidget:setVisible(false)
	local signed = false
	local function update()
		local flag = os.time() > account_data.signInExp_d
		if  flag~= signed then 
		     signed = flag
			 imgWidget:setVisible(signed)
			 if signed then
				obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
			 else
				imgWidget:stopAllActions()
			 end
		end
	end
	obj:egBindWidgetUpdate(kNoticeSign,update)
end

--����ִ�ձ仯
function __menulayer.bindLicenceTimer(obj)
    local diglv = 0
	local passed = 0
	local imgLicence = tolua.cast(obj:egGetWidgetByName(kImgSelfInfo),"ImageView")
	local sprite = tolua.cast(imgLicence:getVirtualRenderer(),"CCSprite") 
    local function update(delta)
		passed = passed + delta
		if passed > 3 then
			passed = 0
			local anima = graphicLoader.getAnimation(actList.licenceBlink)
			anima:setRestoreOriginalFrame(true)
			sprite:runAction(CCAnimate:create(anima))
		end
        if diglv ~= obj._d_data.digLv then
            diglv = obj._d_data.digLv
            obj:egSetBMLabelStr(kLblDigLv,diglv)
			obj:updateAreaStar()
			obj:updatePvpMenu()--����PVP��ť״̬
			obj:updateInviteMenu()--����Invite��ť״̬
			obj:updateGrowMenu()--����Grow��ť״̬
			obj:updateDefMenu() --���·�����ھ�״̬
			obj:updateExFightMenu() --����Զ���״̬
        end
    end
    obj:egBindWidgetUpdate(kLblDigLv,update)
end
--�ж��Ƿ���������
function __menulayer.hasNewMission(obj)
	for areaid, pveArea in pairs(account_data.unlockedPVE) do
		local nmData = MissionHelper.getNormalMission(areaid)
		local dmData = MissionHelper.getResMission(areaid)
		for key,stageid in ipairs(nmData) do
			local stageinfo = pveArea[stageid]
			if  stageinfo and stageinfo.stars == 0 then
				return true
			end
		end
		for key,stageid in ipairs(dmData) do
			local stageinfo = pveArea[stageid]
			if stageinfo and stageinfo.stars == 0 then
				return true
			end
		end
	end
	return false
end
--�����Ƿ���û��������
function __menulayer.bindMissionTimer(obj)
    local imgWidget = obj:egGetWidgetByName(kNoticeRisk)
    imgWidget:setVisible(false)
    local hasNew = obj:hasNewMission()
    if hasNew then
        imgWidget:setVisible(hasNew)
		obj:egUnbindWidgetUpdate(kNoticeRisk)
        obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
    end
end
function __menulayer.loadPvpShellTimer(obj)
	obj._hasShell = false
	obj:egHideWidget(kImgPvpShell)
	local function update(delta)
		if obj._hasShell then
			if obj._d_data.shellPvp <= os.time() then
				obj._hasShell = false
				obj:egHideWidget(kImgPvpShell)
			else
				local left = math.max(obj._d_data.shellPvp - os.time(),0)
				if left ~= obj._shellLeft then
					obj._shellLeft = left
					obj:egSetLabelStr(kLblPvpShellVal,Funs.formatTime(obj._shellLeft))
				end
			end
		else
			if obj._d_data.shellPvp > os.time() then
				obj._hasShell = true
				obj:egShowWidget(kImgPvpShell)
				obj._shellLeft = math.max(obj._d_data.shellPvp - os.time(),0)
				obj:egSetLabelStr(kLblPvpShellVal,Funs.formatTime(obj._shellLeft))
			end
		end
    end
    obj:egBindWidgetUpdate(kImgPvpShell,update)
	
end
--��ʾ����������������
function __menulayer.updateAreaStar(obj)
	obj._missionArea = licenceLevelup[obj._d_data.digLv].areaID --ȡ��ǰִ�ն�Ӧ��������Ϊ��������
    obj._curstar = obj._d_data.unlockedPVE[obj._missionArea].areaStars
    obj._totalstar = pveQuery.getStageCnt(obj._missionArea)*3
    obj:egSetLabelStr(kLabelStar,string.format("%d%s%d",obj._curstar,"/",obj._totalstar))
end
function __menulayer.loadFarMenu(obj)
    if obj._d_data.digLv <  unLockMenu[menuDef.expedition] then
        obj:egChangeImg(kImgFar,ImageList.btn_far_d,UI_TEX_TYPE_PLIST)
        obj._exFightUnlocked = false
		obj:egHideWidget(kNoticeFar)
    else
       obj:egChangeImg(kImgFar,ImageList.btn_far_n,UI_TEX_TYPE_PLIST)
       obj._exFightUnlocked = true
	   obj:bindNewFarTimer()
    end
end
--��Զ����ʾ��ʱ��
function __menulayer.bindNewFarTimer(obj)
	local imgWidget = obj:egGetWidgetByName(kNoticeFar)
    imgWidget:setVisible(false)
	if account_data.exMission then
		local function update()
			if os.time() >= account_data.exMission.nextSt then
				obj:egUnbindWidgetUpdate(kNoticeFar)
				imgWidget:setVisible(true)
				obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
			end
		end
		obj:egBindWidgetUpdate(kNoticeFar,update)
	else
		imgWidget:setVisible(true)
		obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
	end
end
--����Զ�̶ӹ��ܰ�ť
function __menulayer.updateExFightMenu(obj)
    if not obj._exFightUnlocked and obj._d_data.digLv>= unLockMenu[menuDef.expedition] then
         obj._exFightUnlocked = true
		 local btn = obj:egGetWidgetByName(kBtnFar)
		 local posx =  btn:getPositionX()
		 local posy= btn:getPositionY() + btn:getSize().height/2
		 showPopTxt(TxtList.unLockMenuInfo[menuDef.expedition],posx,posy,ccp(1,0.5))
         obj:egChangeImg(kImgFar,ImageList.btn_far_n,UI_TEX_TYPE_PLIST)
		 obj:bindNewFarTimer()
   end
end
--����PVP���ܰ�ť
function __menulayer.loadPvpMenu(obj)
    obj:egSetLabelStr(kLabelPvp,obj._d_data.elo)
    
    if obj._d_data.digLv <  unLockMenu[menuDef.pvp] then
        obj:egChangeImg(kImgFight,ImageList.btn_fight_d,UI_TEX_TYPE_PLIST)
        obj._pvpUnlocked = false
    else
       obj:egChangeImg(kImgFight,ImageList.btn_fight_n,UI_TEX_TYPE_PLIST)
       obj._pvpUnlocked = true
    end
end
--����PVP���ܰ�ť
function __menulayer.updatePvpMenu(obj)
    if not obj._pvpUnlocked and obj._d_data.digLv>= unLockMenu[menuDef.pvp] then
        obj._pvpUnlocked = true
		 local btn = obj:egGetWidgetByName(kBtnFight)
		 local posx =  btn:getPositionX()
		 local posy= btn:getPositionY() + btn:getSize().height/2
		 showPopTxt(TxtList.unLockMenuInfo[menuDef.pvp],posx,posy,ccp(1,0.5))
         obj:egChangeImg(kImgFight,ImageList.btn_fight_n,ImageList.btn_pvp_s,"",UI_TEX_TYPE_PLIST)
   end
end
function __menulayer.scaleWidget(obj,widget,from,to,s)
	local scaleto1 = CCScaleTo:create(s,from)
	local scaleto2 = CCScaleTo:create(s,to)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end
--�ж��Ƿ�����¼����ʾ��¼���ʶ
function __menulayer.loadMailTimer(obj)
    local imgWidget = obj:egGetWidgetByName(kNoticeMail)
    if not account_data.rewardMails then account_data.rewardMails={} end
    
    local hasNew = obj:hasUnReadMail() or videomanager.hasNewDefVideo()
    imgWidget:setVisible(hasNew)
    obj._noticePost = hasNew
    obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
end
function __menulayer.hasUnReadMail(obj)
	 for msgid,item in pairs (account_data.msgBoxList) do
		 if item[1] == 0 then return true end
	 end
	 for msgid,item in pairs(account_data.rewardMails) do
	     if msgid and item then return true end
	 end
	 return false
end

--���ؾƹݹ��ܰ�ť
function __menulayer.loadBarMenu(obj)
    obj:egGetWidgetByName(kNoticeBar):setVisible(false)
    if obj._d_data.digLv < unLockMenu[menuDef.invite] then
        obj._inviteUnlocked = false
        obj:egChangeImg(kImgBar,ImageList.btn_bar_d,UI_TEX_TYPE_PLIST)
    else
         obj._inviteUnlocked = true
        obj:egChangeImg(kImgBar,ImageList.btn_bar_n,UI_TEX_TYPE_PLIST)
        obj:bindBarTimer()
    end
end
--������ļ��ť״̬
function __menulayer.updateInviteMenu(obj)
    if not obj._inviteUnlocked and obj._d_data.digLv >= unLockMenu[menuDef.invite] then
        obj._inviteUnlocked = true
		local btn = obj:egGetWidgetByName(kBtnBar)
		local posx =  btn:getPositionX() 
		local posy= btn:getPositionY() +  btn:getSize().height/2
		showPopTxt(TxtList.unLockMenuInfo[menuDef.invite],posx,posy,ccp(1,0.5))
        obj:egChangeImg(kImgBar,ImageList.btn_bar_n,UI_TEX_TYPE_PLIST)
        obj:bindBarTimer()
    end
end
function __menulayer.hasInviteChance(obj)
	if account_data.freeMsgExpire<= os.time() or account_data.freeBoxExpire<= os.time() then return true end --�Ƿ��������Ϣ��̽
	for heroid,msgnum in pairs(account_data.heroInfoList) do
		if account_data.heroList[heroid] then --����ļ�ж��Ƿ���Խ���
			if msgnum >= jewelCalc.getUpGradeMsg(account_data.heroList[heroid].grade or 0) then
				return true
			end
		else --δ��ļ���ж��Ƿ�ﵽ��ļ����
			local s_cfg = hero_data.getConfig(heroid)
			if msgnum >= s_cfg.infoCnt then
				return true
			end
		end
	end
	return false
end
--�ж��Ƿ��п���ļ��Ӣ��,�п���ļӢ��ʱ,��ʾ��ʾ��Ϣ
function __menulayer.bindBarTimer(obj)
    local imgWidget = obj:egGetWidgetByName(kNoticeBar)
	imgWidget:setVisible(false)
	local function update(delta)
		if obj:hasInviteChance() then
			imgWidget:setVisible(true)
			obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
			obj:egUnbindWidgetUpdate(kImgBar)
		end
	end
	obj:egBindWidgetUpdate(kImgBar,update)
end

--����ѵ����ť
function __menulayer.loadGrowMenu(obj)
    if obj._d_data.digLv < unLockMenu[menuDef.training] then
        obj._growUnlocked = false
        obj:egChangeImg(kImgGrow,ImageList.btn_grow_d,UI_TEX_TYPE_PLIST)
		obj:egGetWidgetByName(kImgGrow):setColor(kGrayColor)
    else
        obj._growUnlocked = true
        obj:egGetWidgetByName(kImgGrow):setColor(kWhiteColor)
    end
end
--����ѵ����ť״̬
function __menulayer.updateGrowMenu(obj)
    if not obj._growUnlocked and obj._d_data.digLv >= unLockMenu[menuDef.training] then
        obj._growUnlocked = true
		local panel = obj:egGetWidgetByName(kPanelBtns)
		local btn = obj:egGetWidgetByName(kBtnGrow)
		local posx = panel:getPositionX() + btn:getPositionX() + btn:getSize().width
		local posy= panel:getPositionY() + btn:getPositionY() + btn:getSize().height/2
		showPopTxt(TxtList.unLockMenuInfo[menuDef.training],posx,posy,ccp(0,0.5))
		obj:egGetWidgetByName(kImgGrow):setColor(kWhiteColor)
    end
end
--���ط������ť
function __menulayer.loadDefMenu(obj)
	obj:egHideWidget(kNoticeDef)
    if obj._d_data.digLv < numDef.pveGuardQuestRequiredLevel then
        obj._defUnlocked = false
        obj:egChangeImg(kImgDef,ImageList.btn_def_d,UI_TEX_TYPE_PLIST)
    else
        obj._defUnlocked = true
        obj:egChangeImg(kImgDef,ImageList.btn_def_n,UI_TEX_TYPE_PLIST)
		obj:bindDefTimer()
    end
end
--���·������ť״̬
function __menulayer.updateDefMenu(obj)
    if not obj._defUnlocked  and obj._d_data.digLv >= numDef.pveGuardQuestRequiredLevel then
        obj._defUnlocked = true
		local btn = obj:egGetWidgetByName(kBtnDef)
		local posx = btn:getPositionX()
		local posy= btn:getPositionY() + btn:getSize().height/2
		showPopTxt(TxtList.unLockMenuInfo[menuDef.def],posx,posy,ccp(1,0.5))
        obj:egChangeImg(kImgDef,ImageList.btn_def_n,UI_TEX_TYPE_PLIST)
		obj:bindDefTimer()
    end
end
function __menulayer.hasNewDef(obj)
	if DefTaskHelper.canRefresh() then return true end
	--[[if account_data.pveGuardQuest then
		for key,item in pairs(account_data.pveGuardQuest) do
			if not item then
				return true
			end
		end
	end--]]
	return false
end
--�ж��Ƿ���Ҫ��ʾ����������ʾ
function __menulayer.bindDefTimer(obj)
	if not account_data.pveGuardQuest then return end --��û������������ 
	local hasDefTask = false
	for key,item in pairs(account_data.pveGuardQuest) do
	    if item then hasDefTask = true break end
    end    
    if hasDefTask then
        obj:egShowWidget(kNoticeDef)
		obj:scaleWidget(obj:egGetWidgetByName(kNoticeDef),kScale1,kScale2,kInterval1)
    else
        local showFlag = false
        local imgWidget = obj:egGetWidgetByName(kNoticeDef)
	    local function update()
		     if showFlag ~= obj:hasNewDef() then
		         showFlag = obj:hasNewDef()
		    	 imgWidget:setVisible(showFlag)
		    	if showFlag then
		    	    obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)	
		        else
                    imgWidget:stopAllActions()	
                end    
		    end
	    end
	    obj:egBindWidgetUpdate(kBtnDef,update)
	end        
  
end
--�ж��Ƿ�������ɵ�δ�콱������
function __menulayer.hasFinishedTask(obj)
	if account_data.taskList then
		for tid, taskctx in pairs(account_data.taskList) do 
			if taskctx[2] == 1 then
				return true
			end
		end
	end
	return false
end

--�ھ���־������ʾ
function __menulayer.loadTaskMenuTimer(obj)
	local imgWidget = obj:egGetWidgetByName(kNoticeTask)

	local hasfinished = obj:hasFinishedTask()
	imgWidget:setVisible(hasfinished)
	if hasfinished then
		obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
	else
		imgWidget:stopAllActions()
	end
end

--��չ��ť����
function __menulayer.bindExtensionTimer(obj)
    if obj._noticePost  then
         obj:egShowWidget(kNoticeExtend)
         local imgWidget = obj:egGetWidgetByName(kNoticeExtend)
         obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1) 
     else
         oldstate = false
         obj:egHideWidget(kNoticeExtend)
     end
end

--����
function __menulayer.bindPostListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgMail):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgMail):setScale(1)
        SoundHelper.playEffect(SoundList.clickMenu)
        local imgWidget = obj:egGetWidgetByName(kNoticeMail)
		obj._noticePost = false
        imgWidget:setVisible(false)
        imgWidget:stopAllActions()
		obj:egShowWidget(kPanelMask)
        local function callbackfunc()
			obj:egHideWidget(kPanelMask)
            sender:setTouchEnabled(true)
        end
        if obj._clickingCallback then obj._clickingCallback() end
        AccountHelper:lock(kStatePrompt)
        showPost(callbackfunc)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgMail):setScale(1)
		end
	end
    obj:egBindTouch(kBtnMail,touchBegan,nil,touchEnded,touchCanceled)
end

--��ļ
function __menulayer.bindInviteListener(obj)
    local function touchBegan(sender)
		obj:egGetWidgetByName(kImgBar):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgBar):setScale(1)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        if obj._d_data.digLv < unLockMenu[menuDef.invite] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.invite])
			local btn = obj:egGetWidgetByName(kBtnBar)
			local posx = btn:getPositionX()
			local posy= btn:getPositionY()+btn:getSize().height/2
			showPopTxt(text,posx,posy,ccp(1,0.5))
            sender:setTouchEnabled(true)
        else
            local scene = PubScene.new()
            scene:egReplace()
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgBar):setScale(1)
		end
	end
    obj:egBindTouch(kBtnBar,touchBegan,nil,touchEnded,touchCanceled)
end

--�Ӷ�
function __menulayer.bindFightListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgFight):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgFight):setScale(1)
       SoundHelper.playEffect(SoundList.clickMenu)
       if obj._clickingCallback then obj._clickingCallback() end
       if obj._d_data.digLv < unLockMenu[menuDef.pvp] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.pvp])
			local btn = obj:egGetWidgetByName(kBtnFight)
			local posx = btn:getPositionX()
			local posy= btn:getPositionY() + btn:getSize().height/2
			showPopTxt(text,posx,posy,ccp(1,0.5))
            sender:setTouchEnabled(true)
       else
           if obj._d_data.actPt<numDef.pvpBattleAP then
               local text = string.format("%s %d",TxtList.needActPt,numDef.pvpBattleAP)
				local posx = sender:getPositionX()
				local posy= sender:getPositionY()+ sender:getSize().height/2
				showPopTxt(text,posx,posy,ccp(1,0.5))
               sender:setTouchEnabled(true)
           else
               AccountHelper:lock(kStatePrompt)
			   if account_data.shellPvp > os.time() then
					obj:egShowWidget(kPanelMask)
			       showPvpCDInfo(nil,function() sender:setTouchEnabled(true) obj:egHideWidget(kPanelMask) end)
               elseif account_data.gold < numDef.goldOfSearch then
					local text = string.format("%s %d",TxtList.needgold,numDef.goldOfSearch)
					local posx = sender:getPositionX()
					local posy= sender:getPositionY()+ sender:getSize().height/2
					showPopTxt(text,posx,posy,ccp(1,0.5))
				   sender:setTouchEnabled(true)
			   else
                   SoundHelper.playEffect(SoundList.click_buy_button)
				   obj:egShowWidget(kPanelMask)
			       AccountHelper:lock(kStateSearchPvp)
			       SendMsg[935001]()
			       account_data.gold  =account_data.gold  - numDef.goldOfSearch --�ҿ󶴳ɹ���۷�
			       showPreviewPvp(function() sender:setTouchEnabled(true) obj:egHideWidget(kPanelMask) end)
               end
           end   
       end    
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgFight):setScale(1)
		end
	end
    obj:egBindTouch(kBtnFight,touchBegan,nil,touchEnded,touchCanceled)
end

--��������
function __menulayer.bindCofcListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgRisk):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgRisk):setScale(1)
       SoundHelper.playEffect(SoundList.clickMenu)
	   local scene = worldmapScene.new()
       --if obj._clickingCallback then obj._clickingCallback() end
	   --local scene = MissionScene.new(licenceLevelup[obj._d_data.digLv].areaID)
	   scene:egReplace()
    end

	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgRisk):setScale(1)
		end
	end
    obj:egBindTouch(kBtnRisk,touchBegan,nil,touchEnded,touchCanceled)
end

--ѵ��
function __menulayer.bindGrowListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgGrow):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgGrow):setScale(1)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        if obj._d_data.digLv < unLockMenu[menuDef.training] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.training])
			local panel = obj:egGetWidgetByName(kPanelBtns)
			local btn = obj:egGetWidgetByName(kBtnGrow)
			local posx = panel:getPositionX() + btn:getPositionX() + btn:getSize().width
			local posy= panel:getPositionY() + btn:getPositionY() + btn:getSize().height/2
			showPopTxt(text,posx,posy,ccp(0,0.5))
            sender:setTouchEnabled(true)
       else
            local scene = GrowScene.new()
            scene:egReplace()
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgGrow):setScale(1)
		end
	end
    obj:egBindTouch(kBtnGrow,touchBegan,nil,touchEnded,touchCanceled)	
end
--�����
function __menulayer.bindDefListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgDef):setScale(kScale3)
	end
	 local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgDef):setScale(1)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
			obj:egHideWidget(kPanelMask)
        end
		if obj._d_data.digLv < numDef.pveGuardQuestRequiredLevel then
            local text = string.format("%s LV%d",TxtList.needLicence,numDef.pveGuardQuestRequiredLevel)
			local posx = sender:getPositionX()
			local posy= sender:getPositionY() + sender:getSize().height/2
			showPopTxt(text,posx,posy,ccp(1,0.5))
            sender:setTouchEnabled(true)
		else
			AccountHelper:lock(kStatePrompt)
			obj:egShowWidget(kPanelMask)
			showDef(nil,callbackfunc) --�򿪷������棬���ѽ���������PVE����
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgDef):setScale(1)
		end
	end
    obj:egBindTouch(kBtnDef,touchBegan,nil,touchEnded,touchCanceled)
end
--PVP��λ
function __menulayer.bindRankListener(obj)
    local function touchBegan(sender)
		obj:egGetWidgetByName(kImgRank):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgRank):setScale(1)
        SoundHelper.playEffect(SoundList.clickMenu)
		obj:egShowWidget(kPanelMask)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
			obj:egHideWidget(kPanelMask)
        end
        AccountHelper:lock(kStatePrompt)
        showEloRank(callbackfunc)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgRank):setScale(1)
		end
	end
    obj:egBindTouch(kBtnRank,touchBegan,nil,touchEnded,touchCanceled)
end
--����
function __menulayer.bindTaskListener(obj)
	 local function touchBegan(sender)
		obj:egGetWidgetByName(kImgTask):setScale(kScale3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgTask):setScale(1)
        SoundHelper.playEffect(SoundList.clickMenu)
		obj:egShowWidget(kPanelMask)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
			obj:egHideWidget(kPanelMask)
        end
        showDigJournal(callbackfunc)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgTask):setScale(1)
		end
	end
    obj:egBindTouch(kBtnTask,touchBegan,nil,touchEnded,touchCanceled)
end
function __menulayer.showBtnPanel(obj,show)
	local panel = obj:egGetWidgetByName(kPanelBtns)
	local parent = panel:getParent()
	local h = panel:getSize().height
	local btnMail = obj:egGetWidgetByName(kBtnMail)
	local btnGrow = obj:egGetWidgetByName(kBtnGrow)
	local btnShop = obj:egGetWidgetByName(kBtnShop)
	local btnSet = obj:egGetWidgetByName(kBtnSet)
	if show then
		panel:setVisible(true)
		panel:setEnabled(true)
		parent:reorderChild(panel,0)
		btnGrow:runAction(CCMoveBy:create(0.2,ccp(0,-h)))
		btnShop:runAction(CCMoveBy:create(0.2,ccp(0,-h)))
		btnSet:runAction(CCMoveBy:create(0.2,ccp(0,-h)))
		local function callback()
			obj:egSetWidgetTouchEnabled(kBtnExten,true)
            obj:egHideWidget(kBtnExten)
			obj:egShowWidget(kBtnPullDown)
			parent:reorderChild(panel,2)
        end
		local callfunc = CCCallFunc:create(callback)
		local moveby = CCMoveBy:create(0.2,ccp(0,-h))
		btnMail:runAction(CCSequence:createWithTwoActions(moveby,callfunc))
	else
		parent:reorderChild(panel,0)
		btnGrow:runAction(CCMoveBy:create(0.2,ccp(0,h)))
		btnShop:runAction(CCMoveBy:create(0.2,ccp(0,h)))
		btnSet:runAction(CCMoveBy:create(0.2,ccp(0,h)))
		local function callback()
			if obj._btnExClickingBack then obj._btnExClickingBack(true) end
			obj:egSetWidgetTouchEnabled(kBtnPullDown,true)
            obj:egHideWidget(kBtnPullDown)
            obj:egShowWidget(kBtnExten)
			panel:setVisible(false)
			panel:setEnabled(false)
		end
		local callfunc = CCCallFunc:create(callback)
		local moveby = CCMoveBy:create(0.2,ccp(0,h))
		btnMail:runAction(CCSequence:createWithTwoActions(moveby,callfunc))
	end
end
--��չ��ť
function __menulayer.bindBtnExListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._btnExClickingBack then
            obj._btnExClickingBack(false)
        end
		obj:showBtnPanel(true)
		obj:egUnbindWidgetUpdate(kBtnExten)
		obj:egHideWidget(kNoticeExtend)
    end

	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnExten,nil,nil,touchEnded,touchCanceled)
end
--����ť
function __menulayer.bindBtnPullListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
        obj:bindExtensionTimer()
		obj:showBtnPanel(false)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnPullDown,nil,nil,touchEnded,touchCanceled)
end
--������Ϣ��ʾ��ť����¼�
function __menulayer.bindSelfInfoListener(obj)
	local function touchBegan(sender)
		sender:setScale(1.3)
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setScale(1.25)
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
		obj:egShowWidget(kPanelMask)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
			obj:egHideWidget(kPanelMask)
        end
        showPubUserInfo(account_data.guid,callbackfunc)
		SoundHelper.playEffect(SoundList.clickMenu)
    end
	local function touchCanceled(sender)
		sender:setScale(1.25)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgSelfInfo,touchBegan,nil,touchEnded,touchCanceled)
end

function __menulayer.bindExFightListener(obj)
	 local function touchBegan(sender)
		obj:egGetWidgetByName(kImgFar):setScale(kScale3)
	end
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgFar):setScale(1)
		SoundHelper.playEffect(SoundList.clickMenu)
		local function callback() sender:setTouchEnabled(true) end
		 if obj._d_data.digLv < unLockMenu[menuDef.expedition] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.expedition])
			local posx = sender:getPositionX()
			local posy= sender:getPositionY() + sender:getSize().height/2
			showPopTxt(text,posx,posy,ccp(1,0.5))
            sender:setTouchEnabled(true)
		else
			if account_data.exMission then --�ѿ���Զ��������´�Զ�����������
				local scene =ExMissionScene.new()
				scene:egReplace()
			else --��û�п���Զ��������´�Զ��������ѡ��༭
                showExpeditionSelectMap(callback)
			end
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgFar):setScale(1)
		end
	end
    obj:egBindTouch(kBtnFar,touchBegan,nil,touchEnded,touchCanceled)
end
--ǩ��
function __menulayer.bindSignListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgSign):setScale(kScale3)
	end
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgSign):setScale(1)
		SoundHelper.playEffect(SoundList.clickMenu)
		showSignLayer(function() sender:setTouchEnabled(true) end)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgSign):setScale(1)
		end
	end
    obj:egBindTouch(kBtnSign,touchBegan,nil,touchEnded,touchCanceled)
end
--�̳�
function __menulayer.bindShopListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgShop):setScale(kScale3)
	end
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgShop):setScale(1)
		SoundHelper.playEffect(SoundList.clickMenu)
		showShopLayer(function() sender:setTouchEnabled(true) end)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgShop):setScale(1)
		end
	end
    obj:egBindTouch(kBtnShop,touchBegan,nil,touchEnded,touchCanceled)
end
--����
function __menulayer.bindSetListener(obj)
	local function touchBegan(sender)
		obj:egGetWidgetByName(kImgSet):setScale(kScale3)
	end
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:egGetWidgetByName(kImgSet):setScale(1)
		SoundHelper.playEffect(SoundList.clickMenu)
		showSetLayer(function() sender:setTouchEnabled(true) end)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		else
			obj:egGetWidgetByName(kImgSet):setScale(1)
		end
	end
    obj:egBindTouch(kBtnSet,touchBegan,nil,touchEnded,touchCanceled)
end
function __menulayer.onClubDataLoaded(obj)
    local function callback(eventName)
		--unBindObserver(obj:egNode(),eventName)
        if eventName == kEventNoticeMission then
            obj:bindMissionTimer()
        elseif eventName == kEventNoticeMail then
            obj:loadMailTimer()
            obj:bindExtensionTimer()
        elseif eventName == kEventNoticeTask then
            obj:loadTaskMenuTimer()
		end
	end
    bindObserver(obj:egNode(),callback,kEventNoticeMission)
    bindObserver(obj:egNode(),callback,kEventNoticeMail)
    bindObserver(obj:egNode(),callback,kEventNoticeTask)
end
function __menulayer.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
function __menulayer.onClicking(obj,callback)
    obj._clickingCallback = callback
end
function __menulayer.btnExOnClicking(obj,callback)
    obj._btnExClickingBack = callback
end
MenuLayer={}
function MenuLayer.new(d_data)
    local obj= TouchWidget.new(JsonList.menuLayer)
   --local obj ={}
   -- CocosWidget.install(obj,JsonList.menuLayer)
    table_aux.unpackTo(__menulayer, obj)
    obj:init(d_data)
    obj:bindPostListener()
    obj:bindInviteListener()
    obj:bindFightListener()
    obj:bindCofcListener()
    obj:bindGrowListener()
	obj:bindDefListener()
    obj:bindRankListener()
    obj:bindBtnExListener()
    obj:bindBtnPullListener()
    obj:bindTaskListener()
	obj:bindExFightListener()
	obj:bindSelfInfoListener()
	obj:bindSignListener()
	obj:bindShopListener()
	obj:bindSetListener()
	obj:autoUnbindObserver()
    return obj
end
local kTeamBp = 1
local kPvpElo = 2
local kPveAchieve = 3
local kClubElo = 4

local __rankhelper = {}
--��ʼ��������Ϣ������
function __rankhelper.initData(obj,rankType,sMsgType,uniqueKey,sortKey)
	obj._rankData={}
	obj._isDownLoading = nil
	obj._isSucceed = nil
	obj._curPageIdx = -1
	obj._totalPageCnt  = 0
	obj._rankType = rankType
	obj._sMsgType = sMsgType
	obj._uniqueKey = uniqueKey
	obj._sortKey = sortKey
	obj._ownIdx = nil
	obj._ownRankData = nil
end
--�ӷ�������ȡ����Ϣ
function __rankhelper.downLoadRankData(obj)
	obj._isDownLoading = true
	obj._isSucceed = nil
	if obj._curPageIdx < obj._totalPageCnt then
		SendMsg[obj._sMsgType](obj._curPageIdx+1)
	else
		obj._isDownLoading = nil
	end
end
--��ǻ�ȡ����Ϣ���״̬
function __rankhelper.finishDownLoad(obj,isSucced)
	obj._isSucceed = isSucced
	if obj._isSucceed then
		table.sort(obj._rankData,function(a,b) return (a[obj._sortKey] > b[obj._sortKey]) or (a[obj._sortKey] == b[obj._sortKey] and a[obj._uniqueKey] > b[obj._uniqueKey]) end)
	end
	obj._isDownLoading = nil
end
--�Ƿ��ѻ�ȡ������������Ϣ
function __rankhelper.isAllDownLoaded(obj)
	return obj._curPageIdx >= obj._totalPageCnt-1
end
--�Ƿ����ڻ�ȡ��������
function __rankhelper.isDownLoading(obj)
	return obj._isDownLoading
end
--�Ƿ����سɹ�
function __rankhelper.isSucceed(obj)
	return obj._isSucceed 
end
--����������Ϣ��¼
function __rankhelper.addRankData(obj,totalPage,curPage,rankInfo)
	obj._totalPageCnt  = totalPage
	obj._curPageIdx = curPage
	for key,rankItem in ipairs(obj._rankData) do
		if rankItem[obj._uniqueKey ] == rankInfo[obj._uniqueKey ] then
			obj._rankData[key] = rankInfo
			if rankInfo[obj._uniqueKey ]==account_data[obj._uniqueKey] then
				obj._ownIdx = key
			end
			return
		end
	end
	table.insert(obj._rankData,rankInfo)
	if rankInfo[obj._uniqueKey ]==account_data[obj._uniqueKey] then
		obj._ownIdx = #obj._rankData
	end
end
--��ȡ�������м�¼
function __rankhelper.getRankList(obj)
	return obj._rankData
end
--��ȡ��������λ��
function __rankhelper.getOwnRankIdx(obj)
	return obj._ownIdx
end
--���¸�������λ��
function __rankhelper.setOwnRankIdx(obj,idx)
	obj._ownIdx = idx
end
--���ø�����������
function __rankhelper.setOwnRankData(obj,tb)
	obj._ownRankData = tb
end
--��ȡ������������
function __rankhelper.getOwnRankData(obj)
	return obj._ownRankData
end
ELORankHelper={}
ClubRankHelper={}
TeamBpRankHelper={}
PveRankHelper={}
setmetatable(ELORankHelper, {__index = __rankhelper})
setmetatable(ClubRankHelper, {__index = __rankhelper})
setmetatable(TeamBpRankHelper, {__index = __rankhelper})
setmetatable(PveRankHelper, {__index = __rankhelper})
RankHelper={}
function RankHelper.init()
	TeamBpRankHelper:initData(kTeamBp,931015,"guid","teamBp")
	ELORankHelper:initData(kPvpElo,931006,"guid","elo")
	PveRankHelper:initData(kPveAchieve,931017,"guid","stars")
	ClubRankHelper:initData(kClubElo,938012,"cid","elo")
end
--��ȡ�������м�¼
function RankHelper.getRankList(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:getRankList() end
	if rankType == kPvpElo then return ELORankHelper:getRankList() end
	if rankType == kPveAchieve then return PveRankHelper:getRankList() end
	if rankType == kClubElo then return ClubRankHelper:getRankList() end
end
--�ӷ�������ȡ����Ϣ
function RankHelper.downLoadRankData(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:downLoadRankData() end
	if rankType == kPvpElo then return ELORankHelper:downLoadRankData() end
	if rankType == kPveAchieve then return PveRankHelper:downLoadRankData() end
	if rankType == kClubElo then return ClubRankHelper:downLoadRankData() end
end
--�Ƿ��ѻ�ȡ������������Ϣ
function RankHelper.isAllDownLoaded(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:isAllDownLoaded() end
	if rankType == kPvpElo then return ELORankHelper:isAllDownLoaded() end
	if rankType == kPveAchieve then return PveRankHelper:isAllDownLoaded() end
	if rankType == kClubElo then return ClubRankHelper:isAllDownLoaded() end
end
--�Ƿ����ڻ�ȡ��������
function RankHelper.isDownLoading(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:isDownLoading() end
	if rankType == kPvpElo then return ELORankHelper:isDownLoading() end
	if rankType == kPveAchieve then return PveRankHelper:isDownLoading() end
	if rankType == kClubElo then return ClubRankHelper:isDownLoading() end
end
--�Ƿ����سɹ�
function RankHelper.isSucceed(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:isSucceed() end
	if rankType == kPvpElo then return ELORankHelper:isSucceed() end
	if rankType == kPveAchieve then return PveRankHelper:isSucceed() end
	if rankType == kClubElo then return ClubRankHelper:isSucceed() end
end
--��ȡ��������λ��
function RankHelper.getOwnRankIdx(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:getOwnRankIdx() end
	if rankType == kPvpElo then return ELORankHelper:getOwnRankIdx() end
	if rankType == kPveAchieve then return PveRankHelper:getOwnRankIdx() end
	if rankType == kClubElo then return ClubRankHelper:getOwnRankIdx() end
end
--���ø�������λ��
function RankHelper.setOwnRankIdx(rankType,idx)
	if rankType == kTeamBp then return TeamBpRankHelper:setOwnRankIdx(idx) end
	if rankType == kPvpElo then return ELORankHelper:setOwnRankIdx(idx) end
	if rankType == kPveAchieve then return PveRankHelper:setOwnRankIdx(idx) end
	if rankType == kClubElo then return ClubRankHelper:setOwnRankIdx(idx) end
end
function RankHelper.getOwnRankData(rankType)
	if rankType == kTeamBp then return TeamBpRankHelper:getOwnRankData(idx) end
	if rankType == kPvpElo then return ELORankHelper:getOwnRankData(idx) end
	if rankType == kPveAchieve then return PveRankHelper:getOwnRankData(idx) end
	if rankType == kClubElo then return ClubRankHelper:getOwnRankData(idx) end
end
--�ӷ�������ȡ��������λ����Ϣ
function RankHelper.downLoadRankIdx(rankType)
	if rankType == kTeamBp then 
		TeamBpRankHelper:setOwnRankData({guid=account_data.guid,digLv = account_data.digLv,teamBp = account_data.teamBp,name = account_data.nickName})
		--SendMsg[931016](rankType)
	elseif rankType == kPvpElo then 
		ELORankHelper:setOwnRankData({guid=account_data.guid,digLv = account_data.digLv,elo = account_data.elo,jewel = 0,name = account_data.nickName})
		--SendMsg[931016](rankType)
	elseif rankType == kPveAchieve then 
		PveRankHelper:setOwnRankData({guid=account_data.guid,digLv = account_data.digLv,stars = account_data.stars or 0,name = account_data.nickName})
		--SendMsg[931016](rankType)
	elseif rankType == kClubElo then
		if account_data.cid > 0 then
			ClubRankHelper:setOwnRankData({cid=account_data.cid,elo = club_data.elo,jewel = club_data.membersCount * 20 + club_data.elo,name = account_data.cbName})
			--SendMsg[931016](rankType,club_data.elo)
		else
			ClubRankHelper:setOwnRankData(nil)
			ClubRankHelper:setOwnRankIdx(0)
		end
	end
end

local kPanelBtn = "btn_panel"
local kPanelLayer = "pop_panel"
local kImgBtn = "img_btn_bg"
local __rankpopmenu = {}
function __rankpopmenu.init(obj,d_data,pos)
	obj._d_data = d_data
	obj._h = 0
	obj._cellh = 60
	local panelbtn = obj:egGetWidgetByName(kPanelBtn)
	local panellayer = obj:egGetWidgetByName(kPanelLayer)
	local imgbtn = obj:egGetWidgetByName(kImgBtn)
	imgbtn:ignoreContentAdaptWithSize(false)
	if obj._d_data.guid then
		obj:addBtnInfo()
		obj:addBtnChat()
	end
	if obj._d_data.cid  and obj._d_data.cid > 0 then --�������������
		obj:addBtnClub()
		--��ǰ��½���û���빫�ᣬ���й��ᳵ��
		if not club_data and account_data.train[train.def.guild] then
			obj:addBtnJoin()
		end
	end
	panelbtn:setSize(CCSizeMake(panelbtn:getSize().width,obj._h))
	local imgh = obj._h + 40
	imgbtn:setSize(CCSizeMake(imgbtn:getSize().width,imgh))
	if pos.y >= imgh then
		imgbtn:setPosition(ccp(pos.x,pos.y  - imgh))
	else
		obj:egSetImgFlipY(kImgBtn,true)
		imgbtn:setPosition(ccp(pos.x,pos.y))
	end
	if obj._onshown then obj._onshown() end
end
--�����Ϣ��ť
function __rankpopmenu.addBtnInfo(obj)
	local panelbtn = obj:egGetWidgetByName(kPanelBtn)
	local menuItem = RankPopMenuItem.new(TxtList.btnTxt[3]) --�����Ϣ
	local function clickCallback()
		obj:egHideWidget(kImgBtn)
		showPubUserInfo(obj._d_data.guid)
		obj:egRemoveSelf()
    end
    menuItem:onClicked(clickCallback)
	panelbtn:addChild(menuItem:egNode())
	obj._h = obj._h + obj._cellh
end
--˽�İ�ť
function __rankpopmenu.addBtnChat(obj)
	local panelbtn = obj:egGetWidgetByName(kPanelBtn)
	local menuItem = RankPopMenuItem.new(TxtList.btnTxt[4]) --˽��
	local function clickCallback()
		obj:egHideWidget(kImgBtn)
		local chatlayer = AccountHelper:get(kChatLayer)
        chatlayer:showChatPanel()
		chatlayer:showPrivatePart(obj._d_data) --������棬�л���˽��
		obj:egRemoveSelf()
    end
    menuItem:onClicked(clickCallback)
	panelbtn:addChild(menuItem:egNode())
	obj._h = obj._h + obj._cellh
end
--������Ϣ��ť
function __rankpopmenu.addBtnClub(obj)
	local panelbtn = obj:egGetWidgetByName(kPanelBtn)
	local menuItem = RankPopMenuItem.new(TxtList.btnTxt[2]) --������Ϣ
	local function clickCallback()
		obj:egHideWidget(kImgBtn)
        ShowGuildView(2,obj._d_data,function() obj:egRemoveSelf() end)		
    end
    menuItem:onClicked(clickCallback)
	panelbtn:addChild(menuItem:egNode())
	obj._h = obj._h + obj._cellh
end
--���빫�ᰴť
function __rankpopmenu.addBtnJoin(obj)
	local panelbtn = obj:egGetWidgetByName(kPanelBtn)
	local menuItem = RankPopMenuItem.new(TxtList.btnTxt[1]) --���빫��
	local function clickCallback()
		obj:egHideWidget(kImgBtn)
		SendMsg[938004](obj._d_data.cid) --������빫��
		ChatHelper.addPubMsg(0,0,TxtList.systemCH..TxtList.msg,0,"",string.format(TxtList.guildMsg[9],obj._d_data.name))
		obj:egRemoveSelf()
    end
    menuItem:onClicked(clickCallback)
	panelbtn:addChild(menuItem:egNode())
	obj._h = obj._h + obj._cellh
end
function __rankpopmenu.bindPanelListener(obj)
	local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_back_button)
		obj:egRemoveSelf()
    end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchEnded)
end
function __rankpopmenu.bindImageListener(obj)
	local img = tolua.cast(obj:egGetWidgetByName(kImgBtn),"ImageView")
	local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
	
    local function touchEnded(sender)
		local pos =sender:getTouchEndPos()
		local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
		if isalpha then
			SoundHelper.playEffect(SoundList.click_back_button)
			obj:egRemoveSelf()
		end
    end
    local function touchCanceled(sender)
		touchEnded(sender)
    end
    obj:egBindTouch(kImgBtn,nil,nil,touchEnded,touchCanceled)
end
RankPopMenu = {}
function RankPopMenu.new(d_data,pos,onshown)
   local obj =TouchWidget.new(JsonList.rankPopMenu)
   table_aux.unpackTo(__rankpopmenu,obj)
   obj._onshown = onshown
   obj:init(d_data,pos)
   obj:bindPanelListener()
   --obj:bindImageListener()
   return obj
end
function showRankPopMenu(d_data,pos,onshown)
	local layer = RankPopMenu.new(d_data,pos,onshown)
	local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
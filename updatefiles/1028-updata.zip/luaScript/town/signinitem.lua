local kPanelItem = "panel_sign_item"
local kBtnItem = "btn_sign"
local kImgVipTool = "img_vip_tool"
local kLblVip = "lbl_vip_sale"
local kImgAward = "img_award"
local kLblAwardVal = "lbl_award_val"
local kImgYes = "img_yes"
local kPanelBlack = "panel_black"
--װ����ʾ
local kImgColorBg = "img_color_bg"
local kImgLvBg = "img_lv_bg"
local kLblLv = "lbl_lv"

local __signinitem = {}
function __signinitem.init(obj,idx)
    obj._data = registration.data[idx]
    obj._btnWidget=tolua.cast(obj:egGetWidgetByName(kBtnItem),"Button")
    if idx<=account_data.signInCnt then
        obj:egShowWidget(kImgYes)
        obj:egShowWidget(kPanelBlack)
    else
        obj:egHideWidget(kImgYes)  
        obj:egHideWidget(kPanelBlack)  
    end
    obj:addprop("idx",idx)
    obj:addprop("data",obj._data)
    obj:egHideWidget(kImgColorBg)
    obj:egHideWidget(kImgLvBg)
    local imgWidget = obj:egGetWidgetByName(kImgAward)
    if obj._data.type then
        local name = KVariantList.coinType[obj._data.type]
        local imgsrc = ImageList[string.format("comm_%s",name)]
        obj:egChangeImg(kImgAward,imgsrc,UI_TEX_TYPE_PLIST)
        if name == "gold" or name == "jewel" then
            imgWidget:setScale(0.8)
        else
            imgWidget:setScale(1.5)
        end    
    elseif obj._data.heroid then
        local s_cfg =  hero_data.getConfig(obj._data.heroid)
        obj:egChangeImg(kImgAward,s_cfg.headPic,UI_TEX_TYPE_PLIST)
        imgWidget:setScale(1.1)
        imgWidget:setPosition(ccp(0,15))
    elseif obj._data.eid_s then
        local s_cfg = equipFuncs.getSubEquipCfg(obj._data.eid_s)
        obj:egChangeImg(kImgAward,s_cfg.icon,UI_TEX_TYPE_PLIST)
        imgWidget:setScale(0.8)
        imgWidget:setPosition(ccp(0,0))
        if obj._data.val<=1 then obj:egHideWidget(kLblAwardVal) end
        obj:egShowWidget(kImgLvBg)
        obj:egShowWidget(kImgColorBg)
        obj:egSetBMLabelStr(kLblLv,obj._data.lv)
        obj:egSetWidgetColor(kImgColorBg,KVariantList.equipColor[obj._data.qal])
    end
    obj:egSetBMLabelStr(kLblAwardVal,string.format("+%d",obj._data.val))
    if obj._data.vip>0 then
        obj:egShowWidget(kImgVipTool)
        obj:egSetLabelStr(kLblVip,string.format("VIP%d%s",obj._data.vip,TxtList.double))
    else
        obj:egHideWidget(kImgVipTool)
    end
end

function __signinitem.setBeGot(obj)
    obj:egShowWidget(kImgYes)
    obj:egShowWidget(kPanelBlack)
end

function __signinitem.setTouchEnabled(obj,enable)
    local btnitem = obj:egGetWidgetByName(kBtnItem)
    btnitem:setTouchEnabled(enable)
end
function __signinitem.setWidgetTouchEnabled(obj,enabled)
    obj:egSetWidgetEnabled(kBtnItem,enabled)
    obj:selectedAction(not enabled)
end
function __signinitem.onItemClicked(obj,onclicked)
    obj._itemCallback = onclicked
end
function __signinitem.selectedAction(obj,show)
    if not obj._selected then
        local btnSign = obj:egGetWidgetByName(kBtnItem)
        local btnSize = btnSign:getSize()
        local img = ImageView:create()
        img:loadTexture(ImageList.comm_blank,UI_TEX_TYPE_PLIST)
        img:setPosition(ccp(0,0))
        btnSign:addChild(img,3,3)
        obj._sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite") 
        obj._selected = true
    end    
	if show then
		local anima = graphicLoader.getAnimation("selected_state_act")
		anima:setRestoreOriginalFrame(true)
		local animate = CCAnimate:create(anima)
		local action = CCRepeat:create(animate,1000000)
		obj._sprite:setVisible(true)
		obj._sprite:runAction(action) 
	else
		obj._sprite:stopAllActions()
		obj._sprite:setVisible(false)
	end
end
function __signinitem.bindItemListener(obj)
    local function touchEnded(sender)
		obj:egSetWidgetEnabled(kBtnItem,false)
		 obj:selectedAction(not false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		if obj._itemCallback then obj._itemCallback() end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
    end
	
    obj:egBindTouch(kBtnItem,nil,nil,touchEnded,touchCanceled)
end
SignInItem = {}
function SignInItem.new(idx)
    local obj = {}
    CocosWidget.install(obj,JsonList.signInItem)
    table_aux.unpackTo(__signinitem, obj)
    BaseProp.install(obj)
	InnerProp.install(obj)
    obj:init(idx)
    obj:bindItemListener()
    return obj
end

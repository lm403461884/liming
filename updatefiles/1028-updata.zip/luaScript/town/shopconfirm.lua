--������Ϣ���
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kPanelTxt = "txt_panel"
local kLblCoinRes = "lbl_coin_res"
local kImgNoteCoin = "img_note_coin"
local kLblNoteTxt = "lbl_note_txt2"
local kImgGray = "img_gray"
local kPanelLayer = "img_note_bg"

local kOffsetY = -40
local __shopconfirm={}
function __shopconfirm.init(obj,itemdata)
	obj._itemdata = itemdata
	obj:egSetWidgetTouchEnabled(kBtnYes,false)
	obj:egSetWidgetTouchEnabled(kBtnNo,false)
	obj:egSetLabelStr(kLblCoinRes,obj._itemdata.payVal)
	obj._payCoinName = KVariantList.coinType[obj._itemdata.payCoin]
	obj:egChangeImg(kImgNoteCoin,ImageList[string.format("comm_%s",obj._payCoinName)],UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblNoteTxt,string.format("%s %s%s",TxtList.buy,obj._itemdata.desc,"?"))
	
	local lbl1 = obj:egGetWidgetByName(kLblCoinRes)
	local img1 = obj:egGetWidgetByName(kImgNoteCoin)
	local lbl2 = obj:egGetWidgetByName(kLblNoteTxt)
	local posImg = lbl1:getPositionX() + lbl1:getSize().width + 10
	img1:setPosition(ccp(posImg,img1:getPositionY()))
	local poslbl = posImg + img1:getSize().width + 10
	lbl2:setPosition(ccp(poslbl,lbl2:getPositionY()))
	local w = poslbl + lbl2:getSize().width
    local panel = obj:egGetWidgetByName(kPanelTxt)
	local oldw = panel:getSize().width
    panel:setSize(CCSizeMake(w,panel:getSize().height))
	panel:setPosition(ccp(panel:getPositionX() + (oldw-w)/2,panel:getPositionY()))
	obj:showWithAction()
end
function __shopconfirm.showWithAction(obj)
	local bg = obj:egGetWidgetByName(kPanelLayer)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	local scaleto = CCScaleTo:create(0.3,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		obj:egSetWidgetTouchEnabled(kBtnYes,true)
		obj:egSetWidgetTouchEnabled(kBtnNo,true)
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	bg:setScale(0)
	bg:runAction(sequence)
	graylayer:setOpacity(0)
	graylayer:runAction(CCFadeTo:create(0.3,128))
end
function __shopconfirm.hideWithAction(obj,onclosed)
	local bg = obj:egGetWidgetByName(kPanelLayer)
	local graylayer = obj:egGetWidgetByName(kImgGray)
	local scaleto = CCScaleTo:create(0.1,0)
	local function callback()
		if onclosed then onclosed() end
		 obj:egRemoveSelf()
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(scaleto,callfunc)
	bg:runAction(sequence)
	graylayer:runAction(CCFadeTo:create(0.1,0))
end
--ȷ�ϰ�ť
function __shopconfirm.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_buy_button)
        obj:hideWithAction(obj._payCallback)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __shopconfirm.bindNoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end
function __shopconfirm.onPayClicked(obj,callback)
	obj._payCallback = callback
end
ShopConfirm={}
function ShopConfirm.new(itemdata,onloaded)
    local obj =  TouchWidget.new(JsonList.shopConfirm)
    table_aux.unpackTo(__shopconfirm, obj)
    obj._onloaded = onloaded
    obj:init(itemdata)
    obj:bindYesListener()
    obj:bindNoListener()
    return obj
end
function showShopConfirm(itemdata,onloaded)
    local layer = ShopConfirm.new(itemdata,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

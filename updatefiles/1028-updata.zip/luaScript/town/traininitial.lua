local kBtnFight = "btn_fight"
local kBtnGold = "btn_gold"
local kBtnDig = "btn_dig"
local kImgNoteFunc = "img_note_func"
local kImgNote = "img_note"
local kPanelDig = "dig_panel"
local kPanelFight = "fight_panel"
local kPanelGold = "gold_panel"

local kImgTrain = "img_train"
local kBarLeft = "bar_left"

local kLblLeft = "lbl_left"
local kGoldZorder = 2
local kFightZorder = 3
local kPromptZorder = 4
local kMoveDistance = 100
local kRedColor = ccc3(245,100,100)
local kWhiteColor = ccc3(255,255,255)
local kScale1 = 1.3
local kScale2 = 1.5
local kInterval1 = 1
local __traininitial={}
-----------------------------------------------------
--��ͷ
----------------------------------------------------
local trainid = 0
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	local trainlv = account_data.digLv 
	local train_cfg = train.config[trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())
end
--��ͷ��ʼ�����ص�����
__traininitial[trainid].onLicenceUpStaring=function(obj,eventName)
	if eventName then unBindObserver(obj:egNode(),eventName) end
	bindObserver(obj:egNode(),function(eName) obj:onLicenceUpFinished(eName) end,kEventLicenceUpEnd)
	obj:egShowWidget(kBarLeft)
	obj:hideAnimate()
	obj:showHeadUpdateAnima(true) --������������
	obj:bindLicenceUpCounter()
	obj:showHeadLvUpFlag() --��ʾ������������ʶ
end

--��ͷ���������ص�����
__traininitial[trainid].onLicenceUpFinished=function(obj,eventName)
	if eventName then unBindObserver(obj:egNode(),eventName) end
	bindObserver(obj:egNode(),function(eName) obj:onLicenceUpStaring(eName) end,kEventLicenceUpStart)
	local train_data = train.config[obj._trainid].research[account_data.digLv]
	obj:egChangeImg(kImgTrain,train_data.bodyImage[1])
	obj:showHeadLvUpFlag()--��ʾ������������ʶ
	obj:egHideWidget(kBarLeft)
	obj:egUnbindWidgetUpdate(kLblLeft)
	obj:showHeadUpdateAnima(false) --�ر���������
	obj:showAnimate()
end
------------------------------------------------------------------
--��β
----------------------------------------------------
local trainid = 99
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())
end

--��ʾ���������³�����ʾ��ʶ
__traininitial[trainid].showFuncFlag=function(obj)
	local funcImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	if obj:hasNewTrain() then
		funcImg:setVisible(true)
		obj:scaleWidget(funcImg,kScale1,kScale2,kInterval1)
		bindObserver(obj:egNode(),function() obj:showFuncFlag() end,kEventBuyNewTrain)
	else
		funcImg:setVisible(false)
		funcImg:stopAllActions()
		unBindObserver(obj:egNode(),kEventBuyNewTrain)
	end
end
--�ж��Ƿ��п��Թ���ĳ���
__traininitial[trainid].hasNewTrain=function(obj)
	for key,val in pairs(train.def ) do
        if not account_data.train[val] then
            local traindata = train.config[val]
			local s_cfg = traindata.research[1]
			local licence = s_cfg.licence or 1
			if licence <= account_data.digLv then return true end
        end
    end
	return false
end
-------------------------------------------------------------
--���ﳵ��
----------------------------------------------------
local trainid = 6
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())
end
--�ж��Ƿ��п��Թ���Ĺ���
__traininitial[trainid].hasNewMonster=function(obj)
	local trainlv =  account_data.train[obj._trainid].lv
    for monsterid,item in pairs(MonsterTrain) do
		local maxNum = item[trainlv] or 0
		local ownNum = 0
		local ownData = account_data.monsterPool[monsterid]
		if ownData then ownNum = ownData.N end
		if ownNum < maxNum then return true end
    end
    return false
end
__traininitial[trainid].showFuncFlag = function(obj)
	local funcImg = obj:egGetWidgetByName(kImgNoteFunc)
	if obj:hasNewMonster() then
		funcImg:setVisible(true)
		obj:scaleWidget(funcImg,kScale1,kScale2,kInterval1)
	else
		funcImg:setVisible(false)
		funcImg:stopAllActions()
	end
end
------------------------------------------------------------------
--�ھ���
----------------------------------------------------
local trainid = 2
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())

	obj._goldPanel = obj:egGetWidgetByName(kPanelGold)
	obj._digPanel = obj:egGetWidgetByName(kPanelDig)
	obj._goldPanel:setPosition(ccp(obj._digPanel:getPositionX(),obj._digPanel:getPositionY()))
	obj:bindGoldBtnListener()--Click Event
	obj:bindDigBtnListener()--Click Event
    if obj:getDigState() then
        obj._digPanel:setVisible(true)
		obj._goldPanel:setVisible(false)
		obj:egHideWidget(kBtnGold)
        obj:egShowWidget(kBtnDig)
		obj:scaleWidget(obj._digPanel,0.9,1,kInterval1)
    else
        obj._digPanel:setVisible(false)
        obj:egHideWidget(kBtnDig)
        obj:bindGoldListener() --timer
    end
end
__traininitial[trainid].showFuncFlag = function(obj) end

__traininitial[trainid].bindGoldBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = DigScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnGold,nil,nil,touchEnded,nil)
end
__traininitial[trainid].bindDigBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = DigScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnDig,nil,nil,touchEnded,nil)
end

--���ռ���Դ��ʾ
__traininitial[trainid].bindGoldListener=function(obj)
    obj._goldPanel:setVisible(false)
    obj:egHideWidget(kBtnGold)
	local function update()
	    local hasCollRes = obj:hasCollRes()
	    if hasCollRes then
	        obj:egUnbindWidgetUpdate(kBtnGold)
	        obj._goldPanel:setVisible(true)
	        obj:scaleWidget(obj._goldPanel,0.9,1,kInterval1)
	        obj:egShowWidget(kBtnGold)
	        obj:egShowWidget(kPanelGold)
	    end
	end
	obj:egBindWidgetUpdate(kBtnGold,update)
end
__traininitial[trainid].hasCollRes = function(obj)
    for key,resCar in ipairs(account_data.collectorList) do
		local targetMine = account_data.mileSpread[resCar.pos]
		if targetMine then
			if not targetMine.dt or targetMine.dt <= 0 then return true end
		end
    end
    return false
end
__traininitial[trainid].isMineRemovable = function(obj,idx,digTrace,w,h)
    if idx > 0 and digTrace[idx] then return false end
    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  digTrace[idx_l] then  return true end--����������ھ�
    return false
end
--�ھ���ʾ
__traininitial[trainid].getDigState=function(obj)
    if account_data.digPt ==account_data.masDigPt  then return true end
    local w,h = scene_data.getWH(account_data.sceneID, account_data.sceneLv)
    for key,val in pairs(account_data.mileSpread) do
        if obj:isMineRemovable(key,account_data.digTrace,w,h) then 
            return false
        end
    end
    return true
end
------------------------------------------------------------------
--���߳���
----------------------------------------------------
local trainid = 3
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())

end
__traininitial[trainid].showFuncFlag = function(obj) end
--------------------------------------------------------------------
--װ������
---------------------------------------------------------------------
local trainid = 8 
__traininitial[trainid] = {}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())
end

--�ж��Ƿ��п�������װ��
__traininitial[trainid].hasEquipLvUp = function (obj)
	local trainlv = account_data.train[train.def.equip].lv
    for eid,item in pairs (account_data.equipments) do
        local curlv,curqa = equipFuncs.getEquipQL(eid, account_data)
		local maxlv = trainlv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
		if (curlv <maxlv and equipFuncs.getData(eid,curlv+1))  or math.floor(curlv* numDef.weaponQaFactor) > curqa then --������������׿ռ�
            return true
        end
    end
    return false
end
__traininitial[trainid].showFuncFlag = function(obj)
    local funcImg = obj:egGetWidgetByName(kImgNoteFunc)
    if  obj:hasEquipLvUp() then
		funcImg:setVisible(true)
		 obj:scaleWidget(funcImg,kScale1,kScale2,kInterval1)
	else
		funcImg:setVisible(false)
		funcImg:stopAllActions()
	end
end
----------------------------------------------------------------------
--��Ϣ��
----------------------------------------------------
local trainid = 4
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())
end
__traininitial[trainid].showFuncFlag = function(obj) end
----------------------------------------------------
------------------------------------------------------------------
--���ᳵ��
----------------------------------------------------
local trainid = 7
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj,trainid)
	obj._trainid = trainid
	local trainlv = account_data.train[obj._trainid].lv 
	local train_cfg = train.config[obj._trainid]
	local s_data = train_cfg.research[trainlv]
	obj:egChangeImg(kImgTrain,s_data.bodyImage[1])
	local img = obj:egGetWidgetByName(kImgTrain)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egNode():setSize(img:getSize())

	if club_data and club_data.warData then
		obj:egShowWidget(kPanelFight)
		obj:egShowWidget(kBtnFight)
		obj:scaleWidget(obj:egGetWidgetByName(kPanelFight),0.9,1,kInterval1)
		obj:bindFightTimer1()
	else
		obj:bindFightTimer2()
	end
	obj:bindFightBtnListener()
end

__traininitial[trainid].bindFightTimer1=function(obj)
	local function update()
	    if not club_data or not club_data.warData then
	   --if  club_data and club_data.warData then
			obj:egUnbindWidgetUpdate(kBtnFight)
	        obj:egHideWidget(kPanelFight)
			obj:egHideWidget(kBtnFight)
			obj:egGetWidgetByName(kPanelFight):stopAllActions()
			obj:bindFightTimer2()
	    end
	end
	obj:egBindWidgetUpdate(kBtnFight,update)
end
__traininitial[trainid].bindFightTimer2=function(obj)
	local function update()
	    if  club_data and club_data.warData then
			obj:egUnbindWidgetUpdate(kBtnFight)
	        obj:egShowWidget(kPanelFight)
			obj:egShowWidget(kBtnFight)
			obj:scaleWidget(obj:egGetWidgetByName(kPanelFight),0.9,1,kInterval1)
			obj:bindFightTimer1()
	    end
	end
	obj:egBindWidgetUpdate(kBtnFight,update)
end
__traininitial[trainid].bindFightBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = GvgMissionScene.new()
		scene:egReplace()
    end
    obj:egBindTouch(kBtnFight,nil,nil,touchEnded,nil)
end
--�ж��Ƿ����Լ���̽�ն�
__traininitial[trainid].hasCbTeam = function(obj)
    for heroid,item in pairs(account_data.cbTeam) do
        if item.tid == account_data.guid then return false end
    end
    return true
end
__traininitial[trainid].showFuncFlag = function(obj)
    local funcImg = obj:egGetWidgetByName(kImgNoteFunc)
    if  obj:hasCbTeam() then
		funcImg:setVisible(true)
		 obj:scaleWidget(funcImg,kScale1,kScale2,kInterval1)
	else
		funcImg:setVisible(false)
		funcImg:stopAllActions()
	end
end

TrainInitial={}
function TrainInitial.install(obj,trainid)
	if __traininitial[trainid] then
		table_aux.unpackTo(__traininitial[trainid], obj)
	end
end
------------------------------------------------------------
local kBtnBasic = "btn_basic"
local kBtnOther = "btn_other"
local kBtnEffect = "btn_effect"
local kImgEffect = "img_select_effect"
local kBtnMusic = "btn_music"
local kImgMusic = "img_select_music"
local kBtnAct = "btn_act"
local kImgAct = "img_select_act"
local kBtnAtk = "btn_atk"
local kImgAtk = "img_select_atk"
local kBtnExplore = "btn_explore"
local kImgExplore = "img_select_explore"
local kBtnClubwar = "btn_clubwar"
local kImgClubwar = "img_select_clubwar"
local kPanelBasic = "panel_basic"
local kPanelOther = "panel_other"
local kPanelLayer = "panel_set"
local kImgBasic = "img_b"
local kImgOther = "img_o"
local kBtnBack = "btn_back"

local kZorderShow = 2
local kZorderHide = 0
local kColorGray = ccc3(128,128,128)
local kColorWhite = ccc3(255,255,255)
local __setmenulayer={}
function __setmenulayer.init(obj)
    obj._effect =  SoundHelper.isEffectOn()
    obj._music =  SoundHelper.isBGMOn()
    obj._act = NotifyHelper.isTurnOn(NotifyCode.actPtFull)
    obj._atk = true
    obj._explore = NotifyHelper.isTurnOn(NotifyCode.teamReturn)
    obj._clubwar = true
    obj:setBtnFocused(true)
    obj:loadBasicSet()
    obj:showWithAction()
end

function __setmenulayer.loadBasicSet(obj)
    obj:egHideWidget(kPanelOther)
    obj:egShowWidget(kPanelBasic)
    local imgTabel = {kImgEffect,kImgMusic,kImgAct,kImgAtk,kImgExplore,kImgClubwar}
    local btnTabel = {kBtnEffect,kBtnMusic,kBtnAct,kBtnAtk,kBtnExplore,kBtnClubwar}
    local stateTabel ={obj._effect,obj._music,obj._act,obj._atk,obj._explore,obj._clubwar,}
    for idx,state in ipairs(stateTabel) do
        if state then 
            obj:egShowWidget(imgTabel[idx])
        else
            obj:egHideWidget(imgTabel[idx]) 
        end
        --obj:bindSelectListener(btnTabel[idx],imgTabel[idx],state)
    end
end
function __setmenulayer.loadOthersSet(obj)
    obj:egHideWidget(kPanelBasic)
    obj:egShowWidget(kPanelOther)
end

function __setmenulayer.setBtnFocused(obj,focuse)
    local btnBasic = tolua.cast(obj:egGetWidgetByName(kBtnBasic),"Button")
    local btnOther = tolua.cast(obj:egGetWidgetByName(kBtnOther),"Button")
    local parentNode = btnBasic:getParent()
    if focuse then
        btnBasic:setFocused(true)
        btnBasic:setTouchEnabled(false)
        obj:egSetWidgetColor(kImgBasic,kColorWhite)
        parentNode:reorderChild(btnBasic,kZorderShow)
        
        btnOther:setFocused(false)
        btnOther:setTouchEnabled(true)
        obj:egSetWidgetColor(kImgOther,kColorGray)
        parentNode:reorderChild(btnOther,kZorderHide)
        obj:egShowWidget(kPanelBasic)
        obj:egHideWidget(kPanelOther)
    else
        btnBasic:setFocused(false)
        btnBasic:setTouchEnabled(true)
        obj:egSetWidgetColor(kImgBasic,kColorGray)
        parentNode:reorderChild(btnBasic,kZorderHide)
        btnOther:setFocused(true)
        btnOther:setTouchEnabled(false)
        obj:egSetWidgetColor(kImgOther,kColorWhite)
        parentNode:reorderChild(btnOther,kZorderShow)
    end
end
--��������
function __setmenulayer.bindBasicListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBasic,1.1)
    end
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj:egSetWidgetScale(kImgBasic,1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:setBtnFocused(true)
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBasic,1)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBasic,touchBegan,nil,touchEnded,touchCanceled)
end
--��������
function __setmenulayer.bindOtherListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgOther,1.1)
    end
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj:egSetWidgetScale(kImgOther,1)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:setBtnFocused(false)
		obj:loadOthersSet()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgOther,1)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnOther,touchBegan,nil,touchEnded,touchCanceled)
end

--[[function __setmenulayer.bindSelectListener(obj,btnName,imgName,select)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        if select then
            select = false
            obj:egHideWidget(imgName)
        else
            select = true
            obj:egShowWidget(imgName)
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(btnName,nil,nil,touchEnded,touchCanceled)
end--]]
--��Ч����
function __setmenulayer.bindEffectListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.turnOffEffect(obj._effect)
		if obj._effect then
		    obj._effect = false
		    obj:egHideWidget(kImgEffect)
		else
		    obj._effect = true
		    obj:egShowWidget(kImgEffect)
		end
		
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnEffect,nil,nil,touchEnded,touchCanceled)
end
--��������
function __setmenulayer.bindMusicListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._music then
		    obj._music = false
		    obj:egHideWidget(kImgMusic)
		    SoundHelper.turnOffBGM()
		else
		    obj._music = true
		    obj:egShowWidget(kImgMusic)
		    SoundHelper.turnOnBGM(SoundList.getTownBGM(account_data))
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnMusic,nil,nil,touchEnded,touchCanceled)
end
--�����ָ�����
function __setmenulayer.bindActListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._act then
		    obj._act = false
		    obj:egHideWidget(kImgAct)
			NotifyHelper.turnOff(NotifyCode.actPtFull)
		else
		    obj._act = true
		    obj:egShowWidget(kImgAct)
			NotifyHelper.turnOn(NotifyCode.actPtFull)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAct,nil,nil,touchEnded,touchCanceled)
end
--����������
function __setmenulayer.bindAtkListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._atk then
		    obj._atk = false
		    obj:egHideWidget(kImgAtk)
		else
		    obj._atk = true
		    obj:egShowWidget(kImgAtk)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAtk,nil,nil,touchEnded,touchCanceled)
end
--̽�նӻع�����
function __setmenulayer.bindExoloreListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._explore then
		    obj._explore = false
		    obj:egHideWidget(kImgExplore)
			NotifyHelper.turnOff(NotifyCode.teamReturn)
		else
		    obj._explore = true
		    obj:egShowWidget(kImgExplore)
			NotifyHelper.turnOn(NotifyCode.teamReturn)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnExplore,nil,nil,touchEnded,touchCanceled)
end
--����ս����
function __setmenulayer.bindClubwarListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._clubwar then
		    obj._clubwar = false
		    obj:egHideWidget(kImgClubwar)
		else
		    obj._clubwar = true
		    obj:egShowWidget(kImgClubwar)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClubwar,nil,nil,touchEnded,touchCanceled)
end
--�رհ���
function __setmenulayer.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __setmenulayer.hideWithAction(obj,callbackfunc)
    local function callback()
			AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __setmenulayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
		baseWidget:runAction(sequece)
	else
		baseWidget:runAction(spawn)
	end
end
SetMenuLayer={}
function SetMenuLayer.new(onloaded)
    local obj =  TouchWidget.new(JsonList.setMenuLayer)
    table_aux.unpackTo(__setmenulayer, obj)
	obj._onloaded = onloaded
    obj:init(d_data)
    obj:bindBackListener()
    obj:bindBasicListener()
    obj:bindOtherListener()
    
    obj:bindEffectListener()
    obj:bindMusicListener()
    obj:bindActListener()
    obj:bindAtkListener()
    obj:bindExoloreListener()
    obj:bindClubwarListener()
    return obj
end
function showSetLayer(onloaded)
    local layer = SetMenuLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

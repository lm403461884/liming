local kLblClick = "lbl_click"
local kBtnClick = "btn_click"
local __rankpopmenuitem = {}
function __rankpopmenuitem.onClicked(obj,callback)
	obj._clickCallback  = callback
end
function __rankpopmenuitem.bindClickListener(obj)
	local function touchEnded(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		if obj._clickCallback then obj._clickCallback() end
    end
    obj:egBindTouch(kBtnClick,nil,nil,touchEnded,touchEnded)
end
RankPopMenuItem = {}
function RankPopMenuItem.new(txt)
   local obj = {}
   CocosWidget.install(obj,JsonList.rankPopMenuItem)
   table_aux.unpackTo(__rankpopmenuitem,obj)
   obj:egSetLabelStr(kLblClick,txt)
   obj:bindClickListener()
   return obj
end

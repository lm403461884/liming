local kImgTrain = "train_img" --����ͼ��
local kLabelTrainName = "lbl_train_name"
local kLabelTrainLv = "lbl_train_lv"
local kPanelTrainProp = "prop_layer"
local kLabelTrainInfo = "lbl_content"
local kLblBtnIn = "lbl_btnin"
local kLblSpeedVal = "lbl_icon_val"
local kBtnUp = "Button_up"
local kBtnIn = "Button_in"
local kBtnSpeedUp = "Button_speed_up"
local kBtnClose = "btn_close"
local kImgIn = "img_btnin" --����ͼ��
local kImgBg = "func_bg"

local kBtnExplore = "Button_explore"--����̽��
local kLblExplore = "lbl_btnexplore"
local kImgTimeBg = "img_time_bg"
local kExploreTime = "lbl_explore_time"
local kImgNewPrompt = "img_new_prompt"

local kImgBtnUp = "img_btnup"
local kImgIcon = "img_icon"
local kImgBtnExplore = "img_btnexplore"

local kRed = ccc3(255,0,0)
local kWhite = ccc3(255,255,255)
local kBrown = ccc3(83,49,22)
local kPosRight = ccp(204,-208)
local kPosMid = ccp(0,-208)
local kPosLeft = ccp(-206,-208)
local __trainfunclayer = {}
function __trainfunclayer.init(obj,trainid,d_data)
    obj._trainid = trainid
	obj:loadSpecTrainProp()
    obj._d_data = d_data
    obj._curProp = {}
    local traindata = obj._d_data.train[obj._trainid]
    local s_cfg = train.config[trainid]
    obj:egChangeImg(kImgTrain,s_cfg.ui.btn_enter_image[1],UI_TEX_TYPE_PLIST)
	obj:egChangeImg(kImgIn,s_cfg.ui.btn_enter_image[1],UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLabelTrainName,s_cfg.name)
    if trainid == train.def.head then
        obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",account_data.digLv))
        obj._curLv = account_data.digLv
    else
        obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",traindata.lv))
        obj._curLv = traindata.lv
    end
	obj:egSetLabelStr(kLblBtnIn,s_cfg.ui.btn_enter_text)
    obj:egSetLabelStr(kLabelTrainInfo,s_cfg.info)

    local propanel =  obj:egGetWidgetByName(kPanelTrainProp)
    obj._oldpropX =propanel:getPositionX()
    obj._oldpropW = propanel:getSize().width
    obj:showSpeedUp(false)
    obj:loadTrainProp()
    obj:loadFuncBtn()
	obj:showWithAction()
end
function __trainfunclayer.loadSpecTrainProp(obj)
	if obj._trainid == train.def.anteroom  then
		account_data.teamAtkCap = obj:getTeamAtkCap()
	end
end
--С��ս�����ܺ�
function __trainfunclayer.getTeamAtkCap(obj)
    local tb = {}
	local teamAtk = 0
    for key,heroprop in pairs(account_data.heroList) do
        tb[heroprop.type] = RiskHelper.getHeroBp( heroprop,account_data)
    end
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk + tb[heroid]
    end
	tb = nil
    return teamAtk
end
function __trainfunclayer.loadTrainProp(obj)
    local propPanel = obj:egGetWidgetByName(kPanelTrainProp)
    for i = 1,propPanel:getChildrenCount() do
        propPanel:removeChildByTag(i,true)
    end
	local fontName = FNList.STHUPO
    local fontSize = 32
    local x =0
    local y = 0
    local margin = 20
    for idx,propKey in ipairs(train.props[obj._trainid] or {} ) do
        local propName,propVal = train.getPropFunc[propKey](account_data)
		obj._curProp[propKey] = propVal
        local txt = string.format("%s%s%s",propName,":",propVal)
        local ttf = Label:create()
        ttf:setText(txt)
        ttf:setFontName(fontName)
        ttf:setFontSize(fontSize)
        ttf:setAnchorPoint(ccp(0,0))
        ttf:setPosition(ccp(x,y))
        ttf:setColor(ccc3(83,49,22))
        obj:bindTtfUpdate(ttf,propKey)
        propPanel:addChild(ttf,idx,idx)
        x = x + ttf:getSize().width + margin
    end
    local newW = x - margin
    local newX = obj._oldpropX + (obj._oldpropW - newW)/2
    propPanel:setSize(CCSizeMake(newW,propPanel:getSize().height))
    propPanel:setPosition(ccp(newX,propPanel:getPositionY()))
end
function __trainfunclayer.bindTtfUpdate(obj,ttf,propKey)
     local function update(delta)
		local propName,propVal = train.getPropFunc[propKey](account_data)
        if obj._curProp[propKey] ~= propVal then
			obj._curProp[propKey] = propVal
            local subVal = propVal - obj._curProp[propKey]
			if subVal > 0 then
				obj._curProp[propKey] = obj._curProp[propKey] +math.ceil(subVal/10)
			else
				obj._curProp[propKey] = obj._curProp[propKey] +math.floor(subVal/10)
			end
            ttf:setText(string.format("%s%s%s",propName,":",propVal))
        end
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  ttf:unscheduleUpdate() end
    end
    ttf:scheduleUpdateWithPriorityLua(update, 0)
    ttf:registerScriptHandler(exitFuns)
end
function __trainfunclayer.loadFuncBtn(obj)
    local traindata = obj._d_data.train[obj._trainid]
    local s_cfg = train.config[obj._trainid]
    local lv = traindata.lv
    local s_data = s_cfg.research[lv + 1]

    local btnEnter = obj:egGetWidgetByName(kBtnIn)
    btnEnter:setPosition(kPosRight)
     
    if obj._trainid ==0 then --��ͷ����
		obj:egHideWidget(kBtnExplore)
        lv = account_data.digLv
        local btnUp = obj:egGetWidgetByName(kBtnUp)
        if  obj._d_data.diggingLvContext>os.time() or ( not licenceLevelup[lv+1])  then
            obj:egHideWidget(kBtnUp)
            obj:egHideWidget(kBtnIn)
            if not licenceLevelup[lv+1] then
                obj:showSpeedUp(false)
            else
                obj:showSpeedUp(true,kPosMid)
		    end
        else
            obj:egShowWidget(kBtnUp)
            obj:showSpeedUp(false)
            obj:egHideWidget(kBtnIn)
            btnUp:setPosition(kPosMid)
            --btnEnter:setPosition(kPosRight)
        end
	else
		if traindata.exp > os.time() then --������
			obj:egHideWidget(kBtnUp)
			obj:showSpeedUp(true)
			if obj._trainid ==train.def.guild and club_data then
				obj:showGuildFuncBtn(kPosRight)
				btnEnter:setPosition(kPosMid)
			else
				obj:egHideWidget(kBtnExplore)
				btnEnter:setPosition(kPosRight)
			end
		elseif (not s_data) then --û�п�������
			obj:egHideWidget(kBtnUp)
			if obj._trainid ==train.def.guild and club_data then
				obj:showGuildFuncBtn(kPosRight)
				btnEnter:setPosition(kPosLeft)
			else
				obj:egHideWidget(kBtnExplore)
				btnEnter:setPosition(kPosMid)
			end
		else --���������û����������
			obj:egShowWidget(kBtnUp)
			obj:showSpeedUp(false)
			if obj._trainid ==train.def.guild and club_data then
				obj:showGuildFuncBtn(kPosRight)
				btnEnter:setPosition(kPosMid)
			else
				obj:egHideWidget(kBtnExplore)
				btnEnter:setPosition(kPosRight)
			end
		end
		
    end
	--���ӵ��������Ч
	--if obj._trainid == 8 then
		--SoundHelper.playEffect(SoundList.fire_burn)
	--end
	
end

function __trainfunclayer.timeUpdate(obj,item)
    local function callback()
        local leftTime = item.ed - os.time()
        if leftTime > 0 then
            obj:egSetLabelStr(kExploreTime,Funs.formatTime(leftTime))
        else
            obj:egHideWidget(kImgTimeBg)
            obj:egSetLabelStr(kLblExplore,TxtList.jointExploration)
            obj:egUnbindWidgetUpdate(kExploreTime)
        end
    end
    obj:egBindWidgetUpdate(kExploreTime,callback)
end
function __trainfunclayer.showGuildFuncBtn(obj,pos)
    local btnEnter = obj:egGetWidgetByName(kBtnIn)
    for heroid,item in pairs(account_data.cbTeam) do
        if item.tid == account_data.guid then
            obj:egShowWidget(kBtnExplore)
            obj:egShowWidget(kImgTimeBg)
            obj:scaleWidget(false)
            obj:egSetLabelStr(kLblExplore,TxtList.adventure)
            obj:timeUpdate(item)
            return
        end
    end
    obj:egShowWidget(kBtnExplore)
    obj:scaleWidget(true)
    obj:egHideWidget(kImgTimeBg)
    btnEnter:setPosition(pos)
end
function __trainfunclayer.scaleWidget(obj,show)
    local widget = obj:egGetWidgetByName(kImgNewPrompt)
    if show then
        obj:egShowWidget(kImgNewPrompt)
	    local scaleto1 = CCScaleTo:create(1,0.9)
	    local scaleto2 = CCScaleTo:create(1,1)
	    local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	    local repeatever = CCRepeatForever:create(sequence)
	    widget:runAction(repeatever)
	else
        widget:stopAllActions()
        obj:egHideWidget(kImgNewPrompt)
    end    
end
--����
function __trainfunclayer.bindUpListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBtnUp,1)
    end
    local function touchEnded(sender)
        obj:egSetWidgetScale(kImgBtnUp,0.9)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:clickLvUp()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBtnUp,0.9)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnUp,touchBegan,nil,touchEnded,touchCanceled)
end
--��������
function __trainfunclayer.bindSpeedListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgIcon,0.65)
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetScale(kImgIcon,0.55)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:clickSpeedUp()
    end
    local function touchCanceled(sender)
        obj:egSetWidgetScale(kImgIcon,0.55)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
	obj:egBindTouch(kBtnSpeedUp,touchBegan,nil,touchEnded,touchCanceled)
end
--���书�ܰ���
function __trainfunclayer.bindInListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgIn,1)
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetScale(kImgIn,0.9)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:clickEnter()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgIn,0.9)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnIn,touchBegan,nil,touchEnded,touchCanceled)
end
--�رհ���
function __trainfunclayer.bindCloseListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideWithAction()
	end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
--����̽��
function __trainfunclayer.bindExploreListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBtnExplore,1)
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetScale(kImgBtnExplore,0.9)
        SoundHelper.playEffect(SoundList.clickMenu)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		local kind = 1
		for heroid,item in pairs(account_data.cbTeam) do
		    if item.tid == account_data.guid then kind=3 end
        end
		 obj:hideWithAction()
        showExploreTeam(nil,kind)
	end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBtnExplore,0.9)
		if AccountHelper:isLocked(kStateGuide) then --����״̬

			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnExplore,touchBegan,nil,touchEnded,touchCanceled)
end
--������복�书��
function __trainfunclayer.clickEnter(obj)
    SoundHelper.playEffect(SoundList.clickMenu)
    obj:hideWithAction()
    --local function callback()
    --end
    local func = train.config[obj._trainid].entra
    if func then func(callback) end
end
--�������������
function __trainfunclayer.clickLvUp(obj)
    SoundHelper.playEffect(SoundList.clickMenu)
    obj:hideWithAction()
    showLvUp(obj._trainid)
end

local function countTrainProps(trainid)
    if not train.props[trainid] then return {} end
    local tb = {}
    for key,_ in pairs(train.props[trainid]) do
        tb[key] = account_data[key]
    end
    return tb
end
local function countTrainPropChanges(oldtb,newtb)
    local tb = {}
    for key,val in pairs(oldtb) do
        tb[key] = {val,newtb[key]}
    end
    return tb
end
--�����������
function __trainfunclayer.clickSpeedUp(obj)
    SoundHelper.playEffect(SoundList.clickMenu)
    obj:hideWithAction()
    if obj._trainid == 0 then
        local icon = jewelCalc.speedupLicence(account_data.diggingLvContext-os.time())
        local lv = account_data.digLv
        local tlv = lv + 1
        SendMsg[932010](lv,tlv,icon)
        account_data.jewel = account_data.jewel - icon
		account_data.digLv = tlv
		account_data.diggingLvContext = -1
		postEventSignal(kEventLicenceUpEnd)
		postEventSignal(kEventNoticeMission)
			--�ھ���־������̸���,���ִ������
		task.updateTaskStatus(account_data,task.client_event_id.diglv_update,{tlv})
			----------------------------------------------------------
        licenceLevelup.onLvUp(account_data)
            --��Ϣ��ʾ--------ִ������---------------
        AccountHelper:addNewPrompt({type=3,data={from = lv,to = tlv}})
            --------------------------
    else
        local lv = account_data.train[obj._trainid].lv
		local tlv = lv + 1
		local oldtb = countTrainProps(obj._trainid) --��ȡ����ǰ����
        local icon = jewelCalc.speedupTrain(account_data.train[obj._trainid].exp -os.time())
        SendMsg[937005](obj._trainid,tlv,icon)
        account_data.jewel = account_data.jewel - icon
		account_data.train[obj._trainid].lv = tlv
		--�ھ���־������̸���,������
		task.updateTaskStatus(account_data,task.client_event_id.update_train,{obj._trainid,tlv})
		----------------------------------------------------------
        train.levelup(account_data,obj._trainid, tlv)
        account_data.train[obj._trainid].exp = -1
        postEventSignal(kEventTrainUpEnd..obj._trainid)
		local newtb = countTrainProps(obj._trainid) --��ȡ����������
        --��Ϣ��ʾ---------------
        local tb = {}
        tb.type = 2 --kTrainPrompt=2
        tb.data={}
        tb.data.trainid = obj._trainid
        tb.data.from = lv
        tb.data.to = tlv
        tb.data.changes = countTrainPropChanges(oldtb,newtb)
        AccountHelper:addNewPrompt(tb)
    end
end
--�Ƿ���ʾ���ٰ�ť
function __trainfunclayer.showSpeedUp(obj,isShow,kPosMid)
    local function updateJewel ()
        local jewel = 0
		local left = 0
        if obj._trainid == 0 then
			left = math.max(account_data.diggingLvContext - os.time(),0)
            jewel = jewelCalc.speedupLicence(left)
        else
			left = math.max(account_data.train[obj._trainid].exp - os.time(),0)
            jewel = jewelCalc.speedupTrain(left)
        end
        if left > 0 then
            obj:egSetLabelStr(kLblSpeedVal,jewel)
            if jewel > account_data.jewel then
                obj:egSetWidgetTouchEnabled(kBtnSpeedUp,false)
                obj:egSetWidgetColor(kLblSpeedVal,kRed)
            else
                 obj:egSetWidgetTouchEnabled(kBtnSpeedUp,true)
                obj:egSetWidgetColor(kLblSpeedVal,kBrown)
            end
        else
            obj:egUnbindWidgetUpdate(kLblSpeedVal)
        end
    end
    if isShow then
        obj:egShowWidget(kBtnSpeedUp)
        obj:egBindWidgetUpdate(kLblSpeedVal,updateJewel)
        obj:bindSpeedListener()
        local btnSpeedUp = obj:egGetWidgetByName(kBtnSpeedUp)
        if kPosMid then btnSpeedUp:setPosition(kPosMid)end
    else
        obj:egHideWidget(kBtnSpeedUp)
    end
end

function __trainfunclayer.hideWithAction(obj)
    AccountHelper:unlock(kStatePrompt)
    local trainlayer = AccountHelper:get(kTrainLayer)
    trainlayer:clearSelectedTrain()
     obj:egRemoveSelf()
end
function __trainfunclayer.showWithAction(obj)
     obj._egObj:setPosition(ccp(0,360))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        obj._egObj:runAction(sequece)
    else
        obj._egObj:runAction(spawn)
    end

end
function __trainfunclayer.activeUpdate(obj)
    local function callback()
        if obj._curLv~=obj._d_data.train[obj._trainid].lv and obj._trainid ~= train.def.head then
            obj._curLv = obj._d_data.train[obj._trainid].lv
            obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",obj._curLv))
            obj:loadFuncBtn()
        end
        if obj._trainid == train.def.head and obj._curLv ~= account_data.digLv then
            obj._curLv = account_data.digLv
            obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",obj._curLv))
            obj:loadFuncBtn()
        end
    end
    obj:egBindWidgetUpdate(kImgBg,callback)
end
TrainFuncLayer = {}
function TrainFuncLayer.new(trainid,d_data,onloaded)
	local obj = TouchWidget.new(JsonList.trainFuncLayer)
   -- local obj = {}
   -- CocosWidget.install(obj,JsonList.trainFuncLayer)
    table_aux.unpackTo(__trainfunclayer, obj)
	obj._onloaded = onloaded
    obj:init(trainid,d_data)
    obj:bindUpListener()
    obj:bindInListener()
    obj:bindCloseListener()
    obj:bindExploreListener()
    obj:activeUpdate()
    return obj
end
function showTrainFunc(trainid,d_data,onloaded)
	local layer = TrainFuncLayer.new(trainid,d_data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

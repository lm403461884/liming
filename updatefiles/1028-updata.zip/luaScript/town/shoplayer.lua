local kPanelLayer="img_pay_bg"
local kBtnClose = "btn_close"
local kItemList = "item_list"
local kCellW = 212
local kCellH = 305
local kMaxRow = 2
local kMaxCol = 5

local __shoplayer = {}
function __shoplayer.init(obj)
	obj._lv = account_data.vip or 0
	obj._itemList = obj:getItemList()
	obj._loadCnt = 0
	obj._colCnt = math.ceil(#obj._itemList/kMaxRow)
	local neww = obj._colCnt*kCellW
	local scrollview = obj:egGetScrollView(kItemList)
	if neww > scrollview:getSize().width then
		scrollview:setInnerContainerSize(CCSizeMake(neww,scrollview:getSize().height))
	end
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then
            if obj._loadCnt >= obj._colCnt then return end
            local innerContainer = scrollview:getInnerContainer()
            local posX = innerContainer:getPositionX()
            if (obj._loadCnt * kCellW) + posX  < scrollview:getSize().width then
                obj:addItem(scrollview,1)
            end
        end
    end
	obj:addItem(scrollview,kMaxCol)
    scrollview:addEventListenerScrollView(scrollEvent)
	obj:showWithAction()
end
function __shoplayer.getItemList(obj)
	local tb ={}
	for key,item in pairs(shopItemCfg) do
		if obj._lv >= item.needVip or account_data.digLv >= item.needLv then
			item.itemid = key
			table.insert(tb,item)
		end
	end
	return tb
end

function __shoplayer.addItem(obj,scrollview,col)
	if obj._loadCnt >= obj._colCnt then return end
	local startIdx = obj._loadCnt * 2 + 1
	local endIdx = math.min(obj._loadCnt*2 + col*2,#obj._itemList)
	for idx = startIdx,endIdx do
		local item = ShopItem.new(obj._itemList[idx])
		item:egSetPosition((math.ceil(idx/kMaxRow)-1)*kCellW,(idx%kMaxRow)*kCellH)
		scrollview:addChild(item:egNode())
	end
	obj._loadCnt= math.min(obj._loadCnt + col,obj._colCnt)
end
function __shoplayer.hideWithAction(obj)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(640,1080))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __shoplayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(640,1080))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(640,360))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	local function callback()
		if obj._onloaded then obj._onloaded() end
	end
    local callfunc = CCCallFunc:create(callback)
    local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
    baseWidget:runAction(sequece)
end
--�ر�
function __shoplayer.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
ShopLayer={}
function ShopLayer.new(onloaded)
   local obj =  TouchWidget.new(JsonList.shopLayer)
    table_aux.unpackTo(__shoplayer, obj)
    obj._onloaded = onloaded
    obj:init()
	obj:bindCloseListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end
function showShopLayer(onloaded)
    local layer = ShopLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
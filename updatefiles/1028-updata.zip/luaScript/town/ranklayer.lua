local kPanelLayer = "rank_panel"
local kBtnBack = "btn_close"
local kLblRank = "lbl_rank_txt" --����
local kLblUser = "lbl_name_txt" --�ǳ�
local kLblDigLv = "lbl_diglv_txt" --ִ�յȼ�
local kLblElo = "lbl_elo_txt" --����
local kBtnAtkcap = "btn_atkcap"
local kBtnElo = "btn_elo"
local kBtnAchieve = "btn_achieve"
local kBtnClub = "btn_club"
local kImgBg = "img_bg"

local kPanelItems = "rank_list_"
local kPanelMySelf = "panel_myself"
local kCornor = {"cornor1","cornor2","cornor3","cornor4",}

local kMaxNum = 10
local kCellH = 57
local kUserAtk = 1 --��ս��������
local kUserElo = 2 --����pvp����
local kUserPve = 3 --PVE
local kClubElo = 4 --����pvp����
local __ranklayer={}
function __ranklayer.init(obj)
   obj._rankInfo = {{},{},{},{}}
   obj._rankInfo[1].uniqueKey = "guid"
   obj._rankInfo[2].uniqueKey = "guid"
   obj._rankInfo[3].uniqueKey = "guid"
   obj._rankInfo[4].uniqueKey = "cid"
   RankHelper.init() --��ʼ�������������ݣ������һ�β�ѯ����������
   obj:focusBtn(kUserElo)
   obj:showWithAction()
end
--�л���ȡ����İ�ť
function __ranklayer.focusBtn(obj,btnType)
	if obj._kind then
		if obj._rankInfo[obj._kind].ownItem then
			obj._rankInfo[obj._kind].ownItem:egNode():setVisible(false)
		end
	end
	obj._kind = btnType
	if obj._rankInfo[obj._kind].ownItem then
		obj._rankInfo[obj._kind].ownItem:egNode():setVisible(true)
	end
	obj:egSetWidgetEnabled(kBtnElo,obj._kind ~= kUserElo)
	obj:egSetWidgetEnabled(kBtnClub,obj._kind ~= kClubElo)
	obj:egSetWidgetEnabled(kBtnAtkcap,obj._kind ~= kUserAtk)
	obj:egSetWidgetEnabled(kBtnAchieve,obj._kind ~= kUserPve)
    --������ʾ�޸�
    obj:egSetLabelStr(kLblRank,TxtList.rankingList[obj._kind][1])
    obj:egSetLabelStr(kLblUser,TxtList.rankingList[obj._kind][2])
    obj:egSetLabelStr(kLblDigLv,TxtList.rankingList[obj._kind][3])
    obj:egSetLabelStr(kLblElo,TxtList.rankingList[obj._kind][4])
	local parentNode = obj:egGetWidgetByName(kImgBg)
	for idx =1,4 do 
		local widget = obj:egGetWidgetByName(string.format("%s%d",kPanelItems,idx))
		if obj._kind == idx then
			widget:setVisible(true)
			parentNode:reorderChild(widget,1)
		else
			widget:setVisible(false)
			parentNode:reorderChild(widget,0)
		end
	end
	obj:loadExpandItem(btnType)
end
function __ranklayer.loadExpandItem(obj,rankType)
	local shownRank = obj._rankInfo[rankType]
	if not shownRank.itemList then 
		shownRank.itemList = {}
		shownRank.loadCnt = 0
		local expandItem = RankItem.new(rankType,1)
		local panel = obj:egGetScrollView(string.format("%s%d",kPanelItems,rankType))
		panel:addChild(expandItem:egNode(),1,1)
		expandItem:doLoadRankData()
		local function downLoadCallback(rankType)
			obj:loadRankData(rankType)
		end
		expandItem:onDownLoaded(downLoadCallback)
		shownRank.expandItem = expandItem
		
		local panelSelf = obj:egGetWidgetByName(kPanelMySelf)
		local ownItem = RankItem.new(rankType)
		panelSelf:addChild(ownItem:egNode(),1,rankType)
		shownRank.ownItem = ownItem
	end
end
function __ranklayer.loadRankData(obj,rankType)
	local panel = obj:egGetScrollView(string.format("%s%d",kPanelItems,rankType))
	local rankList = RankHelper.getRankList(rankType)
	local curRank = obj._rankInfo[rankType]
	for key,rankitem in ipairs(rankList) do
		local uniqueVal = rankitem[curRank.uniqueKey]
		if curRank.itemList[uniqueVal] then
			curRank.itemList[uniqueVal]:resetData(key,rankitem)
			panel:reorderChild(curRank.itemList[uniqueVal]:egNode(),key)
		else
			local rankItemObj = RankItem.new(rankType,key,rankitem)
			panel:addChild(rankItemObj:egNode(),key,key)
			curRank.itemList[uniqueVal] = rankItemObj
		end
		if uniqueVal == account_data[curRank.uniqueKey] then
			if curRank.ownItem then
				curRank.ownItem:resetSelfRankIdx(key)
			end
		end
		 curRank.loadCnt = key
	end
	panel:reorderChild(curRank.expandItem:egNode(),curRank.loadCnt+1)
	local newh = (curRank.loadCnt+1)*kCellH
	local size = panel:getSize()
	if newh > size.height then
		panel:setInnerContainerSize(CCSizeMake(size.width,newh))
	end
end

--������λ��
function __ranklayer.bindUserAtkListener(obj)--������ս����
    local function touchEnded(sender)     
	    if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:focusBtn(kUserAtk)
		SoundHelper.playEffect(SoundList.click_paper_open)		
        --��ʾ����ս������
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then 
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAtkcap,nil,nil,touchEnded,touchCanceled)
end
function __ranklayer.bindUserEloListener(obj)--����elo
    local function touchEnded(sender)        
	    if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		 obj:focusBtn(kUserElo)
		SoundHelper.playEffect(SoundList.click_paper_open)	
        --��ʾ����ELO��
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then 
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnElo,nil,nil,touchEnded,touchCanceled)
end
function __ranklayer.bindUserPveListener(obj)--����pve
    local function touchEnded(sender)
	    if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
		obj:focusBtn(kUserPve)
         --��ʾ����pve��
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then 
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAchieve,nil,nil,touchEnded,touchCanceled)
end
function __ranklayer.bindClubEloListener(obj)--����elo
    local function touchEnded(sender)
	    if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
		obj:focusBtn(kClubElo)
        --��ʾ����elo��
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then 
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClub,nil,nil,touchEnded,touchCanceled)
end

--�رհ���
function __ranklayer.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __ranklayer.hideWithAction(obj)
    local function callback()
			AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __ranklayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
		baseWidget:runAction(sequece)
	else
		baseWidget:runAction(spawn)
	end
end

RankLayer={}
function RankLayer.new(onloaded)
    local obj =  TouchWidget.new(JsonList.rankLayer)
    table_aux.unpackTo(__ranklayer, obj)
	obj._onloaded = onloaded
    obj:init()
    obj:bindBackListener()
    obj:bindUserAtkListener()
    obj:bindUserEloListener()
    obj:bindUserPveListener()
    obj:bindClubEloListener()
   
    return obj
end

function showEloRank(onloaded)
    local layer = RankLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

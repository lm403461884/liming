local kLblRank = "lbl_rank"
local kLblName = "lbl_user"
local kLblDigLv = "lbl_diglv"
local kLblElo = "lbl_elo"
local kImgElo = "img_elo"
local kImgDigLv = "img_diglv"
local kPanelInfo = "panel_info"
local kPanelLoad = "load_panel"
local kImgItemBg = "img_item_bg"
local kImgLine = "img_lines"

local kImgLoading = "img_loading"
local kLblShowMore = "lbl_showmore"

local kUserAtk = 1 --��ս��������
local kUserElo = 2 --����pvp����
local kUserPve = 3 --PVE
local kClubElo = 4 --����pvp����

local __rankitem = {}
function __rankitem.init(obj,kind,idx,rankinfo)
    obj._kind = kind--���а�����
	obj._itemdata = rankinfo--����������
	obj._idx = idx --λ������,�������б�ǩ��ʱΪnil
	if obj._idx then
		if obj._idx%2 == 1 then
			obj:egHideWidget(kImgItemBg)
		else
			obj:egShowWidget(kImgItemBg)
		end
		if obj._itemdata then --��������
			obj:egShowWidget(kPanelInfo)
			obj:egHideWidget(kPanelLoad)
			obj:loadRankInfo()
			if obj._itemdata.guid ~= account_data.guid then
				obj:bindItemListener()
			end
		else --���ذ�ť
			obj:egHideWidget(kPanelInfo)
			obj:egShowWidget(kPanelLoad)
			obj:egHideWidget(kImgLoading)
			obj:egSetLabelStr(kLblShowMore,"...")
			obj:bindLoadListener()
		end
	else
		obj:egHideWidget(kPanelInfo)
		obj:egHideWidget(kPanelLoad)
		obj:egHideWidget(kImgItemBg)
		obj:egHideWidget(kImgLine)
		RankHelper.downLoadRankIdx(obj._kind)
		obj._itemdata = RankHelper.getOwnRankData(obj._kind)
        if not obj._idx then
           obj._idx = "N" 
           obj:egShowWidget(kPanelInfo)
           obj:loadRankInfo()
           obj:activeSelfRankTimer()
       end
	end
end
function __rankitem.loadRankInfo(obj)
	if obj._kind == kUserElo then
			obj:egSetLabelStr(kLblRank,obj._idx)
			obj:egSetLabelStr(kLblName,obj._itemdata.name)
			obj:egSetLabelStr(kLblElo,obj._itemdata.elo)
			obj:egSetLabelStr(kLblDigLv,obj._itemdata.digLv)
		elseif obj._kind == kClubElo then    
			obj:egChangeImg(kImgDigLv,ImageList.comm_club_elo,UI_TEX_TYPE_PLIST)
			obj:egChangeImg(kImgElo,ImageList.comm_jewel,UI_TEX_TYPE_PLIST)
		    if obj._itemdata then
                obj:egSetLabelStr(kLblRank,obj._idx)
                obj:egSetLabelStr(kLblName,obj._itemdata.name)
                obj:egSetLabelStr(kLblElo,obj._itemdata.jewel)
                obj:egSetLabelStr(kLblDigLv,obj._itemdata.elo)
			else
			    obj:egHideWidget(kPanelInfo)
			end
		elseif obj._kind == kUserAtk then
			obj:egChangeImg(kImgElo,ImageList.comm_kinfe,UI_TEX_TYPE_PLIST)
			obj:egGetWidgetByName(kImgElo):setScale(0.6)
			obj:egSetLabelStr(kLblRank,obj._idx)
			obj:egSetLabelStr(kLblName,obj._itemdata.name)
			obj:egSetLabelStr(kLblElo,obj._itemdata.teamBp)
			obj:egSetLabelStr(kLblDigLv,obj._itemdata.digLv)
		elseif obj._kind == kUserPve then
			obj:egChangeImg(kImgElo,ImageList.star,UI_TEX_TYPE_PLIST)
			obj:egGetWidgetByName(kImgElo):setScale(0.45)
			obj:egSetLabelStr(kLblRank,obj._idx)
			obj:egSetLabelStr(kLblName,obj._itemdata.name)
			obj:egSetLabelStr(kLblElo,obj._itemdata.stars)
			obj:egSetLabelStr(kLblDigLv,obj._itemdata.digLv)
		end
end
function __rankitem.resetData(obj,idx,rankinfo)
	if idx ~= obj._idx then
		obj._idx  = idx
		obj._itemdata = rankinfo
		if idx%2 == 1  then
			obj:egHideWidget(kImgItemBg)
		else
			obj:egShowWidget(kImgItemBg)
		end
		obj:loadRankInfo()
	end
end
function __rankitem.resetSelfRankIdx(obj,idx)
	obj._idx = key
	RankHelper.setOwnRankIdx(obj._kind,idx)
	obj:egSetLabelStr(kLblRank,obj._idx)
end
function __rankitem.bindItemListener(obj)
    local function touchEnded(sender)   
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local function onshown()
			sender:setTouchEnabled(true)
		end
		local pos = sender:getTouchEndPos()
		showRankPopMenu(obj._itemdata,pos,onshown)
    end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,nil)
end
function __rankitem.onDownLoaded(obj,callback)
	obj._downloadCallback = callback
end
function __rankitem.bindLoadListener(obj)
    local function touchEnded(sender)  
		sender:setTouchEnabled(false)
		RankHelper.downLoadRankData(obj._kind)
		obj:activeLoadTimer(obj)
    end
    obj:egBindTouch(kPanelLoad,nil,nil,touchEnded,nil)
end
function __rankitem.getRankIdxInList(obj)
	local uniqueKey ="guid"
	if obj._kind == kClubElo then 	uniqueKey ="cid"  end
	local rankList = RankHelper.getRankList(obj._kind)
	for key,rankitem in ipairs(rankList) do
		if rankitem[uniqueKey] == account_data[uniqueKey] then return key end
	end
	return nil
end
function __rankitem.activeSelfRankTimer(obj,rankIdx)
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if RankHelper.getOwnRankIdx(obj._kind) then
			obj:egUnbindWidgetUpdate(kImgLoading)
			obj._idx = RankHelper.getOwnRankIdx(obj._kind)
			obj:egSetLabelStr(kLblRank,obj._idx)
		else
			local key = obj:getRankIdxInList()
			if key then
				obj:egUnbindWidgetUpdate(kImgLoading)
				obj._idx = key
				RankHelper.setOwnRankIdx(obj._kind,idx)
				obj:egSetLabelStr(kLblRank,obj._idx)
			elseif  passed >= numDef.clientTimeOut then
				obj:egUnbindWidgetUpdate(kImgLoading)
			end
		end
	end
	obj:egBindWidgetUpdate(kImgLoading,callback)
end
function __rankitem.activeLoadTimer(obj)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
	imgWidget:setVisible(true)
	imgWidget:setEnabled(true)
    imgWidget:runAction(repeatforever) 
	obj:egHideWidget(kLblShowMore)
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if (RankHelper.isDownLoading(obj._kind) and passed >= numDef.clientTimeOut) or 
		(not RankHelper.isDownLoading(obj._kind) and not RankHelper.isSucceed(obj._kind)) then
			obj:egUnbindWidgetUpdate(kImgLoading)
			imgWidget:stopAllActions()
			imgWidget:setVisible(false)
			obj:egShowWidget(kLblShowMore)
			obj:egSetLabelStr(kLblShowMore,TxtList.getDataError)
			obj:egSetWidgetTouchEnabled(kPanelLoad,true)
		elseif not RankHelper.isDownLoading(obj._kind) and RankHelper.isSucceed(obj._kind) then
			obj:egUnbindWidgetUpdate(kImgLoading)
			if obj._downloadCallback then obj._downloadCallback(obj._kind) end
			imgWidget:stopAllActions()
			imgWidget:setVisible(false)
			if RankHelper.isAllDownLoaded(obj._kind) then
				obj:egHideWidget(kImgItemBg)
				obj:egHideWidget(kImgLine)
			else
				obj:egShowWidget(kLblShowMore)
				obj:egSetLabelStr(kLblShowMore,"...")
				obj:egSetWidgetTouchEnabled(kPanelLoad,true)
			end
		end
	end
	obj:egBindWidgetUpdate(kImgLoading,callback)
end
function __rankitem.doLoadRankData(obj)
	obj:egSetWidgetTouchEnabled(kPanelLoad,false)
	RankHelper.downLoadRankData(obj._kind)
	obj:activeLoadTimer(obj)
end
RankItem={}
function RankItem.new(kind,idx,rankinfo)
    local obj = {}
    CocosWidget.install(obj,JsonList.rankItem)
    table_aux.unpackTo(__rankitem, obj)
    obj:init(kind,idx,rankinfo)
    return obj
end
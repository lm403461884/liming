--����
local kLblDesc = "lbl_desc"
local kImgFlag = "img_type_bg"
local kLblFlag = "lbl_type"
local kImgSplitB = "split_b"
local kImgBonusBg = "img_bonus_bg"
local kLblBonus = "lbl_bonus"
local kLblLimit = "lbl_limit"
local kLblRecharge = "lbl_recharge"
local kBtnRecharge = "btn_recharge"
--��Դ����
local kImgRes = "img_item_res"
local kLblResVal = "lbl_item_val"
local kPanelAward = "panel_award"
--װ������
local kPanelEquip = "panel_item_equip"
local kImgEquip = "img_item_equip"
local kImgColor = "img_color_bg"
local kLblLv = "lbl_lv"
local kPanelEquip_b = "panel_bonus_equip"
local kImgEquip_b = "img_b_equip"
local kImgColor_b = "img_b_color_bg"
local kLblLv_b = "lbl_b_lv"
--Ӣ����Ϣ����
local kImgHero = "img_item_hero"
local kLblHero = "lbl_heromsg"
local kImgHero_b = "img_bonus_hero"
local kLblHero_b = "lbl_b_heromsg"
--ʱ��
local kLblTimeTxt = "lbl_time_txt"
local kLblTimeVal = "lbl_time_val"

local kTypeEquip = 3
local kTypeHero = 2
local kTypeRes = 1
local __purchaseitem={}

function __purchaseitem.init(obj,itemdata)
	obj._itemdata = itemdata
	obj:loadItem(obj._itemdata.mType) --������Ʒ��Ϣ
	if obj._itemdata.recmdTxt then
		obj:egShowWidget(kImgFlag)
		obj:egShowWidget(kLblFlag)
		obj:egSetLabelStr(kLblFlag,obj._itemdata.recmdTxt)
	end
	obj:egSetLabelStr(kLblRecharge,obj._itemdata.payVal..TxtList.yuanSymbol)
	obj:loadBonus()
end
function __purchaseitem.loadItem(obj,mType)
	if mType == kTypeRes then
		obj:loadResItem()
	elseif mType == kTypeHero then
		obj:loadHeroItem()
	elseif mType == kTypeEquip then
		obj:loadEquipItem()
	end
end
--��Դ����Ʒ
function __purchaseitem.loadResItem(obj)
	obj:egHideWidget(kPanelEquip)
	obj:egHideWidget(kImgHero)
	obj:egShowWidget(kImgRes)
	obj:egShowWidget(kLblResVal)
	local coinType  = obj._itemdata.sType
	local coinName = KVariantList.coinType[coinType]
    obj:egChangeImg(kImgRes,ImageList[string.format("comm_%s",coinName)],UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblResVal,obj._itemdata.gainVal)
end
--Ӣ����Ϣ����Ʒ
function __purchaseitem.loadHeroItem(obj)
	obj:egHideWidget(kPanelEquip)
	obj:egShowWidget(kImgHero)
	obj:egHideWidget(kImgRes)
	obj:egHideWidget(kLblResVal)
	local heroid = obj._itemdata.sType
	obj:egChangeImg(kImgHero,hero_data.getConfig(heroid).headPic,UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblHero,TxtList.msg..Funs.signedNum(obj._itemdata.gainVal))
end
--װ������Ʒ
function __purchaseitem.loadEquipItem(obj)
	obj:egShowWidget(kPanelEquip)
	obj:egHideWidget(kImgHero)
	obj:egHideWidget(kImgRes)
	obj:egHideWidget(kLblResVal)
	local subid = obj._itemdata.sType
	local lv = obj._itemdata.lv
	local qa = obj._itemdata.qa
	obj:egChangeImg(kImgEquip,equipFuncs.getSubEquipCfg(subid,"icon"),UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblLv,lv) --��ʾ�����ȼ�
	obj:egSetWidgetColor(kImgColor,KVariantList.equipColor[qa])
end
function __purchaseitem.loadBonus(obj)
	--�и�������
	if obj._itemdata.bonusType then
		--���ڸ����������޶�������������Чʱ
		local usedCnt = obj._itemdata.usedCnt or 0 
		if not obj._itemdata.limitCnt or obj._itemdata.limitCnt > usedCnt then
			obj:egHideWidget(kLblDesc)
			obj:egHideWidget(kLblTimeTxt)
			obj:egHideWidget(kLblTimeVal)
			obj:egShowWidget(kImgSplitB)
			obj:egShowWidget(kImgBonusBg)
			obj:egShowWidget(kLblBonus)
			if obj._itemdata.limitCnt then
				obj:egShowWidget(kLblLimit)
				obj:egSetLabelStr(kLblLimit,string.format(TxtList.limitCnt,obj._itemdata.limitCnt - usedCnt))
			else
				obj:egHideWidget(kLblLimit)
				obj:egGetWidgetByName(kLblBonus):setPosition(ccp(0,0))
			end
			if obj._itemdata.bonusType == kTypeRes then
				obj:loadResBonus()
			elseif obj._itemdata.bonusType == kTypeHero then
				obj:loadHeroBonus()
			elseif obj._itemdata.bonusType == kTypeEquip then
				obj:loadEquipBonus()
			end
		else
			obj:loadNoneBonus()
		end
	--ʱ����Ʒ,��ʾ����ʱ
	elseif obj._itemdata.st then
		obj:loadTimeBonus()
	else
		obj:loadNoneBonus()
	end
end
--û�и�������ʱ,����˵������
function __purchaseitem.loadNoneBonus(obj)
	obj:egHideWidget(kImgSplitB)
	obj:egHideWidget(kImgBonusBg)
	obj:egHideWidget(kLblBonus)
	obj:egHideWidget(kLblLimit)
	obj:egHideWidget(kPanelAward)
	obj:egHideWidget(kPanelEquip_b)
	obj:egHideWidget(kImgHero_b)
	obj:egHideWidget(kLblTimeTxt)
	obj:egHideWidget(kLblTimeVal)
	obj:egShowWidget(kLblDesc)
	obj:egSetLabelStr(kLblDesc,obj._itemdata.desc)
end
--ʱ�޵���ʱ
function __purchaseitem.loadTimeBonus(obj)
	obj:egHideWidget(kImgSplitB)
	obj:egHideWidget(kImgBonusBg)
	obj:egHideWidget(kLblBonus)
	obj:egHideWidget(kLblLimit)
	obj:egHideWidget(kPanelAward)
	obj:egHideWidget(kPanelEquip_b)
	obj:egHideWidget(kImgHero_b)
	obj:egHideWidget(kLblDesc)
	obj:egShowWidget(kLblTimeTxt)
	obj:egShowWidget(kLblTimeVal)
	local endTime = os.time(obj._itemdata.et)
	local left = math.max(endTime - os.time(),0)
	obj:egSetLabelStr(kLblTimeVal,Funs.formatTime(left))
	local function callback()
		local tmp = math.max(endTime - os.time(),0)
		if tmp ~= left then
			left = tmp
			obj:egSetLabelStr(kLblTimeVal,Funs.formatTime(left))
		end
		if left == 0 then
			obj:egUnbindWidgetUpdate(kLblTimeVal)
			obj:egSetLabelStr(kLblTimeTxt,TxtList.expired)
			obj:egHideWidget(kLblTimeVal)
			obj:egGetWidgetByName(kLblTimeTxt):setPosition(ccp(0,-60))
			obj:egSetWidgetEnabled(kBtnRecharge,false)
		end
	end
	obj:egBindWidgetUpdate(kLblTimeVal,callback)
end
--������Դ�ཱ��
function __purchaseitem.loadResBonus(obj)
	obj:egHideWidget(kPanelEquip_b)
	obj:egHideWidget(kImgHero_b)
	obj:egShowWidget(kPanelAward)
	local panel = obj:egGetWidgetByName(kPanelAward)
	local maxW = 0
	for key,item in ipairs(obj._itemdata.bonus) do
		local coinname = KVariantList.coinType[item.bType]
        local awarditem = AwardItem.new(coinname,Funs.signedNum(item.bVal))
		panel:addChild(awarditem:egNode())
		maxW = math.max(maxW,awarditem:egNode():getSize().width)
    end
	local size = panel:getSize()
	if maxW < size.width then
		panel:setPosition(ccp(panel:getPositionX() + (size.width - maxW)/2,panel:getPositionY()))
	end
end
--����Ӣ����Ϣ����
function __purchaseitem.loadHeroBonus(obj)
	obj:egHideWidget(kPanelEquip_b)
	obj:egShowWidget(kImgHero_b)
	obj:egHideWidget(kPanelAward)
	local bonusinfo = obj._itemdata.bonus[1]
	local heroid = bonusinfo.bType
	obj:egChangeImg(kImgHero_b,hero_data.getConfig(heroid).headPic,UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblHero_b,TxtList.msg..Funs.signedNum(bonusinfo.bVal))
end
--����װ������
function __purchaseitem.loadEquipBonus(obj)
	obj:egShowWidget(kPanelEquip_b)
	obj:egHideWidget(kImgHero_b)
	obj:egHideWidget(kPanelAward)
	local bonusinfo = obj._itemdata.bonus[1]
	local subid = bonusinfo.bType
	local lv = bonusinfo.blv
	local qa = bonusinfo.bqa
	obj:egChangeImg(kImgEquip_b,equipFuncs.getSubEquipCfg(subid,"icon"),UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblLv_b,lv) --��ʾ�����ȼ�
	obj:egSetWidgetColor(kImgColor_b,KVariantList.equipColor[qa])
end
PurchaseItem={}
function PurchaseItem.new(itemdata)
    local obj = {}
    CocosWidget.install(obj,JsonList.purchaseItem)
    table_aux.unpackTo(__purchaseitem, obj)
    obj:init(itemdata)
    return obj
end
local kLblTxt = "lbl_txt"
local kImgTxt = "img_bg"
local kMinW = 310
local __poptxt= {}
local visibleSize = CCDirector:sharedDirector():getVisibleSize()
local origin = CCDirector:sharedDirector():getVisibleOrigin()
function __poptxt.init(obj,txt)
    obj:egSetLabelStr(kLblTxt,txt)
	local widget = obj:egGetWidgetByName(kImgTxt)
    local fadein = CCFadeIn:create(0.3)
    local delayAct = CCDelayTime:create(1)
    local fadeout = CCFadeOut:create(0.2)
    local function callback()
        obj:egRemoveSelf()
    end
    local callfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(fadein)
    array:addObject(delayAct)
    array:addObject(fadeout)
    array:addObject(callfunc)
    local sequence = CCSequence:create(array)
    obj._h = widget:getSize().height
	obj._w = obj:egGetWidgetByName(kLblTxt):getSize().width + 120
	if obj._w < kMinW then obj._w = kMinW end
	local img = tolua.cast(widget,"ImageView")
	img:ignoreContentAdaptWithSize(false)
	img:setSize(CCSizeMake(obj._w,obj._h))
    widget:setPosition(ccp(0,obj._h/2))
    widget:runAction(sequence)
end
function __poptxt.setPositionAt(obj,x,y,anchor)
	if not anchor then anchor = ccp(0,0) end
	x = x - obj._w * anchor.x
	y = y - obj._h * anchor.y
	if x < origin.x then x = origin.x
	elseif x > visibleSize.width - obj._w then  x = visibleSize.width - obj._w end
	if y < origin.y then y = origin.y
	elseif y > visibleSize.height - obj._h then y = visibleSize.height - obj._h end
	obj:egNode():setPosition(ccp(x,y))
end
function __poptxt.getWidth(obj)
	return obj._w
end
function __poptxt.getHight(obj)
	return obj._h
end
PopTxt = {}
function PopTxt.new(txt)
      local obj = {}
    CocosWidget.install(obj,JsonList.popTxt)
    table_aux.unpackTo(__poptxt, obj)
    obj:init(txt)
    return obj
end
function showPopTxt(txt,x,y,anchor)
	if not x then x = 640 end
	if not y then y = 360 end
    local layer = PopTxt.new(txt)
	layer:setPositionAt(x,y,anchor)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
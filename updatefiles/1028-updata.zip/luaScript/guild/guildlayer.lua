local kLblTrainLv = "lbl_lv"
local kLblTrainLvs = "lbl_lvs"
local kLblMyGuild = "lbl_guild1"
local kBtnMyGuild = "btn_guild1"
local kBtnSearch = "btn_guild2"
local kPanelBtn2 = "btn_panel_2"
local kBtnBack = "btn_return"
local kImgLongLine = "img_longline"
local kImgPrompt = "img_prompt"
local kListView = "listview_member"
local kPanelGuild = "panel_guild"
local kPanelTouch = "panel_touch"

local kImgLoading = "img_loading"
local kImgBack = "img_return"

local kPanelMsg = "msg_layer"
local kImgMsgBg = "img_msg_bg"
local kLblMsg = "lbl_msg"
local kLblDetail = "lbl_detail"
local kLblDetail2 = "lbl_detail2"
local kBtnOk = "btn_ok"
local kBtnNo = "btn_no"

local kBtnWar = "btn_war"
local kPanelBtnWar = "btn_panel_war"

local kFire = 1
local kDis = 2
local kLeave = 3
local kSetup = 4
local kMaxNum = 11
local typeSearch=1
local typeClub = 2
local kShowZorder = 2
local kHideZorder = 0
local kOrderSearch = 3
local kOrderInfo = 2
local __guildlayer={}
function __guildlayer.init(obj)
   obj._data = club_data
   obj._trainLv= account_data.train[train.def.guild].lv
   obj:egSetLabelStr(kLblTrainLv,string.format("%s%d","LV",obj._trainLv))
   obj:egSetLabelStr(kLblTrainLvs,string.format("%s%d","LV",obj._trainLv))
   obj:egHideWidget(kPanelMsg)
   obj:egHideWidget(kImgLoading)
   obj:egHideWidget(kPanelTouch)
   
   obj._memberItem = {}         --���Աitem
   obj._setupGuild = nil        --�洴���������
   obj._searchGuild = nil       --�������������
   obj._myGuildInfo = nil       --����info
   obj._selectedGuid = nil      --ѡ�е�guid

   if obj._data then 
       obj._isInGuild = true       --�ж��Ƿ���빫��
	   obj:loadMyGuild()
	   obj:egShowWidget(kPanelBtnWar)
   else
       obj._isInGuild = false 
	    --obj:setupGuild()
	    obj:searchGuild()
	    obj:egSetLabelStr(kLblMyGuild,TxtList.setupGuild)
	    obj:egHideWidget(kPanelBtnWar)
	    obj:egHideWidget(kListView)
   end
   obj:bindSetupListener()
   obj:bindSearchListener()
   obj:bindBtnWarListener()
end
--�޸Ĳ�ѯ�͹���ģ��Ľ����ȡ״̬
function __guildlayer.focusSearch(obj,focus)
	local btnGuild = tolua.cast(obj:egGetWidgetByName(kBtnMyGuild),"Button")
	local btnSearch = tolua.cast(obj:egGetWidgetByName(kBtnSearch),"Button")
	local btnWar = tolua.cast(obj:egGetWidgetByName(kBtnWar),"Button")
	local warpanel = obj:egGetWidgetByName(kPanelBtnWar)
	local searchpanel = obj:egGetWidgetByName(kPanelBtn2)
	--ͼƬ��Դ��֧�����ϲ���ʾ
	--local parentNode = searchpanel:getParent()
	if focus then
		btnSearch:setFocused(true)
		btnSearch:setTouchEnabled(false)
		btnGuild:setTouchEnabled(true)
		btnGuild:setFocused(false)
		btnWar :setTouchEnabled(true)
		btnWar:setFocused(false)
		--parentNode:reorderChild(searchpanel,kShowZorder)
		--parentNode:reorderChild(btnGuild,kHideZorder)
		--parentNode:reorderChild(warpanel,kHideZorder)
	elseif obj._btnWar then
	    obj._btnWar = false
	    btnSearch:setFocused(false)
		btnSearch:setTouchEnabled(true)
		btnGuild:setTouchEnabled(true)
		btnGuild:setFocused(false)
		btnWar :setTouchEnabled(false)
		btnWar:setFocused(true)
		--parentNode:reorderChild(searchpanel,kHideZorder)
		--parentNode:reorderChild(btnGuild,kHideZorder)
		--parentNode:reorderChild(warpanel,kShowZorder)
	
	else
		btnSearch:setFocused(false)
		btnSearch:setTouchEnabled(true)
		btnGuild:setTouchEnabled(false)
		btnGuild:setFocused(true)
		btnWar :setTouchEnabled(true)
		btnWar:setFocused(false)
		--parentNode:reorderChild(searchpanel,kHideZorder)
		--parentNode:reorderChild(btnGuild,kShowZorder)
		--parentNode:reorderChild(warpanel,kHideZorder)
	end
end
function __guildlayer.clickMyGuild(obj)
       if club_data then 
           obj._isInGuild=true
           if obj._searchGuild then 
              obj._searchGuild:egRemoveSelf()
              obj._searchGuild = nil
              if club_search then club_search = nil end
           end
           if obj._guildwar then 
               obj._guildwar:egRemoveSelf() 
               obj._guildwar=nil
           end
           if obj._setupGuild then
               obj._setupGuild:egRemoveSelf()
               obj._setupGuild = nil
           end
           obj:egShowWidget(kPanelBtnWar)
           obj:loadMyGuild()
       else
           obj._isInGuild = false
           if obj._searchGuild then 
              obj._searchGuild:egRemoveSelf()
              obj._searchGuild = nil
              if club_search then club_search = nil end
           end
           if obj._guildwar then 
               obj._guildwar:egRemoveSelf() 
               obj._guildwar=nil
           end
           if obj._myGuildInfo then 
              obj._myGuildInfo:egRemoveSelf() 
              obj._myGuildInfo=nil
              local listView = obj:egGetListView(kListView)
              obj:clearMemberList(listView)
          end
           obj:egHideWidget(kPanelBtnWar)
           obj:setupGuild()
       end
       
end
function __guildlayer.bindSetupListener(obj)
    local function touchEnded()
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj:clickMyGuild()
   end
    obj:egBindTouch(kBtnMyGuild,nil,nil,touchEnded,nil)
end
 --�����������
function __guildlayer.bindSearchListener(obj)          
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		obj:searchGuild()
    end
    obj:egBindTouch(kBtnSearch,nil,nil,touchEnded,nil)
end
function __guildlayer.searchGuild(obj)
       obj:focusSearch(true) --�޸ĵ��״̬����ʾZorder
       if obj._setupGuild then --setupLayer
          obj._setupGuild:egRemoveSelf() 
          obj._setupGuild = nil
       end
       if obj._isInGuild then --listview and guildInfo
          local listView = obj:egGetListView(kListView)
          obj:clearMemberList(listView)
          if obj._myGuildInfo then 
              obj._myGuildInfo:egRemoveSelf() 
              obj._myGuildInfo=nil
          end
          obj:egHideWidget(kListView)
          obj:egHideWidget(kImgLongLine)
          obj:egHideWidget(kImgPrompt)
          obj:egHideWidget(kImgLoading)
       end
       if obj._guildwar then 
           obj._guildwar:egRemoveSelf() 
           obj._guildwar=nil
       end
       local searchlayer = SearchLayer.new()
       obj._searchGuild = searchlayer
       obj:egAddChildTo(kPanelGuild,searchlayer:egNode(),kOrderSearch,kOrderSearch)
end
--����ս����
function __guildlayer.bindBtnWarListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj._btnWar = true
        obj:focusSearch(false)
        if obj._searchGuild then 
            obj._searchGuild:egRemoveSelf()
            obj._searchGuild = nil
            if club_search then club_search = nil end
        end
        if obj._setupGuild then --setupLayer
           obj._setupGuild:egRemoveSelf() 
           obj._setupGuild = nil
        end
        if obj._isInGuild then --listview and guildInfo
           local listView = obj:egGetListView(kListView)
           obj:clearMemberList(listView)
           if obj._myGuildInfo then 
               obj._myGuildInfo:egRemoveSelf() 
               obj._myGuildInfo=nil
           end
           obj:egHideWidget(kListView)
           obj:egHideWidget(kImgLongLine)
           obj:egHideWidget(kImgPrompt)
           obj:egHideWidget(kImgLoading)
        end
        if not club_data.warData then
            local guildwarlayer = GvgSearchLayer.new()
            obj._guildwar = guildwarlayer
            obj:egAddChildTo(kPanelGuild,guildwarlayer:egNode(),3,3)
        else
            local guildwarlayer = GvgEnterLayer.new()
            obj._guildwar = guildwarlayer
            obj:egAddChildTo(kPanelGuild,guildwarlayer:egNode(),3,3)
        end     
        obj:updateGuildState(true)
    end
    obj:egBindTouch(kBtnWar,nil,nil,touchEnded,nil)
end
--����ս�����ص�
function __guildlayer.gvgSearchBack(obj,item)
    local function callback()
        if obj._guildwar then obj._guildwar:egRemoveSelf() end
        local guildwarlayer = GvgEnterLayer.new()
        obj._guildwar = guildwarlayer
        obj:egAddChildTo(kPanelGuild,guildwarlayer:egNode(),3,3)
    end
    item:onload(callback)
end
function __guildlayer.clickWaitBack(obj,item) --�ȴ������ص�
    local function callback(isWait)
        obj:actionWait(isWait)
    end
    item:onClicked(callback)
end
function __guildlayer.clearMemberList(obj,listView)--���listView�е�item
    for idx =1,listView:getChildrenCount() do
        item = listView:getItem(idx-1)
        listView:removeChildByTag(item:getTag(),true)
    end
    listView:removeAllItems()
end
function __guildlayer.showPanelPrompt(obj,btnNum)
    obj:egShowWidget(kPanelMsg)
    local btnOk = obj:egGetWidgetByName(kBtnOk)
    local imgMsgBg = obj:egGetWidgetByName(kImgMsgBg)
    local imgX = imgMsgBg:getPosition()
    local posx,posy = btnOk:getPosition()
    if btnNum == 1 then
        obj:egHideWidget(kBtnNo)
        btnOk:setPosition(ccp(imgX,posy))
    else
        obj:egShowWidget(kBtnNo)
        btnOk:setPosition(ccp(imgX-100,posy))
    end
end
--�ҵĹ������
function __guildlayer.loadMyGuild(obj)  
   obj:focusSearch(false)
   obj._data=club_data
   obj._oldH = 0
   obj:egSetLabelStr(kLblMyGuild,club_data.clubName) 
   obj:egHideWidget(kImgPrompt) 
   obj:egShowWidget(kImgLongLine)  
   obj:egShowWidget(kListView)
   local listView = obj:egGetListView(kListView)
   obj._listview = listView
   obj:bindScrollListener()
   obj:membersOrder(obj._data.members)
   obj:addGuildMembers(kMaxNum,typeClub)
   if obj._data.membersCount>=kMaxNum then
      obj:egShowWidget(kImgPrompt)
      obj:egSetWidgetTouchEnabled(kListView,true)
   else
      --obj._listview:setTouchEnabled(false)   
      obj:egSetWidgetTouchEnabled(kListView,false)
   end
   local function callback ()--��ɢ/�뿪����ص�
        obj:egSetWidgetTouchEnabled(kBtnOk,true)
            obj:egHideWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)  
        if club_data.managerID==account_data.guid then
            --obj:egShowWidget(kPanelMsg)
            if club_data.warData then
                obj:egSetLabelStr(kLblMsg,TxtList.disClubInWar)
                obj:showPanelPrompt(1)
            elseif obj:hadTeamMsg() then
                obj:egSetLabelStr(kLblMsg,TxtList.disClubInCbTeam)
                obj:showPanelPrompt(1)
            else
                obj:egSetLabelStr(kLblMsg,TxtList.disGuild)
                obj:showPanelPrompt(2)
            end    
            obj:bindOkListener(kDis)
            obj:bindNoListener()
        else
            obj:egSetWidgetTouchEnabled(kBtnOk,true)
            --obj:egShowWidget(kPanelMsg)
            if club_data.warData then
                obj:egSetLabelStr(kLblMsg,TxtList.leaveClubInWar)
                obj:showPanelPrompt(1)
            elseif obj:isJoinCbTeam() then
                obj:egSetLabelStr(kLblMsg,TxtList.leaveClubInCbTeam)
                obj:showPanelPrompt(1)
            else
                obj:egSetLabelStr(kLblMsg,TxtList.isLeaveGuild)
                obj:showPanelPrompt(2)
            end    
            obj:bindOkListener(kLeave)
            obj:bindNoListener()
        end 
   end
   local guildInfo = GuildInfo.new()
   guildInfo:onClicked(callback)
   obj._myGuildInfo = guildInfo
   obj:egAddChildTo(kPanelGuild,guildInfo:egNode(),kOrderInfo,kOrderInfo) 
   obj:updateGuildState(true)    
end

--�����Ա����
function __guildlayer.membersOrder(obj,members)
    local itemOrder = {}
    obj._guidOrder = {}
    for guid,item in pairs(members) do
        table.insert(itemOrder,item)
    end
    table.sort(itemOrder,function(a,b) return a.elo>b.elo end)
    for _,item in ipairs (itemOrder) do
        table.insert(obj._guidOrder,item.guid)
    end
    obj._maxNum = obj._data.membersCount
    obj._startIdx = 1   
end
--���ع����Ա
function __guildlayer.addGuildMembers(obj,num,kind)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num-1,obj._maxNum)
    for idx = startIdx,obj._maxNum,1 do
        if idx > endIdx then break end
        local guid = obj._guidOrder[idx]
        local memberItem = GuildMemberItem.new(guid,kind,idx)
        obj._memberItem[guid] = memberItem
        if guid == account_data.guid then memberItem:markMyself() end
        obj._listview:pushBackCustomItem(memberItem:egNode())
        obj:bindTouchEventListener(memberItem)
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __guildlayer.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:cancleBtnLook()
                obj:addGuildMembers(kMaxNum,typeClub)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent)
end

function __guildlayer.cancleBtnLook(obj)--ȡ�������İ�ť
    if obj._memberItem[obj._selectedGuid] then
       obj._memberItem[obj._selectedGuid]:setFocused(false)
       obj._selectedGuid = nil
    end
end

function __guildlayer.bindPanelListener(obj)--ȡ�������İ�ť
    local function touchBegan()
        if obj._myGuildInfo then
            obj:cancleBtnLook()
        end
        obj:egHideWidget(kPanelTouch)
    end
    obj:egBindTouch(kPanelTouch,touchBegan,nil,nil,nil)
end

function __guildlayer.bindTouchEventListener(obj,memberItem)
    local function callback(begin)
       if begin then
           if obj._selectedGuid then
               obj._memberItem[obj._selectedGuid]:setFocused(false)
               obj._selectedGuid = nil
           end    
       else
           if obj._selectedGuid then
               obj._memberItem[obj._selectedGuid]:setFocused(false)
               obj._selectedGuid = memberItem:getprop("guid")
           else
               obj._selectedGuid = memberItem:getprop("guid")
           end
           obj:egShowWidget(kPanelTouch)
       end 
       
    end
    local function btnFireTouch(item)--��ͻ�Ա�ص�
        obj:egSetWidgetTouchEnabled(kBtnOk,true)
        --obj:egShowWidget(kPanelMsg)
        obj:egHideWidget(kLblDetail)
        obj:egHideWidget(kLblDetail2)
        if club_data.warData then
            obj:egSetLabelStr(kLblMsg,TxtList.fireInWar)
            obj:showPanelPrompt(1)
        elseif obj:hadTeamMsg() then
            obj:egSetLabelStr(kLblMsg,TxtList.fireInCbTeam)
            obj:showPanelPrompt(1)    
        else
            obj:egSetLabelStr(kLblMsg,TxtList.fireMember)
            obj:showPanelPrompt(2)
        end    
        obj:bindOkListener(kFire,item)
        obj:bindNoListener() 
    end
    --memberItem:egBindTouch(kBtnItem,nil,nil,callback,nil)
    memberItem:onClickedItem(callback)
    memberItem:onClicked(btnFireTouch)
end
 --�����������
function __guildlayer.setupGuild(obj)   
   obj:focusSearch(false)
   obj:egSetLabelStr(kLblMyGuild,TxtList.setupGuild) 
   obj:egHideWidget(kListView)
   obj:egHideWidget(kImgLongLine)
   obj:egHideWidget(kImgPrompt)
   local function callback(kind) --��������ص�
        obj:egSetWidgetTouchEnabled(kBtnOk,true)
        --obj:egShowWidget(kPanelMsg)
        obj:showPanelPrompt(2)
        obj:egHideWidget(kBtnNo)
        local btnOk = obj:egGetWidgetByName(kBtnOk)
        btnOk:setPosition(ccp(634,265))
        if kind ==1 then
            obj:egShowWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)
            obj:egSetLabelStr(kLblMsg,TxtList.guildName)
            obj:bindOkListener()
        elseif kind ==2 then
            obj:egShowWidget(kLblDetail2)
            obj:egHideWidget(kLblDetail)
            obj:egSetLabelStr(kLblMsg,TxtList.guildInfo)
            obj:bindOkListener()
        elseif kind == 3 then
            obj:egHideWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)
            obj:egSetLabelStr(kLblMsg,TxtList.setupSuccess)
            obj:bindOkListener(kSetup)
        elseif kind == 4 then
            obj:egHideWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)
            obj:egSetLabelStr(kLblMsg,TxtList.setupFaild)
            obj:bindOkListener()    
        end    
   end
   local setupGuild = SetupLayer.new()
   setupGuild:onClicked(callback)
   obj._setupGuild = setupGuild
   obj:egAddChildTo(kPanelGuild,setupGuild:egNode(),3,3)
   obj:updateGuildState(false)
end

function __guildlayer.bindOkListener(obj,kind,item)
    local function touchEnded()
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:egSetWidgetTouchEnabled(kBtnOk,false)
        if kind == kFire then
            if club_data.warData or obj:hadTeamMsg() then
                obj:egHideWidget(kPanelMsg)    
            else
                local guid = item:getprop("guid")
                local idx = item:getprop("rank")
                obj._listview:removeItem(idx-1)
                SendMsg[938009](guid)
                obj._memberItem[obj._selectedGuid]=nil
                obj._selectedGuid = nil
                club_data.members[guid]=nil
                club_data.membersCount = club_data.membersCount - 1
                for guid,membersItem in pairs(obj._memberItem) do
                    local rank = membersItem:getprop("rank")
                    if rank >idx then
                       membersItem:setIdx(rank-1)
                    end
                end
            end    
        elseif kind == kDis then
            if club_data.warData or obj:hadTeamMsg() then
                obj:egHideWidget(kPanelMsg)
            else
                print("dissolve guild")  
	            SendMsg[938010]()
	            club_data=nil
				account_data.cid = 0
				account_data.cbName = ""
	            local scene = GuildScene.new()
                scene:egReplace()
            end    
        elseif kind == kLeave then
            if club_data.warData or obj:isJoinCbTeam() then
                obj:egHideWidget(kPanelMsg)
            else
                print("leave guild")                                
                SendMsg[938006]() 
                club_data=nil
				account_data.cid = 0
				account_data.cbName = ""
	            local scene = GuildScene.new()
                scene:egReplace()  
            end    
        elseif kind == kSetup then
           obj:egUnbindWidgetUpdate(kBtnMyGuild)
           local scene = GuildScene.new()
           scene:egReplace()  
        end
        obj:egHideWidget(kPanelMsg)
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __guildlayer.actionWait(obj,isWait)
    if isWait then
        obj:egShowWidget(kImgLoading)
        local imgWidget = obj:egGetWidgetByName(kImgLoading)
        local rotateby = CCRotateBy:create(1,360)
        local repeatforever = CCRepeatForever:create(rotateby)
        imgWidget:runAction(repeatforever) 
    else
        obj:egHideWidget(kImgLoading)
        local imgWidget = obj:egGetWidgetByName(kImgLoading)
        imgWidget:stopAllActions()
    end    
end

function __guildlayer.bindNoListener(obj)
     local function touchEnded()
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:egHideWidget(kPanelMsg)
        --obj:egSetWidgetTouchEnabled(kBtnSelect,true)
    end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,nil)
end
function __guildlayer.bindBackListener(obj)
   local function touchBegan()
       obj:egSetWidgetScale(kImgBack,1.1)
   end
   local function touchEnded(sender)
       SoundHelper.playEffect(SoundList.click_shop_goods)
       obj:egSetWidgetScale(kImgBack,1)
       sender:setTouchEnabled(false)
       if club_search then club_search = nil end
       local scene = TownScene.new()
       scene:egReplace()
   end
   local function touchCanceled()
       obj:egSetWidgetScale(kImgBack,1)
   end
   obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end
function __guildlayer.updateMemberReward(obj)
    for guid,item in pairs(club_data.members) do
        local reward = clubCalc.memberReward(club_data.elo,club_data.coe,item.coe)
        item.reward = reward
    end
end
function __guildlayer.activeUpdata(obj)
    local startTime = os.time()
    local function guildUpdate()
        if not AccountHelper:isLocked(kStateGuildData) then
            obj:egUnbindUpdate()
            --obj:getClubHonor()
            obj:updateMemberReward()--���¹����Ա����
            local imgWidget = obj:egGetWidgetByName(kImgLoading)
            imgWidget:stopAllActions()
            obj:egHideWidget(kImgLoading)
            obj:init()
        else
            if os.time() - startTime >numDef.clientTimeOut then
                obj:egUnbindUpdate()
                local imgWidget = obj:egGetWidgetByName(kImgLoading)
                imgWidget:stopAllActions()
		        postEventSignal(kEventRequestTimeOut)
            end    
        end
    end
    obj:egBindUpdate(guildUpdate)
end
--������߳�����ʱ���������ı�״̬
function __guildlayer.updateGuildState(obj,oldState)
    local function callback()
        if not oldState and club_data then 
            obj:egUnbindWidgetUpdate(kBtnMyGuild)
            if obj._setupGuild then 
                obj:clickMyGuild()        
            end
        elseif oldState and not club_data then
            obj:egUnbindWidgetUpdate(kBtnMyGuild)
            if obj._guildwar or obj._myGuildInfo then
                obj:clickMyGuild()
            else
                obj:egHideWidget(kPanelBtnWar)    
            end
        end
    end
    obj:egBindWidgetUpdate(kBtnMyGuild,callback)  
end
--�Ƿ����̽�ն�
function __guildlayer.isJoinCbTeam(obj,guid)
    if guid then
        
    else
        for heroid,item in pairs(account_data.cbTeam) do
            if heroid then return true end
        end
    end
    return false
end
function __guildlayer.hadTeamMsg(obj)
    for guid,item in pairs(club_data.teamMsg) do
        if guid then return true end
    end
    return false
end
GuildLayer={}
function GuildLayer.new()
   local obj = TouchWidget.new(JsonList.guildLayer)
   table_aux.unpackTo(__guildlayer,obj)
   if club_data then
       if club_data.startRefreshTime and os.time() - club_data.startRefreshTime <= numDef.clubReTime  then
           obj:init()
       else
           club_data.startRefreshTime = os.time()
           SendMsg[938003](club_data.clubName)
           AccountHelper:lock(kStateGuildData)
           obj:activeUpdata()
           obj:actionWait(true)
       end    
   else
       obj:init()
   end    
   obj:bindBackListener()
   obj:bindPanelListener()
   return obj
end

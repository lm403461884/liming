local kLblTitle = "lbl_title"
local kLblName = "lbl_name"
local kLblChatInfo = "lbl_info"
local kLblTime = "lbl_time"
local kLblLv = "lbl_digLv"
local kImgFlag = "img_flag"

local kPanelLayer = "panel_msg"
local kYGreenColor = ccc3(11,92,10)
local kTxtW = 640
local kTxtH = 36
local kOffsetH = 4
local __msgItem={}

function __msgItem.init(obj,idx)
   obj._idx = idx
   obj:egNode():ignoreContentAdaptWithSize(false)
   obj._msg = ChatHelper.getGuildMsg(obj._idx)
   obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",obj._msg.date))

   if obj._msg.type == 3 then
		obj._msg.name = club_data.members[obj._msg.guid].name
		obj:egSetBMLabelStr(kLblLv,club_data.members[obj._msg.guid].digLv)
		if obj._msg.guid == account_data.guid then
			obj:egSetWidgetColor(kLblName,kYGreenColor)
			obj:egSetWidgetColor(kLblTime,kYGreenColor)
			obj:egSetWidgetColor(kLblTitle,kYGreenColor)
		elseif obj._msg.guid > 0 then
			obj:bindPanelListener()
		end
		if obj._msg.guid == club_data.managerID then
			obj:egShowWidget(kLblTitle)
		end
   elseif obj._msg.type == 90 then
		obj:egHideWidget(kLblLv)
   end
   obj:egSetLabelStr(kLblName,obj._msg.name)
   obj:egSetLabelStr(kLblChatInfo,Funs.toUTF(obj._msg.content))
   obj:resetLayout()
end
function __msgItem.resetLayout(obj)
	local panelsize = obj:egNode():getSize()
    local lblInfo = tolua.cast(obj:egGetWidgetByName(kLblChatInfo),"Label")
	local lblsize = lblInfo:getSize()
    local rows = math.ceil(lblsize.width/kTxtW)
    if rows > 1 then
		local panelOffsetH = (rows-1)* (lblsize.height+kOffsetH)
		lblInfo:setTextAreaSize(CCSizeMake(kTxtW,rows*kTxtH))
		obj:egNode():setSize(CCSizeMake(panelsize.width,panelsize.height + panelOffsetH))
		lblInfo:setPosition(ccp(lblInfo:getPositionX(),lblInfo:getPositionY() + panelOffsetH))
		local lblname = obj:egGetWidgetByName(kLblName)
		local lbltime = obj:egGetWidgetByName(kLblTime)
		local lbltitle = obj:egGetWidgetByName(kLblTitle)
		local imgflag = obj:egGetWidgetByName(kImgFlag)
		imgflag:setPosition(ccp(imgflag:getPositionX(),imgflag:getPositionY() + panelOffsetH))
		lbltitle:setPosition(ccp(lbltitle:getPositionX(),lbltitle:getPositionY() + panelOffsetH))
		lblname:setPosition(ccp(lblname:getPositionX(),lblname:getPositionY() + panelOffsetH))
		lbltime:setPosition(ccp(lbltime:getPositionX(),lbltime:getPositionY() + panelOffsetH))
    end
end
--聊天信息点击事件
function __msgItem.bindPanelListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local function onshown()
			sender:setTouchEnabled(true)
		end
		local pos = sender:getTouchEndPos()
		if obj._msg.type == 3 and club_data and club_data.members[obj._msg.guid] then
			obj._msg.clubid = club_data.cid
			obj._msg.clubname = club_data.clubName
			obj._msg.digLv = club_data.members[obj._msg.guid].digLv
		end
		showChatPopMenu(obj._msg,pos,onshown)
    end
	obj:egSetWidgetTouchEnabled(kPanelLayer,true)
    obj:egBindTouch(kPanelLayer,touchBegan,nil,touchEnd,nil)
end
GuildMsgItem = {}
function GuildMsgItem.new(idx)
   local obj ={}
   CocosWidget.install(obj,JsonList.pubMsgItem)
   table_aux.unpackTo(__msgItem,obj)
   obj:init(idx)
   return obj
end
local kLblName = "lbl_name"
local kLblChatInfo = "lbl_info"
local kLblTime = "lbl_time"
local kLblSG = "lbl_sg"
local kLblLv = "lbl_digLv"
local kPanelLayer = "panel_msg"
local kImgFlag = "img_flag"

local kTxtW = 630
local kTxtH = 36
local kOffsetH = 4
local __msgItem={}
function __msgItem.init(obj)
   obj:egNode():ignoreContentAdaptWithSize(false)
   obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",obj._msg.date))
   obj:egSetLabelStr(kLblName,obj._msg.name) 
   if obj._msg.recvmsg == 1 then --接收到的消息
		obj:egSetBMLabelStr(kLblLv,obj._msg.digLv)
   end
   obj:egSetLabelStr(kLblChatInfo,Funs.toUTF(obj._msg.content))
   obj:resetLayout()
end
function __msgItem.resetLayout(obj)
	local lblInfo = tolua.cast(obj:egGetWidgetByName(kLblChatInfo),"Label")
	local panelsize = obj:egNode():getSize()
	local lblsize = lblInfo:getSize()
    local rows = math.ceil(lblsize.width/kTxtW)
    if rows > 1 then
		local panelOffsetH = (rows-1)* (lblsize.height+kOffsetH)
		lblInfo:setTextAreaSize(CCSizeMake(kTxtW,rows*kTxtH))
		obj:egNode():setSize(CCSizeMake(panelsize.width,panelsize.height + panelOffsetH))
		lblInfo:setPosition(ccp(lblInfo:getPositionX(),lblInfo:getPositionY() + panelOffsetH))
		local lblsg = obj:egGetWidgetByName(kLblSG)
		local lblname = obj:egGetWidgetByName(kLblName)
		local lbltime = obj:egGetWidgetByName(kLblTime)
		lblname:setPosition(ccp(lblname:getPositionX(),lblname:getPositionY() + panelOffsetH))
		lbltime:setPosition(ccp(lbltime:getPositionX(),lbltime:getPositionY() + panelOffsetH))
		if obj._msg.recvmsg == 1 then --接收到的消息
			local imgflag = obj:egGetWidgetByName(kImgFlag)
			imgflag:setPosition(ccp(imgflag:getPositionX(),imgflag:getPositionY() + panelOffsetH))
			lblsg:setPosition(ccp(lblname:getPositionX() + lblname:getSize().width + 10 ,lblsg:getPositionY() + panelOffsetH))
		else
			lblsg:setPosition(ccp(lblsg:getPositionX(),lblsg:getPositionY() + panelOffsetH))
		end
	else
		if obj._msg.recvmsg == 1 then 
			local lblname = obj:egGetWidgetByName(kLblName)
			local lblsg = obj:egGetWidgetByName(kLblSG)
			lblsg:setPosition(ccp(lblname:getPositionX() + lblname:getSize().width + 10 ,lblsg:getPositionY()))
		end
    end
end
--聊天信息点击事件
function __msgItem.bindPanelListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local function onshown()
			sender:setTouchEnabled(true)
		end
		local pos = sender:getTouchEndPos()
		showChatPopMenu(obj._msg,pos,onshown)
    end
	obj:egSetWidgetTouchEnabled(kPanelLayer,true)
    obj:egBindTouch(kPanelLayer,touchBegan,nil,touchEnd,nil)
end
PrivateMsgItem = {}
function PrivateMsgItem.new(idx)
   local obj ={}
   table_aux.unpackTo(__msgItem,obj)
   obj._idx = idx
   obj._msg = ChatHelper.getPrivateMsg(obj._idx)
   if obj._msg.recvmsg == 0 then --发送的消息
		CocosWidget.install(obj,JsonList.chatMsgPrivate)
   else --接收到的消息
		CocosWidget.install(obj,JsonList.chatMsgPrivate_r)
   end
   obj:init()
   obj:bindPanelListener()
   return obj
end
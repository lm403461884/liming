local kBtnOk= "btn_ok"
local kPanelLayer = "panel_msg"
local kLblOk = "lbl_ok"

local kLblName = "lbl_name"
local kLblNum = "lbl_num"
local kLblChatInfo = "lbl_info"
local kLblPosition = "lbl_position"
local kLblTime = "lbl_time"
--local kLblLv = "lbl_lv"

local kTxtW = 685
local kTxtH = 31
local kMinH = 95
local __adventuremsgitem={}

function __adventuremsgitem.init(obj,idx)
   obj._idx = idx
   obj._msg =ChatHelper.getGuildMsg(obj._idx)
   obj._msg.name=club_data.members[obj._msg.guid].name or TxtList.LeavedMember
   obj:egSetLabelStr(kLblName,string.format("%s%s",obj._msg.name,TxtList.exploreTeam))
   obj:egSetLabelStr(kLblNum,string.format("(%d/%d)",obj._msg.cur,obj._msg.limit))
   obj:egHideWidget(kBtnOk)
   
   local widName = obj:egGetWidgetByName(kLblName)
   local widNum = obj:egGetWidgetByName(kLblNum)
   local size = widName:getSize()
   local posx,posy = widName:getPosition()
   widNum:setPosition(ccp(posx+size.width/2,posy))
   
   obj._oldCount = obj._msg.cur
   --obj:egHideWidget(kLblLv)
   if obj._msg.guid == club_data.managerID then
       obj:egSetLabelStr(kLblPosition,TxtList.president)
   else
       obj:egSetLabelStr(kLblPosition,TxtList.member)
   end
   
   obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",obj._msg.date))
   if obj._msg.cur < obj._msg.limit then
        obj:egShowWidget(kBtnOk)
        if obj._msg.guid == account_data.guid or obj:isAddCbTeam() then
            obj:egSetLabelStr(kLblOk,TxtList.look)
        else
            obj:egSetLabelStr(kLblOk,TxtList.joinAdventure)
            obj:egChangeBtnImg(kBtnOk,ImageList.btn_red_n,ImageList.btn_red_s,ImageList.btn_red_s,UI_TEX_TYPE_PLIST)
        end
        obj:activeUpdate()
   else
		obj:egShowWidget(kBtnOk)
		obj:egSetLabelStr(kLblOk,TxtList.look)
   end  
   obj:egSetLabelStr(kLblChatInfo,obj._msg.content)
end
--�Ƿ��Ѿ��μӹ���֧̽�ն�
function __adventuremsgitem.isAddCbTeam(obj)
    for heroid,item in pairs(account_data.cbTeam) do
        if item.tid == obj._msg.guid then return true end
    end
    return false
end

--����̽�ն���Ϣ
function __adventuremsgitem.updateInfo(obj) 
    obj._msg =ChatHelper.getGuildMsg(obj._idx)
    obj._msg.name=club_data.members[obj._msg.guid].name or TxtList.LeavedMember
    obj:egSetLabelStr(kLblNum,string.format("(%d/%d)",obj._msg.cur,obj._msg.limit))
    if obj._msg.cur < obj._msg.limit then
        obj:egShowWidget(kBtnOk)
        if obj._msg.guid == account_data.guid or obj:isAddCbTeam() then
            obj:egSetLabelStr(kLblOk,TxtList.look)
            obj:egChangeBtnImg(kBtnOk,ImageList.btn_paper_n,ImageList.btn_paper_s,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
        else
            obj:egSetLabelStr(kLblOk,TxtList.joinAdventure)
            obj:egChangeBtnImg(kBtnOk,ImageList.btn_red_n,ImageList.btn_red_s,ImageList.btn_red_s,UI_TEX_TYPE_PLIST)
        end
    else
		 obj:egShowWidget(kBtnOk)
		 obj:egSetLabelStr(kLblOk,TxtList.look)
		 obj:egChangeBtnImg(kBtnOk,ImageList.btn_paper_n,ImageList.btn_paper_s,ImageList.btn_paper_d,UI_TEX_TYPE_PLIST)
    end  
end
function __adventuremsgitem.activeUpdate(obj)
    local function callback()
        obj._msg =ChatHelper.getGuildMsg(obj._idx)
        if obj._oldCount ~= obj._msg.cur and not obj._msg.cbTeamDissolved then--̽�ն��������
            obj:updateInfo()
            obj._oldCount = obj._msg.cur
        end
        --[[if not club_data.teamMsg[obj._msg.guid] or obj._msg.cbTeamDissolved then --̽�նӽ�ɢ
            obj:egUnbindWidgetUpdate(kLblName)
            obj:egSetLabelStr(kLblChatInfo,TxtList.cbTeamOver)
            obj:egHideWidget(kBtnOk)
            obj:egSetWidgetTouchEnabled(kBtnOk,false)
            obj._msg.cbTeamDissolved = true
            obj._msg._mid = obj._msg.date
        end--]]
        local overTime = obj._msg.date+account_data.scOffsetTime+numDef.cbTeamInterval
        if overTime < os.time() or not club_data.teamMsg[obj._msg.guid] then obj._msg.cbTeamDissolved=true end
        if obj._msg.cbTeamDissolved and obj._msg._mid ~= obj._msg.date then --̽�նӽ�ɢ
            obj:egUnbindWidgetUpdate(kLblName)
            obj:egSetLabelStr(kLblChatInfo,TxtList.cbTeamOver)
            obj:egHideWidget(kBtnOk)
            obj:egSetWidgetTouchEnabled(kBtnOk,false)
            --obj._msg.cbTeamDissolved = true
            obj._msg._mid = obj._msg.date
        end
    end
    obj:egBindWidgetUpdate(kLblName,callback)
end
function __adventuremsgitem:getMsgShow(obj)
    if obj._msg.cbTeamDissolved then
        return false
    end
    return true
end
--�鿴���μ�̽�նӵ���¼�
function __adventuremsgitem.bindOkListener(obj) 
    local function touchEnded (sender)
        sender:setTouchEnabled(false)
        local function callback() sender:setTouchEnabled(true) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
		SendMsg[9313002](obj._msg.guid)
        AccountHelper:lock(kStateAdventureTeam)
        if obj._msg.guid == account_data.guid or obj:isAddCbTeam() then
            showExploreTeam(callback,3,obj._msg.guid)
        elseif obj._msg.cur == obj._msg.limit then
            showExploreTeam(callback,3,obj._msg.guid)
        else
            showExploreTeam(callback,2,obj._msg.guid)
        end 
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)    
end
--������Ϣ����¼�
function __adventuremsgitem.bindPanelListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		if obj._msg.state == 0 then
			SoundHelper.playEffect(SoundList.click_shop_goods)
			local function onshown()
				sender:setTouchEnabled(true)
			end
			local pos = sender:getTouchEndPos()
			showChatPopMenu(obj._msg,pos,onshown)
		end
    end
	obj:egSetWidgetTouchEnabled(kPanelLayer,true)
    obj:egBindTouch(kPanelLayer,touchBegan,nil,touchEnd,nil)
end
AdventureMsgItem = {}
function AdventureMsgItem.new(idx)
   local obj ={}
   CocosWidget.install(obj,JsonList.adventureMsgItem)
   table_aux.unpackTo(__adventuremsgitem,obj)
   obj:init(idx)
   obj:bindPanelListener()
   obj:bindOkListener()
   return obj
end
--����ģ��
local kPanelLayer = "base_panel"
local kPanelInput = "input_panel"
local kBtnSend = "btn_sendmsg"
local kImgChatBox  = "img_info_bg"
local kLblChatTxt = "lbl_show_info"
local kBtnGuildDetail = "btn_guild_info"
local kTfChat = "tf_chat"
local kPanelChatBg = "lblbg_panel"
local kLblTalkWith = "lbl_chat_username"
local kImgCoin = "notice_paymsg"
local kPanelPay = "panel_notice_pay"
local kLblChatCnt = "lbl_chat_cnt"
local kLblPayVal = "lbl_pay_val"
--��������
local kBtnPub = "btn_pub"
local kBtnGuild = "btn_guild"
local kBtnPrivate = "btn_private"
local kBtnHide = "btn_hide"
local kLblPrivate = "lbl_private"
local kLblPub = "lbl_pub"
local kLblGuild = "lbl_guild"

local kImgNotice = "img_notice"
local kImgPub = "img_pub"
local kImgGuild = "img_guild"
local kImgPrivate ="img_private"
local kImgChatBg = "chat_bg"
local kPanelBg = "panel_info"

local kListPub= "list_pub"
local kListGuild = "list_guild"
local kListPrivate = "list_private"

local kImgState = "img_state_arr"
local kLblGuild = "lbl_guild"

--û�й���
local kBtnIn = "btn_in"
local kPanelNoGuild = "noguild_panel"
local kImgTrain = "img_train"
local kLblNoTrain = "lbl_no_guild"

--����Ϣ��ʾ
local kNewMsgBg = "new_msg_bg"
local kLblNewPub = "lbl_new_pub_txt"
local kPanelTxt = "txt_panel"

local kMoveDis = 816
local kMaxCnt = 50
local kMaxNum = 10
local kMPub = 1
local kMGuild = 2
local kMPrivate = 3

local kGrayColor = ccc3(128,128,128)
local kBrownColor = ccc3(83,49,22)
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local __chatlayer={}
function __chatlayer.init(obj)
    obj._shown = false
	obj._showArrow = true
	obj._pubinfo = {}
	obj._guildinfo = {}
	obj._privateinfo = {}
	obj._focusPart = nil
	obj._waterMask = TxtList.promptInput
	local lblImgBg = obj:egGetWidgetByName(kImgChatBox)
	obj._orgImgX = lblImgBg:getPositionX()
	obj._orgImgW = lblImgBg:getSize().width
	local lblPanelBg = obj:egGetWidgetByName(kPanelChatBg)
	obj._orgLblX = lblPanelBg:getPositionX()
	obj._orgLblW = lblPanelBg:getSize().width
	obj:changeArraw(0,0) --��ʼ״̬Ϊ����δ����
	local chatbg = obj:egGetWidgetByName(kPanelBg)
	chatbg:setPosition(ccp(-kMoveDis,chatbg:getPositionY()))
	obj:egHideWidget(kNewMsgBg)
	ChatHelper.loadPrivateMsg()--����˽����ʷ��¼
	obj:loadPubMsg()
	obj:loadGuildMsg()
	obj:loadPrivateMsg()
	obj:activeBackReciver()
	obj:activeNewPubReciver()--�������춨ʱ��
end
function __chatlayer.showScaleAction(obj,widgetName,show)
	local widget = obj:egGetWidgetByName(widgetName)
    widget:setVisible(show)
	if show then
        local scaleto1 = CCScaleTo:create(1,0.6)
        local scaleto2 = CCScaleTo:create(1,0.8)
        local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
        local repeatever = CCRepeatForever:create(sequence)
        widget:runAction(repeatever)
	else
	    widget:stopAllActions()
	end
end
--expand: 0 ����״̬ 1չ��״̬
--pressed 0 ��ͨ״̬ 1����״̬
function __chatlayer.changeArraw(obj,expand,pressed)
	local imgArrow =  tolua.cast(obj:egGetWidgetByName(kImgState),"ImageView")
	local imgSrc = {ImageList.btn_arrow_n,ImageList.btn_arrow_s}
	if pressed==0 then
		imgArrow:loadTexture(ImageList.btn_arrow_n,UI_TEX_TYPE_PLIST)
	else
		imgArrow:loadTexture(ImageList.btn_arrow_s,UI_TEX_TYPE_PLIST)
	end
	if expand==0 then
		imgArrow:setRotation(270)
	else
		imgArrow:setRotation(90)
	end
end
--��ʾ�������촰��
function __chatlayer.setGuildFocused(obj)
	local btnGuild =  tolua.cast(obj:egGetWidgetByName(kBtnGuild),"Button")
	local btnPub = tolua.cast(obj:egGetWidgetByName(kBtnPub),"Button")
	local btnPrivate = tolua.cast(obj:egGetWidgetByName(kBtnPrivate),"Button")
	obj:egSetWidgetColor(kLblPub,kWhiteColor)
	obj:egSetWidgetColor(kLblPrivate,kWhiteColor)
	obj:egSetWidgetColor(kLblGuild,kBrownColor)
	obj._focusPart = kMGuild
	btnGuild:setEnabled(false)
	btnPub:setEnabled(true)
	btnPrivate:setEnabled(true)
	obj:egHideWidget(kListPub)
	obj:egHideWidget(kListPrivate)
	obj:egHideWidget(kLblTalkWith)
	obj:egHideWidget(kPanelPay)
	obj:showScaleAction(kImgGuild,false)
	ChatHelper.setHasGuildMsg(false)
	obj._waterMask = TxtList.promptInput
	if club_data then
		obj:egShowWidget(kPanelInput)
		obj:egShowWidget(kBtnSend)
		obj:egShowWidget(kBtnGuildDetail)
		obj:egShowWidget(kImgChatBox)
		obj:egShowWidget(kListGuild)
		obj:egHideWidget(kPanelNoGuild)
		obj:egHideWidget(kBtnIn)
		obj:egSetLabelStr(kLblGuild,club_data.clubName)
		obj:egSetLabelStr(kLblChatTxt,obj._waterMask)
		local lblPanelBg = obj:egGetWidgetByName(kPanelChatBg)
		lblPanelBg:setPosition(ccp(obj._orgLblX,lblPanelBg:getPositionY()))
		lblPanelBg:setSize(CCSizeMake(obj._orgLblW,lblPanelBg:getSize().height))
		
		local lblImgBg = obj:egGetWidgetByName(kImgChatBox)
		lblImgBg:setPosition(ccp(obj._orgImgX,lblImgBg:getPositionY()))
		lblImgBg:setScaleY(1)
		local textField = tolua.cast(obj:egGetWidgetByName(kTfChat),"TextField")
		textField:setText("")
		obj:egSetWidgetColor(kLblChatTxt,kGrayColor)
		if not(obj._guildinfo.cid and obj._guildinfo.cid == club_data.cid)  then
			obj:clearGuildMsgList()
			obj:loadGuildMsg() --�й������ݺ󣬳����л���������ݼ��أ��ٴ��л�ʱ���������ݼ���
		end
		obj:updateGuildState(true)
	else
		obj:clearGuildMsgList()
		obj:egHideWidget(kPanelInput)
		obj:egHideWidget(kBtnSend)
		obj:egHideWidget(kBtnGuildDetail)
		obj:egHideWidget(kImgChatBox)
		obj:egHideWidget(kListGuild)
		obj:egShowWidget(kPanelNoGuild)
		obj:egShowWidget(kBtnIn)
		obj:egSetLabelStr(kLblGuild,TxtList.guildChat)
		local img = obj:egGetWidgetByName(kImgTrain)
		if account_data.train[train.def.guild] then
			img:setOpacity(255)
			obj:egSetWidgetEnabled(kBtnIn,true)
			obj:egHideWidget(kLblNoTrain)
		else
			img:setOpacity(128)
			obj:egSetWidgetEnabled(kBtnIn,false)
		end
		obj:updateGuildState(false)
	end

end
--������뿪����ʱ�ı乫�����촰��״̬
function __chatlayer.updateGuildState(obj,oldState)
    local function callback()
        if not oldState and club_data then
            obj:egUnbindWidgetUpdate(kBtnGuild)
            obj:setGuildFocused()
            obj:activeGuildReciver()
        elseif oldState and not club_data then
            obj:egUnbindWidgetUpdate(kBtnGuild)
            obj:egUnbindWidgetUpdate(kImgGuild)
            obj:setGuildFocused()
        end
    end
    obj:egBindWidgetUpdate(kBtnGuild,callback)
end
--��ʾ���Ĵ���
function __chatlayer.setPubFocused(obj)
	local btnGuild =  tolua.cast(obj:egGetWidgetByName(kBtnGuild),"Button")
	local btnPub = tolua.cast(obj:egGetWidgetByName(kBtnPub),"Button")
	local btnPrivate = tolua.cast(obj:egGetWidgetByName(kBtnPrivate),"Button")
	obj:egSetWidgetColor(kLblPub,kBrownColor)
	obj:egSetWidgetColor(kLblPrivate,kWhiteColor)
	obj:egSetWidgetColor(kLblGuild,kWhiteColor)
	obj:showScaleAction(kImgPub,false)
	ChatHelper.setHasPubMsg(false)
	obj._focusPart = kMPub
	btnGuild:setEnabled(true)
	btnPub:setEnabled(false)
	btnPrivate:setEnabled(true)
    
	obj:egShowWidget(kListPub)
	obj:egShowWidget(kPanelInput)
	obj:egShowWidget(kBtnSend)
	obj:egShowWidget(kImgChatBox)
	obj:egShowWidget(kPanelPay)
	
	obj:egHideWidget(kListGuild)
	obj:egHideWidget(kListPrivate)
	obj:egHideWidget(kPanelNoGuild)
	obj:egHideWidget(kBtnIn)
	obj:egHideWidget(kBtnGuildDetail)
	obj:egHideWidget(kLblTalkWith)
	obj:egUnbindWidgetUpdate(kBtnGuild)
	obj:showChatCntInfo()
	local panelpay = obj:egGetWidgetByName(kPanelPay)
	local lblPanelBg = obj:egGetWidgetByName(kPanelChatBg)
	local offsetx = panelpay:getSize().width - obj._orgLblX
	lblPanelBg:setPosition(ccp(obj._orgLblX + offsetx,lblPanelBg:getPositionY()))
	lblPanelBg:setSize(CCSizeMake(obj._orgLblW - offsetx,lblPanelBg:getSize().height))
    local lblImgBg = obj:egGetWidgetByName(kImgChatBox)
	lblImgBg:setPosition(ccp(obj._orgImgX + offsetx,lblImgBg:getPositionY()))
	local w = lblImgBg:getSize().width
	lblImgBg:setScaleX((w-offsetx)/w)
	
	obj._waterMask = TxtList.promptInput
	obj:egSetLabelStr(kLblChatTxt,obj._waterMask)
	local textField = tolua.cast(obj:egGetWidgetByName(kTfChat),"TextField")
	textField:setText("")
	obj:egSetWidgetColor(kLblChatTxt,kGrayColor)
end
function __chatlayer.showChatCntInfo(obj)
	if os.time() >= account_data.chatNextSt then
		account_data.chatUsedCnt = 0
		account_data.chatNextSt = Funs.getTimeWithHMS(numDef.chatRefreshUTH,numDef.chatRefreshUTM,0,account_data.scOffsetTime)
	end
	local maxChatCnt =  VipLvUp[account_data.vip or 0].chatCnt or 0
	if account_data.chatUsedCnt < maxChatCnt then
		obj:egHideWidget(kImgCoin)
		obj:egHideWidget(kLblPayVal)
		obj:egShowWidget(kLblChatCnt)
		obj:egSetBMLabelStr(kLblChatCnt,math.max(maxChatCnt-account_data.chatUsedCnt,0))
		obj._chatPayVal = 0
		obj._subStep = 1
	else
		obj._chatPayVal = numDef.chatMsgPrice
		obj._subStep = 0
		obj:egShowWidget(kImgCoin)
		obj:egShowWidget(kLblPayVal)
		obj:egHideWidget(kLblChatCnt)
		obj:egSetBMLabelStr(kLblPayVal,obj._chatPayVal)
		if account_data.jewel < obj._chatPayVal then
			obj:egSetWidgetColor(kLblPayVal,kRedColor)
			obj:egSetWidgetColor(kBtnSend,kGrayColor)
			obj:egSetWidgetTouchEnabled(kBtnSend,false)
		else
			obj:egSetWidgetColor(kLblPayVal,kWhiteColor)
			obj:egSetWidgetColor(kBtnSend,kWhiteColor)
			obj:egSetWidgetTouchEnabled(kBtnSend,true)
		end
	end
end
--��ʾ˽�Ĵ���
function __chatlayer.setPrivateFocused(obj)
	local btnGuild =  tolua.cast(obj:egGetWidgetByName(kBtnGuild),"Button")
	local btnPub = tolua.cast(obj:egGetWidgetByName(kBtnPub),"Button")
	local btnPrivate = tolua.cast(obj:egGetWidgetByName(kBtnPrivate),"Button")
	obj:egSetWidgetColor(kLblPub,kWhiteColor)
	obj:egSetWidgetColor(kLblPrivate,kBrownColor)
	obj:egSetWidgetColor(kLblGuild,kWhiteColor)
	obj:showScaleAction(kImgPrivate,false)
	ChatHelper.setHasPrivateMsg(false)
	obj._focusPart = kMPrivate
	btnGuild:setEnabled(true)
	btnPub:setEnabled(true)
	btnPrivate:setEnabled(false)

	obj:egShowWidget(kListPrivate)
	obj:egShowWidget(kPanelInput)
	obj:egShowWidget(kBtnSend)
	obj:egShowWidget(kImgChatBox)
	obj:egShowWidget(kLblTalkWith)

	obj:egHideWidget(kPanelPay)
	obj:egHideWidget(kListGuild)
	obj:egHideWidget(kListPub)
	obj:egHideWidget(kPanelNoGuild)
	obj:egHideWidget(kBtnIn)
	obj:egHideWidget(kBtnGuildDetail)
	obj:egUnbindWidgetUpdate(kBtnGuild)

	obj:egSetLabelStr(kLblTalkWith,string.format("%s:",obj._privateinfo.talkToName))
	local lblw = obj:egGetWidgetByName(kLblTalkWith):getSize().width - obj._orgLblX/2
	local lblPanelBg = obj:egGetWidgetByName(kPanelChatBg)
	lblPanelBg:setPosition(ccp(obj._orgLblX + lblw,lblPanelBg:getPositionY()))
	lblPanelBg:setSize(CCSizeMake(obj._orgLblW - lblw,lblPanelBg:getSize().height))
	
	local lblImgBg = obj:egGetWidgetByName(kImgChatBox)
	lblImgBg:setPosition(ccp(obj._orgImgX + lblw,lblImgBg:getPositionY()))
	local w = lblImgBg:getSize().width
	lblImgBg:setScaleX((w-math.abs(lblw))/w)

	obj._waterMask = TxtList.promptInput
	obj:egSetLabelStr(kLblChatTxt,obj._waterMask)
	local textField = tolua.cast(obj:egGetWidgetByName(kTfChat),"TextField")
	textField:setText("")
	obj:egSetWidgetColor(kLblChatTxt,kGrayColor)
end
--�л���˽��ģ����ʾ
function __chatlayer.showPrivatePart(obj,userinfo)
    print("guid",userinfo.guid)
	obj._privateinfo.talkToName = userinfo.name
	obj._privateinfo.talkToId = userinfo.guid
	obj._privateinfo.clubid = userinfo.clubid or 0
	obj._privateinfo.clubname = userinfo.clubname or ""
	obj._privateinfo.digLv = userinfo.digLv or 1
	obj:setPrivateFocused()
end
--���ع�����Ϣ���󶨹����б������¼�
function __chatlayer.loadPubMsg(obj)
	if obj._pubinfo.loadedMaxIdx then return end
	obj._pubinfo.loadedMaxIdx = ChatHelper.getPubMsgCnt()
	obj._pubinfo.loadedMinIdx = obj._pubinfo.loadedMaxIdx
	obj._pubinfo.oldH = 0
	obj._pubinfo.loadCnt = 0
	local msglist = obj:egGetListView(kListPub)
	if ChatHelper.hasPubMsg() then
		local msg = ChatHelper.getPubMsg(obj._pubinfo.loadedMaxIdx)
		if msg then obj:showNewPubMsgLbl(msg) end
		ChatHelper.setHasPubMsg(false)
	end
	obj:addPubMsg(msglist,kMaxNum)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = msglist:getInnerContainerSize().height
            if obj._pubinfo.oldH < curH then
                obj:addPubMsg(msglist,kMaxNum)
                obj._pubinfo.oldH = curH
			end
        end
    end
    msglist:addEventListenerScrollView(scrollEvent)
end
--�����������ع�����Ϣ
function __chatlayer.addPubMsg(obj,msglist,num)
	if obj._pubinfo.loadedMinIdx  <= 0 then return end
    if obj._pubinfo.loadCnt >= kMaxCnt then return end
    local startIdx = obj._pubinfo.loadedMinIdx
    local endIdx = math.max(startIdx - num+1,1)
    for idx = startIdx,endIdx,-1 do
        local msgItem = PubMsgItem.new(idx)
		msglist:pushBackCustomItem(msgItem:egNode())
		obj._pubinfo.loadCnt = obj._pubinfo.loadCnt + 1
    end
    obj._pubinfo.loadedMinIdx = endIdx-1
end
--���ع���������Ϣ���󶨹��������б������¼�
function __chatlayer.loadGuildMsg(obj)
	if not club_data then return end
	obj._guildinfo.loadedMaxIdx = ChatHelper.getGuildMsgCnt()
	obj._guildinfo.loadedMinIdx = obj._guildinfo.loadedMaxIdx
	obj._guildinfo.cid = club_data.cid
	obj._guildinfo.oldH = 0
	obj._guildinfo.loadCnt = 0
	local msglist = obj:egGetListView(kListGuild)
	obj:addGuildMsg(msglist,kMaxNum)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = msglist:getInnerContainerSize().height
            if obj._guildinfo.oldH < curH then
                obj:addGuildMsg(msglist,kMaxNum)
                obj._guildinfo.oldH = curH
			end
        end
    end
    msglist:addEventListenerScrollView(scrollEvent)
end
--��--�����������ع����ڲ���Ϣ
function __chatlayer.addGuildMsg(obj,msglist,num)
    if obj._guildinfo.loadedMinIdx  <= 0 then return end
    if obj._guildinfo.loadCnt >= kMaxCnt then return end
    local startIdx = obj._guildinfo.loadedMinIdx
    local endIdx = math.max(startIdx - num+1,1)
    for idx = startIdx,endIdx,-1 do
		local msginfo = ChatHelper.getGuildMsg(idx)
		if (msginfo.type ==3 and not club_data.members[msginfo.guid]) or (msginfo.type==1 and (msginfo.state ~= 0 or club_data.managerID~=account_data.guid)) then
            endIdx = math.max(endIdx-1,1)
		elseif msginfo.type == 1 then
			local msgItem = MsgItem.new(idx)
			msglist:pushBackCustomItem(msgItem:egNode())
			obj._guildinfo.loadCnt = obj._guildinfo.loadCnt + 1
		elseif msginfo.type == 4 then --̽�ն���Ϣ
	        local msgItem = AdventureMsgItem.new(idx)
	        if msgItem:getMsgShow(msgItem) then
	            msglist:pushBackCustomItem(msgItem:egNode())
	            obj._guildinfo.loadCnt = obj._guildinfo.loadCnt + 1
	        end    
		else
			local msgItem = GuildMsgItem.new(idx)
			msglist:pushBackCustomItem(msgItem:egNode())
			obj._guildinfo.loadCnt = obj._guildinfo.loadCnt + 1
		end
    end
    obj._guildinfo.loadedMinIdx = endIdx-1
end
--����Ѽ��صĹ���������Ϣ
function __chatlayer.clearGuildMsgList(obj)
	 local msglist = obj:egGetListView(kListGuild)
     for idx =1,msglist:getChildrenCount() do
        local item = msglist:getItem(idx-1)
        msglist:removeChildByTag(item:getTag(),true)
     end
     msglist:removeAllItems()
     msglist:jumpToTop()
	 obj._guildinfo = {}
end
--����˽����Ϣ����˽���б������¼�
function __chatlayer.loadPrivateMsg(obj)
	if obj._privateinfo.loadedMaxIdx then return end
	obj._privateinfo.loadedMaxIdx = ChatHelper.getPrivateMsgCnt()
	obj._privateinfo.loadedMinIdx = obj._privateinfo.loadedMaxIdx
	obj._privateinfo.oldH = 0
	obj._privateinfo.loadCnt = 0
	if obj._privateinfo.loadedMaxIdx  > 0 then
	    local msginfo = ChatHelper.getPrivateMsg(obj._privateinfo.loadedMaxIdx)
        obj._privateinfo.talkToName = msginfo.name
        obj._privateinfo.talkToId = msginfo.guid
        obj._privateinfo.clubid = msginfo.clubid
        obj._privateinfo.clubname = msginfo.clubname
        obj._privateinfo.digLv = msginfo.digLv
	end
	local msglist = obj:egGetListView(kListPrivate)
	obj:addPrivateMsg(msglist,kMaxNum)
	local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = msglist:getInnerContainerSize().height
            if obj._privateinfo.oldH < curH then
                obj:addPrivateMsg(msglist,kMaxNum)
                obj._privateinfo.oldH = curH
			end
        end
    end
    msglist:addEventListenerScrollView(scrollEvent)
end
--������������˽����Ϣ
function __chatlayer.addPrivateMsg(obj,msglist,num)
	if obj._privateinfo.loadedMinIdx  <= 0 then return end
    if obj._privateinfo.loadCnt >= kMaxCnt then return end
    local startIdx = obj._privateinfo.loadedMinIdx
    local endIdx = math.max(startIdx - num+1,1)
    for idx = startIdx,endIdx,-1 do
        local msgItem = PrivateMsgItem.new(idx)
		msglist:pushBackCustomItem(msgItem:egNode())
		obj._privateinfo.loadCnt = obj._privateinfo.loadCnt + 1
    end
    obj._privateinfo.loadedMinIdx = endIdx-1
end
--�������������ʱ����
function __chatlayer.activeBackReciver(obj)
	--local function callback(delta)
		if ChatHelper.hasPrivateMsg()  or ChatHelper.hasGuildMsg() then
			obj:showScaleAction(kImgNotice,true)
			obj:egUnbindWidgetUpdate(kImgNotice)
		end
	--end
	obj:egUnbindWidgetUpdate(kImgPub)
	obj:egUnbindWidgetUpdate(kImgGuild)
	obj:egUnbindWidgetUpdate(kImgPrivate)
	--obj:egBindWidgetUpdate(kImgNotice,callback)
	obj:onMsgNoticeLoaded()
end

function __chatlayer.showNewPubMsgLbl(obj,msg)
	local imgbg = obj:egGetWidgetByName(kNewMsgBg)
	local msglist = obj:egGetListView(kListPub)
	local txtpanel = obj:egGetWidgetByName(kPanelTxt)
	obj:egSetLabelStr(kLblNewPub, string.format("%s:%s",msg.name,Funs.toUTF(msg.content)))
	imgbg:stopAllActions()
	imgbg:setOpacity(0)
	imgbg:setVisible(true)
	imgbg:setEnabled(true)
	local fadein = CCFadeTo:create(1,255)
	local delay = CCDelayTime:create(10)
	local fadeout = CCFadeOut:create(1)
	local array = CCArray:create()
	array:addObject(fadein)
	array:addObject(delay)
	array:addObject(fadeout)
	local sequence = CCSequence:create(array)
	imgbg:runAction(sequence)
end
--��������Ϣ������
function __chatlayer.activeNewPubReciver(obj)
	local imgbg = obj:egGetWidgetByName(kNewMsgBg)
	local msglist = obj:egGetListView(kListPub)
	local txtpanel = obj:egGetWidgetByName(kPanelTxt)
	local function callback(delta)
		local msg = ChatHelper.getPubMsg(obj._pubinfo.loadedMaxIdx +1)
		if msg then
			obj:showNewPubMsgLbl(msg)
			obj._pubinfo.loadedMaxIdx  = obj._pubinfo.loadedMaxIdx +1
			local msgItem = PubMsgItem.new(obj._pubinfo.loadedMaxIdx)
			msglist:insertCustomItem(msgItem:egNode(),0)
			obj._pubinfo.loadCnt = obj._pubinfo.loadCnt + 1
			ChatHelper.setHasPubMsg(false)
		end
	end
	obj:egBindWidgetUpdate(kNewMsgBg,callback)
end

--������Ϣ����
function __chatlayer.activePubReciver(obj)
    local function callback()
		if obj._focusPart == kMPub and obj._pubinfo.shown then
			obj:showScaleAction(kImgPub,false)
			obj._pubinfo.shown = nil
		elseif obj._focusPart ~= kMPub and ChatHelper.hasPubMsg() and not obj._pubinfo.shown then
			obj:showScaleAction(kImgPub,true)
			obj._pubinfo.shown =true
		end
		local msg = ChatHelper.getPubMsg(obj._pubinfo.loadedMaxIdx +1)
		if msg then
			obj._pubinfo.loadedMaxIdx  = obj._pubinfo.loadedMaxIdx +1
			local msgItem = PubMsgItem.new(obj._pubinfo.loadedMaxIdx)
			local msglist = obj:egGetListView(kListPub)
			msglist:insertCustomItem(msgItem:egNode(),0)
			obj._pubinfo.loadCnt = obj._pubinfo.loadCnt + 1
			ChatHelper.setHasPubMsg(false)
		end
    end
	obj:egBindWidgetUpdate(kImgPub,callback)
end
--�����ڲ���Ϣ����
function __chatlayer.activeGuildReciver(obj)
    local function callback()
		if obj._focusPart == kMGuild and obj._guildinfo.shown then
			obj:showScaleAction(kImgGuild,false)
			obj._guildinfo.shown = nil
		elseif obj._focusPart ~= kMGuild and ChatHelper.hasGuildMsg() and not obj._guildinfo.shown then
			obj:showScaleAction(kImgGuild,true)
			obj._guildinfo.shown = true
		end
		local msginfo = ChatHelper.getGuildMsg(obj._guildinfo.loadedMaxIdx +1)
		if msginfo then
			obj._guildinfo.loadedMaxIdx  = obj._guildinfo.loadedMaxIdx +1
			ChatHelper.setHasGuildMsg(false)
			local msglist = obj:egGetListView(kListGuild)
			if (msginfo.type ==3 and not club_data.members[msginfo.guid]) or (msginfo.type==1 and club_data.managerID~=account_data.guid) then
				return
			elseif msginfo.type == 1 then
				local msgItem = MsgItem.new(obj._guildinfo.loadedMaxIdx)
				msglist:insertCustomItem(msgItem:egNode(),0)
				obj._guildinfo.loadCnt = obj._guildinfo.loadCnt + 1
			elseif msginfo.type ==4 then --̽�ն���Ϣ
	             local msgItem = AdventureMsgItem.new(obj._guildinfo.loadedMaxIdx)
	             msglist:insertCustomItem(msgItem:egNode(),0)
	             obj._guildinfo.loadCnt = obj._guildinfo.loadCnt + 1
			else
				local msgItem = GuildMsgItem.new(obj._guildinfo.loadedMaxIdx)
				msglist:insertCustomItem(msgItem:egNode(),0)
				obj._guildinfo.loadCnt = obj._guildinfo.loadCnt + 1
			end
		end
    end
	if obj._guildinfo.cid and obj._guildinfo.cid == club_data.cid  then
		obj:egBindWidgetUpdate(kImgGuild,callback)
	end
end
--˽����Ϣ����
function __chatlayer.activePrivateReciver(obj)
    local function callback()
		if obj._focusPart == kMPrivate and obj._privateinfo.shown then
			obj:showScaleAction(kImgPrivate,false)
			obj._privateinfo.shown = nil
		elseif obj._focusPart ~= kMPrivate and ChatHelper.hasPrivateMsg() and not obj._privateinfo.shown then
			obj:showScaleAction(kImgPrivate,true)
			obj._privateinfo.shown =true
		end
		local msginfo = ChatHelper.getPrivateMsg(obj._privateinfo.loadedMaxIdx +1)
		if msginfo then
            if not obj._privateinfo.talkToId then
                obj._privateinfo.talkToName = msginfo.name
                obj._privateinfo.talkToId = msginfo.guid
                obj._privateinfo.clubid = msginfo.clubid
                obj._privateinfo.clubname = msginfo.clubname
                obj._privateinfo.digLv = msginfo.digLv
            end
			obj._privateinfo.loadedMaxIdx  = obj._privateinfo.loadedMaxIdx +1
			local msgItem = PrivateMsgItem.new(obj._privateinfo.loadedMaxIdx)
			local msglist = obj:egGetListView(kListPrivate)
			msglist:insertCustomItem(msgItem:egNode(),0)
			obj._privateinfo.loadCnt = obj._privateinfo.loadCnt + 1
			ChatHelper.setHasPrivateMsg(false)
		end
    end
	obj:egBindWidgetUpdate(kImgPrivate,callback)
end

--�����¼�����
function __chatlayer.bindInfoBgListener(obj)
    local lblTxt = obj:egGetWidgetByName(kLblChatTxt)
    local lblbg = obj:egGetWidgetByName(kPanelChatBg)
    local bgsize = lblbg:getSize()
    local txtsize = lblTxt:getSize()
    local y = lblTxt:getPositionY()
    local startX = 0
    local function touchBegan(sender)
        if txtsize.width > bgsize.width then
            startX =sender:getTouchStartPos().x
        end
    end
    local function touchMoved(sender)
        if txtsize.width > bgsize.width then
            local movedX = sender:getTouchMovePos().x - startX
            local oldx = lblTxt:getPositionX()
            local newx = oldx + movedX
            if newx > 0 then newx = 0
            elseif newx < bgsize.width - txtsize.width then newx =  bgsize.width - txtsize.width end
            lblTxt:setPosition(ccp(newx,y))
        end
    end
    local function touchEnded(sender)
         local widget = obj:egGetWidgetByName(kTfChat)
         local textField = tolua.cast(widget,"TextField")
         textField:attachWithIME()
    end
    obj:egBindTouch(kPanelChatBg,touchBegan,touchMoved,touchEnded,nil)
end
function __chatlayer.bindInputListener(obj)
	local lblbg = obj:egGetWidgetByName(kPanelChatBg)
	local lblTxt = obj:egGetWidgetByName(kLblChatTxt)
	local y = lblTxt:getPositionY()
	local size = lblbg:getSize()
    local function textFieldEvent(sender, eventType)
        local textField = tolua.cast(sender,"TextField")
        local text = textField:getStringValue()
        if string.len(text) == 0 then
			obj:egSetLabelStr(kLblChatTxt,obj._waterMask)
            lblTxt:setColor(kGrayColor)
        else
			local utfTxt = Funs.subStr(text,numDef.ChatMsgLen)
			textField:setText(utfTxt)
            obj:egSetLabelStr(kLblChatTxt,utfTxt)
            lblTxt:setColor(kBrownColor)
        end
        if lblTxt:getSize().width > size.width then
			lblTxt:setPosition(ccp(size.width -lblTxt:getSize().width,y))
		else
			lblTxt:setPosition(ccp(0,y))
		end
    end
    local widget = obj:egGetWidgetByName(kTfChat)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent)
end
-- ������Ϣ
function __chatlayer.bindSendMsgListener(obj)
    local function touchEnded(sender)
        local widget = obj:egGetWidgetByName(kTfChat)
		local txtField = tolua.cast(widget,"TextField")
		local lblTxt = obj:egGetWidgetByName(kLblChatTxt)
		local y = lblTxt:getPositionY()
		local info = txtField:getStringValue() or ""
		if string.len(info) > 0 then
			local gbkinfo = Funs.toGBK(info)
            if obj._focusPart == kMPub then
				local clubid = account_data.cid or 0
			    local clubname = account_data.cbName or ""
				 SendMsg[931008](clubid,clubname,gbkinfo)
				 --�ھ���־������̸���,���빫��
				 task.updateTaskStatus(account_data,task.client_event_id.world_talk)
				 ----------------------------------------------------------
				 
				 account_data.jewel = account_data.jewel - obj._chatPayVal
				 account_data.chatUsedCnt = account_data.chatUsedCnt + obj._subStep
				obj:showChatCntInfo()
			elseif obj._focusPart == kMGuild then
			    SendMsg[938008](gbkinfo)
			elseif  obj._focusPart == kMPrivate  then
				local uid = obj._privateinfo.talkToId
				local uname = obj._privateinfo.talkToName
				local diglv = obj._privateinfo.digLv
				local clubid = obj._privateinfo.clubid
				local clubname = obj._privateinfo.clubname
				ChatHelper.addPrivateMsg(0,uid,diglv,uname,clubid,clubname,gbkinfo,os.time())
				local clubid = 0
			    local clubname = ""
			    if club_data then
                    clubid = club_data.cid
                    clubname = club_data.clubName
                end
				SendMsg[931014](uid,clubid,clubname,gbkinfo)
            end
            txtField:setText("")
			obj:egSetLabelStr(kLblChatTxt,obj._waterMask)
			lblTxt:setPosition(ccp(0,y))
            obj:egSetWidgetColor(kLblChatTxt,kGrayColor)
		else
			local pos = sender:getTouchEndPos()
			showPopTxt(obj._waterMask,pos.x,pos.y,ccp(0.5,0.5))
	    end
    end
    obj:egBindTouch(kBtnSend,nil,nil,touchEnded,nil)
end
--��ʾ����������ҳ�����¼�
function __chatlayer.bindShowHideListener(obj)
	local chatbg = obj:egGetWidgetByName(kPanelBg)
    local function touchBegan(sender)
		if obj._shown then
			obj:changeArraw(1,1)
		else
			obj:changeArraw(0,1)
		end
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if obj._shown then
			obj._shown = false
			obj:changeArraw(0,0)
			local imgbg = obj:egGetWidgetByName(kNewMsgBg)
			imgbg:stopAllActions()
			imgbg:setVisible(false)
			imgbg:setEnabled(true)
			SoundHelper.playEffect(SoundList.click_paper_close)
			local desX = -kMoveDis
			if obj._showArrow == false then desX = -kMoveDis-100 end
            local moveto = CCMoveTo:create(0.5,ccp(desX,chatbg:getPositionY()))
			local easeout = CCEaseIn:create(moveto,0.4)
			local function callback()
				sender:setTouchEnabled(true)
				obj:egSetWidgetTouchEnabled(kPanelLayer,false)
				obj:activeBackReciver()
				obj:activeNewPubReciver()
			end
			local callfunc = CCCallFunc:create(callback)
			local sequence = CCSequence:createWithTwoActions(easeout,callfunc)
			chatbg:runAction(sequence)
        else
			obj:changeArraw(1,0)
			SoundHelper.playEffect(SoundList.click_paper_open)
			if obj._clickingCallback then obj._clickingCallback() end
			if not obj._focusPart then obj:setGuildFocused() end
			local moveto = CCMoveTo:create(0.5,ccp(0,chatbg:getPositionY()))
			local easeout = CCEaseIn:create(moveto,0.4)
			local function callback()
				obj._shown = true
				obj:egSetWidgetTouchEnabled(kPanelLayer,true)
				sender:setTouchEnabled(true)
				obj:showScaleAction(kImgNotice,false)
				--obj:egUnbindWidgetUpdate(kImgNotice)
				obj:egHideWidget(kNewMsgBg)
				obj:egUnbindWidgetUpdate(kNewMsgBg)
				obj:activePubReciver()
				obj:activeGuildReciver()
				obj:activePrivateReciver()
			end
            local callfunc = CCCallFunc:create(callback)
			local sequence = CCSequence:createWithTwoActions(easeout,callfunc)
			chatbg:runAction(sequence)
        end
    end
	 local function touchCanceled(sender)
		if obj._shown then
			obj:changeArraw(1,0)
		else
			obj:changeArraw(0,0)
		end
	 end
    obj:egBindTouch(kBtnHide,touchBegan,nil,touchEnded,touchEnded)
end
--������빫�ᳵ��
function __chatlayer.bindGuildDetailListener(obj)
	local function touchEnded(sender)
		sender:setTouchEnabled(false)
		local scene = GuildScene.new()
		scene:egReplace()
    end
	obj:egBindTouch(kBtnGuildDetail,nil,nil,touchEnded,nil)
end
--���������¼�
function __chatlayer.bindPubBtnListener(obj)
    local function touchEnded(sender)
        obj:setPubFocused()
		SoundHelper.playEffect(SoundList.click_paper_open)
    end
    obj:egBindTouch(kBtnPub,nil,nil,touchEnded,nil)
end
--���������¼�
function __chatlayer.bindGuildBtnListener(obj)
    local function touchEnded(sender)
        obj:setGuildFocused()
		SoundHelper.playEffect(SoundList.click_paper_open)
    end
    obj:egBindTouch(kBtnGuild,nil,nil,touchEnded,nil)
end
--˽���¼�
function __chatlayer.bindPrivateBtnListener(obj)
    local function touchEnded(sender)
		if  not obj._privateinfo.talkToId then
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.noListener,pos.x,pos.y,ccp(0.5,0.5))
		else
			obj:setPrivateFocused()
			SoundHelper.playEffect(SoundList.click_paper_open)
		end
    end
    obj:egBindTouch(kBtnPrivate,nil,nil,touchEnded,nil)
end
--���빫�ᰴť�¼�
function __chatlayer.bindEnterListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = GuildScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnIn,nil,nil,touchEnded,nil)
end
function __chatlayer.bindPanelListener(obj)
    local function touchEnded(sender)
		if obj._shown then
			sender:setTouchEnabled(false)
			obj._shown = false
			obj:changeArraw(0,0)
			SoundHelper.playEffect(SoundList.click_paper_close)

			local chatbg = obj:egGetWidgetByName(kPanelBg)
			local desX = -kMoveDis
			if obj._showArrow == false then desX = -kMoveDis-100 end
            local moveto = CCMoveTo:create(0.5,ccp(desX,chatbg:getPositionY()))
			local easeout = CCEaseIn:create(moveto,0.4)
			local function callback()
				obj:activeBackReciver()
				obj:activeNewPubReciver()
			end
			local callfunc = CCCallFunc:create(callback)
			local sequence = CCSequence:createWithTwoActions(easeout,callfunc)

			chatbg:runAction(sequence)
		end
    end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,nil)
end
function __chatlayer.showChatPanel(obj) --��ʾ�������
    local chatbg = obj:egGetWidgetByName(kPanelBg)
    obj:changeArraw(1,0)
	SoundHelper.playEffect(SoundList.click_paper_open)
	if obj._clickingCallback then obj._clickingCallback() end
	if not obj._focusPart then obj:setGuildFocused() end
	local moveto = CCMoveTo:create(0.5,ccp(0,chatbg:getPositionY()))
	local easeout = CCEaseIn:create(moveto,0.4)
	obj:egSetWidgetTouchEnabled(kPanelLayer,true)
	local function callback()
	    obj._shown = true
	    --sender:setTouchEnabled(true)
	    obj:showScaleAction(kImgNotice,false)
	    --obj:egUnbindWidgetUpdate(kImgNotice)
	    obj:egHideWidget(kNewMsgBg)
		obj:egUnbindWidgetUpdate(kNewMsgBg)
		obj:activePubReciver()
		obj:activeGuildReciver()
		obj:activePrivateReciver()
	end
    local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(easeout,callfunc)
	chatbg:runAction(sequence)
end
function __chatlayer.showPanel(obj,isShow)
	local chatbg = obj:egGetWidgetByName(kPanelBg)
	obj._showArrow = isShow
	if isShow then
		chatbg:setPosition(ccp(-kMoveDis,chatbg:getPositionY()))
	else
		chatbg:setPosition(ccp(-kMoveDis-100,chatbg:getPositionY()))
	end
end
function __chatlayer.onClicking(obj,callback)
    obj._clickingCallback = callback
end
function __chatlayer.onMsgNoticeLoaded(obj)
    local function callback(eventName)
		unBindObserver(obj:egNode(),eventName)
		if eventName == kEventChatNotice then
            if ChatHelper.hasPrivateMsg()  or ChatHelper.hasGuildMsg() then
			    obj:showScaleAction(kImgNotice,true)
		    end
		end
	end
    bindObserver(obj:egNode(),callback,kEventGetClubView)
end
function __chatlayer.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
ChatLayer={}
function ChatLayer.new()
    local obj = TouchWidget.new(JsonList.chatLayer)
    table_aux.unpackTo(__chatlayer, obj)
    obj:init()
    obj:bindSendMsgListener()
	obj:bindGuildDetailListener()
    obj:bindInfoBgListener()
	obj:bindInputListener()
    obj:bindShowHideListener()
    obj:bindPubBtnListener() --��������
    obj:bindGuildBtnListener()--�ڲ�����
	obj:bindPrivateBtnListener()--˽��
    obj:bindEnterListener()
	obj:bindPanelListener()
	obj:autoUnbindObserver()
	AccountHelper:bind(kChatLayer,obj)
    return obj
end

local kImgHero = "btn_equip_hero"
local kLblHeroLv = "lbl_hero_lv"
local kImgEquip = "img_item"
local kLblEquipLv = "lbl_lv"
local kImgColor = "img_color_bg"
local kBtnEquip = "btn_equip_bg"
local kPanelStars = "star_list"
local __pubherocard={}
function __pubherocard.init(obj,heroinfo,equiplv,equipqa)
    local heroid = heroinfo.type
	local herolv = heroinfo.lv
	local equipid = heroinfo.eid
	local grade = heroinfo.grade
	obj:egSetWidgetTouchEnabled(kImgHero,false)
	obj:egSetWidgetTouchEnabled(kBtnEquip,false)
    obj:egChangeBtnImg(kImgHero,hero_data[heroid].photo,"","",UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblHeroLv,herolv)
	obj:egSetBMLabelStr(kLblEquipLv,equiplv)
    obj:egChangeImg(kImgEquip,equipCfg[equipid].icon,UI_TEX_TYPE_PLIST)
	obj:egSetWidgetColor(kImgColor,KVariantList.equipColor[equipqa])
	obj:loadHeroGrade(grade)
end
--加载英雄进阶等级
function __pubherocard.loadHeroGrade(obj,grade)
	if not grade then grade = 0 end
	local panel = obj:egGetWidgetByName(kPanelStars)
	for idx=1,panel:getChildrenCount() do
		panel:removeChildByTag(idx,true)
	end
	for idx = 1,grade do
		local img = ImageView:create()
		img:loadTexture(ImageList.star_cato,UI_TEX_TYPE_PLIST)
		panel:addChild(img,1,idx)
	end
end
PubHeroCard = {}
function PubHeroCard.new(heroinfo,equiplv,equipqa)
   local obj ={}
   CocosWidget.install(obj,JsonList.pubHeroCard)
   table_aux.unpackTo(__pubherocard,obj)
   obj:init(heroinfo,equiplv,equipqa)
   return obj
end
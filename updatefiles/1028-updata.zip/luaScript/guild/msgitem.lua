local kBtnAgree = "btn_agree"
local kBtnRefuse = "btn_refuse"
local kPanelLayer = "panel_msg"

local kLblName = "lbl_name"
local kLblChatInfo = "lbl_info"
local kLblTime = "lbl_time"
local kLblLv = "lbl_lv"

local kTxtW = 640
local kTxtH = 31
local kMinH = 95
local __msgItem={}

function __msgItem.init(obj,idx)
   obj._idx = idx
   obj._msg =ChatHelper.getGuildMsg(obj._idx)
   obj:egSetLabelStr(kLblName,obj._msg.name)
   obj:egHideWidget(kLblLv)
   obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",obj._msg.date))
   if obj._msg.state == 0 then
		obj:bindAgreeListener()
		obj:bindRefuseListener()
   else
		obj:loadMsg(obj._msg.state)
   end  
end
function __msgItem.loadMsg(obj,state)
	obj:egHideWidget(kBtnAgree)
	obj:egHideWidget(kBtnRefuse)
	obj:egSetWidgetTouchEnabled(kBtnAgree,false)
	obj:egSetWidgetTouchEnabled(kBtnRefuse,false)
	obj:egNode():ignoreContentAdaptWithSize(false)
	obj:egSetLabelStr(kLblName,TxtList.systemCH)
	local lblInfo = tolua.cast(obj:egGetWidgetByName(kLblChatInfo),"Label")
	lblInfo:setText(string.format(TxtList.guildMsg[state],obj._msg.name))
    local size = lblInfo:getSize()
	local panelsize = obj:egNode():getSize()
    local rows = math.ceil(size.width/kTxtW)
    if rows > 1 then
		local lblh = rows*kTxtH
		lblInfo:setTextAreaSize(CCSizeMake(kTxtW,lblh))
		obj:egNode():setSize(CCSizeMake(panelsize.width,kMinH + (rows-1)* kTxtH))
	else
		obj:egNode():setSize(CCSizeMake(panelsize.width,kMinH))
    end
end
---------ͬ����빫��
function __msgItem.bindAgreeListener(obj) 
    local function touchEnded (sender)
		sender:setTouchEnabled(false)
		if obj._msg.state == 0 then
			SoundHelper.playEffect(SoundList.click_shop_goods)
			obj._msg.state = 1
			obj:loadMsg(obj._msg.state )
			SendMsg[938005](obj._msg._mid,1)
		end
    end
    obj:egBindTouch(kBtnAgree,nil,nil,touchEnded,nil)    
end
  ----------�ܾ����빫��
function __msgItem.bindRefuseListener(obj)
    local function touchEnded (sender)
		sender:setTouchEnabled(false)
		if obj._msg.state == 0 then
			SoundHelper.playEffect(SoundList.click_shop_goods)
			obj._msg.state = 2
			obj:loadMsg(obj._msg.state )
			SendMsg[938005](obj._msg._mid,2)
		end
    end
    obj:egBindTouch(kBtnRefuse,nil,nil,touchEnded,nil)    
end
--������Ϣ����¼�
function __msgItem.bindPanelListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		if obj._msg.state == 0 then
			SoundHelper.playEffect(SoundList.click_shop_goods)
			local function onshown()
				sender:setTouchEnabled(true)
			end
			local pos = sender:getTouchEndPos()
			showChatPopMenu(obj._msg,pos,onshown)
		end
    end
	obj:egSetWidgetTouchEnabled(kPanelLayer,true)
    obj:egBindTouch(kPanelLayer,touchBegan,nil,touchEnd,nil)
end
MsgItem = {}
function MsgItem.new(idx)
   local obj ={}
   CocosWidget.install(obj,JsonList.msgItem)
   table_aux.unpackTo(__msgItem,obj)
   obj:init(idx)
   obj:bindPanelListener()
   return obj
end
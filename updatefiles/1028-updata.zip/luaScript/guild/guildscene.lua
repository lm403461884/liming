local kGuildOrder =0
local __guildscene={}
function __guildscene.init(obj)
    obj._guildlayer = GuildLayer.new()
    obj._guildlayer:egAttachTo(obj,kGuildOrder,kGuildOrder)
	showEmDialog(obj,GuideScene.def.kGuildScene) --����������Ϣ
end

GuildScene={}
function GuildScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__guildscene, obj)
    obj:init()
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
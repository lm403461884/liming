local kLblRank = "lbl_rank"
local kLblClubName = "lbl_club_name"
local kLblElo = "lbl_elo"
local kLblMembersVal = "lbl_members_val"
local kImgItemBg = "img_item_bg"
local kPanelInfo = "panel_info"

local __guilditem={}
function __guilditem.init(obj,d_data,idx)
    obj._d_data = d_data
    obj:egHideWidget(kLblRank)
    obj:egSetLabelStr(kLblClubName,d_data.clubName)
    obj:egSetLabelStr(kLblElo,d_data.elo)
    obj:egSetLabelStr(kLblMembersVal,string.format("%d/%d",d_data.membersCount,50))
    if idx%2 == 1 then
        obj:egHideWidget(kImgItemBg)
    else
        obj:egShowWidget(kImgItemBg)
    end
end
function __guilditem.bindItemListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        local pos = sender:getTouchEndPos()
        if obj._callback then obj._callback(obj._d_data,pos) end
    end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,nil)
end
function __guilditem.onClickedItem(obj,callback)
    if callback then obj._callback = callback end
end
GuildItem = {}
function GuildItem.new(d_data,idx)
   local obj ={}
   CocosWidget.install(obj,JsonList.guildItem)
   BaseProp.install(obj)
   InnerProp.install(obj)
   table_aux.unpackTo(__guilditem,obj)
   obj:init(d_data,idx)
   obj:bindItemListener()
   return obj
end
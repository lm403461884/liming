local kTextName = "text_input_name"
local kTextInfo = "text_input_info"
local kImgNameBg = "img_name_bg"
local kPanelName = "lbl_name_panel"
local kLblName = "lbl_show_name"
local kImgInfoBg = "img_info_bg"
local kBtnSetup = "btn_setup"
local kLblCost = "lbl_cost"
--local kPanelMsg = "msg_layer"
local kLblInfo = "lbl_info"
local kImgLoading = "img_loading"
local kLblDetail1 = "lbl_detail1"

local kMaxTxtLen = 16
--local kNeedGold = 99
local kWhiteColor = ccc3(255,255,255)
local kRedColor = ccc3(255,0,0)
local kGrayColor = ccc3(128,128,128)
kStateSetupGuild = "State_setup_guild"
local kPattenChar="[%p,%c,%s]"
local __setuplayer={}
function __setuplayer.init(obj)
    obj._cost = numDef.clubSetUpGold  --��������۸�
	obj._nameReady = false
    obj:egSetBMLabelStr(kLblCost,obj._cost)
    --obj:egHideWidget(kPanelMsg)
    obj:egHideWidget(kLblDetail1)
    obj:egHideWidget(kImgLoading)
    if account_data.gold<obj._cost then
       obj:egSetWidgetEnabled(kBtnSetup,false)
    end
end
function __setuplayer.bindNameBgListener(obj)
     local function touchEnded(sender)
         local widget = obj:egGetWidgetByName(kTextName)
         local textField = tolua.cast(widget,"TextField")
         textField:attachWithIME()
     end
     obj:egBindTouch(kImgNameBg,nil,nil,touchEnded,nil)
end

function __setuplayer.bindInfoBgListener(obj)
     local function touchEnded(sender)
         local widget = obj:egGetWidgetByName(kTextInfo)
         local textField = tolua.cast(widget,"TextField")
         textField:attachWithIME()
     end
     obj:egBindTouch(kImgInfoBg,nil,nil,touchEnded,nil)
end
function __setuplayer.checkName(obj,textField)
	local txt = textField:getStringValue()
	if string.len(txt) == 0 then
		obj._nameReady = false
		obj:egShowWidget(kLblDetail1)
		obj:egSetLabelStr(kLblDetail1,TxtList.warnNoGuildName)
		obj:egSetLabelStr(kLblName,TxtList.promptGuildInput)
		obj:egSetWidgetColor (kLblName,kGrayColor)    
	else
		local utfTxt = Funs.subStr(txt,kMaxTxtLen)
		textField:setText(utfTxt)
		if string.find(utfTxt,kPattenChar) then
			obj._nameReady = false
			obj:egShowWidget(kLblDetail1)
			obj:egSetLabelStr(kLblDetail1,TxtList.warnGuildNameFormat)
		else
			obj._nameReady = true
			obj:egHideWidget(kLblDetail1)
		end
		obj:egSetLabelStr(kLblName,utfTxt)
		obj:egSetWidgetColor (kLblName,kWhiteColor) 
	end
end
function __setuplayer.bindTextNameListener(obj)
    local function textFieldEvent(sender)
		obj:checkName(tolua.cast(sender,"TextField"))
    end
    local widget = obj:egGetWidgetByName(kTextName)
	local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent)
end
function __setuplayer.bindTextInfoListener(obj)
    local function textFieldEvent(sender)
        local textField = tolua.cast(sender,"TextField")
        local text = textField:getStringValue()
		if string.len(text) == 0  then
			obj:egSetLabelStr(kLblInfo,TxtList.promptMemoInput)
			obj:egSetWidgetColor (kLblInfo,kGrayColor)    
		else
			local utfTxt = Funs.subStr(text,numDef.GuildDescLen)
			textField:setText(utfTxt)
			obj:egSetLabelStr(kLblInfo,utfTxt)
			obj:egSetWidgetColor (kLblInfo,kWhiteColor)    
		end
    end
    local widget = obj:egGetWidgetByName(kTextInfo)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent)
end

function __setuplayer.bindSetupListener(obj) -- ��������
    local function touchEnded(sender)
       SoundHelper.playEffect(SoundList.click_shop_goods)
       if obj._nameReady == false then 
           local nameBg = obj:egGetWidgetByName(kImgNameBg)
			nameBg:stopAllActions()
			nameBg:setColor(kWhiteColor)
			local turnRed = CCTintTo:create(0.2,255,0,0)
			local turnWhite = CCTintTo:create(0.3,255,255,255)
			nameBg:runAction(CCSequence:createWithTwoActions(turnRed,turnWhite))
       else
		   obj:egSetWidgetEnabled(kBtnSetup,false)
		   obj:actionWait()
		   local guild_name = obj:egGetTextFieldVal(kTextName)
		   local guild_info = obj:egGetTextFieldVal(kTextInfo)
		   AccountHelper:lock(kStateSetupGuild)
		   SendMsg[938001](guild_name,guild_info)
		  -- SendMsg[938002]()
		   obj:activeUpdata()
		   account_data.gold = account_data.gold - obj._cost --�ı���
	   end
    end
    obj:egBindTouch(kBtnSetup,nil,nil,touchEnded,nil)
    
end
--��������ȴ�����
function __setuplayer.actionWait(obj)
    obj:egShowWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
end

function __setuplayer.onClicked(obj,callback)
    obj._clickCallback = callback
end

function __setuplayer.activeUpdata(obj)
    local function callback()
        if club_data then   
           if club_data.cid then
               --if obj._clickCallback then obj._clickCallback(3) end
               local imgWidget = obj:egGetWidgetByName(kImgLoading)
               imgWidget:stopAllActions()
               obj:egHideWidget(kImgLoading)
               obj._egObj:unscheduleUpdate()
               
               local scene = GuildScene.new()
               scene:egReplace()
           end    
        end   
        if not AccountHelper:isLocked(kStateSetupGuild) then
           if obj._clickCallback then obj._clickCallback(4) end
           obj:egSetWidgetEnabled(kBtnSetup,true)
           local imgWidget = obj:egGetWidgetByName(kImgLoading)
           imgWidget:stopAllActions()
           obj:egHideWidget(kImgLoading)
           obj._egObj:unscheduleUpdate()
        end
        
    end    
    obj:egBindUpdateWithPriorityLua(callback)
end

SetupLayer={}
function SetupLayer.new()
    local obj = {}
    CocosWidget.install(obj,JsonList.setupLayer)
    table_aux.unpackTo(__setuplayer, obj)
    obj:init()
    obj:bindSetupListener()
    obj:bindTextNameListener()
    obj:bindTextInfoListener()
    obj:bindNameBgListener()
    obj:bindInfoBgListener()
    return obj
end
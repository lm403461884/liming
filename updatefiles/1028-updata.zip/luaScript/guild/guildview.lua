local kLblguildName = "lbl_guild"
local kLblNo = "lbl_no"
local kListMembers = "list_members"
local kImgLoading = "img_loading"
local kImgPrompt = "img_prompt1"
local kImgLongLine = "img_longline1"
local kImgBg = "img_bg"
local kPanelContainer = "panel_container"
local kBtnBack = "btn_back"
local kLblInfo = "lbl_guild_info"
local kLblJoin = "lbl_join"
local kBtnJoin = "btn_join_guild"

local kMaxNum =10

local __guildview={}
function __guildview.init(obj,kind,d_data)
   obj._memberItem={}
   obj._kind = kind
   obj._data = d_data
   obj._oldH=0
   obj:egHideWidget(kImgLoading)
   obj:egHideWidget(kLblNo)
   obj:egHideWidget(kBtnBack)
   obj:egHideWidget(kPanelContainer)
   obj._listview = obj:egGetListView(kListMembers)
    
   obj:onClubDataLoaded()
   if obj._kind == 1 then
         SendMsg[938014](obj._data.guid)
    elseif obj._kind == 2 then
		obj._clubElo = obj._data.elo
         SendMsg[938003](obj._data.name)
         AccountHelper:lock(kStateToViewGuild)
    end 
   obj:activeWaitTimer()	
   obj:showWithAction()
end
function __guildview.activeWaitTimer(obj)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
	imgWidget:setVisible(true)
	imgWidget:setEnabled(true)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
    --[[local function callback()
        if m_clubdata_ready then
            if club_cid[-1] then
				obj:egUnbindWidgetUpdate(kImgLoading)
				obj:egHideWidget(kImgLoading)
				imgWidget:stopAllActions()
                obj._data = club_cid[-1]
                obj:updateMemberReward() --���¹����Ա����
                obj:loadMembers()
                obj:bindScrollListener()
            else
				obj:egUnbindWidgetUpdate(kImgLoading)
				obj:egHideWidget(kImgLoading)
                obj:egShowWidget(kLblNo)
                imgWidget:stopAllActions()
            end
        end   
    end 
    obj:egBindWidgetUpdate(kImgLoading,callback)--]]
end
function __guildview.updateMemberReward(obj)
    for guid,item in pairs(obj._data.members) do
        local reward = clubCalc.memberReward(obj._data.elo,obj._data.coe,item.coe)
        item.reward = reward
    end
end
function __guildview.loadMembers(obj)
   obj:egShowWidget(kPanelContainer) 
   obj:egSetLabelStr(kLblguildName,obj._data.clubName)
   obj:membersOrder(obj._data.members)
   obj:addGuildMembers(kMaxNum,3)
   if obj._maxNum>=kMaxNum then
       obj:egShowWidget(kImgPrompt)
	   obj:egShowWidget(kImgLongLine)
   else
	   obj:egHideWidget(kImgPrompt)
	   --obj:egHideWidget(kImgLongLine)
   end
   obj:egSetLabelStr(kLblInfo,obj._data.clubDesc)
   if club_data or not account_data.train[train.def.guild] then
		obj:egHideWidget(kBtnJoin)
   else
	    obj:egShowWidget(kBtnJoin)
		obj:bindJoinListener()
   end
end
--�����Ա����
function __guildview.membersOrder(obj,members)
    local itemOrder = {}
    obj._guidOrder = {}
    for guid,item in pairs(members) do
        table.insert(itemOrder,item)
    end
    table.sort(itemOrder,function(a,b) return a.elo>b.elo end)
    for _,item in ipairs (itemOrder) do
        table.insert(obj._guidOrder,item.guid)
    end
    obj._maxNum = obj._data.membersCount
    obj._startIdx = 1   
end
--���ع����Ա
function __guildview.addGuildMembers(obj,num,kind)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num-1,obj._maxNum)
    for idx = startIdx,obj._maxNum,1 do
        if idx > endIdx then break end
        local guid = obj._guidOrder[idx]
        local memberItem = GuildMemberItem.new(guid,kind,idx,obj._data)
        obj._memberItem[guid] = memberItem
        obj._listview:pushBackCustomItem(memberItem:egNode())
        obj:bindItemListener(memberItem)
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __guildview.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:cancleBtnLook()
                obj:addGuildMembers(kMaxNum,3)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent)
end
function __guildview.cancleBtnLook(obj)--ȡ��������ť
    if obj._memberItem[obj._selectedGuid] then
         obj._memberItem[obj._selectedGuid]:setFocused(false)
         obj._selectedGuid = nil
    end
end
function __guildview.bindItemListener(obj,memberItem)
    local function callback(begin)
        if begin then
            obj:cancleBtnLook()
        else 
            if obj._selectedGuid then
                obj._memberItem[obj._selectedGuid]:setFocused(false)
                obj._selectedGuid = memberItem:getprop("guid")
            else
                obj._selectedGuid = memberItem:getprop("guid")
            end
        end    
    end
    memberItem:onClickedItem(callback)
end
function __guildview.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    local widget = obj:egGetWidgetByName(kImgBg)
    widget:setPosition(ccp(640,1080))  
	local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(640,360))
    local bounceMove = CCEaseBackOut:create(moveto)
	local spawn = CCSpawn:createWithTwoActions(bounceMove,fadein)
    local function callback()
		if obj._onloaded then obj._onloaded() end
		obj:egShowWidget(kBtnBack)
	end
    local callfunc = CCCallFunc:create(callback)
    local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
    widget:runAction(sequece)
end

function __guildview.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		club_cid = nil
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __guildview.bindJoinListener(obj)
    local function touchEnded(sender)
       SoundHelper.playEffect(SoundList.click_paper_open)
	   sender:setTouchEnabled(false)
       SendMsg[938004](obj._data.cid)
       obj:egSetLabelStr(kLblJoin,TxtList.apllied)
    end
    obj:egBindTouch(kBtnJoin,nil,nil,touchEnded,nil)
end
function __guildview.onClubDataLoaded(obj)
    local function callback(eventName)
		unBindObserver(obj:egNode(),eventName)
		if eventName == kEventGetClubView then
           local imgWidget = obj:egGetWidgetByName(kImgLoading)
            if club_cid[-1] then
				obj:egHideWidget(kImgLoading)
				imgWidget:stopAllActions()
                obj._data = club_cid[-1]
                obj:updateMemberReward() --���¹����Ա����
                obj:loadMembers()
                obj:bindScrollListener()
            else
				obj:egHideWidget(kImgLoading)
                obj:egShowWidget(kLblNo)
                imgWidget:stopAllActions()
            end
		end
	end
    bindObserver(obj:egNode(),callback,kEventGetClubView)
end
function __guildview.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
--kind==1 ����鿴����
--kind==2 ���а�鿴����
GuildView={}
function GuildView.new(kind,d_data,callback)
    local obj = TouchWidget.new(JsonList.guildView)
    table_aux.unpackTo(__guildview, obj)
	obj._onloaded = callback
	obj:init(kind,d_data)
	obj:bindBackListener()
	obj:autoUnbindObserver()
    return obj
end
function ShowGuildView(kind,msg,callback)
    local layer = GuildView.new(kind,msg,callback)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer) 
end

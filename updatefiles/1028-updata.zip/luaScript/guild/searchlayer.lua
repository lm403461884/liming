local kImgName = "img_search_name"
local kTextName = "text_search_name"
local kLblNo = "lbl_search_no"
local kBtnSearch = "btn_search"
local kImgPrompt = "img_prompt1"
local kImgLongLine = "img_longline1"
local kListMembers = "list_members"
local kImgLoading = "img_loading"
local kPanelTouch = "panel_touch_layer"
--local kPanelSearch = "panel_search"

local kBtnMember = "Button_member" --����json�ļ�
local kWhiteColor = ccc3(255,255,255)
local kMaxNum = 8
local kOrderInfo = 2
local kMaxTxtLen = 16
club_show = nil
club_search = nil
local __searchlayer={}
function __searchlayer.init(obj)
    obj:egHideWidget(kLblNo)
    obj._guildInfo = nil
    obj._listview = obj:egGetListView(kListMembers)
    obj._oldH=0
    
    obj._imgWait = obj:egGetWidgetByName(kImgLoading)
    obj:egHideWidget(kImgPrompt) 
    obj:egHideWidget(kImgLongLine)  
    obj:egHideWidget(kListMembers)
    obj:egHideWidget(kImgLoading)
    obj:egHideWidget(kPanelTouch)
    
    if club_show then
        club_search = Funs.copy(club_show)
        obj:loadGuild()
    else
        SendMsg[938016]()
        obj:actionWait()
        obj._clubShow = true
        obj:onClubSearchDataLoaded(kEventClubSearch)
        obj:egSetWidgetTouchEnabled(kBtnSearch,false)
    end    
end

function __searchlayer.bindNameBgListener(obj)
     local function touchEnded(sender)
         local textField = tolua.cast(obj:egGetWidgetByName(kTextName),"TextField")
         textField:attachWithIME()
     end
     obj:egBindTouch(kImgName,nil,nil,touchEnded,nil)
end

function __searchlayer.bindTextNameListener(obj)
    local function textFieldEvent(sender)
        local textField = tolua.cast(sender,"TextField")
        local txt = textField:getStringValue()
		if string.len(txt)>0 then
			local utfTxt = Funs.subStr(txt,kMaxTxtLen)
			textField:setText(utfTxt)
		end
    end
    local widget = obj:egGetWidgetByName(kTextName)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent)
end

function __searchlayer.bindSearchListener(obj) -- ��������
    local function touchEnded(sender)
       SoundHelper.playEffect(SoundList.click_shop_goods)
	   local txt = obj:egGetTextFieldVal(kTextName)
	   if string.len(txt) == 0 then
			local nameBg = obj:egGetWidgetByName(kImgName)
			nameBg:stopAllActions()
			nameBg:setColor(kWhiteColor)
			local turnRed = CCTintTo:create(0.2,255,0,0)
			local turnWhite = CCTintTo:create(0.3,255,255,255)
			nameBg:runAction(CCSequence:createWithTwoActions(turnRed,turnWhite))
	   else
		   obj:egSetWidgetTouchEnabled(kBtnSearch,false)
		   local widget = obj:egGetWidgetByName(kTextName)
		   local textbox = tolua.cast(widget,"TextField")
		   textbox:setText("")
		   club_search = nil
		   obj:onClubSearchDataLoaded(kEventClubSearch)
		   SendMsg[938015](txt)
		   obj:actionWait()
	   end
    end
    obj:egBindTouch(kBtnSearch,nil,nil,touchEnded,nil)
end

--��������ȴ�����
function __searchlayer.actionWait(obj)
    obj:egShowWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
end

function __searchlayer.onClubSearchDataLoaded(obj,name)
    local function callback(eventName)
		unBindObserver(obj:egNode(),eventName)
		if eventName == kEventClubSearch then
           if club_search and not obj._clubShow then
                obj:egSetWidgetTouchEnabled(kBtnSearch,true)
                obj._imgWait:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:removeMembers()
                obj:loadGuild()
            elseif club_search and obj._clubShow then
                obj._clubShow = false
                club_show = Funs.copy(club_search)
                obj._imgWait:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:loadGuild()
                obj:egSetWidgetTouchEnabled(kBtnSearch,true)  
            else
                obj:egSetWidgetTouchEnabled(kBtnSearch,true)
                obj:egShowWidget(kLblNo)
                obj._imgWait:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:egHideWidget(kImgLongLine)
                obj:egHideWidget(kImgPrompt)
                obj:removeMembers()
            end
		end
	end
    if name == kEventClubSearch then  bindObserver(obj:egNode(),callback,kEventClubSearch) end
end
function __searchlayer.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
function __searchlayer.addGuildItem(obj,num)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num -1,obj._maxNum)
    for idx = startIdx,obj._maxNum,1 do
        if idx > endIdx then break end
        local clubprop = club_search[idx]
        local clubitem = GuildItem.new(clubprop,idx)
        obj._listview:pushBackCustomItem(clubitem:egNode())
        obj:bindItemListener(clubitem)
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __searchlayer.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:addGuildItem(kMaxNum)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent)
end
function __searchlayer.bindItemListener(obj,memberItem)
    local function callback(d_data,pos)
        local dataprop = Funs.copy(d_data)
        dataprop.name = dataprop.clubName
        showRankPopMenu(dataprop,pos)
        --obj:egShowWidget(kPanelTouch)
    end
    memberItem:onClickedItem(callback)
end

function __searchlayer.loadGuild(obj)
   obj:egHideWidget(kImgPrompt) 
   obj:egHideWidget(kLblNo)
   obj:egShowWidget(kListMembers)
   obj._startIdx = 1
   obj._maxNum = #club_search
   obj:addGuildItem(kMaxNum)
end

function __searchlayer.removeMembers(obj)
    local listView = obj:egGetListView(kListMembers)
    for idx =1,listView:getChildrenCount() do
        item = listView:getItem(idx-1)
        listView:removeChildByTag(item:getTag(),true)
    end
    listView:removeAllItems()
    listView:jumpToTop()
    if obj._guildInfo then
        obj._guildInfo:egRemoveSelf() 
        obj._guildInfo = nil
    end    
    obj._oldH = 0
end
function __searchlayer.bindPanelListener(obj)--ȡ�������İ�ť
    local function touchBegan()
        local scene = CCDirector:sharedDirector():getRunningScene()
	    scene:removeChildByTag(UILv.popLayer,true)
        obj:egHideWidget(kPanelTouch)
    end
    obj:egBindTouch(kPanelTouch,touchBegan,nil,nil,nil)
end
SearchLayer={}
function SearchLayer.new()
    local obj = {}
    CocosWidget.install(obj,JsonList.searchLayer)
    table_aux.unpackTo(__searchlayer, obj)
    obj:init()
    obj:bindScrollListener()
    obj:bindSearchListener()
    obj:bindTextNameListener()
    obj:bindNameBgListener()
    obj:autoUnbindObserver()
    --obj:bindPanelListener()
    return obj
end
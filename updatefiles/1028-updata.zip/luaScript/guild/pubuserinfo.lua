local kPanelLayer ="img_panel_bg"
local kLblLicence = "lbl_licence"
local kLblElo = "lbl_elo"
local kLblName = "lbl_username"
local kLblClub = "lbl_club"
local kLblAtkCap = "lbl_atkCap"
local kLblDigPt = "lbl_digPt"
local kHeroList = "hero_list"
local kBtnClose = "btn_close"
local kPanleDetail = "detail_panel"
local kImgLoading = "img_loading"
local kLblNote = "lbl_note"
local kCardW = 146
local __pubuserinfo={}

function __pubuserinfo.init(obj,userguid)
    obj._guid = userguid
	obj._userBrief = ChatHelper.getUserBrief(userguid)
	if not obj._userBrief  then
		SendMsg[931009](obj._guid)
	end
	obj:egHideWidget(kLblNote)
	obj:activeWaitTimer()
	obj:showWithAction()
end
function __pubuserinfo.activeWaitTimer(obj)
    obj:egShowWidget(kImgLoading)
    local passed = 0
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
    local function callback(delta)
        passed = passed + delta
		obj._userBrief = ChatHelper.getUserBrief(obj._guid)
		if obj._userBrief then
			obj:egUnbindWidgetUpdate(kImgLoading)
			obj:doLoading()
		elseif passed > numDef.clientTimeOut then
			 obj:egUnbindWidgetUpdate(kImgLoading)
			 imgWidget:stopAllActions()
             obj:egShowWidget(kLblNote)
		end
    end
    obj:egBindWidgetUpdate(kImgLoading,callback)
end
function __pubuserinfo.doLoading(obj)
	local function coFunc()
		obj:loadUserData()
	end
	local coLoad = coroutine.create(coFunc)
	local function callback()
		local f1,f2 = coroutine.resume(coLoad)
		if not f1 then
			obj:egUnbindWidgetUpdate(kImgLoading)
			if type(f2) == "string" then	print(f2) end
		end
	end
	obj:egBindWidgetUpdate(kImgLoading,callback)
end
function __pubuserinfo.loadUserData(obj)
	obj:egHideWidget(kImgLoading)
	obj:egHideWidget(kLblNote)
	obj:egSetBMLabelStr(kLblLicence,obj._userBrief.diglv)
	obj:egSetBMLabelStr(kLblElo,obj._userBrief.elo)
	obj:egSetLabelStr(kLblName,obj._userBrief.nickName)
	
	if obj._userBrief.cid == 0 then
		obj:egSetLabelStr(kLblClub,TxtList.noClub)
	else
		obj:egSetLabelStr(kLblClub,string.format("<%s>",obj._userBrief.cbName))
	end
	obj:egSetLabelStr(kLblDigPt,obj._userBrief.digPt)
	local heroPanel = obj:egGetWidgetByName(kHeroList)
	local teamBp = 0
	local heroCnt = 0
	for key,heroprop in pairs(obj._userBrief.heroList) do
		local equipinfo = obj._userBrief.equipments[heroprop.eid]
		teamBp = teamBp + RiskHelper.getHeroBp(heroprop,obj._userBrief)
		local herocard = PubHeroCard.new(heroprop,equipinfo[1],equipinfo[2])
		heroPanel:addChild(herocard:egNode())
		heroCnt = heroCnt + 1
    end
	local oldw = heroPanel:getSize().width
	local h = heroPanel:getSize().height
	local w = kCardW * heroCnt
	heroPanel:setSize(CCSizeMake(w,h))
	local offsetx = (oldw - w)/2
	heroPanel:setPosition(ccp(heroPanel:getPositionX() + offsetx,heroPanel:getPositionY()))
	
    obj:egSetLabelStr(kLblAtkCap,teamBp)
end
function __pubuserinfo.hideWithAction(obj)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
        if obj._onclosed and not obj._guildLook then obj._onclosed() end
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveBy:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __pubuserinfo.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
	local posx = baseWidget:getPositionX()
	local posy =  baseWidget:getPositionY()
    baseWidget:setPosition(ccp(posx,posy+720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(posx,posy))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    local function callback ()
        if obj._onclosed then obj._onclosed() end
    end    
    local actCallBack = CCCallFunc:create(callback)
    if obj._guildLook then
        local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
        baseWidget:runAction(squence)
    else
        baseWidget:runAction(spawn)
    end    

end
--�ر�����ҳ��
function __pubuserinfo.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,nil)
end
PubUserInfo={}
function PubUserInfo.new(guid,onclosed,guildLook)
   local obj =  TouchWidget.new(JsonList.pubUserInfo)
    table_aux.unpackTo(__pubuserinfo, obj)
    obj._onclosed = onclosed
    if guildLook then obj._guildLook = guildLook end
    obj:init(guid)
    obj:bindCloseListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end
function showPubUserInfo(guid,onclosed,guildLook)
    local layer = PubUserInfo.new(guid,onclosed,guildLook)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
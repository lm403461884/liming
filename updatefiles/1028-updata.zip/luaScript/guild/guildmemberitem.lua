--local kBtnItem = "Button_member"
local kLblLv = "lbl_member_lv"
local kLblName = "lbl_member_name"
local kLblMark = "Label_mark"
local kLblElo = "lbl_elo"
local kLblReward = "lbl_reward_val"
local kLblRank = "lbl_guild_num"
local kLblHonor = "lbl_honor"
local kPanelItem = "panel_member"
local kImgItemBg = "img_item_bg"
local kImgMySelf = "img_myself"
local kImgTopLine = "img_top_line"

local kBtnFire = "btn_fire"
local kImgBtnBg = "img_btn_bg"
local kBtnLook = "btn_look"
local kBtnAppoint = "btn_appoint"

local color1 = ccc3(171,220,245)
local color2 = ccc3(252,151,153)
local kOrderShow = 50
local kCellH = 80
local __guildmemberitem={}
function __guildmemberitem.init(obj,d_data)
    if obj._kind==1 then
        obj._data = club_search
    elseif obj._kind == 3 then
        obj._data = d_data    
    else
        obj._data = club_data
    end
    obj:egSetBMLabelStr(kLblLv,obj._data.members[obj._guid].digLv)
    obj:egSetLabelStr(kLblName,obj._data.members[obj._guid].name)
 
    if obj._data.managerID == obj._guid  then  --�Ƿ�᳤
        obj:egSetLabelStr(kLblMark,TxtList.president)
    else
        obj:egSetLabelStr(kLblMark,TxtList.member)
    end
    obj:egSetLabelStr(kLblRank,obj._rank.."-")
    if obj._data.members[obj._guid].reward and obj._data.members[obj._guid].reward>0 then
        obj:egSetLabelStr(kLblReward,obj._data.members[obj._guid].reward)
    else
        obj:egSetLabelStr(kLblReward,0)
    end  
    local count = obj._rank%2
    obj:egHideWidget(kImgMySelf)
    obj:egHideWidget(kImgTopLine)
    if obj._rank == 1 then obj:egShowWidget(kImgTopLine) end
    if count == 1 then
        obj:egHideWidget(kImgItemBg)
    else
        obj:egShowWidget(kImgItemBg)
    end  
    obj:egSetLabelStr(kLblElo,obj._data.members[obj._guid].elo)
    obj:egSetLabelStr(kLblHonor,obj._data.members[obj._guid].honor)
    obj:addprop("guid",obj._guid)
    obj:addprop("rank",obj._rank)
    obj:egHideWidget(kImgBtnBg)
  
    obj._clickCallback = nil
    obj._filp=false
end
function __guildmemberitem.bindItemListener(obj)
    local function touchBegan(sender)
        if obj._clickedItem then obj._clickedItem(true) end
    end
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        local imgBtnBg = obj:egGetWidgetByName(kImgBtnBg)
        local size = imgBtnBg:getSize()
        if obj._clickedItem then obj._clickedItem()end
        sender:setTouchEnabled(false)
        local newSizeHeight = nil
        if obj._kind == 2 then
            if obj._data.managerID == account_data.guid then
                obj:egShowWidget(kImgBtnBg)
                obj:egHideWidget(kBtnAppoint)
                imgBtnBg:setSize(CCSizeMake(size.width,10+2*kCellH))
                newSizeHeight=10+2*kCellH
            else
                obj:egShowWidget(kImgBtnBg)    
                obj:egHideWidget(kBtnFire)
                obj:egHideWidget(kBtnAppoint)
                imgBtnBg:setSize(CCSizeMake(size.width,10+kCellH))
                newSizeHeight=10+kCellH
            end
        elseif obj._kind ==1 or obj._kind ==3 then
            obj:egShowWidget(kImgBtnBg)    
            obj:egHideWidget(kBtnFire)
            obj:egHideWidget(kBtnAppoint)
            imgBtnBg:setSize(CCSizeMake(size.width,10+kCellH))  
            newSizeHeight=10+kCellH    
        end  
        
        local pointTouch = sender:getTouchEndPos()
        local posx,posy = imgBtnBg:getPosition()
        if pointTouch.y-35 < newSizeHeight and not obj._flip then
            imgBtnBg:setPosition(ccp(posx,posy+newSizeHeight-10))
            obj:egSetImgFlipY(kImgBtnBg,true)
            obj._flip = true
        elseif pointTouch.y-35 < newSizeHeight and obj._flip then
              
        elseif obj._flip then
            imgBtnBg:setPosition(ccp(posx,posy-newSizeHeight+10))
            obj:egSetImgFlipY(kImgBtnBg,false)
            obj._flip = false     
        end 
        
        local parentNode = obj._egObj:getParent()
        parentNode:reorderChild(obj._egObj,kOrderShow)  
    end
    obj:egBindTouch(kPanelItem,touchBegan,nil,touchEnded,nil)
end

function __guildmemberitem.bindLookListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
        local function callback() 
            sender:setTouchEnabled(true)
            obj:setFocused(false)
        end
        showPubUserInfo(obj._guid,callback,true)
    end
    obj:egBindTouch(kBtnLook,nil,nil,touchEnded,nil)    
end

function __guildmemberitem.bindFireListener(obj)
    local function touchEnded()
       if obj._clickCallback then 
          obj._clickCallback(obj)
       end
    end
    obj:egBindTouch(kBtnFire,nil,nil,touchEnded,nil)    
end
function __guildmemberitem.markMyself(obj)
    --obj:egSetWidgetEnabled(kPanelItem,false)
    local widget = obj:egGetWidgetByName(kPanelItem)
    widget:setTouchEnabled(false)
    obj:egShowWidget(kImgMySelf)
    obj:egHideWidget(kImgItemBg)
end
function __guildmemberitem.setFocused(obj,focused)
    if focused then

    else
        obj:egHideWidget(kImgBtnBg)
        local btnItem = obj:egGetWidgetByName(kPanelItem)
        btnItem:setTouchEnabled(true)
        local parentNode = obj._egObj:getParent()
         parentNode:reorderChild(obj._egObj,obj._rank-1)
    end    
end

function __guildmemberitem.setIdx(obj,idx)
    obj:egSetLabelStr(kLblRank,idx..".")
    obj._rank = idx
    obj:setprop("rank",idx)
end
function __guildmemberitem.onClicked(obj,callback) --���
    obj._clickCallback = callback
end
function __guildmemberitem.onClickedItem(obj,callback)
    obj._clickedItem = callback
end
--function __guildmemberitem.onClickedLook(obj,widget,callback)--�鿴������Ϣ����
--    if callback then obj._clickedBtnLook = callback end
--    if widget then obj._guildview = widget end
--end
GuildMemberItem = {}
function GuildMemberItem.new(guid,kind,rank,d_data)--kind=1��������2�������ᣬ3���鿴
   local obj ={}
   CocosWidget.install(obj,JsonList.guildMemberItem)
   BaseProp.install(obj)
   InnerProp.install(obj)
   table_aux.unpackTo(__guildmemberitem,obj)
   obj._guid = guid
   obj._kind = kind
   obj._rank = rank
   obj:init(d_data)
   obj:bindFireListener()
   obj:bindItemListener()
   obj:bindLookListener()
   return obj
end
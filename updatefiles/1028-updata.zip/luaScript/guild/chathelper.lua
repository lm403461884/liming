local __pubMsgList = {} --������Ϣ��
local __guildMsgList = {} --����������Ϣ��
local __privateMsgList = nil --˽����Ϣ��
local __hasGuildMsg = false
local __hasPubMsg = false
local __hasPrivateMsg = false
local __newCreated = false
local __newJoin = false
local __maxNum = 20
local __msgKey = {"recvmsg","guid","name","digLv","clubid","clubname","content","date"}
local __rid = 0 --��ǰ�Ѽ�¼��˽�ļ�¼��
local __userBriefs = {}
ChatHelper = {}
--��ȡ������Ϣ����
function ChatHelper.getPubMsgCnt()
	return #__pubMsgList
end
--��ȡ����������Ϣ����
function ChatHelper.getGuildMsgCnt()
	return #__guildMsgList
end
--��ȡ˽����Ϣ����
function ChatHelper.getPrivateMsgCnt()
	return #__privateMsgList
end
--��ȡ������Ϣ
function ChatHelper.getPubMsg(idx)
	return __pubMsgList[idx]
end
--��ȡ������Ϣ
function ChatHelper.getGuildMsg(idx)
	return __guildMsgList[idx]
end
--��ȡ������Ϣidx
function ChatHelper.getGuildMsgIdx(mid)
    for idx,item in ipairs(__guildMsgList) do
        if item._mid == mid then
            return idx
        end
    end
    return nil
end
--��ȡ˽����Ϣ
function ChatHelper.getPrivateMsg(idx)
	return __privateMsgList[idx]
end
--�Ƿ��й�����Ϣ
function ChatHelper.hasGuildMsg()
	return __hasGuildMsg
end
--�Ƿ��й�����Ϣ
function ChatHelper.hasPubMsg()
	return __hasPubMsg
end
--�Ƿ���˽����Ϣ
function ChatHelper.hasPrivateMsg()
	return __hasPrivateMsg
end
--�Ƿ����´����ɹ��Ĺ���
function ChatHelper.isNewCreated()
	return __newCreated
end
--�Ƿ��Ǹ��������Ĺ���
function ChatHelper.isNewJoin()
	return __newJoin
end
--���ù�����Ϣ��ʶ
function ChatHelper.setHasGuildMsg(has)
	__hasGuildMsg = has
end
--���ù�����Ϣ��ʶ
function ChatHelper.setHasPubMsg(has)
	__hasPubMsg = has
end
--���ù�����Ϣ��ʶ
function ChatHelper.setHasPrivateMsg(has)
	__hasPrivateMsg = has
end
--�����¹����ʶ
function ChatHelper.setNewCreated(isnew)
	__newCreated = isnew
end
--�����¼����ʶ
function ChatHelper.setNewJoin(isnew)
	__newJoin = isnew
end
--��ȡ��ǰ�鿴���û���Ϣ���
function ChatHelper.getUserBrief(userguid)
	if userguid == account_data.guid then
		local tb = {}
		tb.diglv = account_data.digLv
		tb.elo = account_data.elo
		tb.nickName = account_data.nickName
		tb.digPt = account_data.maxDigPt
		tb.cid = account_data.cid or 0
		tb.cbName = account_data.cbName or ""
		tb.heroList={}
		tb.equipments ={}
		for key,heroid in ipairs(account_data.team) do
			local heroprop = account_data.heroList[heroid]
			tb.heroList[heroid] = heroprop
			tb.equipments[heroprop.eid] = account_data.equipments[heroprop.eid]
		end
		return tb
	else
		if __userBriefs[userguid] and os.time() -  __userBriefs[userguid].refreshTime < 2 then
			return __userBriefs[userguid]
		else
			return nil
		end
	end
end
--�޸ĵ�ǰ�鿴���û���Ϣ
function ChatHelper.addUserBrief(userbrief)
	__userBriefs[userbrief.guid] = userbrief	
end
--�����µĹ�����Ϣ
function ChatHelper.addPubMsg(userguid,digLv,name,clubid,clubname,content,m_date)
	local newmsg = {}
	newmsg.guid = userguid
	newmsg.name = name
	newmsg.digLv = digLv
	newmsg.date = m_date or os.time()
	newmsg.clubid = clubid
	newmsg.clubname = clubname
	newmsg.content = content
	for key,pubmsg in ipairs(__pubMsgList) do
		if pubmsg.guid == userguid then
			pubmsg.digLv = digLv
			pubmsg.clubid = clubid
			pubmsg.clubname = clubname
		end
	end
	if newmsg.date > account_data.lastOffline then
		__hasPubMsg = true
	end
	table.insert(__pubMsgList,newmsg)
end
--�����µĹ��������¼
function ChatHelper.addGuildMsg(msgtype,mid,uid,content,state,name,m_date,cur,limit)
	if not club_data then print("not club")  return end --û����������ֱ�ӷ���
	if msgtype == 3 and not club_data.members[uid] then print("not member") return end
	if msgtype == 1 and club_data.managerID~=account_data.guid then return end
	local newmsg = {}
	newmsg.type = msgtype
	newmsg._mid = mid
	newmsg.guid = uid
	newmsg.content = content
	newmsg.state = state
	newmsg.name = name
	newmsg.date = m_date or os.time()
	newmsg.cur = cur 
	newmsg.limit = limit 
	if newmsg.date > account_data.lastOffline then
		__hasGuildMsg = true
		postEventSignal(kEventChatNotice)
	end
    table.insert(__guildMsgList,newmsg)	
end
function ChatHelper.reOrderGuildMsg()
	if __guildMsgList then
		table.sort(__guildMsgList,function(a,b) return a._mid < b._mid end)
	end
end
--���¹���̽�ն���Ϣ��¼
function ChatHelper.updateGuildMsg(msgtype,mid,count)
    local idx = ChatHelper.getGuildMsgIdx(mid)
    if not idx then print("not find mid:",mid) return end
    
    local msginfo = __guildMsgList[idx]
    if count and not msginfo.cbTeamDissolved then
        msginfo.cur = count
        print("msg count:",count)
    else
        msginfo.cbTeamDissolved = true
    end    
end

--�����µ�˽�ļ�¼
--msgtype 0���͵���Ϣ 1���յ�����Ϣ

function ChatHelper.addPrivateMsg(msgtype,uid,diglv,uname,clubid,clubname,content,m_date)
	local newmsg = {}
	newmsg.recvmsg = msgtype
	newmsg.guid = uid
	newmsg.name = uname
	newmsg.digLv = diglv
	newmsg.clubid = clubid
	newmsg.clubname = clubname
	newmsg.content = content
	newmsg.date = m_date or os.time()

	if newmsg.date > account_data.lastOffline then
		__hasPrivateMsg = true
		postEventSignal(kEventChatNotice)
	end
	table.insert(__privateMsgList,newmsg)
	ChatHelper.savePrivateMsg(newmsg)
end
function ChatHelper.clearGuildMsg(obj)
	__guildMsgList = {}
	__hasGuildMsg = false
end
function ChatHelper.PrivateMsgParse(msgStr)
	msgStr = HOAux:hexstr2str(msgStr)
	local tb = {}
	local keyIdx = 0
	local startIdx = 1
	local endIdx = string.find(msgStr,",")
	while endIdx do
		keyIdx = keyIdx+1
		if keyIdx == 3 or keyIdx==6 or keyIdx==7 then
			tb[__msgKey[keyIdx]] =  HOAux:hexstr2str(string.sub(msgStr,1,endIdx-1))
			
		else
			tb[__msgKey[keyIdx]] = tonumber(string.sub(msgStr,1,endIdx-1))
		end
		msgStr =string.sub(msgStr,endIdx+1)
		endIdx = string.find(msgStr,",")
	end
	return tb
end
function ChatHelper.loadPrivateMsg()
	if not __privateMsgList then
		local chatKey = account_data.guid
		local noKey = string.format("%dNO",chatKey)
		__privateMsgList = {}
		__rid = CCUserDefault:sharedUserDefault():getIntegerForKey(noKey)
		for idx = 1,__maxNum do
			local readStr = CCUserDefault:sharedUserDefault():getStringForKey(string.format("%dof%d",chatKey,idx))
			if  string.len(readStr) > 0 then
				table.insert(__privateMsgList, ChatHelper.PrivateMsgParse(readStr))
			else
				local readStr = CCUserDefault:sharedUserDefault():getStringForKey(chatKey..idx)
				if  string.len(readStr) > 0 then
					table.insert(__privateMsgList, ChatHelper.PrivateMsgParse(readStr))
				else
					break
				end
			end
		end
		table.sort(__privateMsgList,function(a,b) return a.date<b.date end)
	end
end
--�洢˽����Ϣ
function ChatHelper.savePrivateMsg(msgInfo)
	local saveStr = ""
	local chatKey = account_data.guid
	local noKey = string.format("%dNO",chatKey)
	__rid = __rid+1
	for key,val in ipairs(__msgKey) do
	    if key == 3 or key==6 or key==7 then
	        saveStr = string.format("%s%s,",saveStr,HOAux:str2hexstr(msgInfo[val]))
	    else
		    saveStr = string.format("%s%s,",saveStr,tostring(msgInfo[val]))
		end
	end
	CCUserDefault:sharedUserDefault():setStringForKey(string.format("%dof%d",chatKey,__rid),HOAux:str2hexstr(saveStr))
	if __rid>=__maxNum then __rid = 0 end
	CCUserDefault:sharedUserDefault():setIntegerForKey(noKey,__rid)
	CCUserDefault:sharedUserDefault():flush()
	
end
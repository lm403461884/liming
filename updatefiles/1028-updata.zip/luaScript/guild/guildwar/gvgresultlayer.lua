local kLblAtkResult = "lbl_atk_result"
local kLblAtkGuild = "lbl_atk_name"
local kLblAtkHonor = "lbl_honor_val1"
local kLblAtkStars = "lbl_atk_stars"
local kBarAtk = "bar_atk_consume"

local kLblDefResult = "lbl_def_result"
local kLblDefGuild = "lbl_def_name"
local kLblDefHonor = "lbl_honor_val2"
local kLblDefStars = "lbl_def_stars"
local kBarDef = "bar_def_consume"

local kPanelLayer = "Panel_result"
local kBtnBack = "btn_back"
local kLblReturn = "lbl_return"
local kLblReturns = "lbl_return_s"
local kPanelInfo = "info_panel"
local kPanelWait = "wait_panel"
local kImgLoading = "img_load"
local kLblSearch = "lbl_search"
local kGvgPrompt = 5
local kEndWarFlag = 1

local __gvgresultlayer = {}

function __gvgresultlayer.init(obj)
	obj._loadState = 0
	obj:showWaitPanel()
	obj:bindWaitTimer()
    obj:showWithAction(obj._callback)
end
function __gvgresultlayer.showWaitPanel(obj)
	obj:egHideWidget(kPanelInfo)
	obj:egShowWidget(kPanelWait)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
	local rotateby = CCRotateBy:create(1,360)
	local repeatforever2 = CCRepeatForever:create(rotateby)
	imgWidget:runAction(repeatforever2) 
end
function __gvgresultlayer.showWarResult(obj)
	
	obj._d_data = club_data.lastWarResult
    obj:egSetLabelStr(kLblAtkGuild,obj._d_data.atkName)
    obj:egSetLabelStr(kLblDefGuild,obj._d_data.defName)
    obj:egSetLabelStr(kLblAtkStars,obj._d_data.atkSumStars)
    obj:egSetLabelStr(kLblDefStars,obj._d_data.defSumStars)
    obj:egSetLabelStr(kLblAtkHonor,obj._d_data.atkEloDlt)
    obj:egSetLabelStr(kLblDefHonor,obj._d_data.defEloDlt)
    if obj._d_data.atkEloDlt >= obj._d_data.defEloDlt then
       obj:egSetLabelStr(kLblAtkResult,"WIN!")
       obj:egSetLabelStr(kLblDefResult,"LOSE")
    else
       obj:egSetLabelStr(kLblAtkResult,"LOSE")
       obj:egSetLabelStr(kLblDefResult,"WIN!")
    end
   
   local to1 = math.floor((obj._d_data.atkSumStars/(numDef.cbWarMaxTargets*numDef.starsPerStage))*100)
   local to2 = math.floor((obj._d_data.defSumStars/(numDef.cbWarMaxTargets*numDef.starsPerStage))*100)
   obj:runStarProgress(to1,to2)
   --����Ѿ���ʾս���������棬�����������ϲ�����ʾ
   if obj._kind ~= 1 and #account_data.prompList > 0 then
		for key,promptItem in ipairs(account_data.prompList) do
			if promptItem.type == kGvgPrompt and promptItem.data.type == kEndWarFlag then
				table.remove(account_data.prompList,key)
			end
		end
   end
end
function __gvgresultlayer.bindWaitTimer(obj)
	--�Ƚ�������
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if club_data and club_data.lastWarResult then
            obj:egUnbindWidgetUpdate(kLblSearch)
			local imgWidget = obj:egGetWidgetByName(kImgLoading)
			imgWidget:stopAllActions()
			obj:egHideWidget(kPanelWait)
			obj:egShowWidget(kPanelInfo)
			
			obj:showWarResult()
			obj._loadState = 1
        elseif not club_data or passed >numDef.clientTimeOut then
            obj:egUnbindWidgetUpdate(kLblSearch)
            local imgWidget = obj:egGetWidgetByName(kImgLoading)
			imgWidget:stopAllActions()
			obj:egSetLabelStr(kLblSearch,TxtList.warGetResultFailed)
			obj._loadState = -1
         end
	end
	obj:egBindWidgetUpdate(kLblSearch,callback)
end
function __gvgresultlayer.runStarProgress(obj,to1,to2)
    local from = 0
    local function callbackFunc()
        from = from + 1
        if from >= to1 then 
            obj:egSetBarPercent(kBarAtk,to1)
        else
            obj:egSetBarPercent(kBarAtk,from)  
        end
        if from>=to2 then
            obj:egSetBarPercent(kBarDef,to2)
        else
            obj:egSetBarPercent(kBarDef,from)
        end
        if from>=to1 and from >=to2 then obj:egUnbindWidgetUpdate(kBarAtk) end
    end
    obj:egBindWidgetUpdate(kBarAtk,callbackFunc)
end

function __gvgresultlayer.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequence)
    else
        baseWidget:runAction(spawn)
    end
end

--�뿪
function __gvgresultlayer.bindBackListener(obj)
    local function touchEnded(sender)
         obj:egSetWidgetTouchEnabled(kBtnOk,false)
		 SoundHelper.playEffect(SoundList.click_paper_close)
		 if obj._kind == 1 then
			if obj._loadState < 0 then
				 local scene = GuildScene.new()
				scene:egReplace()
			else
				obj:egRemoveSelf()
			end
		 else
	         local scene = TownScene.new()
		     scene:egReplace()
		 end    
    end
     obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end

GvgResultLayer={}
function GvgResultLayer.new(kind,callback)--kind==1 ��ʾ�鿴
    local obj = TouchWidget.new(JsonList.gvgResultLayer)
    table_aux.unpackTo(__gvgresultlayer,obj)
    obj._kind = kind or 0
    if callback then obj._callback = callback end
    obj:init()
    obj:bindBackListener()
    return obj
end
function showGvgResultLayer(kind,callback)
    local layer = GvgResultLayer.new(kind,callback)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
local kImagStar = {"star_1","star_2","star_3"}
local kBtnHole = "btn_hole"
local kLblAtk = "lbl_atk"
local kLblAtks = "lbl_atk_s"
local kLblDef = "lbl_def"
local kLblDefs = "lbl_def_s"
local kImgAtk = "img_atk"
local kImgFlag = "img_flag"
local __gvgmission = {}
function __gvgmission.init(obj,holeinfo,u_guid,isAttacker,isEmemy)
    obj._isAttacker= isAttacker
	obj._guid = u_guid
    obj._isEmemy = isEmemy
	obj._holeinfo = holeinfo
	obj:egSetLabelStr(kLblDef,obj._holeinfo.nickName)
	obj:egSetLabelStr(kLblDefs,obj._holeinfo.nickName)
	if obj._holeinfo.atkerName == "" then
		obj:egHideWidget(kLblAtk)
		obj:egHideWidget(kLblAtks)
		obj:egHideWidget(kImgAtk)
	else
		obj:egSetLabelStr(kLblAtk,obj._holeinfo.atkerName)
		obj:egSetLabelStr(kLblAtks,obj._holeinfo.atkerName)
	end
	if obj._isAttacker then
		obj:egChangeImg(kImgFlag,ImageList.icon_war_atk,UI_TEX_TYPE_PLIST)
	else
		obj:egChangeImg(kImgFlag,ImageList.icon_war_def,UI_TEX_TYPE_PLIST)
	end
	if obj._isEmemy then
		obj:egChangeBtnImg(kBtnHole,ImageList.btn_flag_r_n,ImageList.btn_flag_r_s,ImageList.btn_flag_d,UI_TEX_TYPE_PLIST)
	else
		obj:egChangeBtnImg(kBtnHole,ImageList.btn_flag_g_n,ImageList.btn_flag_g_s,ImageList.btn_flag_d,UI_TEX_TYPE_PLIST)
	end
	for idx = 1,obj._holeinfo.stars do
		obj:egChangeImg(kImagStar[idx],ImageList.star,UI_TEX_TYPE_PLIST)
	end
	if obj._isEmemy and obj._holeinfo.stars>=numDef.starsPerStage then
		obj:egSetWidgetEnabled(kBtnHole,false)
	end
	obj:bindStarTimer()
end
function __gvgmission.bindStarTimer(obj)
	local old_stars = obj._holeinfo.stars
	local function callback()
		if not club_data or not club_data.warData then
			obj:egUnbindWidgetUpdate(kImgFlag) 
			obj:egSetWidgetEnabled(kBtnHole,false)
		elseif club_data and club_data.warData then
			if old_stars ~= obj._holeinfo.stars then
				old_stars = obj._holeinfo.stars 
				for idx = 1,obj._holeinfo.stars do
					obj:egChangeImg(kImagStar[idx],ImageList.star,UI_TEX_TYPE_PLIST)
				end
				if old_stars >= numDef.starsPerStage then
					obj:egUnbindWidgetUpdate(kImgFlag) 
					if obj._isEmemy then obj:egSetWidgetEnabled(kBtnHole,false) end
				end
			end
		end
	end
	obj:egBindWidgetUpdate(kImgFlag,callback)
end
function __gvgmission.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_open)
        local function callback()
			sender:setTouchEnabled(true)
		end
		if club_data and club_data.warData and club_data.warData.expire > os.time() then
			if obj._isEmemy  then
				if  account_data.actPt < numDef.actPtForClubPvp then
					local txt = string.format("%s %d",TxtList.needActPt,numDef.actPtForClubPvp)
					local pos = sender:getTouchEndPos()
					showPopTxt(txt,pos.x,pos.y,ccp(0.5,0.5))
					sender:setTouchEnabled(true)
				else
					if club_data.members[account_data.guid].atkCount > 0 then
						
						local scene = CCDirector:sharedDirector():getRunningScene()
						if scene:getChildByTag(UILv.popLayer) then
							sender:setTouchEnabled(true)
						else
							showGvgPreview(obj._guid ,callback)
						end
					else
						--��ʾ��������������	
						local pos = sender:getTouchEndPos()
						showPopTxt(TxtList.warNoAtkCount,pos.x,pos.y,ccp(0.5,0.5))
						sender:setTouchEnabled(true)
					end
				end
			else
				local scene = CCDirector:sharedDirector():getRunningScene()
				if scene:getChildByTag(UILv.popLayer) then
					sender:setTouchEnabled(true)
				else
					showPubUserInfo(obj._guid,callback)
				end
			end	
		else
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.warHasOver,pos.x,pos.y,ccp(0.5,0.5))
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnHole,nil,nil,touchEnded,touchCanceled)
end
GvgMission={}
function GvgMission.new(holeinfo,u_guid,isAttacker,isEmemy)
    local obj = {}
    CocosWidget.install(obj,JsonList.gvgMission)
    table_aux.unpackTo(__gvgmission, obj)
    obj:init(holeinfo,u_guid,isAttacker,isEmemy)
    obj:bindClickListener()
    return obj
end
local kLblAtkName = "lbl_atk_name"
local kLblAtkMembers = "lbl_atk_members"
local kLblAtkNum = "lbl_atk_num"

local kLblDefName = "lbl_def_name"
local kLblDefMembers = "lbl_def_members"
local kLblDefNum = "lbl_def_num"
local kListView = "listview_video"
local kBtnEnter = "btn_enter"
local kImgLine = "img_longline"
local kImgPrompt = "img_prompt"
local kLblNoVideo = "lbl_no_video"
local kPanelWait = "wait_panel"
local kImgLoading = "loading"
local kImgAtkNameBg = "img_name_atk"
local kImgDefNameBg = "img_name_def"

local kLoadNum = 5
local kholdNum =20 --¼����Ч����

local __gvgenterlayer={}
function __gvgenterlayer.init(obj)
    obj._atk_data = club_data.warData.cb_atk
    obj._def_data = club_data.warData.cb_def
    obj:egSetLabelStr(kLblAtkName,obj._atk_data.clubName)
    obj:egSetLabelStr(kLblAtkMembers,obj._atk_data.membersCount)
    obj:egSetLabelStr(kLblAtkNum,string.format("%d/%d",obj._atk_data.sumAtkCount,obj._atk_data.membersCount*2))
    
    obj:egSetLabelStr(kLblDefName,obj._def_data.clubName)
    obj:egSetLabelStr(kLblDefMembers,obj._def_data.membersCount)
    obj:egSetLabelStr(kLblDefNum,string.format("%d/%d",obj._def_data.sumAtkCount,obj._def_data.membersCount*2))
    --if obj._atk_data.cid == club_data.cid then
    --    obj:egChangeImg(kImgAtkNameBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST) 
	--	obj:egChangeImg(kImgDefNameBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST)
    --end
    obj:egSetImgFlipX(kImgDefNameBg,true)
    obj:egHideWidget(kLblNoVideo)
    obj:egHideWidget(kPanelWait)
    if club_data.battleSumaries and #club_data.battleSumaries > 0 then
        obj:loadVideoItem()
        if #club_data.battleSumaries> 2 then
            obj:egShowWidget(kImgLine)
            obj:egShowWidget(kImgPrompt)
        else
            obj:egHideWidget(kImgLine)
            obj:egHideWidget(kImgPrompt)    
        end
    else
        obj:egShowWidget(kLblNoVideo)
        obj:egHideWidget(kImgLine)
        obj:egHideWidget(kImgPrompt)
    end
end

function __gvgenterlayer.loadVideoItem(obj)
    obj._listview = obj:egGetListView(kListView)
    obj._atkNum = 0
    obj._defNum = 0
    local totalCnt = #club_data.battleSumaries
    local endCnt = math.max(totalCnt-kholdNum+1,1)
    for idx = totalCnt,endCnt,-1 do
        if not club_data.battleSumaries[idx].isDefencer and obj._atkNum < 5 then
            local gvgItem = GvgVideoItem.new(idx)
            obj._atkNum = obj._atkNum +1
            obj:bindGvgItemClickEvent(gvgItem)
            obj._listview:pushBackCustomItem(gvgItem:egNode())
        end
    end 
    for idx = totalCnt,endCnt,-1 do
        if club_data.battleSumaries[idx].isDefencer and obj._defNum < 5 then
            local gvgItem = GvgVideoItem.new(idx)
            obj._defNum = obj._defNum + 1
            obj:bindGvgItemClickEvent(gvgItem)
            obj._listview:pushBackCustomItem(gvgItem:egNode())
        end
        
    end 
end
function __gvgenterlayer.bindWarCounter(obj)
	local function callback(delta)
        if club_data and not club_data.warData and club_data.lastWarResult then
           obj:egUnbindWidgetUpdate(kBtnEnter) 
		   obj:egSetWidgetTouchEnabled(kBtnEnter)
		   showGvgResultLayer(0) --��ʾ���㴰��
        end
    end
    obj:egBindWidgetUpdate(kBtnEnter,callback)
end
function __gvgenterlayer.bindGvgItemClickEvent(obj,gvgItem)--video���Żص�����
    local function callback(sender)
		local vid = sender:getItemIdx()
		if videomanager.getwarvideo(vid) then
		    VideoDetail = videomanager.getwarvideoDetail(vid)
			local scene = ReplayPvpScene.new()
			scene:egReplace()
		else
			obj:activeDetailTimer(vid)
		end
	end
	gvgItem:onClicked(callback)
end
--¼����Ϣ��ϸ��ȡ��ʱ��
function __gvgenterlayer.activeDetailTimer(obj,gvgItemIdx)
	local passedTime = 0
	obj:egShowWidget(kPanelWait)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
	AccountHelper:lock(kStateWarVideo)
	SendMsg[9311008](gvgItemIdx)
	local  function callback(delta)
		passedTime = passedTime + delta
			if not  AccountHelper:isLocked(kStateWarVideo) then
				obj:egUnbindWidgetUpdate(kPanelWait)
				if videomanager.getwarvideo(gvgItemIdx) then
					VideoDetail = videomanager.getwarvideoDetail(gvgItemIdx)
					local scene = ReplayPvpScene.new()
					scene:egReplace()
				else
					--¼�����ݲ�����
					MsgLayer.new(nil,TxtList.inValidVideo,1,nil):show()
				end
			elseif passedTime > numDef.clientTimeOut then
				obj:egUnbindWidgetUpdate(kPanelWait)
				imgWidget:stopAllActions()
				postEventSignal(kEventRequestTimeOut)
			end
	end
	obj:egBindWidgetUpdate(kPanelWait,callback)
end
function __gvgenterlayer.bindEnterListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
		if club_data and club_data.warData then
			local scene = GvgMissionScene.new()
			scene:egReplace()
		else
			local function callback()
				local scene = GuildScene.new()
				scene:egReplace()
			end
			local msglayer = MsgLayer.new(nil,TxtList.warHasOver,1,callback)
			msglayer:show()
		end
    end
    obj:egBindTouch(kBtnEnter,nil,nil,touchEnded,nil)
end

GvgEnterLayer={}
function GvgEnterLayer.new()
    local obj = {}
    CocosWidget.install(obj,JsonList.gvgenterLayer)
    table_aux.unpackTo(__gvgenterlayer, obj)
    obj:init()
    obj:bindEnterListener()
	obj:bindWarCounter()
    return obj
end
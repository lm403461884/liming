
local kBtnLook = "btn_look"
local kBtnStart = "btn_start"
local kImgProtect = "img_protect"
local kLblTime = "lbl_time"

local kPanelTxt = "txt_panel"

local __gvgsearchlayer={}
function __gvgsearchlayer.init(obj)
    if club_data.guardSt > os.time() then
        obj:egSetBMLabelStr(kLblTime,Funs.formatTime(club_data.guardSt - os.time()))
        obj:bindCounterTimer()
    else
        obj:egHideWidget(kImgProtect)
    end
	if club_data.lastWarResult then
		obj:egShowWidget(kBtnLook)
    else
        obj:egHideWidget(kBtnLook)
		--local btn = obj:egGetWidgetByName(kBtnStart)
		--btn:setPosition(ccp(btn:getPositionX(),btn:getPositionY() - btn:getSize().height/2))
    end   
	obj:loadWarDesc()
end
function __gvgsearchlayer.loadWarDesc(obj)
	local cnt = #clubWarDesc
	local panel = obj:egGetScrollView(kPanelTxt)
	panel:setTouchEnabled(true)
	panel:setBounceEnabled(true)
	local totalH = 0
	local layouttype = panel:getLayoutType()
	local w = panel:getSize().width
	for idx = 1,cnt do
		local txtInfo = clubWarDesc[idx]
		local lbl = Label:create()
		lbl:setText(txtInfo.txt)
		lbl:setFontSize(txtInfo.fontSize or 24)
		if txtInfo.fontName then lbl:setFontName(txtInfo.fontName) end
		if txtInfo.color then lbl:setColor(ccc3(txtInfo.color[1],txtInfo.color[2],txtInfo.color[3])) end
		
		local lblW = lbl:getSize().width
		local lblH = lbl:getSize().height
		
		if lblW >= w then
			local rows = math.ceil(lblW/w) + 1
			lblW = w
			lblH = rows*lblH
			lbl:setTextAreaSize(CCSizeMake(lblW,lblH))
		else
			lbl:setTextAreaSize(CCSizeMake(w,lblH))
			lbl:setTextHorizontalAlignment(txtInfo.align or 0)
		end
		panel:addChild(lbl,0,idx)
		local layoutparameter = lbl:getLayoutParameter(layouttype)
		layoutparameter:setMarginTo(0,txtInfo.margin_top or 0,0,txtInfo.margin_bottom or 0)
		lbl:setLayoutParameter(layoutparameter)
		totalH = totalH + lblH
	end
	panel:setInnerContainerSize(CCSizeMake(w,totalH))
end
--����ʱ�䵹��ʱ
function __gvgsearchlayer.bindCounterTimer(obj)
    local function callback()
        if club_data.guardSt > os.time() then
            obj:egSetBMLabelStr(kLblTime,Funs.formatTime(club_data.guardSt - os.time()))
        else
            obj:egUnbindWidgetUpdate(kLblTime)   
            obj:egHideWidget(kImgProtect) 
        end
    end
    obj:egBindWidgetUpdate(kLblTime,callback)
end
--��������ս
function __gvgsearchlayer.bindStartListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
		local function callback2()
			 sender:setTouchEnabled(true)
		end
		local function callback1()
			showGvgClubSearch(callback2)
		end
		if club_data then
			if club_data.warData then  --�ѿ���ս��
				local scene = GvgMissionScene.new()
				scene:egReplace()
			elseif club_data.membersCount < numDef.cbWarMinMembers then
				--�������������ܿ���ս��
				local msglayer =  MsgLayer.new(nil,string.format(TxtList.warMemberShort,numDef.cbWarMinMembers),1,callback2,nil)
				msglayer:show()
			elseif club_data.guardSt > os.time() then
				if club_data.managerID == account_data.guid then
					--��ʾ��ս����������״̬��ͬ����ս����ͬ���򷵻�
					local msglayer =  MsgLayer.new(nil,TxtList.warStopProtect,2,callback1,callback2)
					msglayer:show()
				else
					--����״̬�����ܿ���ս��
					local msglayer =  MsgLayer.new(nil,TxtList.warInProtect,1,callback2,nil)
					msglayer:show()
				end
			else
				showGvgClubSearch(callback2)
			end
		else
			obj:showNoClub()
		end
        
    end
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,nil)
end
function __gvgsearchlayer.showNoClub(obj)
	--û�й��ᣬ����ʹ�ù���ս��ع���
	local function callback()
		local scene = GuildScene.new()
		scene:egReplace()
	end
	local msglayer =  MsgLayer.new(nil,TxtList.warNotJoinClub,1,callback,nil)
	msglayer:show()
end
function __gvgsearchlayer.bindLookListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
		local function callback()
			sender:setTouchEnabled(true)
		end
        if club_data then
			--�򿪹���ս��ʷ�������
			showGvgResultLayer(1,callback)
		else
			obj:showNoClub()
		end
    end
    obj:egBindTouch(kBtnLook,nil,nil,touchEnded,nil)
end
GvgSearchLayer={}
function GvgSearchLayer.new()
    local obj = {}
    CocosWidget.install(obj,JsonList.gvgSearchLayer)
    table_aux.unpackTo(__gvgsearchlayer, obj)
    obj:init()
    obj:bindStartListener()
    obj:bindLookListener()
    return obj
end
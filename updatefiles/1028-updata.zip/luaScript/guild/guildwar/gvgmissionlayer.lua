--local kBarTime = "bar_time" --ս������ʱ
local kLblTime = "lbl_time"
--������
local kLblAtkClub = "lbl_club_atk"
--local kLblAtkClubs = "lbl_club_atk_s"
local kLblAtkNum = "lbl_num_atk"
local kLblAtkStar = "lbl_star_atk"
local kBarAtkStar = "bar_atk"
local kImgAtkFlag = "img_flag_atk"
--���ط�
local kLblDefClub = "lbl_club_def"
--local kLblDefClubs = "lbl_club_def_s"
local kLblDefNum = "lbl_num_def"
local kLblDefStar = "lbl_star_def"
local kBarDefStar = "bar_def"
local kImgDefFlag = "img_flag_def"

local kBtnBack = "btn_back"
local kPanelMap = "map_panel"
local kImgMap = "img_war_map"
local kImgPanel = "img_panel"
local kImgBack = "img_back"

local kLblAtkCnt = "lbl_atkCnt_num"

local __gvgmissionlayer = {}
function __gvgmissionlayer.init(obj)
	if not club_data or not club_data.warData then
		local scene = TownScene.new()
		scene:egReplace()
	else
		obj._atkClub =  club_data.warData.cb_atk
		obj._defClub = club_data.warData.cb_def
		obj._atk_oldSumCnt = obj._atkClub.sumAtkCount
		obj._def_oldSumCnt = obj._defClub.sumAtkCount
		obj._atk_oldStar = obj._atkClub.sumStars
		obj._def_oldStar = obj._defClub.sumStars
		--���ؽ���������
		obj:egSetLabelStr(kLblAtkClub,obj._atkClub.clubName)
		--obj:egSetLabelStr(kLblAtkClubs,obj._atkClub.clubName)
		obj:egSetLabelStr(kLblAtkStar,obj._atk_oldStar)
		obj:egSetLabelStr(kLblAtkNum,string.format("%d%s%d",obj._atk_oldSumCnt,"/",obj._atkClub.membersCount*numDef.cbWarAtkCount))
		obj:egSetBarPercent(kBarAtkStar,math.floor(obj._atk_oldStar *100/(numDef.cbWarMaxTargets*numDef.starsPerStage)))
		--���ط��ط�����
		obj:egSetLabelStr(kLblDefClub,obj._defClub.clubName)
		--obj:egSetLabelStr(kLblDefClubs,obj._defClub.clubName)
		obj:egSetLabelStr(kLblDefStar,obj._defClub.sumStars)
		obj:egSetLabelStr(kLblDefNum,string.format("%d%s%d",obj._def_oldSumCnt,"/",obj._defClub.membersCount*numDef.cbWarAtkCount))
		obj:egSetBarPercent(kBarDefStar,math.floor(obj._def_oldStar*100/(numDef.cbWarMaxTargets*numDef.starsPerStage)))
		obj:bindCounterTimer()
		obj._isAtkEmemy = true
		if obj._atkClub.cid == club_data.cid then
			--obj:egSetImgFlipX(kImgPanel,true)
			obj._isAtkEmemy = false
		end
		obj:loadAtkMissionData()
		obj:loadDefMissionData()
		local usedCnt = math.max(numDef.cbWarAtkCount-club_data.members[account_data.guid].atkCount,0)
		obj:egSetLabelStr(kLblAtkCnt,string.format("%d%s%d",usedCnt,"/",numDef.cbWarAtkCount))
		local mapsize = obj:egGetWidgetByName(kImgMap):getSize()
		local panel = obj:egGetScrollView(kPanelMap)
		local outersize = panel:getSize()
		if outersize.height < mapsize.height then
			panel:setInnerContainerSize(CCSizeMake(mapsize.width,mapsize.height))
			panel:scrollToBottom(0.5,true)
		end
	end
end
--ս��ʱ�䵹��ʱ
function __gvgmissionlayer.bindCounterTimer(obj)
    local function callback()
        if club_data and club_data.warData then
			if club_data.warData.expire > os.time() then
				obj:egSetLabelStr(kLblTime,Funs.formatTime(club_data.warData.expire - os.time()))
				if obj._atk_oldSumCnt~= obj._atkClub.sumAtkCount then
					obj._atk_oldSumCnt = obj._atkClub.sumAtkCount 
					obj:egSetLabelStr(kLblAtkNum,string.format("%d%s%d",obj._atk_oldSumCnt,"/",obj._atkClub.membersCount*numDef.cbWarAtkCount))
				end
				if obj._atk_oldStar~=obj._atkClub.sumStars then
					obj._atk_oldStar=obj._atkClub.sumStars
					obj:egSetLabelStr(kLblAtkStar,obj._atk_oldStar)
					obj:egSetBarPercent(kBarAtkStar,math.floor(obj._atk_oldStar *100/(obj._atkClub.membersCount*numDef.starsPerStage)))
				end
				
				if obj._def_oldStar ~=obj._defClub.sumStars then
					obj._def_oldStar =obj._defClub.sumStars
					obj:egSetLabelStr(kLblDefStar, obj._def_oldStar)
					obj:egSetBarPercent(kBarDefStar,math.floor(obj._def_oldStar*100/(obj._defClub.membersCount*numDef.starsPerStage)))
				end
				if obj._def_oldSumCnt ~= obj._defClub.sumAtkCount then
					obj._def_oldSumCnt = obj._defClub.sumAtkCount
					obj:egSetLabelStr(kLblDefNum,string.format("%d%s%d",obj._def_oldSumCnt,"/",obj._defClub.membersCount*numDef.cbWarAtkCount))
				end
			else
				obj:egUnbindWidgetUpdate(kLblTime) 
				club_data.lastWarResult = nil		
				showGvgResultLayer(0) --��ʾ���㴰��
			end
        else 
           obj:egUnbindWidgetUpdate(kLblTime) 
		   showGvgResultLayer(0) --��ʾ���㴰��
        end
    end
    obj:egBindWidgetUpdate(kLblTime,callback)
end
function __gvgmissionlayer.loadAtkMissionData(obj)
	local panelmap = obj:egGetWidgetByName(kImgMap)
	local tb = {}
	for key,_ in pairs(obj._atkClub.targets) do
		table.insert(tb,key)
	end
	table.sort(tb,function(a,b) return obj._atkClub.targets[a].elo < obj._atkClub.targets[b].elo  end)
	for idx,u_guid in ipairs(tb) do
		local holeinfo = obj._atkClub.targets[u_guid]
		local missionitem = GvgMission.new(holeinfo,u_guid,true,obj._isAtkEmemy)
		panelmap:addChild(missionitem:egNode())
		local pos = warItemPosCfg.atk[idx]
		missionitem:egSetPosition(pos[1],pos[2])
	end
end
function __gvgmissionlayer.loadDefMissionData(obj)
	local panelmap = obj:egGetWidgetByName(kImgMap)
	local tb = {}
	for key,_ in pairs(obj._defClub.targets) do
		table.insert(tb,key)
	end
	table.sort(tb,function(a,b) return obj._defClub.targets[a].elo < obj._defClub.targets[b].elo  end)
	for idx,u_guid in ipairs(tb) do
		local holeinfo = obj._defClub.targets[u_guid]
		local missionitem = GvgMission.new(holeinfo,u_guid,false,not obj._isAtkEmemy)
		panelmap:addChild(missionitem:egNode())
		local pos = warItemPosCfg.def[idx]
		missionitem:egSetPosition(pos[1],pos[2])
	end
end
--�󶨷��ذ���������
function __gvgmissionlayer.bindBackListener(obj)
    local function touchBegan()
        obj:egSetWidgetScale(kImgBack,1.1)
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egSetWidgetScale(kImgBack,1)        
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --����
		local scene = GuildScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
	    obj:egSetWidgetScale(kImgBack,1)  
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,touchBegan,nil,touchEnded,touchCanceled)
end 
GvgMissionlayer={}
function GvgMissionlayer.new()
    local obj = TouchWidget.new(JsonList.gvgMissionLayer)
    table_aux.unpackTo(__gvgmissionlayer, obj)
    obj:init()
    obj:bindBackListener()
    return obj
end
local kTypeImg = {[0]=ImageList.pve_atk,[1]=ImageList.pve_dfs}--��������ͼƬ��Դ����0:������1������
--local kPanelAward = "award_panel"
local kImgPvpType = "pvp_type_img"
--local kLabelUserType = "pvp_user_lbl"
--local kLabelUserName = "lbl_user_name"
local kLabelElo = "lbl_elo"
local kLblAtkName = "lbl_atk_name"
local kLblDefName = "lbl_def_name"
local kLabelTime = "time_lbl"
local kBtnPlay = "play_btn"
local kPanelHero = "hero_list"
local kLabelState = "lbl_state"
local kImgStamp = "img_stamp"
local kRedColor = ccc3(128,0,0)
local kGreenColor = ccc3(0,128,0)
local __gvgvideoitem={}
function __gvgvideoitem.init(obj,idx)
    obj._idx = idx
    obj._videoinfo = club_data.battleSumaries[obj._idx]
    obj._vid = obj._videoinfo.vid
	--for idx,coinname in pairs(KVariantList.coinType) do
	--	obj._videoinfo[string.format("def_%s",coinname)] = -(obj._videoinfo[string.format("atk_%s",coinname)] or 0)
	--end
    obj._ptime = Funs.formatTimeCh(os.time() -  obj._videoinfo.time,true,true,true,nil,true)
    if  obj._videoinfo.isDefencer then
		obj:loadDefInfo()
		obj:loadHeros( obj._videoinfo.hero,true)
	else
		obj:loadAtkInfo()
		obj:loadHeros( obj._videoinfo.hero,false)
	end
end
function __gvgvideoitem.loadAward(obj,atkflag)
    local panel = obj:egGetWidgetByName(kPanelAward)
    local eloaward = AwardItem.new("elo",Funs.signedNum(obj._videoinfo[string.format("%s_%s",atkflag,"elo")]))
    panel:addChild(eloaward:egNode())
    for idx,coinname in pairs(KVariantList.coinType) do
        local coinval = obj._videoinfo[string.format("%s_%s",atkflag,coinname)] or 0
        if coinval~=0 then
            local awarditem = AwardItem.new(coinname,Funs.signedNum(coinval))
            panel:addChild(awarditem:egNode())
        end
    end
end
--Ϊ������ʱ��¼������
function __gvgvideoitem.loadAtkInfo(obj)
	obj:egChangeImg(kImgPvpType,ImageList.pve_atk,UI_TEX_TYPE_PLIST)
	--obj:loadAward("atk")
	obj:egSetLabelStr(kLabelElo,obj._videoinfo.atk_elo)
    obj:egSetLabelStr(kLabelTime,string.format("%s%s",obj._ptime,TxtList.ago))
	--obj:egSetLabelStr(kLabelUserType,TxtList.defUserTxt)
	--obj:egSetLabelStr(kLabelUserName,obj._videoinfo.defName)
	obj:egSetLabelStr(kLblDefName,obj._videoinfo.defName)
	obj:egSetLabelStr(kLblAtkName,obj._videoinfo.atkName)
	if obj._videoinfo.stars > 0 then
		obj:egSetWidgetColor(kLabelState,kGreenColor)
		obj:egSetWidgetColor(kImgStamp,kGreenColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.succTxt))
	else
		obj:egSetWidgetColor(kLabelState,kRedColor)
		obj:egSetWidgetColor(kImgStamp,kRedColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.atkTxt,TxtList.failTxt))
	end
end
--Ϊ���ط�ʱ��¼������
function __gvgvideoitem.loadDefInfo(obj)
	obj:egChangeImg(kImgPvpType,ImageList.pve_dfs,UI_TEX_TYPE_PLIST)
	--obj:loadAward("def")
	obj:egSetLabelStr(kLabelElo,obj._videoinfo.atk_elo)
    obj:egSetLabelStr(kLabelTime,string.format("%s%s",obj._ptime,TxtList.ago))
	--obj:egSetLabelStr(kLabelUserType,TxtList.atkUserTxt)
	--obj:egSetLabelStr(kLabelUserName, obj._videoinfo.atkName)
	obj:egSetLabelStr(kLblDefName,obj._videoinfo.defName)
	obj:egSetLabelStr(kLblAtkName,obj._videoinfo.atkName)
	if obj._videoinfo.stars == 0 then
		obj:egSetWidgetColor(kLabelState,kGreenColor)
		obj:egSetWidgetColor(kImgStamp,kGreenColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.succTxt))
	else
		obj:egSetWidgetColor(kLabelState,kRedColor)
		obj:egSetWidgetColor(kImgStamp,kRedColor)
		obj:egSetLabelStr(kLabelState,string.format("%s%s",TxtList.defTxt,TxtList.failTxt))
	end
end
function __gvgvideoitem.getValTxt(obj,val)
	local txt = math.abs(val)
	if val > 0 then txt = string.format("+%s",txt)
	elseif val <0 then txt = string.format("-%s",txt) end
	return txt
end
function __gvgvideoitem.loadHeros(obj,herolist,isememy)
	local listview =obj:egGetListView(kPanelHero)
    for heroid,herolv in pairs(herolist)do
        local heroHead  = HeroHead.new(heroid,herolv,isememy)
        listview:pushBackCustomItem(heroHead:egNode())
    end
end
--��ȡ��ƵID
function __gvgvideoitem.getItemIdx(obj)
	return obj._vid
end
function __gvgvideoitem.onClicked(obj,callback)
	obj._clickCallback = callback
end
function __gvgvideoitem.bindPlayListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_shop_goods)  --�����Ŀ
       obj:egSetWidgetTouchEnabled(kBtnPlay,false)
       if obj._clickCallback then obj._clickCallback(obj) end
    end
    obj:egBindTouch(kBtnPlay,nil,nil,touchEnded,nil)
end

GvgVideoItem={}
function GvgVideoItem.new(idx)
    local obj = {}
    CocosWidget.install(obj,JsonList.gvgVideoItem)
    table_aux.unpackTo(__gvgvideoitem, obj)
    obj:init(idx)
    obj:bindPlayListener()
    return obj
end

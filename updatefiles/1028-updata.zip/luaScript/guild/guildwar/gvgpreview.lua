local kLblTitle = "lbl_title"
local kImgStar={"img_star_full_1","img_star_full_2","img_star_full_3"}
local kLblHard = "lbl_degree"
local kLblAtk = "lbl_atk"
local kLblAtkVal = "lbl_atk_val"
local kPanelHero = "hero_list"
local kPanelAward1 = "panel_award1"
local kPanelAward2 = "panel_award2"
local kLblActPt = "lbl_c_act"
local kImgActPt = "img_c_act"
local kPanelBtn = "btn_panel"
local kBtnStart = "btn_start"
local kBtnBack = "btn_back"
local kImgBg = "img_bg"
local kLblTimeRes = "lbl_time_res"
local kLblPromp = "lbl_promp"

local kPanelLayer = "panel_gvg_pre"
local kPanelInfo = "info_panel"
local kPanelWait = "wait_panel"

local kImgLoading = "img_loading"
local kLblPrepare = "lbl_prepare"
local kLblNoMatch = "lbl_nomatch"
local kLblSearch = "lbl_search"
local kImgLoadBar = "img_bar"
local kImgFight = "img_fight"
local kImgArea = "img_area"
local kPanelMonster = "monster_list"
--Ӣ��ѡ��
local kPanelSelect = "img_hero_select_bg"
local kHeroList = "scrollview"
local kImgMark = "img_mark"
local kLblChangHero = "lbl_change_hero"
local kBtnChangeHero = "btn_change_hero"

local kCellW = 110
local kCellW1 = 150
local kCellH = 160
local kMaxMonster = 5
local kWaitTime = 30 --����ʱ30��
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)

local __gvgpreview={}
function __gvgpreview.init(obj,guid)
	obj._guid = guid
	obj._oldTeam = Funs.copy(account_data.team)
	AccountHelper:lock(kStateWarHole)
	SendMsg[9311002](obj._guid)
	obj:egHideWidget(kPanelInfo)
	obj:showWaitPanel()
    obj:showWidthAction()
end
--��ʾ�ȴ�����
function __gvgpreview.showWaitPanel(obj,show)
	obj:egShowWidget(kPanelWait)
	local widget1 = obj:egGetWidgetByName(kImgFight)
	local scaleto1 = CCScaleTo:create(1,1.3)
	local scaleto2 = CCScaleTo:create(1,1.5)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatforever1 = CCRepeatForever:create(sequence)
	widget1:runAction(repeatforever1)
        
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
	local rotateby = CCRotateBy:create(1,360)
	local repeatforever2 = CCRepeatForever:create(rotateby)
	imgWidget:runAction(repeatforever2) 
	obj:bindLoadTimer()
end
--ֹͣ�ͷŵȴ�����
function __gvgpreview.stopWaitAct(obj)
	local widget1 = obj:egGetWidgetByName(kImgFight)
    local widget2 = obj:egGetWidgetByName(kImgLoading)
    widget1:stopAllActions()
    widget2:stopAllActions()
end
--�����ݼ��صȴ���ʱ��
function __gvgpreview.bindLoadTimer(obj)
	local passed = 0
    local  function callback(delta)
		passed = passed + delta
        if not  AccountHelper:isLocked(kStateWarHole) and passed >= numDef.searchInterval then
            obj:egUnbindWidgetUpdate(kLblPrepare)
			obj:stopWaitAct()
			if clubpvpacct_data then
				 obj:egHideWidget(kPanelWait)
				 obj:showPreView()
			else
				obj:egHideWidget(kLblPrepare)
				obj:egHideWidget(kImgLoading)
				obj:egHideWidget(kImgLoadBar)
				obj:egShowWidget(kLblNoMatch)
				obj:egSetLabelStr(kLblNoMatch,TxtList.playerInWar)
				obj:egSetLabelStr(kLblSearch,TxtList.pvpSearchEnd)
			end
        else
            if passed >= numDef.clientTimeOut then
                obj:egUnbindWidgetUpdate(kLblPrepare)
                obj:stopWaitAct()
				postEventSignal(kEventRequestTimeOut)
            end
         end
    end
    obj:egBindWidgetUpdate(kLblPrepare,callback)
end
function __gvgpreview.showPreView(obj)
	obj:egShowWidget(kPanelInfo)
	obj:egHideWidget(kPanelSelect)
	obj:egHideWidget(kHeroList)
	obj:egSetWidgetTouchEnabled(kPanelInfo,false)
	--Ŀǰ�Ѿ����������
	for idx = 1,clubpvpacct_data.lastStars do
		obj:egShowWidget(kImgStar[idx])
	end
	local pic = scene_data[clubpvpacct_data.sceneID].thumbPic
    obj:egChangeImg(kImgArea,pic,UI_TEX_TYPE_PLIST)
    
	obj:egSetLabelStr(kLblTitle,clubpvpacct_data.user)
	obj:egSetLabelStr(kLblHard,clubpvpacct_data.digLv)
	if account_data.digLv >= clubpvpacct_data.digLv then obj:egSetWidgetColor(kLblHard,kBrownColor) end
	obj:loadHeros()
	obj:loadMonsters()
	obj:loadAward()
	obj._passedTime = 0
	obj:activeTimeUpdate()
	obj:egSetBMLabelStr(kLblActPt,numDef.actPtForClubPvp)
	obj:egSetLabelStr(kLblAtkVal,RiskHelper.getTeamBp())
end
--���ع���
function __gvgpreview.getMonsters(obj)
    local tb = {}
    for pos,monsterid in pairs(clubpvpacct_data.creatureList) do
        if not tb[monsterid] then tb[monsterid] = 1 
        else tb[monsterid] = tb[monsterid] + 1 end
    end
    return tb
end
function __gvgpreview.loadMonsters(obj)
    local monsters = obj:getMonsters()
    local panel =obj:egGetWidgetByName(kPanelMonster)
    local cnt = 0
    for monsterid,num in pairs(monsters) do
		cnt = cnt + 1
        local monsterHead = MonsterHead.new(monsterid,num,clubpvpacct_data)
        panel:addChild(monsterHead:egNode())
		if cnt >= kMaxMonster then break end
    end
    local size = panel:getSize()
    local neww = cnt*kCellW
	panel:setPosition(ccp((size.width - neww)/2 + panel:getPositionX(),panel:getPositionY()))
    panel:setSize(CCSizeMake(neww,size.height))
end
--����Ӣ��ͷ���С��ս����
function __gvgpreview.loadHeros(obj)
    obj._teamheroitem = {}
    local panel  = obj:egGetWidgetByName(kPanelHero)
	for idx = 1,account_data.maxTeam do
		local heroid = account_data.team[idx] or 0
		local herolv = 0
		if heroid > 0 then herolv = account_data.heroList[heroid].lv end
		local heroHead = ExpeditionItem.new(heroid,nil,herolv)
		heroHead:setItemTouchEnabled(false)
		table.insert(obj._teamheroitem,heroHead)
		 panel:addChild(heroHead:egNode())
		if heroid > 0 then
			obj:teamMemberClicked(heroHead)
		end
	end
	local neww = account_data.maxTeam * kCellW1
	local size = panel:getSize()
	if size.width > neww then
		panel:setPosition(ccp((size.width - neww )/2*panel:getScale() + panel:getPositionX(),panel:getPositionY()))
		panel:setSize(CCSizeMake(neww,size.height))
	end
end
--���ؽ�����Ϣ
function __gvgpreview.loadAward(obj)
    local tb={} 
	tb.gold,tb.jewel,tb.iron,tb.copper,tb.stoneR,tb.stoneB,tb.stoneD,tb.honor= baseCalc.SocietyWarPrize(account_data,3,clubpvpacct_data.lastStars,clubpvpacct_data.digLv)
    local panel1 = obj:egGetWidgetByName(kPanelAward1)
	local panel2 = obj:egGetWidgetByName(kPanelAward2)
	local panel1size = panel1:getSize()
	local panel2size = panel2:getSize()
	local actW1 = 0
	local actW2 = 0
	local loadCnt = 0
	 for key,val in pairs(tb) do
        if val~=0 then
            local awarditem = AwardItem.new(key,string.format("%s%d",TxtList.numSymbol,val))
			local item_w = awarditem:egNode():getSize().width
			loadCnt = loadCnt + 1
			if loadCnt<=2 then
				 actW1 = actW1 + item_w
				 panel1:addChild(awarditem:egNode())
				 if actW1 > panel1size.width then
				     panel1:setScale(panel1size/actW1)
				 end
			else
				actW2 = actW2 + item_w
				panel2:addChild(awarditem:egNode())
				if actW2 > panel2size.width then
				     panel2:setScale(panel2size.width/actW2)
				end
			end
        end
    end
end

--ȡ��С��Ӣ��
function __gvgpreview.removeTeamHero(obj,heroid,posx,posy)
    if #account_data.team == 1 then
        showPopTxt(TxtList.teamEmpty,posx,posy,ccp(0.6,0.6))
    else
		panel=obj:egGetWidgetByName(kPanelHero)
        for idx,Theroid in ipairs(account_data.team) do
            if Theroid == heroid then
                table.remove(account_data.team,idx)
                 panel:removeChild(obj._teamheroitem[idx]:egNode(),true)
                table.remove(obj._teamheroitem,idx)
                local heroHead = ExpeditionItem.new(0)
                table.insert(obj._teamheroitem,heroHead)
                panel:addChild(heroHead:egNode())
                obj._heroitem[heroid]:showJoinFlag(false)
           end
       end
	   local teamCap = obj:getTeamAtkCap()--����С��ս����
       obj:egSetLabelStr(kLblAtkVal,teamCap)
    end   
end
--����С��Ӣ��
function __gvgpreview.insertTeamHero(obj,heroid)
    table.insert(account_data.team,heroid)
	local heroitem = obj._teamheroitem[#account_data.team]
	heroitem:updateHeroInfo(heroid,nil,account_data.heroList[heroid].lv)
	heroitem:setItemTouchEnabled(true)
	obj:teamMemberClicked(heroitem)
    local teamCap = RiskHelper.getTeamBp()--����С��ս����
    obj:egSetLabelStr(kLblAtkVal,teamCap)
end
--���С��Ӣ��
function __gvgpreview.teamMemberClicked(obj,heroHead)
    local function callback(sender,posx,posy)
        local heroid = sender:getprop("heroid")
        obj:removeTeamHero(heroid,posx,posy)
    end
    heroHead:onItemClicked(callback)
end
--��ʾӢ��ѡ�����
function __gvgpreview.showPanelSelect(obj)
	obj:egShowWidget(kPanelSelect)
	obj:egShowWidget(kHeroList)
	if obj._selected then return end
    obj._selected = true
    obj._heroitem = {}
    local herolist = obj:egGetScrollView(kHeroList)
    local size = herolist:getSize()
    local heroAtkList = obj:getHeroAtkOrder()
    local maxRow = math.ceil(#heroAtkList/2)
    local newH = maxRow * kCellH
    if newH> size.height then
        herolist:setInnerContainerSize(CCSizeMake(size.width,newH))
    else
        newH = size.height    
    end
	herolist:jumpToTop()
    for idx,item in ipairs (heroAtkList) do
        local heroid = item[1]
        local heroitem = ExpeditionItem.new(heroid,nil,account_data.heroList[heroid].lv)
        obj._heroitem[heroid] = heroitem 
        local itemsize = heroitem:egNode():getSize()
        local row = math.ceil(idx/2)
        if idx%2 == 1 then
            heroitem:egNode():setPosition(ccp(0,newH-row*kCellH)) 
        else
            heroitem:egNode():setPosition(ccp(size.width-itemsize.width,newH-row*kCellH)) 
        end  
        obj:panelHeroClicked(heroitem)  
        herolist:addChild(heroitem:egNode())
    end
    for key,heroid in ipairs (account_data.team) do
        obj._heroitem[heroid]:showJoinFlag(true)
    end   
end
--Ӣ��ս��������
function __gvgpreview.getHeroAtkOrder(obj)
    local tb = {}
    for heroid,heroprop in pairs(account_data.heroList) do
        if not account_data.cbTeam[heroid] then
            table.insert(tb,{heroid, RiskHelper.getHeroBp(heroprop,account_data)})
        end 
    end
    table.sort(tb,function(a,b) return a[2]>b[2] end)
    return tb
end
--���ѡ�����Ӣ��
function __gvgpreview.panelHeroClicked(obj,heroitem)
    local function callback(sender,posx,posy)
        local isJoin = sender:getprop("joined")
        local heroid = sender:getprop("heroid")
        if isJoin then
            obj:removeTeamHero(heroid,posx,posy)
            --obj._heroitem[heroid]:showJoinFlag(false) 
        else
            if #account_data.team == account_data.maxTeam then
                showPopTxt(TxtList.teamLimited,posx,posy,ccp(0.5,0.5))
            else
                 obj._heroitem[heroid]:showJoinFlag(true)
                 obj:insertTeamHero(heroid)
            end
        end
    end
    heroitem:onItemClicked(callback)
end
function __gvgpreview.showWidthAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kImgBg)
    widget:runAction(CCFadeIn:create(0.4))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(baseWidget:getPositionX(),720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(baseWidget:getPositionX(),0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    local function callback()
        if obj._onloaded then obj._onloaded()end
    end
    local callfunc = CCCallFunc:create(callback)
	local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
	baseWidget:runAction(sequece)
end
--�ر�ҳ��
function __gvgpreview.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SendMsg[9311003]()
		for idx,heroids in ipairs(obj._oldTeam) do
            if heroids ~= account_data.team[idx] or #obj._oldTeam ~= #account_data.team then
                 SendMsg[934003](account_data.team)
                 obj._oldTeam = Funs.copy(account_data.team)
                 break
            end
        end   
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

--��ʼ��ť
function __gvgpreview.bindStartListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:egUnbindWidgetUpdate(kLblTimeRes)
		if club_data and club_data.warData and club_data.warData.expire > os.time() then
			AccountHelper:useActPt(numDef.actPtForClubPvp)
			local scene = ClubPvpScene.new()
			scene:egReplace()
		else
			local pos = sender:getTouchEndPos()
			showPopTxt(TxtList.warHasOver,pos.x,pos.y,ccp(0.5,0.5))
			obj:egRemoveSelf()
		end
    end  
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end  
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
function __gvgpreview.getTeamAtkCap(obj)
    local tb = {}
	local teamAtk = 0
    for key,heroprop in pairs(account_data.heroList) do
        tb[heroprop.type] = RiskHelper.getHeroBp(heroprop,account_data)
    end
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk + tb[heroid]
    end
	tb = nil
    return teamAtk
end
function __gvgpreview.bindChangeListener(obj)
    local function touchEnded(sender)
        if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
		sender:setTouchEnabled(false)
		
		 if obj:egGetLabelStr(kLblChangHero) == TxtList.btnOK then
			obj:egSetWidgetTouchEnabled(kPanelInfo,false)
			obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
			for idx,herodata in ipairs(obj._teamheroitem) do 
                herodata:setItemTouchEnabled(false)
            end
			if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
				SendMsg[934003](account_data.team)
                obj._oldTeam = Funs.copy(account_data.team)
			end
            obj:egHideWidget(kPanelSelect)
			obj:egHideWidget(kHeroList)
			obj:egShowWidget(kBtnBack)
		 else
			obj:egSetWidgetTouchEnabled(kPanelInfo,true)
			obj:egSetLabelStr(kLblChangHero,TxtList.btnOK)
			for idx,herodata in ipairs(obj._teamheroitem) do 
                herodata:setItemTouchEnabled(true)
            end
			obj:egHideWidget(kBtnBack)
			obj:showPanelSelect()
		 end  
		 sender:setTouchEnabled(true)
    end
    local function touchCanceled(sender)
        if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end	
    end
    obj:egBindTouch(kBtnChangeHero,nil,nil,touchEnded,touchCanceled)
end
--ѡС��ʱ�󱳾�ͼƬ����¼�
function __gvgpreview.bindBgListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		obj:egShowWidget(kBtnBack)
		obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
		for idx,herodata in ipairs(obj._teamheroitem) do 
            herodata:setItemTouchEnabled(false)
        end
		if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
			SendMsg[934003](account_data.team)
            obj._oldTeam = Funs.copy(account_data.team)
		end
        obj:egHideWidget(kPanelSelect)
		obj:egHideWidget(kHeroList)
    end
    local function touchCanceled(sender)
        if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end	
    end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,touchCanceled)
end
--����ʱ����
function __gvgpreview.activeTimeUpdate(obj)  
    local function callback(delta)
        obj._passedTime = obj._passedTime + delta
        if obj._passedTime < kWaitTime then
           obj:egSetLabelStr(kLblTimeRes,math.ceil(kWaitTime-obj._passedTime))
        end
        if obj._passedTime >= kWaitTime then
			obj:egUnbindWidgetUpdate(kLblTimeRes)
			obj:egSetWidgetTouchEnabled(kBtnChangeHero,false)
			obj:egSetWidgetTouchEnabled(kPanelInfo,false)
            SoundHelper.playEffect(SoundList.click_shop_goods)
            if club_data and club_data.warData and club_data.warData.expire > os.time() then
				if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
					SendMsg[934003](account_data.team)
					obj._oldTeam = Funs.copy(account_data.team)
				end
				AccountHelper:useActPt(numDef.actPtForClubPvp )
			    local scene = ClubPvpScene.new()
			    scene:egReplace()
		    else
			    obj:egRemoveSelf()
		    end 
		elseif obj._passedTime + 1 >= kWaitTime then
            obj:egSetWidgetTouchEnabled(kBtnStart,false)
            obj:egSetWidgetTouchEnabled(kBtnChangeHero,false)
            obj:egSetWidgetTouchEnabled(kBtnBack,false)   			
        end
    end
    obj:egBindWidgetUpdate(kLblTimeRes,callback)
end
GvgPreView={}
function GvgPreView.new(guid,onload)
    local obj =  TouchWidget.new(JsonList.gvgpreview)
    table_aux.unpackTo(__gvgpreview, obj)
    obj._onloaded = onload
    obj:init(guid)
    obj:bindStartListener()
    obj:bindChangeListener()
    obj:bindBackListener()
	obj:bindBgListener()
    return obj
end

function showGvgPreview(guid,onload)
	local layer =  GvgPreView.new(guid,onload)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end


GvgMissionScene = {}
function GvgMissionScene.new()
	 SoundHelper.playBGM(SoundList.rish_bgm)
    local obj = {}
    Scene.install(obj)
    obj._layer = GvgMissionlayer.new()
    obj._layer:egAttachTo(obj)
    
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
local kImgBg = "img_bg"
local kPanelWait = "wait_panel"
local kPanelInfo = "info_panel"
local kImgFight = "img_fight"

local kImgLoading = "img_loading"
local kLblSearch = "lbl_search"
local kBtnBack = "btn_back"

local kLblAtk = "lbl_atk"
local kLblAtkNum = "lbl_atk_cnt"
local kLblDef = "lbl_def"
local kLblDefNum = "lbl_def_cnt"
local kBtnStart = "btn_start"
local kGvgPrompt = 5
local kStartWarFlag = 0

local __gvgclubsearch = {}
function __gvgclubsearch.init(obj)
	AccountHelper:lock(kStateClubPvp)
	SendMsg[9311001]()
	obj:egHideWidget(kBtnBack)
	obj:egHideWidget(kPanelInfo)
	obj:showWaitPanel()
	obj:showWithAction()
end
--��ʾ�ȴ�����
function __gvgclubsearch.showWaitPanel(obj,show)
	obj:egShowWidget(kPanelWait)
	local widget1 = obj:egGetWidgetByName(kImgFight)
	local scaleto1 = CCScaleTo:create(1,1.3)
	local scaleto2 = CCScaleTo:create(1,1.5)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatforever1 = CCRepeatForever:create(sequence)
	widget1:runAction(repeatforever1)
        
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
	local rotateby = CCRotateBy:create(1,360)
	local repeatforever2 = CCRepeatForever:create(rotateby)
	imgWidget:runAction(repeatforever2) 
	obj:bindLoadTimer()
end
--�����ݼ��صȴ���ʱ��
function __gvgclubsearch.bindLoadTimer(obj)
    local startTime = os.time()
    local  function callback(delta)
        if not  AccountHelper:isLocked(kStateClubPvp) or (AccountHelper:isLocked(kStateClubPvp) and club_data and club_data.warData) then
			AccountHelper:unlock(kStateClubPvp)
            obj:egUnbindWidgetUpdate(kLblSearch)
			obj:stopWaitAct()
			if club_data then
				if club_data.warData then
					 obj:egHideWidget(kPanelWait)
					 obj:showPreView()
				 else
					obj:egSetLabelStr(kLblSearch,TxtList.noMatchClub)
					obj:egShowWidget(kBtnBack)
				 end
			else
				obj:egSetLabelStr(kLblSearch,TxtList.joinClubFirst)
				obj:egShowWidget(kBtnBack)
			end
        else
            if os.time() - startTime >numDef.clientTimeOut then
                obj:egUnbindWidgetUpdate(kLblSearch)
                obj:stopWaitAct()
                postEventSignal(kEventRequestTimeOut)
            end
         end
    end
    obj:egBindWidgetUpdate(kLblSearch,callback)
end
--ֹͣ���ŵȴ�����
function __gvgclubsearch.stopWaitAct(obj)
	local widget1 = obj:egGetWidgetByName(kImgFight)
    local widget2 = obj:egGetWidgetByName(kImgLoading)
    widget1:stopAllActions()
    widget2:stopAllActions()
end
function __gvgclubsearch.showPreView(obj)
	obj:egHideWidget(kPanelWait)
	obj:egShowWidget(kPanelInfo)
	local atk = club_data.warData.cb_atk
	local def = club_data.warData.cb_def
	obj:egSetLabelStr(kLblAtk,atk.clubName)
	obj:egSetLabelStr(kLblAtkNum,atk.membersCount)
	obj:egSetLabelStr(kLblDef,def.clubName)
	obj:egSetLabelStr(kLblDefNum,def.membersCount)
	
	--����Ƿ���ս����һ�������������ϲ�����ʾ
   if #account_data.prompList > 0 then
		for key,promptItem in ipairs(account_data.prompList) do
			if promptItem.type == kGvgPrompt and promptItem.data.type == kStartWarFlag then
				table.remove(account_data.prompList,key)
			end
		end
   end
end
--������ʾ����
function __gvgclubsearch.showWithAction(obj)
	obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.2,128))
	
    local bg = obj:egGetWidgetByName(kImgBg)
	local scaleto = CCScaleTo:create(0.4,1)
	local backout =CCEaseBackOut:create(scaleto)
	local function callback()
		if obj._onloaded then obj._onloaded() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(backout,callfunc)
	
	bg:setScale(0)
	bg:runAction(sequence)
end
--�ر�ҳ��
function __gvgclubsearch.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:egRemoveSelf()
		--local scene = GuildScene.new()
		--scene.egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

--��ʼ��ť
function __gvgclubsearch.bindStartListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
		local scene = GvgMissionScene.new()
		scene:egReplace()
    end  
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end  
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
GvgClubSearch={}
function GvgClubSearch.new(onload)
    local obj =  TouchWidget.new(JsonList.gvgClubSearch)
    table_aux.unpackTo(__gvgclubsearch, obj)
    obj._onloaded = onload
    obj:init()
    obj:bindStartListener()
    obj:bindBackListener()
    return obj
end

function showGvgClubSearch(onload)
	local layer =  GvgClubSearch.new(onload)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
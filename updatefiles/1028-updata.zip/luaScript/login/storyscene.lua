StoryScene={}
function StoryScene.new(showidx)
    local obj = {}
	Scene.install(obj)
	obj._baseWidget = StoryLayer.new(showidx)
    obj._baseWidget:egAttachTo(obj)
	    ----------------------------
	obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
	return obj
end
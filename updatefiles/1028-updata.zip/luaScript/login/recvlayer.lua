

local __recvlayer={}
function __recvlayer.setKeyPadEnabled(obj)
    obj:egNode():setKeypadEnabled(true)
	local function callback(eventType)
		if eventType == "backClicked" then
			--�Ѵ��˳�����ʱ��������ز���Ӧ
			if not obj._hasQuitPrompt then
				showQuitPrompt() --�����˳���ʾ����
			end
		end
	end
	obj:egNode():registerScriptKeypadHandler(callback)
end
function __recvlayer.bindReciver(obj)
	local t_stamp = 0
	local function callback(delta)
		t_stamp = t_stamp + delta
		if not numDef then
			numDef = {}
			numDef.beatInterval = 10
		end
		RecvMsg()
		UpdateProp()
		if t_stamp >=numDef.beatInterval then
			t_stamp = 0
			SendMsg[930000]()
		end
	end
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egBindUpdate(callback,exitCallback)
end
function __recvlayer.bindRecvObserver(obj)
	local function onEventActived(eventName)
		unBindObserver(obj:egNode(),eventName)
		if eventName == kEventNetDown then --�������ӶϿ�
			obj:egUnbindUpdate()
			obj._disablePrompt = true
			local function callback()
				AccountHelper:reLoadGame()
			end
			local msglayer = MsgLayer.new(nil,TxtList.netDown,1,callback)
			msglayer:show()
		elseif eventName ==kEventOpenQuitPrompt then --���˳���ʾ
			obj._promptShown = true
		elseif eventName ==kEventCloseQuitPrompt then --�ر��˳���ʾ
			obj._promptShown = false
		elseif eventName == kEventRelogin then--�ظ���¼��������
			obj:egUnbindUpdate()
			SocketHelper.disconnect()
			obj._disablePrompt = true
			local function callback1()
				AccountHelper:reLoadGame()
			end
			local function callback2()	CCDirector:sharedDirector():endToLua() end
			local msglayer = MsgLayer.new(nil,TxtList.reLogin,2,callback1,callback2)
			msglayer:show()
		elseif eventName == kEventBeenAttack then-- ���ڱ�����
			obj:egUnbindUpdate()
			SocketHelper.disconnect()
			obj._disablePrompt = true
		elseif eventName == kEventRequestTimeOut then --�������ݳ�ʱ
			obj:egUnbindUpdate()
			if not obj._disablePrompt then
				AccountHelper:reLoadGame()
			end
		end
	end
	bindObserver(obj:egNode(),onEventActived,kEventNetDown)
	bindObserver(obj:egNode(),onEventActived,kEventCloseQuitPrompt)
	bindObserver(obj:egNode(),onEventActived,kEventOpenQuitPrompt)
	bindObserver(obj:egNode(),onEventActived,kEventRelogin)
	bindObserver(obj:egNode(),onEventActived,kEventBeenAttack)
	bindObserver(obj:egNode(),onEventActived,kEventRequestTimeOut)
end
RecvLayer={}

function RecvLayer.new()
    local obj = {}
	obj._disablePrompt = false
	obj._promptShown = false
	Layer.install(obj)
	table_aux.unpackTo(__recvlayer, obj)
	obj:bindRecvObserver()
	obj:bindReciver()
	obj:setKeyPadEnabled()
	return obj
end
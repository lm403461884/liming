--region loadlayer.lua
--Author : Yanlee
--Date   : 2014/12/2
--SDK自动登陆部分

local kBarLoad = "bar_mid"
local kImgHeader = "img_header"
local kLblNote = "lbl_note"
local kImgBar = "bar_bg"
local __loadlayer = {}
function __loadlayer.activeWaitConn(obj)
    local function callback(delta)
         local state = SocketHelper.currentState()
         if state == 0 then
         elseif state == 1 then
             obj:egUnbindWidgetUpdate(kImgHeader)
             local logname,logpwd = AccountHelper:getLogInfo()
             SendMsg[931001](logname,logpwd)
			 obj:egSetLabelStr(kLblNote,TxtList.updateMsg[8])
         else
            obj:egUnbindWidgetUpdate(kImgHeader)
            obj:egUnbindWidgetUpdate(kBarLoad)
            local function callback()
				AccountHelper:reLoadGame()
			end
			local msglayer = MsgLayer.new(nil,TxtList.connError,1,callback)
			msglayer:egAttachTo(obj)
         end
    end
    obj:egBindWidgetUpdate(kImgHeader,callback)
end
function __loadlayer.isValidNickName(obj)
    if not account_data.nickName then return false end
    if string.len(account_data.nickName)== 0 then return false end
    if account_data.nickName == account_data.user then return false end
    account_data.nickName = HOAux:hexstr2str(account_data.nickName)
    if string.len(account_data.nickName)== 0 then return false end
    return true
end
function __loadlayer.bindLoadObserver(obj)
	local function onDownLoaded(eventName)
		unBindObserver(obj:egNode(),eventName)
		if eventName == kEventAcctDownLoad then
			obj._acct_ready = true
			obj:checkToStart()
		elseif eventName == kEventScriptDownLoad then
			obj._script_ready = true
			obj:checkToStart()
		elseif eventName == kEventClubDownLoad then
			obj._club_read = true
			obj:checkToStart()
		elseif eventName == kEventClubWarDownLoad then
			obj._war_ready = true
			obj:checkToStart()
		elseif eventName == kEventBeenAttack then
			obj:egUnbindWidgetUpdate(kBarLoad)
			obj:egSetBarPercent(kBarLoad,100)
			showBattleWaitLayer()
        elseif eventName == kEventRSAuthorized then
            obj:startLoading()
            obj:activeWaitConn()
		end
	end
	bindObserver(obj:egNode(),onDownLoaded,kEventAcctDownLoad)
	bindObserver(obj:egNode(),onDownLoaded,kEventScriptDownLoad)
	bindObserver(obj:egNode(),onDownLoaded,kEventClubDownLoad)
	bindObserver(obj:egNode(),onDownLoaded,kEventClubWarDownLoad)
	bindObserver(obj:egNode(),onDownLoaded,kEventBeenAttack)
    bindObserver(obj:egNode(),onDownLoaded,kEventRSAuthorized)
end
function __loadlayer.checkToStart(obj)
	if obj._acct_ready and obj._script_ready and obj._club_read and obj._war_ready then
		obj:egUnbindWidgetUpdate(kBarLoad)
		obj:egSetBarPercent(kBarLoad,100)
		if  not obj:isValidNickName() then
			showNickNameLayer()
        else
			if account_data.guideList[GuideScene.def.kAtkScene] then --PVE关卡引导没走完
				local scene = GAtkScene.new()
				scene:egReplace()
			else
				local scene = TownScene.new()
				scene:egReplace()
			end
        end
	end
end
function __loadlayer.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
function __loadlayer.startLoading(obj)
    local curper = 0
	local countS = 0
    obj:egShowWidget(kImgBar)
    obj:egShowWidget(kLblNote)
    local function callback(delta)
		countS = countS + delta
		curper = curper + 1
		if countS >= 100 then
			obj:egUnbindWidgetUpdate(kBarLoad)
			local function callback()
				AccountHelper:reLoadGame()
			end
			local msglayer = MsgLayer.new(nil,TxtList.loadError,1,callback)
			msglayer:egAttachTo(obj)
		else
            obj:egSetBarPercent(kBarLoad,math.min(curper,100))
		end
    end
    obj:egBindWidgetUpdate(kBarLoad,callback)
end
function __loadlayer.init(obj)
    obj._acct_ready = false
    obj._script_ready = false
    obj._club_read = false
    obj._war_ready = false
    obj:egHideWidget(kImgBar)
    obj:egHideWidget(kLblNote)
    obj:bindLoadObserver()
    obj:autoUnbindObserver()
end
LoadLayer = {}

function LoadLayer.new()
    local obj = TouchWidget.new(JsonList.loadingLayer)
    table_aux.unpackTo(__loadlayer, obj)
    obj:init()
    return obj
end

--endregion

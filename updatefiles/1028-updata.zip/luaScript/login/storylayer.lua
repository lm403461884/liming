local kPanelLayer = "story_panel"

local kTxtBg1 = "txt_bg_1"
local kTxtBg2 = "txt_bg_2"
local kTxtBg3 = "txt_bg_3"

local kLblTxt1 = "txt_1"
local kLblTxt2 = "txt_2"
local kLblTxt3 = "txt_3"

local kImg1 = "img_ep_1"
local kImg2 = "img_ep_2"
local kImg3 = "img_ep_3"
local kImg4 = "img_ep_4"
local kImg5 = "img_ep_5"

local kImgBg = "img_story"

local __storylayer={}
function __storylayer.init(obj,nextIdx)
	obj:egSetWidgetTouchEnabled(kPanelLayer,false)
	if nextIdx then
		obj:egHideWidget(kImgBg)
		obj._nextIdx = nextIdx
	else
		obj._nextIdx = 1
		obj:loadTxt1()
		obj:egSetLabelStr(kLblTxt2,storyData[1][2])
		obj:egSetLabelStr(kLblTxt3,storyData[1][3])
		SoundHelper.playBGM(SoundList.rain_bgm)
	end 
	local function callback()
		obj:showNextStory()
	end
	local callfunc = CCCallFunc:create(callback)
	local fadeout = CCFadeTo:create(0.5,0)
	local sequence = CCSequence:createWithTwoActions(fadeout,callfunc)
	obj._colorLayer = CCLayerColor:create(ccc4(0,0,0,0))
	obj:egAddChild(obj._colorLayer,1,1)
	obj._colorLayer:runAction(sequence)
end
function __storylayer.showNextStory(obj)
	local function callback()
		obj:egSetWidgetTouchEnabled(kPanelLayer,true)
		obj._nextIdx = obj._nextIdx + 1
		obj:activeAutoPlay()
	end
	if obj._nextIdx == 1 then
		obj:egShowWidget(kTxtBg1)
		callback()
	elseif obj._nextIdx == 2 then
		obj:egHideWidget(kTxtBg1)
		obj:fadeIn(kImg1,0.5,callback)
	elseif obj._nextIdx == 3 then
		obj:fadeIn(kTxtBg2,0.5,callback)
	elseif obj._nextIdx == 4 then
		obj:fadeIn(kTxtBg3,0.5,callback)
	elseif obj._nextIdx == 5 then
		obj:fadeOut(kTxtBg2,0.2)
		obj:fadeOut(kTxtBg3,0.2)
		obj:fadeOut(kImg1,0.2)
		obj:fadeIn(kImg2,0.5,callback)
	elseif obj._nextIdx == 6 then
		obj:moveIn(kImg3,0.3,ccp(1,3),callback)
	elseif obj._nextIdx == 7 then
	    if account_data.guideList[GuideScene.def.kAtkScene] then --���ε�½����PVE�ؿ�������Ϣʱ
            local scene = GAtkScene.new()
		   --local scene =  ComicScene.new()
            scene:egReplace()
        else
            local scene = TownScene.new()
            scene:egReplace()
        end
		
	elseif obj._nextIdx == 8 then
		obj:fadeIn(kImg4,0.5,callback)
	elseif obj._nextIdx == 9 then
		obj:fadeIn(kImg5,0.5,callback)
	else
	    local scene = TownScene.new()
        scene:egReplace()
	end
end
function __storylayer.fadeIn(obj,widgetName,s,onshown)
	local widget = obj:egGetWidgetByName(widgetName)
	widget:setVisible(true)
	widget:setOpacity(0)
	local fadein= CCFadeIn:create(s)
	local function callback()
		if onshown then onshown() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(fadein,callfunc)
	widget:runAction(sequence)
end

function __storylayer.fadeOut(obj,widgetName,s)
	local widget = obj:egGetWidgetByName(widgetName)
	local fadein= CCFadeOut:create(s)
	local function callback()
		widget:setVisible(false)
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(fadein,callfunc)
	widget:runAction(sequence)
end
function __storylayer.moveIn(obj,widgetName,s,dir,onshown)
    local widget = obj:egGetWidgetByName(widgetName)
	local x = widget:getPositionX()
	local y = widget:getPositionY()
	widget:setPosition(ccp(x*dir.x,y*dir.y))
	widget:setVisible(true)
	local moveto = CCMoveTo:create(s,ccp(x,y))
	local sineout = CCEaseSineOut:create(moveto)
	local fadein = CCFadeIn:create(s)
	local spawn=CCSpawn:createWithTwoActions(fadein,sineout)
	local function callback()
		if onshown then onshown() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
	widget:runAction(sequence)
end
function __storylayer.loadTxt1(obj)
	local lbl_bg = obj:egGetWidgetByName(kTxtBg1)
	local bg_w = lbl_bg:getSize().width
	local bg_h = lbl_bg:getSize().height
	local lbl = tolua.cast(obj:egGetWidgetByName(kLblTxt1),"Label")
	local x = lbl:getPositionX()
	lbl:setText(storyData[1][1])
	local lbl_w = lbl:getSize().width
	local lbl_h = lbl:getSize().height
	local y = (bg_h - lbl_h)/2
	local row_w = bg_w - x*2
	local rows = math.ceil(lbl_w/row_w)
	local new_bg_h = rows*lbl_h + y*2
	if rows > 1 then
		lbl_w = row_w
		lbl:setSize(CCSizeMake(lbl_w,rows*lbl_h))
		lbl:setPosition(ccp(lbl:getPositionX(),new_bg_h/2))
	end
	lbl_bg:setSize(CCSizeMake(x*2 + lbl_w,new_bg_h))
	lbl_bg:setPosition(ccp(lbl_bg:getPositionX(),lbl_bg:getPositionY() + bg_h-new_bg_h))
end
function __storylayer.bindBgListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled (false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		obj:showNextStory()
    end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,nil)
end
function __storylayer.activeAutoPlay(obj)
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if passed >= numDef.comicInterval then
			obj:egUnbindWidgetUpdate(kImgBg)
			obj:egSetWidgetTouchEnabled(kPanelLayer,false)
			SoundHelper.playEffect(SoundList.click_paper_open)
			obj:showNextStory()
		end
	end
	obj:egUnbindWidgetUpdate(kImgBg)
	obj:egBindWidgetUpdate(kImgBg,callback)
end

StoryLayer = {}
function StoryLayer.new(nextIdx)
    local obj =  TouchWidget.new(JsonList.storyLayer)
    table_aux.unpackTo(__storylayer, obj)
    obj:init(nextIdx)
    obj:bindBgListener()
    return obj
end
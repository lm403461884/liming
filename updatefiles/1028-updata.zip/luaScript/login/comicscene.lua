ComicScene={}
function ComicScene.new()
	SoundHelper.playBGM(SoundList.comic_bgm)
    local obj = {}
	Scene.install(obj)
	obj._baseWidget = ComicLayer.new()
    obj._baseWidget:egAttachTo(obj)
	    ----------------------------
	obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
	return obj
end


LoadScene = {}

function LoadScene.new(platform)
    local obj = {}
	SoundHelper.playBGM(SoundList.login_bgm)
    Scene.install(obj)
    obj._loadlayer = LoadLayer.new()
    obj._loadlayer:egAttachTo(obj)
	obj._loginlayer = LoginLayer.new()
    obj._loginlayer:egAttachTo(obj)
    if platform == kTargetAndroid then
        SDKHelper:login()
    else
        obj._loginlayer:doLogin()
    end
	obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
    return obj
end
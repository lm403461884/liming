local panelLayer = "comic_panel"
local panelTxt = "txt_panel"
local kImgPage = "img_page"
local kImgBook = "img_book"

local __comicLayer={}
function __comicLayer.init(obj)
	obj:egSetWidgetTouchEnabled(panelLayer,false)
	obj._colorLayer = CCLayerColor:create(ccc4(0,0,0,255))
	obj:egAddChild(obj._colorLayer,1,2)
	obj._nextPage = 1
	obj:bindLoadTimer()
end
function __comicLayer.showNextPage(obj,s)
	if not s then s = 0.2 end
	obj:clearWidgetChildren(panelTxt)
	obj:egChangeImg(kImgPage,comicImgData[obj._nextPage])
	obj:loadTxt()
	local fadeto = CCFadeTo:create(s,0)
	local function callback()
		obj:egSetWidgetTouchEnabled(panelLayer,true)
		obj._nextPage = obj._nextPage + 1
		obj:activeAutoPlay()
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(fadeto,callfunc)
	obj._colorLayer:runAction(sequence)
end

--加载文字信息
function __comicLayer.loadTxt(obj)
	local txtList = comicTxtData[obj._nextPage]
	local cnt = #txtList
	local panel = obj:egGetScrollView(panelTxt)
	local layouttype = panel:getLayoutType()
	local w = panel:getSize().width
	for idx = 1,cnt do
		local txtInfo = txtList[idx]
		local lbl = Label:create()
		lbl:setText(txtInfo.txt)
		lbl:setFontSize(txtInfo.fontSize or 24)
		if txtInfo.fontName then lbl:setFontName(txtInfo.fontName) end
		if txtInfo.color then lbl:setColor(ccc3(txtInfo.color[1],txtInfo.color[2],txtInfo.color[3])) end
		
		local lblW = lbl:getSize().width
		local lblH = lbl:getSize().height
		
		if lblW >= w then
			local rows = math.ceil(lblW/w) + 1
			lblW = w
			lblH = rows*lblH
			lbl:setTextAreaSize(CCSizeMake(lblW,lblH))
		else
			lbl:setTextAreaSize(CCSizeMake(w,lblH))
			lbl:setTextHorizontalAlignment(txtInfo.align or 0)
		end
		panel:addChild(lbl,0,idx)
		local layoutparameter = lbl:getLayoutParameter(layouttype)
		layoutparameter:setMarginTo(0,txtInfo.margin_top or 0,0,txtInfo.margin_bottom or 0)
		lbl:setLayoutParameter(layoutparameter)
		
	end
end

--清除指定控件的所有子控件
function __comicLayer.clearWidgetChildren(obj,widgetName)
	local widget = obj:egGetWidgetByName(widgetName)
	local cnt = widget:getChildrenCount()
	for idx = 1,cnt do
		widget:removeChildByTag(idx,true)
	end
end
function __comicLayer.turnPage(obj)
	obj:egSetWidgetTouchEnabled(false)
	SoundHelper.playEffect(SoundList.click_paper_open)
	local fadeout = CCFadeTo:create(0.3,255)
	local function callback()
		if comicImgData[obj._nextPage] then --有下一页配置数据
            obj:showNextPage()
        else
            local scene = StoryScene.new(8)
            scene:egReplace()
        end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(fadeout,callfunc)
	obj._colorLayer:runAction(sequence)
end
function __comicLayer.bindTurnListener(obj)
    local function touchEnded(sender)
       obj:turnPage()
    end
    obj:egBindTouch(panelLayer,nil,nil,touchEnded,nil)
end
function __comicLayer.bindLoadTimer(obj)
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if passed >= 1 then
			obj:egUnbindWidgetUpdate(kImgPage)
			obj:showNextPage(3)
		end
	end
	obj:egBindWidgetUpdate(kImgPage,callback)
end
function __comicLayer.activeAutoPlay(obj)
	local passed = 0
	local function callback(delta)
		passed = passed + delta
		if passed >= numDef.comicInterval then
			obj:egUnbindWidgetUpdate(kImgBook)
			 obj:turnPage()
		end
	end
	obj:egUnbindWidgetUpdate(kImgBook)
	obj:egBindWidgetUpdate(kImgBook,callback)
end
ComicLayer = {}
function ComicLayer.new()
    local obj =  TouchWidget.new(JsonList.comicLayer)
    table_aux.unpackTo(__comicLayer, obj)
    obj:init()
    obj:bindTurnListener()
    return obj
end


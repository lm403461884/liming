local __loginlayer={}
local kBtnRegist = "regist_btn"
local kBtnLogin = "login_btn"
local kTbPwd = "pwd_tb"
local kTbAccount = "account_tb"
local kBgPwd = "pwd_bg"
local kBgAccount = "account_bg"
local kLabelMsgName = "lbl_msg_name"
local kLabelMsgPwd = "lbl_msg_pwd"
local kLabelLoad = "lbl_conn"
local kLblWarnAcct = "lbl_warn_acct"
local kLblWarnPwd = "lbl_warn_pwd"
local kAttach_with_ime = 0
local kDetach_with_ime = 1
local kInsert_text = 2
local kDelete_backward = 3
local kMaxTxtLen = 16
local kWhiteColor = ccc3(255,255,255)
local kPattenChar = "[%W+]"
function __loginlayer.checkAccount(obj,textField)
	local txt = textField:getStringValue()
	if string.len(txt) == 0 then
		obj._acctReady = false
		obj:egShowWidget(kLblWarnAcct)
		obj:egSetLabelStr(kLblWarnAcct,TxtList.warnNoAcct)
	else
		local logname = Funs.subStr(txt,kMaxTxtLen)
		textField:setText(logname)
		if string.find(logname,kPattenChar) then
			obj._acctReady = false
			obj:egShowWidget(kLblWarnAcct)
			obj:egSetLabelStr(kLblWarnAcct,TxtList.warnAcctFormat)
		else
			obj._acctReady = true
			obj:egHideWidget(kLblWarnAcct)
		end
	end
end
function __loginlayer.checkPwd(obj,textField)
	local logpwd = textField:getStringValue()
	if string.len(logpwd) == 0 then
		obj._pwdReady = false
		obj:egShowWidget(kLblWarnPwd)
		obj:egSetLabelStr(kLblWarnPwd,TxtList.warnNoPwd)
	elseif string.len(logpwd) > 16 then
		obj._pwdReady = false
		obj:egShowWidget(kLblWarnPwd)
		obj:egSetLabelStr(kLblWarnPwd,TxtList.warnPwdLen)
	else
		if string.find(logpwd,kPattenChar) then
			obj._pwdReady = false
			obj:egShowWidget(kLblWarnPwd)
			obj:egSetLabelStr(kLblWarnPwd,TxtList.warnPwdFormat)
		else
			obj._pwdReady = true
			obj:egHideWidget(kLblWarnPwd)
		end
	end
end
function __loginlayer.startListen(obj,logname,logpwd,isRegisted)
	AccountHelper:setLogInfo(logname,logpwd)
    local  function callback(delta)
		local state = RSHelper:getState()
		if state == 6 then
			obj:egUnbindWidgetUpdate(kLabelLoad)
			obj._connLbl:setVisible(true)
			RSHelper:handleRSMsg()
        elseif state < 0  then
			RSHelper:disconnect()
            obj:egNode():setTouchEnabled(true)
			obj:egUnbindWidgetUpdate(kLabelLoad)
			obj._connLbl:setVisible(false)
			obj._connLbl:stopAllActions()
			local function clickCallback()
				AccountHelper:reLoadGame()
			end
			local msglayer = MsgLayer.new(nil,TxtList.connError,1,clickCallback)
			msglayer:show()
        end
    end
	
	RSHelper:connect()
	if isRegisted then
		RSHelper:sendLogMsg(logname,logpwd)
	else
		RSHelper:sendRegMsg(logname,logpwd)
	end
	
	obj:egNode():setTouchEnabled(false)
	obj:egShowWidget(kLabelLoad)
    obj:egBindWidgetUpdate(kLabelLoad,callback)
	
	obj._connLbl:runAction(CCRepeatForever:create(CCBlink:create(1,3)))
end
function __loginlayer.bindRegistListener(obj)
    local function touchEnded(sender)
		obj._tbacct:setTouchEnabled(false)
		obj._tbpwd:setTouchEnabled(false)
		obj._bgacct:setTouchEnabled(false)
		obj._bgpwd:setTouchEnabled(false)
		obj._btnLog:setTouchEnabled(false)
		obj._btnReg:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
        if obj._acctReady== false or obj._pwdReady == false then
			obj:blinkWarnLbl()
		else
           local logname = obj._tbacct:getStringValue()
           local logpwd = obj._tbpwd:getStringValue()
		  obj:startListen(logname,logpwd,false)
	    end
    end
    obj:egBindTouch(kBtnRegist,nil,nil,touchEnded,nil)
end
function __loginlayer.blinkWarnLbl(obj)
	if obj._acctReady== false then 
		obj._bgacct:stopAllActions()
		obj._bgacct:setColor(kWhiteColor)
		local turnRed = CCTintTo:create(0.2,255,0,0)
		local turnWhite = CCTintTo:create(0.3,255,255,255)
		obj._bgacct:runAction(CCSequence:createWithTwoActions(turnRed,turnWhite))
	end
    if obj._pwdReady== false  then 
		obj._bgpwd:stopAllActions()
		obj._bgpwd:setColor(kWhiteColor)
		local turnRed = CCTintTo:create(0.2,255,0,0)
		local turnWhite = CCTintTo:create(0.3,255,255,255)
		obj._bgpwd:runAction(CCSequence:createWithTwoActions(turnRed,turnWhite))
	end
	obj._btnReg:setTouchEnabled(true)
	obj._btnLog:setTouchEnabled(true)
end
function __loginlayer.bindLogintListener(obj)
    local function touchEnded(sender)
		obj._tbacct:setTouchEnabled(false)
		obj._tbpwd:setTouchEnabled(false)
		obj._bgacct:setTouchEnabled(false)
		obj._bgpwd:setTouchEnabled(false)
		obj._btnLog:setTouchEnabled(false)
		obj._btnReg:setTouchEnabled(false)
	    SoundHelper.playEffect(SoundList.click_shop_goods)
        if obj._acctReady== false or obj._pwdReady == false then
			obj:blinkWarnLbl()
		else
           local logname = obj._tbacct:getStringValue()
           local logpwd = obj._tbpwd:getStringValue()
		   obj:startListen(logname,logpwd,true)
	    end
    end
    obj:egBindTouch(kBtnLogin,nil,nil,touchEnded,nil)
end

function __loginlayer.bindAccountBgListener(obj)
    local function touchEnded(sender)
        obj._tbacct:attachWithIME()
    end
    obj:egBindTouch(kBgAccount,nil,nil,touchEnded,nil)
end

function __loginlayer.bindPwdBgListener(obj)
    local function touchEnded(sender)
        obj._tbpwd:attachWithIME()
    end
    obj:egBindTouch(kBgPwd,nil,nil,touchEnded,nil)
end

function __loginlayer.bindAccountListener(obj)
     local function textFieldEvent(sender, eventType)
        --if eventType == kAttach_with_ime or  eventType ==kDetach_with_ime or eventType == kDelete_backward then
		obj:checkAccount(tolua.cast(sender,"TextField"))
        -- end
    end
    obj._tbacct:addEventListenerTextField(textFieldEvent) 
end

function __loginlayer.bindPwdListener(obj)
    local function textFieldEvent(sender, eventType)
      --  if eventType == kAttach_with_ime or eventType ==kDetach_with_ime or eventType == kDelete_backward then
        obj:checkPwd(tolua.cast(sender,"TextField"))
        -- end
    end
    obj._tbpwd:addEventListenerTextField(textFieldEvent) 
end

function __loginlayer.bindLoginObserver(obj)
	local function onEventActived(eventName)
		if eventName == kEventSDKAuthorized then
		    obj:doLogin()
		elseif eventName == kEventAcctNotExist then
			if SDKHelper:isSDKAuthorized() then
				local logname,logpwd = AccountHelper:getLogInfo()
				obj:startListen(logname,logpwd,false)
			else
				AccountHelper:setLogInfo("","")
				obj:showSelf()
				local msglayer = MsgLayer.new(nil,TxtList.noSuchAccount,1)
				msglayer:show()
			end
		elseif eventName == kEventRSAuthorized then
			obj:hideSelf()
		elseif eventName == kEventAcctExist then
			AccountHelper:setLogInfo("","")
			obj:showSelf()
            local msglayer = MsgLayer.new(nil,TxtList.registedAccount,1)
		    msglayer:show()
		elseif eventName == kEventPwdNotMatch then
			AccountHelper:setLogInfo("","")
			obj:showSelf()
            local msglayer = MsgLayer.new(nil,TxtList.pwdNotMatch,1)
		    msglayer:show()
		end
	end
	bindObserver(obj:egNode(),onEventActived,kEventSDKAuthorized)
	bindObserver(obj:egNode(),onEventActived,kEventAcctNotExist)
	bindObserver(obj:egNode(),onEventActived,kEventRSAuthorized)
	bindObserver(obj:egNode(),onEventActived,kEventAcctExist)
	bindObserver(obj:egNode(),onEventActived,kEventPwdNotMatch)
end
function __loginlayer.autoUnbindObserver(obj)
	local function exitCallback()
		removeAllObserver(obj:egNode())
	end
	obj:egOnExit(exitCallback)
end
function __loginlayer.hideSelf(obj)
	obj._tbacct:setTouchEnabled(false)
	obj._tbpwd:setTouchEnabled(false)
	obj._bgacct:setTouchEnabled(false)
	obj._bgpwd:setTouchEnabled(false)
	obj._btnLog:setTouchEnabled(false)
	obj._btnReg:setTouchEnabled(false)
	obj:egNode():setVisible(false)
	obj:egNode():setTouchEnabled(false)	
end
function __loginlayer.showSelf(obj)
	obj:egNode():setVisible(true)
	obj:egNode():setTouchEnabled(true)
	obj._tbacct:setTouchEnabled(true)
	obj._tbpwd:setTouchEnabled(true)
	obj._bgacct:setTouchEnabled(true)
	obj._bgpwd:setTouchEnabled(true)
	obj._btnLog:setTouchEnabled(true)
	obj._btnReg:setTouchEnabled(true)
	obj:egHideWidget(kLabelLoad)  
	obj:egHideWidget(kLblWarnAcct)
	obj:egHideWidget(kLblWarnPwd)
	obj._connLbl:setVisible(false)
	obj._connLbl:stopAllActions()
end
function __loginlayer.doLogin(obj)
	local logname,logpwd = AccountHelper:getLogInfo()
	if logname and logname~="" then
		obj:startListen(logname,logpwd,true)
	else
		obj:showSelf()
	end
end
function __loginlayer.init(obj)
	obj._tbacct = tolua.cast(obj:egGetWidgetByName(kTbAccount),"TextField")
	obj._tbpwd = tolua.cast(obj:egGetWidgetByName(kTbPwd),"TextField")
	obj._bgacct = obj:egGetWidgetByName(kBgAccount)
	obj._bgpwd = obj:egGetWidgetByName(kBgPwd)
	obj._btnReg = obj:egGetWidgetByName(kBtnRegist)
	obj._btnLog = obj:egGetWidgetByName(kBtnLogin)
	obj._connLbl = obj:egGetWidgetByName(kLabelLoad)
	obj._acctReady = false
	obj._pwdReady = false
	obj:bindRegistListener()
    obj:bindLogintListener()
    obj:bindAccountListener()
    obj:bindPwdListener()
    obj:bindAccountBgListener()
    obj:bindPwdBgListener()
	obj:bindLoginObserver()
	obj:autoUnbindObserver()
	obj:hideSelf()
end
LoginLayer = {}
function LoginLayer.new()
	local obj = TouchWidget.new(JsonList.loginLayer)
	table_aux.unpackTo(__loginlayer, obj)
    obj:init()
    return obj
end

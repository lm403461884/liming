local kImglogo = "img_logo"
local __logoscene = {}
function __logoscene.runLoadAction(obj)
    local widget = obj._baseWidget:egGetWidgetByName(kImglogo)
	widget:setOpacity(32)
	widget:runAction(CCFadeIn:create(2))
	local passed = 0
	local isCoDead = false
	local coLoad = coroutine.create(function() graphicLoader.loadBasicFrame() return 1 end) 
    local function callback(delta)
		passed = passed + delta
		if isCoDead and   passed>=2  then
			obj._baseWidget:egUnbindWidgetUpdate(kImglogo)
			local scene = LoadScene.new(CCApplication:sharedApplication():getTargetPlatform())
			scene:egReplace() 
		elseif not isCoDead then
			local f1,f2 = coroutine.resume(coLoad)
			if f2 == 1 then 
				isCoDead = true
			elseif type(f2) == "string" then 
                obj._baseWidget:egUnbindWidgetUpdate(kImglogo)
				print(f2) 
                local function msgcallback()
                    graphicLoader.clearAllRes()
                    AccountHelper:reLoadGame()
                end
				MsgLayer.new(nil,TxtList.getDataError,1,msgcallback):show()
			end
		end
		if obj._playCnt == 0 then
			SoundHelper.playEffect(SoundList.logo)
			obj._playCnt = obj._playCnt + 1
		end
    end
    obj._baseWidget:egBindWidgetUpdate(kImglogo,callback)
end
LogoScene={}
function LogoScene.new()
    local obj = {}
	SoundHelper.stopBGM()
	obj._playCnt = 0
	Scene.install(obj)
	table_aux.unpackTo(__logoscene, obj)
	obj._baseWidget = TouchWidget.new(JsonList.logoLayer)
    obj._baseWidget:egAttachTo(obj)
	obj:runLoadAction()
	return obj
end
local kBarLoad = "bar_mid"
local kImgHeader = "img_header"
local kLblNote = "lbl_note"
local kDownLoadedVer = "downloaded-version-code"
local kCurrentVer = "current-version-code"
local __verctrscene = {}
function __verctrscene.init(obj)
	local currentVer = CCUserDefault:sharedUserDefault():getIntegerForKey(kCurrentVer)
	if currentVer == 0 then 
		CCUserDefault:sharedUserDefault():setIntegerForKey(kCurrentVer,__version)
		CCUserDefault:sharedUserDefault():setIntegerForKey(kDownLoadedVer,__version)
	end
	RSHelper:initUpdateEngine()
	UpdateEngine:update()
	obj:bindVerTimer()
end
function __verctrscene.formatVerCode(obj,vernum)
	local v1 = math.floor(vernum/1000)
	local v2 = math.floor(vernum%1000/100)
	local v3 = math.floor(vernum%100/10)
	local v4 = math.floor(vernum%10)
	return string.format("%d.%d.%d.%d",v1,v2,v3,v4)
end
function __verctrscene.handlError(obj,msgcode)
	if msgcode == 3  then --û�п��Ը��µİ汾
		obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			CCDirector:sharedDirector():endToLua()
		end
		local msglayer = MsgLayer.new(nil,TxtList.verError,1,callback)
		msglayer:show()
	elseif msgcode == 7 then
		obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			CCDirector:sharedDirector():endToLua()
		end
		local msglayer = MsgLayer.new(nil,TxtList.verError,1,callback)
		msglayer:show()
	else --����ԭ�������ԭ����ɵĸ���ʧ��
		obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			AccountHelper:reLoadGame()
		end
		local msglayer = MsgLayer.new(nil,TxtList.updateError,1,callback)
		msglayer:show()
	end
end
function __verctrscene.bindVerTimer(obj)
	local curVerTxt = ""
	local function update(delta)
		if UpdateEngine:hasNewMsg() then
			local msgtype,msgcode = UpdateEngine:getNewMsg()
			if msgtype == 1 then --���³���
				obj:handlError(msgcode)
			elseif msgtype == 2 then --��鵽�汾����
				obj._baseWidget:egSetLabelStr(kLblNote,TxtList.updateMsg[2])
				print("get new ver")
			elseif msgtype == 3 then --��ʼ����
				print("start down load")
				curVerTxt = obj:formatVerCode(msgcode)
				obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[3],curVerTxt))
				obj._baseWidget:egSetBarPercent(kBarLoad,0)
			elseif msgtype == 4 then --������
			    obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[9],curVerTxt,msgcode,"%"))
				obj._baseWidget:egSetBarPercent(kBarLoad,msgcode)
			elseif msgtype == 5 then --���ؽ���
				print("down load end")
				obj._baseWidget:egSetBarPercent(kBarLoad,100)
			elseif msgtype == 6 then --��ʼ��ѹ
				print("start un zip ")
				obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[4],obj:formatVerCode(msgcode)))
			elseif msgtype== 7 then --��ѹ���
				print("finish un zip ")
				obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[5],obj:formatVerCode(msgcode)))
				CCUserDefault:sharedUserDefault():setIntegerForKey(kDownLoadedVer, msgcode)
			elseif msgtype==8 then --�������
                obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
				print("update succ ")
				local curVer = CCUserDefault:sharedUserDefault():getIntegerForKey(kDownLoadedVer)
				CCUserDefault:sharedUserDefault():setIntegerForKey(kCurrentVer,curVer )
				print("current version: ",curVer)
				obj:startLoadGame()
			end
		end
	end
	obj._baseWidget:egBindWidgetUpdate(kImgHeader,update)
end
function __verctrscene.startLoadGame(obj)
    
    collectgarbage("setpause", 100)
	collectgarbage("setstepmul", 5000)
	 --�����������
	math.randomseed( os.time() )
    graphicLoader.clearAllRes()
    preloadAllFile()
	--������Կ
	ZipUtils:setPvrKey(kPvrKey[1],kPvrKey[2],kPvrKey[3],kPvrKey[4])
    SDKHelper:init()
    local coLoad = coroutine.create(function() graphicLoader.loadBasicFrame() return 1 end) 
    local function update()
        local f1,f2 = coroutine.resume(coLoad)
		if f2 == 1 then 
            obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		    local  scene = LoadScene.new()
            scene:egReplace()
		elseif type(f2) == "string" then 
            obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
            print(f2) 
            local function msgcallback()
                graphicLoader.clearAllRes()
                AccountHelper:reLoadGame()
            end
            MsgLayer.new(nil,TxtList.getDataError,1,msgcallback):show()
		end
    end
    obj._baseWidget:egBindWidgetUpdate(kImgHeader,update)
end
VerCtrScene = {}

function VerCtrScene.new()
    local obj = {}
    table_aux.unpackTo(__verctrscene, obj)
    Scene.install(obj)
    obj._baseWidget = TouchWidget.new(JsonList.loadingLayer)
    obj._baseWidget:egAttachTo(obj)
    obj:init()
    return obj
end
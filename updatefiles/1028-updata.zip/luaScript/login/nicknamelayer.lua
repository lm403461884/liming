local kBtnOk = "btn_ok"
local kImgTxtBg = "nickname_bg"
local kTbTxt = "tb_nickname"
local kLblWarn = "lbl_warn1"
local kImgBg = "img_bg"
local kPattenChar="[%p,%c,%s]"
local kMaxTxtLen = 16
local kWhiteColor = ccc3(255,255,255)
__nicknamelayer={}
function __nicknamelayer.bindOkListener(obj)
    local function touchEnd(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods) --确认
		if obj._nameReady == false then
			local nameBg = obj:egGetWidgetByName(kImgTxtBg)
			nameBg:stopAllActions()
			nameBg:setColor(kWhiteColor)
			local turnRed = CCTintTo:create(0.2,255,0,0)
			local turnWhite = CCTintTo:create(0.3,255,255,255)
			nameBg:runAction(CCSequence:createWithTwoActions(turnRed,turnWhite))
			sender:setTouchEnabled(true)
		else
			account_data.nickName = obj:egGetTextFieldVal(kTbTxt)
			SendMsg[931010](account_data.nickName)
			local widget = obj:egGetWidgetByName(kImgBg)
			local scaleto = CCScaleTo:create(0.1,0)
			widget:runAction(scaleto)
			
			local colorLayer = CCLayerColor:create(ccc4(0,0,0,0))
			obj:egAddChild(colorLayer)

			local fadeIn = CCFadeTo:create(0.5,255)
			local function callback()
				local scene = StoryScene.new()
				scene:egReplace()
			end
			local callfunc = CCCallFunc:create(callback)
			local sequence = CCSequence:createWithTwoActions(fadeIn,callfunc)
			colorLayer:runAction(sequence)
		end
		
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnd,nil) 
end

function __nicknamelayer.bindTxgBgListener(obj)
	 local function touchEnded(sender)
        local widget = obj:egGetWidgetByName(kTbTxt)
        local textField = tolua.cast(widget,"TextField")
        textField:attachWithIME()
    end
    obj:egBindTouch(kImgTxtBg,nil,nil,touchEnded,nil)
end
function __nicknamelayer.checkNickName(obj,textField)
	local txt = textField:getStringValue()
	if string.len(txt) == 0 then
		obj._nameReady = false
		obj:egShowWidget(kLblWarn)
		obj:egSetLabelStr(kLblWarn,TxtList.warnNoNickName)
	else
		local utfTxt = Funs.subStr(txt,kMaxTxtLen)
		textField:setText(utfTxt)
		if string.find(utfTxt,kPattenChar) then
			obj._nameReady = false
			obj:egShowWidget(kLblWarn)
			obj:egSetLabelStr(kLblWarn,TxtList.warnNickNameFormat)
		else
			obj._nameReady = true
			obj:egHideWidget(kLblWarn)
		end
	end
end
function __nicknamelayer.bindTxtListener(obj)
     local function textFieldEvent(sender, eventType)
        obj:checkNickName(tolua.cast(sender,"TextField"))
    end
    local widget = obj:egGetWidgetByName(kTbTxt)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent) 
end
NickNameLayer={}
function NickNameLayer.new()
     local obj=TouchWidget.new(JsonList.nickNameLayer)
	 table_aux.unpackTo(__nicknamelayer,obj)
	 obj._nameReady = false
	 obj:egHideWidget(kLblWarn)
	 obj:bindOkListener()
	 obj:bindTxgBgListener()
	 obj:bindTxtListener()
	 return obj
end
function showNickNameLayer()
	local layer = NickNameLayer.new()
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
local kLblTxt = "stage_name"
local kPanelAward = "Panel"
local kPanelAward1 = "Panel1"
local kPanelAward2 = "Panel2"
local kPanelAward3 = "Panel3"
local bg_image = "bg_image"
local kMinW = 310
local kMaxLoadNum = 2
local __missontipsinfo= {}
local visibleSize = CCDirector:sharedDirector():getVisibleSize()
local origin = CCDirector:sharedDirector():getVisibleOrigin()
function __missontipsinfo.init(obj,txt,areaid,stageid)
	obj._areaid = areaid
    obj._stageid = stageid
	obj._s_data = pveQuery.queryStage(areaid,stageid)
    obj._costVal = obj._s_data.costAct
    obj:egSetLabelStr(kLblTxt,txt)
	local widget = obj:egGetWidgetByName(bg_image)
    local fadein = CCFadeIn:create(0.2)
    local delayAct = CCDelayTime:create(0.8)
    local fadeout = CCFadeOut:create(0.2)
    local function callback()
        obj:egRemoveSelf()
    end
    local callfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(fadein)
    array:addObject(delayAct)
    array:addObject(fadeout)
    array:addObject(callfunc)
    local sequence = CCSequence:create(array)
    obj._h = widget:getSize().height
	obj._w = obj:egGetWidgetByName(kLblTxt):getSize().width + 100
	if obj._w < kMinW then obj._w = kMinW end
	local img = tolua.cast(widget,"ImageView")
	img:ignoreContentAdaptWithSize(false)
	img:setSize(CCSizeMake(obj._w,obj._h))
    widget:setPosition(ccp(0,obj._h/2))
    widget:runAction(sequence)
	obj:loadAward()
end
function __missontipsinfo.setPositionAt(obj,x,y,anchor)
	if not anchor then anchor = ccp(0,0) end
	x = x - obj._w * anchor.x
	y = y - obj._h * anchor.y
	if x < origin.x then x = origin.x
	elseif x > visibleSize.width - obj._w then  x = visibleSize.width - obj._w end
	if y < origin.y then y = origin.y
	elseif y > visibleSize.height - obj._h then y = visibleSize.height - obj._h end
	obj:egNode():setPosition(ccp(x,y))
end
function __missontipsinfo.getWidth(obj)
	return obj._w
end
function __missontipsinfo.getHight(obj)
	return obj._h
end

function __missontipsinfo.getAwardResList(obj)
	local resList={}
	local heroMsgList = {}
	local expVal = obj._s_data.exp
	for idx = 1,7 do resList[idx] = 0 end
	if MissionHelper.groupIdx then
		resList[1],resList[3],resList[4],resList[5],resList[6],resList[7]=baseCalc.getDayRes(obj._areaid*100 + obj._stageid,account_data.digLv, obj._s_data.gold,obj._s_data.iron,obj._s_data.copper,obj._s_data.stoneR,obj._s_data.stoneB,obj._s_data.stoneD)
		heroMsgList = obj._s_data.heromessage or {}
		expVal = baseCalc.getDaypveExp(obj._areaid*100 + obj._stageid,account_data.digLv,obj._s_data.exp)
	else
		for idx,coinname in pairs(KVariantList.coinType) do 
			resList[idx] = obj._s_data[coinname] or 0
		end
		heroMsgList = obj._s_data.heromessage or {}
	end
		
	return resList,heroMsgList,expVal
end

--���ؽ�������Ľ�����Ϣ
function __missontipsinfo.loadAward(obj)
	obj._awardResList,obj._heroMsgList,obj._expVal = obj:getAwardResList()
	obj._award1w = 0
	obj._award2w = 0
	obj._award3w = 0
	local loadCnt = 0
    for idx,coinval in pairs(obj._awardResList) do
		local coinname = KVariantList.coinType[idx]
		if coinval > 0 then
			loadCnt = loadCnt+1
			local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,coinval))
			obj:addItemToAwardPanel(awarditem,loadCnt)
		end
	end
	
	for heroid,msgnum in pairs(obj._heroMsgList) do
	    loadCnt = loadCnt + 1
	    local heromsg = HeroMsg.new(heroid,string.format("%s%d",TxtList.numSymbol,msgnum))
		obj:addItemToAwardPanel(heromsg,loadCnt)
	end
	local expitem = AwardItem.new("exp",string.format("%s%d",TxtList.numSymbol,obj._expVal))
	 loadCnt = loadCnt + 1
	obj:addItemToAwardPanel(expitem,loadCnt)
	if loadCnt <= kMaxLoadNum then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panel1:getSize().height
		panel2:setVisible(false)
		panel3:setVisible(false)
	elseif loadCnt <= kMaxLoadNum*2 then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panelsize.height - panel3:getSize().height
		panel3:setVisible(false)
	end
end

function __missontipsinfo.addItemToAwardPanel(obj,item,loadCnt)
    local margin = 0
	local awardsize = item:egNode():getSize()
	item:egNode():setSize(CCSizeMake(awardsize.width + margin,awardsize.height))
	if loadCnt <= kMaxLoadNum then
	    local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local size = panel1:getSize()
		panel1:addChild(item:egNode())
		obj._award1w = obj._award1w + awardsize.width
		if obj._award1w > size.width then
		    panel1:setScale(size.width/obj._award1w)
		end
	elseif loadCnt <= kMaxLoadNum*2 then
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local size = panel2:getSize()
		panel2:addChild(item:egNode())
		obj._award2w = obj._award2w + awardsize.width
		if obj._award2w > size.width then
		    panel2:setScale(size.width/obj._award2w)
		end
	else
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
	    local size = panel3:getSize()
		panel3:addChild(item:egNode())
		obj._award3w = obj._award3w + awardsize.width
		if obj._award3w > size.width then
		    panel3:setScale(size.width/obj._award3w)
		end
	end
end

missontipsinfo = {}
function missontipsinfo.new(txt,areaid,stageid)
    local obj = {}
    CocosWidget.install(obj,JsonList.missonTipsTxt)
    table_aux.unpackTo(__missontipsinfo, obj)
    obj:init(txt,areaid,stageid)
    return obj
end
function showmissontipsinfo(txt,x,y,areaId,stageId,anchor)
	if not x then x = 640 end
	if not y then y = 360 end
    local layer = missontipsinfo.new(txt,areaId,stageId)
	layer:setPositionAt(x,y,anchor)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
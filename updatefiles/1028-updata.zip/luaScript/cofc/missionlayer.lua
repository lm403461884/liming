local kPanelMap="map_panel"
local kPanelN = "nm_pnael"
local kPanelD = "dm_panel"
local kBtnBack = "btn_close"
local kBtnSwitch="btn_switch"
local kLblSwitch = "lbl_switch"
local kImgNameBg = "img_map_name_bg"
local kImgChain = "img_map_chain"
local kLblMapName = "lbl_map_name"
local kImgExploreBg = "img_explore"
local kLblExploreNum = "lbl_explore_num"
local kResBgPath = "GUIRes/PvrCcz/m_bg/"--���Ŵ�ͼ·��
local kMaxLen = 130
local __missionlayer={}
function __missionlayer.init(obj,areaid)
	obj._areaid = areaid
    obj._d_data = account_data
    obj._normalList = nil
    obj._dailyList = nil
	obj:egChangeBgImg(kPanelMap,string.format("%sareamap_%d.pvr.ccz",kResBgPath,obj._areaid))
	obj:egChangeBgImg(kPanelN,string.format("%sareatrace_%d.pvr.ccz",kResBgPath,obj._areaid))
    if MissionHelper.showDaily then
		obj:egShowWidget(kPanelD)
		obj:egHideWidget(kPanelN)
        obj:loadDayMission()
		--obj:egSetLabelStr(kLblSwitch,TxtList.missionNormal)
		obj:egSetLabelStr(kLblSwitch,TxtList.returns)
    else
		obj:egShowWidget(kPanelN)
		obj:egHideWidget(kPanelD)
        obj:loadNormalMission()
		obj:egSetLabelStr(kLblSwitch,TxtList.missionDaliy)
    end
	local lbl = tolua.cast(obj:egGetWidgetByName(kLblMapName),"Label")
	lbl:setText(scene_data[obj._areaid].name)
	print(scene_data[obj._areaid].name)
	local w = lbl:getSize().width
	if w > kMaxLen then
		local offset = w - kMaxLen
		local imgbg = obj:egGetWidgetByName(kImgNameBg)
		local imgchain = obj:egGetWidgetByName(kImgChain)
		imgbg:setSize(CCSizeMake(imgbg:getSize().width + offset,imgbg:getSize().height))
		imgchain:setSize(CCSizeMake(imgchain:getSize().width + offset,imgchain:getSize().height))
	end
end
--������ͨ����
function __missionlayer.loadNormalMission(obj)
    obj._normalList = {}
    local areaid = obj._areaid 
    local nmData = MissionHelper.getNormalMission(areaid)
    local panel = obj:egGetWidgetByName(kPanelN)
    for key,stageid in ipairs(nmData) do
        local mission = Mission.new(areaid,stageid)
        table.insert(obj._normalList,mission)
        local size = mission:egNode():getSize()
        local pvestage = pveQuery.queryStage(areaid,stageid)
        mission:egNode():setPosition(ccp(pvestage.x - size.width/2,pvestage.y- size.height/2))
        panel:addChild(mission:egNode())
    end
	obj:egHideWidget(kImgExploreBg)
end

--�����ճ�����
function __missionlayer.loadDayMission(obj)
    obj._dailyList = {}
    local areaid = obj._areaid 
	local dmdata = MissionHelper.getResMission(areaid)
    local panel = obj:egGetWidgetByName(kPanelD)
    for key,stageid  in ipairs(dmdata) do
        local mission = Mission.new(areaid,stageid,true)
        table.insert(obj._dailyList,mission)
        local size = mission:egNode():getSize()
        if not stageid then stageid = missionData.day_mission[areaid][groupIdx].mis_array[1] end
        local pvestage = pveQuery.queryStage(areaid,stageid)
        mission:egNode():setPosition(ccp(pvestage.x - size.width/2,pvestage.y- size.height/2))
        panel:addChild(mission:egNode())
    end
    obj:egShowWidget(kImgExploreBg)
	if account_data.pveNextSt <= os.time() then
		account_data.pveUsedCnt  = 0
		account_data.pveNextSt = Funs.getTimeWithHMS(numDef.pveRefreshUTH,numDef.pveRefreshUTM,0,account_data.scOffsetTime)
	end
	obj:egSetLabelStr(kLblExploreNum,string.format("%d/%d",account_data.pveUsedCnt,VipLvUp[account_data.vip or 0].pveCnt or 0))
end
--��ʾ��ͨ����
function __missionlayer.showNormalMission(obj,show)
	
    if show and not obj._normalList then
        obj:loadNormalMission()
    end
	for key,mission in ipairs(obj._normalList) do
		mission:showMission(show)
    end
    if show then obj:egHideWidget(kImgExploreBg) end
end
--��ʾ�ճ�����
function __missionlayer.showDayMission(obj,show)
	
    if show and not obj._dailyList then
        obj:loadDayMission()
	end
	for key,mission in ipairs(obj._dailyList) do
		mission:showMission(show)
	end
    if show then obj:egShowWidget(kImgExploreBg) end
end
--�����л���ť����¼�
function __missionlayer.doClickSwitch(obj,sender)
        sender:setTouchEnabled(false)
         SoundHelper.playEffect(SoundList.click_shop_goods)
        if MissionHelper.showDaily then
            MissionHelper.showDaily = nil
            obj:egShowWidget(kPanelN)
	        obj:egHideWidget(kPanelD)
			MissionHelper.groupIdx = false
            obj:showNormalMission(true)
            obj:showDayMission(false)
			
			obj:egSetLabelStr(kLblSwitch,TxtList.missionDaliy)
        else
			--obj:egSetLabelStr(kLblSwitch,TxtList.missionNormal)
			obj:egSetLabelStr(kLblSwitch,TxtList.returns)
            obj:egShowWidget(kPanelD)
	        obj:egHideWidget(kPanelN)
			MissionHelper.groupIdx = true
            MissionHelper.showDaily = true
            obj:showNormalMission(false)
            obj:showDayMission(true)
        end
        sender:setTouchEnabled(true)
end
--�����л���ť
function __missionlayer.bindSwitchListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:doClickSwitch(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnSwitch,nil,nil,touchEnded,touchCanceled)
end
--�رհ�ť
function __missionlayer.bindBackListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		obj:egNode():removeAllChildrenWithCleanup(true)
		local scene = worldmapScene.new()
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
MissionLayer={}
function MissionLayer.new(d_data)
    local obj =  TouchWidget.new(JsonList.pveMap)
    table_aux.unpackTo(__missionlayer, obj)
    obj:init(d_data)
    obj:bindBackListener()
    obj:bindSwitchListener()
    return obj
end


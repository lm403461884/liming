local kImagStar = {"star_1","star_2","star_3"}
local kBtnMission = "btn_misssion"
local kImgNew = "img_new"
local kbtmimg_y =100
local __mission = {}
function __mission.init(obj,areaid,stageid,isResMission)
    obj._areaid = areaid
    obj._stageid = stageid
    obj._isResMission= isResMission --�Ƿ�����Դ��̽�ؿ�
	obj:egSetWidgetEnabled(kBtnMission,true)
	obj:egHideWidget(kImgNew)
	obj:loadMissionData()
end
function __mission.loadMissionData(obj)
	if not obj._stageid then return end
	if obj._isResMission then
		MissionHelper.groupIdx = obj._isResMission--��������û��������ID
	end
	MissionHelper.areaId = obj._areaid --������������
	MissionHelper.stageId = obj._stageid --����ID
	obj._s_data = pveQuery.queryStage(obj._areaid,obj._stageid)
	obj:egChangeBtnImg(kBtnMission,obj._s_data.tagPic[3],obj._s_data.tagPic[3],obj._s_data.tagPic[3],UI_TEX_TYPE_PLIST)
	local stageitem = account_data.unlockedPVE[obj._areaid][obj._stageid]
	obj._costAct = obj._s_data.costAct
	
	if stageitem then
	    if stageitem.first and not obj._isResMission then obj._costAct = 0 end
		obj._unlocked = true
		obj:egChangeBtnImg(kBtnMission,obj._s_data.tagPic[1],obj._s_data.tagPic[2],obj._s_data.tagPic[3],UI_TEX_TYPE_PLIST)
		for idx=1,stageitem.stars do
			obj:egShowWidget(kImagStar[idx])
			obj:egChangeImg(kImagStar[idx],ImageList.star,UI_TEX_TYPE_PLIST)
		end
		obj:egSetWidgetEnabled(kBtnMission,true)
		if (stageitem.first and not obj._isResMission) or (obj._isResMission and stageitem.stars == 0) then
				obj:egShowWidget(kImgNew)
				local scaleto1 = CCScaleTo:create(0.5,0.9)
				local moveby1 = CCMoveBy:create(0.5,ccp(0,-5))
				local spawn1 = CCSpawn:createWithTwoActions(scaleto1,moveby1)
				local scaleto2 = CCScaleTo:create(0.5,1)
				local moveby2 = CCMoveBy:create(0.5,ccp(0,5))
				local spawn2 = CCSpawn:createWithTwoActions(scaleto2,moveby2)
				local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
				local repeatever = CCRepeatForever:create(sequence)
				local widget = obj:egGetWidgetByName(kImgNew)
				widget:runAction(repeatever)
		end
	end
end
--�豸������ʾ����,��������л���ʾ����ʱ����
function __mission.showMission(obj,show)
    obj:egNode():setVisible(show)
    if obj._unlocked then
        obj:egSetWidgetTouchEnabled(kBtnMission,show)
    end
end
--����ť����¼�
function __mission.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		if account_data.pveNextSt <= os.time() then
			account_data.pveUsedCnt  = 0
			account_data.pveNextSt = Funs.getTimeWithHMS(numDef.pveRefreshUTH,numDef.pveRefreshUTM,0,account_data.scOffsetTime)
		end
		if account_data.unlockedPVE[obj._areaid][obj._stageid] == nil then
			local txt = pveQuery.queryStage(obj._areaid,obj._stageid).name
			local pos = sender:getTouchEndPos()
			showmissontipsinfo(txt,pos.x,pos.y-kbtmimg_y,obj._areaid,obj._stageid,ccp(0.5,0.5))
			sender:setTouchEnabled(true)
		elseif obj._isResMission and account_data.pveUsedCnt >= (VipLvUp[account_data.vip or 0].pveCnt or 0) then
			local pos = sender:getTouchEndPos()
			 showPopTxt(TxtList.maxPveCnt,pos.x,pos.y,ccp(0.5,0.5))
			 sender:setTouchEnabled(true)
		else
			if obj._costAct > account_data.actPt then
				local pos = sender:getTouchEndPos()
				 showPopTxt(string.format("%s %d",TxtList.needActPt,obj._costAct),pos.x,pos.y,ccp(0.5,0.5))
				 sender:setTouchEnabled(true)
			else
				local scene = CCDirector:sharedDirector():getRunningScene()
				if scene:getChildByTag(UILv.popLayer) then
					sender:setTouchEnabled(true)
				else
					SoundHelper.playEffect(SoundList.click_paper_open)
					local function callback()
						sender:setTouchEnabled(true)
					end
					if obj._isResMission then
						MissionHelper.groupIdx = obj._isResMission--��������û��������ID
					end
					MissionHelper.areaId = obj._areaid --������������
					MissionHelper.stageId = obj._stageid --����ID
					--2014/08/07 ����������� 
					pveCalc.showPveStory(obj._areaid,obj._stageid,account_data,callback)
				end
			end
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnMission,nil,nil,touchEnded,touchCanceled)
end
Mission={}
function Mission.new(areaid,stageid,isResMission)
    local obj = {}
    CocosWidget.install(obj,JsonList.pveMission)
    table_aux.unpackTo(__mission, obj)
    obj:init(areaid,stageid,isResMission)
    obj:bindClickListener()
    return obj
end
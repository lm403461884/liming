local kLblLv = "lbl_lv"
local kImgLv = "img_lv"
local kLblNum = "lbl_num"
local kImgItem = "img_item"
local __monsterhead = {}
function __monsterhead.init(obj,monsterid,num,d_data)
    local s_cfg = monster_data.getConfig(monsterid)
    local lv = d_data.monsterLvLook[monsterid]%256
    obj:egChangeImg(kImgItem,s_cfg.headPic,UI_TEX_TYPE_PLIST)
    --obj:egSetBMLabelStr(kLblLv,lv)
   -- obj:egSetBMLabelStr(kLblNum,num )
   obj:egHideWidget(kLblNum)
   obj:egHideWidget(kImgLv)
end
MonsterHead = {}
function MonsterHead.new(monsterid,num,d_data)
     local obj = {}
    CocosWidget.install(obj,JsonList.monsterHead)
    table_aux.unpackTo(__monsterhead, obj)
    obj:init(monsterid,num,d_data)
    return obj
end
local kLabelMissionName = "mission_name_lbl"
local kLabelHardVal = "lbl_hard_val"
local kLabelTeamCap = "lbl_team_cap"
local kLabelTeamCapVal = "lbl_team_caps"
local kImgArea = "img_area"

local kBtnStart = "btn_start"
local kBtnBack = "btn_back"
local kBtnSweep = "btn_sweep"
local kPanelLayer = "atk_mission_panel"
local kPanelSweep = "sweep_panel"
local kPanelStart = "start_panel"
local kPanelAward1 = "award_panel1"
local kPanelAward2 = "award_panel2"
local kPanelAward3 = "award_panel3"
local kPanelAward = "award_panels"
local kImgAwardBg = "img_award_bg"
local kImgAward = "img_award"
local kImgAwardQa = "img_equip_qa"
local kImgAwardBg2 = "img_award_bg2"
local kImgAward2 = "img_award2"
local kImgAwardQa2 = "img_equip_qa2"
--С��Ӣ�۸���
local kBtnChangeHero = "btn_change"
local kPanelSelect = "img_hero_select_bg"
local kHeroList = "scrollview"
local kLblChangHero = "lbl_change"
local kPanelBg = "panel_select_bg"
local kPanelHero = "hero_list"
local kPanelMonster = "monster_list"
local kLabelCost = "lbl_cost"
local kLabelSAct = "lbl_c_act"
local kLabelSJewel = "lbl_c_jewel"
local kImgSJewel = "img_c_jewel"
local kImgSAct = "img_c_act"
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kBrownColor = ccc3(83,49,22)
local kMaroonColor = ccc3(128,0,2)
local kMaxMonster = 5
local kMaxLoadNum = 2
local kCellW = 110
local kCellW1 = 150
local kCellH = 160
local __atkmission ={}
function __atkmission.init(obj,areaid,stageid)
    obj._areaid = areaid
    obj._stageid = stageid
    obj._s_data = pveQuery.queryStage(areaid,stageid)
    obj._costVal = obj._s_data.costAct
	obj._oldTeam = Funs.copy(account_data.team)
	obj._selected = false
	local pic = scene_data[obj._areaid].thumbPic
	obj:egChangeImg(kImgArea,pic,UI_TEX_TYPE_PLIST)
	obj._stars = account_data.unlockedPVE[areaid][stageid].stars or 0
	obj._suggestAtk = obj._s_data.suggestLv
	obj:egSetBMLabelStr(kLabelSAct,obj._costVal)
	if obj._stars < numDef.starsPerStage then --�������²�����ɨ������
		obj:egSetWidgetEnabled(kBtnSweep,false)
	end
	if  MissionHelper.groupIdx  then --�ճ�����
		obj._costJewel = numDef.jewelForSweepR
		obj._suggestAtk =  baseCalc.getDaysuggestLv(obj._areaid*100 + obj._stageid,account_data.digLv, obj._s_data.suggestLv) 
	else --��������
		if account_data.unlockedPVE[areaid][stageid].first then  
			obj._costVal = 0
		end
		obj._costJewel = numDef.jewelForSweep
	end
	if obj._costJewel == 0 then
		obj:egHideWidget(kImgSJewel)
		obj:egHideWidget(kLabelSJewel)
		local imgsact = obj:egGetWidgetByName(kImgSAct)
		imgsact:setPosition(ccp(70,imgsact:getPositionY()))
		imgsact:setScale(0.55)
		local lblsact = obj:egGetWidgetByName(kLabelSAct)
		lblsact:setPosition(ccp(150,lblsact:getPositionY()))
		lblsact:setScale(0.7)
	else
		obj:egSetBMLabelStr(kLabelSJewel,obj._costJewel)
		if obj._costJewel > account_data.jewel then  --���겻������죬���ɵ��
			obj:egSetWidgetColor(kLabelSJewel,kRedColor) 
		end
	end
	obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
    obj:egSetBMLabelStr(kLabelCost,obj._costVal)    
	obj._teamCap = RiskHelper.getTeamBp()
    obj:egSetLabelStr(kLabelMissionName,obj._s_data.name)
	obj:egSetLabelStr(kLabelHardVal,obj._suggestAtk)
	obj:egSetLabelStr(kLabelTeamCapVal,obj._teamCap)
	obj:egHideWidget(kPanelSelect)
	obj:egHideWidget(kHeroList)
	obj:egSetWidgetTouchEnabled(kPanelBg,false)
	if obj._teamCap >= obj._suggestAtk then obj:egSetWidgetColor(kLabelHardVal,kBrownColor) end
	obj:loadAward()
	obj:loadProbableAward()
    obj:loadHeros()
    obj:loadMonsters()
    obj:showWithAction()
end
--��ȡ������Ϣ
function __atkmission.getAwardResList(obj)
	local resList={}
	local heroMsgList = {}
	local expVal = obj._s_data.exp
	for idx = 1,7 do resList[idx] = 0 end
	if MissionHelper.groupIdx then
		resList[1],resList[3],resList[4],resList[5],resList[6],resList[7]=baseCalc.getDayRes(obj._areaid*100 + obj._stageid,account_data.digLv, obj._s_data.gold,obj._s_data.iron,obj._s_data.copper,obj._s_data.stoneR,obj._s_data.stoneB,obj._s_data.stoneD)
		heroMsgList = obj._s_data.heromessage or {}
		expVal = baseCalc.getDaypveExp(obj._areaid*100 + obj._stageid,account_data.digLv,obj._s_data.exp)
	else
		if account_data.unlockedPVE[obj._areaid][obj._stageid].first then
			for idx,coinname in pairs(KVariantList.coinType) do 
				resList[idx] = obj._s_data[coinname] or 0
			end
			heroMsgList = obj._s_data.heromessage or {}
		else --�ظ����Ѵ���Ĺؿ���ֻ�ܻ�ý�ң�������Դ�޷����
			resList[1] = obj._s_data.gold or 0
		end
	end
	return resList,heroMsgList,expVal
end
--���ص�һ�δ��������Ľ�����Ϣ
function __atkmission.loadAward(obj)
	obj._awardResList,obj._heroMsgList,obj._expVal = obj:getAwardResList()
	obj._award1w = 0
	obj._award2w = 0
	obj._award3w = 0
	local loadCnt = 0
    for idx,coinval in pairs(obj._awardResList) do
		local coinname = KVariantList.coinType[idx]
		if coinval > 0 then
			loadCnt = loadCnt+1
			local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,coinval))
			obj:addItemToAwardPanel(awarditem,loadCnt)
		end
	end
	for heroid,msgnum in pairs(obj._heroMsgList) do
	    loadCnt = loadCnt + 1
	    local heromsg = HeroMsg.new(heroid,string.format("%s%d",TxtList.numSymbol,msgnum))
		obj:addItemToAwardPanel(heromsg,loadCnt)
	end
	local expitem = AwardItem.new("exp",string.format("%s%d",TxtList.numSymbol,obj._expVal))
	 loadCnt = loadCnt + 1
	obj:addItemToAwardPanel(expitem,loadCnt)
	if loadCnt <= kMaxLoadNum then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panel1:getSize().height
		panel2:setVisible(false)
		panel3:setVisible(false)
	elseif loadCnt <= kMaxLoadNum*2 then
		local panel = obj:egGetWidgetByName(kPanelAward)
		local panel3 = obj:egGetWidgetByName(kPanelAward3)
		local panelsize = panel:getSize()
		local newh = panelsize.height - panel3:getSize().height
		panel3:setVisible(false)
	end
end
--���ؿ��ܵ���Ľ���
function __atkmission.loadProbableAward(obj)
    obj:egHideWidget(kImgAwardBg)
    obj:egHideWidget(kImgAward)
	obj:egHideWidget(kImgAwardQa)
    obj:egHideWidget(kImgAwardBg2)
    obj:egHideWidget(kImgAward2)
	obj:egHideWidget(kImgAwardQa2)
    if obj._s_data.subequip then
         local cnt = 0
         for key,item in ipairs(obj._s_data.subequip) do
             cnt = cnt + 1
			 local s_cfg = equipFuncs.getSubEquipCfg(item[1])
             if cnt == 1 then
                 obj:egShowWidget(kImgAwardBg)
                 obj:egShowWidget(kImgAward)
				 obj:egShowWidget(kImgAwardQa)
                 obj:egChangeImg(kImgAward,s_cfg.icon,UI_TEX_TYPE_PLIST)
				 obj:egSetWidgetColor(kImgAwardQa,KVariantList.equipColor[s_cfg.quality])
             elseif cnt==2 then
                 obj:egShowWidget(kImgAwardBg2)
                 obj:egShowWidget(kImgAward2)
				 obj:egShowWidget(kImgAwardQa2)
                 obj:egChangeImg(kImgAward2,s_cfg.icon,UI_TEX_TYPE_PLIST)
				 obj:egSetWidgetColor(kImgAwardQa2,KVariantList.equipColor[s_cfg.quality])
             end
         end  
    end   
end
function __atkmission.addItemToAwardPanel(obj,item,loadCnt)
    local margin = 0
	local awardsize = item:egNode():getSize()
	item:egNode():setSize(CCSizeMake(awardsize.width + margin,awardsize.height))
	if loadCnt <= kMaxLoadNum then
	    local panel1 = obj:egGetWidgetByName(kPanelAward1)
	    local size = panel1:getSize()
		panel1:addChild(item:egNode())
		obj._award1w = obj._award1w + awardsize.width
		if obj._award1w > size.width then
		    panel1:setScale(size.width/obj._award1w)
		end
	elseif loadCnt <= kMaxLoadNum*2 then
	    local panel2 = obj:egGetWidgetByName(kPanelAward2)
	    local size = panel2:getSize()
		panel2:addChild(item:egNode())
		obj._award2w = obj._award2w + awardsize.width
		if obj._award2w > size.width then
		    panel2:setScale(size.width/obj._award2w)
		end
	else
	    local panel3 = obj:egGetWidgetByName(kPanelAward3)
	    local size = panel3:getSize()
		panel3:addChild(item:egNode())
		obj._award3w = obj._award3w + awardsize.width
		if obj._award3w > size.width then
		    panel3:setScale(size.width/obj._award3w)
		end
	end
end
function __atkmission.loadHeros(obj)
    obj._teamheroitem = {}
    local panel  = obj:egGetWidgetByName(kPanelHero)
	
	for idx = 1,account_data.maxTeam do
		local heroid = account_data.team[idx] or 0
		local herolv = 0
		if heroid > 0 then herolv = account_data.heroList[heroid].lv end
		local heroHead = ExpeditionItem.new(heroid,nil,herolv)
		heroHead:setItemTouchEnabled(false)
		table.insert(obj._teamheroitem,heroHead)
		 panel:addChild(heroHead:egNode())
		if heroid > 0 then
			obj:teamMemberClicked(heroHead)
		end
	end
	local neww = account_data.maxTeam * kCellW1
	local size = panel:getSize()
	if size.width > neww then
		panel:setPosition(ccp((size.width - neww )/2*panel:getScale() + panel:getPositionX(),panel:getPositionY()))
		panel:setSize(CCSizeMake(neww,size.height))
	end
end

function __atkmission.getMonsters(obj)
    local tb = {}
    for pos,monsterid in pairs(obj._s_data.creatureList) do
        if not tb[monsterid] then tb[monsterid] = 1 
        else tb[monsterid] = tb[monsterid] + 1 end
    end
    return tb
end
function __atkmission.loadMonsters(obj)
    local monsters = obj:getMonsters()
    local panel =obj:egGetWidgetByName(kPanelMonster)
    local cnt = 0
    for monsterid,num in pairs(monsters) do
		cnt = cnt + 1
        local monsterHead = MonsterHead.new(monsterid,num,obj._s_data)
        panel:addChild(monsterHead:egNode())
		if cnt >= kMaxMonster then break end
    end
    local size = panel:getSize()
    local neww = cnt*kCellW
	panel:setPosition(ccp((size.width - neww)/2 + panel:getPositionX(),panel:getPositionY()))
    panel:setSize(CCSizeMake(neww,size.height))
end
--ȡ��С��Ӣ��
function __atkmission.removeTeamHero(obj,heroid,posx,posy)
    if #account_data.team == 1 then
        showPopTxt(TxtList.teamEmpty,posx,posy,ccp(0.6,0.6))
    else
        local panel = obj:egGetWidgetByName(kPanelHero)
        for idx,Theroid in ipairs(account_data.team) do
            if Theroid == heroid then
                table.remove(account_data.team,idx)
                panel:removeChild(obj._teamheroitem[idx]:egNode(),true)
				table.remove(obj._teamheroitem,idx)
                local heroHead = ExpeditionItem.new(0)
                table.insert(obj._teamheroitem,heroHead)
                panel:addChild(heroHead:egNode())
                obj._heroitem[heroid]:showJoinFlag(false)
				break
           end
       end
	   obj._teamCap = RiskHelper.getTeamBp()--����С��ս����
       obj:egSetLabelStr(kLabelTeamCapVal,obj._teamCap)
	   if obj._teamCap >= obj._suggestAtk then obj:egSetWidgetColor(kLabelHardVal,kBrownColor) 
	   else obj:egSetWidgetColor(kLabelHardVal,kMaroonColor) end
    end   
end
--����С��Ӣ��
function __atkmission.insertTeamHero(obj,heroid)
    table.insert(account_data.team,heroid)
	local heroitem = obj._teamheroitem[#account_data.team]
	heroitem:updateHeroInfo(heroid,nil,account_data.heroList[heroid].lv)
	heroitem:setItemTouchEnabled(true)
	obj:teamMemberClicked(heroitem)
	obj._teamCap = RiskHelper.getTeamBp()--����С��ս����
    obj:egSetLabelStr(kLabelTeamCapVal,obj._teamCap)
	if obj._teamCap >= obj._suggestAtk then obj:egSetWidgetColor(kLabelHardVal,kBrownColor) 
	else obj:egSetWidgetColor(kLabelHardVal,kMaroonColor) end
end
--���С��Ӣ��
function __atkmission.teamMemberClicked(obj,heroHead)
    local function callback(sender,posx,posy)
        local heroid = sender:getprop("heroid")
        obj:removeTeamHero(heroid,posx,posy)
    end
    heroHead:onItemClicked(callback)
end
--��ʾӢ��ѡ�����
function __atkmission.showPanelSelect(obj)
	obj:egShowWidget(kPanelSelect)
	obj:egShowWidget(kHeroList)
	if obj._selected then return end
    obj._selected = true
    obj._heroitem = {}
    local herolist = obj:egGetScrollView(kHeroList)
    local size = herolist:getSize()
    local heroAtkList = obj:getHeroAtkOrder()
    local maxRow = math.ceil(#heroAtkList/2)
    local newH = maxRow * kCellH
    if newH> size.height then
        herolist:setInnerContainerSize(CCSizeMake(size.width,newH))
    else
        newH = size.height    
    end
	herolist:jumpToTop()
    for idx,item in ipairs (heroAtkList) do
        local heroid = item[1]
        local heroitem = ExpeditionItem.new(heroid,nil,account_data.heroList[heroid].lv)
        obj._heroitem[heroid] = heroitem 
        local itemsize = heroitem:egNode():getSize()
        local row = math.ceil(idx/2)
        if idx%2 == 1 then
            heroitem:egNode():setPosition(ccp(0,newH-row*kCellH)) 
        else
            heroitem:egNode():setPosition(ccp(size.width-itemsize.width,newH-row*kCellH)) 
        end  
        obj:panelHeroClicked(heroitem)  
        herolist:addChild(heroitem:egNode())
    end
    for key,heroid in ipairs (account_data.team) do
        obj._heroitem[heroid]:showJoinFlag(true)
    end 
end
--Ӣ��ս��������
function __atkmission.getHeroAtkOrder(obj)
    local tb = {}
    for heroid,heroprop in pairs(account_data.heroList) do
        if not account_data.cbTeam[heroid] then
            table.insert(tb,{heroid, RiskHelper.getHeroBp( account_data.heroList[heroid],account_data)})
        end    
    end
    table.sort(tb,function(a,b) return (a[2]>b[2] or (a[2]==b[2] and a[1] > b[1])) end)
    return tb
end
--���ѡ����� Ӣ��
function __atkmission.panelHeroClicked(obj,heroitem)
    local function callback(sender,posx,posy)
        local isJoin = sender:getprop("joined")
        local heroid = sender:getprop("heroid")
        if isJoin then
            obj:removeTeamHero(heroid,posx,posy)
        else
            if #account_data.team == account_data.maxTeam then
                showPopTxt(TxtList.teamLimited,posx,posy,ccp(0.5,0.5))
            else
                 obj._heroitem[heroid]:showJoinFlag(true)
                 obj:insertTeamHero(heroid)
            end
        end
    end
    heroitem:onItemClicked(callback)
end


function __atkmission.hideWithAction(obj)
    local function callback()
        if obj._onloaded then obj._onloaded() end
        obj:egRemoveSelf()
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __atkmission.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     baseWidget:runAction(spawn)
end

--��ʼPVEս��
function __atkmission.bindStartListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		if  MissionHelper.groupIdx  then --�ճ�����
			account_data.pveUsedCnt = account_data.pveUsedCnt + 1
		end
		AccountHelper:useActPt(obj._costVal)
		----------------------------------------------------------
		local scene = AtkScene.new(obj._areaid,obj._stageid)
		scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnStart,nil,nil,touchEnded,touchCanceled)
end
--��ʼPVEɨ��
function __atkmission.bindSweepListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		local function callback()
			sender:setTouchEnabled(true)
		end
		if obj._costJewel > account_data.jewel then
			showPopCharge(obj._costJewel,callback)
		else
			if  MissionHelper.groupIdx  then --�ճ�����
				account_data.pveUsedCnt = account_data.pveUsedCnt + 1
			end
			account_data.jewel = account_data.jewel - obj._costJewel
			AccountHelper:useActPt(obj._costVal)
			----------------------------------------------------------
			obj:showSweepResult()
			sender:setTouchEnabled(true)
			obj:egRemoveSelf()
			--�����㴰��
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnSweep,nil,nil,touchEnded,touchCanceled)
end
function __atkmission.showSweepResult(obj)
	obj._d_data = RiskHelper.getAtkSceneData(obj._areaid,obj._stageid)
	obj._d_data.oldheroList = {} --��¼Ӣ��Ѫ��
	for key,heroid in ipairs(obj._d_data.teamList) do
        local herodata = obj._d_data.heroList[heroid]
        obj._d_data.oldheroList[heroid] =Funs.copy(herodata)
        obj._d_data.oldheroList[heroid].curhp = herodata.hp
    end
	local stars = nil
	local boxArr = nil
	if MissionHelper.groupIdx then --��Դ��̽����
		stars,boxArr = baseCalc.getSweepStarCH(obj._suggestAtk,obj._teamCap)
	else
		stars,boxArr = baseCalc.getSweepStar(obj._suggestAtk,obj._teamCap) --���㱦�����
	end
	for boxtype,boxnum in ipairs(boxArr) do
	    obj._d_data.battleBoxCnt = obj._d_data.battleBoxCnt + boxnum
		for idx = 1,boxnum do
			local awardRes = baseCalc.treasureBox(account_data,boxtype)
			local valnum = awardRes[3] or 0
			local awardtype = awardRes[1] or 0
			local subtype = awardRes[2] or 0
			if awardtype == 1 then --��Դ����
				local cointype = KVariantList.coinType[subtype]
				battleProgress.gainRes[cointype] = (battleProgress.gainRes[cointype] or 0 ) + valnum
			elseif awardtype == 2 then --��Ϣ����
				battleProgress.gainHeroMsg[subtype] = (battleProgress.gainHeroMsg[subtype] or 0) + valnum
			elseif awardtype == 3 then
				table.insert(battleProgress.gainEquip,equipFuncs.getSubEquipId(subtype,valnum,equipFuncs.getSubEquipCfg(subtype,"quality")))
			end	
			table.insert(obj._d_data.battleBox[boxtype],awardRes)
		end
	end
	battleProgress.stars =  stars
	AccountHelper:unlock(kStateBpResult)
	BPResult = {}
	BPResult.stars = stars
	for cointype,coinval in pairs(obj._awardResList) do
		local coinname = KVariantList.coinType[cointype]
		 BPResult[coinname] = math.floor(coinval * BPResult.stars /numDef.starsPerStage)
		 battleProgress.gainRes[coinname] = (battleProgress.gainRes[coinname] or 0 ) + BPResult[coinname]
		 account_data[coinname]= account_data[coinname]+ BPResult[coinname]
	end
	SendMsg[934014](obj._costJewel,battleProgress)
	BPResult.teamExp =baseCalc.getTeamExp( math.floor( BPResult.stars / numDef.starsPerStage * obj._expVal), obj._d_data.teamList,obj._d_data.heroList,account_data.digLv) 
	RiskHelper.updateHeroExp(BPResult.teamExp,obj._d_data.btFlag)
    local scorelayer = BattleResultLayer.new(obj._d_data)
	
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(scorelayer:egNode(),UILv.popLayer,UILv.popLayer)
end
--�������С��Ӣ��
function __atkmission.bindChangeListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_shop_goods)
		sender:setTouchEnabled(false)
		 if obj:egGetLabelStr(kLblChangHero) == TxtList.btnOK then
			obj:egSetWidgetTouchEnabled(kPanelBg,false)
			obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
			for idx,herodata in ipairs(obj._teamheroitem) do 
                herodata:setItemTouchEnabled(false)
            end
			if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
				SendMsg[934003](account_data.team)
                obj._oldTeam = Funs.copy(account_data.team)
			end
            obj:egHideWidget(kPanelSelect)
			obj:egHideWidget(kHeroList)
		 else
			obj:egSetWidgetTouchEnabled(kPanelBg,true)
			obj:egSetLabelStr(kLblChangHero,TxtList.btnOK)
			for idx,herodata in ipairs(obj._teamheroitem) do 
                herodata:setItemTouchEnabled(true)
            end
			obj:showPanelSelect()
		 end  
		 sender:setTouchEnabled(true)
    end
    local function touchCanceled(sender)
        if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end	
    end
    obj:egBindTouch(kBtnChangeHero,nil,nil,touchEnded,touchCanceled)
end
--ѡС��ʱ�󱳾�ͼƬ����¼�
function __atkmission.bindBgListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
		obj:egSetLabelStr(kLblChangHero,TxtList.changeHero)
		for idx,herodata in ipairs(obj._teamheroitem) do 
            herodata:setItemTouchEnabled(false)
        end
		if not Funs.isTbEqual(obj._oldTeam,account_data.team)  then
			SendMsg[934003](account_data.team)
            obj._oldTeam = Funs.copy(account_data.team)
		end
        obj:egHideWidget(kPanelSelect)
		obj:egHideWidget(kHeroList)
    end
    local function touchCanceled(sender)
        if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end	
    end
    obj:egBindTouch(kPanelBg,nil,nil,touchEnded,touchCanceled)
end
function __atkmission.bindBackListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egSetWidgetTouchEnabled(kBtnCancel,false)
        SoundHelper.playEffect(SoundList.click_paper_close)
        for idx,heroids in ipairs(obj._oldTeam) do
            if heroids ~= account_data.team[idx] or #obj._oldTeam ~= #account_data.team then
                SendMsg[934003](account_data.team)
                obj._oldTeam = Funs.copy(account_data.team)
                break
            end
        end
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

AtkMission={}
function AtkMission.new(areaid,stageid,onloaded)
     local obj =  TouchWidget.new(JsonList.cofcAtkMission)
    table_aux.unpackTo(__atkmission, obj)
    obj._onloaded = onloaded
    obj:init(areaid,stageid)
    obj:bindStartListener()
	obj:bindBgListener()
	obj:bindSweepListener()
	obj:bindChangeListener()
    obj:bindBackListener()
    return obj
end
function showAtkMission(areaid,stageid,onloaded)
        local layer = AtkMission.new(areaid,stageid,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

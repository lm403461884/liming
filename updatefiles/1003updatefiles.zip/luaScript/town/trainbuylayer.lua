local kBtnClose= "btn_close"
local kBtnLeft = "btn_left"
local kBtnRight = "btn_right"
local kPageTrain = "train_page"
local kPanelLayer = "buy_panel"
local kLblNotice = "lbl_notice"

local __buytrainlayer={}
--��ȡδ������б�
function __buytrainlayer.getunOwnTrainIdList(obj)
    local unowntb = {}
    for key,val in pairs(train.def ) do
        if not obj._d_data.train[val] then
             table.insert(unowntb,val)
        end
    end
    table.sort(unowntb)
    return unowntb
end
function __buytrainlayer.init(obj,d_data)
    obj._d_data = d_data
    obj._trainList = obj:getunOwnTrainIdList()
    if #obj._trainList == 0 then
        obj:egShowWidget(kLblNotice)
        obj:egHideWidget(kBtnLeft)
        obj:egHideWidget(kBtnRight)
    else
        obj:egHideWidget(kLblNotice)
        obj._trainInfos = {}
        obj._selectedIdx = nil
        local widget = obj:egGetWidgetByName(kPageTrain)
        local pageview = tolua.cast(widget,"PageView")
        for idx,trainid in ipairs(obj._trainList) do
            local traininfo = TrainInfo.new(trainid)
            local layout = tolua.cast(traininfo:egNode(),"Layout")
            layout:setPosition(ccp(0,0))
            pageview:addPage(layout)
            obj._trainInfos[idx] = traininfo
			obj:bindClickEventToTrainInfo(traininfo)
        end
        obj:showTrainAt(1)
        local function pageViewEvent(sender, eventType)
            if eventType == PAGEVIEW_EVENT_TURNING then
                local pageView = tolua.cast(sender, "PageView")
                obj:showTrainAt(pageView:getCurPageIndex() + 1)
            end
        end 
        pageview:addEventListenerPageView(pageViewEvent)
    end
    obj:showWithAction()
end
function __buytrainlayer.showTrainAt(obj,idx)
    if obj._selectedIdx ~= idx then
		obj._trainInfos[idx]:reloadData()
        obj._selectedIdx = idx
        if obj._trainList[idx-1] then obj:egShowWidget(kBtnLeft) 
        else obj:egHideWidget(kBtnLeft)  end
        if obj._trainList[idx+1] then obj:egShowWidget(kBtnRight) 
        else obj:egHideWidget(kBtnRight)  end   
    end
end
--�������
function __buytrainlayer.bindClickEventToTrainInfo(obj,traininfo)
	local function clickCallBack(sender)
	    obj:hideWithAction()
		local trainlyaer =  AccountHelper:get(kTrainLayer)
		trainlyaer:reloadTrains()
	end
	traininfo:onClicked(clickCallBack)
end
--[[
function __buytrainlayer.bindClickEventToTrainInfo(obj,traininfo)
	local function clickCallBack(sender)
		for key,val in ipairs(obj._trainList) do
			if val == sender:getTrainID() then
				table.remove(obj._trainList,key)
				table.remove(obj._trainInfos,key)
				local widget = obj:egGetWidgetByName(kPageTrain)
				local pageview = tolua.cast(widget,"PageView")
				pageview:removePageAtIndex(key-1)
				if key > #obj._trainList then key = key-1 end
				if obj._trainList[key] then 
					obj:showTrainAt(key) 
				else
					obj:egShowWidget(kLblNotice)
					obj:egHideWidget(kBtnLeft)
					obj:egHideWidget(kBtnRight)
				end
			end
		end
	end
	traininfo:onClicked(clickCallBack)
end
--]]
--�������
function __buytrainlayer.bindCloseListener(obj)
     local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
		local trainlyaer =  AccountHelper:get(kTrainLayer)
		trainlyaer:reloadTrains()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
function __buytrainlayer.bindLeftListener(obj)
     local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egHideWidget(kBtnLeft)
		local idx = obj._selectedIdx - 1
		if idx > 0 then
		    local widget = obj:egGetWidgetByName(kPageTrain)
            local pageview = tolua.cast(widget,"PageView")
            pageview:scrollToPage(idx-1)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnLeft,nil,nil,touchEnded,touchCanceled)
end
function __buytrainlayer.bindRightListener(obj)
     local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egHideWidget(kBtnRight)
		local idx = obj._selectedIdx + 1
		if idx <= #obj._trainList then
		    local widget = obj:egGetWidgetByName(kPageTrain)
            local pageview = tolua.cast(widget,"PageView")
            pageview:scrollToPage(idx-1)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnRight,nil,nil,touchEnded,touchCanceled)
end
function __buytrainlayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
		baseWidget:runAction(sequece)
	else
		baseWidget:runAction(spawn)
	end
end
function __buytrainlayer.hideWithAction(obj,callbackfunc)
    local function callback()
			AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
BuyTrainLayer = {}
function BuyTrainLayer.new(d_data,onloaded)
    local obj = TouchWidget.new(JsonList.trainBuyLayer)
    table_aux.unpackTo(__buytrainlayer, obj)
    obj._onloaded = onloaded
    obj:init(d_data)
    obj:bindCloseListener()
	obj:bindRightListener()
	obj:bindLeftListener()
    AccountHelper:lock(kStatePrompt)--��ʾ����ҳ��ʱ����������Ϣ��ʾ
    return obj
end
function showTrainMarket(onloaded)
    local layer = BuyTrainLayer.new(account_data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
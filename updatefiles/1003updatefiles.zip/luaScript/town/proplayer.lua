local kOillbl = "own_oil_val"
--local kMaxOillbl = "own_oil_max"
local kOilBar = "own_oil_bar"

local kJewellbl = "own_jewel_val"
local kBtnJeweadd = "btn_jewel_add"

local kGoldlbl = "own_gold_val"
--local kMaxGoldlbl = "own_gold_max"
local kGoldBar = "own_gold_bar"

local kActlbl = "own_act_val"
local kActBar = "own_act_bar"
--local kMaxActlbl= "own_act_max"
local kBtnActadd= "own_act_add"

local kMaxNumDefault = 10000


local __proplayer={}
function __proplayer.init(obj,d_data)
    if not d_data then d_data = account_data end
    obj._d_data = d_data
    obj._act =obj._d_data.actPt
    obj._oil = obj._d_data.oil
    obj._jewel = obj._d_data.jewel
    obj._gold = obj._d_data.gold
    
    obj._maxGold = obj._d_data.maxGold or kMaxNumDefault
    obj._maxOil = obj._d_data.maxOil or kMaxNumDefault
    obj._maxAct = obj._d_data.maxActPt 
    
    obj:egSetBMLabelStr(kActlbl,string.format("%d%s%d",obj._act,"/",obj._maxAct))
    obj:egSetBMLabelStr(kOillbl,Funs.formatNum(obj._oil))
    obj:egSetBMLabelStr(kJewellbl,Funs.formatNum(obj._jewel))
    obj:egSetBMLabelStr(kGoldlbl,Funs.formatNum(obj._gold))
    
    obj:egSetBarPercent(kOilBar, obj._oil*100/obj._maxOil)
    obj:egSetBarPercent(kGoldBar,obj._gold*100/obj._maxGold)
    obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
    
     obj:egBindTouch(kBtnActadd,nil,nil,obj._callback1,nil) 
     obj:egBindTouch(kBtnJeweadd,nil,nil,obj._callback2,nil)
    
end
function __proplayer.getAddVal(obj,old,new)
	local val = new-old
	if val > 0 then
		val = math.ceil(val/10)
	else
		val = math.floor(val/10)
	end
	return val
end
function __proplayer.activeUpdate(obj)
    local function updateFunc()
     if obj._act ~= obj._d_data.actPt then
        obj._act = obj._act + obj:getAddVal(obj._act,obj._d_data.actPt)
        obj:egSetBMLabelStr(kActlbl,string.format("%d%s%d",obj._act,"/",obj._maxAct))
        obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
    end
    if obj._maxAct ~= obj._d_data.maxActPt then
       obj._maxAct = obj._d_data.maxActPt 
       obj:egSetBMLabelStr(kActlbl,string.format("%d%s%d",obj._act,"/",obj._maxAct))
       obj:egSetBarPercent(kActBar,obj._act*100/obj._maxAct)
     end
     
     if obj._oil ~= obj._d_data.oil then  
        obj._oil = obj._oil +  obj:getAddVal(obj._oil,obj._d_data.oil)
        obj:egSetBMLabelStr(kOillbl,Funs.formatNum(obj._oil))
        obj:egSetBarPercent(kOilBar, obj._oil*100/obj._maxOil)
     end
      if obj._maxOil ~= (obj._d_data.maxOil or kMaxNumDefault) then  
        obj._maxOil = (obj._d_data.maxOil or kMaxNumDefault) 
        obj:egSetBarPercent(kOilBar, obj._oil*100/obj._maxOil)
     end
     if obj._jewel ~= obj._d_data.jewel then
        obj._jewel =  obj._jewel + obj:getAddVal(obj._jewel,obj._d_data.jewel)
        obj:egSetBMLabelStr(kJewellbl,Funs.formatNum(obj._jewel))
     end
     
     if obj._gold ~= obj._d_data.gold then
        obj._gold = obj._gold + obj:getAddVal(obj._gold,obj._d_data.gold)
        obj:egSetBMLabelStr(kGoldlbl,Funs.formatNum(obj._gold))
        obj:egSetBarPercent(kGoldBar,obj._gold*100/obj._maxGold)
     end
     if obj._maxGold ~= (obj._d_data.maxGold or kMaxNumDefault) then
        obj._maxGold = (obj._d_data.maxGold or kMaxNumDefault)
        --obj:egSetBMLabelStr(kMaxGoldlbl,Funs.formatNum(obj._maxGold))
        obj:egSetBarPercent(kGoldBar,obj._gold*100/obj._maxGold)
     end 
    end
    obj:egBindUpdate(updateFunc)
end
PropLayer = {}
function PropLayer.new(d_data,callback1,callback2)
    local obj = {}
    CocosWidget.install(obj,JsonList.propLayer)
    table_aux.unpackTo(__proplayer, obj)
    obj._callback1=callback1
    obj._callback2=callback2
    obj:init(d_data)
    obj:activeUpdate()
    return obj
end
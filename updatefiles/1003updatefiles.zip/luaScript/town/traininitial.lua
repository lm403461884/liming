local kBtnOil = "btn_oil"
local kBtnGold = "btn_gold"
local kBtnDig = "btn_dig"
local kImgNoteFunc = "img_note_func"
local kImgNote = "img_note"
local kPanelDig = "dig_panel"
local kPanelOil = "oil_panel"
local kPanelGold = "gold_panel"
local kGoldZorder = 2
local kOilZorder = 3
local kPromptZorder = 4
local kMoveDistance = 100
local kRedColor = ccc3(245,100,100)
local kWhiteColor = ccc3(255,255,255)
local kScale1 = 1.3
local kScale2 = 1.5
local kInterval1 = 1
local __traininitial={}
-----------------------------------------------------
--��ͷ
----------------------------------------------------
local trainid = 0
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	--obj:egShowWidget(kImgNoteFunc)
	--obj:bindFuncListener()
	obj:bindImgHeadListener()
	obj:bindHeadLvUpListener()
end
--�ж��Ƿ����������������������
__traininitial[trainid].hasNewArea=function(obj)
	for areaID, pveArea in pairs(account_data.unlockedPVE) do
		if areaID ~= account_data.worldAreaID then
			for k, v in pairs(pveArea) do
				if type(v) == 'table' and v.stars == 0 then
					return true
				end
			end
		end
	end
	return false
end
--�����������������ʾ
__traininitial[trainid].bindFuncListener=function(obj)
	obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	obj._noteFuncImg:setVisible(false)
	obj._hasNewFunc = false
	local function update()
	    if not obj._canUpdate then
		    local hasNewFunc = obj:hasNewArea()
		    if obj._hasNewFunc ~= hasNewFunc then
			    obj._hasNewFunc = hasNewFunc
			    obj._noteFuncImg:setVisible(obj._hasNewFunc)
			    if obj._hasNewFunc then
				    obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
			    else
				    obj._noteFuncImg:stopAllActions()
			    end
		    end
		elseif obj._hasNewFunc then --�����������ʱ������������ʾ 
            obj._hasNewFunc = false
            obj._noteFuncImg:setVisible(false)
            obj._noteFuncImg:stopAllActions()   
		end    
	end
	obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
------------------------------------------------------------------
--��β
----------------------------------------------------
local trainid = 99
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNoteFunc)
	obj:bindFuncListener()
end
--�ж��Ƿ��п��Թ���ĳ���
__traininitial[trainid].hasNewTrain=function(obj)
    obj._allBought = true
	for key,val in pairs(train.def ) do
        if not account_data.train[val] then
            obj._allBought = false
            local traindata = train.config[val]
			local s_cfg = traindata.research[1]
			local licence = s_cfg.licence or 1
			if licence <= account_data.digLv then return true end
        end
    end
	return false
end
--�³�����ʾ
__traininitial[trainid].bindFuncListener=function(obj)
	obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	obj._noteFuncImg:setVisible(false)
	obj._hasNewFunc = false
	local function update()
		local hasNewFunc = obj:hasNewTrain()
		if obj._hasNewFunc ~= hasNewFunc then
			obj._hasNewFunc = hasNewFunc
			obj._noteFuncImg:setVisible(obj._hasNewFunc)
			if obj._hasNewFunc then
				obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
			else
				obj._noteFuncImg:stopAllActions()
			end
		end
		if obj._allBought then obj:egUnbindWidgetUpdate(kImgNoteFunc) end
	end
	obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
------------------------------------------------------------------
--���ﳵ��
----------------------------------------------------
local trainid = 6
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNoteFunc)
	obj:egShowWidget(kImgNote)
	obj:bindImgStateListener()
	obj:bindLvUpListener()
	obj:bindFuncListener()
end
--�ж��Ƿ��п��Թ���Ĺ���
__traininitial[trainid].hasNewMonster=function(obj)
    for monsterid,item in pairs(MonsterTrain) do
		local maxNum = item[obj._oldlv] or 0
		local ownNum = 0
		local ownData = account_data.monsterPool[monsterid]
		if ownData then ownNum = ownData.N end
		if ownNum < maxNum then return true end
    end
    return false
end
--�¹�����ʾ
__traininitial[trainid].bindFuncListener=function(obj)
	obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
	obj._noteFuncImg:setVisible(false)
	obj._hasNewFunc = false
	local function update()
		if not obj._canUpdate  then
			local hasNewFunc = obj:hasNewMonster()
			if obj._hasNewFunc ~= hasNewFunc then
				obj._hasNewFunc = hasNewFunc
				obj._noteFuncImg:setVisible(obj._hasNewFunc)
				if obj._hasNewFunc then
					obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
				else
					obj._noteFuncImg:stopAllActions()
				end
			end
	    elseif obj._hasNewFunc then --�����������ʱ�����ع�����ʾ
	        obj._hasNewFunc  = false
	        obj._noteFuncImg:setVisible(false)
	        obj._noteFuncImg:stopAllActions()
		end
	end
	obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
------------------------------------------------------------------
--�ھ���
----------------------------------------------------
local trainid = 2
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNote)
	obj:egShowWidget(kPanelDig)
	obj:egShowWidget(kPanelGold)
	obj._goldPanel = obj:egGetWidgetByName(kPanelGold)
	obj._digPanel = obj:egGetWidgetByName(kPanelDig)
	obj._goldPanel:setPosition(ccp(obj._digPanel:getPositionX(),obj._digPanel:getPositionY()))
	obj:bindGoldBtnListener()--Click Event
	obj:bindDigBtnListener()--Click Event
    if obj:getDigState() then
        obj._digPanel:setVisible(true)
		obj._goldPanel:setVisible(false)
		obj:egHideWidget(kBtnGold)
        obj:egShowWidget(kBtnDig)
		obj:scaleWidget(obj._digPanel,0.9,1,kInterval1)
    else
        obj._digPanel:setVisible(false)
        obj:egHideWidget(kBtnDig)
        obj:bindGoldListener() --timer
    end
	obj:bindImgStateListener()
	obj:bindLvUpListener()
	
end
__traininitial[trainid].bindGoldBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = DigScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnGold,nil,nil,touchEnded,nil)
end
__traininitial[trainid].bindDigBtnListener=function(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = DigScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnDig,nil,nil,touchEnded,nil)
end

--���ռ���Դ��ʾ
__traininitial[trainid].bindGoldListener=function(obj)
    obj._goldPanel:setVisible(false)
    obj:egHideWidget(kBtnGold)
	local function update()
	    local hasCollRes = obj:hasCollRes()
	    if hasCollRes then
	        obj:egUnbindWidgetUpdate(kBtnGold)
	        obj._goldPanel:setVisible(true)
	        obj:scaleWidget(obj._goldPanel,0.9,1,kInterval1)
	        obj:egShowWidget(kBtnGold)
	    end
	end
	obj:egBindWidgetUpdate(kBtnGold,update)
end
__traininitial[trainid].hasCollRes = function(obj)
    for key,resCar in ipairs(account_data.collectorList) do
		local targetMine = account_data.mileSpread[resCar.pos]
		if targetMine then
			if not targetMine.dt or targetMine.dt <= 0 then return true end
		end
    end
    return false
end
__traininitial[trainid].isMineRemovable = function(obj,idx,digTrace,w,h)
    if idx > 0 and digTrace[idx] then return false end
    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  digTrace[idx_l] then  return true end--����������ھ�
    return false
end
--�ھ���ʾ
__traininitial[trainid].getDigState=function(obj)
    if account_data.digPt ==account_data.masDigPt  then return true end
    local w,h = scene_data.getWH(account_data.sceneID, account_data.sceneLv)
    for key,val in pairs(account_data.mileSpread) do
        if obj:isMineRemovable(key,account_data.digTrace,w,h) then 
            return false
        end
    end
    return true
end
------------------------------------------------------------------
--���߳���
----------------------------------------------------
local trainid = 3
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNote)
	obj:bindImgStateListener()
	obj:bindLvUpListener()
end
--------------------------------------------------------------------
--װ������
---------------------------------------------------------------------
local trainid = 8 
__traininitial[trainid] = {}
__traininitial[trainid].initSelfData = function(obj)
    obj:egShowWidget(kImgNoteFunc)
	obj:egShowWidget(kImgNote)
	obj:bindImgStateListener()
	obj:bindLvUpListener()
	obj:bindFuncListener()
end
--�ж��Ƿ��п�������װ��
__traininitial[trainid].hasEquipLvUp = function (obj)
    for eid,item in pairs (account_data.equipments) do
        local curlv,curqa = equipFuncs.getEquipQL(eid, account_data)
        if equipFuncs.getData(eid,curlv+1) then --����һ������
			local lvupdata = equipFuncs.getData(eid,curlv) --��������
            local heroid = equipFuncs.getHeroID(eid)
            local herolv = 1
            for _,item in ipairs(account_data.heroList) do 
                if item.type == heroid then herolv = item.lv end
				break
            end
			--Ӣ�۵ȼ��Ƿ�����
            if lvupdata.hlv + 1 <= herolv then return true end
        end
    end
    return false
end

__traininitial[trainid].bindFuncListener = function(obj)
    obj._noteFuncImg = tolua.cast(obj:egGetWidgetByName(kImgNoteFunc),"ImageView")
    obj._noteFuncImg:setVisible(false)
    obj._hasNewFunc = false
    local function update()
        if not obj._canUpdate then
            local hasNewFunc = obj:hasEquipLvUp()
            if  obj._hasNewFunc ~= hasNewFunc then
                obj._hasNewFunc = hasNewFunc
                obj._noteFuncImg:setVisible(obj._hasNewFunc)
                if obj._hasNewFunc then
                    obj:scaleWidget(obj._noteFuncImg,kScale1,kScale2,kInterval1)
                else
                    obj._noteFuncImg:stopAllActions()
                end
            end
        elseif obj._hasNewFunc then
            obj._hasNewFunc  = false
	        obj._noteFuncImg:setVisible(false)
	        obj._noteFuncImg:stopAllActions()
        end
    end
    obj:egBindWidgetUpdate(kImgNoteFunc,update)
end
----------------------------------------------------------------------
--��Ϣ��
----------------------------------------------------
local trainid = 4
__traininitial[trainid]={}
__traininitial[trainid].initSelfData=function(obj)
	obj:egShowWidget(kImgNote)
	--obj:egShowWidget(kBtnGold)
	--obj:egShowWidget(kBtnOil)
	--obj:egShowWidget(kPanelOil)
	--obj:egShowWidget(kPanelGold)
	--obj:bindGoldBtnListener()--Click Event
	--obj:bindOilBtnListener()--Click Event
	--obj:bindGoldListener() --timer
	--obj:bindOilListener() --timer
	obj:bindImgStateListener()
	obj:bindLvUpListener()
end
__traininitial[trainid].bindGoldBtnListener=function(obj)
    local function touchEnded(sender)
        obj._goldBtn:stopAllActions()
        obj._goldImg:stopAllActions()
        obj:egHideWidget(kBtnGold)
        obj._goldImg:setVisible(false)
        account_data.gold = account_data.gold + obj._gold
		account_data.teamRes.gold_st = os.time()
		account_data.teamRes.gold_elp = 0
		obj:showNumPrompt(obj._goldImg,"gold",obj._gold)
		SendMsg[934009](1,obj._gold)
		obj._gold = 0
		obj._gold_elp = 0
		obj:bindGoldListener()
    end
    obj:egBindTouch(kBtnGold,nil,nil,touchEnded,nil)
end
__traininitial[trainid].bindOilBtnListener=function(obj)
    local function touchEnded(sender)
        obj._oilBtn:stopAllActions()
        obj._oilImg:stopAllActions()
        obj:egHideWidget(kBtnOil)
        obj._oilImg:setVisible(false)
        account_data.oil = account_data.oil + obj._oil
        account_data.teamRes.oil_st = os.time()
        account_data.teamRes.oil_elp = 0
        obj:showNumPrompt(obj._oilImg,"oil",obj._oil)
        SendMsg[934009](2,obj._oil)
        obj._oil = 0
        obj._oil_elp = 0
		obj:bindOilListener()
    end
    obj:egBindTouch(kBtnOil,nil,nil,touchEnded,nil)
end

--����ռ���ʾ
__traininitial[trainid].bindGoldListener=function(obj)
    obj._goldBtn = tolua.cast(obj:egGetWidgetByName(kBtnGold),"Button")
    obj._goldImg = obj:egGetWidgetByName(kPanelGold)
    obj:egHideWidget(kBtnGold)
    obj._goldImg:setVisible(false)
	obj._gold_elp = 0
	obj._gold = 0
	local function update()
		local elp = os.time() - account_data.teamRes.gold_st
		if obj._gold_elp ~= elp then
			obj._gold_elp = elp
			local abi = teamDiscover.getDiscoverAbility(account_data.team, account_data.heroList)
		    local goldInt,goldGain,_,_= teamDiscover.getCollectAbility(abi)
			local gold = math.floor(obj._gold_elp/goldInt)*goldGain
			if obj._gold<=0 and gold > 0 then
				obj:egShowWidget(kBtnGold)
                obj._goldImg:setVisible(true)
				obj:scaleWidget(obj._goldImg,0.9,1,kInterval1)
				--obj:scaleWidget(obj._goldImg,0.5,0.65,kInterval1)
				local goldCap,_ = teamDiscover.getCollectCapacity(account_data.digLv)
				if gold > goldCap then 
					gold = goldCap 
					obj._goldBtn:setColor(kRedColor)
					obj:egUnbindWidgetUpdate(kBtnGold)
				else
					obj._goldBtn:setColor(kWhiteColor)
				end
			end
			obj._gold = gold
		end
	end
	obj:egBindWidgetUpdate(kBtnGold,update)
end
--ʯ���ռ���ʾ
__traininitial[trainid].bindOilListener=function(obj)
    obj._oilBtn = tolua.cast(obj:egGetWidgetByName(kBtnOil),"Button")
    obj._oilImg = obj:egGetWidgetByName(kPanelOil)
    obj:egHideWidget(kBtnOil)
    obj._oilImg:setVisible(false)
	obj._oil_elp = 0
	obj._oil = 0
	local function update()
		local elp = os.time() - account_data.teamRes.oil_st
		if obj._oil_elp ~= elp then
			obj._oil_elp = elp
			
			local abi = teamDiscover.getDiscoverAbility(account_data.team, account_data.heroList)
		    local _,_,oilInt,oilGain= teamDiscover.getCollectAbility(abi)
		    local oil = math.floor(obj._oil_elp/oilInt)*oilGain
			if obj._oil<=0 and oil > 0 then
				obj:egShowWidget(kBtnOil)
                obj._oilImg:setVisible(true)
				obj:scaleWidget(obj._oilImg,0.9,1,kInterval1)
				--obj:scaleWidget(obj._oilImg,0.5,0.65,kInterval1)
				local _,oilCap = teamDiscover.getCollectCapacity(account_data.digLv) 
				if oil > oilCap then 
					oil = oilCap 
					obj._oilBtn:setColor(kRedColor)
					obj:egUnbindWidgetUpdate(kBtnOil)
				else
					obj._oilBtn:setColor(kWhiteColor)
				end
			end
			obj._oil = oil
		end
	end
	obj:egBindWidgetUpdate(kBtnOil,update)
end
__traininitial[trainid].showNumPrompt=function(obj,sender,coinName,num)
    local widget = DigPrompt.new(coinName,num)
	local ttfSize =widget:egNode():getSize()
    obj:egAddChild(widget:egNode(),kPromptZorder,kPromptZorder)
    local x = sender:getPositionX()+obj:egNode():getSize().width/2
    local y = sender:getPositionY() + sender:getSize().height/2
    widget:egSetPosition(x,y)
	local movey = kMoveDistance
    local fadeout = CCFadeOut:create(0.2)
    local moveby = CCMoveBy:create(0.8,ccp(0,movey))
    local sequence1 = CCSequence:createWithTwoActions(moveby,fadeout)
    local function callback()
        widget:egRemoveSelf()
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(sequence1,callfunc)
    widget:egRunAction(sequence)
end 
----------------------------------------------------
TrainInitial={}
function TrainInitial.install(obj,trainid)
	if __traininitial[trainid] then
		table_aux.unpackTo(__traininitial[trainid], obj)
		obj:initSelfData()
	end
end
------------------------------------------------------------
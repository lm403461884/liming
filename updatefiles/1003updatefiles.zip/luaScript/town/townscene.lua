local kPvpPrompt = 1
local kTrainPrompt = 2
local kLicencePrompt = 3
local kChemyPrompt = 4

local kTrainZorder = 1
local kMenuZorder = 2
local kPropZorder = 3
local kChatZorder = 4

local __townscene={}
function __townscene.activeUpdate(obj)
	local function update()
	    if not account_data.prompList or #account_data.prompList == 0 then return end
		if not AccountHelper:isLocked(kStatePrompt) and not AccountHelper:isLocked(kStateGuide) then
		    local promptItem = account_data.prompList[1]
		    if promptItem.type ==kPvpPrompt then
		        AccountHelper:lock(kStatePrompt)
		        showPvpPrompt(promptItem.data)
		    elseif promptItem.type ==kTrainPrompt then
		        AccountHelper:lock(kStatePrompt)
		        showTrainPrompt(promptItem.data)
		    elseif promptItem.type ==kLicencePrompt then
		        AccountHelper:lock(kStatePrompt)
		        showLicencePrompt(promptItem.data.from,promptItem.data.to)
		    elseif promptItem.type ==kChemyPrompt then
		        AccountHelper:lock(kStatePrompt)
		        showChemyPrompt(promptItem.data)
		    end
			table.remove(account_data.prompList,1)
		end
	end
	obj:egBindUpdate(update)	
end
--����¼�ǰ�Ļص����� --���˵�
function __townscene.bindMenuClickingEvent(obj)
	local function clickingCallback()
		if obj:egNode():getChildByTag(UILv.popLayer) then
			obj:egNode():removeChildByTag(UILv.popLayer,true)
		end
		obj._chatWidget:hidePanel()
		obj._baseWidget:clearSelectedTrain()
	end

	obj._menuWidget:onClicking(clickingCallback)
end
--����¼�ǰ�Ļص����� --��
function __townscene.bindTrainClickingEvent(obj)
	local function clickingCallback1()
		if obj:egNode():getChildByTag(UILv.popLayer) then
			obj:egNode():removeChildByTag(UILv.popLayer,true)
		end
		obj._chatWidget:hidePanel()
	end
	obj._baseWidget:onClicking(clickingCallback1)
end
--����¼�ǰ�Ļص����� --����
function __townscene.bindChatClickingEvent(obj)
	local function clickingCallback()
		if obj:egNode():getChildByTag(UILv.popLayer) then
			obj:egNode():removeChildByTag(UILv.popLayer,true)
		end
		obj._baseWidget:clearSelectedTrain()
	end
	obj._chatWidget:onClicking(clickingCallback)
end
--����¼�ǰ�Ļص�����--���밴ť
function __townscene.bindBtnExClickingEvent(obj)
    local function clickingCallback(isShow)
        obj._chatWidget:hideAllPanel(isShow)
    end
    obj._menuWidget:btnExOnClicking(clickingCallback)
end
TownScene = {}
function TownScene.new()
	SoundHelper.playBGM(SoundList.train_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__townscene, obj)
	AccountHelper:unlock(kStatePrompt)
	AccountHelper:unlock(kStateGuide)
	
    obj._baseWidget = TrainBgLayer.new(account_data)
    obj._baseWidget:egAttachTo(obj,kTrainZorder,kTrainZorder)
	obj:bindTrainClickingEvent()
	
	obj._menuWidget = MenuLayer.new(account_data)
	obj._menuWidget:egAttachTo(obj,kMenuZorder,kMenuZorder)
	obj:bindMenuClickingEvent()
	obj:bindBtnExClickingEvent()
	
    obj._propWidget = PropLayer.new()
    obj._propWidget:egAttachTo(obj,kPropZorder,kPropZorder) 
	
	obj._chatWidget = ChatLayer.new()
	obj._chatWidget:egAttachTo(obj,kChatZorder,kChatZorder) 
	obj:bindChatClickingEvent()
	
    showEmDialog(obj,GuideScene.def.kTownScene) --����������Ϣ
	obj:activeUpdate()
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end

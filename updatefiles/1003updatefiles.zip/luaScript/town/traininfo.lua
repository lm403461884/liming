local kBtnBuy = "btn_buy"
local kPanelVal = "val_panel"
local kLblInfo = "lbl_info"
local kImgTrain = "up_item_img"
local kLblTrain = "lbl_trainName"
local kImgCoins = {"img_1","img_2","img_3"}
local kLblVals = {"lbl_1","lbl_2","lbl_3"}
local kTotal = 3
local kLblW = 720
local kLblH = 135
local kRedColor = ccc3(255,0,0)
local kBrownColor = ccc3(83,49,22)
local __traininfo={}
function __traininfo.init(obj,trainid)
    obj._trainid = trainid
    obj._params = {}
    local traindata = train.config[obj._trainid]
    local s_cfg = traindata.research[1]
    obj._licence = s_cfg.licence or 1
    obj._gold = s_cfg.gold or 0
    obj._oil = s_cfg.oil or 0
    table.insert(obj._params,{"digLv",ImageList.comm_lv,obj._licence})
    if obj._gold > 0 then table.insert(obj._params,{"gold",ImageList.comm_gold,obj._gold}) end
    if obj._oil > 0 then  table.insert(obj._params,{"oil",ImageList.comm_oil,obj._oil})  end
    obj:egChangeImg(kImgTrain,s_cfg.bodyImage[1])
    obj:egSetLabelStr(kLblTrain,traindata.name)
    obj:loadParams() 
    obj:loadTrainInfo(traindata.info)
    obj:resizeValPanel()
end
function __traininfo.getTrainID(obj)
	return obj._trainid
end
function __traininfo.resizeValPanel(obj)
     local cnt = #obj._params
    if cnt < kTotal then
        for idx=cnt+1,kTotal do
            obj:egHideWidget(kLblVals[idx])
            obj:egHideWidget(kImgCoins[idx])
        end
        local widget = obj:egGetWidgetByName(kPanelVal)
        local offseth = widget:getSize().height * (kTotal-cnt)/kTotal/2
        widget:setPosition(ccp(widget:getPositionX(),widget:getPositionY() +  offseth))
    end
end
function __traininfo.loadParams(obj)
	obj:egSetWidgetEnabled(kBtnBuy,true)
    for idx,item in ipairs(obj._params) do
        local color = kBrownColor
        obj:egSetLabelStr(kLblVals[idx],item[3])
        obj:egChangeImg(kImgCoins[idx],item[2],UI_TEX_TYPE_PLIST)
        if item[3] > account_data[item[1]] then 
            color = kRedColor 
			obj:egSetWidgetEnabled(kBtnBuy,false)
        end
        obj:egSetWidgetColor(kLblVals[idx],color)
    end
    
end
function __traininfo.loadTrainInfo(obj,info)
    local widget = obj:egGetWidgetByName(kLblInfo)
	local lbl =  tolua.cast(widget,"Label")
	lbl:setText(info)
	local size = lbl:getSize()
	if size.width > kLblW then
		lbl:setTextAreaSize(CCSizeMake(kLblW,kLblH))
	end
end

--�ػؼ������ݣ����ж��Ƿ�ɹ���
function __traininfo.reloadData(obj)
    obj:loadParams()
end
function __traininfo.onClicked(obj,callback)
	obj._clickCallback = callback
end
function __traininfo.bindBuyListener(obj)
	local function touchEnded(sender)
       sender:setTouchEnabled(false)
	   if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
	   SoundHelper.playEffect(SoundList.click_buy_button)
	   SendMsg[937001](obj._trainid)
	   --�ھ���־������̸���,������
		task.updateTaskStatus(account_data,task.client_event_id.buy_train,{obj._trainid})
		----------------------------------------------------------
	   local s_cfg = train.config[obj._trainid].research[1]
	   account_data.train[obj._trainid] = {lv = 1}
	   account_data.gold = account_data.gold - (s_cfg.gold or 0)
	   account_data.oil = account_data.oil - (s_cfg.oil or 0)
	   train.onFirstBuying(obj._trainid,account_data)
       if obj._clickCallback then obj._clickCallback(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBuy,nil,nil,touchEnded,touchCanceled)
end
TrainInfo={}
function TrainInfo.new(trainid)
    local obj = {}
    CocosWidget.install(obj,JsonList.trainInfo)
    table_aux.unpackTo(__traininfo, obj)
    obj:init(trainid)
	obj:bindBuyListener()
    return obj
end
local kBtnTask = "btn_task"
local kBtnActive = "btn_active"
local kListView = "list_members"
local kImgPrompt = "img_prompt1"
local kImgTaskPro = "img_finish_task"
local kImgActivePro = "img_finish_active"
local kLblTaskNo = "lbl_task_no"
local kLblIntro = "lbl_intro"
local kLblSelect = "lbl_select"
local kImgIcon1 = "img_icon1"
local kImgIcon2 = "img_icon2"
local kImgPrompt = "img_prompt1"
local kLblIcon1 = "lbl_1"
local kLblIcon2 = "lbl_2"
local kBtnBack = "btn_back"
local kBtnSelect = "btn_reward"
local kPanelInfo = "panel_info"
local kPanelReward = "panel_reward"
local kPanelReward1 = "reward_panel1"
local kPanelReward2 = "reward_panel2"
local kPanelLayer = "panel_journal_layer"

local kTxtW = 430
local kTxtH = 45
local kMaxNum = 7
local kShowBtn = 2
local kHideBtn= 0

local __digjournal={}
function __digjournal.init(obj)
    local btntask = obj:egGetWidgetByName(kBtnTask)
    obj._btntask = tolua.cast(btntask,"Button")
    obj._btnactive = tolua.cast(obj:egGetWidgetByName(kBtnActive),"Button")
    obj._btntask:setFocused(true)
    obj._btntask:setTouchEnabled(false)
    obj._btnParent = btntask:getParent()
    obj._btnParent:reorderChild(btntask,kShowBtn)
    obj:egHideWidget(kImgPrompt)
    obj._listview = obj:egGetListView(kListView)
    obj._reward1 = obj:egGetWidgetByName(kPanelReward1)
    obj._reward2 = obj:egGetWidgetByName(kPanelReward2)
    obj._type = 1
    obj._iconitem = {} --��������
    obj:egHideWidget(kLblTaskNo)
    obj:loadTask()
    obj:showWithAction()
end
--��������
function __digjournal.loadTask(obj)
    obj:taskOrder()--��������
    obj:clearTaskList()
    obj._task = {}
    obj._oldH=0
    obj._selectitem = nil
    obj._first = false --��ʼ��
    local orderList = nil
    if obj._type == 1 then
        orderList = obj._taskOrder
        obj._maxNum = #obj._taskOrder 
    elseif obj._type == 2 then
        orderList = obj._activeOrder
        obj._maxNum = #obj._activeOrder
    end
    obj:addTaskItem(kMaxNum)
    if obj._maxNum == 0 then
        obj:egHideWidget(kPanelInfo)
        obj:egShowWidget(kLblTaskNo)
    elseif obj._maxNum > 6 then
        obj:egShowWidget(kImgPrompt)
        obj:egShowWidget(kPanelInfo)
        obj:egHideWidget(kLblTaskNo)
    else
        obj:egHideWidget(kImgPrompt)
        obj:egShowWidget(kPanelInfo)
        obj:egHideWidget(kLblTaskNo)    
    end
end
--��������
function __digjournal.taskOrder(obj)
    obj._taskOrder={} 
    obj._activeOrder = {}
    for id,item in pairs (account_data.taskList) do
        local task_data = taskQuery.getName(id)
        if task_data.type == 1 and item[2]~= 2 then
            table.insert(obj._taskOrder,id)
        elseif task_data.type == 2 and item[2]~= 2 then
            table.insert(obj._activeOrder,id)
        end 
    end
    table.sort(obj._taskOrder)
    table.sort(obj._activeOrder)
    obj._startIdx = 1
end
--��������
function __digjournal.addTaskItem(obj,num)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx+num-1,obj._maxNum)
    local order_data = {}
    if obj._type==1 then
          order_data = obj._taskOrder
    elseif obj._type == 2 then
          order_data = obj._activeOrder
    end     
    for idx = startIdx,obj._maxNum,1 do
        if idx >endIdx then break end
        local tid = order_data[idx]
        local task_data = taskQuery.getName(tid)
        local item = DigJournalItem.new(task_data,idx,tid)
        --obj._task[idx]=item
        obj._task[tid]=item
        obj._listview:pushBackCustomItem(item:egNode())
        obj:bindTaskListener(item)
        if obj._first == false then
            obj._first = true 
            obj:clearReward()
            obj._selectitem = item 
            item:setFocused(true)
            obj:loadTaskIntro(task_data)
            obj:egShowWidget(kBtnSelect)
            obj: bindBtnSelectListener(item)
            obj:loadReward(task_data,tid)
        end 
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __digjournal.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:addTaskItem(kMaxNum)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent) 
end
function __digjournal.loadTaskIntro(obj,d_data)
    obj:egSetLabelStr(kLblIntro,d_data.tasklog)
end
--���ؽ�����Ϣ
function __digjournal.loadReward(obj,task_data,tid)
    obj:clearReward()
    local count = 0
    local icon_data = task_data.taskprize
    for _,item in pairs (icon_data) do
        count = count +1
        if count <=3 then
            local iconitem = TheAward.new(item.name,item.val)
            obj._reward1:addChild(iconitem:egNode())
            table.insert(obj._iconitem,iconitem)
            iconitem:egNode():setPosition(ccp((count-1)*149,0))
            obj._reward1:setPosition(ccp(74*(3-count),115))
        else
            local iconitem = TheAward.new(item.name,item.val)
            table.insert(obj._iconitem,iconitem)
            obj._reward2:addChild(iconitem:egNode())
            iconitem:egNode():setPosition(ccp((count-4)*149,0))
            obj._reward2:setPosition(ccp(74*(6-count),62))
        end   
    end
    if task_data.heromessage then --����Ӣ����Ϣ
        for heroid,msgnum in pairs(task_data.heromessage) do
	        count = count + 1
	        local heromsg = HeroMsg.new(heroid,msgnum)
	        table.insert(obj._iconitem,heromsg)
	        if count<= 3 then
	            obj._reward1:addChild(heromsg:egNode())
                heromsg:egNode():setPosition(ccp((count-1)*149,0))
                obj._reward1:setPosition(ccp(74*(3-count),115))
	        else
	            obj._reward2:addChild(heromsg:egNode())
                heromsg:egNode():setPosition(ccp((count-4)*149,0))
                obj._reward2:setPosition(ccp(74*(6-count),62))
	        end
	    end
    end
    if account_data.taskList[tid][2]==1 then
        obj._kind = 2
        obj:egSetLabelStr(kLblSelect,TxtList.reward)
        obj:egShowWidget(kBtnSelect)
    elseif account_data.taskList[tid][2]==0 then
        obj._kind = 1
        obj:egSetLabelStr(kLblSelect,TxtList.enterTask)
        local isshow = true
        for _,eventid in ipairs (task.notShowGoto) do
            if task_data.client_event_id == eventid then
                isshow = false
            end
        end
        if isshow then 
            obj:egShowWidget(kBtnSelect)
        else
            obj:egHideWidget(kBtnSelect)
        end
    end
end
--�����������
function __digjournal.clearReward(obj)
    for idx,item in ipairs (obj._iconitem) do
         if idx<=3 then 
             obj._reward1:removeChild(item:egNode())
         else
             obj._reward2:removeChild(item:egNode())    
         end  
    end
    obj._iconitem={}
    obj._reward1:removeAllChildren()
    obj._reward2:removeAllChildren()
end
--�������¼��ص�
function __digjournal.bindTaskListener(obj,item)
    local function callback(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(true)
        obj:egSetLabelStr(kLblIntro,nil)
        obj:clearReward()
        obj._selectitem:setFocused(false)
        obj._selectitem = item
        item:setFocused(true)
        local task_data = item:getprop("task")
        obj:loadTaskIntro(task_data)
        obj: bindBtnSelectListener(item)
        obj:loadReward(task_data,item:getprop("tid"))
    end
    item:onClicked(callback)     
end

--�رհ���
function __digjournal.bindBackListener(obj)
    local function touchEnded(sender)
            SoundHelper.playEffect(SoundList.click_paper_close)
            sender:setTouchEnabled(false)
			if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		    SoundHelper.playEffect(SoundList.click_paper_close)
            obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __digjournal.bindBtnTaskListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj._btnactive:setFocused(false)
        obj._btnParent:reorderChild(obj._btnactive,kHideBtn)
        obj._btnactive:setTouchEnabled(true)
        obj._btntask:setFocused(true)
        obj._btnParent:reorderChild(obj._btntask,kShowBtn)
        obj._btntask:setTouchEnabled(false)
        obj._type=1
        obj:loadTask()
    end
    obj:egBindTouch(kBtnTask,nil,nil,touchEnded,nil)
end

function __digjournal.bindActiveListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        obj._btnactive:setFocused(true)
        obj._btnParent:reorderChild(obj._btnactive,kShowBtn)
        obj._btnactive:setTouchEnabled(false)
        obj._btntask:setFocused(false)
        obj._btnParent:reorderChild(obj._btntask,kHideBtn)
        obj._btntask:setTouchEnabled(true)
        obj._type=2
        obj:loadTask()
    end
    obj:egBindTouch(kBtnActive,nil,nil,touchEnded,nil)
end
function __digjournal.hideWithAction(obj,callbackfunc)
    local function callback()
			AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __digjournal.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
		baseWidget:runAction(sequece)
	else
		baseWidget:runAction(spawn)
	end
end
--���listview����
function __digjournal.clearTaskList(obj)
     for idx =1,obj._listview:getChildrenCount() do
        local item = obj._listview:getItem(idx-1)
        obj._listview:removeChildByTag(item:getTag(),true)
     end
     obj._listview:removeAllItems()
     obj._listview:jumpToTop()
end
--ɾ��listviewitem
--[[function __digjournal.removeItem(obj,item)
    local idx = item:getprop("idx")
    local old_data = item:getprop("task")
    local oldtaskid = old_data.taskid
    obj._listview:removeItem(idx-1)
    obj._task[idx]=nil
    for oldidx,item in pairs (obj._task) do
        if oldidx >idx then
            obj._task[oldidx-1] = item
            obj._task[oldidx]=nil
            item:setprop("idx",oldidx-1)
        end
    end
    for _,task in ipairs (tasklog) do  --�滻
        if task.taskid == oldtaskid+1 and task.preposition== oldtaskid then
            local newitem = DigJournalItem.new(task,idx)
            obj._listview:insertCustomItem(newitem:egNode(),idx-1)
            newitem:setFocused(true)
            --obj:egSetLabelStr(kLblIntro,task.tasklog)
            obj:loadTaskIntro(task)
            obj:loadReward(task.taskprize)
            obj: bindBtnSelectListener(newitem)
            return
        end
    end
    obj._selectitem = obj._task[idx]
    if not obj._selectitem then
         obj._selectitem = obj._task[idx-1]
    end
    if obj._selectitem then
        obj._selectitem:setFocused(true)
        local task_data = obj._selectitem:getprop("task")
        --obj:egSetLabelStr(kLblIntro,task_data.tasklog)
        obj:loadTaskIntro(task_data)
        obj:loadReward(task_data.taskprize)
        obj: bindBtnSelectListener(obj._selectitem)
    else
        obj:egSetLabelStr(kLblIntro,"")
        obj:clearReward()
        obj:egHideWidget(kBtnSelect)
    end   
end--]]

function __digjournal.doClickChange(obj,sender,item)
    local tid = item:getprop("tid")
    if obj._kind == 1 then  --��������
        SoundHelper.playEffect(SoundList.click_paper_open)
        task.callback(tid)
        obj:egRemoveSelf()
    elseif obj._kind == 2 then  --��ȡ����
        SoundHelper.playEffect(SoundList.click_buy_button)
        SendMsg[9310003](tid)
        --obj:activeUpdata(tid,sender)
        task.onFinished(account_data,tid)
        obj:loadTask()
        sender:setTouchEnabled(true)
    end
end
function __digjournal.bindBtnSelectListener(obj,item)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickChange(sender,item)
	end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnSelect,nil,nil,touchEnded,touchCanceled)
end

function __digjournal.scaleWidget(obj,widget,from,to,s)
	local scaleto1 = CCScaleTo:create(s,from)
	local scaleto2 = CCScaleTo:create(s,to)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end

function __digjournal.activeUpdate(obj)
    obj._taskpro = false
    obj._activepro = false
    local widgetTask = obj:egGetWidgetByName(kImgTaskPro)
    local widgetActive = obj:egGetWidgetByName(kImgActivePro)
    obj:egHideWidget(kImgTaskPro)
    obj:egHideWidget(kImgActivePro)
    local function callback ()
        local taskPro = false
        local activePro = false
        for taskid,item in pairs(account_data.taskList) do
            if item[2] == 1 then
                if obj._task[taskid] then  --�������
                    if taskid == obj._selectitem:getprop("tid") and not obj._selectitem:getprop("finished") then
                        obj:egSetLabelStr(kLblIntro,nil)
                        obj:clearReward()
                        local task_data = obj._selectitem:getprop("task")
                        obj:loadTaskIntro(task_data)
                        obj: bindBtnSelectListener(obj._selectitem)
                        obj:loadReward(task_data,taskid)
                    end
                    obj._task[taskid]:showFinished()
                end
                local task_data = taskQuery.getName(taskid)
                if task_data.type == 1 then 
                    taskPro = true
                else
                    activePro = true
                end
            end
        end
        if taskPro and taskPro ~= obj._taskpro then
            obj._taskpro = taskPro
            obj:egShowWidget(kImgTaskPro)
            obj:scaleWidget(widgetTask,0.6,0.8,0.5)
        elseif not taskPro and taskPro ~= obj._taskpro then
            obj._taskpro = taskPro
            obj:egHideWidget(kImgTaskPro)
            widgetTask:stopAllActions()    
        end
        if activePro and activePro ~= obj._activepro then
            obj._activepro = activePro
            obj:egShowWidget(kImgActivePro)
            obj:scaleWidget(widgetActive,0.6,0.8,0.5)
        elseif not activePro and activePro ~= obj._activepro then
            obj._activepro = activePro
            obj:egHideWidget(kImgActivePro)
            widgetActive:stopAllActions()    
        end
    end
    obj:egBindWidgetUpdate(kImgTaskPro,callback)
end
DigJournal={}
function DigJournal.new(onloaded)
    local obj =  TouchWidget.new(JsonList.digJournal)
    table_aux.unpackTo(__digjournal, obj)
	obj._onloaded = onloaded
    obj:init(d_data)
    obj:bindBackListener()
    obj:bindScrollListener()
    obj:bindActiveListener()
    obj:bindBtnTaskListener()
    obj:activeUpdate()
    return obj
end

function showDigJournal(onloaded)
    local layer = DigJournal.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

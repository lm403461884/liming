local kImgTrain = "train_img" --����ͼ��
local kLabelTrainName = "lbl_train_name"
local kLabelTrainLv = "lbl_train_lv"
local kPanelTrainProp = "prop_layer"
local kLabelTrainInfo = "lbl_content"
local kPanelSubUpdate = "update_Panel"--������������
local kPanelSubBtn = "subupdate_layer" --�������ť���� 
local kLblBtnIn = "lbl_btnin"
local kBtnUp = "Button_up"
local kBtnIn = "Button_in"
local kBtnClose = "btn_close"
local kImgIn = "img_btnin" --����ͼ��
local kImgBg = "func_bg"
local kLblWidth = 540
local kLblHeight = 115
local kPosRight = ccp(133,-209)
local kPosMid = ccp(-10,-209)
local __trainfunclayer = {}
function __trainfunclayer.init(obj,trainid,d_data)
    obj._trainid = trainid
	obj:loadSpecTrainProp()
    obj._d_data = d_data
    obj._curProp = {}
    local traindata = obj._d_data.train[obj._trainid]
    local s_cfg = train.config[trainid]
    obj:egChangeImg(kImgTrain,s_cfg.ui.btn_enter_image[1],UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLabelTrainName,s_cfg.name)
    if trainid == train.def.head then
        obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",account_data.digLv))
        obj._curLv = account_data.digLv
    else
        obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",traindata.lv))
        obj._curLv = traindata.lv
    end    
	obj:egSetLabelStr(kLblBtnIn,s_cfg.ui.btn_enter_text)
    --obj._curLv = traindata.lv
    local widget = obj:egGetWidgetByName(kLabelTrainInfo)
    local lbl =  tolua.cast(widget,"Label")
    lbl:setText(s_cfg.info)
    local size = lbl:getSize()
    if size.width > kLblWidth then
        lbl:setTextAreaSize(CCSizeMake(kLblWidth,kLblHeight))
    end
    local propanel =  obj:egGetWidgetByName(kPanelTrainProp)
    obj._oldpropX =propanel:getPositionX()
    obj._oldpropW = propanel:getSize().width
    obj:loadTrainProp()
    obj:loadSubUpdate()
    obj:loadFuncBtn()
	obj:showWithAction()
end
function __trainfunclayer.loadSpecTrainProp(obj)
	if obj._trainid == train.def.anteroom  then
		account_data.teamAtkCap = obj:getTeamAtkCap()
	end
end
--С��ս�����ܺ�
function __trainfunclayer.getTeamAtkCap(obj)
    local tb = {}
	local teamAtk = 0
    for key,heroprop in ipairs(account_data.heroList) do
        local equiplv,equipqa =  equipFuncs.getEquipQL(heroprop.eid,account_data)
        local atkcap = baseCalc.getBattlePoint(heroprop.lv,equiplv,equipqa)
        tb[heroprop.type] = atkcap
    end
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk + tb[heroid]
    end
	tb = nil
    return teamAtk
end
function __trainfunclayer.loadTrainProp(obj)
    local propPanel = obj:egGetWidgetByName(kPanelTrainProp)
    for i = 1,propPanel:getChildrenCount() do
        propPanel:removeChildByTag(i,true)
    end 
    local props = train.props[obj._trainid]
    if props then
        local fontName = FNList.STHUPO
        local fontSize = 32
        local cnt = 0
        local x =0
        local y = 0
        local margin = 20
        for key,val in pairs(props) do
            cnt = cnt +1
            obj._curProp[key] = obj._d_data[key]
            local txt = string.format("%s%s%s",val,":",obj._d_data[key])
            local ttf = Label:create()
            ttf:setText(txt)
            ttf:setFontName(fontName)
            ttf:setFontSize(fontSize)
            ttf:setAnchorPoint(ccp(0,0))
            ttf:setPosition(ccp(x,y))
            obj:bindTtfUpdate(ttf,key,val)
            propPanel:addChild(ttf,cnt,cnt)
            x = x + ttf:getSize().width + margin
        end
        local newW = x - margin
        local newX = obj._oldpropX + (obj._oldpropW - newW)/2
        propPanel:setSize(CCSizeMake(newW,propPanel:getSize().height))
        propPanel:setPosition(ccp(newX,propPanel:getPositionY()))
    end
end
function __trainfunclayer.bindTtfUpdate(obj,ttf,propName,propTxt)
     local function update(delta)
        if obj._curProp[propName] ~=obj._d_data[propName] then
            local sub = obj._d_data[propName] - obj._curProp[propName]
            local per = math.ceil(sub/10)
            obj._curProp[propName] = obj._curProp[propName] +per
            ttf:setText(string.format("%s%s%s",propTxt,":",obj._curProp[propName]))
        end
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  ttf:unscheduleUpdate() end
    end
    ttf:scheduleUpdateWithPriorityLua(update, 0)
    ttf:registerScriptHandler(exitFuns)
end
function __trainfunclayer.loadSubUpdate(obj)
    local updatepanel = obj:egGetWidgetByName(kPanelSubUpdate)
    local margin = 30
    local x = 0
    local y =0
    local trainSubProp = trainSub[obj._trainid] 
    local btnpanel = obj:egGetWidgetByName(kPanelSubBtn)
    for i = 1,btnpanel:getChildrenCount() do
        btnpanel:removeChildByTag(i,true)
    end 
    local hasSubUpdate = false
    if trainSubProp then  
        local cnt = 0
        for idx,item in ipairs(trainSubProp) do
            if not item.isMax(obj._d_data) then
                hasSubUpdate = true
                cnt = cnt + 1
                local subBtn = SubPropBtn.new(obj._trainid,idx,obj._d_data)
                btnpanel:addChild(subBtn:egNode(),cnt,cnt)
                subBtn:egSetPosition(x,y)
                x = x + subBtn:egNode():getSize().width + margin
                local  function clickCallBack()
                    obj:clickSubLvUp(obj._trainid,idx)
                end
                subBtn:onClicked(clickCallBack) 
            end
        end
    end
    if hasSubUpdate then 
        updatepanel:setVisible(true) 
        obj:egHideWidget(kLabelTrainInfo)
        btnpanel:ignoreContentAdaptWithSize(false)
        local size = updatepanel:getSize()
        local newW = x - margin
        local newX = (size.width - newW)/2
        btnpanel:setSize(CCSizeMake(newW,size.height))
        btnpanel:setPosition(ccp( newW,btnpanel:getPositionY()))
    else 
        updatepanel:setVisible(false) 
        obj:egShowWidget(kLabelTrainInfo) 
    end
end
function __trainfunclayer.loadFuncBtn(obj)
    local traindata = obj._d_data.train[obj._trainid]
    local s_cfg = train.config[obj._trainid]
    local lv = traindata.lv
    local s_data = s_cfg.research[lv + 1]

    local btnEnter = obj:egGetWidgetByName(kBtnIn)
    btnEnter:setPosition(kPosRight)
    
    if obj._trainid ==0 then --��ͷ����
        lv = account_data.digLv
        local btnUp = obj:egGetWidgetByName(kBtnUp)
        if  obj._d_data.diggingLvContext or ( not licenceLevelup[lv+1])  then 
            obj:egHideWidget(kBtnUp)
            obj:egHideWidget(kBtnIn)
            --btnEnter:setPosition(kPosMid)
		    SoundHelper.playEffect(SoundList.clickMenu)
        else
            obj:egShowWidget(kBtnUp)
            obj:egHideWidget(kBtnIn)
            btnUp:setPosition(kPosMid)
            --btnEnter:setPosition(kPosRight)
		    SoundHelper.playEffect(SoundList.clickMenu)
        end
    else
        if  (traindata.ri and traindata.ri.left > 0) or (not s_data) then --û�д���������,û�п�������
            obj:egHideWidget(kBtnUp)
            btnEnter:setPosition(kPosMid)
		    SoundHelper.playEffect(SoundList.clickMenu)
        else
            obj:egShowWidget(kBtnUp)
            btnEnter:setPosition(kPosRight)
		    SoundHelper.playEffect(SoundList.clickMenu)
        end
    end
end
--����
function __trainfunclayer.bindUpListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:clickLvUp()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnUp,nil,nil,touchEnded,touchCanceled)
end
--���书�ܰ���
function __trainfunclayer.bindInListener(obj)

    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:clickEnter()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnIn,nil,nil,touchEnded,touchCanceled)
end
--�رհ���
function __trainfunclayer.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideWithAction()
	end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
--������복�书��
function __trainfunclayer.clickEnter(obj)
    SoundHelper.playEffect(SoundList.click_paper_open)
    obj:hideWithAction()
    --local function callback()
    --end
    local func = train.config[obj._trainid].entra
    if func then func(callback) end
end
 --���������
function __trainfunclayer.clickSubLvUp(obj,trainid,subIdx)
    SoundHelper.playEffect(SoundList.click_buy_button)
    trainSub[trainid][subIdx].updateAccount(account_data)
    SendMsg[937004](trainid,subIdx)
    obj:loadSubUpdate()
end
--�������������
function __trainfunclayer.clickLvUp(obj)
    SoundHelper.playEffect(SoundList.click_paper_open)
    obj:hideWithAction()
    showLvUp(obj._trainid)
end
function __trainfunclayer.hideWithAction(obj)
    AccountHelper:unlock(kStatePrompt)
    local trainlayer = AccountHelper:get(kTrainLayer)
    trainlayer:clearSelectedTrain()
     obj:egRemoveSelf()
end
function __trainfunclayer.showWithAction(obj)   
     obj._egObj:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        obj._egObj:runAction(sequece)
    else
        obj._egObj:runAction(spawn)
    end
    
end
function __trainfunclayer.activeUpdate(obj)
    local function callback()
        if obj._curLv~=obj._d_data.train[obj._trainid].lv then
            obj._curLv = obj._d_data.train[obj._trainid].lv
            obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",obj._curLv))
            obj:loadSubUpdate()
            obj:loadFuncBtn()
        end
        if obj._trainid == train.def.head and obj._curLv ~= account_data.digLv then
            obj._curLv = account_data.digLv
            obj:egSetLabelStr(kLabelTrainLv,string.format("%s%d","LV ",obj._curLv))
            obj:loadSubUpdate()
            obj:loadFuncBtn()
        end
    end
    obj:egBindWidgetUpdate(kImgBg,callback)
end
TrainFuncLayer = {}
function TrainFuncLayer.new(trainid,d_data,onloaded)
	local obj = TouchWidget.new(JsonList.trainFuncLayer)
   -- local obj = {}
   -- CocosWidget.install(obj,JsonList.trainFuncLayer)
    table_aux.unpackTo(__trainfunclayer, obj)
	obj._onloaded = onloaded
    obj:init(trainid,d_data)
    obj:bindUpListener()
    obj:bindInListener()
    obj:bindCloseListener()
    obj:activeUpdate()
    return obj
end
function showTrainFunc(trainid,d_data,onloaded)
	local layer = TrainFuncLayer.new(trainid,d_data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
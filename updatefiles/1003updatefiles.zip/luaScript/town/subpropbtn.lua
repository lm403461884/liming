local kLabelProp = "lbl_prop"
local kImagCoin = "lbl_coin"
local kLabelVal = "lbl_coin_val"
local kBtnSub = "btn_add_content"
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local __subpropbtn={}
function __subpropbtn.init(obj,trainid,subIdx,acct)
    obj._trainid = trainid
    obj._subIdx = subIdx
    obj._propdata = trainSub[trainid][subIdx] 
    obj._acct = acct
    local goldNeed,oilNeed, pt = obj._propdata.giveAndTake(obj._acct)
    local proptxt = string.format("%s%s%d",obj._propdata.txt,TxtList.addSymbol,pt)
    obj:egSetLabelStr(kLabelProp,proptxt)
    if goldNeed>0 then
        obj:egChangeImg(kImagCoin,ImageList.comm_gold,UI_TEX_TYPE_PLIST)
        obj:egSetBMLabelStr(kLabelVal,Funs.formatNum(goldNeed))
        if obj._acct.gold < goldNeed then
            --obj:egSetWidgetColor(kLabelVal,kRedColor)
            --obj:egSetWidgetTouchEnabled(kBtnSub,false)
            obj:egSetWidgetEnabled(kBtnSub,false)
        end
    elseif oilNeed>0 then
        obj:egChangeImg(kImagCoin,ImageList.comm_oil,UI_TEX_TYPE_PLIST)
        obj:egSetBMLabelStr(kLabelVal,Funs.formatNum(oilNeed))
        if obj._acct.oil < oilNeed then
           -- obj:egSetWidgetColor(kLabelVal,kRedColor)
            --obj:egSetWidgetTouchEnabled(kBtnSub,false)
            obj:egSetWidgetEnabled(kBtnSub,false)
        end
    end
    
end
function __subpropbtn.onClicked(obj,callback)
    obj._clickCallBack = callback
end
--����
function __subpropbtn.bindUpListener(obj)
    local function touchEnded(sender)
       sender:setTouchEnabled(false)
       if obj._clickCallBack then obj._clickCallBack() end
    end
    obj:egBindTouch(kBtnSub,nil,nil,touchEnded,nil)
end
SubPropBtn={}
function SubPropBtn.new(trainid,subIdx,acct)
    local obj = {}
    CocosWidget.install(obj,JsonList.trainSubUpdate)
    table_aux.unpackTo(__subpropbtn, obj)
    obj:init(trainid,subIdx,acct)
    obj:bindUpListener()
    return obj
end
local kLblLv = "lbl_note_lv"
local kPanelItem = "item_list"
local kBtnPro = "btn_pro"
local kBtnMult = "btn_mult"
local kMinRowCnt = 2
local kColCnt = 3
local kCellW = 300
local kCellH = 260
local __growlayer={}
function __growlayer.init(obj,d_data)  
   obj._d_data = d_data
   obj._scrollView = obj:egGetScrollView(kPanelItem)
   obj._size = obj._scrollView:getSize() --������ԭʼ�ߴ�
   obj._maxLv = obj._d_data.digLv * numDef.unitLvFactor 
   obj:egSetLabelStr(kLblLv,string.format("%s LV%d",TxtList.maxGrowLv,obj._maxLv))
   obj:loadHeros()
   obj:egChangeBtnImg(kBtnPro,ImageList.btn_brown_d,ImageList.btn_brown_d,"",UI_TEX_TYPE_PLIST)
   obj:egChangeBtnImg(kBtnMult,ImageList.btn_brown_d,ImageList.btn_brown_d,"",UI_TEX_TYPE_PLIST)
end
function __growlayer.loadHeros(obj)
    obj._totalCnt = #obj._d_data.heroList --Ӣ��������
    obj._maxRow=kMinRowCnt
    obj._loadedNum = 0
    if obj._totalCnt > kColCnt*kMinRowCnt then
        obj._maxRow = math.ceil(obj._totalCnt/kColCnt)
        local newh = kCellH*obj._maxRow --��������߶�
        obj._scrollView:setInnerContainerSize(CCSizeMake(obj._size.width,newh))
        obj:bindItemScrollListener()
    end
    obj:addHeroItem(kColCnt*kMinRowCnt)
end
function  __growlayer.addHeroItem(obj,num)
    if not num then num = 1 end
    local leftCnt = obj._totalCnt - obj._loadedNum
    if num > leftCnt then num = leftCnt end
    local startIdx = obj._loadedNum + 1
    local endIdx = obj._loadedNum + num 
    for idx=startIdx,endIdx do 
        obj._loadedNum = idx
        local curRow = math.ceil(obj._loadedNum/kColCnt)
        local y = (obj._maxRow - curRow)*kCellH
        local x = (idx-1)%kColCnt*kCellW
        local growItem = GrowHero.new(obj._d_data.heroList[idx])
        growItem:egSetPosition(x,y)
        obj._scrollView:addChild(growItem:egNode(),idx,idx)
        obj._loadViewH = kCellH*curRow
    end
end

function __growlayer.bindItemScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then 
            if obj._totalCnt <= obj._loadedNum then return end --�Ѽ�����
            local innerContainer = obj._scrollView:getInnerContainer()
            local posY = innerContainer:getPositionY()
            local size = innerContainer:getSize()
            if obj._loadViewH - posY  < size.height then
                obj:addHeroItem(kColCnt)
            end
        end
    end
    obj._scrollView:addEventListenerScrollView(scrollEvent) 
end

function __growlayer.setVisible(obj,visible)
    if visible then
        obj:egNode():setPosition(ccp(0,0))
    else
        obj:egNode():setPosition(ccp(0,-720))
    end
end
function __growlayer.bindExitEvent(obj)
    local function callback()
        AccountHelper:bind(kGrowLayer,nil)
    end
    obj:egOnExit(callback)
end
--����ѵ��
function __growlayer.bindProListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods)
		local text = string.format("%s LV 6",TxtList.needLicence)
		showPopTxt(text,sender:getPositionX()-100,sender:getPositionY()- 50)
    end
    obj:egBindTouch(kBtnPro,nil,nil,touchEnded,nil)
end
--�ؼ�ѵ��
function __growlayer.bindMultiListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods)
		local text = string.format("%s LV 7",TxtList.needLicence)
		showPopTxt(text,sender:getPositionX()-100,sender:getPositionY()- 50)
    end
    obj:egBindTouch(kBtnMult,nil,nil,touchEnded,nil)
end
GrowLayer={}
function GrowLayer.new(d_data)
    local obj = TouchWidget.new(JsonList.growLayer)
    table_aux.unpackTo(__growlayer, obj)
    obj:init(d_data)
    obj:bindExitEvent()
	obj:bindProListener()
	obj:bindMultiListener()
    AccountHelper:bind(kGrowLayer,obj)
    return obj
end

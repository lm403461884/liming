local kBtnItem = "Button_member"
local kLblLv = "lbl_member_lv"
local kLblName = "lbl_member_name"
local kLblMark = "Label_mark"
--local kLblDonation = "lbl_donation"
--local kLblGet = "lbl_get"
local kLblElo = "lbl_elo"
local kLblReward = "lbl_reward_val"
local kLblRank = "lbl_guild_num"
local kBtnFire = "btn_fire"
local kImgShowSelf = "img_show_self"
local kImgSelect ="img_select"

local color1 = ccc3(171,220,245)
local color2 = ccc3(252,151,153)
local __guildmemberitem={}
function __guildmemberitem.init(obj,d_data)
    if obj._kind==1 then
        obj._data = club_search
    elseif obj._kind == 3 then
        obj._data = d_data    
    else
        obj._data = club_data
    end
    obj:egSetBMLabelStr(kLblLv,obj._data.members[obj._guid].digLv)
    obj:egSetLabelStr(kLblName,obj._data.members[obj._guid].name)
    if obj._data.managerID == obj._guid or obj._data.manager == obj._data.members[obj._guid].name then  --�Ƿ�᳤
        obj:egSetLabelStr(kLblMark,TxtList.president)
    else
        obj:egSetLabelStr(kLblMark,TxtList.member)
    end
    obj:egSetLabelStr(kLblRank,obj._rank..".")
    if obj._data.members[obj._guid].reward and obj._data.members[obj._guid].reward>0 then
        obj:egSetLabelStr(kLblReward,obj._data.members[obj._guid].reward)
    else
        obj:egSetLabelStr(kLblReward,0)
    end    
    obj:egSetLabelStr(kLblElo,obj._data.members[obj._guid].elo)
     obj._btnMember = tolua.cast(obj:egGetWidgetByName(kBtnItem),"Button")
    obj:addprop("guid",obj._guid)
    obj:addprop("rank",obj._rank)
    obj:egHideWidget(kBtnFire)
    obj._clickCallback = nil
end

function __guildmemberitem.bindFireListener(obj)
    local function touchEnded()
       -- SendMsg[938009](obj._guid)
       --club_data.members[obj._guid]=nil
       if obj._clickCallback then 
          obj._clickCallback(obj)
       end
    end
    obj:egBindTouch(kBtnFire,nil,nil,touchEnded,nil)    
end
function __guildmemberitem.markMyself(obj)
    --obj:egSetWidgetColor(kBtnItem,color1)
    --obj:egShowWidget(kImgShowSelf)
    obj._btnMember:setEnabled(false)
end
function __guildmemberitem.setFocused(obj,focused)
    obj._btnMember:setFocused(focused)
end

function __guildmemberitem.setIdx(obj,idx)
    obj:egSetLabelStr(kLblRank,idx..".")
    obj._rank = idx
    obj:setprop("rank",idx)
end
function __guildmemberitem.onClicked(obj,callback)
    obj._clickCallback = callback
end

GuildMemberItem = {}
function GuildMemberItem.new(guid,kind,rank,d_data)
   local obj ={}
   CocosWidget.install(obj,JsonList.guildMemberItem)
   BaseProp.install(obj)
   InnerProp.install(obj)
   table_aux.unpackTo(__guildmemberitem,obj)
   obj._guid = guid
   obj._kind = kind
   obj._rank = rank
   obj:init(d_data)
   obj:bindFireListener()
   return obj
end
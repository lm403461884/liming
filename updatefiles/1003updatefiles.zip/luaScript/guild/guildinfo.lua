--local kLblName = "lbl_guild_name"
local kLblNum = "lbl_members_val"
local kLblInfo = "lbl_guild_info"
local kBtnSelect = "btn_join_guild"
local kLblSelect = "lbl_join"
local kLblHonorVal = "lbl_honor_val"
local kLblRankVal = "lbl_rank_val"
local kLblRewardVal = "lbl_reward_val"
local kPanelTxt = "txt_info_panel"
local kTxtW = 348
local kTxtH = 30

local __guildinfo={}
function __guildinfo.init(obj,d_data)
    if obj._kind == 1 then  --Ϊ��������������info
       obj._data = club_search 
    elseif obj._kind == 3 then --�鿴�Ĺ���info
        obj._data = d_data   
    else              --�ҵĹ���info
        obj._data = club_data
    end
    obj:egSetLabelStr(kLblHonorVal,obj._data.honor)
    obj:egSetLabelStr(kLblRankVal,obj._data.rank)
    if obj._data.reward and obj._data.reward>0 then
        obj:egSetLabelStr(kLblRewardVal,obj._data.reward)
    else
        obj:egSetLabelStr(kLblRewardVal,0)  
    end    
    obj:egSetLabelStr(kLblNum,string.format("%d%s%d",obj._data.membersCount,"/",50))
    obj:loadGuildDesc()
    if obj._kind == 1 then
         if not club_data then 
             obj:egSetLabelStr(kLblSelect,TxtList.joinGuild)
         else
             obj:egHideWidget(kBtnSelect)    
         end   
    elseif obj._kind == 3 then
        if club_data or not account_data.train[train.def.guild] then
             obj:egHideWidget(kBtnSelect)
             obj:egHideWidget(kLblSelect)
        else
            obj:egSetLabelStr(kLblSelect,TxtList.joinGuild)
        end
    else
        if obj._data.managerID==account_data.guid then  --�Ƿ�Ϊ�᳤
           obj:egSetLabelStr(kLblSelect,TxtList.dissolveGuild)
        else
           obj:egSetLabelStr(kLblSelect,TxtList.leaveGuild)
        end
    end    
end
function __guildinfo.loadGuildDesc(obj)
    local lbl = tolua.cast(obj:egGetWidgetByName(kLblInfo),"Label")
    lbl:setText(obj._data.clubDesc)
	local lblsize = lbl:getSize()
	local rows = math.ceil(lblsize.width/kTxtW)
	local newh = rows*kTxtH
	lbl:setTextAreaSize(CCSizeMake(kTxtW,newh))
	local panel = obj:egGetWidgetByName(kPanelTxt)
	lbl:setPosition(ccp(0,newh))
	panel:setSize(CCSizeMake(kTxtW,newh))
end
function __guildinfo.bindBtnListener(obj)
    local function touchEnded(sender)
       --obj:egSetWidgetTouchEnabled(kBtnSelect,false)
	   sender:setTouchEnabled(false)
       if obj._kind==1 then                                   --���빫��
           SendMsg[938004](obj._data.cid)
           obj:egSetLabelStr(kLblSelect,TxtList.apllied)
           print("want to join guild")
       elseif obj._kind==3 then
           SendMsg[938004](obj._data.cid)
           obj:egSetLabelStr(kLblSelect,TxtList.apllied)
       else                                                  --��ɢ������뿪����
           if obj._clickCallback then obj._clickCallback() end
       end
       sender:setTouchEnabled(true)    
    end
    obj:egBindTouch(kBtnSelect,nil,nil,touchEnded,nil)
end

function __guildinfo.onClicked(obj,callback)
    obj._clickCallback = callback
end

--kind=2 �ҵĹ���
--kind=1 ��������
--kind=3 �鿴����
GuildInfo={}
function GuildInfo.new(kind,d_data)  
    local obj = {}
    CocosWidget.install(obj,JsonList.guildInfo)
    table_aux.unpackTo(__guildinfo, obj)
    obj._kind = kind
    obj:init(d_data)
    obj:bindBtnListener()
    return obj
end
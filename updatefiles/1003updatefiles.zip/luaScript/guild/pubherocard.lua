local kImgHero = "btn_equip_hero"
local kLblHeroLv = "lbl_hero_lv"
local kImgEquip = "img_item"
local kLblEquipLv = "lbl_lv"
local kImgColor = "img_color_bg"
local kBtnEquip = "btn_equip_bg"

local __pubherocard={}
function __pubherocard.init(obj,heroinfo)
    local heroid = heroinfo.heroid
	local herolv = heroinfo.herolv
	local equipid = heroinfo.equipid
	local equipqa = heroinfo.equipqa
	local equiplv = heroinfo.equiplv
	obj:egSetWidgetTouchEnabled(kImgHero,false)
	obj:egSetWidgetTouchEnabled(kBtnEquip,false)
    obj:egChangeBtnImg(kImgHero,hero_data[heroid].photo,"","",UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblHeroLv,herolv)
	obj:egSetBMLabelStr(kLblEquipLv,equiplv)
    obj:egChangeImg(kImgEquip,equipCfg[equipid].icon,UI_TEX_TYPE_PLIST)
	obj:egSetWidgetColor(kImgColor,KVariantList.equipColor[equipqa])
end

PubHeroCard = {}
function PubHeroCard.new(heroinfo)
   local obj ={}
   CocosWidget.install(obj,JsonList.pubHeroCard)
   table_aux.unpackTo(__pubherocard,obj)
   obj:init(heroinfo)
   return obj
end
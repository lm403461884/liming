local kGuildOrder =0
local __guildscene={}
function __guildscene.init(obj)
    obj._guildlayer = GuildLayer.new()
    obj._guildlayer:egAttachTo(obj,kGuildOrder,kGuildOrder)
end

--[[function __guildscene.activeUpdata(obj)
    local function guildUpdate()
        if not AccountHelper:isLocked(kStateGuildData) then
            obj:egUnbindUpdate()
            obj:getClubHonor()
            obj._guildlayer = GuildLayer.new()
            obj._guildlayer:egAttachTo(obj,kGuildOrder,kGuildOrder)
        end
    end
    
    obj:egBindUpdate(guildUpdate)
end

function __guildscene.getClubHonor()--{{{
	local t = {}
	for _, mbr in pairs(club_data.members) do
		t[#t+1] = mbr
	end
	table.sort(t, 
		function(mbr_a, mbr_b) 
			return mbr_a.elo > mbr_b.elo 
		end)
	for idx, mbr in ipairs(t) do
		if idx >= 1 and idx <= 10 then
			mbr.power = 0.05
		elseif idx >= 11 and idx <= 20 then
			mbr.power = 0.025
		elseif idx >= 21 and idx <= 30 then
			mbr.power = 0.012
		elseif idx >= 31 and idx <= 40 then
			mbr.power = 0.01
		else
			mbr.power = 0.003
		end
		local lastreward = mbr.reward or 0
		lastreward = lastreward + mbr.elo * 0.4 + club_data.reward * mbr.power
        mbr.reward = math.max(1, math.floor(lastreward))
	end
end--}}}--]]
GuildScene={}
function GuildScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__guildscene, obj)
    obj:init()
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
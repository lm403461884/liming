--����ģ��
local kPanelChat = "chat_panel"
local kBtnSend = "btn_sendmsg"
local kImgChatBox  = "img_info_bg"
local kLblChatTxt = "lbl_show_info"
local kBtnGuildDetail = "btn_guild_info"
local kTfChat = "tf_chat"
local kPanelChatBg = "lblbg_panel"
--��������
local kBtnPub = "btn_chat"
local kBtnInter = "btn_guild_inter"
local kBtnHide = "btn_hide"
local kImgNotice = "img_notice"
local kImgNoticeInner = "img_notice_inner"
local kImgNoticePub = "img_notice_pub"
local kPanelLayer ="base_panel"
local kPanelPub = "pub_panel"
local kPanelInner = "inner_panel"
local kListMsg = "list_msg"
local kListPubMsg = "list_pub_msg"
local kImgState = "img_state_arr"
local kLblGuildName = "lbl_guildname"
local kLblPubChat = "lbl_chat_pub"
--�����������
local kPanelPopMenu = "popmenu_panel"
local kBtnUserInfo = "btn_userinfo"
local kBtnPubInfo = "btn_guildinfo"
local kBtnJoinPub = "btn_sendjoin"
local kImgMenuBg = "menu_bg"
local kPanelMenuBtn = "menu_btn_panel"
local kLblPopUser = "lbl_pop_user"
local kPanelMask = "pop_mask_panel"

--û�й���
local kBtnIn = "btn_in"
local kPanelNoGuild = "noguild_panel"
local kImgTrain = "img_train"
local kLblNoTrain = "lbl_no_guild"

local kMoveDis = 640
local kMaxNum = 7
local kPubChat = 1
local kNoGuildTrain = 2
local kNoGuild = 3
local kInnerGuild = 4
local kShowZorder = 3
local kHideZorder = 1
local kNoClub= 3
local kTxtW = 490
local kTxtH = 32
local kPos1 = ccp(92,50)
local kPos2 = ccp(92,130)
local kPos3 = ccp(92,209)
local kGrayColor = ccc3(128,128,128)
local kWhiteColor = ccc3(255,255,255)
local __chatlayer={}
function __chatlayer.init(obj)
    obj._panel = obj:egGetWidgetByName(kPanelLayer)
    obj._panel:setPosition(ccp(-kMoveDis,0))
    obj._msgList = obj:egGetListView(kListMsg)
	obj._pubmsgList = obj:egGetListView(kListPubMsg)
    obj._listsize = obj._msgList:getSize()
    obj._shown = false
	obj._lastMsgNum = 0
	obj._startIdx = 0
	obj._oldH = 0
	obj._oldPubH =0
	obj:showPopMenu(false)
	obj:loadPubMsg()--���ع���������Ϣ
	obj:changeArraw(0,0) --��ʼ״̬Ϊ����δ����
    obj:showNotice( ChatHelper.hasPubMsg() or ChatHelper.hasInnerMsg()) --�����Ƿ�����Ϣ,������ʾͼƬ����ʾ״̬
    obj:showGuildChat()
	obj:activeNoticeTimer()
end
function __chatlayer.showPopMenu(obj,show,pos)
	if show then
		obj:egShowWidget(kPanelPopMenu)
		obj:egShowWidget(kBtnUserInfo)
		obj:egShowWidget(kPanelMenuBtn)
		obj:egShowWidget(kPanelMask)
		obj:egSetLabelStr(kLblPopUser,obj._selectedPubItem:getprop("name") )
		local lblPopUser = obj:egGetWidgetByName(kLblPopUser)
		local basepanel = obj:egGetWidgetByName(kPanelLayer)
		local btnpanel = obj:egGetWidgetByName(kPanelMenuBtn)
		local imgwidget = obj:egGetWidgetByName(kImgMenuBg)
		local imgh = imgwidget:getSize().height
		local btnUser = obj:egGetWidgetByName(kBtnUserInfo)
		local btnPub = obj:egGetWidgetByName(kBtnPubInfo)
		local btnJoin = obj:egGetWidgetByName(kBtnJoinPub)
		local userClubId = obj._selectedPubItem:getprop("clubid") 
		if userClubId > 0 then
		    if club_data or not account_data.train[train.def.guild] then
		        obj:egShowWidget(kBtnPubInfo)
                imgwidget:setScaleY(0.7)
                imgh = imgh*0.7
                btnUser:setPosition(kPos2)
                btnPub:setPosition(kPos1)
		    else
                obj:egShowWidget(kBtnPubInfo)
                obj:egShowWidget(kBtnJoinPub)
                
                imgwidget:setScaleY(1)
                btnUser:setPosition(kPos3)
                btnPub:setPosition(kPos2)
                btnJoin:setPosition(kPos1)
			end
		else
			imgwidget:setScaleY(0.5)
			btnUser:setPosition(kPos1)
			imgh = imgh*0.5
		end
		btnpanel:setSize(CCSizeMake(btnpanel:getSize().width,imgh))
		btnpanel:setPosition(ccp(btnpanel:getPositionX(),-imgh/2))
		lblPopUser:setPosition(ccp(lblPopUser:getPositionX(),imgh-25))
		local posNode = basepanel:convertToNodeSpace(ccp(pos.x,pos.y))
		local panelh = basepanel:getSize().height
		if posNode.y + imgh/2 > panelh then posNode.y = panelh - imgh/2
		elseif posNode.y - imgh/2 < 0 then posNode.y = 0 end
		local menupanel = obj:egGetWidgetByName(kPanelPopMenu)
		menupanel:setPosition(posNode)
	else
		obj:egHideWidget(kPanelPopMenu)
		obj:egHideWidget(kBtnUserInfo)
		obj:egHideWidget(kBtnPubInfo)
		obj:egHideWidget(kBtnJoinPub)
		obj:egHideWidget(kPanelMenuBtn)
		obj:egHideWidget(kPanelMask)
	end
end
--���ع���������Ϣ
function __chatlayer.loadPubMsg(obj)
	obj._maxPubMsgId = ChatHelper.getMaxId()
	obj._minPubMsgId = obj._maxPubMsgId
	obj._selectedPubItem = nil
	if obj._minPubMsgId > 0 then 
        obj:addPubMsg(kMaxNum) 
    end
end
--expand: 0 ����״̬ 1չ��״̬
--pressed 0 ��ͨ״̬ 1����״̬
function __chatlayer.changeArraw(obj,expand,pressed)
	local imgArrow =  tolua.cast(obj:egGetWidgetByName(kImgState),"ImageView")
	local imgSrc = {ImageList.btn_arrow_n,ImageList.btn_arrow_s}
	if pressed==0 then
		imgArrow:loadTexture(ImageList.btn_arrow_n,UI_TEX_TYPE_PLIST)
	else
		imgArrow:loadTexture(ImageList.btn_arrow_s,UI_TEX_TYPE_PLIST)
	end
	if expand==0 then
		imgArrow:setRotation(270)
	else
		imgArrow:setRotation(90)
	end
end
--��ʾ/������Ϣ��ʾ
function __chatlayer.showNotice(obj,show)
    local widget = obj:egGetWidgetByName(kImgNotice)
    widget:setVisible(show)
    if show then
        local scaleto1 = CCScaleTo:create(1,0.6)
        local scaleto2 = CCScaleTo:create(1,0.8)
        local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
        local repeatever = CCRepeatForever:create(sequence)
        widget:runAction(repeatever)
	else
	    widget:stopAllActions()
	    obj:egUnbindWidgetUpdate(kImgNotice)
	    account_data.noticeClub = false
	end
end
function __chatlayer.showPubNotice(obj,show)
	local widget = obj:egGetWidgetByName(kImgNoticePub)
    widget:setVisible(show)
    if show then
        local scaleto1 = CCScaleTo:create(1,0.6)
        local scaleto2 = CCScaleTo:create(1,0.8)
        local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
        local repeatever = CCRepeatForever:create(sequence)
        widget:runAction(repeatever)
	else
	    widget:stopAllActions()
	end
end
function __chatlayer.showInnerNotice(obj,show)
	local widget = obj:egGetWidgetByName(kImgNoticeInner)
    widget:setVisible(show)
    if show then
        local scaleto1 = CCScaleTo:create(1,0.6)
        local scaleto2 = CCScaleTo:create(1,0.8)
        local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
        local repeatever = CCRepeatForever:create(sequence)
        widget:runAction(repeatever)
	else
	    widget:stopAllActions()
	end
end
--��ʾ���������������
function __chatlayer.showChatPanel(obj,show)
	--����ģ��
	if show then
		obj:egShowWidget(kPanelChat)
		obj:egShowWidget(kBtnSend)
		obj:egShowWidget(kBtnGuildDetail)
		obj:egShowWidget(kImgChatBox)
		--obj:egSetWidgetColor(kLblChatTxt,kWhiteColor)
	else
		obj:egHideWidget(kPanelChat)
		obj:egHideWidget(kBtnSend)
		obj:egHideWidget(kBtnGuildDetail)
		obj:egHideWidget(kImgChatBox)
		obj:egSetLabelStr(kLblChatTxt,TxtList.promptInput)
		local textField = tolua.cast(obj:egGetWidgetByName(kTfChat),"TextField")
		textField:setText("")
		obj:egSetWidgetColor(kLblChatTxt,kGrayColor)
	end	
end
--�����Ƿ񽫹�����ΪĬ��ѡ����
function __chatlayer.focusInner(obj,focus)
	local btnInner =  tolua.cast(obj:egGetWidgetByName(kBtnInter),"Button")
	local btnPub = tolua.cast(obj:egGetWidgetByName(kBtnPub),"Button")
	local innerpanel = obj:egGetWidgetByName(kPanelInner)
	local pubpanel = obj:egGetWidgetByName(kPanelPub)
	local parentNode = innerpanel:getParent()
	obj._selectedPubItem = nil
    obj:showPopMenu(false)
	if focus then
		btnInner:setFocused(false)
		btnInner:setTouchEnabled(false)
		btnPub:setTouchEnabled(true)
		btnPub:setFocused(true)
		parentNode:reorderChild(innerpanel,kShowZorder)
		parentNode:reorderChild(pubpanel,kHideZorder)
		obj:egShowWidget(kListMsg)
		obj:egHideWidget(kListPubMsg)
	else
		btnInner:setFocused(true)
		btnInner:setTouchEnabled(true)
		btnPub:setFocused(false)
		btnPub:setTouchEnabled(false)
		parentNode:reorderChild(innerpanel,kHideZorder)
		parentNode:reorderChild(pubpanel,kShowZorder)
		obj:egHideWidget(kListMsg)
		obj:egShowWidget(kListPubMsg)
	end
end
--��ʾ�������޹���ģ�飬�������Ƿ��г��������ʾģʽ
function __chatlayer.showNoGuild(obj,show,hasTrain)
	if show then
		obj:egShowWidget(kPanelNoGuild)
		obj:egShowWidget(kBtnIn)
		if hasTrain then
			obj:egSetOpacityOf(kImgTrain,255)
			obj:egSetWidgetEnabled(kBtnIn,true)
			obj:egHideWidget(kLblNoTrain)
		else
			obj:egSetWidgetEnabled(kBtnIn,false)
			obj:egSetOpacityOf(kImgTrain,150)
			obj:egShowWidget(kLblNoTrain)
		end
	else
		obj:egHideWidget(kBtnIn)
		obj:egHideWidget(kPanelNoGuild)
		
	end
end
--�����л����ڲ�����
function __chatlayer.showGuildChat(obj)
    obj:focusInner(true) --���ᴦ��ѡ��״̬
    if club_data then
		obj:showNoGuild(false,false)
		obj:showChatPanel(true)
		obj:egSetLabelStr(kLblGuildName,club_data.clubName)
        obj._shownType = kInnerGuild
		if obj._lastMsgNum == 0 then
            obj:clearMsgList()
            obj._lastMsgNum = #club_data.messageOrder --������Ϣʱ���ڵ������Ϣ����
            obj._startIdx = obj._lastMsgNum
            obj:addInnerMsg(7)
        end
	    obj:activeInnerReceiver()--�����ڲ���Ϣ����
    else
		obj:egSetLabelStr(kLblGuildName,TxtList.guildChat)
		obj:egHideWidget(kListMsg)
		obj:showChatPanel(false)
        if account_data.train[train.def.guild] then
			obj:showNoGuild(true,true)
			obj._shownType = kNoGuild
        else
			obj:showNoGuild(true,false)
			obj._shownType = kNoGuildTrain
        end
    end
end
function __chatlayer.showPubChat(obj)
	obj._shownType = kPubChat
	obj:focusInner(false) --���Ĵ���ѡ��״̬
	obj:showNoGuild(false,false)
	obj:showChatPanel(true)
	obj:egHideWidget(kBtnGuildDetail)
	obj:activePubReceiver()--�����ڲ���Ϣ����
end
--���ع����ڲ���Ϣ
function __chatlayer.addInnerMsg(obj,num)
    if obj._startIdx <= 0 then return end
    local startIdx = obj._startIdx
    local endIdx = math.max(startIdx - num+1,1)
    for idx = startIdx,1,-1 do
        if idx < endIdx then break end
        local msgid = club_data.messageOrder[idx]
        local msginfo = club_data.message[msgid]
        if (msginfo.type ==3 and not club_data.members[msginfo.guid]) or (msginfo.type==1 and club_data.managerID~=account_data.guid) then
            endIdx = math.max(endIdx-1,1)
        else
            local msgItem = MsgItem.new(msgid)
            obj._msgList:pushBackCustomItem(msgItem:egNode())
        end
    end
    obj._startIdx = endIdx-1
end
function __chatlayer.bindPubMsgClickingEvent(obj,msgItem)
	local function callback(sender)
	    if obj._selectedPubItem ~= sender then
            obj._selectedPubItem = nil
            obj:showPopMenu(false)
		end
	end
	msgItem:onItemClicking(callback)
end
function __chatlayer.bindPubMsgClickedEvent(obj,msgItem)
	local function callback(sender,pos)
	    if obj._selectedPubItem == sender then
	        obj._selectedPubItem = nil
            obj:showPopMenu(false)
	    else
	        local userguid = sender:getprop("guid")
            if  userguid~= account_data.guid and userguid ~=0 then
                obj._selectedPubItem = sender
                obj:showPopMenu(true,pos)
            end
		end
	end
	msgItem:onItemClicked(callback)
end
--���ع���������Ϣ
function __chatlayer.addPubMsg(obj,num)
    if obj._minPubMsgId  <= 0 then return end
    
    local startIdx = obj._minPubMsgId 
    local endIdx = math.max(startIdx - num+1,1)
    for idx = startIdx,endIdx,-1 do
        local msg = ChatHelper.getMsgById(idx)
        local msgItem = PubMsgItem.new(msg)
		obj:bindPubMsgClickingEvent(msgItem)
		obj:bindPubMsgClickedEvent(msgItem)
		obj._pubmsgList:pushBackCustomItem(msgItem:egNode())
		--[[
		local function callback(userguid)
			ChatHelper.shieldMsg(userguid)
			obj:clearPubMsgList()
			obj:loadPubMsg()
		end
		msgItem:shieldMsgBack(callback)
		--]]
    end
    obj._minPubMsgId = endIdx-1
end
--����Ѽ��ص�������Ϣ
function __chatlayer.clearPubMsgList(obj)
    obj:egUnbindWidgetUpdate(kLblPubChat)--�رչ�����Ϣ���ն�ʱ��
     for idx =1,obj._pubmsgList:getChildrenCount() do
        local item = obj._pubmsgList:getItem(idx-1)
        obj._pubmsgList:removeChildByTag(item:getTag(),true)
     end
     obj._pubmsgList:removeAllItems()
     obj._pubmsgList:jumpToTop()
	 obj._selectedPubItem = nil
	 obj:showPopMenu(false)
	 obj._oldPubH = 0
	 obj._minPubMsgId = 0
	 obj._maxPubMsgId = 0
end
--���б������¼�
function __chatlayer.bindScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._msgList:getInnerContainerSize().height
            if obj._oldH < curH then
                if obj._shownType == kInnerGuild then
                    obj:addInnerMsg(kMaxNum)
                end
                obj._oldH = curH
			end
        end
    end
    obj._msgList:addEventListenerScrollView(scrollEvent)
end
--�󶨹�����Ϣ�б������¼�
function __chatlayer.bindPubScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._msgList:getInnerContainerSize().height
            if obj._oldPubH < curH then
                if obj._shownType == kPubChat then
                    obj:addPubMsg(kMaxNum)
                end
                obj._oldPubH = curH
			end
        end
    end
    obj._pubmsgList:addEventListenerScrollView(scrollEvent)
end

--����Ѽ��ص�������Ϣ
function __chatlayer.clearMsgList(obj)
    obj:egUnbindWidgetUpdate(kLblGuildName)--�ر��ڲ���Ϣ���ܶ�ʱ��
     for idx =1,obj._msgList:getChildrenCount() do
        local item = obj._msgList:getItem(idx-1)
        obj._msgList:removeChildByTag(item:getTag(),true)
     end
     obj._msgList:removeAllItems()
     obj._msgList:jumpToTop()
	 obj._lastMsgNum = 0
	 obj._startIdx = 0
	 obj._oldH = 0
end

--�����ڲ���Ϣ����
--�����л��������������ʱ��Ҫ�ر�
function __chatlayer.activeInnerReceiver(obj)
	obj:showInnerNotice(false)
    local function callback()
        if #club_data.messageOrder > obj._lastMsgNum then
            obj._lastMsgNum = obj._lastMsgNum + 1
            local msgItem = MsgItem.new(club_data.messageOrder[obj._lastMsgNum])
            obj._msgList:insertCustomItem(msgItem:egNode(),0)
            ChatHelper.setHasInnerMsg(false)
            --SoundHelper.playEffect(SoundList.message)
        end
    end
    if obj._shownType == kInnerGuild and obj._shown then
        obj:egBindWidgetUpdate(kLblGuildName,callback)
		ChatHelper.setHasInnerMsg(false)
    end
end
--������Ϣ����
--�����л��������������ʱ��Ҫ�ر�
function __chatlayer.activePubReceiver(obj)
	obj:showPubNotice(false)
    local function callback()
	    local msg = ChatHelper.getMsgById(obj._maxPubMsgId +1)
	    if msg then
	        obj._maxPubMsgId  = obj._maxPubMsgId +1
            local msgItem = PubMsgItem.new(msg)
			obj:bindPubMsgClickingEvent(msgItem)
			obj:bindPubMsgClickedEvent(msgItem)
            obj._pubmsgList:insertCustomItem(msgItem:egNode(),0)
            ChatHelper.setHasPubMsg(false)
            --[[
				local function callback(userguid)
					ChatHelper.shieldMsg(userguid)
					obj:clearPubMsgList()
					obj:loadPubMsg()
				end
				msgItem:shieldMsgBack(callback)
			--]]
        end
    end
    if obj._shownType == kPubChat and obj._shown then
        obj:egBindWidgetUpdate(kLblPubChat,callback)
		ChatHelper.setHasPubMsg(false)
    end
end
--��Ϣ��ʾ��ʱ��
--��������ʱ����,ͬʱ�ر���Ϣ������
function __chatlayer.activeNoticeTimer(obj)
    local function callback()
		
        if ChatHelper.hasPubMsg()  or ChatHelper.hasInnerMsg() then
                --SoundHelper.playEffect(SoundList.message)
                obj:showNotice(true)
                obj:egUnbindWidgetUpdate(kImgNotice)
        end
    end
    obj:egUnbindWidgetUpdate(kLblGuildName)
	obj:egUnbindWidgetUpdate(kLblPubChat)
	obj:showInnerNotice(false)
	obj:showPubNotice(false)
    obj:egBindWidgetUpdate(kImgNotice,callback)
end

--�����¼�����
function __chatlayer.bindInfoBgListener(obj)
    local lblTxt = obj:egGetWidgetByName(kLblChatTxt)
    local lblbg = obj:egGetWidgetByName(kPanelChatBg)
    local bgsize = lblbg:getSize()
    local txtsize = lblTxt:getSize()
    local y = lblTxt:getPositionY()
    local startX = 0
    local function touchBegan(sender)
        if txtsize.width > bgsize.width then
            startX =sender:getTouchStartPos().x
        end
    end
    local function touchMoved(sender)
        if txtsize.width > bgsize.width then
            local movedX = sender:getTouchMovePos().x - startX
            local oldx = lblTxt:getPositionX()
            local newx = oldx + movedX
            if newx > 0 then newx = 0 
            elseif newx < bgsize.width - txtsize.width then newx =  bgsize.width - txtsize.width end
            lblTxt:setPosition(ccp(newx,y))
        end
    end
    local function touchEnded(sender)
         local widget = obj:egGetWidgetByName(kTfChat)
         local textField = tolua.cast(widget,"TextField")
         textField:attachWithIME()
    end
    obj:egBindTouch(kImgChatBox,touchBegan,touchMoved,touchEnded,nil)
end
function __chatlayer.bindInputListener(obj)
	local lblbg = obj:egGetWidgetByName(kPanelChatBg)
	local lblTxt = obj:egGetWidgetByName(kLblChatTxt)
	local y = lblTxt:getPositionY()
	local size = lblbg:getSize()
    local function textFieldEvent(sender, eventType)
        local textField = tolua.cast(sender,"TextField")
        local text = textField:getStringValue()
        if text == "" then 
            obj:egSetLabelStr(kLblChatTxt,TxtList.promptInput)
            lblTxt:setColor(kGrayColor)
        else
			--text = Funs.subStr(text,numDef.ChatMsgLen)
            obj:egSetLabelStr(kLblChatTxt,text)
            lblTxt:setColor(kWhiteColor)
        end
        if lblTxt:getSize().width > size.width then
			lblTxt:setPosition(ccp(size.width -lblTxt:getSize().width,y))
		else
			lblTxt:setPosition(ccp(0,y))
		end
    end
    local widget = obj:egGetWidgetByName(kTfChat)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent) 
end
-- ������Ϣ
function __chatlayer.bindSendMsgListener(obj) 
    local function touchEnded(sender)
        local widget = obj:egGetWidgetByName(kTfChat)
		local txtField = tolua.cast(widget,"TextField")
		local lblTxt = obj:egGetWidgetByName(kLblChatTxt)
		local y = lblTxt:getPositionY()
		local info = txtField:getStringValue() or ""
		if string.len(info) >=1 then
            if obj._shownType == kInnerGuild then
			    SendMsg[938008](info)
			elseif  obj._shownType == kPubChat  then
			    local clubid = 0
			    local clubname = ""
			    if club_data then 
                    clubid = club_data.cid 
                    clubname = club_data.clubName
                end
				 SendMsg[931008](clubid,clubname,info)
				 --�ھ���־������̸���,���빫��
				 task.updateTaskStatus(account_data,task.client_event_id.world_talk)
				 ----------------------------------------------------------
            end
            txtField:setText("")
            obj:egSetLabelStr(kLblChatTxt,TxtList.promptInput)
			lblTxt:setPosition(ccp(0,y))
            obj:egSetWidgetColor(kLblChatTxt,kGrayColor)
	    end
    end
    obj:egBindTouch(kBtnSend,nil,nil,touchEnded,nil)
end
--������빫�ᳵ��
function __chatlayer.bindGuildDetailListener(obj)
	local function touchEnded(sender)
		sender:setTouchEnabled(false)
		local scene = GuildScene.new()
		scene:egReplace()
    end
	obj:egBindTouch(kBtnGuildDetail,nil,nil,touchEnded,nil)
end
--�����������
function __chatlayer.hideWithAction(obj,offsetX)
    obj._shown = false
    obj._selectedPubItem = nil
    obj:showPopMenu(false)
     if offsetX >= kMoveDis then
        obj:egSetWidgetTouchEnabled(kBtnHide,true)
     else
        local s = 0.5*(1-offsetX/kMoveDis)
        local moveto = CCMoveTo:create(0.5,ccp(-kMoveDis,0))
        local function callback()
            obj:egSetWidgetTouchEnabled(kBtnHide,true)
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(moveto,callfunc)
        obj._panel:runAction(sequence)
    end
    obj:activeNoticeTimer()
end
function __chatlayer.hidePanel(obj)
    obj._selectedPubItem = nil
    obj:showPopMenu(false)
	if obj._shown then
		obj._shown = false
		 obj._panel:setPosition(ccp(-kMoveDis,0))
		 obj._panel:stopAllActions()
		 obj:egSetWidgetTouchEnabled(kBtnHide,true)
		 obj:activeNoticeTimer()
	end
end
function __chatlayer.showPanel(obj)
    obj._selectedPubItem = nil
    obj:showPopMenu(false)
	if not obj._shown then
		obj._shown = true
		obj:showNotice(false)
		if obj._shownType == kPubChat and ChatHelper.hasInnerMsg() then
			obj:showInnerNotice(true)
		elseif obj._shownType ~= kPubChat and ChatHelper.hasPubMsg() then
			obj:showPubNotice(true)
		end
		if 	(obj._shownType==kInnerGuild and not club_data) or
			(obj._shownType ==kNoGuildTrain and account_data.train[train.def.guild]) or
			(obj._shownType ==kNoGuild and club_data) then
			obj._lastMsgNum = 0
			obj._startIdx = 0
			obj:showGuildChat()
		elseif obj._shownType==kInnerGuild  and  club_data then
			obj:activeInnerReceiver()
		elseif obj._shownType ==kPubChat then
			 obj:activePubReceiver()
		end
		 obj._panel:setPosition(ccp(0,0))
		 obj._panel:stopAllActions()
		 obj:egSetWidgetTouchEnabled(kBtnHide,true)
	end
end
function __chatlayer.hideAllPanel(obj,isShow)
    obj._selectedPubItem = nil
    obj:showPopMenu(false)
    if isShow then
        obj._panel:setPosition(ccp(-kMoveDis,0))
		obj._panel:stopAllActions()
		obj:egSetWidgetTouchEnabled(kBtnHide,true)
		obj:activeNoticeTimer()
    else
        obj._panel:setPosition(ccp(-kMoveDis-50,0))
        obj._panel:stopAllActions()
    end
end
--��ʾ�������
function __chatlayer.showWithAction(obj,offsetX)
    obj._shown = true
    obj:showNotice(false)
    if obj._shownType == kPubChat and ChatHelper.hasInnerMsg() then
		obj:showInnerNotice(true)
	elseif obj._shownType ~= kPubChat and ChatHelper.hasPubMsg() then
		obj:showPubNotice(true)
	end
    if 	(obj._shownType==kInnerGuild and not club_data) or
		(obj._shownType ==kNoGuildTrain and account_data.train[train.def.guild]) or
		(obj._shownType ==kNoGuild and club_data) then
		obj._lastMsgNum = 0
	    obj._startIdx = 0
		obj:showGuildChat()
    elseif obj._shownType==kInnerGuild  and  club_data then
        obj:activeInnerReceiver()
	elseif obj._shownType ==kPubChat then
		 obj:activePubReceiver()
    end
    if offsetX >= kMoveDis then
        obj:egSetWidgetTouchEnabled(kBtnHide,true)
    else
        local s = 0.4*(1-offsetX/kMoveDis)
        local moveto = CCMoveTo:create(s,ccp(0,0))
        local easeout = CCEaseSineOut:create(moveto)
        local function callback()
            obj:egSetWidgetTouchEnabled(kBtnHide,true)
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(easeout,callfunc)
        obj._panel:runAction(sequence)
    end
end
--��ʾ����������ҳ�����¼�
function __chatlayer.bindShowHideListener(obj)
    local oldX = 0
    local oldY = 0
    local function touchBegan(sender)
        oldX = obj._panel:getPositionX()
		if obj._shown then
			obj:changeArraw(1,1)
		else
			obj:changeArraw(0,1)
		end
    end
    local function touchMoved(sender)
        local newX  = oldX + sender:getTouchMovePos().x - sender:getTouchStartPos().x
        if newX > 0 then newX = 0 end
        if newX < -kMoveDis then newX = -kMoveDis end
        obj._panel:setPosition(ccp(newX,oldY))
    end
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local offsetX=math.abs(obj._panel:getPositionX() - oldX)
        if obj._shown then
			obj:changeArraw(0,0)
            obj:hideWithAction(offsetX)
			SoundHelper.playEffect(SoundList.click_paper_close)
        else
			obj:changeArraw(1,0)
             if obj._clickingCallback then obj._clickingCallback() end
            obj:showWithAction(offsetX)
			SoundHelper.playEffect(SoundList.click_paper_open)
        end
    end
    obj:egBindTouch(kBtnHide,touchBegan,touchMoved,touchEnded,touchEnded)
end
--���������¼�
function __chatlayer.bindPubChatListener(obj)
    local function touchEnded(sender)
        obj:showPubChat()
		SoundHelper.playEffect(SoundList.click_paper_open)
    end
    obj:egBindTouch(kBtnPub,nil,nil,touchEnded,nil)
end
--���������¼�
function __chatlayer.bindInterChatListener(obj)
    local function touchEnded(sender)
        obj:showGuildChat()
		SoundHelper.playEffect(SoundList.click_paper_open)
    end
    obj:egBindTouch(kBtnInter,nil,nil,touchEnded,nil)
end
--���빫�ᰴť�¼�
function __chatlayer.bindEnterListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local scene = GuildScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnIn,nil,nil,touchEnded,nil)
end
--�����Ϣ�鿴��ť
function __chatlayer.bindUserInfoListener(obj)
    local function touchEnded(sender)
	--[[
		local function callback()
			obj:showPanel()
		end
		--]]
		showPubUserInfo(obj._selectedPubItem:getprop("guid"))
		obj:hidePanel()
    end
    obj:egBindTouch(kBtnUserInfo,nil,nil,touchEnded,nil)
end
--������Ϣ�鿴��ť
function __chatlayer.bindPubInfoListener(obj)
    local function touchEnded(sender)
		obj:showPopMenu(false)
		local msg = obj._selectedPubItem:getprop("msg")
		local kind = 1
		ShowGuildView(kind,msg,nil)		
		--����������Ϣ����,�Ƿ���Ҫ�رչ������?
		obj._selectedPubItem = nil
    end
    obj:egBindTouch(kBtnPubInfo,nil,nil,touchEnded,nil)
end
--���빫�ᰴť
function __chatlayer.bindJoinPubListener(obj)
    local function touchEnded(sender)
		obj:showPopMenu(false)
		local clubid = obj._selectedPubItem:getprop("clubid")
		local clubname = obj._selectedPubItem:getprop("clubname")
		SendMsg[938004](clubid) --������빫��
		ChatHelper.addNewMsg(0,0,TxtList.systemCH..TxtList.msg,0,"",string.format(TxtList.guildMsg[9],clubname))
		obj._selectedPubItem = nil
    end
    obj:egBindTouch(kBtnJoinPub,nil,nil,touchEnded,nil)
end
--�����˵�������Touch�¼�
function __chatlayer.bindPopMaskListener(obj)
    local function touchEnded(sender)
		obj._selectedPubItem = nil
		obj:showPopMenu(false)
    end
    obj:egBindTouch(kPanelMask,nil,nil,touchEnded,nil)
end
function __chatlayer.onClicking(obj,callback)
    obj._clickingCallback = callback
end
ChatLayer={}
function ChatLayer.new()
    local obj = TouchWidget.new(JsonList.chatLayer)
    table_aux.unpackTo(__chatlayer, obj)
    obj:init()
    obj:bindScrollListener() --��Ϣ�����¼�
	obj:bindPubScrollListener() --������Ϣ�����¼�
    obj:bindSendMsgListener()
	obj:bindGuildDetailListener()
    obj:bindInfoBgListener()
	obj:bindInputListener()
    obj:bindShowHideListener()
    obj:bindPubChatListener() --��������
    obj:bindInterChatListener()--�ڲ�����
    obj:bindEnterListener()
	obj:bindUserInfoListener()
	obj:bindPubInfoListener()
	obj:bindJoinPubListener()
	obj:bindPopMaskListener()
    return obj
end
local kImgBg = "img_bg"
local kLblTitle = "lbl_title"
local kLblInfo = "lbl_info"
local kLblPerson = "lbl_person"
local kImgLine = "img_line"
local kLblAttach= "lbl_attachment"
local kLblReward = "lbl_reward"
local kPanel1 = "panel_award1"
local kPanel2 = "panel_award2"
local kBtnReward = "btn_reward"
local kPanelLayer = "panel_info"

local __mailinfo={}
function __mailinfo.init(obj,msgid)
    obj._msgid = msgid
    obj._msgdata = msgQuery.getName(msgid)
    obj:egSetLabelStr(kLblTitle,obj._msgdata.msgName)
    obj:egSetLabelStr(kLblInfo,obj._msgdata.msgtext)
    obj:egSetLabelStr(kLblPerson,obj._msgdata.msgPerson)
    if obj._msgdata.type == 1 then 
        obj._award = false
    elseif obj._msgdata.type == 2 then
        obj._award = true
    end
    if not obj._award then
        obj:egSetLabelStr(kLblReward,TxtList.btnOK)
        obj:egHideWidget(kLblAttach)
        obj:egHideWidget(kImgLine)
    else
        obj:loadAward()    
    end
    
    obj:showWidthAction()
end
function __mailinfo.loadAward(obj)
    obj._reward1 = obj:egGetWidgetByName(kPanel1)
    obj._reward2 = obj:egGetWidgetByName(kPanel2)
    local count = 0
    local icon_data = obj._msgdata.accessory(account_data)
    for name,val in pairs (icon_data) do
        count = count +1
        if count <=3 then
            local iconitem = TheAward.new(name,val)
            obj._reward1:addChild(iconitem:egNode())
            iconitem:egNode():setPosition(ccp((count-1)*149,0))
            obj._reward1:setPosition(ccp(81*(4-count),225))
        else
            local iconitem = TheAward.new(item.name,item.val)
            obj._reward2:addChild(iconitem:egNode())
            iconitem:egNode():setPosition(ccp((count-4)*149,0))
            obj._reward2:setPosition(ccp(81*(7-count),164))
        end   
    end
end

function __mailinfo.showWidthAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))

    local cardbg = obj:egGetWidgetByName(kImgBg)
    cardbg:setScale(0)
    local scaleto = CCScaleTo:create(0.5,1)
    local backout = CCEaseBackOut:create(scaleto)
    local function callback()
        if obj._onloaded then obj._onloaded() end
        --obj:bindCloseListener()
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(backout,callfunc)
    cardbg:runAction(sequence)
end
function __mailinfo.onClicked(obj,callback)
    obj._callback = callback
end
--�ر�ҳ��
function __mailinfo.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
        if account_data.msgBoxList[obj._msgid][1]==0 and obj._callback then 
             message.onRead(account_data,obj._msgid)
             obj._callback() 
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end
--��ȡ��ť
function __mailinfo.bindBtnListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        if not obj._award then
            SoundHelper.playEffect(SoundList.click_paper_close)
            SendMsg[931011](obj._msgid)
            obj:egRemoveSelf()
            if account_data.msgBoxList[obj._msgid][1]==0 and obj._callback then 
                message.onRead(account_data,obj._msgid)
                obj._callback() 
            end    
        else
            SoundHelper.playEffect(SoundList.click_buy_button)
            SendMsg[931011](obj._msgid)
            message.onRead(account_data,obj._msgid)
            obj:egRemoveSelf()
            if obj._callback then obj._callback(obj._msgid) end
        end
    end    
    obj:egBindTouch(kBtnReward,nil,nil,touchEnded,nil)
end

MailInfo={}
function MailInfo.new(msgid,onload)
    local obj =  TouchWidget.new(JsonList.mailInfo)
    table_aux.unpackTo(__mailinfo, obj)
    obj._onloaded = onload
    obj:init(msgid)
    obj:bindBtnListener()
    return obj
end

local kPanelLayer = "post_panel"
local kPanelWait = "wait_panel"
local kImgLoading = "loading"
local kPanelItem = "item_list"

local kBtnBack = "btn_back"
local kBtnNote = "note_btn"
local kBtnHistory = "history_btn"
local kImgNewMail = "img_new_mail"

local kLabelNoInfo = "noinfo_lbl"
local kMaxLoadNum = 6
local kHideZorder = 1
local kShowZorder = 3
local kShownHistory = 1
local kShownNote = 2

local __postlayer={}

function __postlayer.init(obj,d_data)
   obj._d_data = d_data
   obj._loadItem = 0
   obj._itemlist = obj:egGetListView(kPanelItem)
   obj._oldH = 0
   obj._btnHistory = obj:egGetWidgetByName(kBtnHistory)
   obj._btnNote= obj:egGetWidgetByName(kBtnNote)
   if not account_data.battleSumaries or account_data.newVideo then
        AccountHelper:lock(kStateVideoList)
        SendMsg[931003]()
   end
   obj:activeWaitTimer()
   obj:showWithAction()
end
---------------
--��ʾ¼���¼��
-----------------
function __postlayer.showHistory(obj)
	obj:setHistoryClicked()
    account_data.newVideo = false
    if not account_data.battleSumaries then account_data.battleSumaries= {} end
    if #account_data.battleSumaries == 0 then
       obj:egShowWidget(kLabelNoInfo)
       obj:egSetLabelStr(kLabelNoInfo,TxtList.noHistory)
    else
		obj:addPvpItem(kMaxLoadNum)
    end
	obj:showNewMailFlag(true)
end
--����¼���¼
function __postlayer.addPvpItem(obj,num)
	local totalCnt = #account_data.battleSumaries
	if obj._loadItem >= totalCnt then return end
	local left = totalCnt - obj._loadItem
	local endIdx =  math.max(left - num+1,1)
	local startIdx =left
	for idx = startIdx,endIdx,-1 do
		local pvpItem = PvpItem.new(idx)
		obj:bindPvpItemClickEvent(pvpItem)
		obj._itemlist:pushBackCustomItem(pvpItem:egNode())
		obj._loadItem = obj._loadItem + 1
	end
	
end
--¼����Ϣ��ϸ��ȡ��ʱ��
function __postlayer.activeDetailTimer(obj,pvpItemIdx)
	local passedTime = 0
	obj:egShowWidget(kPanelWait)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
	AccountHelper:lock(kStateVideo)
	SendMsg[931004](pvpItemIdx)
	local  function callback(delta)
		passedTime = passedTime + delta
			if not  AccountHelper:isLocked(kStateVideo) then
				obj:egUnbindWidgetUpdate(kPanelWait)
				VideoDetail = videomanager.getvideoDetail(pvpItemIdx)
				local scene = ReplayPvpScene.new()
				scene:egReplace()
			elseif passedTime > numDef.clientTimeOut then
				obj:egUnbindWidgetUpdate(kPanelWait)
				imgWidget:stopAllActions()
				local function callback()
					--SocketHelper.disconnect()
					local scene = LogoScene.new()
					scene:egReplace()
				 end
				local msglayer = MsgLayer.new(nil,TxtList.dataUnMatch,1,callback)
				msglayer:show()
			end
	end
	obj:egBindWidgetUpdate(kPanelWait,callback)
end
--¼��طŵ���ص�����
function __postlayer.bindPvpItemClickEvent(obj,pvpItem)
	local function callback(sender)
		local vid = sender:getItemIdx()
		if videomanager.getvideo(vid) then
		    VideoDetail = videomanager.getvideoDetail(vid)
			local scene = ReplayPvpScene.new()
			scene:egReplace()
		else
			obj:activeDetailTimer(vid)
		end
	end
	pvpItem:onClicked(callback)
end
---------------
--��ʾ�������
-----------------
function __postlayer.showNote(obj)
	obj:setNoteClicked()
    --[[if not account_data.notice then account_data.notice = {} end
    if math.floor(#account_data.notice/3) == 0 then
		obj:egShowWidget(kLabelNoInfo)
		obj:egSetLabelStr(kLabelNoInfo,TxtList.noNote)
    else
        obj:addNoteItem(kMaxLoadNum)
    end--]]
    if account_data.msgBoxList == {} then
        obj:egShowWidget(kLabelNoInfo)
		obj:egSetLabelStr(kLabelNoInfo,TxtList.noNote)
    else
        obj:getMailOrder()
        obj:addMailItem(kMaxLoadNum)
    end
	obj:showNewMailFlag(false)
end
function __postlayer.hasUnReadMail(obj)
	 for msgid,item in pairs (account_data.msgBoxList) do
		if item[1] == 0 then return true end
	 end
	 return false
end
function __postlayer.showNewMailFlag(obj,show)
	local imgNew = obj:egGetWidgetByName(kImgNewMail)
	if show and obj:hasUnReadMail() then
		imgNew:setVisible(true)
		local scaleto1 = CCScaleTo:create(1,0.8)
		local scaleto2 = CCScaleTo:create(1,1)
		local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
		local repeatever = CCRepeatForever:create(sequence)
		imgNew:runAction(repeatever)
	else
		imgNew:setVisible(false)
		imgNew:stopAllActions()
	end
end
--�ʼ�����
function __postlayer.getMailOrder(obj)
    obj._mailOrder = {}
    for msgid,item in pairs (account_data.msgBoxList) do
        if item[1]~= 2 then
            table.insert(obj._mailOrder,{msgid,item[2]})
        end    
    end
    table.sort(obj._mailOrder,function(a,b) return a[2]>b[2] end)
end
--�����ʼ�
function __postlayer.addMailItem(obj,num)
    local totalCnt = #obj._mailOrder
    if obj._loadItem >= totalCnt then return end
    local left = totalCnt - obj._loadItem
    local startIdx = obj._loadItem + 1
    local endIdx = math.min(obj._loadItem + num,totalCnt)
    for idx = startIdx,endIdx,1 do
        local msgid = obj._mailOrder[idx][1]
        local mailItem = MailItem.new(msgid)
        obj:mailBack(mailItem)
        obj._itemlist:pushBackCustomItem(mailItem:egNode())
        obj._loadItem = obj._loadItem + 1 
    end
end
--�ʼ�����¼��ص�
function __postlayer.mailBack(obj,item)
    local function mailCallback(onload)
        SoundHelper.playEffect(SoundList.click_paper_open)
        local msgid = item:getprop("msgid")
        local mailinfo = MailInfo.new(msgid,onload)
        obj:mailInfoBack(mailinfo)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(mailinfo:egNode(),UILv.popLayer,UILv.popLayer)
    end
    item:onClicked(mailCallback)
end
--�ʼ��콱����¼��ص�
function __postlayer.mailInfoBack(obj,item)
    local function callback()
        obj:showNote()
    end
    item:onClicked(callback)
end
--[[function __postlayer.addNoteItem(obj,num)
	local totalCnt = math.floor(#account_data.notice/3)
	if obj._loadItem >= totalCnt then return end
	local left = totalCnt - obj._loadItem
	local endIdx =  math.max(left - num+1,1)
	local startIdx =left
	for idx = startIdx,endIdx,-1 do
		local noteItem =  NoteItem.new(noteidx)
		obj._itemlist:pushBackCustomItem(noteItem:egNode())
		obj._loadItem = obj._loadItem + 1
	end
end--]]
--����¼���¼Ϊ��ǰѡ����
function __postlayer.setHistoryClicked(obj)
	obj:clearItems()
	obj._showType = kShownHistory
	obj._btnNote:setFocused(false)
    obj._btnNote:setTouchEnabled(true)
	obj._btnHistory:setFocused(true)
    obj._btnHistory:setTouchEnabled(false)
    local parentNode = obj._btnHistory:getParent()
    parentNode:reorderChild(obj._btnHistory,kShowZorder)
    parentNode:reorderChild(obj._btnNote,kHideZorder)
end
--���ù���Ϊ��ǰѡ����
function __postlayer.setNoteClicked(obj)
	obj:clearItems()
	obj._showType = kShownNote
	obj._btnNote:setFocused(true)
    obj._btnNote:setTouchEnabled(false)
	obj._btnHistory:setFocused(false)
    obj._btnHistory:setTouchEnabled(true)
    local parentNode = obj._btnNote:getParent()
    parentNode:reorderChild(obj._btnNote,kShowZorder)
    parentNode:reorderChild(obj._btnHistory,kHideZorder)
end
--���б������¼�
function __postlayer.bindScrollListener(obj)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._itemlist:getInnerContainerSize().height
            if obj._oldH  < curH then
                if obj._showType == kShownHistory then
                    obj:addPvpItem(kMaxLoadNum)
                elseif obj._showType == kShownNote then 
                    --obj:addNoteItem(kMaxLoadNum)
                    obj:addMailItem(kMaxLoadNum)
                end
                 obj._oldH  = curH
			end
        end
    end
    obj._itemlist:addEventListenerScrollView(scrollEvent)
end
--¼���¼����¼�
function __postlayer.bindHistoryListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods)
       obj:showHistory()
    end
    obj:egBindTouch(kBtnHistory,nil,nil,touchEnded,nil)
end
--�����¼����¼�
function __postlayer.bindNoteListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods)
       obj:showNote()
    end
    obj:egBindTouch(kBtnNote,nil,nil,touchEnded,nil)
end
--�رյ���¼�
function __postlayer.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __postlayer.hideWithAction(obj)
    local function callback()
		AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __postlayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
function __postlayer.clearItems(obj)
    for idx = 1,obj._loadItem  do
       local item = obj._itemlist:getItem(idx-1)
        obj._itemlist:removeChildByTag(item:getTag(),true)
    end
    obj._oldH =0
	obj._itemlist:removeAllItems()
	obj._loadItem  = 0
	obj._itemlist:jumpToTop()
	obj:egHideWidget(kLabelNoInfo)
end
function __postlayer.activeWaitTimer(obj)
    obj:clearItems()
    obj:egShowWidget(kPanelWait)
	local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
	local passedTime = 0
    local function callback(delta)
		passedTime = passedTime + delta
        if not AccountHelper:isLocked(kStateVideoList) then
            obj:egHideWidget(kPanelWait)
            obj:egUnbindWidgetUpdate(kPanelWait)
            obj:showHistory()
		elseif passedTime > numDef.clientTimeOut then
			obj:egUnbindWidgetUpdate(kPanelWait)
			imgWidget:stopAllActions()
			local function callback()
				local scene = LogoScene.new()
				scene:egReplace()
			end
			local msglayer = MsgLayer.new(nil,TxtList.dataUnMatch,1,callback)
			msglayer:show()
        end
    end
    obj:egBindWidgetUpdate(kPanelWait,callback)
end

PostLayer={}
function PostLayer.new(onloaded)
    local obj =  TouchWidget.new(JsonList.postLayer)
    table_aux.unpackTo(__postlayer, obj)
    obj._onloaded  = onloaded
    obj:init()
    obj:bindNoteListener()
    obj:bindHistoryListener()
    obj:bindBackListener()
	obj:bindScrollListener()
    return obj
end

function showPost(onloaded)
    local layer = PostLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

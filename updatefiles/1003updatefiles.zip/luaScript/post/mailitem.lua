local kLabelTitle = "title_lbl"
local kLabelInfo = "info_lbl"
local kImgFlag = "flag_img"
local kBtnClick = "btn_item"
local kLblTime = "lbl_time"

local kGray = ccc3(180,180,180)

local __mailitem = {}
function __mailitem.init(obj,msgid)
    obj._msgid = msgid
    obj._msgdata = msgQuery.getName(msgid)
    local title = obj._msgdata.msgName
    local info = obj._msgdata.msgPerson
    obj:egChangeImg(kImgFlag,obj._msgdata.img_1,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLabelTitle,title)
    obj:egSetLabelStr(kLabelInfo,info)
    obj:egSetLabelStr(kLblTime,os.date("%Y-%m-%d %X",account_data.msgBoxList[msgid][2]))
    if account_data.msgBoxList[msgid][1]==1 then
       --obj:egSetWidgetColor(kBtnClick,kGray)
       --obj:egSetWidgetColor(kImgFlag,kGray)
       obj:egChangeImg(kImgFlag,obj._msgdata.img_2,UI_TEX_TYPE_PLIST)
    end
end
function __mailitem.bindClickListener(obj)
    local function touchEnded(sender)
       local function callback() obj:egSetWidgetTouchEnabled(kBtnClick,true) end
       obj:egSetWidgetTouchEnabled(kBtnClick,false)
       if obj._callback then obj._callback(callback) end
       
    end
    obj:egBindTouch(kBtnClick,nil,nil,touchEnded,nil)
end
function __mailitem.onClicked(obj,callback)
    obj._callback = callback
end
MailItem={}
function MailItem.new(msgid)
    local obj = {}
    CocosWidget.install(obj,JsonList.mailItem)
    table_aux.unpackTo(__mailitem,obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:setprop("msgid",msgid)
    obj:init(msgid)
    obj:bindClickListener()
    return obj
end
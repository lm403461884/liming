local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local __atkscene={}
function __atkscene.init(obj,areaid,stageid)
    SendMsg[934001]()
    obj._d_data = RiskHelper.getAtkSceneData(areaid,stageid)
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._atklayer = PvpLayer.new(obj._d_data,obj)
        obj._atklayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene(callback)
	obj._groundlayer:onHeroShown(callback)
    
end
function __atkscene.stopBattle(obj)
    SendMsg[934002](battleProgress)
   -- local function callback()
       -- if not AccountHelper:isLocked(kStateBpResult)  then
            obj._scoreLayer= BattleResultLayer.new(obj._d_data)
            obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
           -- obj:egUnBindSchedule()
      --  end
   -- end
   -- obj:egBindSchedule(callback)
    
end
AtkScene={}
function AtkScene.new(areaid,stageid)
    SoundHelper.playBGM(SoundList.atk_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__atkscene, obj)
    obj:init(areaid,stageid)
    showEmDialog(obj,GuideScene.def.kAtkScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
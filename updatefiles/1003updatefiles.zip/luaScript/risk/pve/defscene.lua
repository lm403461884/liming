local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local __defscene={}
function __defscene.init(obj,pidIdx)
    obj._d_data = RiskHelper.getDefSceneData(pidIdx)
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
    local function callback()
        obj._deflayer = DefLayer.new(obj._d_data,obj)
        obj._deflayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInDefScene(callback)
	obj._groundlayer:onHeroShown(callback)
end
function __defscene.stopBattle(obj)
    SendMsg[934011]( battleProgress.stars,obj._d_data.pidIdx)
    BPResult ={}
    BPResult.elo = 0
    BPResult.stars =  battleProgress.stars 
    local gainStar = numDef.starsPerStage - BPResult.stars
    account_data.pveGuardQuest.stars = account_data.pveGuardQuest.stars  + gainStar
    table.remove(account_data.pveGuardQuest.qid,obj._d_data.pidIdx)
	for key,val in pairs(obj._d_data.awardRes) do
		BPResult[key] = math.floor(val * gainStar /numDef.starsPerStage)
		account_data[key] = account_data[key] + BPResult[key]
	end
    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
end
DefScene={}
function DefScene.new(pidIdx)
    SoundHelper.playBGM(SoundList.def_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__defscene, obj)
    obj:init(pidIdx)
    --showEmDialog(obj,GuideScene.def.kAtkScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
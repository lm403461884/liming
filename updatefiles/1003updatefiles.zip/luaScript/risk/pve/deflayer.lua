--��������
local kBtnBack = "btn_giveup"
local kBtnZoomIn = "btn_zoomin"
local kBtnZoomOut = "btn_zoomout"
local kPanelLayer= "atk_panel"
local kPanelGo = "panel_go"
local kLblCount = "lbl_count"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnNo2 = "btn_no_2"
local kPanelConfirm = "giveup_panel"
local kImgBtnBg = "img_btn_bg"
local kLblNotice = "lbl_notice"
--������Ч���
local kPanelSkill = "skill_panel"
local kImgEffect = "img_effect"
local kImgHead = "img_head"
--��������
local kBarConsume = "bar_consume"
local kImgConsume = "img_bar_bg"
local kLabelLeftCost = "lbl_consume"
local kLabelPerCost = "lbl_cost_val"
local kLabelPerCosts = "lbl_cost_val_s"
--С��Ӣ��
local kListHero = "hero_list"
--��������Ϣ
local kPanelAtk = "atk_layer" 
local kLabelAtk = "lbl_atk" --����������
local kLabelAtk_s = "lbl_atk_s"--���������� ��Ӱ
local kAtkStars = {"star_atk_1","star_atk_2","star_atk_3"}
local kImgAtkBg = "atk_bg"
--���ط���Ϣ
local kPanelDef = "def_layer"
local kLabelDef = "lbl_def" --���ط�����
local kLabelDef_s = "lbl_def_s"--���������� ��Ӱ
local kDefStars = {"def_star_1","def_star_2","def_star_3"}
local kImgDefBg = "def_bg"
--������Ϣ
local kLblBox = {"lbl_gold_box_num","lbl_silver_box_num","lbl_copper_box_num"}
local kImgBox = {"img_box_gold","img_box_silver","img_box_copper"}
local kLblBoxs = {"lbl_gold_box_num_s","lbl_silver_box_num_s","lbl_copper_box_num_s"}
local kPanleBox = "box_list"

local kCounterNum0 = 20
local kCounterNum1 = 10
local kMaxDamage = 99999
local kCellW = 72
local kSpeed = 200

local __deflayer={}

function __deflayer.init(obj,d_data,owner)
     obj._owner = owner
     obj._d_data = d_data
     obj._startTime = os.clock()
     obj._battleStoped = false
     obj._usedConsume = 0 --�ܼ�������
     obj._enteredHeros = {} --�ѽ���ս����Ӣ��
     obj._unenteredHeros = {}--δ����ս����Ӣ��
     obj._skillQueen = {}
     --����ս��˫��������Ϣ
     obj:loadBaseInfo()
	   --����Ӣ��
     obj:loadHeroHeads()
	 obj:egHideWidget(kPanelGo) --�������治��ʾ
     obj:egHideWidget(kBtnZoomIn) --��Ҫ��ʾʱע��
     obj:egHideWidget(kBtnZoomOut)--��Ҫ��ʾʱע��
	 obj:egHideWidget(kPanleBox)--���ر���ģ��
	 
	 obj:egHideWidget(kPanelSkill)
     obj:showConfirmGiveUp(false) 
	 obj:egSetLabelStr(kLblNotice,TxtList.defGiveUpNote) --������ʾ��Ϣ

end
function __deflayer.loadBaseInfo(obj)
 --����������Ϣ
    obj:egSetBarPercent(kBarConsume,100)
    obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume)
    obj:egSetLabelStr(kLabelPerCost,"0/s")
    obj:egSetLabelStr(kLabelPerCosts,"0/s")
     --���ؽ���������
    obj:egSetLabelStr(kLabelAtk,obj._d_data.atkName)
    obj:egSetLabelStr(kLabelAtk_s,obj._d_data.atkName)

     --���ط��ط�����
     obj:egSetLabelStr(kLabelDef,obj._d_data.dfsName)
     obj:egSetLabelStr(kLabelDef_s,obj._d_data.dfsName)
	 
	 --��������ʼ��Ϊ���ط�
	obj:egChangeImg(kImgAtkBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST) 
	obj:egChangeImg(kImgDefBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
     obj:egSetImgFlipX(kImgDefBg,true)
end
--����Ӣ��
function __deflayer.loadHeroHeads(obj)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    for key,heroObj in ipairs(creaturelayer._heros) do
		local heroid = heroObj:getprop("type")
		local heroprop = RiskHelper.getHeroData(heroid,obj._d_data.heroList)
		heroObj:addprop("enterTime",heroprop.enterTime)
		heroObj:addprop("survialTime",0)
		table.insert( obj._unenteredHeros,heroObj)
    end
end
--�볡����ʱ
function __deflayer.activeEnterCounter(obj)
    local passed = 0
    local function callback(delta)
        passed = passed + delta
		local leftCnt =  #obj._unenteredHeros
		if  leftCnt<= 0  then
			--����Ӣ�۶��Ѿ��볡
			obj:egUnbindWidgetUpdate(kLblCount)
		else
			for idx = leftCnt,1,-1 do
				local heroObj = obj._unenteredHeros[idx]
				if heroObj then
					local enterTime = heroObj:getprop("enterTime")
					if passed*1000 >= enterTime then
						table.insert( obj._enteredHeros,heroObj)
						table.remove(obj._unenteredHeros,idx)
						--�Զ��ַ�Ӣ�� �볡
						obj:enterBattle(heroObj)
					end
				end
			end
		end
    end
    obj:egBindWidgetUpdate(kLblCount,callback)
end
--����ս��
function __deflayer.enterBattle(obj,heroObj)
    SoundHelper.playEffect(SoundList.hero_go)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local x,y = creaturelayer:getPosByIdx(heroObj:getprop("birthPlace"))
    local function callback2()
        if heroObj:egNode() then heroObj:openAi() end
    end
    local function callback1()
        if heroObj:egNode() then heroObj:moveToPos(180,x,y,0.5,callback2) end
    end
    local sec = (x - heroObj:egGetPosX())/kSpeed
    heroObj:moveToPos(90,x,heroObj:egGetPosY(),sec,callback1)

end
--Ӣ��ʹ�ü���ǰ�Ļص�����
function __deflayer.doUseHeroSkill(obj,heroObj)
	local heroid = heroObj:getprop("type")
    table.insert(obj._skillQueen,heroObj)
    local holelayer = AccountHelper:get(kHoleLayer)
	local creaturelayer = holelayer._creaturelayer
	creaturelayer:focusHero(heroObj,true)

    local herox = heroObj:egGetPosX()
    local heroy = heroObj:egGetPosY()
    local poscenter = creaturelayer:egPosInNode(640,360)
    local x =poscenter.x -  herox
    local y = poscenter.y - heroy
    if x ~=0 or y ~= 0 then
        holelayer:moveInnerBy(0.1,x,y)
    end
    obj:egShowWidget(kPanelSkill)
    obj:egChangeImg(kImgHead,hero_data.getConfig(heroid).skillHeadPic,UI_TEX_TYPE_PLIST)
    local img = obj:egGetWidgetByName(kImgEffect)
    img:setScaleX(0)
    img:stopAllActions()
    local scaleto = CCScaleTo:create(0.5,1)
    local expOut = CCEaseExponentialOut:create(scaleto)
    local function callback()
		obj:egHideWidget(kPanelSkill)
		for idx = #obj._skillQueen,1,-1 do
			local skillHero = obj._skillQueen[idx]
			skillHero:useActiveSkill()
			skillHero:setprop("powerBar",0)
			creaturelayer:focusHero(skillHero,false)
			table.remove(obj._skillQueen,idx)
		end
    end
    local callfunc = CCCallFunc:create(callback)
    local delaytime = CCDelayTime:create(0.5)
    local array = CCArray:create()
    array:addObject(expOut)
    array:addObject(delaytime)
    array:addObject(callfunc)
    local sequence = CCSequence:create(array)
    img:runAction(sequence)   
end
--��ʾ�Ǽ����
function __deflayer.showStarChange(obj,stars)
    if stars ~= battleProgress.stars  then 
        for idx = battleProgress.stars + 1,stars do
            local star1 = obj:egGetWidgetByName(kDefStars[idx])
            local star2 = obj:egGetWidgetByName(kAtkStars[idx])
            local blink1 = CCBlink:create(0.5,5)
            local blink2 = CCBlink:create(0.5,5)
            local function callbackfunc1()
                obj:egHideWidget(kDefStars[idx])
            end
            local function callbackfunc2()
                obj:egShowWidget(kAtkStars[idx])
            end
            local action_callback1 = CCCallFuncN:create(callbackfunc1)
            local action_callback2 = CCCallFuncN:create(callbackfunc2)
            local sequence1 = CCSequence:createWithTwoActions(blink1,action_callback1)
            local sequence2 = CCSequence:createWithTwoActions(blink2,action_callback2)
            star1:runAction(sequence1)
            star2:runAction(sequence2)
        end
         battleProgress.stars  = stars
    end
end

--��ȡ�����ѽ���ӵ���Ӣ�۵�����ֵ�ܺ�
function __deflayer.getTotalConsume(obj)
    local val = 0
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local survialTime = heroObj:getprop("survialTime")
		local consume = heroObj:getprop("consume")
        val = val +survialTime*consume
    end
    val = math.floor(val)
    if val > obj._d_data.consume then val = obj._d_data.consume end
    return val
end
--��ȡ�ܼ�ÿ������
function __deflayer.getPerConsume(obj)
    local val = 0
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local hp = heroObj:getprop("hp")
		if hp > 0 then
			val = val +heroObj:getprop("consume")
		end
    end
    val = math.floor(val)
    return val
end

--�ж����Ƿ�������
function __deflayer.isTimeOut(obj)
   local perConsume = obj:getPerConsume()
   obj:egSetLabelStr(kLabelPerCost,string.format("%d%s",perConsume,"/s"))
   obj:egSetLabelStr(kLabelPerCosts,string.format("%d%s",perConsume,"/s"))
   local usedConsume = obj:getTotalConsume()
   if usedConsume == obj._d_data.consume then
       obj:egUnbindWidgetUpdate(kLblCount)
       for idx,heroObj in ipairs(obj._unenteredHeros) do
            table.insert(obj._enteredHeros,heroObj)
       end
       obj._unenteredHeros={}
       for idx,heroObj in ipairs(obj._enteredHeros) do
            heroObj:setprop("hp",0)
            heroObj:setprop("powerbar",0)
       end
       
       return true
   else
       if obj._usedConsume ~= usedConsume then
            obj._usedConsume = usedConsume
            local percent =100- usedConsume*100/obj._d_data.consume
            obj:egSetBarPercent(kBarConsume,percent)
            obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume - obj._usedConsume)
       end
       return false
   end
end
--�ж���Դ���Ƿ����
function __deflayer.isResCarClear(obj)
	local collectorCount = #obj._d_data.collectorList
	local leftResCar = collectorCount - #battleProgress.collector
	local stars = math.floor(leftResCar / collectorCount * numDef.starsPerStage)
	if leftResCar > 0 and stars == 0 then
		stars = 1
	end
    obj:showStarChange(numDef.starsPerStage - stars)
    return leftResCar == 0 
end

--�ж�Ӣ���Ƿ�����
function __deflayer.isHeroClear(obj)
    if #obj._unenteredHeros > 0 then return false end
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local hp = heroObj:getprop("hp")
		if hp > 0 then
			return false
		end
    end
	return true
end

--����ս��
function __deflayer.stopBattle(obj)
    ai_module.clear()
    obj._battleStoped = true
    obj:egUnbindWidgetUpdate(kLblCount)
    obj:egSetWidgetTouchEnabled(kBtnBack,false)
    obj:showConfirmGiveUp(false)
    obj:egUnbindWidgetUpdate(kPanelLayer)
    if battleProgress.stars > 0 then
	   SoundHelper.playBGMOnce(SoundList.battleLose)
    else
	   SoundHelper.playBGMOnce(SoundList.battleWin)
    end
    
    obj._d_data.oldheroList = obj:copyHeroData()--���ƽ�ս��ǰӢ������
    obj._owner:stopBattle() --�ص�����������stopBattle����
    obj:egHideWidget(kBtnBack)
    obj:egHideWidget(kBtnZoomOut)
    obj:egHideWidget(kBtnZoomIn)
end
function __deflayer.copyHeroData(obj)
   local herolist ={}
   for idx,heroObj in ipairs(obj._unenteredHeros) do
       table.insert(obj._enteredHeros,heroObj)
   end
    for idx,heroObj in ipairs(obj._enteredHeros) do
		local tb = {}
		tb.type = heroObj:getprop("type")
		tb.lv = heroObj:getprop("level")
		tb.curhp =  heroObj:getprop("hp")
		tb.hp =  heroObj:getprop("maxHP")
		table.insert(herolist,tb)
    end
    
    return herolist
end
--���ط�����ť
function __deflayer.hideGiveUp(obj,hide)
    if hide then
        obj:egHideWidget(kBtnBack)
		obj:egHideWidget(kImgBtnBg)
    else
        obj:egShowWidget(kBtnBack)
		obj:egShowWidget(kImgBtnBg)
    end
end
--��ʾ�������
function __deflayer.showConfirmGiveUp(obj,show)
    if show then
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        --obj:egShowWidget(kBtnNo2)
        obj:egShowWidget(kPanelConfirm)
    else
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
       -- obj:egHideWidget(kBtnNo2)
        obj:egHideWidget(kPanelConfirm)
    end
end
function __deflayer.refreshSurvivalTime(obj,delta)
	for idx,heroObj in ipairs(obj._enteredHeros) do
		local hp =  heroObj:getprop("hp")
		if hp > 0 then
			local survialTime = heroObj:getprop("survialTime")
			 heroObj:setprop("survialTime",survialTime + delta)
		end
    end
end
function __deflayer.bindPanelUpdate(obj)
    local  function callback(delta)
		  obj:refreshSurvivalTime(delta)
          if obj:isTimeOut() then 
                obj:stopBattle()
          elseif obj:isResCarClear() then
                obj:stopBattle()
          elseif obj:isHeroClear() then
                obj:stopBattle()
          end
    end
    obj:egBindWidgetUpdate(kPanelLayer,callback)
end
--����
function __deflayer.bindBackListener(obj)
     local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:showConfirmGiveUp(true)
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
--ȷ�Ϸ���
function __deflayer.bindYesListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
        if not obj._battleStoped  then
            battleProgress.stars = pveGuardQuest.pveGuardSkip(obj._d_data.stageid,account_data)
            obj:stopBattle()
        end
    end
     obj:egBindTouch(kBtnYes,nil,nil,touchEnded,nil)
end
--ȡ������
function __deflayer.bindNoListener(obj)
    local function touchEnded(sender)
        obj:showConfirmGiveUp(false)
		SoundHelper.playEffect(SoundList.click_back_button)
        obj:egSetWidgetTouchEnabled(kBtnBack,true)
    end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,nil)
end

function __deflayer.activeUpdate(obj)
    local function update()
		if #obj._skillQueen== 0 then
			ai_module.update()
		end
		--[[
		local function isusing(target)
		    for key,item in ipairs(obj._skillQueen) do
		        if item == target then return true end
		    end
		    return false
        end 
		local cnt = #obj._enteredHeros
		if cnt > 0 then
		   for key,heroObj in ipairs(obj._enteredHeros) do
		        local power = heroObj:getprop("powerBar")
		        local maxpower = heroObj:getprop("maxPower")
		        if power >= maxpower and not isusing(heroObj) then
		            useHeroSkill(heroObj)
		        end
		   end
        end
        --]]
    end
	local function clear()
		ai_module.clear()
	end
     obj:egBindUpdate(update,clear)
end
DefLayer={}
function DefLayer.new(d_data,owner)
    local obj = TouchWidget.new(JsonList.atkLayer)
    table_aux.unpackTo(__deflayer, obj)
    obj:init(d_data,owner)
    obj:bindBackListener()
    obj:bindYesListener()
    obj:bindNoListener()
	obj:bindPanelUpdate() 
	obj:activeEnterCounter()
	obj:activeUpdate()
	 AccountHelper:bind(kDefLayer,obj)
    return obj
end

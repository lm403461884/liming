--��������
local kBtnBack = "btn_giveup"
local kPanelLayer= "video_panel"
local kPanelGo = "panel_go"
local kLblCount = "lbl_count_txt"
--��������
local kBarConsume = "bar_consume"
local kImgConsume = "img_bar_bg"
local kLabelLeftCost = "lbl_consume"
local kLabelPerCost = "lbl_cost_val"
local kLabelPerCosts = "lbl_cost_val_s"
--������Ч���
local kPanelSkill = "skill_panel"
local kImgEffect = "img_effect"
local kImgHead = "img_head"
--С��Ӣ��
local kListHero = "hero_list"

--��������Ϣ
local kPanelAtk = "atk_layer" 
local kLabelAtk = "lbl_atk" --����������
local kLabelAtk_s = "lbl_atk_s"--���������� ��Ӱ
local kAtkStars = {"star_atk_1","star_atk_2","star_atk_3"}
local kImgAtkBg = "atk_bg"
--���ط���Ϣ
local kPanelDef = "def_layer"
local kLabelDef = "lbl_def" --���ط�����
local kLabelDef_s = "lbl_def_s"--���������� ��Ӱ
local kDefStars = {"def_star_1","def_star_2","def_star_3"}
local kImgDefBg = "def_bg"

local kParticleSrc = "particle/battle/ExplodingRing.plist.png"
local kParticleReady = "particle/battle/skill_ready.plist"
local kParticleFire = "particle/battle/skill_fire.plist"

local kMaxDamage = 99999
local kHeroW = 156
local kParticleCap = 240
local __videolayer={}

function __videolayer.init(obj,d_data,owner)
     obj._owner = owner
     obj._d_data = d_data
     --print("d_data:",table_aux.serial(d_data))
     obj._frameID = 0 --֡ID
     obj._battleStoped = false
     obj._usedConsume = 0 --�ܼ�������
     obj._enteredHeros = {} --�ѽ���ս����Ӣ��
     obj._unenteredHeros = {}--δ����ս����Ӣ��
     obj._heroHeads = {}
     obj._skillQueen={}
     --����ս��˫��������Ϣ
     obj:loadBaseInfo()
     --����Ӣ��
     obj:loadHeroHeads()
     obj:egHideWidget(kPanelSkill)
     obj:showPanelGo(true)
end
--ս��������Ϣ����
function __videolayer.loadBaseInfo(obj)
 --����������Ϣ
    obj:egSetBarPercent(kBarConsume,100)
    obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume)
    obj:egSetLabelStr(kLabelPerCost,"0/s")
    obj:egSetLabelStr(kLabelPerCosts,"0/s")
     --���ؽ���������
    obj:egSetLabelStr(kLabelAtk,obj._d_data.atkName)
    obj:egSetLabelStr(kLabelAtk_s,obj._d_data.atkName)

	
     --���ط��ط�����
     obj:egSetLabelStr(kLabelDef,obj._d_data.dfsName)
     obj:egSetLabelStr(kLabelDef_s,obj._d_data.dfsName)

	 
	 if obj._d_data.atk == account_data.guid then
		obj:egChangeImg(kImgAtkBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST) 
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST)
	 else
		obj:egChangeImg(kImgAtkBg,ImageList.risk_name_red,UI_TEX_TYPE_PLIST) 
		obj:egChangeImg(kImgDefBg,ImageList.risk_name_green,UI_TEX_TYPE_PLIST)
	 end
     obj:egSetImgFlipX(kImgDefBg,true)
end
function __videolayer.showPanelGo(obj,show)
    local lblWidget = obj:egGetWidgetByName(kLblCount)
    if show then
        obj:egShowWidget(kPanelGo)
        local blink = CCBlink:create(1,2)
        local repeatforever1 = CCRepeatForever:create(blink)
        lblWidget:runAction(repeatforever1)
    else
        obj:egHideWidget(kPanelGo)
        lblWidget:stopAllActions()
    end
end
--����Ӣ��ͷ��
function __videolayer.loadHeroHeads(obj)
    local teamCnt = #obj._d_data.teamList
    local heroPanel = obj:egGetWidgetByName(kListHero)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    for key,heroObj in ipairs(creaturelayer._heros) do
        local heroHead = BattleHero.new(heroObj)
        heroHead:disableTouch()
        heroPanel:addChild(heroHead:egNode())
        table.insert(obj._unenteredHeros,heroHead)
        obj._heroHeads[heroObj:getprop('type')] = heroHead 
        obj:bindHeroEntering(heroHead)
        obj:bindHeroDied(heroHead)
        obj:bindHeroSkillReady(heroHead)
        obj:bindHeroUsingSkill(heroHead)
    end
    local size = heroPanel:getSize()
    local oldW = size.width
    local newW = kHeroW*teamCnt
    heroPanel:setSize(CCSizeMake(newW,size.height))
    heroPanel:setPosition(ccp((oldW-newW)/2,0))
end
--Ӣ��׼���볡�ص�����
function __videolayer.bindHeroEntering(obj,heroHead)
    local function callback(sender)
        --��Ӣ�������ѽ���ս���б�
        for key ,item in ipairs(obj._unenteredHeros) do
            if item == sender then
                if #obj._unenteredHeros == #obj._d_data.teamList then 
                     obj:showPanelGo(false)
                end
                table.remove(obj._unenteredHeros,key)
            end
        end
        table.insert(obj._enteredHeros,sender)
    end
    heroHead:onHeroEntering(callback)  
end
--Ӣ�������ص�����
function __videolayer.bindHeroDied(obj,heroHead)
    local function callback(sender)
        for key,item in ipairs(obj._enteredHeros) do
            if item == sender then
                table.remove(obj._enteredHeros,key)
                break
            end
        end
    end
    heroHead:onHeroDied(callback)
end
--Ӣ�ۼ���׼����ɻص�����
function __videolayer.bindHeroSkillReady(obj,heroHead)
    local function callback(sender)
        local particle = CCParticleSystemQuad:create(kParticleReady)
		--local heroid = sender:getHeroID()
		--if obj._particlelayer:getChildByTag(heroid) then
		--	obj._particlelayer:removeChildByTag(heroid,true)
		--end
        --obj._particlelayer:addChild(particle,0,heroid)
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
    end
    heroHead:onSkillReady(callback)
end
--Ӣ��ʹ�ü���ǰ�Ļص�����
function __videolayer.bindHeroUsingSkill(obj,heroHead)
    local function callback(sender)
        table.insert(obj._skillQueen,sender)
        local particle = CCParticleSystemQuad:create(kParticleFire)
		--local heroid = sender:getHeroID()
		--if obj._particlelayer:getChildByTag(heroid) then
		--	obj._particlelayer:removeChildByTag(heroid,true)
		--end
        --obj._particlelayer:addChild(particle,0,heroid)
		obj._particlelayer:addChild(particle,0)
        local objX = sender:egNode():getPositionX()
        local offsetx = sender:egNode():getSize().width/2
        local panelX = obj:egGetWidgetByName(kListHero):getPositionX()
        particle:setPosition(ccp(objX+panelX+offsetx,78))
        
        obj:egShowWidget(kPanelSkill)
        obj:egChangeImg(kImgHead,hero_data.getConfig(sender:getHeroID()).skillHeadPic,UI_TEX_TYPE_PLIST)
        local img = obj:egGetWidgetByName(kImgEffect)
        img:setScaleX(0)
        img:stopAllActions()
        local scaleto = CCScaleTo:create(0.5,1)
        local expOut = CCEaseExponentialOut:create(scaleto)
        local function callback()
            obj:egHideWidget(kPanelSkill)
            for idx = #obj._skillQueen,1,-1 do
                obj._skillQueen[idx]:afterUseSkill()
                table.remove(obj._skillQueen,idx)
            end
        end
        local callfunc = CCCallFunc:create(callback)
        local delaytime = CCDelayTime:create(0.5)
        local array = CCArray:create()
        array:addObject(expOut)
        array:addObject(delaytime)
        array:addObject(callfunc)
        local sequence = CCSequence:create(array)
        img:runAction(sequence)
        
    end
    heroHead:onUsingSkill(callback)
end
--��ʾ�Ǽ����
function __videolayer.refreshStarChange(obj)
    local collectorCount = #obj._d_data.collectorList
	local leftResCar = collectorCount - #battleProgress.collector
	local stars = math.floor(leftResCar / collectorCount * numDef.starsPerStage)
	if leftResCar > 0 and stars == 0 then
		stars = 1
	end
	stars = numDef.starsPerStage - stars
    if stars ~= battleProgress.stars  then 
        for idx = battleProgress.stars + 1,stars do
            local star1 = obj:egGetWidgetByName(kDefStars[idx])
            local star2 = obj:egGetWidgetByName(kAtkStars[idx])
            local blink1 = CCBlink:create(0.5,5)
            local blink2 = CCBlink:create(0.5,5)
            local function callbackfunc1()
                --obj:egChangeImg(kDefStars[idx],ImageList.lvup_starnull,UI_TEX_TYPE_PLIST)
                obj:egHideWidget(kDefStars[idx])
            end
            local function callbackfunc2()
                --obj:egChangeImg(kAtkStars[idx],ImageList.lvup_star,UI_TEX_TYPE_PLIST)
                obj:egShowWidget(kAtkStars[idx])
            end
            local action_callback1 = CCCallFuncN:create(callbackfunc1)
            local action_callback2 = CCCallFuncN:create(callbackfunc2)
            local sequence1 = CCSequence:createWithTwoActions(blink1,action_callback1)
            local sequence2 = CCSequence:createWithTwoActions(blink2,action_callback2)
            star1:runAction(sequence1)
            star2:runAction(sequence2)
        end
         battleProgress.stars  = stars
    end
end

--��ȡ�����ѽ���ӵ���Ӣ�۵�����ֵ�ܺ�
function __videolayer.getTotalConsume(obj)
    local val = 0
    for idx,hero in pairs(obj._heroHeads) do
        val = val + hero:getTotalConsume()
    end
    if val > obj._d_data.consume then val = obj._d_data.consume end
    return val
end
--��ȡ�ܼ�ÿ������
function __videolayer.getPerConsume(obj)
    local val = 0
    for idx,hero in ipairs(obj._enteredHeros) do
        val = val + hero:getConsume()
    end
    return val
end
--�ж����Ƿ�������
function __videolayer.refreshConsume(obj)
   local perConsume = obj:getPerConsume()
   obj:egSetLabelStr(kLabelPerCost,string.format("%d%s",perConsume,"/s"))
   obj:egSetLabelStr(kLabelPerCosts,string.format("%d%s",perConsume,"/s"))
   local usedConsume = obj:getTotalConsume()
   if usedConsume < obj._d_data.consume then
       if obj._usedConsume ~= usedConsume then
            obj._usedConsume = usedConsume
            local percent =100- usedConsume*100/obj._d_data.consume
            obj:egSetBarPercent(kBarConsume,percent)
            obj:egSetBMLabelStr(kLabelLeftCost,obj._d_data.consume - obj._usedConsume)
       end
   end
end
--���������������£�����Ӣ����������
function __videolayer.killAllHeros(obj)
    for _,heroid in ipairs(obj._d_data.teamList) do
        obj._heroHeads[heroid]:killHero()
    end
    obj._enteredHeros={}
    obj._unenteredHeros={}
end

--����ս��
function __videolayer.stopBattle(obj)
    ai_module.clear()
    obj._battleStoped = true
    obj:egSetWidgetTouchEnabled(kBtnBack,false)
    battleProgress.endTime = os.time()
    battleProgress.frameCnt = obj._frameID
    battleProgress.stars = obj._d_data.stars
    obj:egUnbindWidgetUpdate(kPanelLayer)
    if obj._d_data.type==1 then --����¼��
        if battleProgress.stars > 0 then
           SoundHelper.playBGMOnce(SoundList.battleLose)
        else
           SoundHelper.playBGMOnce(SoundList.battleWin)
        end
    else
	    if battleProgress.stars > 0 then
           SoundHelper.playBGMOnce(SoundList.battleWin)
        else
           SoundHelper.playBGMOnce(SoundList.battleLose)
        end
	end    
    obj._d_data.oldheroList = obj:copyHeroData()
    obj._owner:stopBattle() --�ص�����������stopBattle����
    obj:egHideWidget(kBtnBack)
end
function __videolayer.copyHeroData(obj)
   local herolist ={}
    for idx,item in ipairs(obj._d_data.heroList) do
         
         local heroHead = obj._heroHeads[item.type]
         if heroHead then --�ų�heroList��û����Team��Ӣ��
            local tb =Funs.copy(item)
             tb.curhp = heroHead:getHP()
             table.insert(herolist,tb)
         end
    end
    return herolist
end
--����Ӣ���Զ��볡
function __videolayer.recSendHero(obj)

        if #obj._d_data.heroEnterFrame > 0 then
            local heroid = obj._d_data.heroEnterFrame[1]
            local heroFrame = obj._d_data.heroEnterFrame[2]
            if heroFrame<=obj._frameID then
                obj._heroHeads[heroid]:enterBattle()
                table.remove(obj._d_data.heroEnterFrame,2)
                table.remove(obj._d_data.heroEnterFrame,1)
            end
        end
end
--���ÿ���Ӣ��AI
function __videolayer.recActiveHeroAI(obj)
    if #obj._d_data.heroCreatedFrame > 0 then
        local heroid = obj._d_data.heroCreatedFrame[1]
        local createFrame = obj._d_data.heroCreatedFrame[2]
        if createFrame<=obj._frameID then
                    obj._heroHeads[heroid]:activeAI()
                    table.remove(obj._d_data.heroCreatedFrame,2)
                    table.remove(obj._d_data.heroCreatedFrame,1)
        end
    end
end
--ʹ�ü���
function __videolayer.recUseSkill(obj)
     for heroid,useFrameList in pairs(obj._d_data.skillFrame) do
        if #useFrameList > 0 then
            local userFrame = useFrameList[1]
            if userFrame<=obj._frameID then
                obj._heroHeads[heroid]:doUseSkill()
                table.remove(useFrameList,1)
            end
        else
            obj._d_data.skillFrame[heroid] = nil
        end
    end
end
function __videolayer.bindPanelUpdate(obj)
    local  function callback()
        obj._frameID = obj._frameID + 1
        obj:recSendHero()--����Ӣ���Զ��볡
        obj:recActiveHeroAI()--���ÿ���Ӣ��AI
        obj:recUseSkill()--����ʹ�ü���
        obj:refreshConsume() --��������ֵ
        obj:refreshStarChange()
        if obj._frameID >= obj._d_data.frameCnt then
            obj:stopBattle()
        end
    end
    obj:egBindWidgetUpdate(kPanelLayer,callback)
end
--����
function __videolayer.bindBackListener(obj)
     local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        local scene = TownScene.new()
        scene:egReplace()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __videolayer.activeUpdate(obj)
    local function update()
        if #obj._skillQueen== 0 then
		    ai_module.update()
		end
    end
	local function clear()
		ai_module.clear()
	end
     obj:egBindUpdate(update,clear)
end
VideoLayer={}
function VideoLayer.new(d_data,owner)
    local obj = TouchWidget.new(JsonList.videoLayer)
    obj._particlelayer =  CCParticleBatchNode:create(kParticleSrc,kParticleCap)
	obj:egAddChild(obj._particlelayer,1,1)
    table_aux.unpackTo(__videolayer, obj)
    obj:init(d_data,owner)
    obj:bindBackListener()
    obj:bindPanelUpdate() 
	obj:activeUpdate()
    return obj
end

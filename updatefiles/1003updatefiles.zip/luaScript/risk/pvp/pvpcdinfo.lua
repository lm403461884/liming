local kPanelLayer = "info_panel"
local kLblNotice = "lbl_info_2"
local kBtnBack = "btn_back"
local kPanelPrompt="prompt_layer"
local kBtnPvp = "btn_pvp"
local __promptlayer={}
function __promptlayer.init(obj)
	obj:showWithAction()
end

function __promptlayer.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __promptlayer.bindPvpListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        obj:egRemoveSelf()
       -- AccountHelper:lock(kStatePrompt)
        showPreparePvp()
    end
    obj:egBindTouch(kBtnPvp,nil,nil,touchEnded,nil)
end
function __promptlayer.hideWithAction(obj,callbackfunc)
    local function callback()
            --AccountHelper:unlock(kStatePrompt)
            obj:egRemoveSelf()
            if callbackfunc then callbackfunc() end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __promptlayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,360))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end

PvpCDInfo={}
function PvpCDInfo.new(onloaded)
    local obj =  TouchWidget.new(JsonList.pvpPrompt)
    table_aux.unpackTo(__promptlayer, obj)
    obj._onloaded = onloaded
    obj:init()
    obj:bindBackListener()
    obj:bindPvpListener()
    return obj
end

function showPvpCDInfo(onloaded)
    local layer = PvpCDInfo.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
local kImgIcon = "icon"
local kLabelBlack = "lbl_black"
local kLabelYellow = "lbl_yellow"
local kRedColor = ccc3(255,0,0)
local koffsetX = 5
local __digprompt = {}
--KVariantList.coinType
function __digprompt.init(obj,promptype,num)
	local coinName = KVariantList.coinType[promptype]
    obj:egChangeImg(kImgIcon,ImageList[string.format("comm_%s",coinName)],UI_TEX_TYPE_PLIST)
    if num > 0 then num = string.format("%s%d","+",num) end
    local lblname = kLabelYellow
    if promptype == KVariantList.coinGold then --金
        obj:egHideWidget(kLabelBlack)
        obj:egSetBMLabelStr(kLabelYellow,num)
        lblname = kLabelYellow
    elseif promptype == KVariantList.coinDig then --挖掘值
        obj:egHideWidget(kLabelYellow)
        obj:egSetBMLabelStr(kLabelBlack,num)
        obj:egSetWidgetColor(kLabelBlack,kRedColor)
        lblname = kLabelBlack
	else --其它
		obj:egHideWidget(kLabelYellow)
        obj:egSetBMLabelStr(kLabelBlack,num)
        lblname = kLabelBlack
    end
    local img = obj:egGetWidgetByName(kImgIcon)
    local lbl = obj:egGetWidgetByName(lblname)
    local w = img:getSize().width * img:getScale() + lbl:getSize().width* lbl:getScale() + koffsetX
    local size = obj:egNode():getSize()
    obj:egNode():setSize(CCSizeMake(w,size.height))
end
DigPrompt={}
function DigPrompt.new(promptype,num)
    local obj = {}
    CocosWidget.install(obj,JsonList.digPrompt)
    table_aux.unpackTo(__digprompt, obj)
    obj:init(promptype,num)
    return obj
end

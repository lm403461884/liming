RiskHelper={}
--------------------------
--�ھ򳡾�����
--------------------------
function RiskHelper.getDigSceneData()
    enableExpandAI = false
    local tb = {}
    local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
	tb.showFlag = true
    tb.w = s_data.w
    tb.h = s_data.h
    tb.maxDigPt = account_data.maxDigPt
    tb.digVision = account_data.digVision --�ھ���Ұ
    tb.dfs = account_data.guid
	tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLv = account_data.sceneLv
    tb.digTrace = account_data.digTrace
    tb.mileSpread = account_data.mileSpread --�����ֲ�
    tb.collectorList = account_data.collectorList --�󳵷ֲ�
    tb.spread = s_data.spread
    tb.entraIdx = s_data.w/2
    if not tb.digTrace[tb.entraIdx] then
       tb.digTrace[tb.entraIdx] = 1
    end
    tb.creatureList = account_data.creatureList
    tb.monsterLvLook = account_data.monsterLvLook
    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/iceberg_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png" 
    tb.earthImg = EarthImages[tb.sceneID]
    tb.mineOutRange = RiskHelper.getMineOutOfDigTrance(tb) --��ȡ�ھ����������ʾ�Ŀ�
    return tb
end

--------------------------
--��ȡ������������
--------------------------
function RiskHelper.getAtkSceneData(areaid,stageid)
    enableExpandAI = true
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    local stagedata = pveQuery.queryStage(areaid,stageid)
    local tb = {}
    tb.type = 0
	tb.btFlag = 0
    tb.digVision = account_data.digVision
	tb.digLv = account_data.digLv
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
    tb.dfs = 0
    tb.dfsName = TxtList.pveDefName
    tb.areaid = areaid
    tb.stageid = stageid
    tb.sceneID = areaid
    tb.sceneLv = stageid
	tb.battleBox = {[1]={},[2]={},[3]={}}
	tb.battleBoxCnt = 0
    RiskHelper.initBP(tb.type,tb.btFlag,tb.areaid,tb.stageid,tb.dfsName) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ������ߣ��ڽ��յ�ս���ط����ݺ�ָ� 394001
    tb.w = stagedata.w
    tb.h = stagedata.h
    tb.digTrace = Funs.copy(stagedata.digTrace)
    tb.mileSpread = {}
	tb.boxList = stagedata.boxList
    tb.collectorList = stagedata.collectorList --�󳵷ֲ�
    tb.spread = stagedata.spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(stagedata.creatureList)
	--�ճ����������ִ�յȼ���������ȼ�
	if MissionHelper.groupIdx then
		tb.monsterLvLook =  baseCalc.getMonsterLv(tb.digLv, stagedata.monsterLvLook)
	else --��ͨ����ֱ�Ӷ�����
		tb.monsterLvLook = Funs.copy(stagedata.monsterLvLook)
	end
    tb.heroList = account_data.heroList
	for idx,hero in pairs(account_data.heroList) do
        hero.hp = hero_data.getData(hero.type, hero.lv, "maxHP")
    end
    tb.teamList = account_data.team 
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag
    tb.consume = account_data.consume 
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png" 
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ����ս������
--------------------------
function RiskHelper.getDefSceneData(pidIdx)
    enableExpandAI = true
    --��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
	local tb = {}
	tb.stageid = account_data.pveGuardQuest.qid[pidIdx]
	tb.pidIdx = pidIdx
	
    local stagedata = pveGuardQuery.getName(tb.stageid)
	local s_data = scene_data.get(account_data.sceneID, account_data.sceneLv)
	tb.awardRes=RiskHelper.getDefAwardRes(tb.stageid)
    tb.type = 1
    tb.btFlag = 3
    tb.digVision = account_data.digVision
    tb.atk = 0
    tb.digLv = account_data.digLv
    tb.atkName = TxtList.pveAtkName
    tb.dfs = account_data.guid
    tb.dfsName = account_data.nickName
    tb.sceneID = account_data.sceneID
    tb.sceneLV = account_data.sceneLV
	
	RiskHelper.initBP(tb.type,tb.btFlag, tb.sceneID,tb.stageid,tb.dfsName)
	
    tb.w = s_data.w
    tb.h = s_data.h
	tb.entraIdx =  s_data.w/2
    tb.digTrace = Funs.copy(account_data.digTrace)
    tb.mileSpread = Funs.copy(account_data.mileSpread)
    tb.collectorList =  Funs.copy(account_data.collectorList)
	tb.creatureList = Funs.copy(account_data.creatureList)
    tb.monsterLvLook = Funs.copy(account_data.monsterLvLook)
    tb.spread = s_data.spread
	
    tb.heroList = Funs.copy(stagedata.heroList)
    for idx,hero in pairs (tb.heroList) do
        hero.hp = hero_data.getData(hero.type,hero.lv,"maxHP")
    end
    tb.teamList = Funs.copy(stagedata.team)
	
    tb.equipments = Funs.copy(stagedata.equipments)
    tb.consume = stagedata.consume

    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/iceberg_6.png" 
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ��ս��������
--------------------------
function RiskHelper.getPvpSceneData()
    enableExpandAI = true
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    local tb = {}
    tb.type = 0
	tb.btFlag = 1
    tb.digVision = account_data.digVision
    tb.atk = account_data.guid
	tb.atkName = account_data.nickName
	tb.digLv = account_data.digLv
    tb.dfs = pvpaccount_data.guid
	tb.dfsName = pvpaccount_data.user
    tb.sceneID = pvpaccount_data.sceneID
    tb.sceneLv = pvpaccount_data.sceneLv
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName) --��ʼ��ս������
   -- pauseShopItemRT() --��ͣ�������,�ڽ��յ�ս���ط����ݺ�ָ� 395004
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(pvpaccount_data.digTrace)
    tb.mileSpread = Funs.copy(pvpaccount_data.mileSpread)
    tb.collectorList = Funs.copy(pvpaccount_data.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(pvpaccount_data.creatureList)
    tb.monsterLvLook = Funs.copy(pvpaccount_data.monsterLvLook)
    tb.heroList = account_data.heroList
	for idx,hero in pairs(account_data.heroList) do
        hero.hp = hero_data.getData(hero.type, hero.lv, "maxHP")
    end
    tb.teamList = account_data.team 
	tb.equipments = account_data.equipments
    tb.bag = account_data.bag
    tb.teamBag = account_data.teamBag
    tb.consume = account_data.consume 
    tb.headImg = scene_data[tb.sceneID].sub_img --"GUIRes/image/bg/grasslands_5.png"
    tb.entraImg =scene_data[tb.sceneID].enter_img --"GUIRes/image/bg/grasslands_6.png" 
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
end
--------------------------
--��ȡ¼�񳡾�����
--------------------------
function RiskHelper.getVideoSceneData()
     local tb = {}
     tb.type = 0
	 tb.btFlag = 2
     tb.old_acct = VideoDetail.atk
     if VideoDetail.def.user == account_data.guid then
        tb.type = 1
        tb.old_acct = VideoDetail.def
    end
	--��ʱ����Ӣ�ۼ���ͷ����Դ
	graphicLoader.loadFrameWithFile(KVariantList.battleImgList,KVariantList.heroPvrPath)
    tb.digVision = VideoDetail.atk.digVision or 2
    tb.atk = VideoDetail.atk.guid
	tb.atkName = VideoDetail.atk.userName
	tb.digLv = VideoDetail.atk.digLv or 1
    tb.dfs = VideoDetail.def.guid
	tb.dfsName = VideoDetail.def.userName
    tb.sceneID = VideoDetail.def.sceneID
    tb.sceneLv = VideoDetail.def.sceneLv
    tb.frameCnt = VideoDetail.atk.frameCnt
    RiskHelper.initBP(tb.type,tb.btFlag,tb.sceneID,tb.sceneLv,tb.dfsName) --��ʼ��ս������
    tb.w,tb.h = scene_data.getWH(tb.sceneID, tb.sceneLv)
    tb.digTrace = Funs.copy(VideoDetail.def.digTrace)
    tb.mileSpread =  Funs.copy(VideoDetail.def.mileSpread)
    tb.collectorList = Funs.copy(VideoDetail.def.collectorList) --�󳵷ֲ�
    tb.spread = scene_data.get(tb.sceneID, tb.sceneLv).spread
    tb.entraIdx = tb.w/2
    tb.creatureList =  Funs.copy(VideoDetail.def.creatureList)
    tb.monsterLvLook = Funs.copy(VideoDetail.def.monsterLvLook)
    tb.heroList = VideoDetail.atk.heroList
	for idx,hero in pairs(tb.heroList) do
        hero.hp = hero_data.getData(hero.type, hero.lv, "maxHP")
    end
    tb.teamList = Funs.copy(VideoDetail.atk.team )
	tb.equipments = VideoDetail.atk.equipments
    tb.teamBag = Funs.copy(VideoDetail.atk.teamBag)
    tb.consume = VideoDetail.atk.consume 
    tb.itemFrame = Funs.copy(VideoDetail.atk.itemUsageFrame) or {} --ʹ��ʱ��
	tb.itemPos = Funs.copy(VideoDetail.atk.itemUsagePos) or {}--ʹ��λ��
    tb.heroEnterFrame = Funs.copy(VideoDetail.atk.heroEnterFrame) or {}
	tb.heroCreatedFrame = Funs.copy(VideoDetail.atk.heroCreatedFrame) or {}
	tb.skillFrame = Funs.copy(VideoDetail.atk.skillUsageFrame) or {}
    tb.bag = {}
    for itemid,usetb in pairs(tb.itemFrame) do
        tb.bag [itemid] = #usetb
    end
    --ս����ʧ��Ϣ�����������ʾ
	tb.atk_elo = VideoDetail.atk_elo
	tb.def_elo = VideoDetail.def_elo
	for idx = 1,7 do
		local coinname = KVariantList.coinType[idx]
		local atkparam = string.format("atk_%s",coinname)
		local defparam = string.format("def_%s",coinname)
		tb[atkparam] = VideoDetail[atkparam]
		tb[defparam] = VideoDetail[defparam]
	end
    tb.stars = VideoDetail.stars
    ----------------------
    tb.headImg = scene_data[tb.sceneID].sub_img
    tb.entraImg =scene_data[tb.sceneID].enter_img
    tb.earthImg = EarthImages[tb.sceneID]
    return tb
    
end

--��ȡ�ֲ������ھ�������Ŀ�
function RiskHelper.getMineOutOfDigTrance(d_data)
    local openedView = Funs.getIdxInVision(d_data.digTrace,d_data.w,d_data.h,d_data.digVision,nil)--�ھ���Ұ
    local mineView =  Funs.getIdxInVision(d_data.entraIdx,d_data.w,d_data.h,d_data.maxDigPt,nil)--������Ұ
    local cnt = baseCalc.getVisibleMineCnt() --��ʾ����
    local tb = {}
    for idx,item in pairs(d_data.mileSpread) do
        if #tb>= cnt then return tb end
        if not openedView[idx] then
            if mineView[idx] and not d_data.digTrace[idx] then
                table.insert(tb,idx)
            end 
        end
    end
    return tb
end
--------------------------
--��ȡ��������������б�
--------------------------
function RiskHelper.getDefAwardRes(pid)
    local tb={}
    local stagedata = pveGuardQuery.getName(pid)
    if stagedata then
        for key,val in pairs(stagedata) do
            if KVariantList.coinName[key] then
                tb[key] = val
            end
        end
    end
    return tb
end
--------------------------
--��ȡӢ������
--------------------------
function RiskHelper.getHeroData(heroid,herolist)
    for _, hero in pairs(herolist) do
        if hero.type == heroid then
            return hero
        end
    end
   -- print("can not find heroData from HeroList with heroid:",heroid)
    return nil
end
--------------------------
--��ȡӢ�۶���
--------------------------
function RiskHelper.getHeroObj(heroid,heroObjs)
    if heroObjs then
        for _, hero in pairs(heroObjs) do
            if hero:getprop("type")== heroid then
                return hero
            end
        end
    end
   -- print("can not find HeroObj from heroObjs with heroid:",heroid)
    return nil
end
--------------------------
--��ȡӢ�۶�������ֵ
--------------------------
function RiskHelper.getHeroConsume(heroid,herolist)
    local s_cfg = hero_data.getConfig(heroid)
    local hero = RiskHelper.getHeroData(heroid,herolist)
    local s_data = hero_data.get(hero.type,hero.lv)
    return s_data.consume
end
--------------------------
--�жϿ����Ƿ���ھ�
--------------------------
function RiskHelper.isRemovable(idx,digTrace,w,h)
    if idx > 0 and digTrace[idx] then return false end
    local idx_t = Funs.getTop(idx,w)
    if idx_t > 0 and  digTrace[idx_t] then  return true end  --���Ϸ��������ھ�

    local idx_b = Funs.getBottom(idx,w,h)
     if idx_b > 0 and  digTrace[idx_b] then  return true end --���·��������ھ�

    local idx_r = Funs.getRight(idx,w )
    if idx_r > 0 and  digTrace[idx_r] then  return true end--�ҷ��������ھ�

    local idx_l = Funs.getLeft(idx,w)
    if idx_l > 0 and  digTrace[idx_l] then  return true end--����������ھ�
    return false
end

--��ʼ��ս������
function RiskHelper.initBP(mtype,btFlag,areaid,stageid,defUser)
    battleAIData = {}
    battleProgress ={}
	battleProgress.user = defUser
    battleProgress.type = mtype
    battleProgress.btFlag = btFlag
    battleProgress.startTime = os.time()
    battleProgress.areaID = areaid
    battleProgress.stageID = stageid
    battleProgress.heroDamage = {} --heroDamage={[heroid]={damage1,time1,damage2,time2...}}
    battleProgress.monsterDeath = {} 
    battleProgress.gold = {}  --gold = {pos,pos2...} --posΪ����collectorList��������λ��
    battleProgress.oil = {}   --oil = {pos,pos2...}
	battleProgress.collector={}--collector={idx1,idx2...}idxΪ����collectorList��������λ��
    --battleProgress.itemUsage = {} --itemUsage = {[itemid]={time1,time2,...}}
    battleProgress.itemUsageFrame = {}--itemUsageFrame = {[itemid]={framid1,frameid2,...}}
	battleProgress.itemUsagePos = {}--itemUsagePos = {[itemid]={idx1,idx2,...}} --����ʹ��λ��
    battleProgress.heroEnterFrame = {} --heroEnterFrame={heroid,framid,}
    battleProgress.heroCreatedFrame = {} --heroCreatedFrame={heroid,framid,} --Ӣ��AI������
	battleProgress.skillUsageFrame = {} --skillUsageFrame={[heroid]={framid1,..frameidn},} --Ӣ�ۼ���ʹ��֡
    battleProgress.stars = 0 
    battleProgress.frameCnt = 0
	battleProgress.gainRes = {} --gainRes={gold=0,stoneR = 0,...}
	battleProgress.gainHeroMsg={} --gainHeroMsg={[heroid] = msgNum,...}Ӣ��ID����õ���Ϣ�� 
end
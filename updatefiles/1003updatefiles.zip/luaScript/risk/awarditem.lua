local kImgCoin = "img_coin"
local kLblVal = "lbl_coin_val"
local __imgpropitem = {}
function __imgpropitem.init(obj,name,val)
    local imgsrc = ImageList[string.format("comm_%s",name)]
    obj:egChangeImg(kImgCoin,imgsrc,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblVal,val)
	local img = obj:egGetWidgetByName(kImgCoin)
	local lbl = obj:egGetWidgetByName(kLblVal)
	local imgsize = img:getSize()
	local lblsize = lbl:getSize()
	local panelsize = obj:egNode():getSize()
	img:setPosition(ccp(imgsize.width/2,img:getPositionY()))
	lbl:setPosition(ccp(imgsize.width + 5,lbl:getPositionY()))
	obj:egNode():setSize(CCSizeMake(imgsize.width + lblsize.width + 30,panelsize.height))
end
AwardItem={}
function AwardItem.new(name,val)
    local obj = {}
    CocosWidget.install(obj,JsonList.imgProp)
    table_aux.unpackTo(__imgpropitem, obj)
    obj:init(name,val)
    return obj
end

local kLblScope = "lbl_scope"
local kPanleAward = "awardinfo_panel"
local kImgLine = "img_line"
local kImgStar = "img_star"
local __defawarditem = {}
function __defawarditem.init(obj,awardinfo)
	
	local scopetxt = string.format("%d%s%d",awardinfo[1],TxtList.linkSymbol,awardinfo[2])
    obj:egSetLabelStr(kLblScope,scopetxt)
	local panelaward = obj:egGetWidgetByName(kPanleAward)
	obj._actW = panelaward:getPositionX()
	local max_x = 0
    for coinname,val in pairs (awardinfo[3]) do
        local awarditem = AwardItem.new(coinname,string.format("%s%d",TxtList.numSymbol,val))
        panelaward:addChild(awarditem:egNode())
		local w = awarditem:egNode():getPositionX() + awarditem:egNode():getSize().width
		if w>max_x then max_x = w end
    end
	obj._actW = obj._actW + max_x
end
function __defawarditem.getItemW(obj)
	return obj:egNode():getSize().width
end
function __defawarditem.getShownW(obj)
	return obj._actW
end
function __defawarditem.reLocateLine(obj,offsetx)
	local img = obj:egGetWidgetByName(kImgStar)
	local panel = obj:egGetWidgetByName(kPanleAward)
	local lbl = obj:egGetWidgetByName(kLblScope)
	img:setPosition(ccp(img:getPositionX() + offsetx,img:getPositionY()))
	panel:setPosition(ccp(panel:getPositionX() + offsetx,panel:getPositionY()))
	lbl:setPosition(ccp(lbl:getPositionX() + offsetx,lbl:getPositionY()))
end
DefAwardItem={}
function DefAwardItem.new(awardinfo)
    local obj = {}
    CocosWidget.install(obj,JsonList.defAwardItem)
    table_aux.unpackTo(__defawarditem, obj)
    obj:init(awardinfo)
    return obj
end
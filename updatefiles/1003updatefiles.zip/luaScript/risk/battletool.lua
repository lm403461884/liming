
local kImgTool = "img_tool_t"
local kLblNum = "lbl_num"
local kBtnTool = "tool_btn"
local kPanelCD = "img_cd"
local kRedColor = ccc3(255,0,0)
local kGrayColor = ccc3(64,64,64)
local kWhiteColor = ccc3(255,255,255)
local kCellW = 130
local __battletool={}
function __battletool.init(obj,itemid,d_data)
    obj._selected = false
    obj._d_data = d_data
    --obj._bagIdx = bagIdx
    obj._itemId = itemid--obj._d_data.teamBag[obj._bagIdx] --������ָ��λ�ô��ڵ���
    obj._usedTime = 0
    obj:egSetWidgetTouchEnabled(kBtnTool,false)
    if obj._itemId then
        obj._itemData  = itemQuery.query(obj._itemId)
        obj._curNum = obj._d_data.bag[obj._itemId]
        obj:egChangeImg(kImgTool,obj._itemData.icon,UI_TEX_TYPE_PLIST)
        obj:egSetBMLabelStr(kLblNum,obj._curNum)
        if obj._curNum <= 0 then
            obj:egSetWidgetColor(kLblNum,kRedColor)
            obj:egSetWidgetColor(kImgTool,kGrayColor) 
        else
            obj:bindClickListener() 
            obj:egSetWidgetTouchEnabled(kBtnTool,true)
        end
    else
        obj:egHideWidget(kImgTool)
        obj:egHideWidget(kLblNum)
    end
    obj._imgWidget = tolua.cast(obj:egGetWidgetByName(kImgTool),"ImageView")
    obj._imgSize = obj._imgWidget:getSize()
    obj._toolWidget = tolua.cast(obj:egGetWidgetByName(kBtnTool),"Button")
    obj:initCDBar()
end
function __battletool.initCDBar(obj)
    local cdwidget = tolua.cast(obj:egGetWidgetByName(kPanelCD):getVirtualRenderer(),"CCSprite")
    local sprite = CCSprite:create(ImageList.comm_cd)
    
    local scale = kCellW/sprite:getContentSize().width
    
    obj._cdsprite = CCProgressTimer:create(sprite)
    obj._cdsprite:setScale(scale)
	obj._cdsprite:setType(kCCProgressTimerTypeRadial)
	cdwidget:addChild(obj._cdsprite)
    obj._cdsprite:setVisible(false)
end
function __battletool.doClickTool(obj)
	obj:egSetWidgetTouchEnabled(kBtnTool,false)
	obj:setSelected(not obj._selected)
	if obj._clickCallback then 
		obj._clickCallback(obj)
	end
	obj:egSetWidgetTouchEnabled(kBtnTool,true)
	SoundHelper.playEffect(SoundList.click_monster_menu)
end
function __battletool.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:doClickTool()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnTool,nil,nil,touchEnded,touchCanceled)
end
function __battletool.setSelected(obj,selected)
    obj._selected = selected
    obj._toolWidget:setFocused(selected)
    if selected then
       obj._imgWidget:setOpacity(200) 
       obj._toolWidget:setScale(1.02)
    else
        obj._imgWidget:setOpacity(255)
        obj._toolWidget:setScale(1)
    end
end
function __battletool.disableTouch(obj)
    obj._disableTouch = true
    obj:egSetWidgetTouchEnabled(kBtnTool,false)
end
function __battletool.activeCD(obj)
	obj._cdsprite:setVisible(true)
	obj:egSetWidgetTouchEnabled(kBtnTool,false)
	local action_progress_to = CCProgressFromTo:create(obj._itemData.ucd,100,0)
	local function cd_callbackfunc(sender)
		obj._cdsprite:setVisible(false)
		if not obj._disableTouch then
		    obj:egSetWidgetTouchEnabled(kBtnTool,true)
		end
	end
	local action_callback = CCCallFuncN:create(cd_callbackfunc);
	obj._cdsprite:runAction(CCSequence:createWithTwoActions(action_progress_to, action_callback))
end
--�ж��Ƿ����
function __battletool.canBeUsed(obj)
    if not obj._itemId then return false end
    if not obj._itemData then return false end
    --����������
    if obj._curNum <= 0 then  return false end
    --��������ȴ״̬
    if os.time() - obj._usedTime < obj._itemData.ucd then return false end
    return true
end 
--�ڳ�����ָ��λ��ʹ�õ���
function __battletool.doUseToolAt(obj,matrixIdx,frameId)
    obj:egSetWidgetTouchEnabled(kBtnTool,false)
    obj:setSelected(false)
    if not obj:canBeUsed() then return end
    obj._usedTime = os.time()
    obj._curNum = obj._curNum - 1
    obj:egSetBMLabelStr(kLblNum,obj._curNum)
    if obj._curNum <= 0 then
        obj:egSetWidgetColor(kLblNum,kRedColor)
        obj:egSetWidgetColor(kImgTool,kGrayColor) 
    end
    obj._d_data.bag[obj._itemId] = obj._curNum
     if battleProgress.itemUsagePos[obj._itemId] then
       -- table.insert( battleProgress.itemUsage[obj._itemId],obj._usedTime)
        table.insert(battleProgress.itemUsagePos[obj._itemId],matrixIdx)
        table.insert( battleProgress.itemUsageFrame[obj._itemId],frameId)
    else
        --battleProgress.itemUsage[obj._itemId]={obj._usedTime}
        battleProgress.itemUsagePos[obj._itemId]={matrixIdx}
        battleProgress.itemUsageFrame[obj._itemId]={frameId}
    end
    obj._itemData.onUse(matrixIdx)
    obj:activeCD()
end
function __battletool.onClicked(obj,callback)
    obj._clickCallback = callback
end
BattleTool={}
function BattleTool.new(bagIdx,d_data)
    local obj = {}
    CocosWidget.install(obj,JsonList.battleTool)
    table_aux.unpackTo(__battletool, obj)
    obj:init(bagIdx,d_data)
    return obj
end
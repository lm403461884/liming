TouchLv = 
{
    msgLayer = -256,
    guidLayer = -254,
    menuLayer = -2,
    btnMaskLayer = -1,
    normalLayer = 0,
    
}
UILv=
{
	quitLayer = 257,
    msgLayer = 256,
    guidLayer = 255,
    cdLayer = 9,
    popLayer = 5,
    loadingLayer = 11
}
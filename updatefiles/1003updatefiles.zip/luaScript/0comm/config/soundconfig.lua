local fx_bgm = "sound/bgm/"
local fx_menu = "sound/menu/"
local fx_sprite = "sound/sprite/"
local fx_item = "sound/item/"
local bgm_ns = ".mp3"
local effect_ns = ".wav"
SoundList = {}
SoundList.bgm_ns = bgm_ns
SoundList.effect_ns = effect_ns
SoundList.train_bgm = fx_bgm.."HO_train"..bgm_ns
SoundList.shop_bgm = fx_bgm.."HO_shop"..bgm_ns
SoundList.rish_bgm = fx_bgm.."HO_world_map"..bgm_ns
SoundList.atk_bgm = fx_bgm.."HO_battle_attack"..bgm_ns
SoundList.def_bgm = fx_bgm.."HO_battle_defend"..bgm_ns
SoundList.dig_bgm = fx_bgm.."HO_mining"..bgm_ns
SoundList.comic_bgm = fx_bgm.."HO_opening"..bgm_ns

SoundList.arriveStation = fx_menu.."arrive_station"..effect_ns --到达新地区火车进站
SoundList.battleLose = fx_menu.."battle_lose"..effect_ns --战斗失败
SoundList.battleWin = fx_menu.."battle_win"..effect_ns --战斗胜利
SoundList.clickMenu = fx_menu.."click_menu"..effect_ns --主界面面板按键
SoundList.clickTrain = fx_menu.."click_train"..effect_ns --火车点击
SoundList.clickTrainHead = fx_menu.."click_train_head"..effect_ns --火车头出发
SoundList.digBlock = fx_menu.."dig_block"..effect_ns --挖掘普通砖块
SoundList.digDisabled = fx_menu.."dig_disable"..effect_ns --挖掘等级不足提示
SoundList.digFailed = fx_menu.."dig_failed"..effect_ns --高级土块一次未挖碎
SoundList.digOil = fx_menu.."dig_oil"..effect_ns --挖掘石油
SoundList.digGold = fx_menu.."dig_gold"..effect_ns --挖掘金矿
SoundList.inviteHero = fx_menu.."invite_hero"..effect_ns --招募成功
SoundList.message = fx_menu.."message"..effect_ns --消息
SoundList.up_level = fx_menu.."up_level"..effect_ns --英雄升级

--temp--
SoundList.destroy_rock = fx_menu.."Destroy_rock"..effect_ns
SoundList.gold_Metal_click = fx_menu.."gold_Metal_click"..effect_ns

--道具音效
SoundList.baseball_attack_01 = fx_item.."baseball_attack_01"..effect_ns
SoundList.baseball_hit_01 = fx_item.."baseball_hit_01"..effect_ns
SoundList.Goods_cookie = fx_item.."Goods_cookie"..effect_ns
SoundList.GasBomb_attack_01 = fx_item.."GasBomb_attack_01"..effect_ns
SoundList.Goods_perk = fx_item.."Goods_perk"..effect_ns
SoundList.Goods_detect = fx_item.."Goods_detect"..effect_ns
SoundList.Goods_potion = fx_item.."Goods_potion"..effect_ns
SoundList.Goods_throw = fx_item.."Goods_throw"..effect_ns

SoundList.energe_ready = fx_item.."energe_ready"..effect_ns
SoundList.energe_fire = fx_item.."energe_fire"..effect_ns
--界面音效
SoundList.click_back_button = fx_menu.."click_back_button"..effect_ns --返回
SoundList.click_buy_button = fx_menu.."click_buy_button"..effect_ns --购买
SoundList.click_paper_close = fx_menu.."click_paper_close"..effect_ns --关闭页面
SoundList.click_paper_open = fx_menu.."click_paper_open"..effect_ns --打开页面
SoundList.click_shop_goods = fx_menu.."click_shop_goods"..effect_ns --点击项目
SoundList.click_world_menu = fx_menu.."click_world_menu"..effect_ns --点击音效
SoundList.shop_door_open = fx_menu.."shop_door_open"..effect_ns --打开商店
SoundList.mine_die_01 = fx_item.."mine_die_01"..effect_ns --打开商店
SoundList.mine_hurt_01 = fx_item.."mine_hurt_01"..effect_ns --打开商店
SoundList.box_open_01 = fx_item.."box_open_01"..effect_ns --宝箱点击
SoundList.buy_hero_01 = fx_menu.."buy_hero_01"..effect_ns --点击雇佣
SoundList.buy_message_01 = fx_menu.."buy_message_01"..effect_ns --点击信封
SoundList.update_equip = fx_menu.."update_equip"..effect_ns --点击装备升级
SoundList.click_letter_open = fx_menu.."click_letter_open"..effect_ns --点击信封

--坑洞生物操作音效

SoundList.click_monster_dig = fx_menu.."click_rescar_dig"..effect_ns --点击坑道生物
SoundList.set_monster_dig = fx_menu.."set_rescar_digres"..effect_ns --放置坑道生物
SoundList.click_monster_menu = fx_menu.."click_monster_menu"..effect_ns --坑道生物栏点击
SoundList.click_rescar_dig = fx_menu.."click_rescar_dig"..effect_ns --点击坑道中矿车
SoundList.click_rescar_digres = fx_menu.."click_rescar_digres"..effect_ns --点击坑道中正在挖矿的矿车与放置矿车在矿上
SoundList.set_rescar_digres = fx_menu.."set_rescar_digres"..effect_ns --放置机械怪与放置矿车在非矿上
SoundList.click_rescar_dighasres = fx_menu.."click_rescar_dighasres"..effect_ns --点击有资源的矿车
SoundList.hero_go = fx_menu.."hero_go"..effect_ns --英雄进入战斗点击音效
SoundList.click_Error = fx_menu.."click_Error"..effect_ns --错误提示音通用

--战斗单位用音效
SoundList.battle_uint_effect = {}
function addUnitSoundEffect(unit_name,effect_name)
	SoundList["battle_uint_effect"][unit_name] = {}
	for eff_num,eff_name in ipairs(effect_name) do
		SoundList["battle_uint_effect"][unit_name][eff_name] = fx_sprite..unit_name.."/"..eff_name..effect_ns
		SoundHelper.unloadEffect(SoundList["battle_uint_effect"][unit_name][eff_name])
		SoundHelper.preLoadEffect(SoundList["battle_uint_effect"][unit_name][eff_name])
	end
end
--预加载音效文件
function preLoadSounds()
addUnitSoundEffect("buder01",{"hit_01","attack_01","hit_02","hurt_01","death_01","attack_02","skill_01"})
addUnitSoundEffect("bear01",{"hit_01","attack_01","death_01","hurt_01"})
addUnitSoundEffect("heavygun_bullet01",{"attack_01",})
addUnitSoundEffect("snowball01",{"attack_01","skill_01"})
addUnitSoundEffect("scientist01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("infighter01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("bomberman01",{"hit_01","attack_01","hurt_01","death_01"})
addUnitSoundEffect("icebomber01",{"hit_01","attack_01","hurt_01","death_01"})
addUnitSoundEffect("boomerang01",{"hit_01","run_01",})
addUnitSoundEffect("shockdevice01",{"attack_01","death_01","hurt_01",})
addUnitSoundEffect("mushroom01",{"attack_01","death_01","hurt_01",})
addUnitSoundEffect("firedragon01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("artisan01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("mole01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("queen01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("lizard01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("revenger01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("rockman01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("nurses01",{"hit_01","attack_01","hit_02","hurt_01","death_01","attack_02","skill_01"})
addUnitSoundEffect("miningrobot01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("skeletonman01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("doublegun_bullet01",{"attack_01",})
addUnitSoundEffect("stone01",{"hit_01","run_01",})
addUnitSoundEffect("spider01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("bigsword01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("mushroom_bullet01",{"attack_01",})
addUnitSoundEffect("conch01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("villainb01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("piranha01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("machinemouth01",{"hit_01","attack_01","death_01","hurt_01",})
addUnitSoundEffect("avatars01",{"attack_01",})
addUnitSoundEffect("villaina01",{"attack_01","hit_02","reloading_01","death_01","hurt_01",})
addUnitSoundEffect("teargasbomb01",{"attack_01",})
addUnitSoundEffect("doublegun01",{"attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("knight01",{"hit_01","attack_01","run_01","hurt_01","death_01","skill_01"})
addUnitSoundEffect("assassin01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("meetcar01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("tank01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("joker01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("bowman01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("bomb01",{"attack_01",})
addUnitSoundEffect("missile01",{"attack_01",})
addUnitSoundEffect("bow01",{"attack_01",})
addUnitSoundEffect("tank_bullet01",{"attack_01",})
addUnitSoundEffect("heavygun01",{"attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("snowman01",{"attack_01","death_01","hurt_01"})
addUnitSoundEffect("sisters01",{"hit_01","attack_01","death_01","hurt_01","skill_01"})
addUnitSoundEffect("bigbomb01",{"attack_01",})
end





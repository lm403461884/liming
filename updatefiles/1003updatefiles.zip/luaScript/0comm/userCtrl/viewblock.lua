
local __viewblock={}

function __viewblock.lightTopLeft(obj)
    obj._topLeft  =2
    obj:refresh()
end
function __viewblock.lightTopRight(obj)
    obj._topRight = 1
    obj:refresh()
end
function __viewblock.lightBottomLeft(obj)
    obj._bottomLeft = 8
    obj:refresh()
end
function __viewblock.lightBottomRight(obj)
    obj._bottomRight = 4
    obj:refresh()
end
function __viewblock.lightTop(obj)
	 obj._topLeft  =2
	 obj._topRight = 1
	  obj:refresh()
end
function __viewblock.getNum(obj)
    return obj._num
end
function __viewblock.refresh(obj)
	local num = obj._topLeft + obj._topRight + obj._bottomLeft +obj._bottomRight
	if obj._num  ~= num then
	    obj._num = num
	    obj:egChangeFrame(ViewImages[obj._areaid][obj._num + 1])
	    obj:egNode():getTexture():setAliasTexParameters()
       --obj:egRunAction(CCFadeIn:create(0.5))
	    
	end
end

Viewblock={}
--������Ұģ��
function Viewblock.new(areaid)
	local obj = {}
	table_aux.unpackTo(__viewblock, obj)
	sprite.install(obj)
	obj._topLeft = 0
	obj._bottomLeft = 0
	obj._topRight = 0
	obj._bottomRight = 0
	obj._areaid = areaid
    obj:refresh()
	return obj
end

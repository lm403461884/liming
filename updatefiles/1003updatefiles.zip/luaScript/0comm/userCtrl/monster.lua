local __monster = {}
function __monster.openAi(obj)
    ai_module.add(obj)
    obj:showHP()
end
function __monster.setSelected(obj,selected)
	if selected then
		obj:egSetAlpha(255)
		obj:showHPBar()
	else
		obj:egSetAlpha(128)
		obj:hideHPBar()
	end
end
Monster={}

function Monster.new(mtype,lv,idx)

	local obj = {}
	table_aux.unpackTo(__monster, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
	sprite.install(obj)
	Blood.install(obj)
	local s_cfg = monster_data.getConfig(mtype)
	local s_data = monster_data.get(mtype,lv)
	for name,val in pairs(s_data) do
		obj:addprop(name,val)
	end

	obj:addprop('mainType', 2)
	obj:addprop('type', mtype)
	obj:addprop("level", lv)
	obj:addprop('aiEntryName', s_cfg.aiEntryName) --string
	obj:addprop('skillNames', s_cfg.skillNames) --table
	obj:addprop("zorder", 0)
	obj:addprop("birthPlace", idx)
	obj:addprop('graphName', s_cfg.graphList[s_data.graphLV])
	obj:egChangeFrame(string.format('%s_020201.png',s_cfg.graphList[s_data.graphLV]))
	obj:addprop('hp', obj:getprop('maxHP'))
	return obj
end


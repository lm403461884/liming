
local __mine={}
function __mine.showBrokenActions(obj)
    local mtype =  obj:getprop("type")
	local lv =   obj:getprop("level")
	local animaName = Pic.getMineAnima(mtype,lv)
	 local animaCache = CCAnimationCache:sharedAnimationCache()
	local anima = animaCache:animationByName(animaName)
    local animate = CCAnimate:create(anima)
	local function callback()
		local holelayer = AccountHelper:get(kHoleLayer)
		blocklayer = holelayer._blocklayer
		blocklayer:removeMineralAt(obj:getprop("birthPlace"))
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(animate,callfunc)
    obj:egRunAction(sequence)
end

Mine={}

--������������
function Mine.new(pos, prop,areaid,deep)
	local obj = {}
    table_aux.unpackTo(__mine, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
	sprite.install(obj)
	local s_data = mile_data.get(prop.type, prop.lv)
	for name,val in pairs(s_data) do
		obj:addprop(name,val)
	end
    obj:addprop("type",prop.type)			 --��������	
    obj:addprop("level", prop.lv)  
	obj:addprop("leftCnt", prop.cnt) 	--ʣ���
 	obj:addprop("birthPlace", pos)
    obj:egChangeFrame(Pic.getMineral(prop.type,areaid,deep,prop.lv))	
    obj:addprop("zorder", 0)
	return obj
end


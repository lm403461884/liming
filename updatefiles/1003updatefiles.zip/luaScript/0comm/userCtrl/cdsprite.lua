
local __cdsprite={}

function __cdsprite.showCD(obj,sec,from,to,callback,type)
	local action_progress_to = CCProgressFromTo:create(sec,from,to)
	local function cd_callbackfunc(sender)
		obj:egRemoveSelf()
		if callback then callback() end
	end
	local action_callback = CCCallFuncN:create(cd_callbackfunc);
	obj._cdsprite:runAction(CCSequence:createWithTwoActions(action_progress_to, action_callback))
	---------------------Number show
	local time = sec-1
	local m=0
	local h=0
	local function SubTime()
	      time=time-1
	      m=math.floor(time/60)
	      h=math.floor(m/60)
	      if obj._blackNumSprite and time>=0 then-----------�ж�ʱ�䡢obj�Ƿ�Ϊ��
	          if type==1 then---------�ж�����
       	          if h>=1 then
	               obj._orangeNumSprite:setString(h)
	               obj._orangeSprite:setString(TxtList.hours)
	              elseif m>=1 then
	       
	                obj._orangeNumSprite:setString(m)
	               obj._orangeSprite:setString(TxtList.minute)
	              else
	
	                obj._orangeNumSprite:setString(time)
	               obj._orangeSprite:setString(TxtList.sec)
	          
	              end
	         elseif type==2 then
	              if h>=1 then
	               obj._blackNumSprite:setString(h)
	               obj._blackSprite:setString(TxtList.hours)
	              elseif m>=1 then
	              obj._blackSprite:setString(TxtList.minute)
	              obj._blackNumSprite:setString(m)
	              else
	              obj._blackSprite:setString(TxtList.sec)
	              obj._blackNumSprite:setString(time)
	              end
             end   
	     else
	       obj:egUnBindSchedule()
	     end
	end	
	obj:egBindSchedule(SubTime,1)	
end
function __cdsprite.onExit(obj)
    local function callback()
         obj:egUnBindSchedule()
    end
    obj:egOnExit(callback)
end
CDSprite= {}

function CDSprite.new()
    local obj = {}
    sprite.install(obj        )
    table_aux.unpackTo(__cdsprite, obj)
    local sprite = CCSprite:create(ImageList.comm_cd)
    obj:egNode():setContentSize(sprite:getContentSize())
    obj._cdsprite = CCProgressTimer:create(sprite)
	obj._cdsprite:setType(kCCProgressTimerTypeRadial)
	obj._cdsprite:setAnchorPoint(ccp(0.0,0.0))
	obj._cdsprite:setPosition(ccp(0.0,0.0))
	obj:egAddChild(obj._cdsprite,UILv.cdLayer,UILv.cdLayer)
    obj:onExit()
    
    local fontName = FNList.BlackNum
    local fontSize = 1
    obj._blackNumSprite = CCLabelBMFont:create("",fontName,fontSize)
    obj._blackNumSprite:setPosition(ccp(23,35))	
    obj._blackNumSprite:setScale(0.7)
    obj:egAddChild(obj._blackNumSprite,UILv.cdLayer,UILv.cdLayer)	
    
    local fontName2 = FNList.BlackTime
    local fontSize2 = 1
    obj._blackSprite = CCLabelBMFont:create("",fontName2,fontSize2)
    obj._blackSprite:setPosition(ccp(55,35))
    obj._blackSprite:setScale(0.8)
    obj:egAddChild(obj._blackSprite,UILv.cdLayer,UILv.cdLayer)
    
    local fontName3 = FNList.OrangeNum
    local fontSize3 = 1
    obj._orangeNumSprite = CCLabelBMFont:create("",fontName3,fontSize3)
    obj._orangeNumSprite:setPosition(ccp(23,35))
    obj._orangeNumSprite:setScale(0.7)	
    obj:egAddChild(obj._orangeNumSprite,UILv.cdLayer,UILv.cdLayer)
    
    local fontName4 = FNList.OrangeTime
    local fontSize4 = 1
    obj._orangeSprite = CCLabelBMFont:create("",fontName4,fontSize4)
    obj._orangeSprite:setPosition(ccp(55,35))
    obj._orangeSprite:setScale(0.8)
    obj:egAddChild(obj._orangeSprite,UILv.cdLayer,UILv.cdLayer)
	return obj
end

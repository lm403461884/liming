
local local_rs = {host = "127.0.0.1",port = 10001}
local company_rs = {host = "192.168.1.11",port = 10001}
local public_rs = {host = "1up.linkpc.net",port = 5000}
local public_rs1 = {host = "1up.linkpc.net",port = 6000}
local verFileUrl = "https://raw.githubusercontent.com/alidalee/duobaolianmeng/master/version"
local downLoadPath ="https://raw.githubusercontent.com/alidalee/duobaolianmeng/master/updatefiles/"
local subDir = "duobaolianmeng"

rs_config = local_rs
local rsMsgParser = {}
--==========================
--291001 ��½�ɹ�
--==========================
--guid���û�Ψһ��Ƿ�
--ip:    ������IP
--prot:    �������˿ں�
--==========================
rsMsgParser[291001] = function(rsconn)
    local port = rsconn:readInt()
    local host,_ = rsconn:readStr()
	rsconn:disconnect()
    SocketHelper.connect(host,port)
    local scene = LoadScene.new()
    scene:egReplace()
end
--==========================
--291002 �ʺŲ����ڵ�½ʧ��
--==========================
rsMsgParser[291002] = function(rsconn)
	rsconn:disconnect()
	local logname,logpwd = AccountHelper:getDevMac()
	if logname ~= "" then
		local scene = LogoScene.new(true)
		scene:egReplace()
	else
		local function callback()
			AccountHelper:showLogin()
		end
		local msglayer = MsgLayer.new(nil,TxtList.noSuchAccount,1,callback)
		msglayer:show()
	end
end
--==========================
--291003 ע��ʧ�� �ʺ���ռ��
--==========================
rsMsgParser[291003] = function(rsconn)
    rsconn:disconnect()
    local function callback()
        AccountHelper:showLogin()
    end
    local msglayer = MsgLayer.new(nil,TxtList.registedAccount,1,callback)
    msglayer:show()
end
--==========================
--291004 ��½ʧ�� �������
--==========================
rsMsgParser[291004] = function(rsconn)
	rsconn:disconnect()
    local function callback()
        AccountHelper:showLogin()
    end
    local msglayer = MsgLayer.new(nil,TxtList.pwdNotMatch,1,callback)
    msglayer:show()
end

--==========================
--291005 �ظ���¼
--==========================
rsMsgParser[291005] = function(rsconn)
	rsconn:disconnect()
    local function callback()
        AccountHelper:showLogin()
    end
    local msglayer = MsgLayer.new(nil,TxtList.hasLogin,1,callback)
    msglayer:show()
end

--==========================
--291006 ��������
--==========================
rsMsgParser[291006] = function(rsconn)
	rsconn:disconnect()
    if RSHelper.battleNum == 0 then
        RSHelper.battleNum = 1
        local scene = BattleWaitScene.new()
		scene:egReplace()
    end
end
--==========================
--291007 �汾����
--==========================
rsMsgParser[291007] = function(rsconn)
	rsconn:disconnect()
    local scene = VerCtrScene.new()
	scene:egReplace()
    --������ش�������
end
RSHelper={}
RSHelper.battleNum = 0 --����������
function RSHelper:connect()
	self._conn = SyncSocket:connect(rs_config.host,rs_config.port,128,128)
end
function RSHelper:disconnect()
	self._conn:disconnect()
end
function RSHelper:isNewReg()
	return self._newReg
end
function RSHelper:initUpdateEngine()
	UpdateEngine:setStoragePath(CCFileUtils:sharedFileUtils():getWritablePath().. subDir)
	UpdateEngine:setVerFileUrl(verFileUrl)
	UpdateEngine:setDownLoadPath(downLoadPath)
	UpdateEngine:setTimeOut(60)
end
function RSHelper:sendRegMsg(account,pwd)
	self._newReg = true
	local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd
	self._conn:write(len_msg,921002,0,__version)
    self._conn:writeStr(account,len_account)
    self._conn:writeStr(pwd,len_pwd)
	self._conn:send()
	
end
function RSHelper:sendLogMsg(account,pwd)
	self._newReg = false
	local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd
	self._conn:write(len_msg,921001,0,__version)
    self._conn:writeStr(account,len_account)
    self._conn:writeStr(pwd,len_pwd)
	self._conn:send()
end

function RSHelper:getState()
	return self._conn:socketState()
end
function RSHelper:handleRSMsg()
	 local msglen,msgcode,msgguid,opstate = self._conn:read(4)
	 guid = msgguid
	 rsMsgParser[msgcode](self._conn)
end


local function getTableFromMsg()
    local strVal,_ = RecvQueue:readStr()
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function getBattleSumaryFromMsg()
	local strVal,_ = RecvQueue:readStr()
	strVal = string.gsub(strVal, "\\", "")
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function getTableFromPaser()
    local strVal,_ = StreamPaser:readStr()
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end
local function getZipTableFromMsg(len)
    local srcBytes = RecvQueue:readUserData(len)
    local desBytes,deslen =HOGZip:decompress(srcBytes,len)
    StreamPaser:init(desBytes,deslen)
    local strVal,_ = StreamPaser:readStr()
    ----------
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end
local _socketParser = {}

function RecvMsg()
    if not RecvQueue:hasData() then  return end
    RecvQueue:lock()
    if RecvQueue:hasData() then
      local msglen,msgcode,msgguid,opstate = RecvQueue:read(4)
      guid = msgguid
      print("msglen,msgcode,guid,opstate:",msglen,msgcode,guid,opstate)
      _socketParser[msgcode](msglen,guid,opstate)
    end
    RecvQueue:refresh()
    RecvQueue:unlock()
end

--==========================
--391001 帐号数据
--==========================
--account_data：帐号数据
--==========================
_socketParser[391001] = function(msglen)
   -- account_data = getTableFromMsg()
    local byteLen = msglen - 16
    account_data = getZipTableFromMsg(byteLen)
    print("account_data:",table_aux.serial(account_data))
    if not account_data then return end
	if not account_data.nickName then account_data.nickName = account_data.user end
    CCUserDefault:sharedUserDefault():setStringForKey("name", account_data.user)
    CCUserDefault:sharedUserDefault():setStringForKey("pwd", account_data.password)
    AccountHelper:unlock(kStateAccount)
    if not scriptDownloaded then
        AccountHelper:lock(kStateScript)
        AccountHelper:lock(kStateClub)
        AccountHelper:lock(kStateCntNewVideo)
        SendMsg[931002]()
        SendMsg[931003]()
        SendMsg[938002]()
    else
        resetRTInfo()
    end
end

--==========================
 --391002 脚本文件
 --==========================
 --fileCount:    脚本文件数量
 --type:        文件类型
 --filename:    文件名称
 --filedata:    文件内容
 --==========================
_socketParser[391002] = function(msglen)
    AccountHelper:unlock(kStateScript)
    scriptDownloaded = true
    local filecount = RecvQueue:readInt()
    local srclen = msglen - 20
    local srcBytes = RecvQueue:readUserData(srclen)
    local desBytes,deslen =HOGZip:decompress(srcBytes,srclen)
    StreamPaser:init(desBytes,deslen)
    if filecount > 0 then
        for i = 1,filecount do
            local flag,_ = StreamPaser:readStr()
            if flag ~= "9" then
                return
            else
                local filename,_ = StreamPaser:readStr()
                local filedata,_ = StreamPaser:readStr()
                local chunck, err = loadstring(filedata,filename)
                if not chunck then print(err) return end
                local succ, err = pcall(chunck)
                if not succ then print(err) return end
            end
        end
    end
    resetRTInfo()
end

--==========================
 --391003 录像信息列表
 --==========================
 --recordStr:录像列表字符串
 --[[sumary={}
	sumary.time = os.time()
	sumary.atk_gold = m_gold
	sumary.atk_oil = m_oil
	sumary.atk_elo = m_elo
	sumary.atkName = m_user
	sumary.def_gold = f_gold
	sumary.def_oil = f_oil
	sumary.def_elo = f_elo
	sumary.defName = f_user
	sumary.stars = stars
	sumary.hero = hero
	--]]
 --==========================
local function __getbattleheader()--{{{
	local cnt = RecvQueue:readInt()
	if cnt == 0 then return end
	local ret = {}
	for idx=1, cnt do
		ret[idx] = {vid=RecvQueue:readInt(), sumzlen=RecvQueue:readInt()}
	end
	return ret
 end--}}}

 local function __getbattlesumary(ud, ul)--{{{
	 StreamPaser:init(ud, ul)
	 local sumary = {
		atk_oil = 0,
		def_oil = 0,
		time = StreamPaser:readInt(),
		atkGuid = StreamPaser:readInt(),
		defGuid = StreamPaser:readInt(),
		atk_gold = StreamPaser:readInt(),
		def_gold = StreamPaser:readInt(),
		atk_iron = StreamPaser:readInt(),
		atk_copper = StreamPaser:readInt(),
		atk_stoneR = StreamPaser:readInt(),
		atk_stoneB = StreamPaser:readInt(),
		atk_stoneD = StreamPaser:readInt(),
		hero1 = StreamPaser:readInt(),
		hero2 = StreamPaser:readInt(),
		hero3 = StreamPaser:readInt(),
		hero4 = StreamPaser:readInt(),
		equip1 = StreamPaser:readInt(),
		equip2 = StreamPaser:readInt(),
		equip3 = StreamPaser:readInt(),
		equip4 = StreamPaser:readInt(),
		atk_elo = StreamPaser:readInt(),
		def_elo = StreamPaser:readInt(),
		stars = StreamPaser:readInt(),
		atkName = StreamPaser:readStr(),
		defName = StreamPaser:readStr()
	 }
	 if sumary.atkGuid == account_data.guid then
		sumary.atkName = account_data.nickName
	 else
		sumary.defName = account_data.nickName
	 end
	 --read hero data
	 local hctx = {sumary.hero1, sumary.hero2, sumary.hero3, sumary.hero4}
	 local ectx = {sumary.equip1, sumary.equip2, sumary.equip3, sumary.equip4}
	 local hero = {}
	 local team = {}
	 local heroList = {}
	 local equipments = {}
	 for idx, ctx in ipairs(hctx) do
		 if ctx > 0 then
			local hid = math.floor(ctx / 100) % 100
			local hlv = math.floor(ctx / 1000000)
			local eid = ctx % 10000
			hero[hid] = hlv
			table.insert(team, hid)
			table.insert(heroList, {type=hid, lv=hlv, eid=eid})
			local equip = ectx[idx]
			local elv = math.floor(equip / 1000)
			local eqlv = equip % 1000
			equipments[eid] = {elv, eqlv}
		 end
	 end
	 sumary.hero = hero
	 sumary.team = team
	 sumary.heroList = heroList
	 sumary.equipments = equipments
	 return sumary
 end--}}}

 local function __getbattledetail(ud, ul)--{{{
	 StreamPaser:init(ud, ul)
	 --get attacker data
	 local atk = assert(loadstring(StreamPaser:readStr()))()
	 --get defencer data
		--skip useless data
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 StreamPaser:readInt()
	 local collectorList = {}
	 local monsterLvLook = {}
	 local creatureList = {}
	 local digTrace = {}
	 local mileSpread = {}
	 local def = {
		 sceneID = StreamPaser:readInt(),
		 sceneLv = StreamPaser:readInt(),
		 collectorList = collectorList,
		 monsterLvLook = monsterLvLook,
		 creatureList = creatureList,
		 digTrace = digTrace,
		 mileSpread = mileSpread
	 }
	 --read collector list and mile spread
	 for idx=1, StreamPaser:readInt() do
		 local coll = {
			 lv = StreamPaser:readInt(),
			 st = StreamPaser:readInt(),
			 elapsed = StreamPaser:readInt(),
			 pos = StreamPaser:readInt(),
			 coin = StreamPaser:readInt(),
			 mileLv = StreamPaser:readInt(),
			 mileCnt = StreamPaser:readInt()
		 }
		 table.insert(collectorList, coll)
		 if coll.coin ~= 0 then
			 mileSpread[coll.pos] = {type=coll.coin, lv=coll.mileLv, cnt=coll.mileCnt}
		 end
	 end
	 --read monster level look
	 for idx=1, StreamPaser:readInt() do
		 local mid = StreamPaser:readInt()
		 local mlv = StreamPaser:readInt()
		 monsterLvLook[mid] = mlv
	 end
	 --read creature list
	 for idx=1, StreamPaser:readInt() do
		 local combineddata = StreamPaser:readInt()
		 local pos = math.floor(combineddata / 1000)
		 local mid = combineddata % 1000
		 creatureList[pos] = mid
	 end
	 --read dig trace
	 for idx=1, StreamPaser:readInt() do
		 local combinedpos = StreamPaser:readInt()
		 local pos1 = math.floor(combinedpos / 1000)
		 local pos2 = combinedpos % 1000
		 if pos1 > 0 then
			 digTrace[pos1] = 1
		 end
		 if pos2 > 0 then
			 digTrace[pos2] = 1
		 end
	 end

	 return atk, def
 end--}}}

_socketParser[391003] = function(msglen)--{{{
	local ret = __getbattleheader()
	if ret then
		for _, hdr in ipairs(ret) do
			local zdata = RecvQueue:readUserData(hdr.sumzlen)
			local ud, ul = HOGZip:decompress(zdata, hdr.sumzlen)
			local sumary = __getbattlesumary(ud, ul)
			sumary.vid = hdr.vid
			videomanager.addsumary(sumary)
		end
	end
	account_data.battleSumaries = videomanager.getsumaries()
    AccountHelper:unlock(kStateVideoList)
    AccountHelper:countNewVideo() --如果是登陆的时候请求录像数据，则计划是否有新的战斗记录
end--}}}

--==========================
 --391004 录像信息明细
 --==========================
 --atk: 进攻方数据
 --dfs: 防守方数据
 --==========================
_socketParser[391004] = function(msglen,guid,opstate)
	if opstate == -1 then
	else
		local vid = RecvQueue:readInt()
		local zsumlen = RecvQueue:readInt()
		local zdetaillen = RecvQueue:readInt()

		local zd_sum = RecvQueue:readUserData(zsumlen)
		local sum, sumlen = HOGZip:decompress(zd_sum, zsumlen)
		local sumary = __getbattlesumary(sum, sumlen)

		local zd_detail = RecvQueue:readUserData(zdetaillen)
		local detail, detaillen = HOGZip:decompress(zd_detail, zdetaillen)
		local atk, def = __getbattledetail(detail, detaillen)
		atk.team = sumary.team
		atk.heroList = sumary.heroList
		atk.equipments = sumary.equipments

		videomanager.addvideo(vid, {bpresult=sumary, atk=atk, def=def})
	end
    AccountHelper:unlock(kStateVideo)
end

--==========================
 --391006 ELO排名信息
 --==========================
_socketParser[391006] = function(msglen)
	local bodylen = RecvQueue:readInt()
	if bodylen > 0 then
		local leftTime = RecvQueue:readInt()
		account_data.elo_awardTime = os.time() + leftTime
		account_data.elo_rank = {}
		local byteLen = msglen - 24
		local srcBytes = RecvQueue:readUserData(byteLen)
		StreamPaser:init(srcBytes,byteLen)
		local cnt = StreamPaser:readInt()
		for idx=1,cnt do
			local tb = {}
			tb.guid,tb.elo,tb.jewel = StreamPaser:read(3)
			tb.name = StreamPaser:readStr()
			table.insert(account_data.elo_rank,tb)
		end
	else
		account_data.elo_awardTime = os.time() + 24*3600
		account_data.elo_rank = {}
	end
    AccountHelper:unlock(kStateEloRank)
end
--==========================
 --391007 ELO奖励
 --==========================
_socketParser[391007] = function(msglen)
	account_data.jewel = account_data.jewel + RecvQueue:readInt()
end

--==========================
 --391008 公共聊天信息
 --==========================
_socketParser[391008] = function(msglen)
	local userGuid = RecvQueue:readInt()
	local userDigLv = RecvQueue:readInt()
    local userName = RecvQueue:readStr()
	local userclubid = RecvQueue:readInt()
	local userclubname  = RecvQueue:readStr()
    local userMsg  = RecvQueue:readStr()
	ChatHelper.addNewMsg(userGuid,userDigLv,userName,userclubid,userclubname,userMsg)
end
--==========================
 --391009 某GUID对应的帐号摘要数据
 --==========================
_socketParser[391009] = function(msglen)
	local userbrief = {}
	userbrief.guid,userbrief.diglv,userbrief.digPt,userbrief.elo,userbrief.teamCnt= RecvQueue:read(5)
	local heroinfoList = {}
	if userbrief.teamCnt > 0 then
        for idx=1,userbrief.teamCnt do
            local tb = {}
            local heroctx = RecvQueue:readInt()
            local equipctx = RecvQueue:readInt()
            tb.herolv = math.floor(heroctx/10000)
            tb.equipid = (heroctx -tb.herolv*10000)
            tb.heroid = math.floor(tb.equipid/100)
            tb.equipqa = math.floor(equipctx/100)
            tb.equiplv = equipctx%100
            table.insert(heroinfoList,tb)
        end
	end
	userbrief.heroList = heroinfoList
	userbrief.refreshTime = os.time()--做个时间标记,2分钟内不重新获取
	ChatHelper.addUserBrief(userbrief)
end
--==========================
 --392001 地穴资源分布
 --==========================
 --aid:        地形编号
 --sid:        场景ID
 --en:         入口位置
 --cs:         生物资源分布
 --ms:         未暴露的矿脉分布
 --em:         已暴露的矿脉分布
 --==========================
_socketParser[392001] = function()
    local scenetb = getTableFromMsg()
    if not scenetb then return end
    account_data.sceneID =scenetb.aid
    account_data.sceneLv = scenetb.sid

    account_data.creatureList = {}
    account_data.mileSpread = scenetb.ms
    account_data.digPt = account_data.maxDigPt
    account_data.actPt =account_data.actPt  - numDef.openHole
    account_data.digTrace = scenetb.dt
    account_data.collectorList = scenetb.cl
    for key,item in pairs(account_data.monsterPool) do
        item.n = item.N
    end
    AccountHelper:unlock(kStateNewHole)
end

--==========================
--394001 PVE后的帐号数据
--==========================
--stars:获得的星星数
--gold:金币
--oil:石油
--pve:是否PVE战斗结果
--newStage:是否解锁新的PVE关卡
--账户变动项：根据PVE、PVP类型产生变动
--    PVE、PVP【进攻】附带bag,teamBag,heroList
--==========================

local function createBpResultFromStream()--{{{

	local result = {}

	result.stars = RecvQueue:readInt()
	result.newStage = RecvQueue:readInt()
	result.gold = RecvQueue:readInt()
	result.iron = RecvQueue:readInt()
	result.copper = RecvQueue:readInt()
	result.stoneR = RecvQueue:readInt()
	result.stoneB = RecvQueue:readInt()
	result.stoneD = RecvQueue:readInt()
	result.teamExp = {
		RecvQueue:readInt(),
		RecvQueue:readInt(),
		RecvQueue:readInt(),
		RecvQueue:readInt()
	}
	
	local msgCnt = RecvQueue:readInt()
	local heroMsg = {}
	result.heroInfo = heroMsg	
	for idx=1, msgCnt do
		local hid = RecvQueue:readInt()
		local num = RecvQueue:readInt()
		heroMsg[hid] = num
	end

	return result
end--}}}

_socketParser[394001] = function(msglen)
    AccountHelper:unlock(kStateBpResult)
    BPResult = createBpResultFromStream()
    --account_data更新项
	BPResult.gold = BPResult.gold or 0
	BPResult.oil = BPResult.oil or 0
	BPResult.iron = BPResult.iron or 0
	BPResult.copper = BPResult.copper or 0
	BPResult.stoneR = BPResult.stoneR or 0
	BPResult.stoneB = BPResult.stoneB or 0
	BPResult.stoneD = BPResult.stoneD or 0
	----更新获得的英雄消息
	for heroid,msgnum in pairs(BPResult.heroInfo) do
		local s_cfg = hero_data.getConfig(heroid)
		account_data.heroInfoList[heroid] = math.min((account_data.heroInfoList[heroid] or 0 ) + msgnum,s_cfg.infoCnt)
	end
	---------------
    account_data.gold = account_data.gold + BPResult.gold
    account_data.oil = account_data.oil + BPResult.oil
	account_data.jewel = account_data.jewel
	--------------------------------------
	-----------------------------------矿石变动
	account_data.iron = account_data.iron + BPResult.iron
	account_data.copper = account_data.copper + BPResult.copper
	account_data.stoneR = account_data.stoneR + BPResult.stoneR
	account_data.stoneB = account_data.stoneB + BPResult.stoneB
	account_data.stoneD = account_data.stoneD + BPResult.stoneD
	---------------------------------------
    account_data.teamBag = BPResult.teamBag or account_data.teamBag
    account_data.bag = BPResult.bag or account_data.bag
	--BPResult.teamExp 更新经验值
	local heroexp = {}
	for idx,heroid in ipairs(account_data.team) do
	    heroexp[heroid] = BPResult.teamExp[idx]
	end
	local lvMax = account_data.digLv * numDef.unitLvFactor
	for key,heroprop in pairs(account_data.heroList) do
	    local expval = heroexp[heroprop.type] or 0
	    if expval > 0 then
	        local dataAtNextLv = hero_data.get(heroprop.type,heroprop.lv + 1)
	        while heroprop.exp <= expval and (heroprop.lv + 1) <= lvMax and dataAtNextLv  do
                expval = expval - heroprop.exp
                heroprop.lv = heroprop.lv + 1
                heroprop.exp = dataAtNextLv.exp
                dataAtNextLv = hero_data.get(heroprop.type,heroprop.lv + 1)
            end
            if dataAtNextLv and heroprop.exp > expval and (heroprop.lv + 1) <= lvMax then
                heroprop.exp = heroprop.exp - expval
            end
	    end
	end
	--------------------------------------
	BPResult.elo = 0

    --若是PVE关卡 则尝试更新评价星
    --并根据清关标记解锁新关卡
    local bp = battleProgress
    local myArea = account_data.unlockedPVE[bp.areaID]
    local myStage = myArea[bp.stageID]
    if BPResult.stars > myStage.stars then
		MissionHelper.updateClientMission() --更新本地日常任务进度
		if not MissionHelper.groupIdx  then
			 myArea.areaStars = myArea.areaStars - myStage.stars + BPResult.stars
		end
        myStage.stars = BPResult.stars
        myStage.first = nil
        if BPResult.newStage == 1 then
            pveCalc.unlockNext(bp.areaID, bp.stageID,account_data)
        end
    end
end
--==========================
--394002 防御任务活动结算通知
--==========================
_socketParser[394002] = function(msglen)
	pveGuardQuest.calcOnClient(account_data)
end
--==========================
--395001 PVP匹配对象数据
--==========================
--dfsaccount_data：匹配的帐号信息
--==========================
_socketParser[395001] = function(msglen)
	local curTime = RecvQueue:readInt()
    local byteLen = msglen - 20
    local srcBytes = RecvQueue:readUserData(byteLen)
    StreamPaser:init(srcBytes, byteLen)
    pvpaccount_data = {}
	pvpaccount_data.guid = StreamPaser:readInt()
    pvpaccount_data.elo = StreamPaser:readInt()
    pvpaccount_data.gold = StreamPaser:readInt()
    pvpaccount_data.oil = StreamPaser:readInt()
    pvpaccount_data.digLv = StreamPaser:readInt()
    pvpaccount_data.sceneID = StreamPaser:readInt()
    pvpaccount_data.sceneLv = StreamPaser:readInt()
    pvpaccount_data.collectorList = {}
    pvpaccount_data.mileSpread = {}
	pvpaccount_data.resVal = {0,0,0,0,0,0,0} --{gold,oil,iron,copper,sR,sB,sD}
	pvpaccount_data.carRes = {}
    local rescarCnt = StreamPaser:readInt()
    for idx = 1,rescarCnt do
		local lv,st,elapsed,pos,coin,minelv,minecnt = StreamPaser:read(7)
        local tb = {}
        tb.lv = lv
        tb.st = st
        tb.elapsed = curTime-st
        tb.pos = pos
        tb.coin = coin
		table.insert(pvpaccount_data.collectorList,tb)
		local collVal = 0
		if tb.coin > 0 then
			 local tbmine = {}
			tbmine.type = coin
			tbmine.lv = minelv
			tbmine.cnt = minecnt
			pvpaccount_data.mileSpread[pos] = tbmine
			local mine_cfg = mile_data.get(tbmine.type, tbmine.lv)
			if minecnt >= mine_cfg.gainVal then collVal = mine_cfg.gainVal	end
			pvpaccount_data.resVal[coin] = pvpaccount_data.resVal[coin] + collVal
		end
		table.insert(pvpaccount_data.carRes,collVal)
    end
    --monsterLvLook
    local monsterCnt = StreamPaser:readInt()
    pvpaccount_data.monsterLvLook = {}
    for idx=1,monsterCnt do
		local monsterid,monsterlv = StreamPaser:read(2)
        pvpaccount_data.monsterLvLook[monsterid] = monsterlv
    end
    --creatureList
    local creatureCnt = StreamPaser:readInt()
    pvpaccount_data.creatureList = {}
    for idx=1,creatureCnt do
		local combineddata = StreamPaser:readInt()
		local pos = math.floor(combineddata / 1000)
		local id = combineddata % 1000
		pvpaccount_data.creatureList[pos] = id
    end
    --digTrace
	local blankCnt = StreamPaser:readInt()
    pvpaccount_data.holeDeep = blankCnt * 2
    pvpaccount_data.digTrace = {}
    for idx=1,blankCnt do
		local combinedpos = StreamPaser:readInt()
		local pos1 = math.floor(combinedpos / 1000)
		local pos2 = combinedpos % 1000
		if pos1 > 0 then
		    pvpaccount_data.digTrace[pos1] = 1
		end
		if pos2 > 0 then
			pvpaccount_data.digTrace[pos2] = 1
		end
    end
	
    pvpaccount_data.user = StreamPaser:readStr()
    AccountHelper:unlock(kStateSearchPvp)
end

--==========================
--395004 PVP结束后的帐户数据
--==========================
--stars:获得的星星数
--gold:金币增量
--oil:石油增量
--elo:elo增量
--teamBag:道具位置
--bag：道具数量
--==========================
_socketParser[395004] = function()
    AccountHelper:unlock(kStateBpResult)
    BPResult = getTableFromMsg()
    ------account_data更新项
	BPResult.gold = BPResult.gold or 0
	BPResult.oil = BPResult.oil or 0
	BPResult.iron = BPResult.iron or 0
	BPResult.copper = BPResult.copper or 0
	BPResult.stoneR = BPResult.stoneR or 0
	BPResult.stoneB = BPResult.stoneB or 0
	BPResult.stoneD = BPResult.stoneD or 0
	---------------
    account_data.gold = account_data.gold + BPResult.gold
    account_data.oil = account_data.oil + BPResult.oil
	--------------------------------------
	-----------------------------------矿石变动
	account_data.iron = account_data.iron + BPResult.iron
	account_data.copper = account_data.copper + BPResult.copper
	account_data.stoneR = account_data.stoneR + BPResult.stoneR
	account_data.stoneB = account_data.stoneB + BPResult.stoneB
	account_data.stoneD = account_data.stoneD + BPResult.stoneD
	----------------------------------
    account_data.elo = account_data.elo + BPResult.elo
    account_data.teamBag = BPResult.teamBag or account_data.teamBag
    account_data.bag = BPResult.bag or account_data.bag
    --更新PVP保护时间
    account_data.pvpGuardTime = os.time()
    account_data.pvpShellInterval=0
    --resumeShopItemRT()--恢复道具制造
end
--==========================
--398001 新建公会回复
--==========================
_socketParser[398001] = function(msglen,guid,opstate)
  --local issuccsed =RecvQueue:readInt()
  if opstate==0 then
	  ChatHelper.setNewCreated(true)
      SendMsg[938002]()
	  --挖掘日志任务进程更新,加入公会
	  task.updateTaskStatus(account_data,task.client_event_id.enter_guild)
	  ----------------------------------------------------------
      print ("sutup succesful")
  else
      print ("setup false")
      AccountHelper:unlock(kStateSetupGuild)
  end
end
--==========================
--398003 搜索公会 返回公会摘要
--==========================
--club_search :公会摘要信息表
--==========================
_socketParser[398003] = function (msglen,guid,opstate)
    local bytelen = msglen - 16
    if AccountHelper:isLocked(kStateGuildData) then --更新公会数据
        AccountHelper:unlock(kStateGuildData)
        local tb = {}
        tb = getTableFromMsg(bytelen)
        club_data.honor = tb.honor
        club_data.rank = tb.rank
        club_data.reward = tb.reward or 0 
        club_data.members = tb.members
        club_data.membersCount= tb.membersCount
    else --搜索公会
        if opstate == 0 then
            club_search = getTableFromMsg(bytelen)
        else
            club_search = nil
            print("search false")
        end
        AccountHelper:unlock(kStateSearch)
        if not club_search then print("search false") return end
        print("club_search:",table_aux.serial(club_search))
   end     
end
--==========================
--398002 公会数据
--==========================
--club_data:公会数据
--==========================
_socketParser[398002] = function(msglen,guid,opstate)
    local buteLen = msglen - 16
    --local cnt = RecvQueue:readInt()
   -- local msglen,msgcode,msgguid,opstate = RecvQueue:read(4)
    if opstate == 0 then
        club_data = getZipTableFromMsg(buteLen)
		--90为客户端自定义标记类型,标记创建公会成功的消息
		if ChatHelper.isNewCreated() then --是新创建的公会
			club_data.message[-1]={guid=-1,name=TxtList.systemCH,_mid=0,content=string.format(TxtList.guildMsg[5],club_data.clubName), type=90, date=os.time(),}
			table.insert(club_data.messageOrder,-1)
			ChatHelper.setHasInnerMsg(true)--客户端自定义标识,提示用
		elseif ChatHelper.isNewJoin() then
			club_data.message[-2]={guid=-1,name=club_data.manager,_mid=0,content=string.format(TxtList.guildMsg[7],club_data.clubName), type=90, date=os.time(),}
			table.insert(club_data.messageOrder,-2)
			ChatHelper.setHasInnerMsg(true) --客户端自定义标识,提示用
		else --检查是否有下线后发送过来的消息
            for idx = #club_data.messageOrder,1,-1 do
                local msgid = club_data.messageOrder[idx]
                if club_data.message[msgid].date > account_data.lastOffline then
                    ChatHelper.setHasInnerMsg(true) --客户端自定义标识,提示用
                    break
                end
            end
		end
		ChatHelper.setNewCreated(false)
		ChatHelper.setNowJoin(false)
        print("club_data:",table_aux.serial(club_data))
    else
        club_data = nil
        print("no join club")
    end
    AccountHelper:unlock(kStateClub)
end
--===========================
--398005 已加入公会回复
--===========================
_socketParser[398005] = function()
    local guid = RecvQueue:readInt()
	local digLvs = RecvQueue:readInt()
	local elos = RecvQueue:readInt()
	local names = RecvQueue:readStr()
	if guid == account_data.guid then
	    ChatHelper.setNowJoin(true)
		--挖掘日志任务进程更新,加入公会
		task.updateTaskStatus(account_data,task.client_event_id.enter_guild)
		----------------------------------------------------------
        SendMsg[938002]()
    else
   	    club_data.members[guid]={name = names,digLv = digLvs,elo = elos}
   	    club_data.membersCount = club_data.membersCount+1
    end
end

--===========================
--398008 会内聊天广播
--===========================
_socketParser[398008]= function(msglen)
    print("receve chat infomation")
    local userguid = RecvQueue:readInt()
    local mid = RecvQueue:readInt()
    local usermsg  = RecvQueue:readStr()
    club_data.message[mid]={guid=userguid, _mid=mid, content=usermsg, type=3, date=os.time(),}
    table.insert(club_data.messageOrder,mid)
	ChatHelper.setHasInnerMsg(true)
end
--==========================
--398009 被踢出公会
--==========================
_socketParser[398009] = function()
	ChatHelper.setHasInnerMsg(false)
	if club_data then
		ChatHelper.addNewMsg(0,0,TxtList.systemCH..TxtList.msg,0,"",string.format(TxtList.guildMsg[4],club_data.manager,club_data.clubName))
	end
    club_data = nil
end
--==========================
--398010 广播解散公会
--==========================
_socketParser[398010] = function()
	ChatHelper.setHasInnerMsg(false)
	if club_data then
		ChatHelper.addNewMsg(0,0,TxtList.systemCH..TxtList.msg,0,"",string.format(TxtList.guildMsg[8],club_data.manager,club_data.clubName))
	end
	club_data=nil
end

--==========================
--398004 广播申请加入公会
--==========================
_socketParser[398004] = function(msglen,guid)
    local byteLen = msglen - 16
    local tableTemp = getTableFromMsg(byteLen)
    print("message join guild:",table_aux.serial(tableTemp))
    club_data.message[tableTemp._mid]=tableTemp
    table.insert(club_data.messageOrder,tableTemp._mid)
	ChatHelper.setHasInnerMsg(true)
end
--===========================
--398012 全服公会排位数据
--===========================
_socketParser[398012] = function (msglen)
    --local bodylen = RecvQueue:readInt()
	--if bodylen > 0 then
		local leftTime = RecvQueue:readInt()
		account_data.honor_awardTime = os.time() + leftTime
		account_data.honor_rank = {}
		local byteLen = msglen - 20
		local srcBytes = RecvQueue:readUserData(byteLen)
		StreamPaser:init(srcBytes,byteLen)
		local cnt = StreamPaser:readInt()
		for idx=1,cnt do
			local tb = {}
			tb.cid,tb.elo,tb.jewel = StreamPaser:read(3)
			tb.name = StreamPaser:readStr()
			table.insert(account_data.honor_rank,tb)
		end
	--else
	--	account_data.honor_awardTime = os.time() + 24*3600
	--	account_data.honor_rank = {}
	--end
    AccountHelper:unlock(kStateHonorRank)
end
--==========================
 --398013 公会ELO奖励
 --==========================
_socketParser[398013] = function(msglen)
	account_data.jewel = account_data.jewel + RecvQueue:readInt()
end
--==========================
--398014 指定GUID帐号对应的公会信息摘要
--==========================
_socketParser[398014] = function (msglen,guid,opstate)
    local bytelen = msglen - 16
    if opstate == 0 then
        local club = getTableFromMsg(bytelen)
        if not club_cid then 
            club_cid={}
            club_cid[club.cid]=club 
        else
            club_cid[club.cid]=club    
        end
        club_cid[-1] = club --当前搜索的公会
        AccountHelper:unlock(kStateToViewGuild)
    else
        if not club_cid then club_cid={}end
        AccountHelper:unlock(kStateToViewGuild)
    end
end
--==========================
--990001 服务器断开连接
--==========================
_socketParser[990001] = function()
   if AccountHelper:isLocked(kStateDisConnected) then return end
   AccountHelper:lock(kStateDisConnected)
   local function callback()
		AccountHelper:unlock(kStateDisConnected)
		local scene = LogoScene.new()
		scene:egReplace()
    end
    local msglayer = MsgLayer.new(nil,TxtList.dataUnMatch,1,callback)
    msglayer:show()
end
--==========================
--990002 网络异常
--==========================
_socketParser[990002] = function()
	if AccountHelper:isLocked(kStateDisConnected) then return end
	AccountHelper:lock(kStateDisConnected)
    local function callback()
		AccountHelper:unlock(kStateDisConnected)
        local scene = LogoScene.new()
        scene:egReplace()
     end
    local msglayer = MsgLayer.new(nil,TxtList.netDown,1,callback)
    msglayer:show()
end


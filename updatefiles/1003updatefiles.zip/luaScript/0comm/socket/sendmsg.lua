SendMsg={}
SendMsg.digCache={}
--===========================
--���ھ�ͨѶ������������ʱ�����б�
--idx:    int    �ھ������λ��
--dp:    int    �ھ�������㼶
--===========================
function SendMsg.addDigMsg(idx,dp,gold,oil)
    table.insert(SendMsg.digCache,idx)
    table.insert(SendMsg.digCache,dp)
    table.insert(SendMsg.digCache,gold)
    table.insert(SendMsg.digCache,oil)
end

--===========================
--921001 ��½��Ϣ
--===========================
--account:    string ��½�ʺ�
--pwd:        string ��½����
--===========================
SendMsg[921001] = function(account,pwd)
    local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd
    SendQueue:lock()
    SendQueue:write(len_msg,921001,0,-1)
    SendQueue:writeStr(account,len_account)
    SendQueue:writeStr(pwd,len_pwd)
    SendQueue:unlock()
end
--===========================
--921002 ע��������Ϣ
--===========================
--account:    string ��½�ʺ�
--pwd:        string ��½����
--===========================
SendMsg[921002] = function(account,pwd)
    
    local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd
    SendQueue:lock()
    SendQueue:write(len_msg,921002,0,-1)
    SendQueue:writeStr(account,len_account)
    SendQueue:writeStr(pwd,len_pwd)
    SendQueue:unlock()
end
--===========================
--930000 ������Ϣ
--===========================
--===========================
SendMsg[930000] = function()
    SendQueue:lock()
    SendQueue:write(16,930000,guid,-1)
    SendQueue:unlock()
end
--===========================
--931001 ��ȡ�ʺ�����
--===========================
--account:    string ��½�ʺ�
--pwd:        string ��½����
--===========================
SendMsg[931001] = function(account,pwd)
    local len_account = #account
    local len_pwd = #pwd
    local len_msg = 18 + len_account + len_pwd
    SendQueue:lock()
    SendQueue:write(len_msg,931001,guid,-1)
    SendQueue:writeStr(account,len_account)
    SendQueue:writeStr(pwd,len_pwd)
    SendQueue:unlock()
end

--===========================
--931002 ��ȡ�ű��ļ�
--===========================

SendMsg[931002] = function()
    SendQueue:lock()
    SendQueue:write(16,931002,guid,-1)
    SendQueue:unlock()
end
--===========================
--931003 ����¼���б�
--===========================
SendMsg[931003] = function()
    SendQueue:lock()
	local lastvid = videomanager.getlastvid()
    SendQueue:write(20,931003,guid,-1,lastvid)
    SendQueue:unlock()
    --print("931003")
end
--===========================
--931004 ¼��طţ�����¼����Ϣ��ϸ
--===========================
--idx: ¼��ID
--===========================
SendMsg[931004] = function(idx)
    SendQueue:lock()
    SendQueue:write(20,931004,guid,-1,idx)
    SendQueue:unlock()
end
--===========================
--931005 ���������
--===========================
--sceneCode ��Ҫ�����������ҳ����
--itemId ������ID
--===========================
SendMsg[931005] = function(sceneCode,itemId)
    SendQueue:lock()
    SendQueue:write(24,931005,guid,-1,sceneCode,itemId)
    SendQueue:unlock()
end
--===========================
--931006 ��ȡELO����
--===========================
SendMsg[931006] = function()
    SendQueue:lock()
    SendQueue:write(16,931006,guid,-1)
    SendQueue:unlock()
end
--============================
--931008 ����Ƶ�����췢��
--============================
SendMsg[931008] = function (clubid,clubname,info)
    local len_info = #info
	local len_clubname = #clubname
    local len_msg = 22+len_info + len_clubname
    SendQueue:lock()
    SendQueue:write(len_msg,931008,guid,-1,clubid)
	SendQueue:writeStr(clubname,len_clubname)
    SendQueue:writeStr(info,len_info)
    SendQueue:unlock()
end
--============================
--931009 ��ѯĳ�ʺ�ժҪ����
--============================
SendMsg[931009] = function (user_guid)
    SendQueue:lock()
    SendQueue:write(20,931009,guid,-1,user_guid)
    SendQueue:unlock()
end
--============================
--931010 �޸��û��ǳ�
--============================
SendMsg[931010] = function (user_nickname)
	local len_nickname = #user_nickname
	local len_msg = 17+len_nickname
    SendQueue:lock()
    SendQueue:write(len_msg,931010,guid,-1)
	SendQueue:writeStr(user_nickname,len_nickname)
    SendQueue:unlock()
end
--===========================
--931011 �ʼ��콱
--===========================
SendMsg[931011] = function (msgid)
    SendQueue:lock()
    SendQueue:write(20,931011,guid,-1,msgid)
    SendQueue:unlock()
end
--===========================
--932001 �ھ���Ϣ
--===========================
--idx:    int    �ھ������λ��
--dp:    int    �ھ�������㼶
--===========================
SendMsg[932001] = function()
    local cnt = #SendMsg.digCache
    if cnt <=0 then return end
    local msglen = 16 + cnt*4
    SendQueue:lock()
    SendQueue:write(msglen,932001,guid,-1)
    for idx = 1,cnt,4 do
        SendQueue:write(SendMsg.digCache[idx],SendMsg.digCache[idx+1],SendMsg.digCache[idx+2],SendMsg.digCache[idx+3])
        --print(SendMsg.digCache[idx],SendMsg.digCache[idx+1])
    end
    SendQueue:unlock()
    SendMsg.digCache={}
end
--===========================
--932002 ���¿�
--===========================
SendMsg[932002] = function()
    SendMsg.digCache={}--���¿�ǰ������ھ�����е���Ϣ
    SendQueue:lock()
    SendQueue:write(16,932002,guid,-1)
    SendQueue:unlock()
end

--===========================
--932003 �޸Ĺ�����ʾλ��
--===========================
--monsterid:����ID
--oldpos:��ǰλ��
--newpos:Ŀ��λ��
--===========================
SendMsg[932003] = function(monsterid,oldpos,newpos)
    SendMsg[932001]() --����ǰ�ȴ����ھ�����е���Ϣ
    SendQueue:lock()
    SendQueue:write(28,932003,guid,-1,monsterid,oldpos,newpos)
    --print(28,932003,guid,-1,monsterid,oldpos,newpos)
    SendQueue:unlock()
end
--===========================
--932004 ��ʼִ������
--===========================
--lv:��ǰ
--tlv:Ŀ��ȼ�
--===========================
SendMsg[932004] = function(lv,tlv)
    SendQueue:lock()
    SendQueue:write(24,932004,guid,-1,lv,tlv)
    SendQueue:unlock()
end
--===========================
--932005 ִ���������
--===========================
--lv:��ǰ
--tlv:Ŀ��ȼ�
--===========================
SendMsg[932005] = function(lv,tlv)
    SendQueue:lock()
    SendQueue:write(24,932005,guid,-1,lv,tlv)
    SendQueue:unlock()
end
--===========================
--932006 �ƶ���
--===========================
--idx:�ɼ�����collectorList�е���������
--pos:Ŀ��λ��
--===========================
SendMsg[932006] = function(idx,pos)
    SendMsg[932001]() --����ǰ�ȴ����ھ�����е���Ϣ
    SendQueue:lock()
    SendQueue:write(24,932006,guid,-1,idx,pos)
    SendQueue:unlock()
    print(932006)
end
--===========================
--932007 �ɼ�����Դ
--===========================
--idx:�ɼ�����collectorList�е���������
--gain:����
--===========================
SendMsg[932007] = function(idx,gain)
    SendMsg[932001]() --����ǰ�ȴ����ھ�����е���Ϣ
    SendQueue:lock()
    SendQueue:write(24,932007,guid,-1,idx,gain)
    SendQueue:unlock()
    print(932007,idx,gain)
end
--===========================
--932008 ���ù�
--===========================
--monsterid:����ID
--pos:Ŀ��λ��
--===========================
SendMsg[932008] = function(monsterid,pos)
    SendMsg[932001]() --����ǰ�ȴ����ھ�����е���Ϣ
    SendQueue:lock()
    SendQueue:write(24,932008,guid,-1,monsterid,pos)
    SendQueue:unlock()
end
--===========================
--932009 �ջع�
--===========================
--monsterid:����ID
--pos:���ﵱǰλ��
--===========================
SendMsg[932009] = function(monsterid,pos)
    SendMsg[932001]() --����ǰ�ȴ����ھ�����е���Ϣ
    SendQueue:lock()
    SendQueue:write(24,932009,guid,-1,monsterid,pos)
    SendQueue:unlock()
end
--===========================
--933001 �������
--===========================
--itemid:��ƷID
--===========================
SendMsg[933001] = function(itemid)
    SendQueue:lock()
    SendQueue:write(20,933001,guid,-1,itemid)
    SendQueue:unlock()
	print("933001",itemid)
end
--===========================
--933002 �������
--===========================
--itemid:��ƷID
--===========================
SendMsg[933002] = function(itemid)
    SendQueue:lock()
    SendQueue:write(20,933002,guid,-1,itemid)
    SendQueue:unlock()
	print("933002",itemid)
end
--===========================
--933003 ȡ������
--===========================
--itemid:��ƷID
--===========================
SendMsg[933003] = function(itemid)
   SendQueue:lock()
   SendQueue:write(20,933003,guid,-1,itemid)
   SendQueue:unlock()
   print("933003",itemid)
end
--===========================
--933004 ��������
--===========================
SendMsg[933004] = function()
   SendQueue:lock()
   SendQueue:write(16,933004,guid,-1)
   SendQueue:unlock()
end

--===========================
--934001 ��ʼPVEս��
--===========================
SendMsg[934001] = function()
    SendQueue:lock()
    SendQueue:write(16,934001,guid,-1)
    SendQueue:unlock()
end

--===========================
--934002 ����PVEս���������
--===========================
--bp ս������
--===========================
SendMsg[934002] = function(bp)
	--[[
    local srcBytes = table_aux.serial(bp, true)
    local desBytes,deslen = HOGZip:compress(srcBytes,#srcBytes)
    local len_msg = 16 + deslen
    SendQueue:lock()
    SendQueue:write(len_msg,934002,guid,-1)
    SendQueue:writeUserData(desBytes,deslen)
    SendQueue:unlock()
	--]]
	
	local name2id = {gold=1, oil=2, iron=3, copper=4, stoneR=5, stoneB=6, stoneD=7}
	local res = {}
	for name, cnt in pairs(bp.gainRes) do
		local id = name2id[name]
		table.insert(res, id)
		table.insert(res, cnt)
	end

	local hmsg = {}
	for hid, cnt in pairs(bp.gainHeroMsg) do
		table.insert(hmsg, hid)
		table.insert(hmsg, cnt)
	end

	local rescnt = #res / 2
	local hmsgcnt = #hmsg / 2
	local msglen = 16 + 12 + 4 + rescnt * 8 + 4 + hmsgcnt * 8 

	SendQueue:lock()

	    SendQueue:write(msglen, 934002, guid, -1)
		SendQueue:write(bp.areaID, bp.stageID, #bp.collector)
		
		SendQueue:write(rescnt)
		for _, val in ipairs(res) do
			SendQueue:write(val)
		end

		SendQueue:write(hmsgcnt)
		for _, val in ipairs(hmsg) do
			SendQueue:write(val)
		end
    SendQueue:unlock()

end

--===========================
--934003 С�ӳ�Ա��Ϣ�޸�
--===========================
--team:С�ӳ�Ա��Ϣ
--===========================
SendMsg[934003] = function(team,captain)
    local itemcnt = #team + 1
    local len_msg = 16 + itemcnt*4
    SendQueue:lock()
    SendQueue:write(len_msg,934003,guid,-1)
    SendQueue:writeInt(captain)
    for key,val in ipairs(team) do
        SendQueue:writeInt(val)
    end
    SendQueue:unlock()
end
--===========================
--934004 �����ͼ���
--===========================
--areaid:����ID
--===========================
SendMsg[934004] = function(areaid)
    SendQueue:lock()
    SendQueue:write(20,934004,guid,-1,areaid)
    SendQueue:unlock()
end
--===========================
--934005 �����ļ�³�Ա
--===========================
--areaid:����ID
--===========================
SendMsg[934005] = function(heroid)
    SendQueue:lock()
    SendQueue:write(20,934005,guid,-1,heroid)
    SendQueue:unlock()
end
--===========================
--934006 �����Ϣ��̽
--=============================
--msglist: ��õ�Ӣ����Ϣ
--reslist: ��õ���Դ��Ϣ
--===========================
SendMsg[934006] = function(msglist,reslist)
	local msgcnt = #msglist
    local rescnt = #reslist
    local len_msg = 24 + (msgcnt + rescnt)*4
    SendQueue:lock()
    SendQueue:write(len_msg,934006,guid,-1,msgcnt/2)
    for idx = 1,msgcnt ,2 do
        SendQueue:writeInt(msglist[idx])
        SendQueue:writeInt(msglist[idx + 1])
    end
	SendQueue:writeInt(rescnt/2)
	for idx = 1,rescnt ,2 do
        SendQueue:writeInt(reslist[idx])
        SendQueue:writeInt(reslist[idx + 1])
    end
    SendQueue:unlock()
end
--===========================
--934007 ������Ϣ��̽
--=============================
--awardinfo: ��õ���Դ
--cost��֧���Ľ��
--===========================
SendMsg[934007] = function(cost,msglist,reslist)
    local msgcnt = #msglist
    local rescnt = #reslist
    local len_msg = 28 + (msgcnt + rescnt)*4
    SendQueue:lock()
    SendQueue:write(len_msg,934007,guid,-1,cost,msgcnt/2)
    for idx = 1,msgcnt ,2 do
        SendQueue:writeInt(msglist[idx])
        SendQueue:writeInt(msglist[idx + 1])
    end
	SendQueue:writeInt(rescnt/2)
	for idx = 1,rescnt ,2 do
        SendQueue:writeInt(reslist[idx])
        SendQueue:writeInt(reslist[idx + 1])
    end
    SendQueue:unlock()
end
--===========================
--934008 ���ѹ�Ӷ
--=============================
--cost: ֧����jewel��
--heroid:Ӣ��ID
--===========================
SendMsg[934008] = function(heroid,cost)
    SendQueue:lock()
    SendQueue:write(24,934008,guid,-1,heroid,cost)
    SendQueue:unlock()
end
--===========================
--934009 ����С����Դ
--=============================
--coinType:��Դ���� 1:gold 2:oil
--val:���յ���Դ����
--===========================
SendMsg[934009] = function(coinType,val)
    SendQueue:lock()
    SendQueue:write(24,934009,guid,-1,coinType,val)
    SendQueue:unlock()
end
--===========================
--934010 ׷�ӷ�������
--=============================
--dmId:���ӵ�����ID
--===========================
SendMsg[934010] = function(dmId)
    SendQueue:lock()
    SendQueue:write(20,934010,guid,-1,dmId)
    SendQueue:unlock()
end
--===========================
--934011 �����������
--=============================
--stars ��õ�������
--dmIdx �������������������е�����λ��
--===========================
SendMsg[934011] = function(stars,dmIdx)
   SendQueue:lock()
    SendQueue:write(24,934011,guid,-1,stars,dmIdx)
    SendQueue:unlock()
end
--===========================
--935001 ����PVP����
--===========================
SendMsg[935001] = function()
    SendQueue:lock()
    SendQueue:write(16,935001,guid,-1)
    SendQueue:unlock()
end

--===========================
--935002 ��ʼPVP����
--===========================
SendMsg[935002] = function()
    SendQueue:lock()
    SendQueue:write(16,935002,guid,-1)
    SendQueue:unlock()
end

--===========================
--935003 ����PVP����
--===========================
SendMsg[935003] = function()
    SendQueue:lock()
    SendQueue:write(16,935003,guid,-1)
    SendQueue:unlock()
end

--===========================
--935004 ����PVP����
--===========================
--battledata ս������
--===========================
SendMsg[935004] = function(battledata)
    --[[
    local battle_str = table_aux.serial(battledata, true)
    local battle_str_len = #battle_str
    local len_msg = 17 + battle_str_len
    SendQueue:lock()
    SendQueue:write(len_msg,935004,guid,-1)
    SendQueue:writeStr(battle_str,battle_str_len)
    SendQueue:unlock()
    --]]
    local srcBytes = table_aux.serial(battledata, true)
    local desBytes,deslen = HOGZip:compress(srcBytes,#srcBytes)
    local len_msg = 16 + deslen
    SendQueue:lock()
    SendQueue:write(len_msg,935004,guid,-1)
    SendQueue:writeUserData(desBytes,deslen)
    SendQueue:unlock()
end

--===========================
--935005 ����PVP��ȴ
--===========================
SendMsg[935005] = function()
   SendQueue:lock()
   SendQueue:write(16,935005,guid,-1)
   SendQueue:unlock()
end
--===========================
--936001 ��ʼ�о�
--===========================
--id:����ID
--lv:Ŀ��ȼ�
--===========================
SendMsg[936001] = function(id,lv)
    SendQueue:lock()
    SendQueue:write(24,936001,guid,-1,id,lv)
    SendQueue:unlock()
end

--===========================
--936002 �о�����
--===========================
--id:����ID
--lv:Ŀ��ȼ�
--===========================
SendMsg[936002] = function(id,lv)
    SendQueue:lock()
    SendQueue:write(24,936002,guid,-1,id,lv)
    SendQueue:unlock()
end

--===========================
--936003 ȡ���о�
--===========================
--id:����ID
--lv:Ŀ��ȼ�
--===========================
SendMsg[936003] = function(id,lv)
    SendQueue:lock()
    SendQueue:write(24,936003,guid,-1,id,lv)
    SendQueue:unlock()
end
--===========================
--936004 ��������
--===========================
--monsterid:����ID
--===========================
SendMsg[936004] = function(monsterid)
    SendQueue:lock()
    SendQueue:write(20,936004,guid,-1,monsterid)
    SendQueue:unlock()
end
--===========================
--936005 ��ʼѵ��
--===========================
--utype:��λ���� 1Ӣ�� 2��
--itemid:��λID 
--isJewel:�Ƿ����� 1�ǣ�0����
--isSucc:�Ƿ�ɹ� 1�ɹ� 0����
--===========================
SendMsg[936005] = function(utype,itemid,isJewel,isSucc)
    SendQueue:lock()
    SendQueue:write(32,936005,guid,-1,utype,itemid,isJewel,isSucc)
    SendQueue:unlock()
end
--===========================
--936006 ȡ��ѵ��
--===========================
SendMsg[936006] = function()
    SendQueue:lock()
    SendQueue:write(16,936006,guid,-1)
    SendQueue:unlock()
end
--===========================
--936007 ����ѵ��
--===========================
SendMsg[936007] = function()
    SendQueue:lock()
    SendQueue:write(16,936007,guid,-1)
    SendQueue:unlock()
end
--===========================
--936008 ѵ�����
--===========================
SendMsg[936008] = function()
    SendQueue:lock()
    SendQueue:write(16,936008,guid,-1)
    SendQueue:unlock()
end
--===========================
--937001 ������
--===========================
--posIdx:λ��ID
--id:����ID
--lv:Ŀ��ȼ�
--===========================
SendMsg[937001] = function(id)
    SendQueue:lock()
    SendQueue:write(20,937001,guid,-1,id)
    SendQueue:unlock()
end
--===========================
--937002 ��ʼ��������
--===========================
--id:����ID
--lv:Ŀ��ȼ�
--===========================
SendMsg[937002] = function(id,lv)
    SendQueue:lock()
    SendQueue:write(24,937002,guid,-1,id,lv)
    SendQueue:unlock()
end

--===========================
--937003 ������������
--===========================
--id:����ID
--lv:Ŀ��ȼ�
--===========================
SendMsg[937003] = function(id,lv)
    SendQueue:lock()
    SendQueue:write(24,937003,guid,-1,id,lv)
    SendQueue:unlock()
end
--===========================
--937004 ������������
--===========================
--trainID:����ID
--subTrainID:��������ID
--===========================
SendMsg[937004] = function(trainID,subTrainID)
    SendQueue:lock()
    SendQueue:write(24,937004,guid,-1,trainID,subTrainID)
    SendQueue:unlock()
end
--===========================
--938001 �����¹���
--===========================
--clubName:��������
--===========================
SendMsg[938001] = function(clubName,clubInfo)
   SendQueue:lock()
   local len_clubName = #clubName
   local len_clubInfo = #clubInfo
   local len_msg = 18+len_clubName+len_clubInfo
   SendQueue:write(len_msg,938001,guid,-1)
   SendQueue:writeStr(clubName,len_clubName)
   SendQueue:writeStr(clubInfo,len_clubInfo)
   SendQueue:unlock()
end  
--===========================
--938002 ���󹫻�����
--===========================
SendMsg[938002] = function()
    SendQueue:lock()
    SendQueue:write(16,938002,guid,-1)
    SendQueue:unlock()
end    
--===========================
--938003 ���ҹ���ժҪ
--===========================
--clubname Ҫ���ҹ�������
--===========================
SendMsg[938003] = function(clubname)
    local len_name = #clubname
    local len_msg = 17+len_name
    SendQueue:lock()
    SendQueue:write(len_msg,938003,guid,-1)
    SendQueue:writeStr(clubname,len_name)
    SendQueue:unlock()
end   

--===========================
--938004 ������빫��
--===========================
--cid Ŀ�깫��id
--===========================
SendMsg[938004] = function(cid)
    SendQueue:lock()
    SendQueue:write(20,938004,guid,-1,cid)
    SendQueue:unlock()
end
--============================
--938005 ͬ����빫��
--============================
--mid ��Ϣid
--============================
SendMsg[938005] = function(mid,state)
    SendQueue:lock()
    SendQueue:write(24,938005,guid,-1,mid,state)
    SendQueue:unlock()
end
--============================
--938006 �뿪����
--============================
SendMsg[938006] = function()
    SendQueue:lock()
    SendQueue:write(16,938006,guid,-1)
    SendQueue:unlock()
end
--============================
--938008 ���췢��
--============================
SendMsg[938008] = function (info)
    local len_info = #info
    local len_msg = 17+len_info
    SendQueue:lock()
    SendQueue:write(len_msg,938008,guid,-1)
    SendQueue:writeStr(info,len_info)
    SendQueue:unlock()
end
--============================
--938009 ɾ����Ա
--============================
--guids ��ɾ����Ա��guid
--============================
SendMsg[938009] = function(guids)
    SendQueue:lock()
    SendQueue:write(20,938009,guid,-1,guids)
    SendQueue:unlock()
end
--=============================
--938010 ��ɢ����
--=============================
SendMsg[938010] = function()
    SendQueue:lock()
    SendQueue:write(16,938010,guid,-1)
    SendQueue:unlock()
end
--=============================
--938012 ��ȡȫ��������λ
--=============================
SendMsg[938012] = function()
    SendQueue:lock()
    SendQueue:write(16,938012,guid,-1)
    SendQueue:unlock()
end
--=============================
--938013 ��ȡ�����ڲ�����
--=============================
SendMsg[938013] = function()
    SendQueue:lock()
    SendQueue:write(16,938013,guid,-1)
    SendQueue:unlock()
end
--============================
--938014 ��ѯĳ�ʺ������ֻ�ժҪ��Ϣ
--============================
SendMsg[938014] = function (user_guid)
    SendQueue:lock()
    SendQueue:write(20,938014,guid,-1,user_guid)
    SendQueue:unlock()
end
--=============================
--939001 ����װ��
--heroId Ӣ��ID
--equipId װ��ID
--=============================
SendMsg[939001]=function(heroId,equipId)
	SendQueue:lock()
    SendQueue:write(24,939001,guid,-1,heroId,equipId)
    SendQueue:unlock()
end
--=============================
--939002 װ������
--equipId װ��ID
--=============================
SendMsg[939002]=function(equipId)
	SendQueue:lock()
    SendQueue:write(20,939002,guid,-1,equipId)
    SendQueue:unlock()
end
--=============================
--939003 װ��Ʒ������
--equipId װ��ID
--=============================
SendMsg[939003]=function(equipId)
	SendQueue:lock()
    SendQueue:write(20,939003,guid,-1,equipId)
    SendQueue:unlock()
end
--=============================
--9310001 ˢ���ھ���־�����б�
--=============================
SendMsg[9310001]=function()
	SendQueue:lock()
    SendQueue:write(16,9310001,guid,-1)
    SendQueue:unlock()
end
--=============================
--9310002 �����ھ���־����
--=============================
SendMsg[9310002]=function(tidList,paramList)
	local itemcnt = #tidList
	if not paramList then paramList = {} end
	local paramcnt =  #paramList
    local len_msg = 24 + (itemcnt + paramcnt)*4
    SendQueue:lock()
    SendQueue:write(len_msg,9310002,guid,-1,paramcnt)
	for key,val in ipairs(paramList) do
		SendQueue:writeInt(val)
	end
	SendQueue:writeInt(itemcnt)
    for key,val in ipairs(tidList) do
        SendQueue:writeInt(val)
    end
    SendQueue:unlock()
end
--=============================
--9310003 ��ȡ����
--=============================
SendMsg[9310003]=function(tid)
    SendQueue:lock()
    SendQueue:write(20,9310003,guid,-1,tid)
    SendQueue:unlock()
end


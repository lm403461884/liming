

function createMonster(mtype,lv,idx)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local monster = Monster.new(mtype,lv,idx)
    creaturelayer:createMonster(monster)
    return monster
end
function createSubMonster(mtype,lv,idx)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local monster = Monster.new(mtype,lv,idx)
    creaturelayer:insertSubMonster(monster)
    return monster
end

function createHero(prop,idx)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local hero = Hero.new(prop,idx)
    creaturelayer:insertHero(hero)
    return hero
end

function createBullet(mtype,lv,idx)
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    local bullet = Bullet.new(mtype,lv,idx)
    creaturelayer:insertBullet(bullet)
    return bullet
end
--����ս���������Ӷ���,δ����������ʱ������NULL
function createBox(birthIdx,deadIdx)
    local holelayer = AccountHelper:get(kHoleLayer)
    local boxlayer = holelayer._boxlayer
	boxlayer:createBox(birthIdx,deadIdx)
end

--ʹ�ô���
function useHeroSkill(heroObj)
	local deflayer = AccountHelper:get(kDefLayer)
	deflayer:doUseHeroSkill(heroObj)
end
function getBPHeroList()
	local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
	return creaturelayer:getHeros()
end

function getViewLayer()
	local holelayer = AccountHelper:get(kHoleLayer)
	local viewlayer = holelayer._viewlayer	
	return viewlayer:egNode()
end

--AI�Ϳ�������
ObjLook={}
function ObjLook.removeObj(obj)
    if obj == nil then return end
    local maintype = obj:getprop("mainType")
    local holelayer = AccountHelper:get(kHoleLayer)
    local creaturelayer = holelayer._creaturelayer
    if maintype == 2 then
        creaturelayer:removeMonster(obj)
    elseif maintype == 1 then
        creaturelayer:removeHero(obj)
    elseif maintype == 3 then
        creaturelayer:removeBullet(obj)
    elseif maintype == 4 then
        creaturelayer:removeResCar(obj)
    end
end

function addView(idx,r)

	local holelayer = AccountHelper:get(kHoleLayer)
	local viewlayer = holelayer._viewlayer
	viewlayer:showViewInVision(idx,r)
end

function getTime()
    return os.time()*1000 + HOAux:getMSec()
end


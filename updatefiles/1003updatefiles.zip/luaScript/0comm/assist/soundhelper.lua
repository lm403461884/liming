SoundHelper = {}
local BGM = nil
function SoundHelper.playBGM(filename)
    if BGM ~= filename then
        BGM = filename
        AudioEngine.playMusic(BGM, true)
        --print("BGM switch to "..filename)
    end
end
function SoundHelper.playBGMOnce(filename)
    if BGM ~= filename then
        BGM = filename
        AudioEngine.playMusic(BGM, false)
        --print("BGM switch to "..filename)
    end
end
function SoundHelper.playEffect(filename)
    AudioEngine.playEffect(filename, false)
    --print("Effect played  "..filename)
end
function SoundHelper.preLoadEffect(filename)
    AudioEngine.preloadEffect(filename)
end
function SoundHelper.unloadEffect(filename)
	AudioEngine.unloadEffect(filename)
end
local __touchdelegate={}

function __touchdelegate.egBindTouchEvent(obj,touchbegan,touchmoved,touchend,touchcanceled,priority,swallow)
    local function onTouch(eventType, x,y)
        if eventType == "began" then
            if touchbegan then return touchbegan( x,y) end
            return true
        elseif eventType == "moved" then
            if touchmoved then  touchmoved( x,y) end
        elseif eventType == "ended" then
            if touchend then touchend( x,y) end
        else
            if touchcanceled then touchcanceled(x,y) end
        end
    end
    local _priority = priority or 0
    local _swallow = swallow
    obj._egObj:registerScriptTouchHandler(onTouch,false,_priority,_swallow)
    obj._egObj:setTouchEnabled(true)
end

function __touchdelegate.egBindTouchesEvent(obj,touchesbegan,touchesmoved,touchesend,touchescanceled,priority,swallow)
    local function onTouches(eventType, touches)
        if eventType == "began" then
            if touchesbegan then touchesbegan(touches) end
        elseif eventType == "moved" then
            if touchesmoved then touchesmoved(touches) end
        elseif eventType =="ended" then
            if touchesend then touchesend(touches) end
        else
             if touchescanceled then touchescanceled(touches)end
        end
    end
    local _priority = priority or 0
    local _swallow = swallow
    obj._egObj:registerScriptTouchHandler(onTouches,true,_priority,_swallow)
    obj._egObj:setTouchEnabled(true)
end
--�������TOUCH�¼���͸
--priority: touch�¼���Ӧ���ȼ�
function __touchdelegate.swallowTouch(obj,priority)
    local function onTouch(eventType, x,y)
        if eventType == "began" then return true end
    end
    obj._egObj:setTouchEnabled(true)
    obj._egObj:registerScriptTouchHandler(onTouch,false,priority ,true)
end
function __touchdelegate.egSetTouchPriority(obj,priority)
    obj._egObj:setTouchPriority(priority)
end
function __touchdelegate.egGetTouchPriority(obj)
   return obj._egObj:getTouchPriority()
end

TouchDelegate={}
function TouchDelegate.install(obj)
    for name, func in pairs(__touchdelegate) do
        obj[name] = func
    end
end
local kMaxScrollSpeed = 1000
local kMinScrollSpeed = 200
local kAcceleration = -1000  --���ٶ�
local kTouchBegan = 0
local kTouchMoved = 1
local kTouchEnd =2
local kTouchCanceled = 3
local visibleSize = CCDirector:sharedDirector():getVisibleSize()
local origin = CCDirector:sharedDirector():getVisibleOrigin()
local __view={}
--[[ ʹ��ʾ��
   local view =  LuaScrollView.new() 
   view:setBoundRect(CCRectMake(0,0,1280,720)) 
   view:setMoveDir(ccp(1,0)) --ˮƽ�ƶ�
   view:setSize(CCSizeMake(2048,720))
--]]
function __view.init(obj)
    obj._m_distance = 0
    obj._m_dir = ccp(0,0)
    obj._scroll_dir = ccp(1,1) --���������ķ���
    obj._pressed = false -- ����Ƿ���
    obj._autoScroll = false --����Ƿ��Զ�����
    obj._slideTime = 0
    obj._originalSpeed = 0
    obj._autoScrolledTime = 0
    obj._preMovePt = ccp(0,0)
    
    obj._hasDes = false
    obj._offsetX = 0
    obj._offsetY = 0
    obj._movedX = 0
    obj._movedY = 0
    obj._usedTime = 0
    obj._des_dir = nil
    obj._des_speed = 0
	obj._frameid = 0
    obj._boundRect = CCRectMake(origin.x,origin.y,visibleSize.width,visibleSize.height)
end
function __view.activeUpdate(obj)
    local function update(delta)
        if obj._hasDes then
            obj:doScrollToDes(delta)
        else
            if obj._pressed then obj._slideTime = obj._slideTime + delta end --������¼����ʱ��
            if obj._autoScroll then
                obj:doAutoScroll(delta)
            end
         end
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  obj._egObj:unscheduleUpdate() end
    end
    obj._egObj:scheduleUpdateWithPriorityLua(update, 0)
    obj._egObj:registerScriptHandler(exitFuns)
end
function __view.activeTouch(obj)
    local function callbackFuns(sender, eventType)
        if eventType == kTouchBegan then
           return obj:onInnerTouchBegan()
        elseif eventType == kTouchMoved then
            obj:onInnerTouchMoved()
        elseif eventType == kTouchEnd then
            obj:onInnerTouchEnd()
        elseif eventType == kTouchCanceled then
             obj:onInnerTouchCancelled()
        end
    end
    obj._egObj:setTouchEnabled(true)
    obj._egObj:addTouchEventListener(callbackFuns)
end
function __view.onInnerTouchBegan(obj)
    obj._pressed = true
    obj._preMovePt = obj._egObj:getTouchStartPos()
    obj:stopAutoScroll()
    if obj._beganCallBack then return obj._beganCallBack() end
    return true
end
function __view.onInnerTouchMoved(obj)
    local beganPt = obj._preMovePt
    local movePt = obj._egObj:getTouchMovePos() 
    local offsetx = movePt.x - beganPt.x
    local offsety = movePt.y - beganPt.y
    offsetx = offsetx * obj._scroll_dir.x
    offsety = offsety * obj._scroll_dir.y
    local scale = obj._egObj:getScale()
    local point = obj:getValidMovePoint(offsetx,offsety,scale)
    local actOffsetX = point.x - obj._egObj:getPositionX()
    local actOffsetY = point.y - obj._egObj:getPositionY()
    obj._egObj:setPosition(point)
    obj._preMovePt = ccp(movePt.x,movePt.y)
    if obj._moveCallBack then obj._moveCallBack(actOffsetX,actOffsetY) end
end
function __view.getValidMovePoint(obj,offsetx,offsety,scale)
    local x = obj._egObj:getPositionX() + offsetx
    local y = obj._egObj:getPositionY() + offsety
    local anchor = obj._egObj:getAnchorPoint()
    local size = obj._egObj:getSize()
    local left = x - anchor.x * size.width * scale
    local right =  x + size.width * scale *(1-anchor.x)
    local bottom = y - anchor.y * size.height* scale
    local top = y + size.height* scale *(1- anchor.y)
    local outerSize = obj._boundRect.size
    local origin = obj._boundRect.origin
    if left > origin.x then  x = anchor.x * size.width * scale + origin.x  end
    if right < outerSize.width + origin.x then x = outerSize.width + origin.x - size.width * scale *(1-anchor.x) end
    if bottom >origin.y then y = anchor.y * size.height* scale + origin.y end
    if top < outerSize.height + origin.y then y = outerSize.height + origin.y - size.height* scale *(1- anchor.y) end
    return ccp(x,y)
end
function __view.onInnerTouchEnd(obj,touches)
    if obj._slideTime > 0.016 then 
        local beganPt = obj._egObj:getTouchStartPos()
        local endPoint = obj._egObj:getTouchEndPos()
        obj:startAutoScroll(beganPt,endPoint,obj._slideTime)
    end
    if  obj._endCallBack then  obj._endCallBack() end
end
function __view.onInnerTouchCancelled(obj,touches)
    obj._pressed = false
    obj._beganPts = {}
    obj._m_distance = 0
    obj._m_dir = ccp(0,0)
    if obj._cancelCallBack then obj._cancelCallBack() end
end
function __view.getMoveDir(obj,startPt,endPt)
    local offsetx = endPt.x - startPt.x
    local offsety = endPt.y - startPt.y
    local dir = ccpNormalize(ccp(offsetx,offsety))
    dir.x = dir.x * obj._scroll_dir.x
    dir.y = dir.y*obj._scroll_dir.y
    return dir
end

function __view.startAutoScroll(obj,oldpoint,newpoint,duration)
    obj._m_distance = ccpDistance(newpoint,oldpoint)/obj._egObj:getScale() --�����ƶ�����
    obj._m_dir = obj:getMoveDir(oldpoint,newpoint) --�����ƶ�����
    obj._originalSpeed  = math.min(obj._m_distance/duration,kMaxScrollSpeed)--�����ƶ��ٶ�
    obj._autoScroll = true
    obj._autoScrolledTime = 0
    obj._slideTime = 0
end
function __view.stopAutoScroll(obj)
    obj._autoScroll = false
    obj._autoScrolledTime = 0
    obj._slideTime = 0
    obj._originalSpeed = 0
    obj._m_dir = ccp(0,0)
    obj._m_distance = 0
end
function __view.doAutoScroll(obj,dt)
    local curSpeed = obj._originalSpeed  + kAcceleration * obj._autoScrolledTime
    if curSpeed > 0 then
        local timeParam = obj._autoScrolledTime * 2 + dt
        local offset = (obj._originalSpeed + kAcceleration * timeParam * 0.5) * dt
        local offsetx = offset * obj._m_dir.x
        local offsety = offset * obj._m_dir.y
        local point = obj:getValidMovePoint(offsetx,offsety,obj._egObj:getScale())
        local actOffsetX = point.x - obj._egObj:getPositionX()
        local actOffsetY = point.y - obj._egObj:getPositionY()
        obj._egObj:setPosition(point)
        obj._autoScrolledTime = obj._autoScrolledTime + dt
        if actOffsetX == 0 and actOffsetY==0 then obj:stopAutoScroll() end
        if obj._moveCallBack then obj._moveCallBack(actOffsetX,actOffsetY) end
    else
        obj:stopAutoScroll()
    end
end
function __view.startScrollToDes(obj,offsetx,offsety)
    obj._hasDes = true
    obj._offsetX = offsetx*obj._scroll_dir.x
    obj._offsetY = offsety*obj._scroll_dir.y
    obj._des_dir = ccpNormalize(ccp(obj._offsetX,obj._offsetY))
    obj._movedX = 0
    obj._movedY = 0
    obj._usedTime = 0
    obj._des_speed = kMaxScrollSpeed*2 --math.max(math.abs(ccpLength(ccp(obj._offsetX,obj._offsetY)))*2,kMaxScrollSpeed)
    obj._egObj:setTouchEnabled(false)
end
function __view.stopScrollToDes(obj)
    obj._hasDes = false
    obj._des_dir = ccp(0,0)
    obj._offsetX = 0
    obj._offsetY = 0
    obj._movedX = 0
    obj._movedY = 0
    obj._usedTime = 0
    obj._des_speed = 0
    obj._egObj:setTouchEnabled(true)
    if obj._arriveDesCallback then 
        obj._arriveDesCallback() 
        obj._arriveDesCallback = nil 
    end
end
function __view.doScrollToDes(obj,dt)
    if obj._frameid < 1 then dt = 0.016 end
	obj._frameid = obj._frameid+1
    local curSpeed = obj._des_speed  + kAcceleration*2 * obj._usedTime
    --print(curSpeed)
    local offset = kMinScrollSpeed * dt
    if curSpeed > kMinScrollSpeed then
       -- local curspeed = math.min(obj._des_speed + kMaxScrollSpeed*obj._usedTime,kMaxScrollSpeed)
       local timeParam = obj._usedTime * 2 + dt
       -- local offset = (obj._des_speed + kMaxScrollSpeed/2 * timeParam * 0.5)*dt
       offset = (obj._des_speed + kAcceleration*2 * timeParam * 0.5)*dt
    end
    local offsetx = offset * obj._des_dir.x
    local offsety = offset * obj._des_dir.y
    local tmpx = obj._movedX + offsetx
    local tmpy = obj._movedY + offsety
    obj._usedTime = obj._usedTime + dt
    if math.abs(tmpx) >= math.abs(obj._offsetX) then 
        tmpx = obj._offsetX
        offsetx = obj._offsetX - obj._movedX
    end
    if math.abs(tmpy) >= math.abs(obj._offsetY) then
        tmpy = obj._offsetY
        offsety = obj._offsetY - obj._movedY
    end
    obj._movedX = tmpx
    obj._movedY = tmpy
    
    local point = obj:getValidMovePoint(offsetx,offsety,obj._egObj:getScale())
    local actOffsetX = point.x - obj._egObj:getPositionX()
    local actOffsetY = point.y - obj._egObj:getPositionY()
    obj._egObj:setPosition(point)
    if obj._moveCallBack then obj._moveCallBack(actOffsetX,actOffsetY) end
    if actOffsetX == 0 and actOffsetY==0 then obj:stopScrollToDes() end
    if math.abs(obj._movedX) >= math.abs(obj._offsetX) and math.abs(obj._movedY) >= math.abs(obj._offsetY) then
        obj:stopScrollToDes()
    end
end
function __view.scrollBy(obj,offsetx,offsety,scrollBegan,scrollEnd)
    obj:stopAutoScroll()
    obj:stopScrollToDes()
    if scrollBegan then scrollBegan() end
    obj._arriveDesCallback = scrollEnd
    obj:startScrollToDes(offsetx,offsety)
end
--�����ƶ����� (1,0) ˮƽ,(0,1)��ֱ,(1,1) ˫��
function __view.setMoveDir(obj,dir)
    obj._scroll_dir = dir
end
--�����ƶ���Χ
function __view.setBoundRect(obj,rect)
    obj._boundRect = rect
end
function __view.setSize(obj,size)
    obj._egObj:setSize(size)
end
function __view.onTouchBegan(obj,callback)
    obj._beganCallBack = callback
end
function __view.onTouchMoved(obj,callback)
    obj._moveCallBack = callback
end
function __view.onTouchEnded(obj,callback)
    obj._endCallBack = callback
end
function __view.onTouchCancelled(obj,callback)
    obj._cancelCallBack = callback
end

LuaScrollView={}
function LuaScrollView.new() 
    local obj = {}
    obj._egObj = Layout:create()
    obj._egObj:setAnchorPoint(ccp(0,0))
    CocosNode.install(obj)
    table_aux.unpackTo(__view, obj)
    obj:init()
    obj:activeTouch()
    obj:activeUpdate()
    return obj
end
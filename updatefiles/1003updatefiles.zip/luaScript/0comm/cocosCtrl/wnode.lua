WNode={}

local kTouchBegan = 0
local kTouchMoved = 1
local kTouchEnd =2
local kTouchCanceled = 3
local __wnode = {}
function __wnode.egSetWidgetScale(obj,widgetName,scale)
    local widget = obj:egGetWidgetByName(widgetName)
    if not widget then return  end
    widget:setScale(scale)
end
function __wnode.egGetScaleOf(obj,widgetName)
    local widget = obj:egGetWidgetByName(widgetName)
    if not widget then return  end
   return widget:getScale()
end
function __wnode.egGetSizeOf(obj,widgetName)
    local widget = obj:egGetWidgetByName(widgetName)
    if widget then return widget:getSize() end
    return nil
end
function __wnode.egAddChildTo(obj,widgetName,child,zorder,tag)
    local widget = obj:egGetWidgetByName(widgetName)
    if widget then 
        if not zorder or not tag then
            widget:addChild(child)
        else
            widget:addChild(child,zorder,tag)
        end
    end
end
function __wnode.egSetFocused(obj,widgetName,focused)
     local widget = obj:egGetWidgetByName(widgetName)
     if not widget then return end
     widget:setFocused(focused)
end
function __wnode.egSetOpacityOf(obj,widgetname,opacity)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    widget:setOpacity(opacity)
end
function __wnode.egGetOpacityOf(obj,widgetname,opacity)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    return widget:getOpacity()
end
function __wnode.egFadeOut(obj,widgetname,sec,callback)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local function callbackfunc()
        if callback then callback() end
    end
    local callFunc = CCCallFunc:create(callbackfunc)
    local fadeto = CCFadeTo:create(sec,0)
    local action = CCSequence:createWithTwoActions(fadeto,callFunc )
    widget:setOpacity(255)
    widget:setVisible(true)
    widget:runAction(action)
end

function __wnode.egFadeIn(obj,widgetname,sec,callback)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local function callbackfunc()
        if callback then callback() end
    end
    local callFunc = CCCallFunc:create(callbackfunc)
    local fadeto = CCFadeTo:create(sec,255)
    local action = CCSequence:createWithTwoActions(fadeto,callFunc )
    widget:setOpacity(0)
    widget:setVisible(true)
    widget:runAction(action)
end
function __wnode.egProgressFromTo(obj,widgetname,sec,from,to,onRuning,onEnd)
    if sec < 0 then return end
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local bar = tolua.cast(widget,"LoadingBar")
    local curper = from
    local startTime = os.time()
    local markTime = startTime
    local passedTime = 0
    local computeTime = 0
     local per = (to-from)/sec
    if math.abs(per) < 1 then per =(to-from)/math.abs(from-to) end
    bar:setPercent(from)
    local function update(delta)
      local ptime = os.time() - markTime
      if ptime >= 1 then
          markTime = os.time()
          passedTime = passedTime + ptime
          computeTime = computeTime + ptime
          if math.abs(computeTime* 100 / sec) >= math.abs(per) then
            computeTime = 0
            curper = curper + per
            bar:setPercent(curper )
          end
          if onRuning then onRuning(sec-passedTime, curPer) end
       end
       if passedTime == sec then  
            bar:unscheduleUpdate() 
            if onEnd then onEnd() end
       end
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  bar:unscheduleUpdate() end
    end
    bar:scheduleUpdateWithPriorityLua(update, 0)
    bar:registerScriptHandler(exitFuns)
end
function __wnode.egBindTouch(obj,widgetName,began,moved,ended,canceled)
   local function callbackFuns(sender, eventType)
        if eventType == kTouchBegan then
            if began then  began(sender) end
        elseif eventType == kTouchMoved then
             if moved then  moved(sender) end
        elseif eventType == kTouchEnd then
             if ended then ended(sender) end
        elseif eventType == kTouchCanceled then
             if canceled then canceled(sender) end
        end
    end
    local widget = obj._widget 
    if  widgetName then widget = obj:egGetWidgetByName(widgetName) end
    if not widget then return end
    widget:addTouchEventListener(callbackFuns)
end
function __wnode.egBindWidgetUpdate(obj,widgetName,callback)
    local widget = obj:egGetWidgetByName(widgetName)
    if not widget then return end
    local function update(delta)
        if callback then callback(delta) end
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  widget:unscheduleUpdate() end
    end
    widget:scheduleUpdateWithPriorityLua(update, 0)
    widget:registerScriptHandler(exitFuns)
end
function __wnode.egUnbindWidgetUpdate(obj,widgetName)
    local widget = obj:egGetWidgetByName(widgetName)
    if not widget then return end
    widget:unscheduleUpdate()
end
function __wnode.egSetWidgetTouchEnabled(obj,widgetName,enabled)
    local widget = obj:egGetWidgetByName(widgetName)
    if not widget then return end
    widget:setTouchEnabled(enabled)
end
function __wnode.egGetScrollView(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return nil end
    local scrollview = tolua.cast(widget,"ScrollView")
    return scrollview
end
function __wnode.egGetListView(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return nil end
    local listview = tolua.cast(widget,"ListView")
    return listview
end
function __wnode.egGetTextFieldVal(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local textbox = tolua.cast(widget,"TextField")
    return textbox:getStringValue()
end
function __wnode.egGetLabelStr(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local lbl = tolua.cast(widget,"Label")
    return lbl:getStringValue()
end
function __wnode.egGetBMLabelStr(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local lbl = tolua.cast(widget,"LabelBMFont")
    return lbl:getStringValue()
end
function __wnode.egSetLabelStr(obj,widgetname,str)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local lbl = tolua.cast(widget,"Label")
    lbl:setText(str)
end
function __wnode.egSetBMLabelStr(obj,widgetname,str)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local lbl = tolua.cast(widget,"LabelBMFont")
    lbl:setText(str)
end
function __wnode.egSetBtnStr(obj,widgetname,str)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local lbl = tolua.cast(widget,"Button")
    lbl:setTitleText(str)
end
function __wnode.egSetWidgetColor(obj,widgetname,color)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    widget:setColor(color)
end
--restype: UI_TEX_TYPE_LOCAL, UI_TEX_TYPE_PLIST
function __wnode.egChangeImg(obj,widgetname,imgsrc,restype)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local img = tolua.cast(widget,"ImageView")
    if not restype then
        img:loadTexture(imgsrc)
    else
         img:loadTexture(imgsrc,restype)
    end
end
--更新Layout背景图片
function __wnode.egChangeBgImg(obj,widgetname,imgsrc,restype)
	local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local img = tolua.cast(widget,"Layout")
    if not restype then restype = UI_TEX_TYPE_LOCAL end
    img:setBackGroundImage(imgsrc,restype)
end
--在指定范围内平铺加载图片
function __wnode.egRepeatWidgetImg(obj,widgetName,w,h,imgsrc)
    local widget = obj:egGetWidgetByName(widgetName)
    local img = tolua.cast(widget,"ImageView")
    if imgsrc then img:loadTexture(imgsrc) end
    local params = ccTexParams:new()
    params.minFilter = GL_LINEAR
    params.magFilter = GL_LINEAR
    params.wrapS = GL_REPEAT
    params.wrapT = GL_REPEAT
    local sprite =  tolua.cast(img:getVirtualRenderer(),"CCSprite")
    sprite:getTexture():setTexParameters(params)
    img:setTextureRect(CCRectMake(0, 0, w, h))
end
function __wnode.egSetImgFlipX(obj,widgetname,flipx)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local img = tolua.cast(widget,"ImageView")
    img:setFlipX(flipx)
end
function __wnode.egChangeBtnImg(obj,widgetname,normalSrc,pressedSrc,disabledSrc,restype)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local btn = tolua.cast(widget,"Button")
    if not restype then
        if normalSrc then  btn:loadTextureNormal(normalSrc) end
        if pressedSrc then  btn:loadTexturePressed(pressedSrc) end
        if disabledSrc then  btn:loadTextureDisabled(disabledSrc) end
    else
        if normalSrc then  btn:loadTextureNormal(normalSrc,restype) end
        if pressedSrc then  btn:loadTexturePressed(pressedSrc,restype) end
        if disabledSrc then  btn:loadTextureDisabled(disabledSrc,restype) end
    end
end
function __wnode.egSetBarPercent(obj,widgetname,percent)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local bar = tolua.cast(widget,"LoadingBar")
    bar:setPercent(percent)
end
function __wnode.egGetBarPercent(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    local bar = tolua.cast(widget,"LoadingBar")
   return bar:getPercent()
end
function __wnode.egSetWidgetEnabled(obj,widgetname,enabled)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    widget:setEnabled(enabled)
end
function __wnode.egShowWidget(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    widget:setVisible(true)
    widget:setEnabled(true)
end
function __wnode.egEnabledWidget(obj,widgetname,enabled)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    widget:setEnabled(enabled)
end
function __wnode.egHideWidget(obj,widgetname)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    widget:setEnabled(false)
    widget:setVisible(false)
end
function __wnode.egSetWidgetMargin(obj,widgetname,layouttype,left,top,right,bottom)
    local widget = obj:egGetWidgetByName(widgetname)
    if not widget then return end
    if not left then left = 0 end
    if not top then top = 0 end
    if not right then right = 0 end
    if not bottom then bottom = 0 end
    local layoutparameter = widget:getLayoutParameter(layouttype)
    layoutparameter:setMarginTo(left,top,right,bottom)
    widget:setLayoutParameter(layoutparameter)
end
function WNode.install(obj)
    table_aux.unpackTo(__wnode, obj) 
end
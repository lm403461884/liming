local kPaneInvite = "invite_panel"
local kPanelHire = "buy_panel"
local kBtnInvite = "btn_invite"
local kBtnHire = "btn_buy"
local kImgReady = "img_light_border"
local kImgPhoto = "btn_photo"
local kImgEquip = "img_equip"
local kLblName = "lbl_name"
local kLblMsgNum = "lbl_msg_num"
local kBlackColor = ccc3(0,0,0)
local kGrayColor = ccc3(32,32,32)
local __pubhero={}

function __pubhero.init(obj,heroid)
    obj:addprop("heroid",heroid)
    obj._heroid = heroid
    obj._msgnum = account_data.heroInfoList[obj._heroid] or 0
    local s_cfg =  hero_data.getConfig(obj._heroid)
    
    obj:egChangeBtnImg(kImgPhoto,s_cfg.photo,"","",UI_TEX_TYPE_PLIST)
    local equipid = obj._heroid*100+1
    obj:egChangeImg(kImgEquip,equipCfg[equipid].icon,UI_TEX_TYPE_PLIST)
    obj:egHideWidget(kPaneInvite)
    obj:egHideWidget(kBtnInvite)
    obj:egShowWidget(kPanelHire)
    obj:egShowWidget(kBtnHire)
    if obj._msgnum == 0 then
        obj:egSetLabelStr(kLblName, "???")
        obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/??",TxtList.msg,obj._msgnum))
        obj:egSetWidgetColor(kImgPhoto,kGrayColor)
        obj:egSetWidgetColor(kImgEquip,kBlackColor)
        obj:egSetWidgetTouchEnabled(kImgPhoto,false)
        obj:egSetWidgetEnabled(kBtnHire,false)
    else
        obj:egSetLabelStr(kLblName, s_cfg.heroName)
        obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,math.min(obj._msgnum,s_cfg.infoCnt),s_cfg.infoCnt))
        if obj._msgnum >= s_cfg.infoCnt then
            obj:egShowWidget(kPaneInvite)
            obj:egShowWidget(kBtnInvite)
            obj:egHideWidget(kPanelHire)
            obj:egHideWidget(kBtnHire)
            local imgborder = obj:egGetWidgetByName(kImgReady)
            local fadeout = CCFadeTo:create(1,64)
            local fadein = CCFadeTo:create(1,255)
            local sequence = CCSequence:createWithTwoActions(fadeout,fadein)
            local repeatever = CCRepeatForever:create(sequence)
            imgborder:runAction(repeatever)
        end    
   end 
end
--��ʾ�߿��£Ч��
function __pubhero.showInviteState(obj)
    obj:egHideWidget(kPanelHire)
    obj:egHideWidget(kBtnHire)
    obj:egShowWidget(kPaneInvite)
    obj:egShowWidget(kBtnInvite)
    obj:egSetWidgetTouchEnabled(kBtnHire,false)
    obj:egSetWidgetTouchEnabled(kBtnInvite,false)
    local imgborder = obj:egGetWidgetByName(kImgReady)
    imgborder:setScale(1.3)
    imgborder:setOpacity(0)
    local fadeout1 = CCFadeIn:create(0.5)
    local scaleto1 = CCScaleTo:create(0.5,1)
    local spawn = CCSpawn:createWithTwoActions(fadeout1,scaleto1)
    local function callback()
        obj:egSetWidgetTouchEnabled(kBtnInvite,true)
        local fadeout = CCFadeTo:create(1,64)
        local fadein = CCFadeTo:create(1,255)
        local sequence = CCSequence:createWithTwoActions(fadeout,fadein)
        local repeatever = CCRepeatForever:create(sequence)
        imgborder:runAction(repeatever)
    end
    local callfunc = CCCallFunc:create(callback)
    
    local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
    imgborder:runAction(sequence)
end
function __pubhero.updateHeroMsg(obj)
    obj._msgnum = account_data.heroInfoList[obj._heroid] or 0
    local s_cfg =  hero_data.getConfig(obj._heroid)
    obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,obj._msgnum,s_cfg.infoCnt))
    if obj._msgnum >= s_cfg.infoCnt then
        obj:showInviteState()
    end    
end
function __pubhero.unlockHeroInfo(obj)
    local photo = obj:egGetWidgetByName(kImgPhoto)
    local equip = obj:egGetWidgetByName(kImgEquip)
    photo:runAction(CCTintTo:create(0.3,255,255,255))
    equip:runAction(CCTintTo:create(0.3,255,255,255))
    obj._msgnum = account_data.heroInfoList[obj._heroid] or 0
    local s_cfg =  hero_data.getConfig(obj._heroid)
    obj:egSetLabelStr(kLblName, s_cfg.heroName)
    obj:egSetLabelStr(kLblMsgNum,string.format("%s:%02d/%02d",TxtList.msg,obj._msgnum,s_cfg.infoCnt))
    obj:egSetWidgetTouchEnabled(kImgPhoto,true)
    obj:egSetWidgetEnabled(kBtnHire,true)
    if obj._msgnum >= s_cfg.infoCnt then
        obj:showInviteState()
    end    
end
function __pubhero.onHired(obj,callback)
    obj._hireCallback = callback
end
function __pubhero.onInvited(obj,callback)
    obj._inviteCallback = callback
end
--�鿴��Ϣ��ϸ
function __pubhero.bindCardListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
        --����Ϣͨ��Ԥ��ҳ��
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgPhoto,nil,nil,touchEnded,touchCanceled)
end
--�����ļ
function __pubhero.bindInviteListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.buy_hero_01)
        if obj._inviteCallback then obj._inviteCallback(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnInvite,nil,nil,touchEnded,touchCanceled)
end
--����ؽ��Ӷ
function __pubhero.bindHireListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        local s_cfg = hero_data.getConfig(obj._heroid)
        local msgNum = account_data.heroInfoList[obj._heroid] or 0
        local cost = baseCalc.getMsgforHero(msgNum,s_cfg.infoCnt)
        if cost > account_data.jewel then
            showPopCharge(cost,function()sender:setTouchEnabled(true) end)
        else
            if obj._hireCallback then obj._hireCallback(obj) end
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnHire,nil,nil,touchEnded,touchCanceled)
end
function __pubhero.enabledHireBtn(obj)
    obj:egSetWidgetTouchEnabled(kBtnHire,true)
end
PubHero={}
function PubHero.new(heroid)
    local obj = {}
    CocosWidget.install(obj,JsonList.pubHero)
    table_aux.unpackTo(__pubhero, obj)
    BaseProp.install(obj)
    InnerProp.install(obj)
    obj:init(heroid)
    obj:bindCardListener()
    obj:bindInviteListener()
    obj:bindHireListener()
    return obj
end


local kPanelInfo = "panel_info"
local kImgHero = "img_hero"
local kLblTitle = "lbl_hero_title"
local kLblName = "lbl_hero_name"
local kLblIntro = "lbl_hero_intro"
local kLblInviteInfo = "lbl_invite_info"
local kLblLv = "lbl_lv"
local kLblInfo = "lbl_info"
local kLblInviteVal = "lbl_invite_val"
local kLblAtkcap = "lbl_atkcap"
local kLblAtkVal = "lbl_atkcap_val"
local kLblHp = "lbl_hp"
local kLblHpVal = "lbl_hp_val"
local kLblConsume = "lbl_consume"
local kLblConVal = "lbl_consume_val"
local kImgMapBg = "map_bg"
local kBtnBack = "but_back"
local kPropX= 105
local kPropY = 93

local __heroinfo={}
function __heroinfo.init(obj,heroid)
    obj._heroid = heroid
    obj._lv,obj._eid = obj:getHeroLv(heroid)
    obj._invited = true --�Ƿ�����ļ
    if not obj._lv then
        obj._invited = false
        obj._lv = 1      
    end 
    local s_cfg = hero_data.getConfig(obj._heroid)
    local s_data = hero_data.get(obj._heroid,obj._lv)
    if obj._invited then
        obj:egHideWidget(kLblInfo)
        obj:egHideWidget(kLblInviteVal)
        local equiplv,equipqa =  equipFuncs.getEquipQL(obj._eid,account_data) 
		local equiprop = equipFuncs.getData(obj._eid,equiplv)
        obj:egSetLabelStr(kLblInviteInfo,TxtList.invited)
        obj:egShowWidget(kLblLv)
        obj:egSetLabelStr(kLblLv,string.format("LV.%d",obj._lv))  
        --��ʾ�ӳɺ�Ĺ�����������ֵ
        obj:egShowWidget(kLblAtkcap)
        obj:egShowWidget(kLblHp)
        obj:egShowWidget(kLblConsume)
		obj:egSetLabelStr(kLblAtkVal,s_data.power + equiprop.power) 
        obj:egSetLabelStr(kLblHpVal,s_data.maxHP+equiprop.maxHP)
        obj:egSetLabelStr(kLblConVal,s_data.consume)
    else
        obj:egHideWidget(kLblAtkcap)
        obj:egHideWidget(kLblHp)
        obj:egHideWidget(kLblConsume)
        obj:egHideWidget(kLblLv)
        local inviteval = account_data.heroInfoList[heroid]
        if inviteval > s_cfg.infoCnt then inviteval = s_cfg.infoCnt end
        obj:egSetLabelStr(kLblInviteVal,string.format("%d/%d",inviteval,s_cfg.infoCnt))
    end
    
    obj:egSetLabelStr(kLblName,s_cfg.heroName)
    obj:egSetLabelStr(kLblTitle,s_cfg.profession)
    --obj:egSetLabelStr(kLblIntro,string.format("%s%s",TxtList.charIntro,s_cfg.info))
    obj:egSetLabelStr(kLblIntro,string.format("%s%s","    ",s_cfg.info))
    obj:egChangeImg(kImgHero,s_cfg.photo,UI_TEX_TYPE_PLIST)
    --local imghero = tolua.cast(obj:egGetWidgetByName(kImgHero),"ImageView")
    --imghero:setFlipX(true)
    obj:initPropMap()
end
function __heroinfo.initPropMap(obj)
    local s_data = hero_data.get(obj._heroid,obj._lv)
    obj._drawNode = CCDrawNode:create()
    local cos18 = math.cos(18/180*math.pi)
    local sin18 =  math.sin(18/180*math.pi)
    local cos54 = math.cos(54/180*math.pi)
    local sin54 = math.sin(54/180*math.pi)
    local atk = s_data.charATK
    local hp = s_data.charHP
    local cost = s_data.charCost
    local speed = s_data.charSpeed
    local vision = s_data.charVision
    local p1 = ccp(0,atk) --atk
    local p2 = ccp(cos18*cost,sin18*cost) --cost
    local p3 = ccp(cos54*speed,-sin54*speed) -- speed
    local p4 = ccp(-cos54*vision,-sin54*vision) --vision
    local p5 = ccp(-cos18*hp,sin18*hp) --hp
    obj._drawNode:drawPolygon(ccc4f(0.46,0.6,0.62,0.8), 1, ccc4f(0.46,0.6,0.62,0.8),p1,p2,p3,p4,p5)
    local mapbg = tolua.cast(obj:egGetWidgetByName(kImgMapBg),"ImageView")
    local node = mapbg:getVirtualRenderer()
    node:addChild(obj._drawNode)
    obj._drawNode:setPosition(ccp(kPropX,kPropY))
end

function __heroinfo.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelInfo)
    widget:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveTo:create(0.3,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end
function __heroinfo.showPropWithAction(obj)
    obj._drawNode:setScale(0)
    obj._drawNode:runAction(CCScaleTo:create(0.5,1))
end
function __heroinfo.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
function __heroinfo.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelInfo,nil,nil,touchEnded,touchCanceled)
end
function __heroinfo.getHeroLv(obj,heroid)
    for _,item in ipairs(account_data.heroList) do
        if item.type == heroid then
            return item.lv, item.eid
        end
    end
    return nil
end
HeroInfo={}
function HeroInfo.new(heroid)
    local obj = TouchWidget.new(JsonList.heroInfo)
    table_aux.unpackTo(__heroinfo, obj)
    obj:init(heroid)
    obj:bindBackListener()
    obj:bindPanelListener()
    return obj
end
function ShowHeroInfo(heroid,callback)
    local layer = HeroInfo.new(heroid)
    local scene = CCDirector:sharedDirector():getRunningScene()
	scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction(callback)    
end

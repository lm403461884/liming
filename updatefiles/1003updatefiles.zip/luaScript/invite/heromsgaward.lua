local kImgPhoto = "btn_photo"
local kLblName = "lbl_name"
local kLblMsgNum = "lbl_msg_num"
local kImgBg = "img_card_bg"
local kSx = 640
local kSy = 430
local __heromsgaward={}

function __heromsgaward.init(obj,heroid,msgnum)
    obj._heroid = heroid
    local s_cfg =  hero_data.getConfig(obj._heroid)
    obj:egChangeBtnImg(kImgPhoto,s_cfg.photo,"","",UI_TEX_TYPE_PLIST)
	obj:egSetLabelStr(kLblName, s_cfg.heroName)
	obj:egSetLabelStr(kLblMsgNum,Funs.signedNum(msgnum)) 
end
function __heromsgaward.scaleAndShow(obj,callbackfunc)
	obj:scaleAndShowWithSrc(kSx,kSy,callbackfunc)
end
function __heromsgaward.scaleAndShowWithSrc(obj,srcx,srcy,callbackfunc)
	local widget = obj:egGetWidgetByName(kImgBg)
	local x = obj:egNode():getPositionX()
	local oldx = widget:getPositionX()
	local oldy = widget:getPositionY()
	local sx = srcx - x
	widget:setPosition(ccp(sx,srcy))
	local scaleto = CCScaleTo:create(0.2,1.5)
	local moveto = CCMoveTo:create(0.2,ccp(oldx,oldy))
	local array = CCArray:create()
	array:addObject(scaleto)
	array:addObject(moveto)
	local spawn = CCSpawn:create(array)
	local function callback()
	    callbackfunc()
	end
	local callfunc = CCCallFunc:create(callback)
	local scaleto1 = CCScaleTo:create(0.1,1)
	--local bouceout = CCEaseBounceOut:create(scaleto1)
	local delay = CCDelayTime:create(0.3)
	local array1 = CCArray:create()
	array1:addObject(spawn)
	array1:addObject(scaleto1)
	array1:addObject(delay)
	array1:addObject(callfunc)
	local sequence = CCSequence:create(array1)
	widget:runAction(sequence)
end
--�鿴��Ϣ��ϸ
function __heromsgaward.bindCardListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
        --����Ϣͨ��Ԥ��ҳ��
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kImgPhoto,nil,nil,touchEnded,touchCanceled)
end

HeroMsgAward={}
function HeroMsgAward.new(heroid,msgnum)
    local obj = {}
    CocosWidget.install(obj,JsonList.heroMsgAward)
    table_aux.unpackTo(__heromsgaward, obj)
    obj:init(heroid,msgnum)
    obj:bindCardListener()
    return obj
end


local kEquipOrder = 0
local __equipscene={}
function __equipscene.init(obj)
    obj._equipLayer = EquipLayer.new()
    obj._equipLayer:egAttachTo(obj,kEquipOrder,kEquipOrder)
    
end
EquipScene={}
function EquipScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__equipscene, obj)
    obj:init()
    
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
	showEmDialog(obj,GuideScene.def.kequipScene) --����������
    return obj
end
local kLblTrainLv = "lbl_train_lv"
local kListview = "listview"
local kBtnBack = "btn_return"
local kPanelInfo = "panel_info"
local kPanelUpdate = "panel_update"
--------------------------icon
local kLblIron = "lbl_iron"
local kLblCopper = "lbl_copper"
local kLblStoneR = "lbl_stoneR"
local kLblStoneB = "lbl_stoneB"
local kLblStoneD = "lbl_stoneD"
local kLblGold = "own_gold_val"
local kLblJewel = "own_jewel_val"
local kBarGold = "own_gold_bar"
local kImgIconBg = "img_icon_bg"
---------------װ����Ϣ
local kLblEquipName = "lbl_equip_name"
local kLblSkillName = "lbl_skill_name"
local kLblAtk = "lbl_atk_num"
local kLblHP = "lbl_hp_num"
local kImgEquip = "img_equip_show"
local kBtnArm = "btn_arm"
local kImgLv = "img_lv_show"
local kLblLv = "lbl_lv_show"
local kLblHPUp="lbl_hp_up"
local kLblAtkUp="lbl_atk_up"
local kImgMaskBg = "img_mask_bg"
local kImgMaskBar = "img_mask_bar"
--------------------װ������
local kItemList = "item_list"
local kLblNotice = "lbl_notice"
local kBtnLvup = "btn_lvup"
local kBtnUpgrade = "btn_upgrade"
local kRedColor = ccc3(255,0,0)
local kBrownColor = ccc3(83,49,22)

local kMaxMetal = 9999
local kMaxStone = 999


local __equiplayer={}
--��ʽ�����
local function __getBouncedNum(val,maxVal)
	if val > maxVal then
		return string.format("%d%s",maxVal,"+")
	end
	return string.format("%d",val)
end
local function __getAddVal(old,new)
	local val = new-old
	if val > 0 then
		val = math.ceil(val/20)
	else
		val = math.floor(val/20)
	end
	return val
end
function __equiplayer.init(obj)
   obj._d_data = account_data
   obj._trainLv = account_data.train[train.def.equip].lv
   obj:egSetLabelStr(kLblTrainLv,string.format("LV %d",obj._trainLv))
   obj._selectedEquip =nil --ѡ�е�װ��
   --Ǯ�ҡ���ʯ
   obj:loadIcon()
   --����Ӣ��
   obj:loadHero()
end
-----------------Ӣ������
function __equiplayer.getOrderHeroList(obj)
    local tb={}
    for key,herodata in ipairs(obj._d_data.heroList) do
        if not obj:isTeamMember(herodata.type) then
            table.insert(tb,herodata)
        else
            table.insert(tb,1,herodata)
        end
    end
    return tb
end
function __equiplayer.isTeamMember(obj,heroid)
    for key,val in ipairs(obj._d_data.team) do
        if val == heroid then return key end
    end
    return nil
end
------------������Դ
function __equiplayer.loadIcon(obj)	
	obj._iron = obj._d_data.iron
    obj._copper = obj._d_data.copper
    obj._stoneR = obj._d_data.stoneR
    obj._stoneB = obj._d_data.stoneB
    obj._stoneD = obj._d_data.stoneD
    obj._gold = obj._d_data.gold
    obj._jewel = obj._d_data.jewel
    obj._maxGold = obj._d_data.maxGold
     
    obj:egSetBMLabelStr(kLblGold,Funs.formatNum(obj._gold))
    obj:egSetBarPercent(kBarGold,obj._gold*100/obj._maxGold)
    obj:egSetBMLabelStr(kLblJewel,Funs.formatNum(obj._jewel))
	obj:egSetBMLabelStr(kLblIron,__getBouncedNum(obj._iron,kMaxMetal))
	obj:egSetBMLabelStr(kLblCopper,__getBouncedNum(obj._copper,kMaxMetal))
	
	obj:egSetBMLabelStr(kLblStoneR,__getBouncedNum(obj._stoneR,kMaxStone))
	obj:egSetBMLabelStr(kLblStoneB,__getBouncedNum(obj._stoneB,kMaxStone))
	obj:egSetBMLabelStr(kLblStoneD,__getBouncedNum(obj._stoneD,kMaxStone))
end
-------------��ҡ���ʯ��������
--�޸Ŀ�ʯ��ֵ
function __equiplayer.refreshResVal(obj,paramName,coinName,widgetName,maxVal)
    local matched = false
    if obj[paramName] ~=obj._d_data[coinName] then
        obj[paramName] = obj[paramName]+__getAddVal(obj[paramName],obj._d_data[coinName])
        if obj[paramName] > maxVal and obj._d_data[coinName]<=maxVal then obj[paramName]=maxVal 
        elseif obj[paramName] >= maxVal and obj._d_data[coinName]>maxVal then obj[paramName] = obj._d_data[coinName]end
        obj:egSetBMLabelStr(widgetName,__getBouncedNum(obj[paramName],maxVal))
    else
        matched = true
    end
    return matched
end
--���¿�ʯ��ֵ
function __equiplayer.iconUpdate(obj)
    local gold = false
    local jewel = false
    local iron = false
    local copper = false
    local stoneR = false
    local stoneB = false
    local stoneD = false
    local function updateFunc()
        if obj._jewel ~= obj._d_data.jewel then
            obj._jewel =   obj._jewel + __getAddVal(obj._jewel,obj._d_data.jewel)
            obj:egSetBMLabelStr(kLblJewel,Funs.formatNum(obj._jewel))
        else
            jewel = true    
        end
        if obj._gold ~= obj._d_data.gold then
            obj._gold = obj._gold + __getAddVal(obj._gold,obj._d_data.gold)
            obj:egSetBMLabelStr(kLblGold,Funs.formatNum(obj._gold))
            obj:egSetBarPercent(kBarGold,obj._gold*100/obj._maxGold)
        else
            gold = true    
        end
		iron = obj:refreshResVal("_iron","iron",kLblIron,kMaxMetal)
		copper = obj:refreshResVal("_copper","copper",kLblCopper,kMaxMetal)
		stoneR = obj:refreshResVal("_stoneR","stoneR",kLblStoneR,kMaxMetal)
		stoneB = obj:refreshResVal("_stoneB","stoneB",kLblStoneB,kMaxMetal)
		stoneD = obj:refreshResVal("_stoneD","stoneD",kLblStoneD,kMaxMetal)
        if jewel and gold and iron and copper and stoneR and stoneB and stoneD then
            obj:egUnbindWidgetUpdate(kImgIconBg)
        end
    end
    obj:egBindWidgetUpdate(kImgIconBg,updateFunc)
end
--����Ӣ��
function __equiplayer.loadHero(obj)
    obj._hero={}
    local listview = obj:egGetListView(kListview)
    local heroList = obj:getOrderHeroList()
    for _,item in ipairs (heroList) do
        local heroid = item.type
        local heroItem = EquipHeroItem.new(heroid)
        listview:pushBackCustomItem(heroItem:egNode())  
        obj._hero[heroid]=heroItem
        obj:loadEquip(item) 
    end
end
--�л�ѡ��װ��
function __equiplayer.changeSelecteEquip(obj,equipItem)
    
    if obj._selectedEquip ~= equipItem then 
        if obj._selectedEquip then
            obj._selectedEquip:setSelected(false)
        end
         local equipid = equipItem:getprop("eid")
        obj:loadEquipInfo(equipid)
        obj:loadEquipLvUp(equipid)
        obj._selectedEquip = equipItem
    end
    obj._selectedEquip:setSelected(true)
end
--------------����װ��
function __equiplayer.loadEquip(obj,heroprop)
    for eid,item in pairs(obj._d_data.equipments) do
        local beforeId = equipFuncs.getHeroID(eid) 
        if beforeId == heroprop.type then
            local equipItem = EquipItem.new(eid)
            -----��װ������ص��¼�
            equipItem:onClicked(function(sender) obj:changeSelecteEquip(sender) end)
            local memberItem = obj._hero[ heroprop.type ]
            memberItem:addEquip(equipItem)
            if not obj._selectedEquip and eid== heroprop.eid then 
                obj:changeSelecteEquip(equipItem)
            end 
        end
    end    
end
--------------����װ����Ϣ
function __equiplayer.loadEquipInfo(obj,equipid)
    local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
    local heroid = equipFuncs.getHeroID(equipid)
    local heroprop = obj:getHeroProp(heroid)
    local s_cfg = equipCfg[equipid]
    local armedequip = heroprop.eid --��ǰװ��������ID
    
    local equiprop = equipFuncs.getData(equipid,curlv)
    ----------------------
    obj:egSetLabelStr(kLblEquipName,s_cfg.name)
    obj:egChangeImg(kImgEquip,s_cfg.icon,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblSkillName,s_cfg.skillName)
    
    obj:egSetLabelStr(kLblAtk,Funs.signedNum(equiprop.power))
    obj:egSetLabelStr(kLblHP,Funs.signedNum(equiprop.maxHP))
    obj:egSetWidgetColor(kImgMaskBg,KVariantList.equipColor[curqa])
	obj:egSetWidgetColor(kImgMaskBar,KVariantList.equipColor[curqa])
    obj:egSetBMLabelStr(kLblLv,curlv)
    obj:egHideWidget(kLblHPUp)
    obj:egHideWidget(kLblAtkUp)
    obj:egHideWidget(kImgMaskBg)
    obj:egHideWidget(kImgMaskBar)
    if equipid == armedequip then
        obj:egSetWidgetEnabled(kBtnArm,false)
    else
        obj:egSetWidgetEnabled(true)
    end
end
function __equiplayer.showAndHideProp(obj,widgetName,s1,s2,callbackfunc)
    local lbl = obj:egGetWidgetByName(widgetName)
    lbl:setVisible(true)
    lbl:setOpacity(255)
    local delay = CCDelayTime:create(s1)
    local fadeout = CCFadeOut:create(s2)
    local function callback()
         lbl:setVisible(false)
         if callbackfunc then callbackfunc() end
    end
    local ccallfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(delay)
    array:addObject(fadeout)
    array:addObject(ccallfunc)
    local sequence = CCSequence:create(array)
    lbl:runAction(sequence)
end
--��ʾ�ȼ��䶯��������
function __equiplayer.showLvUpBGAction(obj,widgetName,opacity)
    local widget = obj:egGetWidgetByName(widgetName)
    widget:setOpacity(0)
    widget:setVisible(true)
    widget:setEnabled(true)
    widget:setScale(1.2)
    local fadeto1 = CCFadeTo:create(0.6,opacity)
    local scaleto1 = CCScaleTo:create(0.6,1)
    local spawn1 = CCSpawn:createWithTwoActions(fadeto1,scaleto1)
    local fadeto2 = CCFadeTo:create(0.4,0)
    local callfunc = CCCallFunc:create( function()  widget:setVisible(false) end)
    local array = CCArray:create()
    array:addObject(spawn1)
    array:addObject(fadeto2)
    array:addObject(callfunc)
    widget:runAction(CCSequence:create(array))
end
function __equiplayer.showLvUpItemAction(obj)
    local widget = obj:egGetWidgetByName(kImgEquip)
    local scaleto1 = CCScaleTo:create(0.6,1.1)
    local scaleto2 = CCScaleTo:create(0.4,1)
    local backout = CCEaseBackOut:create(scaleto2)
    local squence=CCSequence:createWithTwoActions(scaleto1,backout)
    widget:runAction(squence)
end
function __equiplayer.showLvUpAction(obj,curlv)
    local lvwidget = obj:egGetWidgetByName(kImgLv) 
    lvwidget:setVisible(false)  
    obj:egSetBMLabelStr(kLblLv,curlv)
    lvwidget:setScale(5)
    local delay = CCDelayTime:create(0.6)
    local callfunc1 = CCCallFunc:create(function()  lvwidget:setVisible(true)   end)
    local scale = CCScaleTo:create(0.4,1)
    local backout = CCEaseBackOut:create(scale)
    local callfunc2 = CCCallFunc:create(function() obj:egSetWidgetTouchEnabled(kBtnLvup,true) end)
    local array = CCArray:create()
    array:addObject(delay)
    array:addObject(callfunc1)
    array:addObject(backout)
    array:addObject(callfunc2)
    lvwidget:runAction(CCSequence:create(array))
end
--��ʾ�豸������Ϣ
function __equiplayer.updateEquipInfo(obj,equipid)
    local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
    local oldlv = curlv -1
    local heroid = equipFuncs.getHeroID(equipid)
    local s_cfg = equipCfg[equipid]
    local oldprop = equipFuncs.getData(equipid,oldlv)
    local newprop = equipFuncs.getData(equipid,curlv)
    obj:egSetLabelStr(kLblHPUp,Funs.signedNum(newprop.maxHP-oldprop.maxHP)) 
    obj:egSetLabelStr(kLblAtkUp,Funs.signedNum(newprop.power-oldprop.power)) 
    --��ʾ���Եȼ��仯
    obj:showAndHideProp(kLblHPUp,0.8,0.2,function()  obj:egSetLabelStr(kLblHP,Funs.signedNum(newprop.maxHP)) end)
    obj:showAndHideProp(kLblAtkUp,0.8,0.2,function()  obj:egSetLabelStr(kLblAtk,Funs.signedNum(newprop.power)) end)
    obj:showLvUpAction(curlv)
    obj:showLvUpBGAction(kImgMaskBg,150)
    obj:showLvUpBGAction(kImgMaskBar,255)
    obj:showLvUpItemAction()
end
-------------����������Ϣ
function __equiplayer.loadEquipLvUp(obj,equipid)
    local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
    local heroid = equipFuncs.getHeroID(equipid)
     local heroprop = obj:getHeroProp(heroid)
    local lvupdata = equipFuncs.getData(equipid,curlv)
    
	obj:egSetWidgetEnabled(kBtnUpgrade, math.floor(curlv* numDef.weaponQaFactor) > curqa )
	obj._lvupEnabled = true
	local maxlv = obj._trainLv * numDef.weaponLvFactor --��ȡ��ǰ����ȼ���Ӧ����������ȼ�
	if curlv <maxlv and equipFuncs.getData(equipid,curlv+1) then --���п������ռ�
		obj:egHideWidget(kLblNotice)
        obj:egShowWidget(kItemList)

        obj:loadNeedsProp(lvupdata) --��������������Դ,ͬʱ�ж��Ƿ��������
        obj:egSetWidgetEnabled(kBtnLvup,obj._lvupEnabled)
	else --û�п������Ŀռ�
		obj:egHideWidget(kItemList)
        obj:egShowWidget(kLblNotice)
        obj:egSetWidgetEnabled(kBtnLvup,false)
	end 
end
--��������������Դ
function __equiplayer.loadNeedsProp(obj,lvupdata)
    local listlayer = obj:egGetWidgetByName(kItemList)
	local cnt = listlayer:getChildrenCount()
    for idx=1,cnt do
        listlayer:removeChildByTag(idx,true)
    end
	local itemcnt = 0
    for cointype,val in pairs( lvupdata.cost) do
        local ownnum = account_data[cointype]
        local showNum = val
        if cointype ~= "gold" then
            local hasval = ownnum
            if ownnum > val then hasval = val end
            showNum = string.format("%d/%d",hasval,val)
        end
        local item = ImgPropItem.new(cointype,showNum)
        if val > ownnum then
            item:setTxtColor(kRedColor)
            obj._lvupEnabled = false
        end
		itemcnt = itemcnt +1
        listlayer:addChild(item:egNode(),0,itemcnt)
    end
end
--���ذ�ť����¼�
function __equiplayer.doClickBack(obj,sender)
        sender:setTouchEnabled(false)
        local scene = TownScene.new()
        scene:egReplace()
end

--���ذ�ť
function __equiplayer.bindBackListener(obj)
   
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickBack(sender)
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
--"װ��"��ť����¼�
function __equiplayer.doClickArm(obj,sender)
        if not obj._selectedEquip then return end
        sender:setTouchEnabled(false)
        local eid = obj._selectedEquip:getprop("eid") --ѡ�е�eid
        local heroid = equipFuncs.getHeroID(eid)
        SendMsg[939001](heroid,eid)
        obj._hero[heroid]:changeEquip(eid) 
        obj:loadEquipInfo(eid) 
        sender:setTouchEnabled(true)
end
--------------��װ������ť�ص�����
function __equiplayer.bindArmListener(obj)
    
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickArm(sender)
    end
	local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnArm,nil,nil,touchEnded,touchCanceled)  
end
--������ť����¼�
function __equiplayer.doClickLvUp(obj,sender)
        sender:setTouchEnabled(false)
         local equipid = obj._selectedEquip:getprop("eid") --ѡ�е�eid
         local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
        local lvupdata = equipFuncs.getData(equipid,curlv)
        for cointype,val in pairs (lvupdata.cost) do
            account_data[cointype]=account_data[cointype]-val
        end
        account_data.equipments[equipid][1]=account_data.equipments[equipid][1]+1
        SendMsg[939002](equipid)
		--�ھ���־�������
		task.updateTaskStatus(account_data,task.client_event_id.equit_update,{equipid,curlv+1})
		----------------------------------------------------------
        obj:iconUpdate() --����UI��ʾ
        obj:loadEquipLvUp(equipid)
        obj:updateEquipInfo(equipid)
        obj._selectedEquip:setEquipID(equipid)
		SoundHelper.playEffect(SoundList.update_equip)
end

-----------------װ������
function __equiplayer.bindLvUpListener(obj)
   
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickLvUp(sender)
    end
	 local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
    end
    obj:egBindTouch(kBtnLvup,nil,nil,touchEnded,touchCanceled)  
	
end
function __equiplayer.bindUpgradeListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		local equipid = obj._selectedEquip:getprop("eid") --ѡ�е�eid
		local function qaChangedCallBack()
			local curlv,curqa = equipFuncs.getEquipQL(equipid, account_data)
			obj:egSetWidgetColor(kImgMaskBg,KVariantList.equipColor[curqa])
			obj:egSetWidgetColor(kImgMaskBar,KVariantList.equipColor[curqa])
			obj._selectedEquip:updateEquipQa()
			obj:egSetWidgetEnabled(kBtnUpgrade, math.floor(curlv* numDef.weaponQaFactor) > curqa )
		end
		local function loadedCallback()
			sender:setTouchEnabled( true)
		end
		
        local qalayer = EquipQALayer.new(equipid,loadedCallback)
		qalayer:onQAChanged(qaChangedCallBack)
		local scene = CCDirector:sharedDirector():getRunningScene()
		scene:addChild(qalayer:egNode(),UILv.popLayer,UILv.popLayer)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnUpgrade,nil,nil,touchEnded,touchCanceled)
end
function __equiplayer.getHeroProp (obj,heroid)
    for _,item in ipairs(account_data.heroList) do
        if item.type == heroid then
            return item
        end
    end 
end
function __equiplayer.setHeroEid (obj,heroid,eidNew)
    for _,item in ipairs(account_data.heroList) do
        if item.type == heroid then
            item.eid = eidNew
        end
    end 
end

EquipLayer={}
function EquipLayer.new()
   local obj = TouchWidget.new(JsonList.equipLayer)
   table_aux.unpackTo(__equiplayer,obj)
   obj:init()
   obj:bindBackListener()
   obj:bindArmListener()
   obj:bindLvUpListener()
   obj:bindUpgradeListener()
   return obj
end

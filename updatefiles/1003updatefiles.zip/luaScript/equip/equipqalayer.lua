local kPanelLayer = "qa_panel"
local kImgOuterBar = "img_light_bar"
local kImgInnerBar = "img_color_bg"
local kImgEquip = "img_item"
local kLblLv = "lbl_lv"
local kLblName = "lbl_equip_name"
local kLblOldVal = "lbl_qa_val"
local kLblAddVal = "lbl_qa_val_1"
local kLblStone = "lbl_stoneD_val"
local kImgStone = "img_stoneD"
local kLblJewel = "lbl_jewel_val"
local kBtnBack = "btn_no"
local kBtnYes = "btn_yes"
local kPanelStamp = "img_stamp"
local kPanelStone = "pay_panel"
local kPanelJewel = "pay_panel_1"
local kRedColor = ccc3(255,0,0)
local __equipqalayer ={}
function __equipqalayer.init(obj,equipid)
	obj:egHideWidget(kPanelStamp)
	obj:egHideWidget(kPanelJewel)
	obj:egHideWidget(kLblAddVal)
	obj:egHideWidget(kImgOuterBar)
	obj._equipid = equipid
	obj._curlv,obj._curqa = equipFuncs.getEquipQL(obj._equipid, account_data)
	local s_cfg = equipCfg[obj._equipid]
	obj:egSetLabelStr(kLblName,s_cfg.name)
	obj:egChangeImg(kImgEquip,s_cfg.icon,UI_TEX_TYPE_PLIST)
	obj:egSetBMLabelStr(kLblLv,obj._curlv) --��ʾ�����ȼ�
	obj._old_qa_cfg =  equipEvoData[obj._equipid ][obj._curqa]
	obj._new_qa_cfg = equipEvoData[obj._equipid ][obj._curqa +1]
	obj:egSetLabelStr(kLblOldVal, obj._old_qa_cfg.powerPlus or 0)
	for coinName,coinVal in pairs( obj._old_qa_cfg.cost or {}) do
		obj:egChangeImg(kImgStone,ImageList[string.format("comm_%s",coinName)],UI_TEX_TYPE_PLIST)
		obj:egSetLabelStr(kLblStone,string.format("%d/%d",math.min(coinVal,account_data[coinName]),coinVal))
		if account_data[coinName]<coinVal then
			obj:egShowWidget(kPanelJewel)
			local stonepanel = obj:egGetWidgetByName(kPanelStone)
			local jewelpanel = obj:egGetWidgetByName(kPanelJewel)
			stonepanel:setPosition(ccp(stonepanel:getPositionX(),jewelpanel:getPositionY() + jewelpanel:getSize().height))
			obj._needJewel = numDef.stoneDPrice*(coinVal - account_data[coinName])
			obj:egSetLabelStr(kLblJewel,obj._needJewel)
			if account_data.jewel < obj._needJewel then
				obj:egSetWidgetColor(kLblJewel,kRedColor)
				obj:bindChargeListener()
			else
				obj:bindYesListener()
			end
		else
			obj:bindYesListener()
		end
		break
	end 
    --��ʾ����Ʒ��
	obj:egSetWidgetColor(kImgOuterBar,KVariantList.equipColor[obj._curqa])
	obj:egSetWidgetColor(kImgInnerBar,KVariantList.equipColor[obj._curqa])
	
	obj:showWithAction()
end

function __equipqalayer.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __equipqalayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
--��ʾ����ϵͳ�仯
function __equipqalayer.showPowerPlusChange(obj)	
    local lbl = obj:egGetWidgetByName(kLblAddVal)
    lbl:setVisible(true) 
	lbl:setEnabled(true)
    lbl:setOpacity(255)
    local delay = CCDelayTime:create(0.8)
    local fadeout = CCFadeOut:create(0.2)
	local increPower = string.format("+%0.2f",(obj._new_qa_cfg.powerPlus or 0) - (obj._old_qa_cfg.powerPlus or 0))
	obj:egSetLabelStr(kLblAddVal,increPower)
    local function callback()
         lbl:setVisible(false)
		 lbl:setEnabled(false)
		 obj:egSetLabelStr(kLblOldVal,obj._new_qa_cfg.powerPlus or 0)
    end
    local ccallfunc = CCCallFunc:create(callback)
    local array = CCArray:create()
    array:addObject(delay)
    array:addObject(fadeout)
    array:addObject(ccallfunc)
    local sequence = CCSequence:create(array)
    lbl:runAction(sequence)
end
--��ʾ�ȼ��䶯�ڲ���������
function __equipqalayer.showInnerColorChange(obj)
    local widget = obj:egGetWidgetByName(kImgInnerBar)
    local fadeto1 = CCFadeTo:create(0.6,0)
	local function callback1()
		obj:egSetWidgetColor(kImgInnerBar,KVariantList.equipColor[obj._curqa])
	end
    local callfunc1 = CCCallFunc:create(callback1)
    local fadeto2 = CCFadeTo:create(0.4,255)
    local array = CCArray:create()
    array:addObject(fadeto1)
	array:addObject(callfunc1)
    array:addObject(fadeto2)
    widget:runAction(CCSequence:create(array))
end
--��ʾ�ȼ��䶯��������
function __equipqalayer.showOutColorChange(obj)
    local widget = obj:egGetWidgetByName(kImgOuterBar)
    widget:setVisible(true)
    widget:setEnabled(true)
    widget:setOpacity(0)
    local fadeto1 = CCFadeTo:create(0.6,255)
    local scaleto1 = CCScaleTo:create(0.6,1.2)
    local spawn1 = CCSpawn:createWithTwoActions(fadeto1,scaleto1)
	local function callback1()
		obj:egSetWidgetColor(kImgOuterBar,KVariantList.equipColor[obj._curqa])
	end
    local callfunc1 = CCCallFunc:create(callback1)
    local fadeto2 = CCFadeTo:create(0.4,0)
	local scaleto2 = CCScaleTo:create(0.4,1)
	local spawn2 = CCSpawn:createWithTwoActions(fadeto2,scaleto2)
	local function callback2()
		widget:setVisible(false)
        widget:setEnabled(false)
		obj:egShowWidget(kBtnBack)
		if obj._changedCallback then obj._changedCallback() end
	end
    local callfunc2 = CCCallFunc:create(callback2)
    local array = CCArray:create()
    array:addObject(spawn1)
	array:addObject(callfunc1)
    array:addObject(spawn2)
    array:addObject(callfunc2)
    widget:runAction(CCSequence:create(array))
end
function __equipqalayer.showQAStamp(obj)
	local stamp = obj:egGetWidgetByName(kPanelStamp)
	stamp:setVisible(true)
	stamp:setEnabled(true)
	stamp:setScale(2)
	local scaleTo = CCScaleTo:create(1,1)
	local backout = CCEaseBackOut:create(scaleTo)
	stamp:runAction(backout)
end
function __equipqalayer.onQAChanged(obj,callback)
	obj._changedCallback = callback
end
--����/��Դ�㹻ʱ�ĵ���¼�
function __equipqalayer.bindYesListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		sender:setVisible(false)
		obj:egHideWidget(kBtnBack)
		SendMsg[939003](obj._equipid)
		obj._curqa = obj._curqa + 1
		account_data.equipments[obj._equipid][2] = obj._curqa
		obj:showPowerPlusChange()
		obj:showInnerColorChange()
		obj:showOutColorChange()
		obj:showQAStamp()
		
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--���겻���ĵ���¼�
function __equipqalayer.bindChargeListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then  AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		obj:egRemoveSelf()
		showPopCharge(obj._needJewel)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
function __equipqalayer.bindBackListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egSetWidgetTouchEnabled(kBtnCancel,false)
        SoundHelper.playEffect(SoundList.click_paper_close)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
EquipQALayer={}
function EquipQALayer.new(equipid,onloaded)
     local obj =  TouchWidget.new(JsonList.equipQa)
    table_aux.unpackTo(__equipqalayer, obj)
    obj._onloaded = onloaded
    obj:init(equipid)
    obj:bindBackListener()
    return obj
end

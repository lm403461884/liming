--[[
dofile("luaScript/comm/ai/heroAI/hero01.lua")
dofile("luaScript/moudle/ai/monsterAI/monster08.lua")
dofile("luaScript/moudle/ai/monsterAI/monster04.lua")
dofile("luaScript/moudle/ai/monsterAI/monster05.lua")
dofile("luaScript/moudle/ai/monsterAI/monster03.lua")
dofile("luaScript/moudle/ai/monsterAI/monster10.lua")
dofile('luaScript/moudle/skill/monster/monster02Skill.lua')
dofile('luaScript/moudle/skill/monster/monster04Skill.lua')
dofile('luaScript/moudle/skill/monster/monster05Skill.lua')
dofile('luaScript/moudle/skill/monster/monster08Skill.lua')
dofile("luaScript/moudle/ai/skill.lua")
dofile("luaScript/moudle/ai/movement.lua")
dofile("luaScript/moudle/ai/vision.lua")
dofile("luaScript/data/s_data/monsterData.lua")
]]--

battleProgress ={}
    battleProgress.type = 1
    battleProgress.startTime = os.time()
    battleProgress.areaID = 1
    battleProgress.stageID = 1
    battleProgress.heroDamage = {} --heroDamage={[heroid]={damage1,time1,damage2,time2...}}
    battleProgress.monsterDeath = {}
    battleProgress.gold = {}  --gold = {pos,pos2...} --posΪcollectorList����������λ��
    battleProgress.oil = {}   --oil = {pos,pos2...}
    battleProgress.itemUsage = {} --itemUsage = {[itemid]={time1,time2,...}}
    battleProgress.itemUsageFrame = {}--itemUsageFrame = {[itemid]={framid1,frameid2,...}}
    battleProgress.heroEnterFrame = {} --heroEnterFrame={[heroid] = framid,}
    battleProgress.stars = 3
    battleProgress.frameCnt = 0

createHero({type=6, lv=5, hp=100000, maxHP=100000}, 90)

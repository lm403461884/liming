local kImgHero = "img_hero"
local kImgLv = "img_lv"
local kLabelLv = "lbl_lv"
local kLabelCost = "lbl_cost"
local kBtnItem = "btn_heroitem"
local kImgBar = "img_bar"
local kImgPompt = "img_note_bg"

local __teamNow = {}
function __teamNow.init(obj,pos)
    obj._pos = pos
    obj._heroid = account_data.team[obj._pos] or 0
    obj:egHideWidget(kImgBar)
    obj:egHideWidget(kImgPompt)
    obj:changeHeroId(obj._heroid)
end
function __teamNow.changeHeroId(obj,heroid)
    obj._heroid = heroid
    if obj._heroid == 0 then 
        obj._herodata = nil
        obj:egHideWidget(kLabelCost)
        obj:egHideWidget(kImgLv)
        obj:egHideWidget(kImgHero)
        obj:egSetWidgetEnabled(kBtnItem,false)
    else
        obj:egSetWidgetEnabled(kBtnItem,true)
        obj._herodata =  RiskHelper.getHeroData(obj._heroid,account_data.heroList)
        ----------------------------------------------------------------------------
        local s_cfg = hero_data.getConfig(obj._heroid)
        local s_data = hero_data.get(obj._heroid,obj._herodata.lv)
        obj._photo = string.format('%s_010201.png',s_cfg.graphList[s_data.graphLV])
        ----------------------------------------------------------------------------
        --����������ʾ
        obj:egShowWidget(kLabelCost)
        obj:egShowWidget(kImgLv)
        obj:egShowWidget(kImgHero)
        obj:egChangeImg(kImgHero,obj._photo,UI_TEX_TYPE_PLIST)
        obj:egSetBMLabelStr(kLabelLv,obj._herodata.lv)
        obj:egSetLabelStr(kLabelCost,string.format(string.format("%s%d","COST",s_data.consume)))
    end
end
function __teamNow.loadHeroAtPos(obj,pos)
    obj._pos = pos
    obj:egHideWidget(kImgBar)
    obj:egHideWidget(kImgPompt)
    local heroid = account_data.team[obj._pos] or 0
    if heroid ~= obj._heroid then
        obj:changeHeroId(heroid)
    end
end
function __teamNow.getHeroID(obj)
    return obj._heroid
end
function __teamNow.getHeroPos(obj)
    return obj._pos
end

function __teamNow.setItemTouchEnabled(obj,enabled)
    obj:egSetWidgetTouchEnabled(kBtnItem,enabled)
end
function __teamNow.onItemClicked(obj,onclicked)
    obj._itemCallback = onclicked
end
function __teamNow.bindItemListener(obj)
    local function touchBegan(sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_rescar_dig)
        local imgbar = obj:egGetWidgetByName(kImgBar)
        imgbar:setScale(1)
        imgbar:setOpacity(255)
        obj:egShowWidget(kImgBar)
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        if obj._pos == 1 and #account_data.team == 1 then
            obj:egShowWidget(kImgPompt)
            local imgpromt = obj:egGetWidgetByName(kImgPompt)
            local function callback()
                obj:egHideWidget(kImgPompt)
                obj:egHideWidget(kImgBar)
                sender:setTouchEnabled(true)
            end
            local callfunc = CCCallFunc:create(callback)
            local fadein = CCFadeIn:create(0.3)
            local delay = CCDelayTime:create(0.5)
            local fadeout = CCFadeOut:create(0.2)
            local array = CCArray:create()
            array:addObject(fadein)
            array:addObject(delay)
            array:addObject(fadeout)
            array:addObject(callfunc)
            local sequence = CCSequence:create(array)
            imgpromt:runAction(sequence)
        else
            local imgbar = obj:egGetWidgetByName(kImgBar)
            local scaleto = CCScaleTo:create(0.2,1.1)
            local fadeout = CCFadeOut:create(0.2)
            local spawn = CCSpawn:createWithTwoActions(scaleto,fadeout)
            local function callback()
                if obj._itemCallback then obj._itemCallback(obj) end
            end
            local callfunc = CCCallFunc:create(callback)
            local sequence = CCSequence:createWithTwoActions(spawn,callfunc)
            imgbar:runAction(sequence)
        end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			obj:egHideWidget(kImgBar)
		end
    end
	
    obj:egBindTouch(kBtnItem,touchBegan,nil,touchEnded,touchCanceled)
end
TeamNow = {}
function TeamNow.new(pos)
    local obj = {}
    CocosWidget.install(obj,JsonList.teamRightNow)
    table_aux.unpackTo(__teamNow, obj)
    obj:init(pos)
    obj:bindItemListener()
    return obj
end

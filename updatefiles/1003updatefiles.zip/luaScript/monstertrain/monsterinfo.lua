local kLabelName = "lbl_name"
local kLabelLv = "lbl_lv"
local kLabelAtk = "lbl_atkcap_val"
local kLabelHp = "lbl_hp_val"
local kLabelConsume = "lbl_consume_val"
local kLabelIntro = "lbl_introduce"
local kImgMonsterInfo = "img_big_monster"
local kImgMapBg = "map_bg"
local kPanelMonsterInfo = "Panel_monster_info"

local kPropX= 105
local kPropY = 91
local KMonsterMaxLv = 100
local kGrayColor = ccc3(64,64,64)
local __monsterinfo={}
function __monsterinfo.init(obj,monsterid)
    obj._monsterid = monsterid
    obj._lv = account_data.monsterLvLook[obj._monsterid] or 1
    local s_cfg = monster_data.getConfig(obj._monsterid)
    local s_data = monster_data.get(obj._monsterid,obj._lv)
    obj:egSetLabelStr(kLabelName,s_cfg.name)
    obj:egSetLabelStr(kLabelLv,string.format("%s%d","LV.",obj._lv))
    obj:egSetLabelStr(kLabelAtk,s_data.power)
    obj:egSetLabelStr(kLabelHp,s_data.maxHP)
    obj:egSetLabelStr(kLabelConsume,s_data.consume)
    obj:egSetLabelStr(kLabelIntro,string.format("%s%s","    ",s_cfg.info))
    obj:egChangeImg(kImgMonsterInfo,s_cfg.photo,UI_TEX_TYPE_PLIST) 
    obj:initPropMap()
end

function __monsterinfo.initPropMap(obj)
    local s_data = monster_data.get(obj._monsterid,obj._lv)
    obj._drawNode = CCDrawNode:create()
    local cos18 = math.cos(18/180*math.pi)
    local sin18 =  math.sin(18/180*math.pi)
    local cos54 = math.cos(54/180*math.pi)
    local sin54 = math.sin(54/180*math.pi)
    local atk = s_data.charATK
    local hp = s_data.charHP
    local cost = s_data.charCost
    local speed = s_data.charSpeed
    local vision = s_data.charVision
    local p1 = ccp(0,atk) --atk
    local p2 = ccp(cos18*cost,sin18*cost) --cost
    local p3 = ccp(cos54*speed,-sin54*speed) -- speed
    local p4 = ccp(-cos54*vision,-sin54*vision) --vision
    local p5 = ccp(-cos18*hp,sin18*hp) --hp
    obj._drawNode:drawPolygon(ccc4f(0.46,0.6,0.62,0.8), 1, ccc4f(0.46,0.6,0.62,0.8),p1,p2,p3,p4,p5)
    local mapbg = tolua.cast(obj:egGetWidgetByName(kImgMapBg),"ImageView")
    local node = mapbg:getVirtualRenderer()
    node:addChild(obj._drawNode)
    obj._drawNode:setPosition(ccp(kPropX,kPropY))
end
function __monsterinfo.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelInfo)
    widget:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveTo:create(0.3,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end
function __monsterinfo.bindBackListener(obj)
    local function touchEnded(sender)
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelMonsterInfo,nil,nil,touchEnded,touchCanceled)
end
MonsterInfo={}
function MonsterInfo.new(monsterid)
    local obj = TouchWidget.new(JsonList.monsterInfo)
    table_aux.unpackTo(__monsterinfo, obj)
    obj:init(monsterid)
    obj:bindBackListener()
    return obj
end
function ShowMonsterInfo(monsterid,callback)
    local layer = MonsterInfo.new(monsterid)
    local scene = CCDirector:sharedDirector():getRunningScene()
	scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction(callback)    
end
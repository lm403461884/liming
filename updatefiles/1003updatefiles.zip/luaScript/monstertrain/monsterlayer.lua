local kBtnBack = "btn_back"
local kLabelCnt = "lbl_monstercnt"
local kLabelDig = "lbl_digcnt"
local kLabelGold = "own_gold_val"
local kBarGold = "own_gold_bar"
local KLblTrainLv = "lbl_train"
--������Ϣ���
local kPanelNote = "notice_panel"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kPanelTxt = "txt_panel"
local kLblNoteTxt = "lbl_note_txt_2"
local kImgNoteCoin = "img_note_coin"
local kImgTxtBg = "img_note_bg"
local kImgTxtMask="img_note_mask"
--�����б�
local kItemList = "itemlist"
local kCellW = 190
local kUtype = 2
local kRedColor = ccc3(255,0,0)

local __monsterlayer={}
function __monsterlayer.init(obj)
	obj._trainLv= account_data.train[train.def.monster].lv
	obj._monsterItems = {}
    obj:showNotePanel(false)
    obj._selectedmonster = nil
	obj:egSetLabelStr(kLabelDig,account_data.maxDigPt or 0)
	obj:egSetLabelStr(KLblTrainLv,string.format("%s%d","LV",obj._trainLv))
	obj:refreshMonsterNum()
	obj:refreshGold()
    obj:loadMonsterCard()
end
--ˢ�¹���������ʾ
function __monsterlayer.refreshMonsterNum(obj)
	local cnt = 0
	for monsterid ,data in  pairs(account_data.monsterPool) do
		cnt = cnt + data.N
	end
	obj:egSetLabelStr(kLabelCnt,cnt)
end
--ˢ�½�������ʾ
function __monsterlayer.refreshGold(obj)
	local gold = account_data.gold
	local maxgold = account_data.maxGold
	obj:egSetBarPercent(kBarGold,math.min(gold*100/maxgold,100))
	obj:egSetBMLabelStr(kLabelGold,Funs.formatNum(gold))
end
--����ȷ�Ͽ���ʾ
function __monsterlayer.showNotePanel(obj,show)
    if show then
        obj:egShowWidget(kPanelNote)
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        obj:egSetWidgetTouchEnabled(kBtnYes,true)
        obj:egSetWidgetTouchEnabled(kBtnNo,true)
    else
        obj:egHideWidget(kPanelNote)
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
    end
end

--��ȡ����С���������Ĺ���ID�б�
function __monsterlayer.getOrderedMonsterList(obj)
    local tbUnlocked = {}
    local tbLocked = {}
    for monsterid,item in pairs(MonsterTrain) do  --monsterid����
       if item[obj._trainLv] then 
          table.insert(tbUnlocked,monsterid) 
       else
          table.insert(tbLocked,monsterid)
       end 
    end
    table.sort(tbUnlocked)
    table.sort(tbLocked)
    for key,val in ipairs(tbLocked) do
        table.insert(tbUnlocked,val)
    end
    tbLocked = nil
    return tbUnlocked
end
--����Ӣ�ۿ�Ƭ��Ϣ
function __monsterlayer.loadMonsterCard(obj)
    local itemlist = obj:egGetScrollView(kItemList)
    local size = itemlist:getSize()
    local monsterList = obj:getOrderedMonsterList()
    for key,monsertid in ipairs(monsterList) do
        local monstercard = MonsterCard.new(monsertid)
        monstercard:egSetPosition((key-1)*kCellW,0)
        obj:bindAddCallBack(monstercard)
        obj:bindGrowCallBack(monstercard)
        itemlist:addChild(monstercard:egNode())
		table.insert(obj._monsterItems,monstercard)
    end
    local neww = #monsterList * kCellW
    if neww > size.width then
        itemlist:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
end
function __monsterlayer.getMonsterPrice(obj,monsterid,ownNum)
	for key,val in pairs(MonsterCost[monsterid][ownNum]) do
		return key,val
	end
end
--������ص�����
function __monsterlayer.bindAddCallBack(obj,monstercard)
	local function addCallBack(sender)
		obj._selectedmonster = sender
        
        local monsterid = sender:getprop("monsterid")
		local ownNum = sender:getprop("ownNum")
		local coinName,coinVal = obj:getMonsterPrice(monsterid,ownNum)
		if account_data[coinName] < coinVal then
			 showPopChargeRes(coinName,coinVal,function () sender:setAddBtnEnabled() end)
		else
			obj:showNotePanel(true)
			obj:egChangeImg(kImgNoteCoin,ImageList[string.format("comm_%s",coinName)],UI_TEX_TYPE_PLIST)
			obj:egSetLabelStr(kLblNoteTxt,string.format("%d %s %s",coinVal,TxtList.addMonster,sender:getprop("name")))
			
			local lbl = obj:egGetWidgetByName(kLblNoteTxt)
			local w = lbl:getPositionX() + lbl:getSize().width
			local panel = obj:egGetWidgetByName(kPanelTxt)
			panel:setSize(CCSizeMake(w,panel:getSize().height))
			local img = obj:egGetWidgetByName(kImgTxtBg)
			panel:setPosition(ccp((img:getSize().width-w)/2,img:getPositionY()))
			local imgmask = obj:egGetWidgetByName(kImgTxtMask)
			imgmask:setScale(0)
			local scaleto = CCScaleTo:create(0.2,1)
			local backout = CCEaseBackOut:create(scaleto)
			imgmask:runAction(backout)
		end
	end
	monstercard:onMonsterAdd(addCallBack)
end
--��ѵ���ص�����
function __monsterlayer.bindGrowCallBack(obj,monstercard)
	local function growCallback(sender)
		local monsterlv = sender:getprop("lv")
		local monsterid = sender:getprop("monsterid")
		local monsterdata =  monster_data.get(monsterid,monsterlv )
		local coinName = monsterdata.tCoin
		local coinVal = monsterdata.tValue
		local isjewel = 0
		if coinName==KVariantList.coinType[99] then isjewel = 1 end
		account_data[coinName] = account_data[coinName] - coinVal --�ۼ��ʻ�
		SendMsg[936005](kUtype,monsterid,isjewel,0)--����ѵ����Ϣ��������
		--�ھ���־������̸���,��������
		task.updateTaskStatus(account_data,task.client_event_id.update_monster,{monsterid,monsterlv+1})
		----------------------------------------------------------
		local function loadedCallback()
			sender:doMonsterLvUp()
			obj:refreshGold()
			obj:changeAllGrowBtnState()
		end
		showTrainingInfo(monsterid,monsterlv,loadedCallback)
	end
	monstercard:onMonsterGrow(growCallback)
end
--��������䶯���޸����п�Ƭ��ť����
function __monsterlayer.changeAllGrowBtnState(obj)
	for key,monstercard in ipairs(obj._monsterItems) do
		monstercard:changeGrowBtnState()
	end
end
--ȷ������
function __monsterlayer.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
		SoundHelper.playEffect(SoundList.buy_hero_01)
        obj:showNotePanel(false)--�ر���ʾ��
		
		local monsterid = obj._selectedmonster:getprop("monsterid")
		local ownNum = obj._selectedmonster:getprop("ownNum")
		local coinName,coinVal = obj:getMonsterPrice(monsterid,ownNum)
		account_data[coinName] = account_data[coinName] - coinVal --�ۼ��ʻ�
		SendMsg[936004](monsterid)--����������Ϣ��������
		--�ھ���־������̸���,�������
		task.updateTaskStatus(account_data,task.client_event_id.buy_monster,{monsterid})
		----------------------------------------------------------
        -----------------------
        local popmonstercard =PopMonsterCard.new(monsterid)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmonstercard:egNode(),UILv.popLayer,UILv.popLayer)
        local function onclosedCallback()
			obj._selectedmonster:doMonsterNumUp()
			obj:refreshMonsterNum()
			obj:refreshGold()
			obj:changeAllGrowBtnState()
			obj._selectedmonster = nil
		end
		popmonstercard:onPopCardClosed(onclosedCallback)
		--]]
	end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end

--ȡ������
function __monsterlayer.bindNoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
       local imgmask = obj:egGetWidgetByName(kImgTxtMask)
        local scaleto = CCScaleTo:create(0.2,0)
        local function callback()
            sender:setTouchEnabled(true)
			obj._selectedmonster:setAddBtnEnabled()
            obj:showNotePanel(false)
			obj._selectedmonster = nil
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(scaleto,callfunc)
        imgmask:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end

--���ذ�ť
function __monsterlayer.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        local scene = TownScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬		
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
MonsterLayer={}
function MonsterLayer.new()
    local obj =  TouchWidget.new(JsonList.monsterLayer)
    table_aux.unpackTo(__monsterlayer, obj)
    obj:init()
    obj:bindBackListener()
    obj:bindYesListener()
    obj:bindNoListener()
    return obj
end


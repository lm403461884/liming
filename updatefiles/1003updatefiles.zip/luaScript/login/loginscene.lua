local __loginscene={}
local kBtnRegist = "regist_btn"
local kBtnLogin = "login_btn"
local kTbPwd = "pwd_tb"
local kTbAccount = "account_tb"
local kBgPwd = "pwd_bg"
local kBgAccount = "account_bg"
local kPanelMsg = "msg_layer"
local kPanelMsg0 = "msg_layer_0"
local kImgBg0 = "img_bg_0"
local kBtnOk0 = "btn_ok_0"
local kImgBg = "img_bg"
local kBtnOk = "btn_ok"
local kLabelMsgName = "lbl_msg_name"
local kLabelMsgPwd = "lbl_msg_pwd"
local kLabelLoad = "lbl_conn"
local kPanelLog = "log_layer"
local kExTxt = {"",".","..","..."}
local kAttach_with_ime = 0
local kDetach_with_ime = 1
local kInsert_text = 2
local kDelete_backward = 3
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local kPattenChar = "%W+"
local kPattenNum ="^%d+"
function __loginscene.promptName(obj)
    obj._baseWidget:egShowWidget(kPanelMsg)
    obj._baseWidget:egShowWidget(kImgBg)
    obj._baseWidget:egShowWidget(kBtnOk)
    obj._baseWidget:egShowWidget(kLabelMsgName)
    obj._baseWidget:egHideWidget(kLabelMsgPwd)
end
function __loginscene.promptPwd(obj)
    obj._baseWidget:egShowWidget(kPanelMsg)
    obj._baseWidget:egShowWidget(kImgBg)
    obj._baseWidget:egShowWidget(kBtnOk)
    obj._baseWidget:egHideWidget(kLabelMsgName)
    obj._baseWidget:egShowWidget(kLabelMsgPwd)
end
function __loginscene.hideInputPrompt(obj)
    obj._baseWidget:egHideWidget(kPanelMsg)
    obj._baseWidget:egHideWidget(kImgBg)
    obj._baseWidget:egHideWidget(kBtnOk)
    obj._baseWidget:egHideWidget(kLabelMsgName)
    obj._baseWidget:egHideWidget(kLabelMsgPwd)
    obj._baseWidget:egSetWidgetTouchEnabled(kBtnRegist,true)
    obj._baseWidget:egSetWidgetTouchEnabled(kBtnLogin,true)
end
function __loginscene.hideConnPrompt(obj)
    obj._baseWidget:egHideWidget(kPanelMsg0)
    obj._baseWidget:egHideWidget(kImgBg0)
    obj._baseWidget:egHideWidget(kBtnOk0)
    obj._baseWidget:egSetWidgetTouchEnabled(kBtnRegist,true)
    obj._baseWidget:egSetWidgetTouchEnabled(kBtnLogin,true)
end
function __loginscene.checkAccount(obj)
    login_account = obj._baseWidget:egGetTextFieldVal(kTbAccount) or ""
    local len = string.len(login_account)
	if  len < 1 or  len > 15 or string.find(login_account,kPattenNum) or string.find(login_account,kPattenChar) then
	   obj:promptName()
	    return false
	end
	return true
end
function __loginscene.checkPwd(obj)
     login_pwd =  obj._baseWidget:egGetTextFieldVal(kTbPwd)  or ""
     local len = string.len(login_pwd)
	if   len < 1 or  len > 15 or string.find(login_account,kPattenNum) or string.find(login_account,kPattenChar) then
	    obj:promptPwd()
	    return false
	end
	return true
end
function __loginscene.startListen(obj)
	local timestamp = os.clock()
	local cnt = 1
    local  function callback()
			if (os.clock() - timestamp)*1000 >= 400 then
				timestamp = os.clock()
				cnt = cnt + 1
				if cnt > 4 then cnt = 1 end
				obj._baseWidget:egSetLabelStr(kLabelLoad,obj._txtLoad..kExTxt[cnt])
			end
			local state = RSHelper:getState()
			if state == 6 then
				obj._baseWidget:egUnbindWidgetUpdate(kLabelLoad)
				obj._baseWidget:egHideWidget(kLabelLoad)
				RSHelper:handleRSMsg()
            elseif state < 0  then
                print("state",state)
				RSHelper:disconnect()
               obj._baseWidget:egNode():setTouchEnabled(true)
			   obj._baseWidget:egUnbindWidgetUpdate(kLabelLoad)
			   obj._baseWidget:egHideWidget(kLabelLoad)
			   obj._baseWidget:egShowWidget(kPanelMsg0)
			   obj._baseWidget:egShowWidget(kImgBg0)
			   obj._baseWidget:egShowWidget(kBtnOk0)
			   
            end
    end
	RSHelper:connect()
	if obj._regFlag then
		RSHelper:sendRegMsg(login_account,login_pwd)
	else
		RSHelper:sendLogMsg(login_account,login_pwd)
	end
	obj._baseWidget:egNode():setTouchEnabled(false)
	obj._baseWidget:egSetLabelStr(kLabelLoad,obj._txtLoad)
	obj._baseWidget:egShowWidget(kLabelLoad)
    obj._baseWidget:egBindWidgetUpdate(kLabelLoad,callback)
end
function __loginscene.bindOkListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:hideInputPrompt()
    end
    obj._baseWidget:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __loginscene.bindOkListener0(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_shop_goods)
        obj:hideConnPrompt()
    end
    obj._baseWidget:egBindTouch(kBtnOk0,nil,nil,touchEnded,nil)
end
function __loginscene.bindRegistListener(obj)
    local function touchEnded(sender)
		obj._baseWidget:egSetWidgetTouchEnabled(kBtnRegist,false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
       if not obj:checkAccount() then return end
       if not obj:checkPwd() then return end
	   obj._regFlag = true
	   obj:startListen()
    end
    obj._baseWidget:egBindTouch(kBtnRegist,nil,nil,touchEnded,nil)
end
function __loginscene.bindLogintListener(obj)
    local function touchEnded(sender)
		obj._baseWidget:egSetWidgetTouchEnabled(kBtnLogin,false)
		SoundHelper.playEffect(SoundList.click_shop_goods)
       if not obj:checkAccount() then return end
       if not obj:checkPwd() then return end
	   obj._regFlag = false
	   CCUserDefault:sharedUserDefault():setStringForKey("name",login_account)
	   CCUserDefault:sharedUserDefault():setStringForKey("pwd",login_pwd)
       obj:startListen()
    end
    obj._baseWidget:egBindTouch(kBtnLogin,nil,nil,touchEnded,nil)
end

function __loginscene.bindAccountBgListener(obj)
    local function touchEnded(sender)
        local widget = obj._baseWidget:egGetWidgetByName(kTbAccount)
        local textField = tolua.cast(widget,"TextField")
        textField:attachWithIME()
    end
    obj._baseWidget:egBindTouch(kBgAccount,nil,nil,touchEnded,nil)
end

function __loginscene.bindPwdBgListener(obj)
    local function touchEnded(sender)
        local widget = obj._baseWidget:egGetWidgetByName(kTbPwd)
        local textField = tolua.cast(widget,"TextField")
        textField:attachWithIME()
    end
    obj._baseWidget:egBindTouch(kBgPwd,nil,nil,touchEnded,nil)
end

function __loginscene.bindAccountListener(obj)
     local function textFieldEvent(sender, eventType)
        --if eventType == kAttach_with_ime or  eventType ==kDetach_with_ime or eventType == kDelete_backward then
             local textField = tolua.cast(sender,"TextField")
             local text = textField:getStringValue()
             if text == "" and obj._accountColor == kWhiteColor then 
                 obj._accountColor = kRedColor
                 obj._baseWidget:egSetWidgetColor(kBgAccount,obj._accountColor) 
             elseif text ~= "" and obj._accountColor == kRedColor  then
                 obj._accountColor = kWhiteColor
                 obj._baseWidget:egSetWidgetColor(kBgAccount,obj._accountColor) 
             end
        -- end
    end
    local widget = obj._baseWidget:egGetWidgetByName(kTbAccount)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent) 
end

function __loginscene.bindPwdListener(obj)
    local function textFieldEvent(sender, eventType)
      --  if eventType == kAttach_with_ime or eventType ==kDetach_with_ime or eventType == kDelete_backward then
            local textField = tolua.cast(sender,"TextField")
             local text = textField:getStringValue()
             if text == "" and obj._pwdColor == kWhiteColor then 
                 obj._pwdColor = kRedColor
                 obj._baseWidget:egSetWidgetColor(kBgPwd,obj._pwdColor) 
             elseif text ~= "" and obj._pwdColor == kRedColor  then
                 obj._pwdColor = kWhiteColor
                 obj._baseWidget:egSetWidgetColor(kBgPwd,obj._pwdColor) 
             end
        -- end
    end
    local widget = obj._baseWidget:egGetWidgetByName(kTbPwd)
    local textField = tolua.cast(widget,"TextField")
    textField:addEventListenerTextField(textFieldEvent) 
end
function __loginscene.init(obj)
    obj._accountColor = kWhiteColor
    obj._pwdColor = kWhiteColor
    obj._baseWidget:egHideWidget(kPanelMsg)
    obj._baseWidget:egHideWidget(kImgBg)
    obj._baseWidget:egHideWidget(kBtnOk)
	obj._baseWidget:egHideWidget(kPanelMsg0)
    obj._baseWidget:egHideWidget(kImgBg0)
    obj._baseWidget:egHideWidget(kBtnOk0)
	obj._baseWidget:egHideWidget(kLabelLoad)
	obj._txtLoad = obj._baseWidget:egGetLabelStr(kLabelLoad)
	obj._regFlag = false
end
LoginScene = {}
function LoginScene.new()
	local obj = {}
	Scene.install(obj)
	table_aux.unpackTo(__loginscene, obj)
	obj._baseWidget = TouchWidget.new(JsonList.loginLayer)
    obj._baseWidget:egAttachTo(obj)
    
    obj:init()
    obj:bindRegistListener()
    obj:bindLogintListener()
    obj:bindOkListener()
	obj:bindOkListener0()
    obj:bindAccountListener()
    obj:bindPwdListener()
    obj:bindAccountBgListener()
    obj:bindPwdBgListener()
    obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
    return obj
end

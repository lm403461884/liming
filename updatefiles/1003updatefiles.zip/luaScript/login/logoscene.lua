
local kImglogo = "img_logo"
local kMaxInterval = 10
local __logoscene = {}
function __logoscene.startListen(obj)
    local  function callback()
            local state = RSHelper:getState()
			if state == 6 then
				obj._baseWidget:egUnbindWidgetUpdate(kImglogo)
				RSHelper:handleRSMsg()
            elseif state < 0  then
				print("state:",state)
				RSHelper:disconnect()
               obj._baseWidget:egUnbindWidgetUpdate(kImglogo)
				local function callback()
					obj:runLoadAction()
				end
				local msglayer = MsgLayer.new(nil,TxtList.connFailed,1,callback)
				msglayer:show()
			end
    end
	RSHelper:connect()
	if obj._doReg then
		RSHelper:sendRegMsg(obj._logname,obj._logpwd)
	else
		RSHelper:sendLogMsg(obj._logname,obj._logpwd)
	end
    obj._baseWidget:egBindWidgetUpdate(kImglogo,callback)
end
function __logoscene.runLoadAction(obj)
    local widget = obj._baseWidget:egGetWidgetByName(kImglogo)
	widget:setOpacity(32)
    local fadein = CCFadeIn:create(2)
    local function callback()
		obj._logname = CCUserDefault:sharedUserDefault():getStringForKey("name")
		obj._logpwd = CCUserDefault:sharedUserDefault():getStringForKey("pwd")
		if obj._logname == "" then
		    obj._logname,obj._logpwd = AccountHelper:getDevMac()
		end
		if obj._logname == "" then
			local scene = LoginScene.new()
			scene:egReplace() 
		else
			obj:startListen()
		end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(fadein,callfunc)
    widget:runAction(sequence)
end
function __logoscene.bindNetTimer(obj)
    local passed = 0
    local function callback(delta)
        passed = passed + delta
        if HOAux:isNetConnected() then
            obj:runLoadAction()
            obj._baseWidget:egUnbindWidgetUpdate(kImglogo)
        elseif passed > kMaxInterval then
            obj._baseWidget:egUnbindWidgetUpdate(kImglogo)
            obj:showConnectPrompt()
        end
    end
    obj._baseWidget:egBindWidgetUpdate(kImglogo,callback)
end
function __logoscene.showConnectPrompt(obj)
     local function callback()
        --打开网络设置
        HOAux:openNetSetting()
        obj:bindNetTimer()
	end
	local msglayer = MsgLayer.new(nil,TxtList.netOff,1,callback)
	msglayer:egAttachTo(obj)
end
function __logoscene.init(obj,doReg)
	obj._doReg = doReg
    if CCApplication:sharedApplication():getTargetPlatform()==kTargetAndroid then
        if HOAux:isNetConnected() then
            obj:runLoadAction()
        else
           obj:showConnectPrompt()
        end
    else
        obj:runLoadAction()
    end
end

LogoScene={}
function LogoScene.new(doReg)
    local obj = {}
	Scene.install(obj)
	table_aux.unpackTo(__logoscene, obj)
	obj._baseWidget = TouchWidget.new(JsonList.logoLayer)
    obj._baseWidget:egAttachTo(obj)
	obj:init(doReg)
	    ----------------------------
	obj._recvlayer = RecvLayer.new()
	obj._recvlayer:egAttachTo(obj)
	return obj
end
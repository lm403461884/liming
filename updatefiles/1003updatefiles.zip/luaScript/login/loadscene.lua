local kBarLoad = "bar_mid"
local kImgHeader = "img_header"
local kLblNote = "lbl_note"
local __loadscene = {}
function __loadscene.activeWaitConn(obj)
    local function callback()
         local state = SocketHelper.currentState()
         if state == 0 then
         elseif state == 1 then
             obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
             AccountHelper:lock(kStateAccount)
             if not login_account or not login_pwd then
                login_account = CCUserDefault:sharedUserDefault():getStringForKey("name")
                login_pwd = CCUserDefault:sharedUserDefault():getStringForKey("pwd")
             end
             SendMsg[931001](login_account,login_pwd)
             obj:activeWaitLoad()
         else
            obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
            obj._baseWidget:egUnbindWidgetUpdate(kBarLoad)
            local function callback()
				local scene = LogoScene.new()
				scene:egReplace()
			end
			local msglayer = MsgLayer.new(nil,TxtList.connError,1,callback)
			msglayer:egAttachTo(obj)
         end
    end
    obj._baseWidget:egBindWidgetUpdate(kImgHeader,callback)
end

function __loadscene.activeWaitLoad(obj)
	obj._baseWidget:egSetLabelStr(kLblNote,TxtList.updateMsg[8])
    local function callback()
        if  not AccountHelper:isLocked(kStateAccount) and not AccountHelper:isLocked(kStateScript) and not AccountHelper:isLocked(kStateClub) then
            obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
            obj._baseWidget:egUnbindWidgetUpdate(kBarLoad)
            obj._baseWidget:egSetBarPercent(kBarLoad,100)
            local widget = obj._baseWidget:egGetWidgetByName(kImgHeader)
            local delay = CCDelayTime:create(0.05)
            local function callbackfunc()
                preLoadSounds()
				graphicLoader.loadAllImages()
                if not obj._isLoged and  RSHelper:isNewReg() then
					showNickNameLayer()
                else
					local areaid = licenceLevelup[1].areaID
					local stageid = 1
					if account_data.guideList[GuideScene.def.kAtkScene] and not account_data.unlockedPVE[areaid][1].nextUnlocked  then --PVE�ؿ�����û����
						local scene = GAtkScene.new(areaid,stageid)
						scene:egReplace()
					else
						local scene = TownScene.new()
						scene:egReplace()
					end
                end
            end
            local callFunc = CCCallFunc:create(callbackfunc)
            local sequence = CCSequence:createWithTwoActions(delay,callFunc)
            widget:runAction(sequence) 
        end
    end
    obj._baseWidget:egBindWidgetUpdate(kImgHeader,callback)
end
function __loadscene.startLoading(obj)
    local startTime = os.time()
    local function callback()
        local oldper =  obj._baseWidget:egGetBarPercent(kBarLoad)
        local curper = os.time() - startTime
        if curper > oldper then
           if curper >= 100 then
                obj._baseWidget:egUnbindWidgetUpdate(kBarLoad)
                local function callback()
					 AccountHelper:autoLogin()
				end
				local msglayer = MsgLayer.new(nil,TxtList.loadError,1,callback)
				msglayer:egAttachTo(obj)
            else
                obj._baseWidget:egSetBarPercent(kBarLoad,curper)
            end
         end
    end
    obj._baseWidget:egBindWidgetUpdate(kBarLoad,callback)
end

function __loadscene.init(obj,isLoged)
    obj._isLoged = isLoged 
	
    obj:startLoading()
    if isLoged  then 
        obj:activeWaitLoad() 
    else 
		obj._baseWidget:egSetLabelStr(kLblNote,TxtList.updateMsg[6])
        obj:activeWaitConn() 
    end
end
LoadScene = {}

function LoadScene.new(isLoged)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__loadscene, obj)
    Scene.install(obj)
    obj._baseWidget = TouchWidget.new(JsonList.loadingLayer)
    obj._baseWidget:egAttachTo(obj)
    obj:init(isLoged)
        ----------------------------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
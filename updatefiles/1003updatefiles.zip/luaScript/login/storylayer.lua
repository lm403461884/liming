local kPanelLayer = "story_panel"
local kPanelTxt = "txt_panel"
local kLabelWord = "lbl_word"
local kLabelWords = "lbl_word_s"
local kImgBgs = {"img_story","img_story_0"}
local __storylayer={}
function __storylayer.init(obj)
    obj._idx = 1
    obj._subidx = 1
    obj._showimgIdx = 1
    obj._hideimgIdx = 2
    local lbl = obj:egGetWidgetByName(kLabelWord)
    local lbls = obj:egGetWidgetByName(kLabelWords)
    obj._posx = lbl:getPositionX()
    obj._posxs = lbls:getPositionX()
    obj:showStory(true)
end

function __storylayer.showTxt(obj,txt)
    if string.len(txt) > 0 then
        obj:egShowWidget(kPanelTxt)
        local lbl = obj:egGetWidgetByName(kLabelWord)
        local lbls = obj:egGetWidgetByName(kLabelWords)
        obj:egSetLabelStr(kLabelWord,txt)
        obj:egSetLabelStr(kLabelWords,txt)
        lbl:setPosition(ccp(obj._posx + 360,lbl:getPositionY()))
        lbls:setPosition(ccp(obj._posxs + 360,lbls:getPositionY()))
        --local fadein = CCFadeIn:create(1)
        local moveby = CCMoveBy:create(1,ccp(-360,0))
       -- local spawn = CCSpawn:createWithTwoActions(fadein,moveby)
        local backout = CCEaseExponentialOut:create(moveby)
        
       -- local fadeins = CCFadeIn:create(1)
        local movebys = CCMoveBy:create(1,ccp(-360,0))
       -- local spawns = CCSpawn:createWithTwoActions(fadeins,movebys)
        local backouts = CCEaseExponentialOut:create(movebys)
        
        lbl:runAction(backout)
        lbls:runAction(backouts)
    else
       obj:egHideWidget(kPanelTxt)
    end
end
function __storylayer.showImg(obj,img)
	SoundHelper.playEffect(SoundList.click_paper_open)
    local showimg = obj:egGetWidgetByName(kImgBgs[obj._showimgIdx])
    local hideimg = obj:egGetWidgetByName(kImgBgs[obj._hideimgIdx])
    obj:egChangeImg(kImgBgs[obj._hideimgIdx],img)
    showimg:setVisible(false)
    hideimg:setVisible(true)
    --hideimg:setOpacity(255)
    --showimg:runAction(CCFadeOut:create(0.5))
    hideimg:runAction(CCFadeIn:create(0.5))
end
function __storylayer.bindPanelListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kPanelLayer,false)
        obj:showStory()
        local delay = CCDelayTime:create(0.5)
        local function callbackfunc()
            obj:egSetWidgetTouchEnabled(kPanelLayer,true)
        end
        local callFunc = CCCallFunc:create(callbackfunc)
        local sequence = CCSequence:createWithTwoActions(delay,callFunc)
        local widget = obj:egGetWidgetByName(kPanelLayer)
        widget:runAction(sequence)
    end
    obj:egBindTouch(kBtnRight,nil,nil,touchEnded,nil)
end

function __storylayer.showStory(obj,isfirst)
    local s_data = storyData[obj._idx]
    if not s_data then
        if account_data.guideList[GuideScene.def.kAtkScene] then --���ε�½����PVE�ؿ�������Ϣʱ
			local areaid = licenceLevelup[1].areaID
			local stageid = 1
			if account_data.unlockedPVE[areaid][1].nextUnlocked then
				local scene = TownScene.new()
				scene:egReplace()
			else
				local scene = GAtkScene.new(areaid,stageid)
				scene:egReplace()
			end
		else
			local scene = TownScene.new()
			scene:egReplace()
		end
    else
		if isfirst then obj:showImg(storyData[obj._idx].pic) end
        local txt = s_data.txt[obj._subidx]
        if txt then
            obj:showTxt(txt)
             obj._subidx = obj._subidx + 1
         else
            obj._idx = obj._idx + 1
            obj._subidx = 1
            obj:showStory(true)
        end
   end
end
StoryLayer = {}
function StoryLayer.new()
    local obj =  TouchWidget.new(JsonList.storyLayer)
    table_aux.unpackTo(__storylayer, obj)
    obj:init()
    obj:bindPanelListener()
    return obj
end
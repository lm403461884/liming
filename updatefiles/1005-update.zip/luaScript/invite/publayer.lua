local kBtnBack = "btn_return"
local kBtnClose = "btn_close"
--��Ϣ��̽���
local kBtnBuy = "btn_buymsg"
local kBtnAsk= "btn_askmsg"
local kLblAskVal = "lbl_ask_coin"
local kLblBuyVal = "lbl_buy_coin"
local kLblTime="lbl_note_ask"
local kImgAskCoin = "img_ask_coin"
local kPanelFree = "free_panel"
--������Ϣ���
local kPanelNote = "notice_panel"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kPanelTxt = "txt_panel"
local kLblNoteTxt = "lbl_note_txt_2"
local kImgTxtBg = "img_note_bg"
local kImgTxtMask="img_note_mask"
--Ӣ���б�
local kItemList = "itemlist"
local kCellW = 155

local kRedColor = ccc3(255,0,0)

local __publayer={}
function __publayer.init(obj,areaid)
    obj:showNotePanel(false)
    obj._pubherolist = {}
    obj._selectedhero = nil
    obj._askMsgNote = obj:egGetLabelStr(kLblTime)
    if account_data.invite then
        account_data.invite.left = account_data.invite.left - (os.time() - account_data.invite.st)
        account_data.invite.st = os.time()
        if account_data.invite.left<= 0 then  account_data.invite = nil end
    end
    obj:changeAskBtnState()
    obj:changeBuyBtnState()
    obj:loadHeroCard()
end
--��Ӷ��ʾ��
function __publayer.showNotePanel(obj,show)
    if show then
        obj:egShowWidget(kPanelNote)
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
        obj:egSetWidgetTouchEnabled(kBtnYes,true)
        obj:egSetWidgetTouchEnabled(kBtnNo,true)
    else
        obj:egHideWidget(kPanelNote)
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
    end
end

--�޸���Ϣ��̽��ť״̬
function __publayer.changeAskBtnState(obj)
    if account_data.invite then
        obj:egShowWidget(kImgAskCoin)
        obj:egShowWidget(kLblAskVal)
		obj:egHideWidget(kPanelFree)
        obj:egSetLabelStr(kLblTime,string.format("%s%s",Funs.formatTime(account_data.invite.left),obj._askMsgNote))
        obj:egSetLabelStr(kLblAskVal,numDef.askMsgPrice)
        if account_data.jewel < numDef.askMsgPrice then
            obj:egSetWidgetColor(kLblAskVal,kRedColor)
            obj:egSetWidgetEnabled(kBtnAsk,false)
        end
        obj:bindAskTimer()
    else
		obj:egShowWidget(kPanelFree)
        obj:egSetLabelStr(kLblTime,TxtList.askMsgNote)
        obj:egHideWidget(kImgAskCoin)
        obj:egHideWidget(kLblAskVal)
        obj:egSetWidgetEnabled(kBtnAsk,true)
    end
end
--�޸��ؽ��̽��ť״̬
function __publayer.changeBuyBtnState(obj)
    obj:egSetLabelStr(kLblBuyVal,numDef.buyMsgPrice)
    if account_data.jewel < numDef.buyMsgPrice then
        obj:egSetWidgetColor(kLblBuyVal,kRedColor)
        obj:egSetWidgetTouchEnabled(kBtnBuy,false)
    end
end
--��ȡ����Ϣ��������Ӣ���б�
function __publayer.getOrderedHeroInfoList(obj)
    local tbNum = {}
    local tb = {}
    for heroid ,_ in pairs(heroNumData) do
        if not account_data.heroList[heroid] then
            local num = account_data.heroInfoList[heroid] or 0
            if tb[num] then
                table.insert(tb[num],heroid)
            else
                tb[num]={heroid}
                table.insert(tbNum,num)
            end
        end
    end
    table.sort(tbNum,function(a,b) return a>b end)
    return tb,tbNum
end
--����Ӣ�ۿ�Ƭ��Ϣ
function __publayer.loadHeroCard(obj)
    local itemlist = obj:egGetScrollView(kItemList)
    local size = itemlist:getSize()
    local heroInfoList,heroNumtb = obj:getOrderedHeroInfoList()
    local cnt = 0
    for key,num in ipairs(heroNumtb) do
        for idx,heroid in ipairs(heroInfoList[num]) do
            local pubhero = PubHero.new(heroid)
            pubhero:egSetPosition(cnt*kCellW,0)
            obj._pubherolist[heroid] = pubhero
            obj:bindInviteCallBack(pubhero)
            obj:bindHireCallBack(pubhero)
            itemlist:addChild(pubhero:egNode())
            cnt = cnt + 1
        end
    end
    local neww = cnt * kCellW
    if neww > size.width then
        itemlist:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
end
--���µ���Ӣ�ۿ�Ƭλ��,�������Ϣ����ļ�����
function __publayer.reOrderPubHeros(obj)
    local heroInfoList,heroNumtb = obj:getOrderedHeroInfoList()
    local cnt = 0
    for key,num in ipairs(heroNumtb) do
        for idx,heroid in ipairs(heroInfoList[num]) do
            local pubhero = obj._pubherolist[heroid]
            pubhero:egSetPosition(cnt*kCellW,0)
            cnt = cnt + 1
        end
    end
end
--����ļ�ص�����
function __publayer.bindInviteCallBack(obj,pubhero)
    local function inviteCallback(sender)
        obj._selectedhero = sender
        local heroid = obj._selectedhero:getprop("heroid")
        --�������������
        SendMsg[934005](heroid)
		--�ھ���־������̸���,�����ļ
		task.updateTaskStatus(account_data,task.client_event_id.buy_hero,{heroid})
		----------------------------------------------------------
        local popherocard = PopHeroCard.new(heroid)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popherocard:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindPopCardCloseEvent(popherocard)
    end
    pubhero:onInvited(inviteCallback)
end
--�Ƴ�����ļ�ĳ�Ա�����¶�Ӣ�ۿ�Ƭ��������
function __publayer.bindPopCardCloseEvent(obj,popherocard)
    local function onclosedCallback()
        local heroid = obj._selectedhero:getprop("heroid")
		local herodata = hero_data.get(heroid,1)
        local tb = {type =heroid,lv = 1,eid = heroid*100 + 1,exp=herodata.exp}
		account_data.heroList[heroid] = tb
		account_data.heroInfoList[heroid] = nil
        account_data.equipments[tb.eid]={1,1}
        obj._pubherolist[heroid]:egRemoveSelf()
        obj:reOrderPubHeros()
    end
    popherocard:onPopCardClosed(onclosedCallback)
end
--ȷ�Ϲ�Ӷ
function __publayer.bindYesListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
		SoundHelper.playEffect(SoundList.buy_hero_01)
        obj:showNotePanel(false)--�ر���ʾ��
        -----------------------
        local heroid = obj._selectedhero:getprop("heroid")
        local s_cfg = hero_data.getConfig(heroid)
        local msgNum = account_data.heroInfoList[heroid] or 0
        local cost = baseCalc.getMsgforHero(msgNum,s_cfg.infoCnt)
        account_data.jewel = account_data.jewel - cost
        --�������������
        SendMsg[934008](heroid,cost)
		--�ھ���־������̸���,�ؽ���ļ
		task.updateTaskStatus(account_data,task.client_event_id.buy_hero,{heroid})
		----------------------------------------------------------
        local popherocard = PopHeroCard.new(heroid)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popherocard:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindPopCardCloseEvent(popherocard)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end

--ȡ����Ӷ
function __publayer.bindNoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
       local imgmask = obj:egGetWidgetByName(kImgTxtMask)
        local scaleto = CCScaleTo:create(0.2,0)
        local function callback()
            sender:setTouchEnabled(true)
            obj:showNotePanel(false)
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(scaleto,callfunc)
        imgmask:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end
--�ؽ��Ӷ�ص�����,�򿪹�Ӷȷ�Ͽ�
function __publayer.bindHireCallBack(obj,pubhero)
    local function hireCallback(sender)
        obj._selectedhero = sender
        obj:showNotePanel(true)
        local heroid = sender:getprop("heroid")
        local s_cfg = hero_data.getConfig(heroid)
        local msgNum = account_data.heroInfoList[heroid] or 0
        local cost = baseCalc.getMsgforHero(msgNum,s_cfg.infoCnt)
        obj:egSetLabelStr(kLblNoteTxt,string.format("%d %s %s",cost,TxtList.hire,s_cfg.heroName))
        local lbl = obj:egGetWidgetByName(kLblNoteTxt)
        local w = lbl:getPositionX() + lbl:getSize().width
        local panel = obj:egGetWidgetByName(kPanelTxt)
        panel:setSize(CCSizeMake(w,panel:getSize().height))
        local img = obj:egGetWidgetByName(kImgTxtBg)
        panel:setPosition(ccp((img:getSize().width-w)/2,img:getPositionY()))
        local imgmask = obj:egGetWidgetByName(kImgTxtMask)
        imgmask:setScale(0)
        local scaleto = CCScaleTo:create(0.2,1)
        local backout = CCEaseBackOut:create(scaleto)
        local callfunc = CCCallFunc:create(function()sender:enabledHireBtn() end)
        local sequence = CCSequence:createWithTwoActions(backout,callfunc)
        imgmask:runAction(sequence)
    end
     pubhero:onHired(hireCallback)
end
--����Ϣ��̽��ť��ʱ��
function __publayer.bindAskTimer(obj)
    local passed = 0
    local passedS = 0
    local function update(delta)
        passed = passed + delta
        if account_data.invite then
            if passed >= 1 then
                passedS = math.floor(passed)
                passed = passed - passedS
                account_data.invite.left = account_data.invite.left  - passedS
                account_data.invite.st = os.time()
                if account_data.invite.left > 0 then
                    obj:egSetLabelStr(kLblTime,string.format("%s%s",Funs.formatTime(account_data.invite.left),obj._askMsgNote))
                else
                    account_data.invite = nil
                end
            end
        else
            obj:changeAskBtnState()
            obj:egUnbindWidgetUpdate(kBtnAsk)
        end
    end
    obj:egBindWidgetUpdate(kBtnAsk,update)
end
--��һ�λ��Ӣ����Ϣ�Ĵ�������
function __publayer.bindFirstGainCallback(obj,popmail)
    local function callback(heroid)
        if obj._pubherolist[heroid] then 
            obj._pubherolist[heroid]:unlockHeroInfo()
        end
    end
    popmail:onFirstGainHeroMsg(callback)
end
--���Ӣ����Ϣʱ�Ĵ�������
function __publayer.bindGainMsgCallback(obj,popmail)
    local function callback(heroid)
        if obj._pubherolist[heroid] then
            obj._pubherolist[heroid]:updateHeroMsg()
        end
    end
    popmail:onGainHeroMsg(callback)
end
--Ӣ����Ϣ���������䶯��Ĵ�������
function __publayer.bindHeroMsgChangedCallback(obj,popmail)
    local function callback(heroid)
        obj:reOrderPubHeros()
    end
    popmail:onHeroMsgChanged(callback)
end
--�ֽ⽱����Ϣ��ϸ��ΪӢ����Ϣ����Դ
function __publayer.splitAwardinfo(obj,awardinfo)
    local msglist = {}
	local reslist = {}
	for key,item in pairs(awardinfo) do
		if type(item) == "table" then
			for heroid,msgnum in pairs(item) do
				table.insert(msglist,heroid)
				table.insert(msglist,msgnum)
			end
		else
			table.insert(reslist,KVariantList.coinName[key])
			table.insert(reslist,item)
		end
	end
	return msglist,reslist
end
--�ؽ��̽����
function __publayer.bindBuyMsgListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
        account_data.jewel = account_data.jewel - numDef.buyMsgPrice --��Ǯ
        local function onPopMailLoaded()
			 if account_data.jewel < numDef.buyMsgPrice then
				obj:egSetWidgetColor(kLblBuyVal,kRedColor)
				sender:setTouchEnabled(false)
			else
				sender:setTouchEnabled(true)
			end
			if account_data.jewel < numDef.askMsgPrice then
				obj:egSetWidgetColor(kLblAskVal,kRedColor)
				 obj:egSetWidgetEnabled(kBtnAsk,false)
			else
				obj:egSetWidgetEnabled(kBtnAsk,true)
			end
        end
        local awardinfo = baseCalc.getMsglargePrize(account_data)
        local msglist,reslist = obj:splitAwardinfo(awardinfo)
        --������Ϣ��������
        SendMsg[934007](numDef.buyMsgPrice,msglist,reslist)
        local popmail = PopMail.new(awardinfo,sender:getPositionX(),sender:getPositionY(),onPopMailLoaded)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmail:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindGainMsgCallback(popmail)
        obj:bindFirstGainCallback(popmail)
        obj:bindHeroMsgChangedCallback(popmail)
        --����Ϣ��������
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBuy,nil,nil,touchEnded,touchCanceled)
end

--��Ϣ��̽��ť
function __publayer.bindAskMsgListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_buy_button)
        local awardinfo = baseCalc.getMsgPrize(account_data)
        local msglist,reslist = obj:splitAwardinfo(awardinfo)
        if account_data.invite then--��Ǯ
			account_data.jewel = account_data.jewel - numDef.askMsgPrice
			--������Ϣ��������
			SendMsg[934007](numDef.askMsgPrice,msglist,reslist)
		else --���
			account_data.invite = {st=os.time(),left = numDef.inviteInterval} --�޸����ˢ��ʱ��
			obj:changeAskBtnState()--�޸İ�ť״̬
			--������Ϣ��������
			SendMsg[934006](msglist,reslist)
		end
		--�ھ���־������̸���,��Ϣ��̽
		task.updateTaskStatus(account_data,task.client_event_id.use_message_box)
		----------------------------------------------------------
        local function onPopMailLoaded()
			if account_data.jewel < numDef.askMsgPrice then
				obj:egSetWidgetColor(kLblAskVal,kRedColor)
				 sender:setTouchEnabled(false)
			else
				 sender:setTouchEnabled(true)
			end
			if account_data.jewel < numDef.buyMsgPrice then
				obj:egSetWidgetColor(kLblBuyVal,kRedColor)
				obj:egSetWidgetEnabled(kBtnBuy,false)
			else
				obj:egSetWidgetEnabled(kBtnBuy,true)
			end
        end
        local popmail = PopMail.new(awardinfo,sender:getPositionX(),sender:getPositionY(),onPopMailLoaded)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(popmail:egNode(),UILv.popLayer,UILv.popLayer)
        obj:bindGainMsgCallback(popmail)
        obj:bindFirstGainCallback(popmail)
        obj:bindHeroMsgChangedCallback(popmail)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnAsk,nil,nil,touchEnded,touchCanceled)
end
--���ذ�ť
function __publayer.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        local scene = TownScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
PubLayer={}
function PubLayer.new()
    local obj =  TouchWidget.new(JsonList.pubLayer)
    table_aux.unpackTo(__publayer, obj)
    obj:init()
    obj:bindBackListener()
    obj:bindBuyMsgListener()
    obj:bindAskMsgListener()
    obj:bindYesListener()
    obj:bindNoListener()
    return obj
end


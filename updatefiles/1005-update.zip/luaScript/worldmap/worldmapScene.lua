--[[--{{{
account_data = {

	worldAreaID = 4,

	unlockedPVE = {
		{areaStars=0, [1]={stars=0}, [2]={stars=0}, [3]={stars=0}, },
		{areaStars=0, [1] = {stars=0}},
		{areaStars=0, [1] = {stars=0}},
		{areaStars=0, [1] = {stars=0}},
		{areaStars=0},
		{areaStars=0},
		{areaStars=0},
		{areaStars=0},
		{areaStars=0},
		{areaStars=0},
	}
}
]]----}}}
worldmapScene = {}

function worldmapScene.new()--{{{
    SoundHelper.playBGM(SoundList.rish_bgm)
	local obj = {}
    Scene.install(obj)
    --table_aux.unpackTo(__townscene, obj)
	obj._baseWidget = MapLayer.new()
	obj._baseWidget:egAttachTo(obj)
	showEmDialog(obj,GuideScene.def.kMapScene) --加载引导信息	
	-------------
	obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
	return obj
end

local kImgHero = "btn_equip_hero"
local kLblHeroLv = "lbl_hero_lv"
local kImgBg = "img_hero_bg"
local kPanelMember = "panel_member" --member层

local kPoint1 = ccp(17,277)

local __equipheroitem={}
function __equipheroitem.init(obj,heroid)
    obj._heroid = heroid
	obj._equipCnt = 1
    obj:addprop("heroid",obj._heroid)
    obj._equip = {}
    obj:egChangeBtnImg(kImgHero,hero_data[heroid].photo,"","",UI_TEX_TYPE_PLIST)
	obj._heroData = account_data.heroList[heroid]
    obj:egSetBMLabelStr(kLblHeroLv,obj._heroData.lv)
end
function __equipheroitem.addEquip(obj,equipItem)
	local widget = obj:egGetWidgetByName(kPanelMember)
	local equipid = equipItem:getprop("eid")
	obj._equip[equipid] = equipItem
	local equipWidget = equipItem:egNode()
	if equipid == obj._heroData.eid then
		equipWidget:setPosition(kPoint1)
		equipWidget:setScale(0.85)
	else
		equipWidget:setPosition(ccp(10,132-(obj._equipCnt-1)*127))
		obj._equipCnt = obj._equipCnt+1
	end
	widget:addChild(equipWidget,0,obj._equipCnt)
end
--����װ��
function __equipheroitem.changeEquip(obj,equipid)
    local oldEquip = obj._equip[obj._heroData.eid]:egNode()
    local newEquip = obj._equip[equipid]:egNode()
    local x = newEquip:getPositionX()
    local y = newEquip:getPositionY()
    obj._heroData.eid = equipid
	oldEquip:setScale(1)
	oldEquip:setPosition(ccp(x,y))
	newEquip:setScale(0.85)
	newEquip:setPosition(kPoint1)
	obj._equip[obj._heroData.eid]:showWithAction()
	
end
--Ӣ�۵���¼�
function __equipheroitem.doClickItem(obj,sender)
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_paper_open)
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)
end
function __equipheroitem.bindClickListener(obj)
   
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickItem(sender)    
    end
	local function touchCanceled(sender)
       if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
    end
    obj:egBindTouch(kImgHero,nil,nil,touchEnded,touchCanceled)  
end
EquipHeroItem = {}
function EquipHeroItem.new(heroid)
   local obj ={}
   CocosWidget.install(obj,JsonList.equipHeroItem)
   BaseProp.install(obj)
   InnerProp.install(obj)
   table_aux.unpackTo(__equipheroitem,obj)
   obj:init(heroid)
   obj:bindClickListener()
   return obj
end
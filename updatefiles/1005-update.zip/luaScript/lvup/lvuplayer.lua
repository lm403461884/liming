--[[
train.config[1].research = {            --1�ų����о�����������Դ�����������������
    [2] = {gold,licence,oil,duration,
bodyImage={"",""} 
unlockItem={[1]='���С��', [2]='С����001.png'}},
 --1 ���������� 2������ͼƬ ��ÿ��������������һ�������� �����ڶ�������� �򰴴˸�ʽ˳�����������
--]]
local kNextLv = "ask_lv_val"
local kCostTime = "up_time_val"
local kUpItemImg = "up_item_img"
local kLiceneVal = "cost_licene_val"--
local kGoldVal = "cost_gold_val"--
local kOilVal = "cost_oil_val"--

local kBtnConfirm = "confirm_btn"
local kBtnCancel = "close_btn"
local kLblUnlock = "lbl_unlock"
local kPanelMask = "mask_panel"--
local kPanelBg = "lvup_bg"
local kActionShow = "show"--
local kActionHide = "hide"--
local kPanelLayer = "lvup_panel"
local kLblComfirm="comfirm_lbl"
local kImgCoins = {"img_1","img_2","img_3"}
local kLblVals = {"lbl_1","lbl_2","lbl_3"}
local kPanelVal = "val_panel"
local kImgTrainLv ="img_train_lv"
local kLblTrainLv = "lbl_train_lv"
local kLblArea = "lbl_area"

local kRedColor = ccc3(255,0,0)
local kBrownColor = ccc3(83,49,22)
local kCellW = 720
local kCellH = 106
local kMovedes=80
local kTotal = 3
local __lvuplayer={}
function __lvuplayer.confirmLvUp(obj,onclosed)
    SoundHelper.playEffect(SoundList.click_shop_goods)
    if obj._trainid==0 then obj:trainHeadLvUp() return end
    local d_data = account_data.train[obj._trainid]
       SendMsg[937002](obj._trainid,d_data.lv +1)
       local tb = {}
       tb.tlv = d_data.lv +1
       tb.left = obj._s_data.duration
       tb.st = os.time()
       tb.timeTotal = obj._s_data.duration
       account_data.train[obj._trainid].ri = tb
       account_data.gold = account_data.gold - (obj._s_data.gold or 0)
       account_data.oil = account_data.oil - (obj._s_data.oil or 0)
       obj:hideWithAction(onclosed)
end
--��ͷ����
function __lvuplayer.trainHeadLvUp(obj,onclosed)
    local lv = account_data.digLv
    local s_data = licenceLevelup[lv]
    SendMsg[932004](lv, lv + 1)
	--�ھ���־������̸���,ִ������
	task.updateTaskStatus(account_data,task.client_event_id.update_train_head,{lv})
	----------------------------------------------------------
	MissionHelper.unlockClientMission(lv+1)
    --[[local tb = {}
       tb.tlv = lv +1
       tb.left = s_data.duration
       tb.st = os.time()
       tb.timeTotal = s_data.duration
       account_data.train[obj._trainid].ri = tb
	account_data.gold = account_data.gold - (s_data.gold or 0)
	account_data.oil = account_data.oil - (s_data.oil or 0)	 --]]
	local cost = licenceLevelup[lv]
	account_data.gold = account_data.gold - (cost.gold or 0)
	account_data.diggingLvContext = {
    	timeTotal = cost.duration,
		st = os.time(),
		left = cost.duration,
	   }
    obj:hideWithAction(onclosed)
    
end

--ȷ������
function __lvuplayer.bindConfirmListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:confirmLvUp()
    end

	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnConfirm,nil,nil,touchEnded,touchCanceled)
end
--�ر�����ҳ��
function __lvuplayer.bindCancelListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCancel,nil,nil,touchEnded,touchCanceled)
end

function __lvuplayer.init(obj,idx)
    obj._trainid = idx
    if obj._trainid == 0 then--��ͷ���
        obj:showTrainHead(idx)
        return
    end
	obj._params = {}
    local d_data = account_data.train[obj._trainid]
    local train_cfg = train.config[obj._trainid]
    local nextlv = d_data.lv + 1
    local s_data = train_cfg.research[nextlv]
    obj._s_data = s_data
     obj._licence = s_data.licence or 1
    obj._gold = s_data.gold or 0
    obj._oil = s_data.oil or 0
    table.insert(obj._params,{"digLv",ImageList.comm_lv,obj._licence})
    if obj._gold > 0 then table.insert(obj._params,{"gold",ImageList.comm_gold,obj._gold}) end
    if obj._oil > 0 then  table.insert(obj._params,{"oil",ImageList.comm_oil,obj._oil})  end
    obj:egChangeImg(kUpItemImg,s_data.bodyImage[1])
    obj:egSetLabelStr(kNextLv,nextlv)
    obj:egSetLabelStr(kCostTime,Funs.formatTimeCh(s_data.duration,true,true,true,true,true))
    obj:egHideWidget(kImgTrainLv)
	obj:loadParams() 
	obj:resizeValPanel()
    if s_data.unlockItem=="" then
        obj:egHideWidget(kLblUnlock)
    else
        local widget = obj:egGetWidgetByName(kLblUnlock)
        local lbl =  tolua.cast(widget,"Label")
        lbl:setText(s_data.unlockItem)
        local size = lbl:getSize()
        if size.width > kCellW then
            lbl:setTextAreaSize(CCSizeMake(kCellW,kCellH))
        end
    end
    obj:showWithAction()
end
--��ͷ��������
function __lvuplayer.showTrainHead(obj,idx)
    obj._trainid = idx
    local lv = account_data.digLv
    local touchEnable = true
    local s_data = licenceLevelup[lv]
    obj:egShowWidget(kImgTrainLv)
    obj:egChangeImg(kUpItemImg,train.config[obj._trainid].research[account_data.digLv+1].bodyImage[1])
    obj:egSetLabelStr(kNextLv,lv+1)
    obj:egSetLabelStr(kCostTime,Funs.formatTimeCh(s_data.duration,true,true,true,true,true))
    obj:egSetLabelStr(kLblTrainLv,lv+1)
    local areaName = string.format(TxtList.needArea,scene_data[s_data.areaID].name)
    obj:egSetLabelStr(kLblArea,areaName)
    obj._gold = s_data.gold
    obj._oil = s_data.oil
    obj._star = s_data.stars
    obj._curstar = account_data.unlockedPVE[s_data.areaID].areaStars
    obj:egChangeImg(kImgCoins[3],ImageList.comm_gold,UI_TEX_TYPE_PLIST)
    --obj:egChangeImg(kImgCoins[2],ImageList.comm_oil,UI_TEX_TYPE_PLIST)
    obj:egChangeImg(kImgCoins[2],ImageList.star,UI_TEX_TYPE_PLIST)
    obj:egSetWidgetScale(kImgCoins[2],0.5)
    obj:egHideWidget(kImgCoins[1])
    obj:egHideWidget(kLblVals[1])
    if obj._gold>account_data.gold then
        obj:egSetLabelStr(kLblVals[3],string.format("%d%s%d",account_data.gold,"/",obj._gold))
        obj:egSetWidgetColor(kLblVals[3],kRedColor)
        touchEnable = false
    else
        obj:egSetLabelStr(kLblVals[3],obj._gold.."/"..obj._gold)
    end
    --[[if obj._oil>account_data.oil then
        obj:egSetLabelStr(kLblVals[2],string.format("%d%s%d",account_data.oil,"/",obj._oil))
        obj:egSetWidgetColor(kLblVals[2],kRedColor)
        touchEnable = false
    else
        obj:egSetLabelStr(kLblVals[2],obj._oil.."/"..obj._oil)
    end--]]
    if obj._star>obj._curstar then
        obj:egSetLabelStr(kLblVals[2],string.format("%d%s%d",obj._curstar,"/",obj._star))
        obj:egSetWidgetColor(kLblVals[2],kRedColor)
        touchEnable = false
    else
        obj:egSetLabelStr(kLblVals[2],obj._star.."/"..obj._star)
    end
    
    local widget = obj:egGetWidgetByName(kPanelVal)
    widget:setPosition(ccp(widget:getPositionX()-kMovedes,widget:getPositionY()))
     
    if s_data.unlockItem=="" then
        obj:egHideWidget(kLblUnlock)
    else
        local widget = obj:egGetWidgetByName(kLblUnlock)
        local lbl =  tolua.cast(widget,"Label")
        lbl:setText(s_data.unlockItem)
        local size = lbl:getSize()
        if size.width > kCellW then
            lbl:setTextAreaSize(CCSizeMake(kCellW,kCellH))
        end
    end
    if account_data.diggingLvContext then
        touchEnable = false
    end
    obj:egSetWidgetEnabled(kBtnConfirm,touchEnable)    
    obj:showWithAction()
end
function __lvuplayer.resizeValPanel(obj)
     local cnt = #obj._params
    if cnt < kTotal then
        for idx=cnt+1,kTotal do
            obj:egHideWidget(kLblVals[idx])
            obj:egHideWidget(kImgCoins[idx])
        end
        local widget = obj:egGetWidgetByName(kPanelVal)
        local offseth = widget:getSize().height * (kTotal-cnt)/kTotal/2
        widget:setPosition(ccp(widget:getPositionX(),widget:getPositionY() +  offseth))
    end
end
function __lvuplayer.loadParams(obj)
	obj:egSetWidgetEnabled(kBtnConfirm,true)
    for idx,item in ipairs(obj._params) do
        local color = kBrownColor
        obj:egSetLabelStr(kLblVals[idx],item[3])
        obj:egChangeImg(kImgCoins[idx],item[2],UI_TEX_TYPE_PLIST)
        if item[3] > account_data[item[1]] then 
            color = kRedColor 
			obj:egSetWidgetEnabled(kBtnConfirm,false)
        end
        obj:egSetWidgetColor(kLblVals[idx],color)
    end
    if account_data.train[obj._trainid].ri and account_data.train[obj._trainid].ri.left>0 then
        obj:egSetWidgetEnabled(kBtnConfirm,false)
    end
    
end
function __lvuplayer.hideWithAction(obj,onclosed)
    local function callback()
        AccountHelper:unlock(kStatePrompt)
        obj:egRemoveSelf()
        if onclosed then onclosed() end
    end
    obj:egSetWidgetTouchEnabled(kBtnCancel,false)
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __lvuplayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
LvUpLayer={}
function LvUpLayer.new(idx,callback)
   local obj =  TouchWidget.new(JsonList.lvupLayer)
    table_aux.unpackTo(__lvuplayer, obj)
    obj._onloaded = callback
    obj:init(idx)
    obj:bindConfirmListener()
    obj:bindCancelListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end
function showLvUp(idx,callback)
    local layer = LvUpLayer.new(idx,callback)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
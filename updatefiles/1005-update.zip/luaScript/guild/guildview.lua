local kLblguildName = "lbl_guild1"
local kLblNo = "lbl_no"
local kListMembers = "list_members"
local kImgLoading = "img_loading"
local kImgPrompt = "img_prompt1"
local kImgLongLine = "img_longline1"
local kImgBg = "img_bg"
local kBtnBack = "btn_back"
local kPanelLayer = "panel_guild_view"
local kPanelView = "panel_view"

local kMaxNum =6

local __guildview={}
function __guildview.initByMsg(obj,d_data)
   obj._listview = obj:egGetListView(kListMembers)
   obj._oldH=0
   obj._cid = d_data.clubid
   obj:egHideWidget(kImgPrompt)
   obj:egHideWidget(kLblguildName)
   obj:egHideWidget(kImgLongLine)
   obj:egHideWidget(kImgLoading)
   if club_cid and club_cid[obj._cid] then
       obj._data = club_cid[obj._cid]
       obj:loadMembers()
       obj:bindScrollListener()
   else
       SendMsg[938014](d_data.guid)
       AccountHelper:lock(kStateToViewGuild)
       obj:actionWait()
       obj:activeUpdate()
   end    
end
function __guildview.initByCid(obj,d_data)
   obj._listview = obj:egGetListView(kListMembers)
   obj._oldH=0
   obj._cid = d_data.cid
   obj:egHideWidget(kImgPrompt)
   obj:egHideWidget(kLblguildName)
   obj:egHideWidget(kImgLongLine)
   obj:egHideWidget(kImgLoading)
   if club_cid and club_cid[obj._cid] then
       obj._data = club_cid[obj._cid]
       obj:loadMembers()
   else
       SendMsg[938003](d_data.name)
       AccountHelper:lock(kStateToViewGuild)
       obj:actionWait()
       obj:activeUpdate()
   end    
end
--�ȴ�����
function __guildview.actionWait(obj)
    obj:egShowWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
end

function __guildview.activeUpdate(obj)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local function callback()
        if not AccountHelper:isLocked(kStateToViewGuild) then
            if club_cid[-1] then
                obj._data = club_cid[-1]
                imgWidget:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:loadMembers()
                obj:bindScrollListener()
                obj._egObj:unscheduleUpdate()
            else
                obj:egShowWidget(kLblNo)
                imgWidget:stopAllActions()
                obj:egHideWidget(kImgLoading)
                obj:egHideWidget(kImgLongLine)
                obj:egHideWidget(kImgPrompt)
                obj._egObj:unscheduleUpdate()
            end
        end   
    end 
    obj:egBindUpdateWithPriorityLua(callback)
end
function __guildview.loadMembers(obj)
   obj:egHideWidget(kImgPrompt) 
   obj:egHideWidget(kLblNo)
   obj:egShowWidget(kImgLongLine)  
   obj:egShowWidget(kListMembers)
   obj:egShowWidget(kLblguildName)
   obj:egSetLabelStr(kLblguildName,obj._data.clubName)
   obj:membersOrder(obj._data.members)
   obj:addGuildMembers(kMaxNum,3)
   if obj._maxNum>5 then
       obj:egShowWidget(kImgPrompt)
   end
   local kind = 3
   local guildInfo = GuildInfo.new(kind,obj._data)
   --guildInfo:egNode():setScale(0.85)
   --guildInfo:egNode():setPosition(ccp(104,65))
   obj:egAddChildTo(kPanelView,guildInfo:egNode(),2,2)
end
--�����Ա����
function __guildview.membersOrder(obj,members)
    local itemOrder = {}
    obj._guidOrder = {}
    for guid,item in pairs(members) do
        table.insert(itemOrder,item)
    end
    table.sort(itemOrder,function(a,b) return a.elo>b.elo end)
    for _,item in ipairs (itemOrder) do
        for guid,member in pairs (members)do
            if member.name == item.name then
                table.insert(obj._guidOrder,guid)
                break
            end
        end
    end
    obj._maxNum = #obj._guidOrder
    obj._startIdx = 1   
end
--���ع����Ա
function __guildview.addGuildMembers(obj,num,kind)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num-1,obj._maxNum)
    for idx = startIdx,obj._maxNum,1 do
        if idx > endIdx then break end
        local guid = obj._guidOrder[idx]
        local memberItem = GuildMemberItem.new(guid,kind,idx,obj._data)
        obj._listview:pushBackCustomItem(memberItem:egNode())
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __guildview.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:addGuildMembers(kMaxNum)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent)
end
function __guildview.showWithAction(obj,callback)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))
    
    local widget = obj:egGetWidgetByName(kPanelLayer)
    widget:setPosition(ccp(0,360))  
    local fadein = CCFadeIn:create(0.3)
    local moveto = CCMoveTo:create(0.3,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if callback then
        local callfunc = CCCallFunc:create(callback)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        widget:runAction(sequece)
    else
        widget:runAction(spawn)
    end
end

function __guildview.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		club_cid[-1]=nil
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end

function __guildview.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		club_cid[-1]=nil
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end
--kind==1 ����鿴����
--kind==2 ���а�鿴����
GuildView={}
function GuildView.new(kind,d_data)
    local obj = TouchWidget.new(JsonList.guildView)
    table_aux.unpackTo(__guildview, obj)
    if kind == 1 then
        obj:initByMsg(d_data)
    elseif kind == 2 then
        obj:initByCid(d_data)
    end    
    obj:bindPanelListener()
    obj:bindBackListener()
    return obj
end
function ShowGuildView(kind,msg,callback)
    local layer = GuildView.new(kind,msg)
    local scene = CCDirector:sharedDirector():getRunningScene()
	scene:removeChildByTag(UILv.popLayer,true)
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction(callback)    
end

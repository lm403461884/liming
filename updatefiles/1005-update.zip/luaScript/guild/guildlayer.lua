local kLblTrainLv = "lbl_lv"
local kLblTrainLvs = "lbl_lvs"
local kLblMyGuild = "lbl_guild1"
local kBtnMyGuild = "btn_guild1"
local kBtnSearch = "btn_guild2"
local kPanelBtn2 = "btn_panel_2"
local kBtnBack = "btn_return"
local kImgLongLine = "img_longline"
local kImgPrompt = "img_prompt"
local kListView = "listview_member"
local kPanelGuild = "panel_guild"
local kBtnItem = "Button_member"
local kBtnFire = "btn_fire"
local kBtnMember = "Button_member"
local kImgLoading = "img_loading"

local kPanelMsg = "msg_layer"
local kLblMsg = "lbl_msg"
local kLblDetail = "lbl_detail"
local kLblDetail2 = "lbl_detail2"
local kBtnOk = "btn_ok"
local kBtnNo = "btn_no"

local kFire = 1
local kDis = 2
local kLeave = 3
local kSetup = 4
local kMaxNum = 7
local typeSearch=1
local typeClub = 2
local kShowZorder = 2
local kHideZorder = 0
local __guildlayer={}
function __guildlayer.init(obj)
   obj._data = club_data
   obj._trainLv= account_data.train[train.def.guild].lv
   --obj._trainLv =1
   obj:egSetLabelStr(kLblTrainLv,string.format("%s%d","LV",obj._trainLv))
   obj:egSetLabelStr(kLblTrainLvs,string.format("%s%d","LV",obj._trainLv))
   obj:egHideWidget(kPanelMsg)
   obj:egHideWidget(kImgLoading)
   
   obj._memberItem = {}         --���Աitem
   obj._setupGuild = nil        --�洴���������
   obj._searchGuild = nil       --�������������
   obj._myGuildInfo = nil       --����info
   obj._selectedGuid = nil      --ѡ�е�guid

   if obj._data then 
       obj._isInGuild = true       --�ж��Ƿ���빫��
	   obj:loadMyGuild()
   else
       obj._isInGuild = false 
	    obj:setupGuild()
   end
   obj:bindSetupListener()
   obj:bindSearchListener()
end
--�޸Ĳ�ѯ�͹���ģ��Ľ����ȡ״̬
function __guildlayer.focusSearch(obj,focus)
	local btnGuild = tolua.cast(obj:egGetWidgetByName(kBtnMyGuild),"Button")
	local btnSearch = tolua.cast(obj:egGetWidgetByName(kBtnSearch),"Button")
	local searchpanel = obj:egGetWidgetByName(kPanelBtn2)
	local parentNode = searchpanel:getParent()
	if focus then
		btnSearch:setFocused(true)
		btnSearch:setTouchEnabled(false)
		btnGuild:setTouchEnabled(true)
		btnGuild:setFocused(false)
		parentNode:reorderChild(searchpanel,kShowZorder)
		parentNode:reorderChild(btnGuild,kHideZorder)
	else
		btnSearch:setFocused(false)
		btnSearch:setTouchEnabled(true)
		btnGuild:setTouchEnabled(false)
		btnGuild:setFocused(true)
		parentNode:reorderChild(searchpanel,kHideZorder)
		parentNode:reorderChild(btnGuild,kShowZorder)
	end
end
function __guildlayer.bindSetupListener(obj)
    local function touchEnded()
        if obj._isInGuild then 
           if obj._searchGuild then 
              obj._searchGuild:egRemoveSelf()
              obj._searchGuild = nil
           end
           obj:loadMyGuild()
       else
           if obj._searchGuild then 
              obj._searchGuild:egRemoveSelf()
              obj._searchGuild = nil
           end
           obj:setupGuild()
       end
   end
    obj:egBindTouch(kBtnMyGuild,nil,nil,touchEnded,nil)
end
 --�����������
function __guildlayer.bindSearchListener(obj)          
    local function touchEnded(sender)
		obj:focusSearch(true) --�޸ĵ��״̬����ʾZorder
       if obj._setupGuild then --setupLayer
          obj._setupGuild:egRemoveSelf() 
          obj._setupGuild = nil
       end
       if obj._isInGuild then --listview and guildInfo
          local listView = obj:egGetListView(kListView)
          --listView:removeAllChildren()
          obj:clearMemberList(listView)
          obj._myGuildInfo:egRemoveSelf()
          obj:egHideWidget(kListView)
          obj:egHideWidget(kImgLongLine)
          obj:egHideWidget(kImgPrompt)
          obj:egHideWidget(kImgLoading)
       end
       local searchlayer = SearchLayer.new()
       obj._searchGuild = searchlayer
       --searchlayer:onClicked(callback)
       obj:egAddChildTo(kPanelGuild,searchlayer:egNode(),3,3)
    end
    obj:egBindTouch(kBtnSearch,nil,nil,touchEnded,nil)
end

function __guildlayer.clearMemberList(obj,listView)--���listView�е�item
    for idx =1,listView:getChildrenCount() do
        item = listView:getItem(idx-1)
        listView:removeChildByTag(item:getTag(),true)
    end
    listView:removeAllItems()
end
--�ҵĹ������
function __guildlayer.loadMyGuild(obj)  
   obj:focusSearch(false)
   obj._oldH = 0
   obj:egSetLabelStr(kLblMyGuild,club_data.clubName) 
   obj:egHideWidget(kImgPrompt) 
   obj:egShowWidget(kImgLongLine)  
   obj:egShowWidget(kListView)
   local listView = obj:egGetListView(kListView)
   obj._listview = listView
   obj:bindScrollListener()
   obj:membersOrder(obj._data.members)
   obj:addGuildMembers(kMaxNum,typeClub)
   if obj._data.membersCount>5 then
      obj:egShowWidget(kImgPrompt)
   end
   local function callback ()--��ɢ/�뿪����ص�
        obj:egSetWidgetTouchEnabled(kBtnOk,true)
            obj:egHideWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)  
        if club_data.managerID==account_data.guid then
            obj:egShowWidget(kPanelMsg)
            obj:egSetLabelStr(kLblMsg,TxtList.disGuild)
            obj:bindOkListener(kDis)
            obj:bindNoListener()
        else
            obj:egSetWidgetTouchEnabled(kBtnOk,true)
            obj:egShowWidget(kPanelMsg)
            obj:egSetLabelStr(kLblMsg,TxtList.isLeaveGuild)
            obj:bindOkListener(kLeave)
            obj:bindNoListener()
        end 
   end
   local guildInfo = GuildInfo.new()
   guildInfo:onClicked(callback)
   obj._myGuildInfo = guildInfo
   obj:egAddChildTo(kPanelGuild,guildInfo:egNode(),3,3)     
end
--�����Ա����
function __guildlayer.membersOrder(obj,members)
    local itemOrder = {}
    obj._guidOrder = {}
    for guid,item in pairs(members) do
        table.insert(itemOrder,item)
    end
    table.sort(itemOrder,function(a,b) return a.elo>b.elo end)
    for _,item in ipairs (itemOrder) do
        for guid,member in pairs (members)do
            if member.name == item.name then
                table.insert(obj._guidOrder,guid)
                break
            end
        end
    end
    obj._maxNum = obj._data.membersCount
    obj._startIdx = 1   
end
--���ع����Ա
function __guildlayer.addGuildMembers(obj,num,kind)
    local startIdx = obj._startIdx
    local endIdx = math.min(startIdx + num-1,obj._maxNum)
    for idx = startIdx,obj._maxNum,1 do
        if idx > endIdx then break end
        local guid = obj._guidOrder[idx]
        local memberItem = GuildMemberItem.new(guid,kind,idx)
        obj._memberItem[guid] = memberItem
        if guid == account_data.guid then memberItem:markMyself() end
        obj._listview:pushBackCustomItem(memberItem:egNode())
        obj:bindTouchEventListener(memberItem)
    end
    obj._startIdx = endIdx + 1
end
--���б������¼�
function __guildlayer.bindScrollListener(obj)
    local function scrollEvent(sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLL_TO_BOTTOM then
            local curH = obj._listview:getInnerContainerSize().height
            if obj._oldH<curH then
                obj:addGuildMembers(kMaxNum)
                obj._oldH = curH
            end
        end
    end
    obj._listview:addEventListenerScrollView(scrollEvent)
end
function __guildlayer.bindTouchEventListener(obj,memberItem)
    local function callback(sender) 
       if obj._selectedGuid then
          obj._memberItem[obj._selectedGuid]:egHideWidget(kBtnFire)
          obj._memberItem[obj._selectedGuid]:setFocused(false)
           obj._selectedGuid = memberItem:getprop("guid")
       else
          obj._selectedGuid = memberItem:getprop("guid")
       end
       if obj._data.managerID == account_data.guid and obj._selectedGuid ~=account_data.guid  then
          memberItem:egShowWidget(kBtnFire)
          memberItem:setFocused(true)
       end
    end
    local function btnFireTouch(item)--��ͻ�Ա�ص�
        obj:egSetWidgetTouchEnabled(kBtnOk,true)
        obj:egShowWidget(kPanelMsg)
        obj:egHideWidget(kLblDetail)
        obj:egHideWidget(kLblDetail2)
        obj:egSetLabelStr(kLblMsg,TxtList.fireMember)
        obj:bindOkListener(kFire,item)
        obj:bindNoListener() 
    end
    memberItem:egBindTouch(kBtnItem,nil,nil,callback,nil)
    memberItem:onClicked(btnFireTouch)
end
 --�����������
function __guildlayer.setupGuild(obj)   
   obj:focusSearch(false)
   obj:egSetLabelStr(kLblMyGuild,TxtList.setupGuild) 
   obj:egHideWidget(kListView)
   obj:egHideWidget(kImgLongLine)
   obj:egHideWidget(kImgPrompt)
   local function callback(kind) --��������ص�
        obj:egSetWidgetTouchEnabled(kBtnOk,true)
        obj:egShowWidget(kPanelMsg)
        obj:egHideWidget(kBtnNo)
        local btnOk = obj:egGetWidgetByName(kBtnOk)
        btnOk:setPosition(ccp(634,265))
        if kind ==1 then
            obj:egShowWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)
            obj:egSetLabelStr(kLblMsg,TxtList.guildName)
            obj:bindOkListener()
        elseif kind ==2 then
            obj:egShowWidget(kLblDetail2)
            obj:egHideWidget(kLblDetail)
            obj:egSetLabelStr(kLblMsg,TxtList.guildInfo)
            obj:bindOkListener()
        elseif kind == 3 then
            obj:egHideWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)
            obj:egSetLabelStr(kLblMsg,TxtList.setupSuccess)
            obj:bindOkListener(kSetup)
        elseif kind == 4 then
            obj:egHideWidget(kLblDetail)
            obj:egHideWidget(kLblDetail2)
            obj:egSetLabelStr(kLblMsg,TxtList.setupFaild)
            obj:bindOkListener()    
        end    
   end
   local setupGuild = SetupLayer.new()
   setupGuild:onClicked(callback)
   obj._setupGuild = setupGuild
   obj:egAddChildTo(kPanelGuild,setupGuild:egNode(),3,3)
end

function __guildlayer.bindOkListener(obj,kind,item)
    local function touchEnded()
        obj:egSetWidgetTouchEnabled(kBtnOk,false)
        if kind == kFire then
            local guid = item:getprop("guid")
            local idx = item:getprop("rank")
            obj._listview:removeItem(idx-1)
            SendMsg[938009](guid)
            obj._memberItem[obj._selectedGuid]=nil
            obj._selectedGuid = nil
            club_data.members[guid]=nil
            club_data.membersCount = club_data.membersCount - 1
            for guid,membersItem in pairs(obj._memberItem) do
                local rank = membersItem:getprop("rank")
                if rank >idx then
                   membersItem:setIdx(rank-1)
                end
            end
        elseif kind == kDis then
            print("dissolve guild")  
	        SendMsg[938010]()
	        club_data=nil
	        local scene = GuildScene.new()
            scene:egReplace()
        elseif kind == kLeave then
           print("leave guild")                                
           SendMsg[938006]() 
           club_data=nil
	       local scene = GuildScene.new()
           scene:egReplace()  
        elseif kind == kSetup then
           local scene = GuildScene.new()
           scene:egReplace()  
        end
        obj:egHideWidget(kPanelMsg)
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __guildlayer.actionWait(obj)
    obj:egShowWidget(kImgLoading)
    local imgWidget = obj:egGetWidgetByName(kImgLoading)
    local rotateby = CCRotateBy:create(1,360)
    local repeatforever = CCRepeatForever:create(rotateby)
    imgWidget:runAction(repeatforever) 
end

function __guildlayer.bindNoListener(obj)
     local function touchEnded()
        obj:egHideWidget(kPanelMsg)
        --obj:egSetWidgetTouchEnabled(kBtnSelect,true)
    end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,nil)
end
function __guildlayer.bindBackListener(obj)
   local function touchEnded(sender)
       sender:setTouchEnabled(false)
       local scene = TownScene.new()
       scene:egReplace()
   end
   obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
function __guildlayer.activeUpdata(obj)
    local function guildUpdate()
        if not AccountHelper:isLocked(kStateGuildData) then
            obj:egUnbindUpdate()
            obj:getClubHonor()
             local imgWidget = obj:egGetWidgetByName(kImgLoading)
             imgWidget:stopAllActions()
             obj:egHideWidget(kImgLoading)
            obj:init()
        end
    end
    obj:egBindUpdate(guildUpdate)
end
GuildLayer={}
function GuildLayer.new()
   local obj = TouchWidget.new(JsonList.guildLayer)
   table_aux.unpackTo(__guildlayer,obj)
   if club_data then
       SendMsg[938003](club_data.clubName)
       AccountHelper:lock(kStateGuildData)
       obj:activeUpdata()
       obj:actionWait()
   else
       obj:init()
   end    
   obj:bindBackListener()
   return obj
end
function __guildlayer.getClubHonor()--{{{
	local t = {}
	for _, mbr in pairs(club_data.members) do
		t[#t+1] = mbr
	end
	table.sort(t, 
		function(mbr_a, mbr_b) 
			return mbr_a.elo > mbr_b.elo 
		end)
	for idx, mbr in ipairs(t) do
		if idx >= 1 and idx <= 10 then
			mbr.power = 0.05
		elseif idx >= 11 and idx <= 20 then
			mbr.power = 0.025
		elseif idx >= 21 and idx <= 30 then
			mbr.power = 0.012
		elseif idx >= 31 and idx <= 40 then
			mbr.power = 0.01
		else
			mbr.power = 0.003
		end
		local lastreward = mbr.reward or 0
		lastreward = lastreward + mbr.elo * 0.4 + club_data.reward * mbr.power
        mbr.reward = math.max(1, math.floor(lastreward))
	end
end--}}}
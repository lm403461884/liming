local kImgItem = "head_pic"
local kLblName = "lbl_name"
local kLblLv = "lbl_lv"
local kBtnItem = "btn_unit"
local kPanelTxt = "txt_panel"
local kUType = 1
local __growhero ={}
function __growhero.init(obj,heroData)
    obj._heroData = heroData
    obj._heroid = heroData.type
    obj._lv = heroData.lv
    obj._s_cfg = hero_data[obj._heroid]
    obj:egSetLabelStr(kLblName,obj._s_cfg.heroName)
    obj:egSetLabelStr(kLblLv,string.format("LV%d",obj._lv))
    obj:egChangeImg(kImgItem,obj._s_cfg.headPic,UI_TEX_TYPE_PLIST)
	local maxLv = account_data.digLv*numDef.unitLvFactor
	if not obj._s_cfg[obj._lv+1] or obj._lv >= maxLv then
		obj:egShowWidget(kPanelTxt)
	else
		obj:egHideWidget(kPanelTxt)
	end
end
function __growhero.doClickItem(obj,sender)
	sender:setTouchEnabled(false)
	SoundHelper.playEffect(SoundList.click_shop_goods)
	local function callback()
            sender:setTouchEnabled(true)
	end
	showGrowInfo(obj._heroid,obj._lv,callback)
end
--�󶨵���¼�
function __growhero.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:doClickItem(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnItem,nil,nil,touchEnded,touchCanceled)
end
function __growhero.bindLvTimer(obj)
    local function update(delta)
		local lv = obj._heroData.lv
		if obj._lv ~= lv then
			obj._lv = lv
			obj:egSetLabelStr(kLblLv,string.format("LV%d",obj._lv))
			local maxLv = account_data.digLv*numDef.unitLvFactor
			if not obj._s_cfg[obj._lv+1] or obj._lv >= maxLv then
				obj:egShowWidget(kPanelTxt)
			else
				obj:egHideWidget(kPanelTxt)
			end
		end
	end
	obj:egBindWidgetUpdate(kLblLv,update)
end
GrowHero = {}
function GrowHero.new(heroData)
    local obj={}
    CocosWidget.install(obj,JsonList.growHero)
    table_aux.unpackTo(__growhero, obj)
    obj:init(heroData)
    obj:bindClickListener()
	obj:bindLvTimer()
    return obj
end
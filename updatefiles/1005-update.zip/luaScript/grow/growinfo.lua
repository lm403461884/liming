local kPanelLayer = "pvp_bg"
local kImgPoster = "unit_pic"
local kLblName = "lbl_name"
local kLblHP="lbl_hp"
local kLblLV = "lbl_lv"
local kLblATK ="lbl_atk"
local kLblHPNew="lbl_hp_new"
local kLblLVNew = "lbl_lv_new"
local kLblATKNew ="lbl_atk_new"
--�߼�ѵ��
local kLblValG = "lbl_jewel"
--��ť
local kBtnChange = "btn_change"
local kBtnBack = "btn_back"
local kBtnGrade = "btn_grade"

local kPanelTrain = "panel_train"
local kPanelNote="note_bar"
local kPanelGrade = "panel_grade"

local kTypeHero = 1
local kRandomNum = 100
local kMoveDistance = 100
local kPromptZorder = 3
local kRedColor = ccc3(255,0,0)
local __growinfo={}
function __growinfo.init(obj,itemid,itemlv)  
   obj._id = itemid
   obj._lv = itemlv

   obj._s_cfg = hero_data[obj._id]
   obj._name = obj._s_cfg.heroName

   obj:initItem()
   obj:showWithAction()
end
--������ʾ����
function __growinfo.initItem(obj)
    local curData = obj._s_cfg[obj._lv]
    local newData = obj._s_cfg[obj._lv+1]
    local maxLv = account_data.digLv*numDef.unitLvFactor
    obj._curData = curData
    obj._newData = newData
    obj:egSetLabelStr(kLblName,obj._name)
    obj:egSetLabelStr(kLblLV,string.format("%s%d", obj:egGetLabelStr(kLblLV),obj._lv))
    obj:egSetLabelStr(kLblHP,string.format("%s%d", obj:egGetLabelStr(kLblHP),curData.maxHP))
    obj:egSetLabelStr(kLblATK,string.format("%s%d", obj:egGetLabelStr(kLblATK),curData.power))
    obj:egChangeImg(kImgPoster,obj._s_cfg.photo,UI_TEX_TYPE_PLIST)
    
    if not obj._s_cfg[obj._lv+1] or obj._lv >= maxLv  then
       obj:egHideWidget(kBtnGrade)
       obj:egHideWidget(kPanelTrain)
       obj:egHideWidget(kLblHPNew)
       obj:egHideWidget(kLblLVNew) 
       obj:egHideWidget(kLblATKNew) 
    else
        obj:egHideWidget(kPanelNote)
        obj:egSetLabelStr(kLblLVNew,string.format("%s%d", obj:egGetLabelStr(kLblLVNew),obj._lv+1))
        obj:egSetLabelStr(kLblHPNew,string.format("%s%d", obj:egGetLabelStr(kLblHPNew),newData.maxHP))
        obj:egSetLabelStr(kLblATKNew,string.format("%s%d", obj:egGetLabelStr(kLblATKNew),newData.power))
        obj:egSetLabelStr(kLblValG,curData.tRuby)
		if curData.tRuby > account_data.jewel then
			obj:egSetWidgetColor(kLblValG,kRedColor)
			obj:egSetWidgetTouchEnabled(kBtnGrade,false)
		end
    end
end
function __growinfo.hideWithAction(obj,callbackfunc)
    local function callback()
        obj:egRemoveSelf()
        if callbackfunc then callbackfunc() end
    end
    local widget = obj:egGetWidgetByName(kImgPoster)
    widget:runAction(CCFadeOut:create(0.4))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(baseWidget:getPositionX(),720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    baseWidget:runAction(squence)
    local growlayer = AccountHelper:get(kGrowLayer)
    growlayer:setVisible(true)
end
function __growinfo.showWithAction(obj)
    local widget = obj:egGetWidgetByName(kImgPoster)
    widget:runAction(CCFadeIn:create(0.4))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(baseWidget:getPositionX(),720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(baseWidget:getPositionX(),0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
	if obj._onloaded then
		local callfunc = CCCallFunc:create(obj._onloaded)
		local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
		baseWidget:runAction(sequece)
	else
		baseWidget:runAction(spawn)
	end
	local growlayer = AccountHelper:get(kGrowLayer)
	growlayer:setVisible(false)
end
--�رձ�ҳ��
function __growinfo.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
--�رձ�ҳ��
function __growinfo.bindChangeListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_back_button)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:hideWithAction()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnChange,nil,nil,touchEnded,touchCanceled)
end
--�߼�ѵ��
function __growinfo.bindGradeLister(obj)

    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        if obj._curData.tRuby <= account_data.jewel then
            SoundHelper.playEffect(SoundList.click_buy_button)
            account_data.jewel = account_data.jewel - obj._curData.tRuby
			SendMsg[936005](kTypeHero,obj._id,1,0)
			--�ھ���־�������
			task.updateTaskStatus(account_data,task.client_event_id.hero_levelup,{obj._id,obj._lv+1})
			----------------------------------------------------------
			showGrowRate(obj._id) 
            obj:egRemoveSelf()
            
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGrade,nil,nil,touchEnded,touchCanceled)
end

GrowInfo={}
function GrowInfo.new(itemid,itemlv,onloaded)
    local obj = TouchWidget.new(JsonList.growInfo)
    table_aux.unpackTo(__growinfo, obj)
    obj._onloaded = onloaded
    obj:init(itemid,itemlv)
    obj:bindBackListener()
    obj:bindChangeListener()
	obj:bindGradeLister()
    return obj
end
function showGrowInfo(itemid,itemlv,onloaded)
    local layer = GrowInfo.new(itemid,itemlv,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

local kBarLoad = "bar_mid"
local kImgHeader = "img_header"
local kLblNote = "lbl_note"
local kDownLoadedVer = "downloaded-version-code"
local kCurrentVer = "current-version-code"
local __verctrscene = {}
function __verctrscene.init(obj)
	local currentVer = CCUserDefault:sharedUserDefault():getIntegerForKey(kCurrentVer)
	if currentVer == 0 then 
		CCUserDefault:sharedUserDefault():setIntegerForKey(kCurrentVer,__version)
		CCUserDefault:sharedUserDefault():setIntegerForKey(kDownLoadedVer,__version)
	end
	RSHelper:initUpdateEngine()
	UpdateEngine:update()
	obj:bindVerTimer()
end
function __verctrscene.formatVerCode(obj,vernum)
	local v1 = math.floor(vernum/1000)
	local v2 = math.floor(vernum%1000/100)
	local v3 = math.floor(vernum%100/10)
	local v4 = math.floor(vernum%10)
	return string.format("%d.%d.%d.%d",v1,v2,v3,v4)
end
function __verctrscene.handlError(obj,msgcode)
	if msgcode == 3  then --û�п��Ը��µİ汾
		obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			CCDirector:sharedDirector():endToLua()
		end
		local msglayer = MsgLayer.new(nil,TxtList.verError,1,callback)
		msglayer:show()
	elseif msgcode == 7 then
		obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			CCDirector:sharedDirector():endToLua()
		end
		local msglayer = MsgLayer.new(nil,TxtList.verError,1,callback)
		msglayer:show()
	else --����ԭ�������ԭ����ɵĸ���ʧ��
		obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
		local function callback()
			local  scene = LogoScene.new()
			scene:egReplace()
		end
		local msglayer = MsgLayer.new(nil,TxtList.updateError,1,callback)
		msglayer:show()
	end
end
function __verctrscene.jumpToLogin(obj)
	obj._logname = CCUserDefault:sharedUserDefault():getStringForKey("name")
	obj._logpwd = CCUserDefault:sharedUserDefault():getStringForKey("pwd")
	if obj._logname == "" then
		obj._logname,obj._logpwd = AccountHelper:getDevMac()
	end
	if obj._logname == "" then
		local scene = LoginScene.new()
		scene:egReplace()
	else
		obj:startListen()
	end
end
function __verctrscene.startListen(obj)
    local  function callback()
            local state = RSHelper:getState()
			if state == 6 then
				obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
				RSHelper:handleRSMsg()
            elseif state < 0  then
				print("state:",state)
				RSHelper:disconnect()
               obj._baseWidget:egUnbindWidgetUpdate(kImgHeader)
				local function callback()
					local scene = LogoScene.new()
					scene:egReplace()
				end
				local msglayer = MsgLayer.new(nil,TxtList.connFailed,1,callback)
				msglayer:show()
			end
    end
	RSHelper:connect()
	RSHelper:sendLogMsg(obj._logname,obj._logpwd)
    obj._baseWidget:egBindWidgetUpdate(kImgHeader,callback)
end
function __verctrscene.bindVerTimer(obj)
	local curVerTxt = ""
	local function update(delta)
		if UpdateEngine:hasNewMsg() then
			local msgtype,msgcode = UpdateEngine:getNewMsg()
			if msgtype == 1 then --���³���
				obj:handlError(msgcode)
			elseif msgtype == 2 then --��鵽�汾����
				obj._baseWidget:egSetLabelStr(kLblNote,TxtList.updateMsg[2])
				print("get new ver")
			elseif msgtype == 3 then --��ʼ����
				print("start down load")
				curVerTxt = obj:formatVerCode(msgcode)
				obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[3],curVerTxt))
				obj._baseWidget:egSetBarPercent(kBarLoad,0)
			elseif msgtype == 4 then --������
			    obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[9],curVerTxt,msgcode,"%"))
				obj._baseWidget:egSetBarPercent(kBarLoad,msgcode)
			elseif msgtype == 5 then --���ؽ���
				print("down load end")
				obj._baseWidget:egSetBarPercent(kBarLoad,100)
			elseif msgtype == 6 then --��ʼ��ѹ
				print("start un zip ")
				obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[4],obj:formatVerCode(msgcode)))
			elseif msgtype== 7 then --��ѹ���
				print("finish un zip ")
				obj._baseWidget:egSetLabelStr(kLblNote,string.format(TxtList.updateMsg[5],obj:formatVerCode(msgcode)))
				CCUserDefault:sharedUserDefault():setIntegerForKey(kDownLoadedVer, msgcode)
			elseif msgtype==8 then --�������
				print("update succ ")
				local curVer = CCUserDefault:sharedUserDefault():getIntegerForKey(kDownLoadedVer)
				CCUserDefault:sharedUserDefault():setIntegerForKey(kCurrentVer,curVer )
				preloadAllFile()
				obj:jumpToLogin()
			end
		end
	end
	obj._baseWidget:egBindWidgetUpdate(kImgHeader,update)
end
VerCtrScene = {}

function VerCtrScene.new()
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__verctrscene, obj)
    Scene.install(obj)
    obj._baseWidget = TouchWidget.new(JsonList.loadingLayer)
    obj._baseWidget:egAttachTo(obj)
    obj:init()
    return obj
end
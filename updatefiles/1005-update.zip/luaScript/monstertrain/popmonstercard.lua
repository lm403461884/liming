local kBtnClose="btn_close"
local kImgLight = "img_light"
local kImgMask = "img_dark_mask"
local kLblName = "lbl_name"
local kImgPhoto = "img_photo"
local kLblAtk = "lbl_atk_val"
local kLblHP = "lbl_hp_val"
local kLblLv = "lbl_lv"
local kLblCost = "lbl_cost_val"
local kImgCard = "member_bg"
local kLblMsg = "lbl_msg"
local __popmonstercard={}
function __popmonstercard.init(obj,monsterid)
  --��ʾ�ŷ���ʾ��
    obj._monsterid = monsterid
	local monsterlv = account_data.monsterLvLook[obj._monsterid] or 1
    local s_cfg =  monster_data.getConfig(obj._monsterid)
    local s_data =  monster_data.get(obj._monsterid,monsterlv )
    obj:egSetBMLabelStr(kLblLv,monsterlv)
	obj:egSetLabelStr(kLblHP,s_data.maxHP)
	obj:egSetLabelStr(kLblAtk,s_data.power)
	obj:egSetLabelStr(kLblCost,s_data.consume)
    obj:egSetLabelStr(kLblName,s_cfg.name)
    obj:egChangeImg(kImgPhoto,s_cfg.photo,UI_TEX_TYPE_PLIST)
    obj:egHideWidget(kBtnClose)
    
    obj:showWidthAction()
end
function __popmonstercard.showWidthAction(obj)
    local cardbg = obj:egGetWidgetByName(kImgCard)
    cardbg:setScale(0)
    local scaleto = CCScaleTo:create(0.5,1)
    local backout = CCEaseBackOut:create(scaleto)
    local function callback()
        obj:egShowWidget(kBtnClose)
        local moveby1 = CCMoveBy:create(1,ccp(0,-10))
        local moveby2 = CCMoveBy:create(1,ccp(0,10))
        local sequence1 = CCSequence:createWithTwoActions(moveby1,moveby2)
        local repeatever = CCRepeatForever:create(sequence1)
        cardbg:runAction(repeatever)
        if obj._onloaded then obj._onloaded() end
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(backout,callfunc)
    cardbg:runAction(sequence)
    
    local lightbg = obj:egGetWidgetByName(kImgLight)
    local rotateby1 = CCRotateBy:create(2,37.2)
    local scaleto1 = CCScaleTo:create(2,0.9)
    local rotateby2 = CCRotateBy:create(2,37.2)
    local scaleto2 = CCScaleTo:create(2,1)
    local spawn1 = CCSpawn:createWithTwoActions(rotateby1,scaleto1)
    local spawn2 = CCSpawn:createWithTwoActions(rotateby2,scaleto2)
    local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
    local repeatever = CCRepeatForever:create(sequence)
    lightbg:runAction(repeatever)
    
    local widget = obj:egGetWidgetByName(kImgMask)
    widget:setOpacity(0)
    widget:runAction(CCFadeTo:create(0.2,180))
    local lblmsg = obj:egGetWidgetByName(kLblMsg)
    lblmsg:setScale(0)
    lblmsg:runAction(CCEaseBackOut:create(CCScaleTo:create(0.5,1)))
end
function __popmonstercard.onPopCardClosed(obj,callback)
    obj._closeCallback = callback
end
--�رհ�ť
function __popmonstercard.bindCloseListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        if obj._closeCallback then obj._closeCallback() end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end

PopMonsterCard={}
function PopMonsterCard.new(monsterid,onloaded)
    local obj =  TouchWidget.new(JsonList.popMonsterCard)
    table_aux.unpackTo(__popmonstercard, obj)
    obj._onloaded = onloaded
    obj:init(monsterid)
    obj:bindCloseListener()
    return obj
end

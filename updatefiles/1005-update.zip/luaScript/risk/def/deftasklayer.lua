local kBtnAward = "btn_look_award"
local kLblTimeEnd = "lbl_time_end"
local kLblTaskNum = "lbl_task_num"
local kLblTimeUpdate = "lbl_time_update"
local kLblStarNum = "lbl_star_num"
local kLblNo = "lbl_no"
local kListview = "List_def_task"
local kBtnBack = "btn_back"
local kBtnToDig = "btn_digscene" 
local kPanelLayer = "panel_def" 

local __deftasklayer={}

function __deftasklayer.init(obj)
   obj:egSetLabelStr(kLblStarNum,account_data.pveGuardQuest.stars)
   obj:egSetLabelStr(kLblTaskNum,#account_data.pveGuardQuest.qid.."/"..numDef.pveGuardQuestMaxCount)
   obj:egHideWidget(kLblNo)
   obj:loadDefTask()
   obj:activeTimer()
   obj:showWithAction()
	
end
function __deftasklayer.loadDefTask(obj)
    local listview = obj:egGetListView(kListview)
    local taskList = account_data.pveGuardQuest.qid
    for idx,guardID in ipairs(taskList) do
        local def_data = pveGuardQuery.getName(guardID)
        local taskitem = DefTaskItem.new(guardID)
        listview:insertCustomItem(taskitem:egNode(),0)
        obj:clickTaskItem(taskitem,idx)
    end
    if #taskList == 0 then
        obj:egShowWidget(kLblNo)
    end
end
--����item�ص�
function __deftasklayer.clickTaskItem(obj,taskitem,idx)
    local guardID = taskitem:getprop("guardID")
    local function callback(onload)
        local defpreview = DefPreview.new(guardID,onload,idx)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(defpreview:egNode(),UILv.popLayer,UILv.popLayer)
    end
    taskitem:onClicked(callback)
end

function __deftasklayer.activeTimer(obj)
    obj._oldTaskNum = # account_data.pveGuardQuest.qid
    local function update(delta)
        obj._lefttime =  account_data.pveGuardQuest.left
        local time = Funs.formatTime(obj._lefttime)
        obj:egSetLabelStr(kLblTimeUpdate,time)
        if  obj._oldTaskNum ~= # account_data.pveGuardQuest.qid then--ˢ������
            obj:clearItems()
            obj:loadDefTask()
            obj._oldTaskNum = # account_data.pveGuardQuest.qid
        end
    end
    obj:egBindWidgetUpdate(kLblTimeUpdate,update)
end
function __deftasklayer.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128))
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
function __deftasklayer.clearItems(obj)
    local listview = obj:egGetListView(kListview)
    for idx = 1,obj._oldTaskNum  do
       local item = listview:getItem(idx-1)
        listview:removeChildByTag(item:getTag(),true)
    end
	listview:removeAllItems()
	listview:jumpToTop()
end
function __deftasklayer.bindLookAward(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setEnabled(false)
        local function callback() sender:setEnabled(true) end
        local defaward = DefAward.new(callback)
        local scene = CCDirector:sharedDirector():getRunningScene()
        scene:addChild(defaward:egNode(),UILv.popLayer,UILv.popLayer)
    end
    obj:egBindTouch(kBtnAward,nil,nil,touchEnded,nil)
end
function __deftasklayer.bindDigListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_open)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        local scene = DigScene.new(obj._idx)
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnToDig,nil,nil,touchEnded,touchCanceled)   
end
function __deftasklayer.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        AccountHelper:unlock(kStatePrompt)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end
function __deftasklayer.bindBackListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        AccountHelper:unlock(kStatePrompt)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
DefTaskLayer={}
function DefTaskLayer.new(onloaded)
    local obj =  TouchWidget.new(JsonList.defTaskLayer)
    table_aux.unpackTo(__deftasklayer, obj)
    obj._onloaded  = onloaded
    obj:init()
    --obj:bindCloseListener()
    obj:bindBackListener()
    obj:bindLookAward()
    obj:bindDigListener()
    AccountHelper:lock(kStatePrompt)
    return obj
end

function showDef(onloaded)
    local layer = DefTaskLayer.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

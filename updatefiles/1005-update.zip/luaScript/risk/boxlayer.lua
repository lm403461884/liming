local kcellW = 72
local kcellH = 72 
local kBoxOffset = 10
local kBoxZorder = 1
local __boxlayer = {}
function __boxlayer.initlayer(obj,d_data)
    obj._d_data = d_data
    obj._matrixW =d_data.w
    obj._matrixH = d_data.h
	obj._boxes = {}
end
--=============================================
--����һ������ --AI������
--birthIdx ���䱦��Ĺ��������
--deadIdx ���䱦��Ĺ���������
function __boxlayer.createBox(obj,birthIdx,deadIdx)
	if not obj._d_data.boxList or not obj._d_data.boxList[birthIdx] then return nil end
	local boxtype = obj._d_data.boxList[birthIdx](account_data)
	if not boxtype then return nil end
	local box = BattleBox.new(deadIdx,boxtype)
	box:runStandAction()
    table.insert(obj._boxes,box)
    local x,y = obj:getPosByIdx(deadIdx)
    box:egSetPos(x,y + kBoxOffset)
    box:egAttachTo(obj,kBoxZorder,deadIdx)
end
function __boxlayer.removeBox(obj,box,offsetx,offsety)
	for idx,boxitem in ipairs(obj._boxes) do
		if box == boxitem then
			boxitem:removeWithAction(offsetx,offsety)
			table.remove(obj._boxes,idx)
		end
	end
end

function __boxlayer.getPosByIdx(obj,idx)
    local x = kcellW*( Funs.getX(obj._matrixW,idx)+ 0.5)
    local y = kcellH*(Funs.getViewY(obj._matrixW,obj._matrixH,idx)+0.5)
    return x,y
end
function __boxlayer.getBoxAt(obj,idx)
	for key,boxitem in ipairs(obj._boxes) do
		local birthplace = boxitem:getprop("birthPlace")
		if birthplace == idx then
			return boxitem
		end
	end
	return nil
end
function __boxlayer.getAllBoxes(obj)
	return obj._boxes
end
BoxLayer={}
function BoxLayer.new(d_data)
    local obj={}
    table_aux.unpackTo(__boxlayer, obj)
    Layer.install(obj)
    obj:initlayer(d_data)
    return obj
end
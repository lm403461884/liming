local visibleSize = CCDirector:sharedDirector():getVisibleSize()

local kCellW = 72
local kCellH = 72
local kEarthW = 64
local kEarthH = 64
local kMinCntX = 40
local kMinCntY = 20
local kHeaderH = 512 --ͷͼ�߶�
local kGroundOffset = 136

local kEarthZorder = 1
local kBlockZorder = 2
local kHeaderZorder = 3
local kEntraZorder = 4
local kCreatureZorder = 5
local kViewZorder = 6
local kBoxZorder = 7
local kDamageZorder = 10
local kNumZorder = 20

local kHeroSpeed = 150
local kGroundSpeed = 50
local __groundlayer = {}
--��ƽ�̷�ʽ����ͼƬ����
function __groundlayer.createRepeatImg(obj,srcImg,w,h,isframe)
    local params = ccTexParams:new()
    params.minFilter = GL_LINEAR
    params.magFilter = GL_LINEAR
    params.wrapS = GL_REPEAT
    params.wrapT = GL_REPEAT
    local sprite = nil
    if isframe then
        sprite = CCSprite:createWithSpriteFrameName(srcImg)
    else
        sprite = CCSprite:create(srcImg)
    end
    sprite:setAnchorPoint(ccp(0,0))
    sprite:getTexture():setTexParameters(params)
    sprite:getTexture():setAliasTexParameters()
    --sprite:getTexture():setAntiAliasTexParameters()
    sprite:setTextureRect(CCRectMake(0, 0, w,h))
    return sprite
end

--��ʼ����������������
function __groundlayer.initData(obj,d_data)
    obj._d_data = d_data
    obj._w = obj._d_data.w --ˮƽ������������
    obj._h = obj._d_data.h --��ֱ������������
    obj._visionLen = obj._d_data.digVision --��Ұ
    obj._entraIdx = obj._d_data.entraIdx --�������
    --obj._headImg = obj._d_data.headImg --����ͼ
    obj._entraImg = obj._d_data.entraImg --���ͼ
    obj._earthImg = obj._d_data.earthImg --���鱳��ͼ
    obj._actW = obj._w + 10
    obj._actH = obj._h + 5
    if obj._actW < kMinCntX then obj._actW = kMinCntX end
    if obj._actH < kMinCntY then obj._actH = kMinCntY end

    --ש�����������
    obj._width = kCellW * obj._w
    obj._height = kCellH * obj._h
    --�ھ��²㳡��������
    obj._actWidth = kCellW * obj._actW
    obj._actHeight = kCellH * obj._actH
    --ש��������ʼ����
    obj._orignalX = (obj._actWidth - obj._width)/2
    obj._orignalY = obj._actHeight - obj._height
    --�ھ򳡾����������
    obj._viewWidth = obj._actWidth
    obj._viewHeight = obj._actHeight + kHeaderH - kCellH
    --���ͼƬ����
    obj._entraX = obj._actWidth/2 - kCellW/2
    --�������ʼ����
    obj._innerX = (visibleSize.width - obj._viewWidth)/2
    obj._innerY = visibleSize.height - obj._viewHeight
    obj:moveInnerTo(obj._innerX,obj._innerY)

    obj:setInnerSize(CCSizeMake(obj._viewWidth,obj._viewHeight))
    obj:setSize(visibleSize)
    obj:setMinScale(math.floor(obj:getExtramMinScale()*100)/100 + 0.1)
    obj:setMaxScale(2)
    obj:loadGroundImgs()

end
function __groundlayer.loadGroundImgs(obj)
    --�ϲ㳡��
    --local headerImg = obj:createRepeatImg(obj._headImg,obj._viewWidth,kHeaderH)

    --obj:addChild(headerImg,kHeaderZorder,kHeaderZorder)
    --headerImg:setPosition(ccp(0,obj._actHeight - kCellH))
    local header = DigHeadLayer.new(obj._d_data,obj._viewWidth,kHeaderH)
    obj:addChild(header:egNode(),kHeaderZorder,kHeaderZorder)
    header:egNode():setPosition(ccp(0,obj._actHeight))
    --���ͼƬ
    local entraImg = CCSprite:create(obj._entraImg)
    obj:addChild(entraImg,kEntraZorder,kEntraZorder)
    entraImg:setAnchorPoint(ccp(0.5,0))
    entraImg:setPosition(ccp(obj._entraX ,obj._actHeight - kCellH))
    --���鱳����
    --obj._earthImg = "GUIRes/image/pic_view_00.png"
    --local earthImg = obj:createRepeatImg(obj._earthImg,obj._actW*kEarthW,obj._actH*kEarthH,true)
   -- earthImg:setScale(kCellW/kEarthW)
   -- obj:addChild(earthImg,kEarthZorder,kEarthZorder)
   -- earthImg:setPosition(ccp(0,0))
end
function __groundlayer.loadDigLayers(obj)

    obj._blocklayer = BlockLayer.new(obj._d_data)
    obj:addChild(obj._blocklayer:egNode(),kBlockZorder,kBlockZorder)
    obj._blocklayer:egSetPosition(obj._orignalX,obj._orignalY)

    obj._creaturelayer = CreatureLayer.new(obj._d_data)
    obj:addChild(obj._creaturelayer:egNode(),kCreatureZorder,kCreatureZorder)
    obj._creaturelayer:egSetPosition(obj._orignalX,obj._orignalY)

    obj._viewlayer = ViewLayer.new(obj._d_data)
    obj:addChild(obj._viewlayer:egNode(),kViewZorder,kViewZorder)
    obj._viewlayer:egSetPosition(obj._orignalX - kCellW/2,obj._orignalY - kCellH/2)

    --[[
    obj._numlayer =NumLayer.new(obj._w,obj._h,kCellW,kCellH)
    obj:addChild(obj._numlayer:egNode(),kNumZorder,kNumZorder)
    obj._numlayer:egSetPosition(obj._orignalX,obj._orignalY)
    --]]
end
function __groundlayer.loadBattleLayers(obj)

    obj._blocklayer = BlockLayer.new(obj._d_data)
    obj:addChild(obj._blocklayer:egNode(),kBlockZorder,kBlockZorder)
    obj._blocklayer:egSetPosition(obj._orignalX,obj._orignalY)

    obj._creaturelayer = CreatureLayer.new(obj._d_data)
    obj:addChild(obj._creaturelayer:egNode(),kCreatureZorder,kCreatureZorder)
    obj._creaturelayer:egSetPosition(obj._orignalX,obj._orignalY)
	
	obj._boxlayer = BoxLayer.new(obj._d_data)
    obj:addChild(obj._boxlayer:egNode(),kBoxZorder,kBoxZorder)
    obj._boxlayer:egSetPosition(obj._orignalX,obj._orignalY)

    obj._viewlayer = ViewLayer.new(obj._d_data)
    obj:addChild(obj._viewlayer:egNode(),kViewZorder,kViewZorder)
    obj._viewlayer:egSetPosition(obj._orignalX - kCellW/2,obj._orignalY - kCellH/2)
    
    obj._damagelayer = DamageLayer.new(obj._d_data)
    obj:addChild(obj._damagelayer:egNode(),kDamageZorder,kDamageZorder)
    obj._damagelayer:egSetPosition(obj._orignalX - kCellW/2,obj._orignalY - kCellH/2)

    --[[
    obj._numlayer =NumLayer.new(obj._w,obj._h,kCellW,kCellH)
    obj:addChild(obj._numlayer:egNode(),kNumZorder,kNumZorder)
    obj._numlayer:egSetPosition(obj._orignalX,obj._orignalY)
    --]]
end

function __groundlayer.loadHeros(obj)
    local distance = (obj._w-3)/2 *kCellW - (obj._width - visibleSize.width)/2
    local sec = distance/(kHeroSpeed + kGroundSpeed) --�ƶ�ʱ��
    local groundX = sec*kGroundSpeed --�����ƶ�ʱ��
    local x = (obj._width - visibleSize.width)/2 + groundX
    local y  = obj._height + kGroundOffset
    obj._creaturelayer:showHeros(x,y,distance - groundX,sec)
    local function callbackfunc()
        obj:setTouchable(true)
        if obj._onShowCallBack then
            obj._onShowCallBack()
            obj._onShowCallBack = nil
        end
    end
    local moveby = CCMoveBy:create(sec,ccp(groundX,0))
    local action_callback = CCCallFuncN:create(callbackfunc)
    local sequence = CCSequence:createWithTwoActions(moveby,action_callback)
    obj:setTouchable(false)
    obj:egSetPosition(-groundX,0)
    obj:egRunAction(sequence)
end
function __groundlayer.zoomIn(obj)
     obj:egSetScale(obj:egNode():getScale()* 1.1)
end

function __groundlayer.zoomOut(obj)
     obj:egSetScale(obj:egNode():getScale()* 0.9)
end
function __groundlayer.showInDigScene(obj)
    obj:loadDigLayers()
    obj._blocklayer:showBlocksArroundDigTrace()--�����ھ���Ұ�ڵ�����
    obj._blocklayer:showMinesOutOfDigTrace() --�����ھ���Ұ��Ŀ���
    obj._blocklayer:downloadMap()
    obj._viewlayer:showViewArroundDigTrace()
    obj._viewlayer:showMineViewOutOfDigTrace()
   -- obj._creaturelayer:loadAllMonster() --���ز���ʾ���й�
    obj._creaturelayer:loadMonstersWithOpacity(128)
    obj._creaturelayer:loadAllResCar()
	obj._creaturelayer:loadMonsterFlags()
    DigGround.install(obj)

end
function __groundlayer.showInDefScene(obj)
    obj:loadBattleLayers()
    obj._blocklayer:showBlocksArroundDigTrace()--�����ھ���Ұ�ڵ�����
    obj._blocklayer:markResCar() --�ڿ�����λ�ñ��Ϊ�յ�
    obj._blocklayer:downloadMap()
    obj._viewlayer:showViewArroundDigTrace()
    obj._creaturelayer:loadAllMonster() --���ز���ʾ���й�
    obj._creaturelayer:activeResCarAI()--������AI
    obj._creaturelayer:loadAllResCar() --���ز���ʾ���п�
    obj:loadHeros()
   -- BattleGround.install(obj)
end
function __groundlayer.showInAtkScene(obj)
    obj:loadBattleLayers()
    obj._blocklayer:showBlocksArroundDigTrace()--�����ھ���Ұ�ڵ�����
    obj._blocklayer:markResCar() --�ڿ�����λ�ñ��Ϊ�յ�
    obj._blocklayer:downloadMap()
    obj._viewlayer:hideViewArroundDigTrace()
    obj._viewlayer:showViewInVision(obj._d_data.entraIdx,obj._d_data.digVision)
    obj._creaturelayer:loadAllMonster() --���ز���ʾ���й�
    obj._creaturelayer:activeResCarAI()--������AI
    obj._creaturelayer:loadAllResCar() --���ز���ʾ���п�
    obj:loadHeros()
    BattleGround.install(obj)
end
--�����ã���ȡָ������ID�����꣬�Լ�����Ļ���ĵ�ľ���
function __groundlayer.getFocusPosByIdx(obj,idx)
    local blockx,blocky = obj._blocklayer:getPosByIdx(idx)
    local blockX = blockx - kCellW/2
    local blockY = blocky - kCellH/2
    local xInContainer = blockX + obj._orignalX
    local yInContainer = blockY + obj._orignalY
    local containerX = obj._innerObj:getPositionX()
    local containerY = obj._innerObj:getPositionY()
    local x = containerX + xInContainer
    local y = containerY + yInContainer

    local poscenter = obj._blocklayer:egPosInNode(640,360)
    local offsetx =poscenter.x -  blockx
    local offsety = poscenter.y - blocky
    if offsetx ~=0 or offsety ~= 0 then
        local des = obj:getValidMovePoint(offsetx,offsety)
        offsetx = des.x - containerX
        offsety = des.y - containerY
    end
    return x,y,offsetx,offsety
end
--Ӣ���볡��Ļص�����
function __groundlayer.onHeroShown(obj,callback)
    obj._onShowCallBack = callback
end
--x,yΪ��Ļ����
function __groundlayer.showPropMsg(obj,msg,posX,posY)
    showPopTxt(msg,posX,posY)
end
function __groundlayer.setOwner(obj,owner)
    obj._owner = owner
end
GroundLayer = {}
function GroundLayer.new(d_data)
    local obj = LuaZoomView.new()
    table_aux.unpackTo(__groundlayer, obj)
    obj:initData(d_data)
    AccountHelper:bind(kHoleLayer,obj)
    return obj
end


local kGroundOrder = 1
local kAtkOrder = 2
local kMaskOrder = 4
local kPropOrder = 5
local kScoreOrder = 6
local __atkscene={}
function __atkscene.init(obj,areaid,stageid)
    SendMsg[934001]()
    obj._d_data = RiskHelper.getAtkSceneData(areaid,stageid)
    obj._groundlayer = GroundLayer.new(obj._d_data)
    obj._groundlayer:egAttachTo(obj,kGroundOrder,kGroundOrder)
	obj._groundlayer:setOwner(obj)
    local function callback()
        obj._atklayer = GAtkLayer.new(obj._d_data,obj)
        obj._atklayer:egAttachTo(obj,kAtkOrder,kAtkOrder)
    end
    obj._groundlayer:showInAtkScene(callback)
	obj._groundlayer:onHeroShown(callback)
    --��������ID
	--showDialog(1)
end
function __atkscene.stopBattle(obj)
    SendMsg[934002](battleProgress)

    obj._scoreLayer= BattleResultLayer.new(obj._d_data)
	obj._scoreLayer:setBackToTown()
    obj:egAddChild(obj._scoreLayer:egNode(),kScoreOrder,kScoreOrder)
   
end
GAtkScene={}
function GAtkScene.new(areaid,stageid)
    SoundHelper.playBGM(SoundList.atk_bgm)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__atkscene, obj)
    obj:init(areaid,stageid)
	showEmDialog(obj,GuideScene.def.kAtkScene) --����������Ϣ
     --------
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    
    return obj
end
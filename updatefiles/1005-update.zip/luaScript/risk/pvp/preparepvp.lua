
local kLabelCost = "lbl_cost"
local kLabelTeamCap = "lbl_team_cap"
local kPanelLayer = "pvp_panel"
local kBtnQuery = "btn_query"
local kBtnBack = "btn_back"

local kPanelHero = "hero_list"
local kBtnRight1 = "btn_right1"
local kImgScene = "img_scene"
local kLblOwner = "lbl_hole_name"
local kLblLv = "licence_val"
local kLblElo = "lbl_elo_val"
local kMaxNum = 4
local kCellW = 110
local kRedColor = ccc3(255,0,0)
local __preparepvp = {}
function __preparepvp.init(obj)
    obj._searchCost = numDef.goldOfSearch
    obj:egSetBMLabelStr(kLabelCost,obj._searchCost)
    if account_data.gold < obj._searchCost then 
        obj:egSetWidgetEnabled(kBtnQuery,false)
        obj:egSetWidgetColor(kLabelCost,kRedColor)
    end
    local sceneid = account_data.sceneID
    local pic = scene_data[sceneid].thumbPic
    local elo = account_data.elo or 0
    local lv = account_data.digLv
    obj:egSetLabelStr(kLblOwner,account_data.nickName)
    obj:egSetBMLabelStr(kLblLv,lv)
    obj:egChangeImg(kImgScene,pic,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblElo,elo)
	local teamCap = obj:getTeamAtkCap()
	obj:egSetLabelStr(kLabelTeamCap,string.format("%s: %d",TxtList.teamCap,teamCap))
    obj:loadHeros()
    obj:showWithAction()
end
--����ļ������Ӣ��ս�������ݱ�
function __preparepvp.getTeamAtkCap(obj)
    local tb = {}
	local teamAtk = 0
    for key,heroprop in pairs(account_data.heroList) do
        local equiplv,equipqa =  equipFuncs.getEquipQL(heroprop.eid,account_data)
        local atkcap = baseCalc.getBattlePoint(heroprop.lv,equiplv,equipqa)
        tb[heroprop.type] = atkcap
    end
	for key,heroid in ipairs(account_data.team) do
        teamAtk = teamAtk + tb[heroid]
    end
	tb = nil
    return teamAtk
end
function __preparepvp.loadHeros(obj)
    local heros = account_data.team
    local listview  = obj:egGetListView(kPanelHero)
    for key,heroid in ipairs(heros) do
		local herodata = account_data.heroList[heroid]
        heroHead = HeroHead.new(heroid,herodata.lv)
        listview:pushBackCustomItem(heroHead:egNode())
    end
    if #heros < kMaxNum then 
		local size = listview:getSize()
		local neww = #heros * kCellW
		local newx = (size.width-neww)/2 + listview:getPositionX()
		listview:setSize(CCSizeMake(neww,size.height))
		listview:setPosition(ccp(newx,listview:getPositionY()))
    end
end
function __preparepvp.hideWithAction(obj,callbackfunc)
    local function callback()
          obj:egRemoveSelf()
          if callbackfunc then callbackfunc () end
    end
    obj._masklayer:runAction(CCFadeTo:create(0.5,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __preparepvp.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.4)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
    if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
function __preparepvp.doClickQuery(obj)
    obj:egSetWidgetTouchEnabled(kBtnQuery,false)
    SoundHelper.playEffect(SoundList.click_buy_button)
    AccountHelper:lock(kStateSearchPvp)
    SendMsg[935001]()
    obj:hideWithAction(showPreviewPvp)
end
--Ѱ�Ҷ���
function __preparepvp.bindQueryListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:doClickQuery()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnQuery,nil,nil,touchEnded,touchCanceled)
end

function __preparepvp.bindBackListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_paper_close)
        local function callback()
            AccountHelper:unlock(kStatePrompt)
        end
        obj:hideWithAction(callback)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end
PreparePvp = {}
function PreparePvp.new(onloaded)
    local obj = TouchWidget.new(JsonList.pvpAtkPre)
    table_aux.unpackTo(__preparepvp, obj)
    obj._onloaded = onloaded
    obj:init()
    obj:bindQueryListener()
    obj:bindBackListener()
    return obj
end

function showPreparePvp(onloaded)
    local layer = PreparePvp.new(onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end
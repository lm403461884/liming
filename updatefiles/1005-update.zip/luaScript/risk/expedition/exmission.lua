local kImagStar = {"star_1","star_2","star_3"}
local kBtnMission = "btn_misssion"
local kImgNew = "img_new"
local kLblCD = "lbl_cd_num"
local kLblCD_CH = "lbl_cd_ch"
local kLblCH = "lbl_ch"
local kLblCH_s = "lbl_ch_s"
local __exmission = {}
function __exmission.init(obj,stageid,stageinfo)
    obj._stageid = stageid
	obj._stageinfo = stageinfo
	obj:egSetWidgetEnabled(kBtnMission,false)
	obj:egHideWidget(kImgNew)
	obj:egHideWidget(kLblCD)
	obj:egHideWidget(kLblCD_CH)
	obj:egHideWidget(kLblCH)
	obj:egHideWidget(kLblCH_s)
	obj:loadMissionData()
end
function __exmission.loadMissionData(obj)
	if not obj._stageid then return end
	obj._s_data = farpveQuery.queryStage(obj._stageid)
	obj:egChangeBtnImg(kBtnMission,obj._s_data.tagPic[1],obj._s_data.tagPic[2],obj._s_data.tagPic[3],UI_TEX_TYPE_PLIST)
	local stars = math.floor(obj._stageinfo/256)
	local unlocked = math.min(obj._stageinfo%256,1)
	obj:addprop("stageid",obj._stageid)
	obj:addprop("stars",stars)
	obj:addprop("x",obj._s_data.x)
	obj:addprop("y",obj._s_data.y)
	for idx=1,stars do
		obj:egShowWidget(kImagStar[idx])
		obj:egChangeImg(kImagStar[idx],ImageList.star,UI_TEX_TYPE_PLIST)
	end
	if unlocked== 1 then
		obj:egSetWidgetEnabled(kBtnMission,true)
		if  stars == 0  then
			obj:egShowWidget(kImgNew)
			obj:egSetWidgetTouchEnabled(kBtnMission,true)
			local scaleto1 = CCScaleTo:create(0.5,0.9)
			local moveby1 = CCMoveBy:create(0.5,ccp(0,-5))
			local spawn1 = CCSpawn:createWithTwoActions(scaleto1,moveby1)
			local scaleto2 = CCScaleTo:create(0.5,1)
			local moveby2 = CCMoveBy:create(0.5,ccp(0,5))
			local spawn2 = CCSpawn:createWithTwoActions(scaleto2,moveby2)
			local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
			local repeatever = CCRepeatForever:create(sequence)
			local widget = obj:egGetWidgetByName(kImgNew)
			widget:runAction(repeatever)
		else
			obj:egSetWidgetTouchEnabled(kBtnMission,false)
		end
	end
end
function __exmission.enableTouch(obj,enabled)
	obj:egSetWidgetTouchEnabled(kBtnMission,enabled)
end
function __exmission.onItemClicked(obj,callback)
	obj._clickCallBack = callback
end
--����ť����¼�
function __exmission.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		 sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_open)
        if obj._clickCallBack then obj._clickCallBack(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnMission,nil,nil,touchEnded,touchCanceled)
end
ExMission={}
function ExMission.new(stageid,stageinfo)
    local obj = {}
    CocosWidget.install(obj,JsonList.pveMission)
    table_aux.unpackTo(__exmission, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
    obj:init(stageid,stageinfo)
    obj:bindClickListener()
    return obj
end
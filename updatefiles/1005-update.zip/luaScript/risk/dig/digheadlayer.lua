local kPanelScene = "panel_scene"
local kImgBg2 = "img2"
local kImgBg3 = "img3"
local kImgBg1 = "img1"
local kImgShadow = "img_shadow"

local __digheadlayer = {}

function __digheadlayer.init(obj,d_data,w,h)
    local areaData = scene_data[d_data.sceneID]
    local panelscene = obj:egGetWidgetByName(kPanelScene)
    local size = panelscene:getSize()
    panelscene:setSize(CCSizeMake(w,size.height))
    obj:loadImgRepeat(kImgBg2,areaData.mid_img,w,h)
    obj:loadImgRepeat(kImgBg1,areaData.far_img,w,h)
    obj:loadImgRepeat(kImgBg3,areaData.near_img,w,h)
end
--ƽ�̼���ͼƬ
function __digheadlayer.loadImgRepeat(obj,widgetName,imgsrc,w,h)
    local widget = obj:egGetWidgetByName(widgetName)
    local img = tolua.cast(widget,"ImageView")
    img:loadTexture(imgsrc)
    local params = ccTexParams:new()
    params.minFilter = GL_LINEAR
    params.magFilter = GL_LINEAR
    params.wrapS = GL_REPEAT
    params.wrapT = GL_REPEAT
    local sprite =  tolua.cast(img:getVirtualRenderer(),"CCSprite")
    sprite:getTexture():setTexParameters(params)
    sprite:getTexture():setAliasTexParameters()
    local size = img:getSize()
    if size.height > h then h = size.height end  
    img:setTextureRect(CCRectMake(0, 0, w, h))
end

--------------------------------------------------------
DigHeadLayer={}
function DigHeadLayer.new(d_data,w,h)
    local obj = TouchWidget.new(JsonList.digHeadLayer)
    table_aux.unpackTo(__digheadlayer, obj)
    obj:init(d_data,w,h)
    return obj
end
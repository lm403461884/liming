local kBtnBack = "btn_back"
local kImgTrain = "train"
local kPanelTouch = "map_touch_panel"

local kPanelNotice = "notice_panel"
local kBtnYes = "btn_yes"
local kBtnNo = "btn_no"
local kBtnNo2 = "btn_no_2"

local __digmaplayer={}
function __digmaplayer.init(obj)
    obj._touchAreaID = 0
    obj._areaSprites = {}
    obj:showTrain()--��ʾС��
    obj:showPromptPanel(false)
	--����PVE��� ���������ͼ
	for areaID, area in pairs(account_data.unlockedPVE) do
		--����ѽ�������Ľ��沼��
		if area[1] then
		    local widgetName = 'touch_area_'..areaID
		    local img = tolua.cast(obj:egGetWidgetByName(widgetName),"ImageView")
		    local sprite = tolua.cast(img:getVirtualRenderer(),"CCSprite")
		    obj._areaSprites[areaID] = sprite
			--�޳���������
			local maskCtrl = obj:egGetWidgetByName('mask_'..areaID)
			maskCtrl:runAction(CCFadeOut:create(1))
		end
	end
end
--�ڵ�ǰ������ʾС��
function __digmaplayer.showTrain(obj)	
    local touchArea = obj:egGetWidgetByName('touch_area_'..account_data.worldAreaID)
    local size = touchArea:getSize()
    local anchor = touchArea:getAnchorPoint()
    local x = touchArea:getPositionX() + (0.5-anchor.x)*size.width
    local y = touchArea:getPositionY()+ (0.5-anchor.y)*size.height
	local train = obj:egGetWidgetByName(kImgTrain)
	train:setPosition(ccp(x,y))
	local moveAction = CCRepeatForever:create(CCSequence:createWithTwoActions(CCMoveBy:create(0.5, ccp(-10, 0)), CCMoveBy:create(0.5, ccp(10, 0))))
	train:runAction(moveAction)
end
--��ȡ��ǰ���������ID,�޵������ʱ����0
function __digmaplayer.getTouchedAreaID(obj,pos)
    for areaid,sprite in pairs(obj._areaSprites) do
        local isalpha = sprite:isAlphaAtPoint(pos.x,pos.y)
        if not isalpha then
            return areaid
        end
	end
	return 0
end
--��ͼ�����������¼�
function __digmaplayer.bindTouchListener(obj)
    local function touchBegan(sender)
		sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.click_paper_open)
		local pos =sender:getTouchStartPos()
		obj._touchAreaID = obj:getTouchedAreaID(pos)
		if obj._touchAreaID > 0 then
		    obj._areaSprites[obj._touchAreaID]:setScale(1.05)
		end
    end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		if obj._touchAreaID > 0 then
            obj._areaSprites[obj._touchAreaID]:setScale(1)
            sender:setTouchEnabled(true)
            obj:showPromptPanel(true)
        else
            sender:setTouchEnabled(true)
		end
    end
    local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		else
			sender:setTouchEnabled(true)
			if obj._touchAreaID > 0 then
				obj._areaSprites[obj._touchAreaID]:setScale(1)
			end
			obj._touchAreaID = 0
		end
    end
    obj:egBindTouch(kPanelTouch,touchBegan,nil,touchEnded,touchCanceled)
end
function __digmaplayer.bindBackListener(obj)
    local function touchEnded(sender)
		sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_close)
        local scene = DigScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end


function __digmaplayer.activeNewHoleTimer(obj)
    local cnt = 0
    local function callback(delta)
		cnt = cnt + delta
        if not AccountHelper:isLocked(kStateNewHole) then
            local scene = DigScene.new()
            scene:egReplace()
		elseif cnt >numDef.clientTimeOut then
            obj:egUnbindWidgetUpdate(kImgTrain)
            local function callback()
				local scene = LogoScene.new()
				scene:egReplace()
			end
			local msglayer = MsgLayer.new(nil,TxtList.dataUnMatch,1,callback)
			msglayer:show()
        end
    end
    obj:egBindWidgetUpdate(kImgTrain,callback)
end
--���¿���ʾ��
function __digmaplayer.showPromptPanel(obj,show)
    if show then
        obj:egShowWidget(kPanelNotice)
        obj:egShowWidget(kBtnYes)
        obj:egShowWidget(kBtnNo)
    else
        obj:egHideWidget(kPanelNotice)
        obj:egHideWidget(kBtnYes)
        obj:egHideWidget(kBtnNo)
    end
end

--ȷ�Ͽ��¿�
function __digmaplayer.bindYesListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj:showPromptPanel(false)
        obj:egSetWidgetTouchEnabled(kPanelTouch,false)
        obj:egHideWidget(kBtnBack)
        SoundHelper.playEffect(SoundList.click_shop_goods)
		if obj._touchAreaID ~= account_data.worldAreaID then
			--������������л������������Ϣ
			--���¿ͻ��˱�����������ID
			SendMsg[934004](obj._touchAreaID)
			account_data.worldAreaID = obj._touchAreaID
		end
		AccountHelper:lock(kStateNewHole)--�������¿�״̬
		SendMsg[932002]()
		--�ھ���־������̸���,���¿�
		task.updateTaskStatus(account_data,task.client_event_id.new_dig,{obj._touchAreaID})
		----------------------------------------------------------
		--�ھ���־������̸���,�ۼ��ʻ�actPt��recvMsg392001�н���
		task.updateTaskStatus(account_data,task.client_event_id.cost_actPt,{numDef.openHole})
		----------------------------------------------------------
		--���¿��¿���ȴʱ��
		account_data.openHoleContext={st=os.time(),left = numDef.openHoleInterval }
		for areaid,_ in pairs(obj._areaSprites) do
		    local maskCtrl = obj:egGetWidgetByName('mask_'..obj._touchAreaID)
		    if areaid == obj._touchAreaID then
		        local fadeto1 = CCFadeTo:create(1.5,255)
		        local fadeto2 = CCFadeTo:create(1.5,100)
		        local sequence = CCSequence:createWithTwoActions(fadeto1,fadeto2)
		        local repeatever = CCRepeatForever:create(sequence)
		        maskCtrl:runAction(repeatever)
		    else
		        maskCtrl:runAction(CCFadeIn:create(0.5))
		    end
		end
		obj:activeNewHoleTimer()
    end
	 local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnYes,nil,nil,touchEnded,touchCanceled)
end
--ȡ�����¿�
function __digmaplayer.bindNoListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        obj._touchAreaID = 0
        obj:showPromptPanel(false)
        SoundHelper.playEffect(SoundList.click_back_button)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnNo,nil,nil,touchEnded,touchCanceled)
end
function __digmaplayer.bindExitEvent(obj)
	local function unloadSpriteFrame()
		--ɾ��Plist��Ӧ�ľ���֡
		graphicLoader.unloadFrameWithFile(KVariantList.matImgList,KVariantList.mapPvrPath)
	end
	obj:egOnExit(unloadSpriteFrame)
end
DigMapLayer = {}
function DigMapLayer.new(sceneID)
	graphicLoader.loadFrameWithFile(KVariantList.matImgList,KVariantList.mapPvrPath) --����ͼƬ��Դ
	local obj =  TouchWidget.new(JsonList.digmapLayer)
    table_aux.unpackTo(__digmaplayer, obj)
    obj:init(sceneID)
	obj:bindBackListener()
	obj:bindTouchListener()
	obj:bindYesListener()
	obj:bindNoListener()
	obj:bindExitEvent()
	return obj
end
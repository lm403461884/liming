local knumzorder = 0

local __numlayer = {}


function __numlayer.loadNums(obj)
    local count = obj.matrixW *obj.matrixH


    for idx = 1,count do

        local item = nil
        if obj._isred then 
            item = CCLabelTTF:create(tostring(idx), "Marker Felt", 12)
            item:setColor(ccc3(255,0,0)) 
        else
            item = CCLabelTTF:create(tostring(idx), "Marker Felt", 24)
        end
        local x,y = obj:getPosPix(idx)
        item:setPosition(x,y)
        obj:egAddChild(item,knumzorder,idx)
    end
    obj:egSetContentSize(obj.block_w *obj.matrixW,obj.block_h * obj.matrixH)
end

function __numlayer.getPosPix(obj,idx)
    local x = obj.block_w*( Funs.getX(obj.matrixW,idx)+ 0.5)
    local y = obj.block_h*(Funs.getViewY(obj.matrixW,obj.matrixH,idx)+0.5)
    return x,y
end

NumLayer = {}

function NumLayer.new(width,height,pixw,pixh,isred)
    local obj = {}
    Layer.install(obj)
    table_aux.unpackTo(__numlayer, obj)
    obj.matrixW = width
    obj.matrixH =height
    obj.block_w = pixw
    obj.block_h = pixh
    obj._isred = isred
    obj:loadNums()
    return obj
end

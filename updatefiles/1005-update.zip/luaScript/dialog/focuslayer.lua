local kCellW = 64
local kCellH = 64
local kclipOrder = 1
local kfocusOrder = 2
local khandOrder = 3
local kbgOrder = 4

local __focuslayer = {}

function __focuslayer.init(obj,data)
    --if not data then data={rect={11}} end
    obj._d_data = data
	obj._touchEnabled = false
    local cnt = #obj._d_data.rect
    if cnt <4 then
       obj:loadBlockFocus()
    else
        obj:loadNormalFocus()
    end
end
function __focuslayer.loadNormalFocus(obj)
    obj._x = obj._d_data.rect[1]
    obj._y = obj._d_data.rect[2]
    obj._w = obj._d_data.rect[3]
    obj._h = obj._d_data.rect[4]
	obj:loadClip()
	obj:loadHand()
	obj:showWithAction()
	--[[
    local function callback()
        obj._touchEnabled = true
        obj:loadHand()
    end
    local callfunc = CCCallFunc:create(callback)
    local delay = CCDelayTime:create(0.5)
    local sequence = CCSequence:createWithTwoActions(delay,callfunc)
    obj:egNode():runAction(sequence)
	--]]
end
function __focuslayer.loadBlockFocus(obj)
     local holelayer = AccountHelper:get(kHoleLayer)
        local x,y,offsetx,offsety = holelayer:getFocusPosByIdx(obj._d_data.rect[1])
        obj._x = x + offsetx
        obj._y = y + offsety
        obj._w = kCellW
        obj._h = kCellH
        local innerContainer = holelayer:getInnerContainer() 
        local moveby = CCMoveBy:create(0.5,ccp(offsetx,offsety))
		innerContainer:runAction(moveby)
		obj:loadClip()
		obj:loadHand()
		obj:showWithAction()
		--[[
        local function callback()
            obj._touchEnabled = true
            obj:loadHand()
        end
        local callfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(moveby,callfunc)
        innerContainer:runAction(sequence)
		--]]
end
function __focuslayer.showWithAction(obj)
    local function callback()
		obj._touchEnabled = true
		obj._fadebg:setVisible(false)
		obj._clip:setVisible(true)
	end
	obj._clip:setVisible(false)
	local callfunc = CCCallFunc:create(callback)
	local fadeto = CCFadeTo:create(0.5,125)
	local sequence = CCSequence:createWithTwoActions(fadeto,callfunc)
	obj._fadebg = CCLayerColor:create(ccc4(0,0,0,0))
	obj:egAddChild(obj._fadebg,kbgOrder,kbgOrder)
	obj._fadebg:runAction(sequence)
end
function __focuslayer.loadClip(obj)
    obj._clip = CCClippingNode:create()
    obj._clip:setInverted(true)
    obj._clip:setAlphaThreshold(0)
    obj:egAddChild(obj._clip,kclipOrder,kclipOrder)
    obj._bg = CCLayerColor:create(ccc4(0,0,0,128))
    obj._clip:addChild(obj._bg )
    local sprite = CCScale9Sprite:createWithSpriteFrameName(ImageList.comm_focus_button)
    sprite:setContentSize(CCSizeMake(obj._w,obj._h))
    sprite:setPosition(ccp(obj._w/2,obj._h/2))
    obj._clipShape = sprite
    local node = CCNode:create()
    node:addChild(obj._clipShape)
    node:setPosition(ccp(obj._x,obj._y))
    obj._clip:setStencil(node)
end
function __focuslayer.loadHand(obj)
    obj._focusImg = CCSprite:createWithSpriteFrameName(ImageList.comm_focus)
    local handImg = CCSprite:createWithSpriteFrameName(ImageList.comm_focus_hand)
    obj._focusImg:setPosition(ccp(obj._x +obj._w/2,obj._y + obj._h/2))
    handImg:setAnchorPoint(ccp(0,1))
    handImg:setPosition(ccp(obj._x +obj._w/2,obj._y + obj._h/2))
    obj:egAddChild(obj._focusImg,kfocusOrder,kfocusOrder)
    obj:egAddChild(handImg,khandOrder,khandOrder)
    local scaleto1 = CCScaleTo:create(1,0.9)
    local scaleto2 = CCScaleTo:create(1,1)
    local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
    local repeatever = CCRepeatForever:create(sequence)
    obj._focusImg:runAction(repeatever)
end
function __focuslayer.bindClickListener(obj)
    local function onTouch(eventType, x,y)
        if eventType == "began" then 
			if not obj._touchEnabled then return true end
			if #obj._d_data.rect<4 then --�ھ򳡾�
				local rect = CCRectMake(obj._x,obj._y,obj._w,obj._h)
			    if rect:containsPoint(ccp(x,y)) then 
					local holelayer = AccountHelper:get(kHoleLayer)
					holelayer:touchAtPos(x,y)
					obj:doClickCallback()
				end
                return true
            else
                local rect = CCRectMake(obj._x,obj._y,obj._w,obj._h)
			    if rect:containsPoint(ccp(x,y)) then 
                    obj:doClickCallback()
                    return false 
                else
                    return true
                end
		    end
        end
    end
    obj._egObj:setTouchEnabled(true)
    obj._egObj:registerScriptTouchHandler(onTouch,false,obj._priority ,true)
end
function __focuslayer.doClickCallback(obj)
    obj._focusImg:stopAllActions()
    if obj._d_data.guideIdx then  
        GuideScene[obj._d_data.sceneCode][obj._d_data.guideIdx].unLockNext(account_data)
        SendMsg[931005](obj._d_data.sceneCode,obj._d_data.guideIdx) 
    end
    if obj._d_data.focusIdx then
        showFocus(obj._d_data.focusIdx)
		AccountHelper:lock(kStateGuide0)
		
    elseif obj._d_data.dialogIdx then
        showDialog(obj._d_data.dialogIdx) 
		AccountHelper:lock(kStateGuide0)
    else
        AccountHelper:unlock(kStateGuide0)
    end
    obj:egRemoveSelf()
end
FocusLayer={}
function FocusLayer.new(idx)
    if focusData[idx] then
        local obj = {}
        table_aux.unpackTo(__focuslayer, obj)
        Layer.install(obj)
        obj._priority = TouchLv.guidLayer
        obj:init(focusData[idx])
        obj:bindClickListener()
        AccountHelper:lock(kStateGuide)
        return obj
    else
        print("can not find focusData with idx ",idx)
    end
    
end
function showFocus(idx)
     if AccountHelper:isLocked(kStateGuide) then
        local scene = CCDirector:sharedDirector():getRunningScene()
		if scene:getChildByTag(UILv.guidLayer) then
			scene:removeChildByTag(UILv.guidLayer,true)
		end
    end
    local layer = FocusLayer.new(idx)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.guidLayer,UILv.guidLayer)
    
end
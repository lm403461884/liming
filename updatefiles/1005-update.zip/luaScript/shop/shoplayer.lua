local kLblLv_s = "lbl_lv_s"
local kLblLv = "lbl_lv"
local kBtnBack = "btn_back"
local kBtnSpeedUp = "btn_speedup"
local kPanelShop = "item_panel"
local kPanelBag = "tool_panel"
local kPanelSpeedUp = "speedup_panel"
local kPanelNotice = "notice_panel"
local kLblCapacity = "lbl_capcity"
local kLblLeft = "lbl_time_CH"
local kLblTime = "lbl_time"
local kImgCoin = "img_jewel"
local kLblCoin = "lbl_speedup_val"
local kCellH = 185
local kCellW = 185
local kOuterY = 20--��Ʒ�������²�߿�ľ���
local kColCnt = 5
local kMinRowCnt = 2
local kCoinType = "jewel"
local kPromptZorder = 5
local kMoveDistance = 200
local kBagW = 160
local kBagCnt = 6
local __shoplayer={}
function __shoplayer.init(obj,d_data)
    
   obj._d_data = d_data
   if not obj._d_data.bagCapacity then obj._d_data.bagCapacity = 6 end
   obj._loadedCnt = 0 --�Ѽ��ص���Ʒ����
   obj._shopViewH = 0 --��Ʒ��ʵ�ʼ��ظ߶�
   obj._d_data.usedBagCapacity = obj:getUsedCapacity() --��ʹ�õ�������ÿ�μ����̵�ҳ��ʱ���¼��㣬�ͻ�����
   obj:refreshBagCap()
   obj:refreshLv()
   obj:showSpeedUp(#obj._d_data.pdLine.items > 0)
   obj:loadShopItems()
   obj:loadBagItems()
end
function __shoplayer.loadBagItems(obj)
    obj._bagitems = {}
    local scrollview = obj:egGetScrollView(kPanelBag)
    for idx = 1,kBagCnt do
        local itemid = obj._d_data.teamBag[idx] or 0
        local bagitem = BagItem.new(itemid)
        bagitem:egSetPosition((idx-1)*kBagW,0)
        obj:bindAllRemovedEvent(bagitem)
        scrollview:addChild(bagitem:egNode())
        table.insert(obj._bagitems,bagitem)
    end
end
function __shoplayer.bindAllRemovedEvent(obj,bagitem)
    local function removedCallback(sender)
        local idx = 0
        local cnt = #obj._bagitems
        for key,item in ipairs(obj._bagitems) do
            if item == sender then
                idx = key
                break
            end
        end
        table.remove(obj._bagitems,idx)
        table.insert(obj._bagitems,sender)
        sender:egSetPosition(cnt*kBagW,0)
        for i = idx,#obj._bagitems do
              obj._bagitems[i]:egRunAction(CCMoveBy:create(0.5,ccp(-kBagW,0)))  
        end
    end
    bagitem:onAllRemoved(removedCallback)
end
--������ռ�õ�������
function __shoplayer.getUsedCapacity(obj)
    local val = 0
	for itemid,num in pairs(obj._d_data.bag) do
		local s_cfg = itemQuery.query(itemid)--��ȡ���߾�̬����
		val = val + s_cfg.consume*num
	end
	for idx,item in ipairs(obj._d_data.pdLine.items) do
        local s_cfg = itemQuery.query(item.itemid)--��ȡ���߾�̬����
		val = val + s_cfg.consume*item.cnt
    end
    return val
end
function __shoplayer.showSpeedUp(obj,show)
    if show then 
        obj:egShowWidget(kPanelSpeedUp)
        obj:egShowWidget(kBtnSpeedUp)
        obj:egHideWidget(kPanelNotice)
        obj:bindSpeedUpdate()
    else
        
        obj:egHideWidget(kPanelSpeedUp)
        obj:egHideWidget(kBtnSpeedUp)
        obj:egShowWidget(kPanelNotice)
        obj:unBindSpeedUpdate()
    end
end
--����������ض�ʱ��
function __shoplayer.bindSpeedUpdate(obj)
    obj._leftTime = 0
    obj._speedupVal = 0
    local function update(delta)
        local leftTime = obj._d_data.pdLine.total - (os.time() - obj._d_data.pdLine.st)
        if obj._leftTime ~= leftTime then
            obj._leftTime = leftTime
            local timeTxt = Funs.formatTimeCh(obj._leftTime,true,true,true,true,true)
            obj:egSetLabelStr(kLblTime,timeTxt)
            local speedupval = jewelCalc.speedupTool(obj._leftTime)--���������������
            if obj._speedupVal~= speedupval then
                obj._speedupVal = speedupval
                obj:egSetLabelStr(kLblCoin,obj._speedupVal)
                local widget = obj:egGetWidgetByName(kBtnSpeedUp)
                widget:setEnabled(obj._speedupVal <= obj._d_data[kCoinType])
            end
        end
        if leftTime <= 0 then
            obj:showSpeedUp(false)
        end
        
	end
	obj:egBindWidgetUpdate(kLblTime,update)
end
--�رռ�����ض�ʱ��
function __shoplayer.unBindSpeedUpdate(obj)
    obj:egUnbindWidgetUpdate(kLblTime)
end
function __shoplayer.loadShopItems(obj)
    obj._shopItems = itemQuery.unLockedItems(obj._d_data)--��ȡ�ѽ����ĵ����б�
    local lockedItems = itemQuery.lockedItems(obj._d_data) --��ȡδ�����ĵ����б�
    for idx = 1,#lockedItems do
        table.insert(obj._shopItems,lockedItems[idx])
    end
    local cnt = #obj._shopItems --����������
    obj._maxRow=kMinRowCnt
    if cnt > kColCnt*kMinRowCnt then
        obj._maxRow = math.ceil(cnt/kColCnt)
        local newh = kOuterY*2 + kCellH*obj._maxRow --��Ʒ��������߶�
        local scrollview = obj:egGetScrollView(kPanelShop)
        local size = scrollview:getSize()
        scrollview:setInnerContainerSize(CCSizeMake(size.width,newh))
        obj:bindShopItemScrollListener()
    end
    obj:addShopItem(kColCnt*kMinRowCnt)
end
function __shoplayer.bindShopItemScrollListener(obj)
    local scrollview = obj:egGetScrollView(kPanelShop)
    local function scrollEvent( sender,eventType)
        if eventType ==SCROLLVIEW_EVENT_SCROLLING then 
            if #obj._shopItems  <= 0 then return end --�Ѽ��������е���
            local innerContainer = scrollview:getInnerContainer()
            local posY = innerContainer:getPositionY()
            local size = innerContainer:getSize()
            print(obj._shopViewH,posY,size.height)
            if obj._shopViewH - posY  < size.height then
                obj:addShopItem(kColCnt)
            end
        end
    end
    scrollview:addEventListenerScrollView(scrollEvent) 
end
function __shoplayer.addShopItem(obj,num)
    if not num then num = 1 end
    local leftCnt = #obj._shopItems
    if num > leftCnt then num = leftCnt end
    local scrollview = obj:egGetScrollView(kPanelShop)
    for idx=1,num do 
        obj._loadedCnt = obj._loadedCnt + 1
        local curRow = math.ceil(obj._loadedCnt/kColCnt)
        local y = kOuterY +(obj._maxRow - curRow)*kCellH
        local x = (idx-1)%kColCnt*kCellW
        local shopitem = ShopItem.new(obj._shopItems[1])
        obj:bindEventToShopItem(shopitem)
        shopitem:egSetPosition(x,y)
        scrollview:addChild(shopitem:egNode())
        table.remove(obj._shopItems,1)
        obj._shopViewH = kOuterY*2 + kCellH*curRow
    end
end
--��Ʒ���Ӱ���¼�
function __shoplayer.bindEventToShopItem(obj,shopitem)
    local function clickCallback(sender)
        local pos = sender:getTouchEndPos()
        if sender:canBuy() then
            local itemid = sender:getItemId()
            local pdIdx = obj:getPdItemIdx(itemid) --�������������е�����λ��
            if not pdIdx and #obj._d_data.pdLine.items == kBagCnt then
                obj:showPrompt(TxtList.needBag,pos.x,pos.y)
				SoundHelper.playEffect(SoundList.click_shop_goods)
            else
                local s_cfg = itemQuery.query(itemid)--��ȡ���߾�̬����
                if obj._d_data.usedBagCapacity + s_cfg.consume > obj._d_data.bagCapacity then
                    obj:showPrompt(TxtList.needCapacity,pos.x,pos.y)
					SoundHelper.playEffect(SoundList.click_shop_goods)
                else
					SoundHelper.playEffect(SoundList.click_buy_button)
                    obj:addPdItem(itemid,pdIdx)
                end
            end
        else
            local infotxt = sender:getNotifyMsg()
            obj:showPrompt(infotxt,pos.x,pos.y)
			SoundHelper.playEffect(SoundList.click_shop_goods)
        end
    end
    shopitem:onClicked(clickCallback)
end
--��ȡ�������������е�λ������
function __shoplayer.getPdItemIdx(obj,itemid)
    for key,item in ipairs(obj._d_data.pdLine.items) do
        if item.itemid == itemid then
            return key
        end
    end
    return nil
end
--������������������
function __shoplayer.addPdItem(obj,itemid,pdIdx)
    local s_cfg = itemQuery.query(itemid)--��ȡ���߾�̬����
    obj._d_data.usedBagCapacity = obj._d_data.usedBagCapacity + s_cfg.consume
    if pdIdx then --�������������е�����λ��
        obj._d_data.pdLine.items[pdIdx].cnt = obj._d_data.pdLine.items[pdIdx].cnt+1
    else
        local tb = {}
        tb.itemid = itemid
        tb.cnt = 1
        if #obj._d_data.pdLine.items == 0 then
            obj._d_data.pdLine.st = os.time()
            obj._d_data.pdLine.passed = 0
            obj._d_data.pdLine.total = 0
            obj:showSpeedUp(true)
        end
        table.insert(obj._d_data.pdLine.items,tb)
        if not obj._d_data.bag[itemid] then --�����в�����Щ����ʱ����Ҫ����
            obj._d_data.bag[itemid] = 0 
            table.insert(obj._d_data.teamBag,itemid)
            local pdIdx = #obj._d_data.teamBag
            obj._bagitems[pdIdx]:init(itemid) --��ʾ�����ĵ�����
        end
    end
   obj._d_data.pdLine.total =  obj._d_data.pdLine.total + s_cfg.fcd --��������������ʱ��
   obj._d_data[s_cfg.coin] = obj._d_data[s_cfg.coin] - s_cfg.basePrice
   SendMsg[933001](itemid)--����������Ϣ��������
end

--��ʾ������ʾ
function __shoplayer.showPrompt(obj,msg,posX,posY)
    local fontName = FNList.STHUPO
    local fontSize = 32
    local lbl = Label:create()
	lbl:setAnchorPoint(ccp(0.5,0))
	lbl:setFontName(fontName)
	lbl:setFontSize(fontSize)
	lbl:setText(msg)
	obj:egAddChild(lbl,kPromptZorder,kPromptZorder)
    lbl:setPosition(ccp(posX,posY))
    local fadeout = CCFadeOut:create(0.2)
    local moveby = CCMoveBy:create(0.8,ccp(0,kMoveDistance))
    local sequence1 = CCSequence:createWithTwoActions(moveby,fadeout)
    local function callback()
        obj:egNode():removeChild(lbl,true)
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(sequence1,callfunc)
    lbl:runAction(sequence)
end
--���ز���ʾ����ȼ�
function __shoplayer.refreshLv(obj)
    local trainlv = obj._d_data.train[train.def.shop].lv
    if obj._trainlv ~= trainlv then
        obj._trainlv = trainlv
        local lvTxt = string.format("%s%d","LV",obj._trainlv)
        obj:egSetLabelStr(kLblLv_s,lvTxt)
        obj:egSetLabelStr(kLblLv,lvTxt)
    end
end
--���ز�����������ʾ
function __shoplayer.refreshBagCap(obj)
    local usedBagCapacity = obj._d_data.usedBagCapacity
    if obj._usedBagCapacity ~= usedBagCapacity then
        obj._usedBagCapacity = usedBagCapacity
        obj:egSetLabelStr(kLblCapacity,string.format("%d%s%d",obj._usedBagCapacity,"/",obj._d_data.bagCapacity))
    end
end

--���ذ����¼�
function __shoplayer.bindBackListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_back_button)
       sender:setTouchEnabled(false)
       local scene = TownScene.new()
	   scene:egReplace()
    end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,nil)
end
--���ٴ����¼�
function __shoplayer.bindSpeedUpListener(obj)
    local function touchEnded(sender)
		SoundHelper.playEffect(SoundList.click_buy_button)
       sender:setTouchEnabled(false)
       obj._d_data[kCoinType] = obj._d_data[kCoinType] - obj._speedupVal
       --���ٴ�������
       for key,item in ipairs(account_data.pdLine.items) do
           account_data.bag[item.itemid] =   account_data.bag[item.itemid] + item.cnt
       end
       account_data.pdLine={items={},st=0,passed = 0,total=0}
	   SendMsg[933004]()--���ͼ�����Ϣ��������
       sender:setTouchEnabled(true)
    end
    obj:egBindTouch(kBtnSpeedUp,nil,nil,touchEnded,nil)
end
function __shoplayer.activeUpdate(obj)
    local function update(delta)
       obj:refreshLv()
	   obj:refreshBagCap()
	end
	obj:egBindWidgetUpdate(kLblLv,update)
end
ShopLayer={}
function ShopLayer.new(d_data)
    local obj = TouchWidget.new(JsonList.shopLayer)
    table_aux.unpackTo(__shoplayer, obj)
    obj:init(d_data)
    obj:bindBackListener()
	obj:bindSpeedUpListener()
	obj:activeUpdate()
    return obj
end

local kBtnItem = "btn_item"
local kBtnInfo = "btn_info"
local kPanelNotice = "notice_layer"
local kImgCoin = "img_coin"
local kLblCoin = "lbl_val"
local kLblNotice = "lbl_notice"
local kGrayColor = ccc3(128,128,128)
local kRedColor = ccc3(255,0,0)
local kWhiteColor = ccc3(255,255,255)
local __shopitem ={}
function __shopitem.init(obj,itemid)
    obj._itemid = itemid
    obj._lvNotFit = false
    obj._s_data = itemQuery.query(obj._itemid) --��ȡ���߾�̬����
    obj._needLv = obj._s_data.lv
    obj._noticeInfo = string.format("%s %s%d",train.config[train.def.shop].name,"LV",obj._needLv)
    obj._trainLv = account_data.train[train.def.shop].lv
    obj._needCoin = obj._s_data.basePrice --����
    obj:egChangeBtnImg(kBtnItem,obj._s_data.icon,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLblNotice,obj._noticeInfo)
    obj:egSetBMLabelStr(kLblCoin,Funs.formatNum(obj._needCoin))
    obj:egChangeImg(kImgCoin,ImageList[string.format("comm_%s",obj._s_data.coin)],UI_TEX_TYPE_PLIST)
    obj:loadData()
end
function __shopitem.getItemId(obj)
    return obj._itemid
end
function __shopitem.loadData(obj)
    if obj._needLv > obj._trainLv then
        obj._lvNotFit = true
        obj:egHideWidget(kImgCoin)
        obj:egShowWidget(kPanelNotice)
        obj:egSetWidgetColor(kBtnItem,kGrayColor)
    else
        obj._lvNotFit = false
        obj:egHideWidget(kPanelNotice)
        obj:egShowWidget(kImgCoin)
        obj:egSetWidgetColor(kBtnItem,kWhiteColor)
        if obj._needCoin > account_data[obj._s_data.coin] then
            obj:egSetWidgetColor(kLblCoin,kRedColor)
        else
             obj:egSetWidgetColor(kLblCoin,kWhiteColor)
        end
    end
    
end
function __shopitem.activeUpdate(obj)
    local function update()
        if  obj._lvNotFit then
            if obj._trainLv ~= account_data.train[train.def.shop].lv then
                obj._trainLv = account_data.train[train.def.shop].lv
                obj:loadData()
            end
        else
            if obj._needCoin > account_data[obj._s_data.coin] then
                obj:egSetWidgetColor(kLblCoin,kRedColor)
            else
                 obj:egSetWidgetColor(kLblCoin,kWhiteColor)
            end
        end 
	end
	obj:egBindWidgetUpdate(btn_item,update)
end
function __shopitem.onClicked(obj,callback)
    obj._clickCallback = callback
end
--����Ʒ��ϸ����¼���������Ʒ��ϸ��Ϣ
function __shopitem.bindInfoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
        local function callback()
            sender:setTouchEnabled(true)
        end
		SoundHelper.playEffect(SoundList.click_shop_goods)
        showShopItemDetail(obj._s_data,callback)
    end
    obj:egBindTouch(kBtnInfo,nil,nil,touchEnded,nil)
end
function __shopitem.canBuy(obj)
    if obj._lvNotFit then return false end
    if obj._needCoin > account_data[obj._s_data.coin] then return false end
    return true
end
function __shopitem.getNotifyMsg(obj)
    local msg = ""
    if obj._lvNotFit then
        msg = string.format("%s%s",TxtList.need,obj._noticeInfo)
    elseif obj._needCoin > account_data[obj._s_data.coin] then
        msg = TxtList.needCoin
    end
    return msg
end
function __shopitem.doClickItem(obj,sender)
	sender:setTouchEnabled(false)
	obj._touchEndPos = sender:getTouchEndPos()
	if obj._clickCallback then obj._clickCallback(obj) end
	sender:setTouchEnabled(true)
end
--����Ʒ����¼�
function __shopitem.bindClickListener(obj)
	local function touchBegan(sender)
		 if AccountHelper:isLocked(kStateGuide) then --����״̬
			obj:doClickItem(sender)
		 end
	end
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide) then --������״̬
			obj:doClickItem(sender)
		 end
    end
    obj:egBindTouch(kBtnItem,touchBegan,nil,touchEnded,nil)
end
function __shopitem.getTouchEndPos(obj)
    return obj._touchEndPos
end
ShopItem = {}
function ShopItem.new(itemid)
    local obj={}
    CocosWidget.install(obj,JsonList.shopItem)
    table_aux.unpackTo(__shopitem, obj)
    obj:init(itemid)
    obj:activeUpdate()
    obj:bindInfoListener()
    obj:bindClickListener()
    return obj
end
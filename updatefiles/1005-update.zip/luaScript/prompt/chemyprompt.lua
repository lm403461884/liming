local kBtnOk = "btn_ok"
local kPanelLayer = "prompt_panel"
local kImgBg = "img_bg"
local kLabelTitle = "lbl_title"
local kImgItem = "img_item"
local kLabelLv = "lbl_lv_change"
local kLabelHp = "lbl_hp_change"
local kLabelAtk = "lbl_atk_change"
local kTypeHero = 1
local kTypeMonster = 2
local __chemyprompt = {}
function __chemyprompt.init(obj,data)
	local utype = data.utype
    local itemid = data.itemid
    local from = data.from
    local to = data.to
	local s_cfg = nil
	local name = nil
	if utype == kTypeHero then
		s_cfg = hero_data.getConfig(itemid)
		name = s_cfg.heroName
	else
		s_cfg = monster_data.getConfig(itemid)
		name = s_cfg.name
	end
    local s_data_from = s_cfg[from]
    local s_data_to = s_cfg[to]
    obj:egSetLabelStr(kLabelTitle,string.format("%s%s",name,obj:egGetLabelStr(kLabelTitle)))
    obj:egSetLabelStr(kLabelLv,string.format("LV%d%sLV%d",from,TxtList.arrowSymbol,to))
    obj:egSetLabelStr(kLabelHp,string.format("%d%s%d",s_data_from.maxHP,TxtList.arrowSymbol,s_data_to.maxHP))
    obj:egSetLabelStr(kLabelAtk,string.format("%d%s%d",s_data_from.power,TxtList.arrowSymbol,s_data_to.power))
    obj:egChangeImg(kImgItem,s_cfg.headPic,UI_TEX_TYPE_PLIST)
end
function __chemyprompt.bindOkListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnOk,false)
        SoundHelper.playEffect(SoundList.click_back_button)
        obj:hideWithAction()
    end
    obj:egBindTouch(kBtnOk,nil,nil,touchEnded,nil)
end
function __chemyprompt.hideWithAction(obj)
    local function callback()
        obj:egRemoveSelf()
        AccountHelper:unlock(kStatePrompt)
    end
    obj._masklayer:runAction(CCFadeTo:create(0.4,0))
    local actCallBack = CCCallFunc:create(callback)
    local fadeOut = CCFadeOut:create(0.4)
    local moveto = CCMoveTo:create(0.4,ccp(0,720))
    local spawn = CCSpawn:createWithTwoActions(fadeOut,moveto)
    local squence = CCSequence:createWithTwoActions(spawn,actCallBack)
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:runAction(squence)
end
function __chemyprompt.showWithAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,128)) 
    local baseWidget = obj:egGetWidgetByName(kPanelLayer)
    baseWidget:setPosition(ccp(0,720))
    local fadein = CCFadeIn:create(0.2)
    local moveto = CCMoveTo:create(0.5,ccp(0,0))
    local bounceMove = CCEaseBackOut:create(moveto)
    local spawn = CCSpawn:createWithTwoActions(fadein,bounceMove)
     if obj._onloaded then
        local callfunc = CCCallFunc:create(obj._onloaded)
        local sequece = CCSequence:createWithTwoActions(spawn,callfunc)
        baseWidget:runAction(sequece)
    else
        baseWidget:runAction(spawn)
    end
end
ChemyPrompt={}
function ChemyPrompt.new(data,onloaded)
   local obj =  TouchWidget.new(JsonList.chemyPromt)
    table_aux.unpackTo(__chemyprompt, obj)
    obj._onloaded = callback
    obj:init(data)
    obj:bindOkListener()
    return obj
end
function showChemyPrompt(data,onloaded)
    local layer = ChemyPrompt.new(data,onloaded)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
    layer:showWithAction()
end
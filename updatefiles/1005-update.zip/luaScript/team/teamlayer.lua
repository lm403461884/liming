local kPanelMember = "member_panel"
local kPanelCard = "hero_list"
local kPanelItem = "item_list"
local kBtnBack = "btn_back"
local kLblTrain ="lbl_train"  --̽�ն�
local kLblAttack = "lbl_attack"
local kLblConsume = "lbl_material"  --��ս���ʣ�ս��������������
local kCellW1 = 142
local kCellW2 = 200
local kMarginX1 = 10
local __teamlayer = {}
function __teamlayer.init(obj)
    obj._selectedCardIdx = nil
    obj._selectedItemIdx = nil
    obj._heroItems = {} --Ӣ�ۿ�
    obj._heroCards = {} --Ӣ�ۿ�Ƭ
    obj._oldTeam = Funs.copy(obj._d_data.team)
    obj._heroAtkList =obj:getHeroAtkCapList()--��ȡ����Ӣ�������б�
    obj._capHashTb,obj._capTb = obj:getOrderdHeroList()
    obj._trainLv = 1
    if obj._d_data.train[train.def.anteroom] then
        obj._trainLv = obj._d_data.train[train.def.anteroom].lv
    end
    obj:egSetLabelStr(kLblTrain,string.format("%s LV%d",TxtList.riskTeam,obj._trainLv))
    obj:egSetLabelStr(kLblConsume,obj._d_data.consume)--��ս����
    obj:refreshTeamAtkCap()
    obj:loadHeroCards()
    obj:loadHeroItems()
end
--����ļ������Ӣ��ս�������ݱ�
function __teamlayer.getHeroAtkCapList(obj)
    local tb = {}
    for heroid,heroprop in pairs(obj._d_data.heroList) do
        local equiplv,equipqa =  equipFuncs.getEquipQL(heroprop.eid,obj._d_data)
        local atkcap = baseCalc.getBattlePoint(heroprop.lv,equiplv,equipqa)
        tb[heroid] = atkcap
    end
    return tb
end
--��ȡ��ս���������Ӣ���б�
function __teamlayer.getOrderdHeroList(obj)
    local tb = {} --ս���������
    local hashtb = {}--ս���������
    for key,heroprop in pairs(obj._d_data.heroList) do
        local atkcap = obj._heroAtkList[heroprop.type]
        if not hashtb[atkcap] then
            hashtb[atkcap]={heroprop.type}
            table.insert(tb,atkcap)
        else
            table.insert(hashtb[atkcap],heroprop.type)
        end
    end
    table.sort(tb,function(a,b) return a>b end)
    return hashtb,tb
end
--����С��ս������ֵ��ʾ
function __teamlayer.refreshTeamAtkCap(obj)
    local teamAtk = 0
    for key,heroid in ipairs(obj._d_data.team) do
        teamAtk = teamAtk + obj._heroAtkList[heroid]
    end
    obj:egSetLabelStr(kLblAttack,teamAtk)
end

--����Ӣ�ۿ�Ƭ
function __teamlayer.loadHeroCards(obj)
    local listview = obj:egGetScrollView(kPanelCard)
    local loadedNum = 0
    for key,heroid in ipairs(obj._d_data.team) do
         local herocard =  HeroCard.new(heroid)
         listview:addChild(herocard:egNode())
         herocard:egSetPosition(loadedNum*kCellW2,0)
         obj._heroCards[heroid] = herocard
         obj:bindJoinTeamCallback(herocard)
         loadedNum = loadedNum +1
    end
    for idx,cap in pairs(obj._capTb) do
         for key,heroid in ipairs(obj._capHashTb[cap]) do
             if not obj._heroCards[heroid] then
                local herocard =  HeroCard.new(heroid)
                listview:addChild(herocard:egNode())
                herocard:egSetPosition(loadedNum*kCellW2,0)
                obj._heroCards[heroid] = herocard
                obj:bindJoinTeamCallback(herocard)
                loadedNum = loadedNum +1
             end
         end
    end
    local neww = kCellW2 * loadedNum
    local size = listview:getSize()
    if neww > size.width then
        listview:setInnerContainerSize(CCSizeMake(neww,size.height))
    end
end
--�󶨿�Ƭ���Ƶ���¼�
function __teamlayer.bindJoinTeamCallback(obj,herocard)
    local function callback(sender)
        local heroid = sender:getHeroID()
        table.insert(account_data.team,heroid)
        obj:reorderHeroCard()
        
        local pos = #account_data.team
        local heroitem = obj._heroItems[pos]
        heroitem:loadHeroAtPos(pos)
        obj:refreshTeamAtkCap()
		--�ھ���־������̸��� ����С�ӳ�Ա
		task.updateTaskStatus(account_data,task.client_event_id.team_add,{heroid})	
		----------------------
    end
    herocard:onJoinClicked(callback)
end
--���¶�Ӣ�ۿ�Ƭ��������
function __teamlayer.reorderHeroCard(obj)
    local loadedNum = 0
    local teamtb = {}
     for key,heroid in ipairs(obj._d_data.team) do
        teamtb[heroid] = 1
         local herocard =  obj._heroCards[heroid]
         local moveto = CCMoveTo:create(0.2,ccp(loadedNum*kCellW2,0))
         herocard:egNode():runAction(moveto)
         --herocard:egSetPosition(loadedNum*kCellW2,0)
         herocard:updateJoinState()
         loadedNum = loadedNum +1
    end
    for idx,cap in pairs(obj._capTb) do
         for key,heroid in ipairs(obj._capHashTb[cap]) do
             if not teamtb[heroid] then
                local herocard =  obj._heroCards[heroid]
                local moveto = CCMoveTo:create(0.2,ccp(loadedNum*kCellW2,0))
                herocard:egNode():runAction(moveto)
                herocard:updateJoinState()
                --herocard:egSetPosition(loadedNum*kCellW2,0)
                loadedNum = loadedNum +1
             end
         end
    end
    teamtb= nil
end
function __teamlayer.reOrderHeroItem(obj)
    for idx,heroitem in ipairs(obj._heroItems) do
        heroitem:loadHeroAtPos(idx)
        heroitem:setItemTouchEnabled(false)
        local function callback()
            heroitem:setItemTouchEnabled(true)
        end
        local callfunc = CCCallFunc:create(callback)
        local moveto = CCMoveTo:create(0.2,ccp((idx-1)*(kCellW1+kMarginX1),0))
        local sequence = CCSequence:createWithTwoActions(moveto,callfunc)
        heroitem:egNode():runAction(sequence)
    end
end
--����С��Ӣ��
function  __teamlayer.loadHeroItems(obj)
    local listview= obj:egGetWidgetByName(kPanelItem)
    for idx=1,obj._d_data.maxTeam do
        local heroitem = TeamNow.new(idx)
        heroitem:egSetPosition((idx-1)*(kCellW1+kMarginX1),0)
        listview:addChild(heroitem:egNode())
        table.insert(obj._heroItems,heroitem)
        obj:bindItemClickEvent(heroitem)
    end
end
--Ӣ�ۿ����¼�
function __teamlayer.bindItemClickEvent(obj,heroitem)
    local function clickCallback(sender)
        local heroid = sender:getHeroID()
        local oldCnt = #account_data.team
        local pos = sender:getHeroPos() 
        table.remove(account_data.team,pos)
        if pos == oldCnt then
            obj:refreshTeamAtkCap()
            obj:reOrderHeroItem()
            obj:reorderHeroCard()
        else
            table.insert(obj._heroItems,sender)
            table.remove(obj._heroItems,pos)
            local x = oldCnt*(kCellW1+kMarginX1)
            sender:egSetPosition(x,0)
            obj:refreshTeamAtkCap()
            obj:reOrderHeroItem()
            obj:reorderHeroCard()
        end
    end
    heroitem:onItemClicked(clickCallback)    
end

--�󶨷��ذ���������
function __teamlayer.bindBackListener(obj)
    local function touchEnded(sender)
        obj:egSetWidgetTouchEnabled(kBtnBack,false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        SoundHelper.playEffect(SoundList.click_back_button) --����
         if not Funs.isTbEqual(obj._oldTeam,obj._d_data.team)  then
            SendMsg[934003](obj._d_data.team,0)
        end
        local scene = TownScene.new()
        scene:egReplace()
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnBack,nil,nil,touchEnded,touchCanceled)
end 
TeamLayer={}
function TeamLayer.new(d_data)
    local obj = TouchWidget.new(JsonList.teamLayer)
    table_aux.unpackTo(__teamlayer, obj)
    obj._d_data=d_data
    obj:init()
    obj:bindBackListener()
    return obj
end
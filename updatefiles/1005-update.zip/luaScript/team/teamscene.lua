local __teamscene = {}
TeamScene = {}
function TeamScene.new(replaceScene)
    local obj = {}
    Scene.install(obj)
    table_aux.unpackTo(__teamscene, obj)
    obj._layer = TeamLayer.new(account_data,replaceScene)
    obj._layer:egAttachTo(obj)
    showEmDialog(obj,GuideScene.def.kTeamScene) --����������Ϣ
    
    obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
    return obj
end
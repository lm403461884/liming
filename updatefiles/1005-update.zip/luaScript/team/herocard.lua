local kBtnJoin = "btn_join"
local kBtnLeave = "btn_member"
local kBtnPhoto = "btn_photo"
local kBtnEquip = "btn_equip_bg"

local kImgBar = "member_bg_bar"

local kLblName = "lbl_name"
local kLblLv = "lbl_lv"
local kLblAtk = "lbl_atk_val"
local kLblExp = "lbl_exp_val"
local kImgExp = "exp_bar"

local kImgEquip = "img_item"
local kLblEquipLv="lbl_equip_lv"
local kImgColor = "img_color_bg"


local __herocard={}

function __herocard.init(obj,heroid)
    obj:egHideWidget(kImgBar) --ѡ�п�
    obj:egSetWidgetTouchEnabled(kBtnEquip,false) --������ť
    obj:egSetWidgetTouchEnabled(kBtnLeave,false) --С�ӱ�ʶ��ť
    
    obj._heroid = heroid
    obj._herodata =  account_data.heroList[obj._heroid]
    obj._s_herodata = hero_data.get(obj._heroid,obj._herodata.lv)
    obj._s_cfg = hero_data.getConfig(obj._heroid)
    
    local equip_cfg = equipCfg[obj._herodata.eid]
    local equiplv,equipqa = equipFuncs.getEquipQL(obj._herodata.eid, account_data)
    local atkcap = baseCalc.getBattlePoint(obj._herodata.lv,equiplv,equipqa)
    obj:egChangeImg(kImgEquip,equip_cfg.icon,UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblEquipLv,equiplv) --��ʾ�����ȼ�
        --��ʾ����Ʒ��
	obj:egSetWidgetColor(kImgColor,KVariantList.equipColor[equipqa])
    
    obj:egSetLabelStr(kLblName, obj._s_cfg.heroName)
    obj:egChangeBtnImg(kBtnPhoto,obj._s_cfg.photo,"","",UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblLv,obj._herodata.lv)
    obj:egSetLabelStr(kLblAtk,atkcap)
    --������
	local widget = obj:egGetWidgetByName(kImgExp)
	--ת������
    local expbar = tolua.cast(widget,"ImageView")
	local sprite = tolua.cast(widget:getVirtualRenderer(),"CCSprite")
	local rect = sprite:getTextureRect()
    local expsize = expbar:getSize()
    local explen = (1-obj._herodata.exp/obj._s_herodata.exp) * expsize.width
    expbar:setTextureRect(CCRectMake(rect.origin.x + expsize.width-explen,rect.origin.y,explen,expsize.height))
	obj:egSetLabelStr(kLblExp,string.format("%d%s%d",obj._s_herodata.exp-obj._herodata.exp,"/",obj._s_herodata.exp))
    obj:updateJoinState()
end
function __herocard.updateJoinState(obj)
    obj:egHideWidget(kBtnJoin)
    if obj:isTeamMember() then
        obj:egShowWidget(kBtnLeave)
    else
        obj:egHideWidget(kBtnLeave)
        if account_data.maxTeam > #account_data.team then
            obj:egShowWidget(kBtnJoin)
            obj:egSetWidgetTouchEnabled(kBtnJoin,true)
        end
    end
end

function __herocard.getHeroID(obj)
    return obj._heroid
end
--�ж��Ƿ���С�ӳ�Ա
function __herocard.isTeamMember(obj)
    for key,val in ipairs(account_data.team) do
        if val == obj._heroid then return key end
    end
    return nil
end

function __herocard.onJoinClicked(obj,onclicked)
    obj._joinCallback = onclicked
end
function __herocard.bindJoinListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_monster_menu)
        obj:egShowWidget(kBtnLeave)
        obj:egHideWidget(kBtnJoin)
        if obj._joinCallback then obj._joinCallback(obj) end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnJoin,nil,nil,touchEnded,touchCanceled)
end
function __herocard.bindPhotoListener(obj)
    local function touchEnded(sender)
        sender:setTouchEnabled(false)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		SoundHelper.playEffect(SoundList.click_paper_open)
        --��ͨ��Ԥ������
        ShowHeroInfo(obj._heroid)
        sender:setTouchEnabled(true)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnPhoto,nil,nil,touchEnded,touchCanceled)
end

HeroCard={}
function HeroCard.new(pos,herotb)
    local obj = {}
    CocosWidget.install(obj,JsonList.teamMember)
    table_aux.unpackTo(__herocard, obj)
    obj:init(pos,herotb)
    obj:bindPhotoListener()
    obj:bindJoinListener()
    return obj
end


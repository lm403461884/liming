local __hero = {}
function __hero.openAi(obj)
    ai_module.add(obj)
    obj:showHP()
end
function __hero.moveToPos(obj,dir,x,y,sec,callback)
    local moveto = CCMoveTo:create(sec,ccp(x,y))
    local function callbackfunc()
        obj:egNode():stopAllActions()
        obj:egChangeFrame(obj._startFrame)
        if callback then callback() end
    end
    local action_callback = CCCallFuncN:create(callbackfunc)
    local sequence = CCSequence:createWithTwoActions(moveto,action_callback)
    local animaName = string.format('%s_02%02d', obj:getprop('graphName'),dir/90)
    local anima = graphicLoader.getAnimation(animaName)
    if not anima then print('engine: can not find anima ' .. animaName) return end
    anima:setRestoreOriginalFrame(true)
    local animate = CCAnimate:create(anima)
    local action = CCRepeat:create(animate,1000000)
    local spawn = CCSpawn:createWithTwoActions(sequence,action)
    obj:egRunAction(spawn)
end
function __hero.moveToward(obj,dir,disance,sec)
    local x = 0
    local y = 0
    if dir == 90 then x = disance 
    elseif dir == 270 then x = -disance 
    elseif dir == 180 then y = -disance 
    elseif dir == 360 then y = disance end
    local moveby = CCMoveBy:create(sec,ccp(x,y))
    local function callbackfunc()
        obj:egNode():stopAllActions()
        obj:egChangeFrame(obj._startFrame)
    end
    local action_callback = CCCallFuncN:create(callbackfunc)
    local sequence = CCSequence:createWithTwoActions(moveby,action_callback)
    local animaName = string.format('%s_02%02d', obj:getprop('graphName'),dir/90)
    local anima = graphicLoader.getAnimation(animaName)
    if not anima then print('engine: can not find anima ' .. animaName) return end
    anima:setRestoreOriginalFrame(true)
    local animate = CCAnimate:create(anima)
    local action = CCRepeat:create(animate,1000000)
    local spawn = CCSpawn:createWithTwoActions(sequence,action)
    obj:egRunAction(spawn)
end

	Hero={}

function Hero.new(prop, pos,battleData)

    local obj = {}
    BaseProp.install(obj)
    InnerProp.install(obj)
    sprite.install(obj)
    Blood.install(obj)
    table_aux.unpackTo(__hero, obj)
	if not battleData then battleData = account_data end
	--read various config data
    local heroCfg = assert(hero_data.getConfig(prop.type))
    local heroDataAtLv = assert(hero_data.get(prop.type, prop.lv))
	local equipLv = assert(battleData.equipments[prop.eid][1])
	local equipQualityLv = assert(battleData.equipments[prop.eid][2])
	local equipDataAtLv = assert(equipNum[prop.eid][equipLv])
	local equipCfgOfEid = assert(equipCfg[prop.eid] or {skill=heroCfg.skillNames[1]})
    prop.hp =  prop.hp+ equipDataAtLv.maxHP
	obj._s_data = heroDataAtLv
    obj._d_data = prop
    
	--add static properties
    for name, val in pairs(heroDataAtLv) do
		obj:addprop(name, val)
    end
    
	--main
	obj:addprop('mainType', 1)
    obj:addprop('type', prop.type)
    obj:addprop("level", prop.lv)
    
	--about equipment
	obj:addprop('equipID', prop.eid)
	obj:addprop('equipLv', equipLv)
	obj:setprop('maxHP', heroDataAtLv.maxHP + equipDataAtLv.maxHP)
	obj:setprop('hp', prop.hp)
	obj:setprop('power', heroDataAtLv.power + equipDataAtLv.power)
	obj:setprop('activeSkill', equipCfgOfEid.skill)
	obj:setprop('activeSkillPowerPlus', equipEvoData[prop.eid][equipQualityLv]["powerPlus"])

	--ai
    obj:addprop('aiEntryName', heroCfg.aiEntryName)
    obj:addprop('skillNames', heroCfg.skillNames)
    obj:addprop("zorder", 0)
    obj:addprop("birthPlace",pos)
	obj:addprop("powerBar",prop.power)
	obj:addprop("maxPower",numDef.maxPower)
    obj:addprop('graphName', heroCfg.graphList[heroDataAtLv.graphLV])
    obj._startFrame = string.format('%s_010201.png',heroCfg.graphList[heroDataAtLv.graphLV])
    obj:egChangeFrame(obj._startFrame)
    
    return obj
end

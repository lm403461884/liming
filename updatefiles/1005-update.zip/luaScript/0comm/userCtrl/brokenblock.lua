local __brokenblock = {}
function __brokenblock.showEffect(obj,callbackfunc)
    local animaCache = CCAnimationCache:sharedAnimationCache()
	local anima = animaCache:animationByName(obj._animaName)
    local animate = CCAnimate:create(anima)
	local function callback()
		obj:egRemoveSelf()
		if callbackfunc then callbackfunc() end
	end
	local callfunc = CCCallFunc:create(callback)
	local sequence = CCSequence:createWithTwoActions(animate,callfunc)
    obj:egRunAction(sequence)
end
BrokenBlock={}
--������������
function BrokenBlock.new(animaName)
	local obj = {}
	table_aux.unpackTo(__brokenblock, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
	obj._animaName = animaName
	sprite.install(obj,Pic.getBrokenBlock(),true)
	return obj
end

local __blankblock={}
--��ʼ���յ�
--areaid:������α��
function __blankblock.init(obj,areaid,sur)
	obj:addprop("area",areaid)
	obj:addprop("sur",sur)
	obj:addprop("zorder",3)
	obj:addprop("birthPlace",0)
	obj:egChangeFrame(Pic.getBlank(areaid,sur))
end
function __blankblock.updateSur(obj)
	local sur = obj:getprop("sur")
	local framename = Pic.getBlank(obj:getprop("area"),sur)
	obj:egChangeFrame(framename)
end

Blankblock={}
--�����յ�
function Blankblock.new()

	local obj = {}
	table_aux.unpackTo(__blankblock, obj)
	BaseProp.install(obj)
	InnerProp.install(obj)
	sprite.install(obj)
	return obj
end

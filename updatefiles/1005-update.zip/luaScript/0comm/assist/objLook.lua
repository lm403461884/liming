ObjLook={}

function ObjLook.removeObj(obj)
	if obj == nil then return end
	AccountHelper:removeCreature(obj)
end

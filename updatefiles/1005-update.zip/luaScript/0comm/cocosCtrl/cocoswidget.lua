
local __cocoswidget = {}
function __cocoswidget.egGetWidgetByName(obj,childName)
    if not childName then return obj._egObj end
    local widget = obj._egObj:getChildByName(childName)
    if widget then return widget end
    
    local function findChild(parent,name)
        local childArray = parent:getChildren()
        local count = parent:getChildrenCount()
        if count <= 0 then return nil end
        for idx = 0,count-1 do  
            local item = tolua.cast(childArray:objectAtIndex(idx),"Widget")
            local child = item :getChildByName(name)
            if child then return child end
            local child = findChild(item,name)
            if child then return child end
        end
        return nil
    end
    widget = findChild(obj._egObj,childName)
    return widget
end
function __cocoswidget.egGetSize(obj)
    return obj._egObj:getSize()
end
function __cocoswidget.egGetName(obj)
    return obj._egObj:getName()
end
CocosWidget={}
function CocosWidget.install(obj,jsonFile)
    if not jsonFile and not obj._egObj then
        print("can not install CocosWidget functions with both jsonFile and obj.egObj are nil")
        return
    end
    if not obj._egObj then
        obj._egObj = GUIReader:shareReader():widgetFromJsonFile(jsonFile)
    end
    CocosNode.install(obj)
    WNode.install(obj)
    table_aux.unpackTo(__cocoswidget, obj)
end

local __zoomlayer={}
--����������ű���
function __zoomlayer.setMaxScale(obj,maxScale)
    if maxScale < obj._fixMaxScale then obj._fixMaxScale = maxScale end
    obj._maxScale = maxScale
    obj._egLayer:setScale(math.min(obj._egLayer:getScale(),obj._fixMaxScale))
end
--������С���ű���
function __zoomlayer.setMinScale(obj,minScale)
    if minScale > obj._fixMinScale then obj._fixMinScale = minScale end
    obj._minScale =minScale
    obj._egLayer:setScale(math.max(obj._egLayer:getScale(),obj._fixMinScale))
end

--��������Ӧ������ű���
function __zoomlayer.setFixMaxScale(obj,maxScale)
    if maxScale > obj._maxScale then obj._maxScale = maxScale end
    obj._fixMaxScale = maxScale
    obj._egLayer:setScale(math.min(obj._egLayer:getScale(),obj._fixMaxScale))
end
--��������Ӧ��С���ű���
function __zoomlayer.setFixMinScale(obj,minScale)
    if minScale < obj._minScale then obj._minScale = minScale end
    obj._fixMinScale = minScale
    obj._egLayer:setScale(math.max(obj._egLayer:getScale(),obj._fixMinScale))
end
--�������ű���
function __zoomlayer.setScale(obj,scale)
    obj._egLayer:setScale(math.min(math.max(scale,obj._minScale),obj._maxScale))
end
function __zoomlayer.refreshScale(obj)
     if not obj._viewRect:equals(CCRectMake(0,0,0,0)) then
        local csize = obj._egLayer:getContentSize()
        local intval,_ = math.modf(math.max(obj._viewRect.size.width/csize.width,obj._viewRect.size.height/csize.height)*100)
        local minscale = intval/100
        obj._fixMinScale = math.max(obj._fixMinScale,minscale)
        obj._minScale = math.max(obj._minScale,minscale)
        obj._maxScale = math.max(obj._maxScale,minscale)
        obj._fixMaxScale = math.max(obj._fixMaxScale,minscale)
    end
end
function __zoomlayer.getMinScale(obj)
     return obj._minScale
end
function __zoomlayer.getFixMinScale(obj)
    return obj._fixMinScale
end
function __zoomlayer.getMaxScale(obj)
    return obj._maxScale
end
function __zoomlayer.getFixMaxScale(obj)
    return obj._fixMaxScale
end

function __zoomlayer.setScrollSpead(obj,val)
    obj._speedAutoScroll = val
end

--����ͼ��λ�� �� egSetPosition����ʹ��
function __zoomlayer.egSetPositon(obj,x,y)
    obj._egLayer:setPosition(x,y)
    if obj._viewRect:equals(CCRectMake(0,0,0,0)) then return end
    local layer = obj._egLayer
    local anchor = layer:getAnchorPoint()
    local boundBox = layer:boundingBox()
    local origin = obj._viewRect.origin
    local size = obj._viewRect.size
    if layer:getPositionX() - boundBox.size.width * anchor.x > origin.x then
        layer:setPosition(boundBox.size.width * anchor.x + origin.x,layer:getPositionY())
    end 
    
    if layer:getPositionY() - boundBox.size.height * anchor.y > origin.y then
        layer:setPosition(layer:getPositionX(),boundBox.size.height* anchor.y + origin.y)
    end
    
    if layer:getPositionX() + boundBox.size.width*(1-anchor.x) < size.width + origin.x then
        layer:setPosition(size.width + origin.x - boundBox.size.width*(1-anchor.x),layer:getPositionY())
    end
    
    if layer:getPositionY() + boundBox.size.height * (1- anchor.y) < size.height + origin.y then
        layer:setPosition(layer:getPositionX(),size.height + origin.y - boundBox.size.height * (1- anchor.y))
    end

 end
function __zoomlayer.onTouchStart(obj,touches)
   -- print("touch start---------------------")
	--obj._egObj:stopAllActions()
     --����touch�����������
    for i = 1,#touches,3 do
        obj._touches[touches[i+2]] = ccp(touches[i],touches[i+1])
        obj._touchCount = obj._touchCount + 1
      --  print("start:=------------------",touches[i],touches[i+1],touches[i+2],obj._touchCount)
    end
        --���ֻ��һ�����ص㣬���¼touch��ʼλ��
    if obj._touchCount == 1 then    
         obj._touchStartPoint = ccp(touches[1],touches[2])
    end
end
function __zoomlayer.onMultiTouch(obj,touches)
     local curPoint1 = ccp(touches[1],touches[2])
     local curPoint2 = ccp(touches[4],touches[5])
     local idx1 = touches[3]
     local idx2= touches[6]
     local prePoint1 = obj._touches[idx1]
     local prePoint2 = obj._touches[idx2]
            
     obj._touches[idx1]= curPoint1
     obj._touches[idx2] = curPoint2
            
     local curMid = ccpMidpoint(curPoint1,curPoint2)
     local preMid = ccpMidpoint(prePoint1,prePoint2)
            
     local preScale = obj._egLayer:getScale()
     local newScale = obj._egLayer:getScale() * ccpDistance(curPoint1,curPoint2)/ccpDistance(prePoint1,prePoint2)
     obj:setScale(newScale)
     --���scale�����仯��������ʾλ��
     local curScale = obj._egLayer:getScale()
     if curScale ~= preScale then
         local contentsize = obj._egLayer:getContentSize()
         local realCurMid = obj:egPosInNode(curMid.x,curMid.y)
         local anchor = obj._egLayer:getAnchorPoint()
         local deltaX = (realCurMid.x - anchor.x * contentsize.width)* (curScale - preScale)
         local deltaY = (realCurMid.y - anchor.y * contentsize.height)*(curScale - preScale)
         local x = obj._egLayer:getPositionX() - deltaX
         local y = obj._egLayer:getPositionY() - deltaY
         obj:egSetPositon(x,y)
         obj._midPoint = realCurMid
      end
      if not preMid:equals(curMid) then
          local newposX = obj._egLayer:getPositionX() + curMid.x - preMid.x
          local newposY = obj._egLayer:getPositionY() + curMid.y - preMid.y
          obj:egSetPositon(newposX,newposY)
      end
end
function __zoomlayer.onTouchMoved(obj,touches)
     local curPoint = ccp(touches[1],touches[2])
     local idx= touches[3]
    -- print("move:----------------",touches[1],touches[2],touches[3])
     local prePoint = obj._touches[idx]
     if not prePoint then return end
     local newx = obj._egLayer:getPositionX() + curPoint.x - prePoint.x
     local newy = obj._egLayer:getPositionY() + curPoint.y - prePoint.y
     obj:egSetPositon(newx,newy)   
    -- print("move to:-------------------------------------",newx,newy)
     obj._touches[idx] = curPoint
     local curtime = HOAux:getMS()--��ȡ��ǰʱ��
     local interval = curtime - obj._touchStartTime --�������㴥��ʱ����
     obj._touchStartTime = HOAux:getMS()
      --����ʱ�䳤���趨ʱ��ʱ�����»�ȡ��ʼ������
     if interval > obj._holdTimeInterval then
          obj._touchStartPoint = ccp(touches[1],touches[2])
         -- print("reset start------------------")
     end
end
function __zoomlayer.onTouchEnd(obj,touches)
     local touchEndPoint = nil
     for i = 1,#touches,3 do
         touchEndPoint = ccp(touches[i],touches[i+1])
         obj._touches[touches[i+2]] = nil
         obj._touchCount = obj._touchCount - 1
        -- print("end:=------------------",touches[i],touches[i+1],touches[i],touches[i+2],obj._touchCount)
      end
      if obj._touchCount == 1 then
            for _,item in pairs(obj._touches) do
                obj._touchStartPoint = item
            end
      elseif obj._touchCount <= 0 then
            obj._touchCount = 0
            local curTime = HOAux:getMS()
            local interval = curTime - obj._touchStartTime 
            if interval < obj._scrollInterval then
                 obj._moveDistance =  ccpDistance(touchEndPoint,obj._touchStartPoint)
                 obj._moveby = ccpSub(touchEndPoint,obj._touchStartPoint)
            else 
                obj._moveDistance  = 0
                obj._moveby =ccp(0,0)
            end
            --obj:recoverPositionAndScale()
           obj:doAutoScroll()
       end
end
function __zoomlayer.calculateMovePoint(obj,delta,scale)
    local newX = obj._egLayer:getPositionX() + delta.x
    local newY = obj._egLayer:getPositionY() + delta.y
   -- boundBox = obj._egLayer:boundingBox()
   -- local w = boundBox.size.width
   -- local h = boundBox.size.height
    boundBox = obj._egLayer:getContentSize()
    local w = boundBox.width*scale
    local h = boundBox.height*scale
    local anchor = obj._egLayer:getAnchorPoint()
    local origin = obj._viewRect.origin
    local size = obj._viewRect.size
    if newX - w* anchor.x > origin.x then
        newX = w* anchor.x + origin.x
    end
    if newY - h * anchor.y > origin.y then
        newY = h * anchor.y + origin.y
    end
    if newX + w * (1 - anchor.x) < size.width + origin.x then
        newX = size.width + origin.x - w * (1- anchor.x)
    end
    if newY + h * (1 - anchor.y) < size.height + origin.y then
        newY = size.height + origin.y -h*(1-anchor.y)
    end
    return ccp(newX,newY)
end
--�Զ�����
function __zoomlayer.doAutoScroll(obj,recover)
    obj._egLayer:stopAllActions()
    local duration = obj._moveDistance /obj._speedAutoScroll --�����Զ�����ʱ�䳤��
    local movePoint = obj:calculateMovePoint(obj._moveby,obj._egLayer:getScale())
    local function sequenceCallback()
        obj:recoverPositionAndScale()
    end
    local moveto = CCMoveTo:create(duration,movePoint)
    local callfunc = CCCallFunc:create(sequenceCallback)
    local sequence = CCSequence:createWithTwoActions(moveto, callfunc)
     obj._egLayer:runAction(sequence)
    obj._moveDistance = 0
     obj._moveby = ccp(0,0)
    obj._touchStartPoint = ccp(0,0)
end
--����λ�ú͹���
function __zoomlayer.recoverPositionAndScale(obj)
    obj._egLayer:stopAllActions()
    if obj._viewRect:equals(CCRectMake(0,0,0,0)) then return end
    local winSize = CCDirector:sharedDirector():getWinSize()
    local rightEdgeDistance = obj:rightEdgeDistance()
    local leftEdgeDistance = obj:leftEdgeDistance()
    local topEdgeDistance = obj:topEdgeDistance()
    local bottomEdgeDistance = obj:bottomEdgeDistance()
   
    local scale = obj:getFixMinScale()
    local curScale = obj._egLayer:getScale()
    
    if curScale < scale then
        local newpos = ccp(0,0)
        local anchor = obj._egLayer:getAnchorPoint()
        local contSize = obj._egLayer:getContentSize()
        if rightEdgeDistance and leftEdgeDistance and topEdgeDistance and bottomEdgeDistance then
            local dx = scale * contSize.width * (anchor.x - 0.5)
            local dy = scale * contSize.height *(anchor.y - 0.5)
            newpos = ccp(winSize.width * 0.5 + dx,winSize.height * 0.5 + dy)
        elseif rightEdgeDistance and leftEdgeDistance and topEdgeDistance  then
            local dx = scale* contSize.width * (anchor.x - 0.5)
            local dy = scale * contSize.height * (1.0- anchor.y)
            newpos = ccp(winSize.width * 0.5 + dx,winSize.height - dy)
        elseif rightEdgeDistance and leftEdgeDistance and bottomEdgeDistance then
            local dx = scale* contSize.width * (anchor.x - 0.5)
            local dy = scale * contSize.height * anchor.y
            newpos = ccp(winSize.width* 0.5 + dx,dy)
        elseif  rightEdgeDistance and topEdgeDistance and bottomEdgeDistance  then
            local dx = scale * contSize.width *(1.0 - anchor.x)
            local dy = scale * contSize.height * (anchor.y - 0.5)
            newpos = ccp(winSize.width - dx,winSize.height * 0.5 + dy)
        elseif leftEdgeDistance and topEdgeDistance and bottomEdgeDistance  then
            local dx = scale* contSize.width * anchor.x
            local dy = scale * contSize.height * (anchor.y - 0.5)
            newpos = ccp(dx,winSize.height * 0.5 + dy)
        elseif leftEdgeDistance and topEdgeDistance then
            local dx = scale * contSize.width * anchor.x
            local dy = scale * contSize.height * (1.0 - anchor.y)
            newpos = ccp(dx,winSize.height - dy)
        elseif leftEdgeDistance and  bottomEdgeDistance then
            local dx = scale * contSize.width * anchor.x
            local dy = scale * contSize.height * anchor.y
            newpos = ccp(dx,dy)
        elseif rightEdgeDistance and topEdgeDistance then
            local dx = scale * contSize.width * (1.0- anchor.x)
            local dy = scale * contSize.height *(1.0- anchor.y)
            newpos = ccp(winSize.width - dx,winSize.height - dy)
        elseif rightEdgeDistance  and bottomEdgeDistance then
            local dx = scale* contSize.width *(1.0- anchor.x)
            local dy = scale* contSize.height * anchor.y
            newpos = ccp(winSize.width-dx,dy)
        elseif topEdgeDistance or  bottomEdgeDistance then
            local dy = scale * contSize.height * (anchor.y - 0.5)
            newpos = ccp(obj._egLayer:getPositionX(),winSize.height * 0.5 + dy)
        elseif rightEdgeDistance or leftEdgeDistance then
            local dx = scale * contSize.width * (anchor.x - 0.5)
            newpos = ccp(winSize.width * 0.5 + dx,obj._egLayer:getPositionY())
        end

        local array = CCArray:create()
        array:addObject(CCScaleTo:create(obj._rubberEffectRecoveryTime,scale))
        array:addObject(CCMoveTo:create(obj._rubberEffectRecoveryTime,newpos))
        local action = CCSpawn:create(array)
        obj._egLayer:runAction(action) 
    end
    if curScale > obj._fixMaxScale then 
         local contentsize = obj._egLayer:getContentSize()
         local realCurMid = obj._midPoint 
         local anchor = obj._egLayer:getAnchorPoint()
         local deltaX = (realCurMid.x - anchor.x * contentsize.width)* (curScale - obj._fixMaxScale)
         local deltaY = (realCurMid.y - anchor.y * contentsize.height)*(curScale - obj._fixMaxScale)
         local newpos = obj:calculateMovePoint(ccp(deltaX,deltaY),obj._fixMaxScale)
        local array = CCArray:create()
        array:addObject(CCScaleTo:create(obj._rubberEffectRecoveryTime,obj._fixMaxScale))
        array:addObject(CCMoveTo:create(obj._rubberEffectRecoveryTime,newpos))
        local action = CCSpawn:create(array)
        obj._egLayer:runAction(action) 
    end  
         
end
function __zoomlayer.rightEdgeDistance(obj)
    local boundBox = obj._egLayer:boundingBox()
    local origin = obj._viewRect.origin
    local size = obj._viewRect.size
    local anchor = obj._egLayer:getAnchorPoint()
    local valInt,_ = math.modf(size.width + origin.x - obj._egLayer:getPositionX() - boundBox.size.width*(1-anchor.x))
    return math.max(valInt,0)
end

function __zoomlayer.leftEdgeDistance(obj)
    local boundBox = obj._egLayer:boundingBox()
    local origin = obj._viewRect.origin
    local size = obj._viewRect.size
    local anchor = obj._egLayer:getAnchorPoint()
    local valInt,_ = math.modf(obj._egLayer:getPositionX() - boundBox.size.width* anchor.x - origin.x)
    return math.max(valInt,0)
end

function __zoomlayer.topEdgeDistance(obj)
    local boundBox = obj._egLayer:boundingBox()
    local origin = obj._viewRect.origin
    local size = obj._viewRect.size
    local anchor = obj._egLayer:getAnchorPoint()
    local valInt,_ = math.modf(size.height + origin.y - obj._egLayer:getPositionY() - boundBox.size.height*(1-anchor.y))
    return math.max(valInt,0)
end

function __zoomlayer.bottomEdgeDistance(obj)
    local boundBox = obj._egLayer:boundingBox()
    local origin = obj._viewRect.origin
    local size = obj._viewRect.size
    local anchor = obj._egLayer:getAnchorPoint()
    local valInt,_ = math.modf(obj._egLayer:getPositionY() - boundBox.size.height* anchor.y - origin.y)
    return math.max(valInt,0)
end

function __zoomlayer.onTouchCancel(obj,touches)
    for i = 1,#touches,3 do
        obj._touches[touches[i+2]] = nil
        obj._touchCount = obj._touchCount - 1
    end
    obj._touchCount = 0
    obj._moveDistance = 0
    obj._moveby = ccp(0,0)
    obj._touchStartPoint = ccp(0,0)
end
function __zoomlayer.activeTouch(obj)
    local function touchesbegan(touches)
      --  print("-----------------begin")
       obj:onTouchStart(touches)
    end
    local function touchesmoved(touches)
        --print("-----------------move")
       if obj._touchCount > 1 and #touches>= 6 then
            obj:onMultiTouch(touches)
       else
            obj._touchCount = 1
            obj:onTouchMoved(touches)
       end  
    end
    local function touchesend(touches)
       -- print("-----------------edn")
        obj:onTouchEnd(touches)
    end
    local function touchescanceled(touches)
        -- print("-----------------cancel")
        obj:onTouchCancel(touches)
    end
    obj:egBindTouchesEvent(touchesbegan,touchesmoved,touchesend,touchescanceled)
end
--���ÿ�������
function __zoomlayer.setViewRect(obj,x,y,width,height)
    obj._viewRect = CCRectMake(x,y,width,height)
    --��������˿�������Ĵ�С,����ݿ��������С������С���ű���
    obj:refreshScale()
    obj:setScale(obj._fixMinScale)
    obj:egSetPositon(obj:egGetPosX(),obj:egGetPosY())
end
function __zoomlayer.initZoomLayer(obj)
    obj._maxScale = 5
    obj._minScale = 0.2
    obj._fixMaxScale = 4
    obj._fixMinScale = 0.5
    obj._midPoint = ccp(0,0)
    
    obj._touches = {}
    obj._touchCount = 0
    obj._moveDistance = 0
    obj._moveby = ccp(0,0)
    obj._touchStartPoint = ccp(0,0)
    obj._touchStartTime = 0
    obj._speedAutoScroll = 1000.0
    obj._holdTimeInterval = 50
    obj._scrollInterval = 5
    obj._rubberEffectRecoveryTime = 0.2
    
    obj._viewRect = CCRectMake(0,0,0,0)
    local visibleSize = CCDirector:sharedDirector():getVisibleSize()
    obj:setViewRect(0,0,visibleSize.width,visibleSize.height)
    obj._egLayer:setAnchorPoint(ccp(0,0))
    obj._egLayer:setPosition(ccp(0,0))
end
ZoomLayer={}
function ZoomLayer.new()
    local obj={}
    Layer.install(obj)
    obj._egLayer = obj._egObj
    for name, func in pairs(__zoomlayer) do
        obj[name] = func
    end
    obj:initZoomLayer()
    obj:activeTouch()
    return obj
end

local kBtnPost = "btn_post" --����
local kBtnInvite = "btn_invite" --��ļ
local kBtnFight = "btn_fight" --����
local kBtnCofc = "btn_cofc" --�ھ��̻�
local kBtnGrow = "btn_grow" --ѵ��
local kBtnRank = "btn_elo" --PVP��λ
local kBtnTask = "btn_task" --����
local kBtnDef = "btn_def" --�����
local kBtnSelfInfo = "btn_showself" --������Ϣ
local kBtnExFight = "btn_exfight" --Զ��

local kImgNewPost = "img_newPost"
local kImgNewInvite = "img_new_invite"
local kImgNewCofc = "img_new_cofc"
local kImgNewGrow = "img_new_grow"
local kImgNewDef = "img_new_def"
local kImgNewFinished = "img_newfinished"
local kImgNewExFight = "img_new_exfight"

local kLblUserName = "lbl_user_name"
local kLblDigLv = "lbl_diglv"
local kBtnExten = "btn_extension" --���밴ť
local kBtnPullDown = "btn_pulldown"
local kImgNotices = "img_notices"
--local kScrollview = "scrollview_btns"
local kPanelBtns = "panel_btns" 
local kPanelShow = "panel_show"
--local kImgBtnBg = "img_btn_bg"

local kLabelPvp = "lbl_pvp" --PVP��λ
local kLabelStar = "lbl_star" --PVE�Ǽ�
local kImgPvp = "img_king" --pvp��λ��ʶ
local kLabelDigLv = "lbl_licence"--ִ�յȼ�

local kLblPvpShellVal = "lbl_protect_val"
local kImgPvpShell = "img_protect"

local kScale1 = 0.9
local kScale2 = 1
local kInterval1 = 1
local kOffsetX = 360
local kOldHight = 420
local kOldWight = 200
local kPointBtns = ccp(4,2)
local kHidePoint = ccp(4,440)
local __menulayer = {}
function __menulayer.init(obj,d_data)
    obj._d_data = d_data
    obj._noticePost = false
    obj._noticeInvite = false
    obj._noticeDef= false
	
    --ִ�����
    obj:bindLicenceTimer()
    ---ð�����
    obj:bindMissionTimer()
    -----------------
	--�Ӷ����
    obj:loadExFightMenu()
    ------------------------------------
    --�Ӷ����
    obj:loadPvpMenu()
    ------------------------------------
    --���䣨¼���ʼ�)���
    obj:loadPostTimer()
    ------------------------------------
    --��ļ���
    obj:loadInviteMenu()
    ------------------------------------
    --ѵ�����
    obj:loadGrowMenu()
	------------------------------------
	 --�����
    obj:loadDefMenu()
    ------------------------------------
	--�ھ���־�������
    obj:loadTaskMenuTimer()
    ------------------------------------
    --��չ��ť���
    obj:bindExtensionTimer()
    --obj._show = false --�Ƿ�չ����չ��ť
	--------------------
    --pvp����ʱ��
	obj:loadPvpShellTimer()
	-------------------
    obj:egHideWidget(kPanelShow)
    obj:egHideWidget(kImgNotices)
    obj:egHideWidget(kBtnPullDown)
    widget = obj:egGetWidgetByName(kPanelBtns)
    widget:setPosition(kHidePoint)
    --------------------------------------    
    obj._btnFight = tolua.cast(obj:egGetWidgetByName(kBtnFight),"Button")
    obj:egSetLabelStr(kLblUserName,obj._d_data.nickName)
    obj:egSetBMLabelStr(kLblDigLv,obj._d_data.digLv)
end
function __menulayer.loadPvpShellTimer(obj)
	local leftval = 0
	local function update(delta)
		if obj._d_data.pvpShellInterval <= 0 then
			obj:egUnbindWidgetUpdate(kImgPvpShell)
			obj:egHideWidget(kImgPvpShell)
		else
			if leftval~=obj._d_data.pvpShellInterval then
				leftval = obj._d_data.pvpShellInterval
				obj:egSetBMLabelStr(kLblPvpShellVal,Funs.formatTime(leftval))
			end
		end
    end
    obj:egBindWidgetUpdate(kImgPvpShell,update)
	
end
--��ʾ����������������
function __menulayer.updateAreaStar(obj)
	obj._missionArea = licenceLevelup[obj._d_data.digLv].areaID --ȡ��ǰִ�ն�Ӧ��������Ϊ��������
    obj._curstar = obj._d_data.unlockedPVE[obj._missionArea].areaStars
    obj._totalstar = pveQuery.getStageCnt(obj._missionArea)*3
    obj:egSetLabelStr(kLabelStar,string.format("%d%s%d",obj._curstar,"/",obj._totalstar))
end
function __menulayer.loadExFightMenu(obj)
    if obj._d_data.digLv <  unLockMenu[menuDef.expedition] then
        obj:egChangeBtnImg(kBtnExFight,ImageList.btn_expedition_d,ImageList.btn_expedition_d,"",UI_TEX_TYPE_PLIST)
        obj._exFightUnlocked = false
		obj:egHideWidget(kImgNewExFight)
    else
       obj:egChangeBtnImg(kBtnExFight,ImageList.btn_expedition_n,ImageList.btn_expedition_s,"",UI_TEX_TYPE_PLIST)
       obj._exFightUnlocked = true
	   obj:bindNewExFightTimer()
    end
end
--��Զ����ʾ��ʱ��
function __menulayer.bindNewExFightTimer(obj)
	local imgWidget = obj:egGetWidgetByName(kImgNewExFight)
    imgWidget:setVisible(false)
	if account_data.exMission then
		local function update()
			if os.time() >= account_data.exMission.nextSt then
				obj:egUnbindWidgetUpdate(kImgNewExFight)
				imgWidget:setVisible(true)
				obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
			end
		end
		obj:egBindWidgetUpdate(kImgNewExFight,update)
	else
		imgWidget:setVisible(true)
		obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
	end
end
--����Զ�̶ӹ��ܰ�ť
function __menulayer.updateExFightMenu(obj)
    if not obj._exFightUnlocked and obj._d_data.digLv>= unLockMenu[menuDef.expedition] then
        obj._exFightUnlocked = true
        local popWidget = PopTxt.new(TxtList.unLockMenuInfo[menuDef.expedition],-kOffsetX,0)
         obj:egGetWidgetByName(kBtnExFight):addChild(popWidget:egNode())
         obj:egChangeBtnImg(kBtnExFight,ImageList.btn_expedition_n,ImageList.btn_expedition_s,"",UI_TEX_TYPE_PLIST)
		 obj:bindNewExFightTimer()
   end
end
--����PVP���ܰ�ť
function __menulayer.loadPvpMenu(obj)
    obj:egChangeImg(kImgPvp,ImageList.comm_elo,UI_TEX_TYPE_PLIST)
    obj:egSetLabelStr(kLabelPvp,obj._d_data.elo)
    
    if obj._d_data.digLv <  unLockMenu[menuDef.pvp] then
        obj:egChangeBtnImg(kBtnFight,ImageList.btn_pvp_d,ImageList.btn_pvp_d,"",UI_TEX_TYPE_PLIST)
        obj._pvpUnlocked = false
    else
       obj:egChangeBtnImg(kBtnFight,ImageList.btn_pvp_n,ImageList.btn_pvp_s,"",UI_TEX_TYPE_PLIST)
       obj._pvpUnlocked = true
    end
end
--����PVP���ܰ�ť
function __menulayer.updatePvpMenu(obj)
    if not obj._pvpUnlocked and obj._d_data.digLv>= unLockMenu[menuDef.pvp] then
        obj._pvpUnlocked = true
        local popWidget = PopTxt.new(TxtList.unLockMenuInfo[menuDef.pvp],-kOffsetX,0)
         obj:egGetWidgetByName(kBtnFight):addChild(popWidget:egNode())
         obj:egChangeBtnImg(kBtnFight,ImageList.btn_pvp_n,ImageList.btn_pvp_s,"",UI_TEX_TYPE_PLIST)
   end
end
function __menulayer.scaleWidget(obj,widget,from,to,s)
	local scaleto1 = CCScaleTo:create(s,from)
	local scaleto2 = CCScaleTo:create(s,to)
	local sequence = CCSequence:createWithTwoActions(scaleto1,scaleto2)
	local repeatever = CCRepeatForever:create(sequence)
	widget:runAction(repeatever)
end
--�ж��Ƿ�����¼�����ʾ��¼���ʶ
function __menulayer.loadPostTimer(obj)
    local imgWidget = obj:egGetWidgetByName(kImgNewPost)
    obj._noticePost = false
    imgWidget:setVisible(obj._noticePost)
	local function update()
        local hasNew = obj._d_data.newVideo or obj:hasUnReadMail()
        if hasNew~= obj._noticePos then
			obj._noticePos = hasNew
            imgWidget:setVisible(obj._noticePos)
            obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
        end
	end
	obj:egBindWidgetUpdate(kImgNewCofc,update)
end
function __menulayer.hasUnReadMail(obj)
	 for msgid,item in pairs (account_data.msgBoxList) do
		if item[1] == 0 then return true end
	 end
	 return false
end
--����ִ�ձ仯
function __menulayer.bindLicenceTimer(obj)
    local diglv = 0
    local function update()
        if diglv ~= obj._d_data.digLv then
            diglv = obj._d_data.digLv
            obj:egSetBMLabelStr(kLblDigLv,diglv)
			obj:updateAreaStar()
			obj:updatePvpMenu()--����PVP��ť״̬
			obj:updateInviteMenu()--����Invite��ť״̬
			obj:updateGrowMenu()--����Grow��ť״̬
			obj:updateDefMenu() --���·�����ھ�״̬
        end
    end
    obj:egBindWidgetUpdate(kLblDigLv,update)
end
--�ж��Ƿ���������
function __menulayer.hasNewMission(obj)
	local pveArea = obj._d_data.unlockedPVE[obj._missionArea]
	local nmdata = missionData.normal_mission[obj._missionArea]
	for key,stageid in ipairs(nmdata) do
		if not pveArea[stageid] or pveArea[stageid].stars == 0 then
			return true
		end
	end
	local dmdata = MissionHelper.getClientMission()
	for areaid,areadmdata in pairs (dmdata) do
		for groupidx,_ in ipairs(areadmdata) do
			local stageid =   MissionHelper.getStageId(areaid,groupidx)
			if stageid then return true end
		end
	end
	return false
end
--�����Ƿ���û��������
function __menulayer.bindMissionTimer(obj)
    local imgWidget = obj:egGetWidgetByName(kImgNewCofc)
    imgWidget:setVisible(false)
	---------------------------------
	local function update()
        local hasNew = obj:hasNewMission()
        if hasNew then
            imgWidget:setVisible(hasNew)
			obj:egUnbindWidgetUpdate(kImgNewCofc)
            obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
        end
	end
	obj:egBindWidgetUpdate(kImgNewCofc,update)
end

--������ļ���ܰ���
function __menulayer.loadInviteMenu(obj)
    obj:egGetWidgetByName(kImgNewInvite):setVisible(false)
    if obj._d_data.digLv < unLockMenu[menuDef.invite] then
        obj._inviteUnlocked = false
        obj:egChangeBtnImg(kBtnInvite,ImageList.btn_invite_d,ImageList.btn_invite_d,"",UI_TEX_TYPE_PLIST)
    else
         obj._inviteUnlocked = true
        obj:egChangeBtnImg(kBtnInvite,ImageList.btn_invite_n,ImageList.btn_invite_s,"",UI_TEX_TYPE_PLIST)
        obj:loadInviteFlag()
    end
end
--������ļ��ť״̬
function __menulayer.updateInviteMenu(obj)
    if not obj._inviteUnlocked and obj._d_data.digLv >= unLockMenu[menuDef.invite] then
        obj._inviteUnlocked = true
		local offsetY = obj:egGetWidgetByName(kPanelShow):getPositionY() + obj:egGetWidgetByName(kBtnInvite):getPositionY()
         local popWidget = PopTxt.new(TxtList.unLockMenuInfo[menuDef.invite],kOffsetX,offsetY)
        obj:egAddChild(popWidget:egNode())
        obj:egChangeBtnImg(kBtnInvite,ImageList.btn_invite_n,ImageList.btn_invite_s,"",UI_TEX_TYPE_PLIST)
        obj:loadInviteFlag()
    end
end
--�ж��Ƿ��п���ļ��Ӣ��,�п���ļӢ��ʱ,��ʾ��ʾ��Ϣ
function __menulayer.loadInviteFlag(obj)
    local imgWidget = obj:egGetWidgetByName(kImgNewInvite)
    imgWidget:setVisible(false)
	for heroid,msgnum in pairs(account_data.heroInfoList) do
		local s_cfg = hero_data.getConfig(heroid)
        if msgnum >= s_cfg.infoCnt and not account_data.heroList[heroid] then
			 obj._noticeInvite = true
			 imgWidget:setVisible(true)
			 obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
			 return
		end
    end
end

--����ѵ����ť
function __menulayer.loadGrowMenu(obj)
	obj:egHideWidget(kImgNewGrow)
    if obj._d_data.digLv < unLockMenu[menuDef.training] then
        obj._growUnlocked = false
        obj:egChangeBtnImg(kBtnGrow,ImageList.btn_grow_d,ImageList.btn_grow_d,"",UI_TEX_TYPE_PLIST)
    else
        obj._growUnlocked = true
        obj:egChangeBtnImg(kBtnGrow,ImageList.btn_grow_n,ImageList.btn_grow_s,"",UI_TEX_TYPE_PLIST)
    end
end
--����ѵ����ť״̬
function __menulayer.updateGrowMenu(obj)
    if not obj._growUnlocked and obj._d_data.digLv >= unLockMenu[menuDef.training] then
        obj._growUnlocked = true
		local offsetY = obj:egGetWidgetByName(kPanelShow):getPositionY() + obj:egGetWidgetByName(kBtnGrow):getPositionY()
        local popWidget = PopTxt.new(TxtList.unLockMenuInfo[menuDef.training],kOffsetX,offsetY)
        obj:egAddChild(popWidget:egNode())
        obj:egChangeBtnImg(kBtnGrow,ImageList.btn_grow_n,ImageList.btn_grow_s,"",UI_TEX_TYPE_PLIST)
    end
end
--���ط������ť
function __menulayer.loadDefMenu(obj)
	obj:egHideWidget(kImgNewDef)
    if obj._d_data.digLv < numDef.pveGuardQuestRequiredLevel then
        obj._defUnlocked = false
        obj:egChangeBtnImg(kBtnDef,ImageList.btn_def_d,ImageList.btn_def_d,"",UI_TEX_TYPE_PLIST)
    else
        obj._defUnlocked = true
        obj:egChangeBtnImg(kBtnDef,ImageList.btn_def_n,ImageList.btn_def_s,"",UI_TEX_TYPE_PLIST)
		obj:bindDefTimer()
    end
end
--���·������ť״̬
function __menulayer.updateDefMenu(obj)
    if not obj._defUnlocked  and obj._d_data.digLv >= numDef.pveGuardQuestRequiredLevel then
        obj._defUnlocked = true
		local offsetY = obj:egGetWidgetByName(kPanelShow):getPositionY() + obj:egGetWidgetByName(kBtnDef):getPositionY()
        local popWidget = PopTxt.new(TxtList.unLockMenuInfo[menuDef.def],kOffsetX,offsetY)
        obj:egAddChild(popWidget:egNode())
        obj:egChangeBtnImg(kBtnDef,ImageList.btn_def_n,ImageList.btn_def_s,"",UI_TEX_TYPE_PLIST)
		obj:bindDefTimer()
    end
end
--�ж��Ƿ���Ҫ��ʾ����������ʾ
function __menulayer.bindDefTimer(obj)
	if not account_data.pveGuardQuest then return end
	local function update()
		if #account_data.pveGuardQuest.qid > 0 then
			obj:egShowWidget(kImgNewDef)
			obj._noticeDef = true
			obj:scaleWidget(obj:egGetWidgetByName(kImgNewDef),kScale1,kScale2,kInterval1)
			obj:egUnbindWidgetUpdate(kBtnDef)
		end
	end
	obj:egBindWidgetUpdate(kBtnDef,update)
end
--�ж��Ƿ�������ɵ�δ�콱������
function __menulayer.hasFinishedTask(obj)
	if account_data.taskList then
		for tid, taskctx in pairs(account_data.taskList) do 
			if taskctx[2] == 1 then
				return true
			end
		end
	end
	return false
end

--�ھ���־������ʾ
function __menulayer.loadTaskMenuTimer(obj)
	local showflag = false
	local imgWidget = obj:egGetWidgetByName(kImgNewFinished)
	imgWidget:setVisible(false)
	
	local function update()
		local hasfinished = obj:hasFinishedTask()
		if hasfinished~=showflag then
			showflag = hasfinished
			imgWidget:setVisible(showflag)
			if showflag then
				obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
			else
				imgWidget:stopAllActions()
			end
		end
	end
	obj:egBindWidgetUpdate(kBtnTask,update)
end

--��չ��ť����
function __menulayer.bindExtensionTimer(obj)
    local oldstate = false
    local function update()
        if obj._noticePost or obj._noticeInvite or obj._noticeDef then
            obj:egShowWidget(kImgNotices)
            local changed = true
            if oldstate ~= changed then
                oldstate = true
                local imgWidget = obj:egGetWidgetByName(kImgNotices)
                obj:scaleWidget(imgWidget,kScale1,kScale2,kInterval1)
            end    
        else
            oldstate = false
            obj:egHideWidget(kImgNotices)
        end
    end
    obj:egBindWidgetUpdate(kBtnExten,update)
end

--����
function __menulayer.bindPostListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        local imgWidget = obj:egGetWidgetByName(kImgNewPost)
        imgWidget:setVisible(false)
        imgWidget:stopAllActions()
        local function callbackfunc()
            sender:setTouchEnabled(true)
        end
        if obj._clickingCallback then obj._clickingCallback() end
        AccountHelper:lock(kStatePrompt)
        showPost(callbackfunc)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnPost,nil,nil,touchEnded,touchCanceled)
end

--��ļ
function __menulayer.bindInviteListener(obj)

    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        if obj._d_data.digLv < unLockMenu[menuDef.invite] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.invite])
			local offsetY = obj:egGetWidgetByName(kBtnInvite):getPositionY() + sender:getPositionY()
            local popWidget = PopTxt.new(text,kOffsetX,offsetY)
            obj:egAddChild(popWidget:egNode())
            sender:setTouchEnabled(true)
        else
            local scene = PubScene.new()
            scene:egReplace()
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnInvite,nil,nil,touchEnded,touchCanceled)
end

--�Ӷ�
function __menulayer.bindFightListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
       SoundHelper.playEffect(SoundList.clickMenu)
       if obj._clickingCallback then obj._clickingCallback() end
       if obj._d_data.digLv < unLockMenu[menuDef.pvp] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.pvp])
            local popWidget = PopTxt.new(text,-kOffsetX,0)
            sender:addChild(popWidget:egNode())
            sender:setTouchEnabled(true)
       else
           if obj._d_data.actPt<numDef.pvpBattleAP then
               local text = string.format("%s %d",TxtList.needActPt,numDef.pvpBattleAP)
               local popWidget = PopTxt.new(text,-kOffsetX,0)
               sender:addChild(popWidget:egNode())
               sender:setTouchEnabled(true)
           else
               local function callbackfunc()
                    sender:setTouchEnabled(true)
               end
               AccountHelper:lock(kStatePrompt)
               if obj._d_data.pvpShellInterval > 0 then
                    showPvpCDInfo(callbackfunc)
                else
                    showPreparePvp(callbackfunc)
                end
           end   
       end    
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnFight,nil,nil,touchEnded,touchCanceled)
end

--�ھ��̻�
function __menulayer.bindCofcListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
       SoundHelper.playEffect(SoundList.clickMenu)
	   local scene = worldmapScene.new()
       --if obj._clickingCallback then obj._clickingCallback() end
	   --local scene = MissionScene.new(licenceLevelup[obj._d_data.digLv].areaID)
	   scene:egReplace()
    end

	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnCofc,nil,nil,touchEnded,touchCanceled)
end

--ѵ��
function __menulayer.bindGrowListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        if obj._d_data.digLv < unLockMenu[menuDef.training] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.training])
			local offsetY = obj:egGetWidgetByName(kPanelShow):getPositionY() + sender:getPositionY()
            local popWidget = PopTxt.new(text,kOffsetX,offsetY)
            obj:egAddChild(popWidget:egNode())
            sender:setTouchEnabled(true)
       else
            local scene = GrowScene.new()
            scene:egReplace()
        end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnGrow,nil,nil,touchEnded,touchCanceled)	
end
--�����
function __menulayer.bindDefListener(obj)
	 local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
        end
		if obj._d_data.digLv < numDef.pveGuardQuestRequiredLevel then
            local text = string.format("%s LV%d",TxtList.needLicence,numDef.pveGuardQuestRequiredLevel)
			local offsetY = obj:egGetWidgetByName(kPanelShow):getPositionY() + sender:getPositionY()
            local popWidget = PopTxt.new(text,kOffsetX,offsetY)
            obj:egAddChild(popWidget:egNode())
            sender:setTouchEnabled(true)
		else
			AccountHelper:lock(kStatePrompt)
			showDef(callbackfunc)
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnDef,nil,nil,touchEnded,touchCanceled)
end
--PVP��λ
function __menulayer.bindRankListener(obj)
    
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
        end
        AccountHelper:lock(kStatePrompt)
        showEloRank(callbackfunc)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnRank,nil,nil,touchEnded,touchCanceled)
end
--����
function __menulayer.bindTaskListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
        end
        showDigJournal(callbackfunc)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnTask,nil,nil,touchEnded,touchCanceled)
end
--��չ��ť
function __menulayer.bindBtnExListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        local function callback()
            sender:setTouchEnabled(true)
            obj:egHideWidget(kBtnExten)
            obj:egShowWidget(kBtnPullDown)
        end
        if obj._btnExClickingBack then
            obj._btnExClickingBack(false)
        end
        obj:egUnbindWidgetUpdate(kBtnExten)
        obj:egHideWidget(kImgNotices)
            
        local btns = obj:egGetWidgetByName(kPanelBtns)
           
        obj:egShowWidget(kPanelShow)
        local move = CCMoveTo:create(0.2,kPointBtns)
        local callbackfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(move,callbackfunc)
        btns:runAction(sequence)
    end

	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnExten,nil,nil,touchEnded,touchCanceled)
end
--������Ϣ��ʾ��ť����¼�
function __menulayer.bindSelfInfoListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.clickMenu)
        if obj._clickingCallback then obj._clickingCallback() end
        local function callbackfunc()
            sender:setTouchEnabled(true)
        end
        showPubUserInfo(account_data.guid,callbackfunc)
		SoundHelper.playEffect(SoundList.clickMenu)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnSelfInfo,nil,nil,touchEnded,touchCanceled)
end
--����ť
function __menulayer.bindBtnPullListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		 local function callback()
            if obj._btnExClickingBack then
            obj._btnExClickingBack(true)
            end
            sender:setTouchEnabled(true)
            obj:egHideWidget(kPanelShow)
            obj:egHideWidget(kBtnPullDown)
            obj:egShowWidget(kBtnExten)
        end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
        obj:bindExtensionTimer()
        local btns = obj:egGetWidgetByName(kPanelBtns)
        local move = CCMoveTo:create(0.2,kHidePoint)
        local callbackfunc = CCCallFunc:create(callback)
        local sequence = CCSequence:createWithTwoActions(move,callbackfunc)
        btns:runAction(sequence)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnPullDown,nil,nil,touchEnded,touchCanceled)
end
function __menulayer.bindExFightListener(obj)
	local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
        sender:setTouchEnabled(false)
		SoundHelper.playEffect(SoundList.clickMenu)
		 if obj._d_data.digLv < unLockMenu[menuDef.expedition] then
            local text = string.format("%s LV%d",TxtList.needLicence,unLockMenu[menuDef.expedition])
            local popWidget = PopTxt.new(text,-kOffsetX,0)
            sender:addChild(popWidget:egNode())
            sender:setTouchEnabled(true)
		else
		    --[[���Դ���
			if not account_data.expedition then
		    account_data.exMission = {st=os.time(),stages={[101]=1},creatureList = {[208]=3,[211]=2,[264]=9,[310]=3,[162]=5,[269]=1,[124]=2,[204]=1,[66]=8,[225]=2,[63]=4,[145]=1,},}
		    account_data.expedition={[1]=25600,[2]=25600,[20]=25600,[5]=25600,[6]=25600,[8]=25600,[9]=25600,[10]=25600,[19]=25600,[14]=25600,[15]=25600,[18]=25600}
			end
			--]]
			if account_data.expedition then --�ѿ���Զ��������´�Զ�����������
				local scene =ExMissionScene.new()
				scene:egReplace()
			else --��û�п���Զ��������´�Զ���ӱ༭����
				local scene =ExpeditionTeamScene.new()
				scene:egReplace()
			end
		end
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			 touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnExFight,nil,nil,touchEnded,touchCanceled)
end
function __menulayer.onClicking(obj,callback)
    obj._clickingCallback = callback
end
function __menulayer.btnExOnClicking(obj,callback)
    obj._btnExClickingBack = callback
end
MenuLayer={}
function MenuLayer.new(d_data)
    local obj= TouchWidget.new(JsonList.menuLayer)
   --local obj ={}
   -- CocosWidget.install(obj,JsonList.menuLayer)
    table_aux.unpackTo(__menulayer, obj)
    obj:init(d_data)
    obj:bindPostListener()
    obj:bindInviteListener()
    obj:bindFightListener()
    obj:bindCofcListener()
    obj:bindGrowListener()
	obj:bindDefListener()
    obj:bindRankListener()
    obj:bindBtnExListener()
    obj:bindBtnPullListener()
    obj:bindTaskListener()
	obj:bindExFightListener()
	obj:bindSelfInfoListener()
    return obj
end
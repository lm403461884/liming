local kLblRank = "lbl_rank"
local kLblName = "lbl_user"
local kLblJewel = "lbl_jewel"
local kLblElo = "lbl_elo"
local __rankitem = {}
function __rankitem.init(obj,idx,kind)
    local itemdata = nil
    if kind == 1 then
         itemdata = account_data.elo_rank[idx]
    elseif kind == 2 then    
         itemdata = account_data.honor_rank[idx]
    end
    obj:egSetLabelStr(kLblRank,string.format("NO.%d",idx))
    obj:egSetLabelStr(kLblName,itemdata.name)
    obj:egSetLabelStr(kLblJewel,itemdata.jewel)
    obj:egSetLabelStr(kLblElo,itemdata.elo)
end

RankItem={}
function RankItem.new(idx,kind)
    local obj = {}
    CocosWidget.install(obj,JsonList.rankItem)
    table_aux.unpackTo(__rankitem, obj)
    obj:init(idx,kind)
    return obj
end
MissionScene = {}
function MissionScene.new(areaid)--{{{
    SoundHelper.playBGM(SoundList.rish_bgm)
	local obj = {}
    Scene.install(obj)
    --table_aux.unpackTo(__missionscene, obj)
	obj._baseWidget = MissionLayer.new(areaid)
	obj._baseWidget:egAttachTo(obj)
	showEmDialog(obj,GuideScene.def.kMissionScene) --����������
	-------------
	obj._recvlayer = RecvLayer.new()
    obj._recvlayer:egAttachTo(obj)
	return obj
end

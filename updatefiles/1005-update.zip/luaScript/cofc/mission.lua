local kImagStar = {"star_1","star_2","star_3"}
local kBtnMission = "btn_misssion"
local kImgNew = "img_new"
local kLblCD = "lbl_cd_num"
local kLblCD_CH = "lbl_cd_ch"
local kLblCH = "lbl_ch"
local kLblCH_s = "lbl_ch_s"
local __mission = {}
function __mission.init(obj,areaid,stageid,groupIdx,updateDt)
    obj._areaid = areaid
    obj._stageid = stageid
	obj._updateDt = updateDt
    obj._groupIdx = groupIdx --��������û��groupIdx
	--����������ʾ����
	if obj._groupIdx then
		obj:egHideWidget(kImagStar[1])
		obj:egHideWidget(kImagStar[2])
		obj:egHideWidget(kImagStar[3])
	end
	obj:egSetWidgetEnabled(kBtnMission,false)
	obj:egHideWidget(kImgNew)
	obj:egHideWidget(kLblCD)
	obj:egHideWidget(kLblCD_CH)
	obj:egHideWidget(kLblCH)
	obj:egHideWidget(kLblCH_s)
	obj._unlocked = false
	obj:loadMissionData()
	obj:bindDMTimer()
end
function __mission.loadMissionData(obj)
	if not obj._stageid then return end
	obj._s_data = pveQuery.queryStage(obj._areaid,obj._stageid)
	obj:egChangeBtnImg(kBtnMission,obj._s_data.tagPic[1],obj._s_data.tagPic[2],obj._s_data.tagPic[3],UI_TEX_TYPE_PLIST)
	local stageitem = account_data.unlockedPVE[obj._areaid][obj._stageid]
	if stageitem then
		obj._unlocked = true
		for idx=1,stageitem.stars do
			obj:egShowWidget(kImagStar[idx])
			obj:egChangeImg(kImagStar[idx],ImageList.star,UI_TEX_TYPE_PLIST)
		end
		obj:egSetWidgetEnabled(kBtnMission,true)
		if stageitem.first or obj._groupIdx then
				obj:egShowWidget(kImgNew)
				local scaleto1 = CCScaleTo:create(0.5,0.9)
				local moveby1 = CCMoveBy:create(0.5,ccp(0,-5))
				local spawn1 = CCSpawn:createWithTwoActions(scaleto1,moveby1)
				local scaleto2 = CCScaleTo:create(0.5,1)
				local moveby2 = CCMoveBy:create(0.5,ccp(0,5))
				local spawn2 = CCSpawn:createWithTwoActions(scaleto2,moveby2)
				local sequence = CCSequence:createWithTwoActions(spawn1,spawn2)
				local repeatever = CCRepeatForever:create(sequence)
				local widget = obj:egGetWidgetByName(kImgNew)
				widget:runAction(repeatever)
		end
	end
end
function __mission.bindDMTimer(obj)
	if obj._stageid then return end
	obj:egShowWidget(kLblCD)
	obj:egShowWidget(kLblCD_CH)
	obj:egShowWidget(kLblCH)
	obj:egShowWidget(kLblCH_s)
	local refTime = missionData.day_mission[obj._areaid][obj._groupIdx].ref_time
	local leftTime = math.ceil(refTime -(os.time() - obj._updateDt))
	local disNum,disUnit = Funs.formmatTimeCh2(leftTime)
	obj:egSetBMLabelStr(kLblCD,disNum)
	obj:egSetBMLabelStr(kLblCD_CH,disUnit)
	local function callback()
		leftTime = math.ceil(refTime -(os.time() - obj._updateDt))
		
		if leftTime >0 then
			local disNum1,disUnit1 = Funs.formmatTimeCh2(leftTime)
			if disNum~=disNum1 then
			    disNum = disNum1
			    obj:egSetBMLabelStr(kLblCD,disNum)
			end
			if disUnit~=disUnit1 then
			    disUnit = disUnit1
			    obj:egSetBMLabelStr(kLblCD_CH,disUnit)
			end
		else
			obj._stageid = MissionHelper.getStageId(obj._areaid,obj._groupIdx)
			obj:egHideWidget(kLblCD)
            obj:egHideWidget(kLblCD_CH)
            obj:egHideWidget(kLblCH)
            obj:egHideWidget(kLblCH_s)
			obj:egUnbindWidgetUpdate(kLblCD)
			obj:loadMissionData()
		end
	end
	obj:egBindWidgetUpdate(kLblCD,callback)
end
--�豸������ʾ����,��������л���ʾ����ʱ����
function __mission.showMission(obj,show)
    obj:egNode():setVisible(show)
    if obj._unlocked then
        obj:egSetWidgetTouchEnabled(kBtnMission,show)
    end
    obj:egSetWidgetEnabled(kBtnMission,obj._unlocked)
end
--����ť����¼�
function __mission.doClickMission(obj,sender)
        sender:setTouchEnabled(false)
        SoundHelper.playEffect(SoundList.click_paper_open)
        local function callback()
            sender:setTouchEnabled(true)
        end
        MissionHelper.groupIdx = obj._groupIdx --��������û��������ID
		MissionHelper.areaId = obj._areaid --������������
        showAtkMission(obj._areaid,obj._stageid,callback)
end

function __mission.bindClickListener(obj)
    local function touchEnded(sender)
		if not AccountHelper:isLocked(kStateGuide0) then AccountHelper:unlock(kStateGuide) end
		obj:doClickMission(sender)
    end
	local function touchCanceled(sender)
		if AccountHelper:isLocked(kStateGuide) then --����״̬
			
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnMission,nil,nil,touchEnded,touchCanceled)
end
Mission={}
function Mission.new(areaid,stageid,groupIdx,updateDt)
    local obj = {}
    CocosWidget.install(obj,JsonList.pveMission)
    table_aux.unpackTo(__mission, obj)
    obj:init(areaid,stageid,groupIdx,updateDt)
    obj:bindClickListener()
    return obj
end
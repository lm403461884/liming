local kLblNum = "lbl_num"
local kImgItem = "img_item"
local __toolhead = {}
function __toolhead.init(obj,itemid,d_data)
    local s_cfg = itemQuery.query(itemid)
    local num = d_data.bag[itemid] or 0
    obj:egChangeImg(kImgItem,s_cfg.icon,UI_TEX_TYPE_PLIST)
    obj:egSetBMLabelStr(kLblNum,num)
end
ToolHead = {}
function ToolHead.new(itemid,d_data)
     local obj = {}
    CocosWidget.install(obj,JsonList.toolHead)
    table_aux.unpackTo(__toolhead, obj)
    obj:init(itemid,d_data)
    return obj
end
HOEntryHelper={}
HOEntryHelper._fileList = {
"luaScript/0comm/assist/keymanager.lua"
,"luaScript/0comm/assist/accounthelper.lua"
,"luaScript/0comm/assist/baseprop.lua"
,"luaScript/0comm/assist/funs.lua"
,"luaScript/0comm/assist/graphic.lua"
,"luaScript/0comm/assist/guidehelper.lua"
,"luaScript/0comm/assist/innerprop.lua"
,"luaScript/0comm/assist/pic.lua"
,"luaScript/0comm/assist/acctManager.lua"
,"luaScript/0comm/assist/scriptHelper.lua"
,"luaScript/0comm/assist/tableAux.lua"
,"luaScript/0comm/assist/soundhelper.lua"
,"luaScript/0comm/assist/datatransform.lua"
,"luaScript/0comm/assist/notifyhelper.lua"
,"luaScript/0comm/assist/sdkhelper.lua"
,"luaScript/0comm/assist/pushmsghelper.lua"
,"luaScript/0comm/assist/tdhelper.lua"
,"luaScript/0comm/assist/tdeventconst.lua"
,"luaScript/0comm/assist/wordfilter.lua"
,"luaScript/0comm/assist/filterworddb.lua"
,"luaScript/0comm/assist/scenemanager.lua"
,'luaScript/0comm/assist/usermanager.lua'
,'luaScript/0comm/assist/encryptTable.lua'
,'luaScript/0comm/assist/securityManager.lua'
,'luaScript/0comm/assist/speedManager.lua'

,"luaScript/0comm/config/jsonconfig.lua"
,"luaScript/0comm/config/sdkconfig.lua"
,"luaScript/0comm/config/imgconfig.lua"
,"luaScript/0comm/config/imgCfg.lua"
,"luaScript/0comm/config/layerconfig.lua"
,"luaScript/0comm/config/soundconfig.lua"
,"luaScript/0comm/config/varconfig.lua"
,"luaScript/0comm/config/eventconst.lua"
,"luaScript/0comm/config/animaCfg.lua"
,"luaScript/0comm/config/txtconfig_ch.lua"


,"luaScript/0comm/cocosCtrl/cocoswidget.lua"
,"luaScript/0comm/cocosCtrl/layer.lua"
,"luaScript/0comm/cocosCtrl/layercolor.lua"
,"luaScript/0comm/cocosCtrl/node.lua"
,"luaScript/0comm/cocosCtrl/scene.lua"
,"luaScript/0comm/cocosCtrl/sprite.lua"
,"luaScript/0comm/cocosCtrl/touchdelegate.lua"
,"luaScript/0comm/cocosCtrl/wnode.lua"
,"luaScript/0comm/cocosCtrl/touchwidget.lua"
,"luaScript/0comm/cocosCtrl/luazoomview.lua"

,"luaScript/0comm/socket/recvmsg.lua"
,"luaScript/0comm/socket/sendmsg.lua"
,"luaScript/0comm/socket/netconfig.lua"
,"luaScript/0comm/socket/sshelper.lua"
,"luaScript/0comm/socket/sockethelper.lua"


,"luaScript/login/logoscene.lua"
,"luaScript/login/loadscene.lua"
,"luaScript/login/storylayer.lua"
,"luaScript/login/storyscene.lua"
,"luaScript/login/battlewaitlayer.lua"
,"luaScript/login/quitlayer.lua"
,"luaScript/login/nicknamelayer.lua"
,"luaScript/login/comiclayer.lua"
,"luaScript/login/comicscene.lua"
,"luaScript/login/switchlayer.lua"
,"luaScript/login/switchitem.lua"
,"luaScript/login/pubmsgbar.lua"
,"luaScript/login/pubmsgsheet.lua"
,"luaScript/login/letterlayer.lua"
,"luaScript/login/floatnode.lua"
,"luaScript/login/messagebox.lua"
,"luaScript/login/confirmbox.lua"
,"luaScript/login/flatmsgitem.lua"
,"luaScript/db/dbutil.lua"
,"luaScript/db/dbhelper.lua"
,"luaScript/db/dbverlist.lua"
,"luaScript/HOLoadHelper.lua"
}

HOEntryHelper._language = k_LANGUAGE_CH
function HOEntryHelper.loadScriptByName(filename)
	package.loaded[filename] = nil
	require(filename)
end

function HOEntryHelper.init()
	for key,filename in ipairs(HOEntryHelper._fileList) do
		HOEntryHelper.loadScriptByName(filename)
	end
	HOLoadHelper.allLoaded = false
	--设置密钥
	KeyManager.init()
	TDHelper.init()
	DBHelper.initDB()
end
--常变脚本部分，在进入游戏主界面前加载
function HOEntryHelper.loadCMScript()
	--cmVersion 常变脚本版本号，没有说明还没有加载这部分脚本
	if not cmVersion then 
		if DBHelper.hasNewCMScript() then
			DBHelper.loadCMScript()
		else
			for key,filename in ipairs(HOLoadHelper.cmScriptList) do
				HOEntryHelper.loadScriptByName(filename)
			end
		end
	end
end





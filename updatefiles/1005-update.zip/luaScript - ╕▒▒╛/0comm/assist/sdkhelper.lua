--region sdkhelper.lua
--Author : Yanlee
--Date   : 2014/12/1
--sdk 鎺ュ叆杈呭姪
SDKHelper={}
function SDKHelper:login()
	if not self._sdkUID then
		PlugInHelper:showLogin()
	else
		PlugInHelper:triggerEvent(CLTEvent.LoginSucceed,"")
	end
end
function SDKHelper:saveUID()
	if not self._sdkUID then
		local uid = PlugInHelper:getUid()
		local lastuid = DBHelper.getLastLogPID()
		if uid == "nouid" then
			if lastuid == "" or lastuid == nil then
				local devmac = HOAux:getDevMacAddr()
				uid = string.gsub(devmac,"%p","")
				if string.len(uid) < 12 then
					uid = math.random(4096)..os.time()
				end
			else
				uid = lastuid
			end
		end
		DBHelper.setLastLogPID(uid)
		self._sdkUID = uid
	end
	return self._sdkUID
end
function SDKHelper:clearUID()
	self._sdkUID = nil
end
--获取玩家帐号信息，接入SDK后可能调整
function SDKHelper:getAccountInfo()
	if AcctManager:get() then
		local tb = {}
		tb.acctId = AcctManager:getParam("guid")
		tb.acctLv =  AcctManager:getParam("digLv")
		local serverInfo = SSHelper:getLastLogServer()
		if serverInfo then
			tb.gameServer = serverInfo.name
		end
		tb.acctType = SDKConfig.getAcctType()
		return tb
	end
	return nil
end
--瀹㈡埛绔嚜鐢↖D,骞冲彴鏍囪瘑 + "_" + 骞冲彴UID
function SDKHelper:getHOUID()
	local uid = "p"..SDKConfig.getFlag().."_"..self._sdkUID
	return uid
end
function SDKHelper:loginWithSid(sid)
	self._sid = sid
	PlugInHelper:setServerId(sid)
end
function SDKHelper:getSID()
	return self._sid
end
function SDKHelper:initPurchase()
	if self._sid then
		PlugInHelper:initPurchase(self._sid)
		return true
	else
		return false
	end
end
function SDKHelper:purchaseItem(itemid,amount)
    local lastServer = SSHelper:getLastLogServer()
    local info ={}
    info.serverId = lastServer.sid
    info.roleId = AcctManager:getParam("guid")
    info.roleName =  AcctManager:getParam("nickName")
    info.grade =  AcctManager:getParam("digLv")
    if amount then info.amount = amount else info.amount = 0 end
    info.itemid = itemid
    payInfo = json.encode(info)
	PlugInHelper:purchaseItem(payInfo)
end
function SDKHelper:submitServerInfo()

    local lastServer = SSHelper:getLastLogServer()
    local info = {}
    info.zoneName = lastServer.name
    info.roleId = AcctManager:getParam("guid")
    info.roleName = AcctManager:getParam("nickName")
    local serverInfo = json.encode(info)
    PlugInHelper:submitServerInfo(serverInfo)
end
function SDKHelper:submitLoginGameRole()
    local lastServer = SSHelper:getLastLogServer()
    local info = {}
    info.roleId = AcctManager:getParam("guid")
    info.roleName = AcctManager:getParam("nickName")
    info.roleLevel = AcctManager:getParam("digLv")
    info.zoneId = lastServer.sid
    info.zoneName = lastServer.name
    local roleInfo = json.encode(info)
    PlugInHelper:submitLoginGameRole(roleInfo)
end
function SDKHelper:uploadScore(scores,ids)
    local info = {}
    info.score=scores
    info.topnid=ids
    local scoreInfo = json.encode(info)
    PlugInHelper:uploadScore(scoreInfo)
end
function SDKHelper:exitSDK()
    PlugInHelper:exitSDK()
end
function SDKHelper:logOut()
    PlugInHelper:logOut()
end
function SDKHelper:destroy()
	--PlugInHelper:destory()
end



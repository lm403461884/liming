SecurityManager = {}
function SecurityManager:encrypt(target)
	local key = math.random(1,10)
	local function encryptFunc(k,v)
		return (string.byte(k) + string.byte(k,-1))%(100+string.len(k)) + v+key
	end
	local function callbackFunc(k,v)
		if not AcctManager:hasData() then return end
		AcctManager:clear()
		SocketHelper.clearDSConn()
		SocketHelper.clearGSConn()
		SendQueue:clearQueue()
		--MessageBox.show("invalid data key:"..k..",val:"..v,LogoScene)
		MessageBox.show("Warning: client data error !!",LogoScene)
	end
	target = encryptTable.create(target,encryptFunc,callbackFunc)
	return target
end
function SecurityManager:encryptGameData(needYeild)
	numDef = self:encrypt(numDef)
	if needYeild then coroutine.yield() end
	bullet_data = self:encrypt(bullet_data)
	if needYeild then coroutine.yield() end
	hero_data = self:encrypt(hero_data)
	if needYeild then coroutine.yield() end
	equipNum = self:encrypt(equipNum)
	if needYeild then coroutine.yield() end
	licenceLevelup =  self:encrypt(licenceLevelup)
	if needYeild then coroutine.yield() end
	mile_data = self:encrypt(mile_data)
	if needYeild then coroutine.yield() end
	monster_data = self:encrypt(monster_data)
end
--====================================================================================
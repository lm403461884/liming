

local plist = ".plist"
local spritePath = "GUIRes/Images/sprite/"
local animaPath = "GUIRes/Images/anima/"
local picPath = "GUIRes/Images/pic/"
local bgPath = "GUIRes/Images/bg/"
local _animaRefCounter = {}
local _animaInfoCfg = {}
local _soundRefCounter = {}
------------------------------------------------------------------
--! @module graphicLoader
graphicLoader = {}
function graphicLoader.clearAllRes()
	_animaRefCounter = {}
	 _soundRefCounter = {}
	 _animaInfoCfg = {}
	CCAnimationCache:purgeSharedAnimationCache()
	CCSpriteFrameCache:purgeSharedSpriteFrameCache()
	CCTextureCache:purgeSharedTextureCache()
end
function graphicLoader.getTextureFrameName(imgName)
	assert(imgName,"can not load texture without imgName")
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	imgName =  string.gsub(imgName,"^.+/","")
	imgName =   string.gsub(imgName,"%..+","")
	local frameName = imgName..".png"
	local frame = frameCache:spriteFrameByName(frameName)
	if not frame then
		local folderIdx = ImageToPvrCcz[imgName]
		if folderIdx then
			frameCache:addSpriteFramesWithFile(picPath..PvrCczImgList[folderIdx]..plist)
		else
			frameCache:addSpriteFramesWithFile(bgPath..imgName..plist)
		end
	end
	return frameName
end
function graphicLoader.loadAllEpsAnima(needyield)
	for key,val in pairs(actList) do
		if string.find(key,"eps_") then
			graphicLoader.getAnimation(key)
			if needyield then coroutine.yield() end
		end
	end
end
--��ȡӢ�۶�����Դ����
function graphicLoader.getHeroGraphic(heroid,lv)
	if not lv then lv = 1 end
	local creature_cfg = assert(hero_data.getConfig(heroid),"can not find hero config with id "..heroid)
	local creature_data = assert(hero_data.get(heroid,lv),"can not find hero data with id "..heroid.." lv "..lv)
	local graphicLv = assert(creature_data.graphLV,"can not find graphic Lv config")
	local graphicName = assert(creature_cfg.graphList[graphicLv],"can not find graphic name width graphLV "..graphicLv)
	return graphicName
end
--��ȡ���ﶯ����Դ����
function graphicLoader.getMonsterGraphic(monsterid,lv)
	if not lv then lv = 1 end
	local creature_cfg = assert(monster_data.getConfig(monsterid),"can not find monster config with id "..monsterid)
	local creature_data = assert(monster_data.get(monsterid,lv),"can not find monster data with id "..monsterid.." lv "..lv)
	local graphicLv = assert(creature_data.graphLV,"can not find graphic Lv config")
	local graphicName = assert(creature_cfg.graphList[graphicLv],"can not find graphic name width graphLV "..graphicLv)
	return graphicName
end
--����Ӣ����Դ
function graphicLoader.loadHeroFrame(heroid,lv)
	local graphicName = graphicLoader.getHeroGraphic(heroid,lv)
	local filename = spritePath..graphicName..plist
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(filename)
end
--���ع�����Դ
function graphicLoader.loadMonsterFrame(monsterid,lv)
	local graphicName = graphicLoader.getHeroGraphic(monsterid,lv)
	local filename = spritePath..graphicName..plist
	CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile(filename)
end
--����Ӣ�۶���
function graphicLoader.loadHeroAnima(heroid,lv,withEffect)
	local graphicName = graphicLoader.getHeroGraphic(heroid,lv)
	graphicLoader.loadUserDefineAnima(graphicName)
	if withEffect then
		if SoundHelper.isEffectOn() then addUnitSoundEffect(graphicName) _soundRefCounter[graphicName] = 1 end
		for key,effectName in ipairs(animaEffectUnit[graphicName]) do
			graphicLoader.loadUserDefineAnima(effectName)
		end
	end
end
--���ع��ﶯ��
function graphicLoader.loadMonsterAnima(monsterid,lv,withEffect)
	local graphicName = graphicLoader.getMonsterGraphic(monsterid,lv)
	graphicLoader.loadUserDefineAnima(graphicName)
	if withEffect then
		if SoundHelper.isEffectOn() then addUnitSoundEffect(graphicName) _soundRefCounter[graphicName] = 1 end
		for key,effectName in ipairs(animaEffectUnit[graphicName]) do
			graphicLoader.loadUserDefineAnima(effectName)
		end
	end
end
function graphicLoader.loadResCarTexture(frameName)
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	if not frameCache:spriteFrameByName(frameName) then
		frameCache:addSpriteFramesWithFile(spritePath.."grab_action"..plist)
		frameCache:addSpriteFramesWithFile(spritePath.."grab_stand"..plist)
	end
end
function graphicLoader.loadBoxTexture(boxname)
	local frameName = string.format("comm_box_%s",boxname)
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	if not frameCache:spriteFrameByName(frameName) then
		local textureName = string.format("box_%s_open",boxname)
		frameCache:addSpriteFramesWithFile(spritePath..textureName..plist)
	end
end
--�����Զ��嶯��
function graphicLoader.loadUserDefineAnima(graphicName)
	local animaCache = CCAnimationCache:sharedAnimationCache()
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	local filename = spritePath..graphicName..plist
	frameCache:addSpriteFramesWithFile(filename)
	local anima_cfg =assert( animaBattleUnit[graphicName],"can not find anima with graphicName "..graphicName)
	
	for actionID,action_cfg in pairs(anima_cfg) do
		for dir=1,4 do
			local animaName = string.format('%s_%02d%02d', graphicName, actionID, dir)
			if not animaCache:animationByName(animaName) then
				local anima = CCAnimation:create()
				anima:setDelayPerUnit(action_cfg.delay)
				for idx=1, action_cfg.frames do
					local frameName = string.format('%s_%02d%02d%02d.png', graphicName, actionID, dir, idx)
					local frame = assert(frameCache:spriteFrameByName(frameName),'can not find frame with name: ' .. frameName)
					anima:addSpriteFrame(frame)
				end
				animaCache:addAnimation(anima, animaName)
			end
			_animaInfoCfg[animaName] = {delay = action_cfg.delay,durationS = action_cfg.frames*action_cfg.delay}
			_animaRefCounter[animaName] = graphicName
		end
	end
end
function graphicLoader.unloadUserDefineAnima()
	local animaCache = CCAnimationCache:sharedAnimationCache()
	for key,val in pairs(_animaRefCounter) do
		animaCache:removeAnimationByName(key)
		_animaRefCounter[key] = nil
	end
	for key,val in pairs(_soundRefCounter) do
		removeUnitSoundEffect(key)
		_soundRefCounter[key] = nil
	end
	CCSpriteFrameCache:sharedSpriteFrameCache():removeUnusedSpriteFrames()
	CCTextureCache:sharedTextureCache():removeUnusedTextures()
end
--���ݶ������ƻ�ȡ����
function graphicLoader.getAnimation(animaName)--{{{
	local animaCache = CCAnimationCache:sharedAnimationCache()
	if actList[animaName] then
		local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
		local anima = animaCache:animationByName(animaName)
		if not anima then
			frameCache:addSpriteFramesWithFile(spritePath..animaName..plist)
			animaCache:addAnimationsWithFile(animaPath..animaName..plist)
			anima = animaCache:animationByName(animaName)
			_animaInfoCfg[animaName] = {delay = anima:getDelayPerUnit(),durationS = anima:getDuration()}
		end
		_animaRefCounter[animaName] = animaName
		return anima
	else
		local anima =  animaCache:animationByName(animaName)
		assert(anima,"Can not find animation with name " .. animaName)
		_animaRefCounter[animaName] = animaName
		return anima
	end
end--}}}
function graphicLoader.getFrame(frameName)
	local frameCache = CCSpriteFrameCache:sharedSpriteFrameCache()
	local frame =  assert(frameCache:spriteFrameByName(frameName),'can not find frame with name: ' .. frameName)
	return frame
end
--��ȡ��������
function graphicLoader.animaName(prefix, action, dir) --dir is in degree
	if not dir then dir = 0 end
	local dirFlag = math.floor((dir + 90)/90)
	return string.format('%s_%02d%02d', prefix, action, dirFlag)
end
--��ȡ������������
function graphicLoader.getActionCfg(prefix,action)
	local anima_cfg =assert(animaBattleUnit[prefix],"this is no animation with prefix "..prefix)
	local action_cfg = assert(anima_cfg[action],"this is no action with id "..action)
	return action_cfg
end

function graphicLoader.animaDelay(prefix, action)
	local action_cfg = graphicLoader.getActionCfg(prefix,action)
    return action_cfg.delay
end

function graphicLoader.animaDurS(prefix, action)
	local action_cfg =graphicLoader.getActionCfg(prefix,action)
    return action_cfg.frames*action_cfg.delay
end

function graphicLoader.animaDurMS(prefix, action)
	local action_cfg = graphicLoader.getActionCfg(prefix,action)
    return action_cfg.frames*action_cfg.delay*1000
end

function graphicLoader.getOrigUnitDelay(animaName)--{{{
	if not _animaInfoCfg[animaName] then
		graphicLoader.getAnimation(animaName)
	end
    return _animaInfoCfg[animaName].delay or 0.1
end--}}}

function graphicLoader.getOrigDurition(animaName)--{{{
    if not _animaInfoCfg[animaName] then
		graphicLoader.getAnimation(animaName)
	end
    return _animaInfoCfg[animaName].durationS
end--}}}




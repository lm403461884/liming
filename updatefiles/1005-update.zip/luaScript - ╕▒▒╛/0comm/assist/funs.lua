
Funs={}
--����Ԫ����������Ԫ����ָ�����ߵĶ�ά�����е�X����  ���Ͻ�Ϊԭ��Ϊ��0��0����������ʼֵΪ1
function Funs.getX(w,idx)
    return (idx-1)%w
end
--����Ԫ����������Ԫ����ָ�����ߵĶ�ά�����е�Y����  ���Ͻ�ԭ��Ϊ��0��0����������ʼֵΪ1
function Funs.getY(w,idx)
    return Funs.getInt((idx-1)/w)
end
--����Ԫ����������Ԫ���������Ļ���½ǵĴ�ֱ����
function Funs.getViewY(w,h,idx)
    return  h - Funs.getInt((idx-1)/w )- 1
end
--����Ԫ����������Ԫ�������㼶 �㼶����Ļ�Ϸ���ʼ����ʼֵΪ1
function Funs.getDeep(w,h,idx)
    return   Funs.getInt((idx-1)/w) +1
end
--���ݶ�ά���������������ֵ ����ֵΪ1 ��Ļ���Ϸ�Ϊԭ�㣨0,0��
function Funs.getIndex(x,y,w,h)
    return (h-1-y)*w + x + 1
end
--���ݾ���ͼƬ���ؿ��Ⱥ;�������Ļ�ϵ�X���꣬���㾫���ڵ�ͼ��ά�����е�X����ֵ
function Funs.getpX(px,pw)
    return Funs.getInt(px/pw)
end
--���ݾ���ͼƬ���ظ߶Ⱥ;�������Ļ�ϵ�Y���꣬���㾫���ڵ�ͼ��ά�����е�Y����ֵ
function Funs.getpY(py,ph)
    return Funs.getInt(py/ph)
    
end
--��ȡ��������
function Funs.getInt(val)
    local valInt,_ = math.modf(val)
    return valInt
end
--��ȡ�Ϸ�ָ����Χ������
function Funs.getTopIdx(idx,w,num,idxlist,tb)
    if not idxlist then idxlist = {} end
    if not tb then tb = {} end
    while idx > w and num > 0 do
        idx = idx - w
        num = num - 1
        local r = idxlist[idx]
        if not r then 
            r = 0 
            table.insert(tb,idx)
        end
        if num > r then r = num end
        idxlist[idx] = r
    end
    return idxlist
end
--��ȡ�·�ָ����Χ������
function Funs.getBottomIdx(idx,w,h,num,idxlist,tb)
    if not idxlist then idxlist = {} end
    if not tb then tb = {} end
    while idx <= w*(h-1) and num > 0 do
        idx = idx + w
        num = num - 1
        local r = idxlist[idx]
        if not r then 
            r = 0 
            table.insert(tb,idx)
        end
        if num > r then r = num end
        idxlist[idx] = r
    end
    return idxlist
end
--��ȡ��ָ����Χ������
function Funs.getLeftIdx(idx,w,num,idxlist,tb)
    if not idxlist then idxlist = {} end
    if not tb then tb = {} end
    while (idx % w >1 or idx % w ==0) and  num > 0  do
        idx = idx - 1
        num = num - 1
        local r = idxlist[idx]
        if not r then 
            r = 0 
            table.insert(tb,idx)
        end
        if num > r then r = num end
        idxlist[idx] = r
    end
    return idxlist
end
function Funs.trimStr(str)
	 if not str then return "" end
	 return (string.gsub(str, "^%s*(.-)%s*$", "%1")) 
end
function Funs.trimlStr(str)
	 if not str then return "" end
	 return (string.gsub(str, "^%s*(.-)$", "%1")) 
end
function Funs.trimrStr(str)
	 if not str then return "" end
	return (string.gsub(str, "^(.-)%s*$", "%1")) 
end
--��ȡ�ҷ�ָ����Χ������
function Funs.getRightIdx(idx,w,num,idxlist,tb)
    if not idxlist then idxlist = {} end
    if not tb then tb = {} end
    while idx % w > 0  and  num > 0  do
        idx = idx + 1
        num = num - 1
        local r = idxlist[idx]
        if not r then 
            r = 0 
            table.insert(tb,idx)
        end
        if num > r then r = num end
        idxlist[idx] = r
    end
    return idxlist
end
--��ȡ��ָ������Ϊ���ģ�ָ������Ϊ�뾶�����η�Χ�ڵ�������
function Funs.getIdxInVision(center,w,h,r,viewlist)
    if not viewlist then viewlist = {} end
    local tb = {}
    if type(center) == "table" then
        for k,v in pairs(center) do
            table.insert(tb,k)
        end
    else
        table.insert(tb,center)
    end
    for i = 1,#tb do
        local k = tb[i]
        viewlist[k] = r
        Funs.getRightIdx(k,w,r,viewlist,tb)
        Funs.getLeftIdx(k,w,r,viewlist,tb)
    end
    for i = 1,#tb do
        local idx = tb[i]
        local cr = viewlist[idx]
        Funs.getBottomIdx(idx,w,h,cr,viewlist,tb)
        Funs.getTopIdx(idx,w,cr,viewlist,tb)
    end
    return viewlist
end
--��ȡ�Ϸ�����
function Funs.getTop(idx,w)
    if idx <= w then
        return 0
    else
        return idx - w
    end
end
--��ȡ�·�����
function Funs.getBottom(idx,w,h)
    if (idx + w ) > w*h then
        return 0
    else
        return idx + w
    end
end
--��ȡ������
function Funs.getRight(idx,w )
    if idx % w == 0 then
        return 0
    else
        return idx + 1
    end
end
--��ȡ�ҷ�����
function Funs.getLeft(idx,w)
    if idx % w == 1 then
        return 0
    else
        return idx - 1
    end
end
--��ȡ���Ϸ�����
function Funs.getLeftTop(idx,w)
    local leftidx = Funs.getLeft(idx,w)
    if leftidx == 0 then return 0 end
    local topidx = Funs.getTop(leftidx,w)
    return topidx
end
--��ȡ���·�����
function Funs.getLeftBottom(idx,w,h)
    local leftidx = Funs.getLeft(idx,w)
    if leftidx == 0 then return 0 end
    local bottomidx = Funs.getBottom(leftidx,w,h)
    return bottomidx
end

--��ȡ���·�����
function Funs.getRightBottom(idx,w,h)
    local rightidx = Funs.getRight(idx,w)
    if rightidx == 0 then return 0 end
    local bottomidx = Funs.getBottom(rightidx,w,h)
    return bottomidx
end

--��ȡ���Ϸ�����
function Funs.getRightTop(idx,w)
    local rightidx = Funs.getRight(idx,w)
    if rightidx == 0 then return 0 end
    local topidx = Funs.getTop(rightidx,w)
    return topidx
end
--��ȡ�����������ŵ����ݱ�ʾ
--��: 99���Ϊ+99
function Funs.signedNum(val)
	if val > 0 then return string.format("+%d",val) 
	else return string.format("%d",val) end
	
end
--��xxx,xxx,xxx�ĸ�ʽ��������
function Funs.formatNum(val)
     local str = tostring(val)
     local valstr = str
     local len = #str
        if len > 3  then
            valstr = ""
            local startidx = len%3
            local cnt,_ = math.modf(len/3)
            if startidx > 0 then valstr = string.sub(str,1, startidx) end
            for idx = 1,cnt do
                if valstr == "" then
                    valstr = string.sub(str, startidx + 1 + (idx-1)*3, startidx + idx*3)
                else
                    valstr = valstr .. ","..string.sub(str, startidx + 1 + (idx-1)*3, startidx + idx*3)
                end
            end
        end
      return valstr
end
--��ʾ����ת��
--�� ���ֵ��999��1000��ת��Ϊ999+��900��Ȼ��900
function Funs.getBouncedNum(val,maxVal,withSplit)
	if val > maxVal then
		if withSplit then
			return string.format("%s%s",Funs.formatNum(maxVal),"+")
		else
			return string.format("%d%s",maxVal,"+")
		end
	else
		if withSplit then
			return Funs.formatNum(val)
		else
			return string.format("%d",val)
		end
	end
	
end
--��00:00:00�ĸ�ʽ����ʱ��
function Funs.formatTime(val)
    local hour,_ = math.modf(val/3600)
    local min,_ = math.modf((val-hour*3600)/60)
    local sec = val -hour*3600 - min*60
    local valstr = string.format("%02d:%02d:%02d",hour,min,sec)
    return valstr
end
--�����ĸ�ʽ���ʱ��
function Funs.formatTimeCh(val,d,h,m,s,auto)
    local day,_ = math.modf(val/3600/24)
    local tmpsec = val - day*3600*24
    local hour,_ = math.modf(tmpsec/3600)
    local min,_ = math.modf((tmpsec-hour*3600)/60)
    local sec,_ = math.modf(tmpsec-hour*3600 - min *60)
    local valstr = ""
    if d and day > 0 then valstr = valstr..string.format("%d%s",day,TxtList.day) end
    if h and hour > 0 then valstr = valstr..string.format("%d%s",hour,TxtList.hour) end
    if m and min > 0 then valstr = valstr..string.format("%d%s",min,TxtList.minute) end
    if not auto then
        if s and sec > 0 then valstr = valstr..string.format("%d%s",sec,TxtList.sec) end
    else
        if day == 0 and min == 0 and hour == 0 then 
            valstr = valstr..string.format("%d%s",sec,TxtList.sec)
        end
    end
    return valstr
end
--�����ĸ�ʽ���ʱ�䣬����ֵΪ���� + ��λ
function Funs.formmatTimeCh2(val,oneCh)
	--local day = math.ceil(val/3600/24)
	--if day > 0 then return day,TxtList.day end
	if val < 60 then 
        return val,TxtList.sec 
	elseif val < 3600 then 
        local minute = math.ceil(val/60)
        return minute,TxtList.minute
    else
        local hour = math.ceil(val/3600)
		if oneCh then
			return hour,TxtList.hour
		else
			return hour,TxtList.hours
		end
    end
end
function Funs.formatTimeEn(val)
	if val < 60 then 
        return val,"s"
	elseif val < 3600 then 
        local minute = math.ceil(val/60)
        return minute,"m"
    elseif val < 24*3600 then
        local hour = math.ceil(val/3600)
		return hour,"h"
	else
		local day = math.ceil(val/(24*3600))
		return day,"d"
    end
end
function Funs.findItemIdx(item,tb)
    for key,val in pairs(tb) do    
        if  val == item then return key end
    end
    return nil
end
function Funs.findItemByProp(propname,propval,tb)
    for key,item in pairs(tb) do    
        if  item[propname] == propval then return item end
    end
    return nil
end
function Funs.isTbEqual(tb1,tb2)
    if tb1 == tb2 then return true end
    if #tb1 ~= #tb2 then return false end
    for key,val in pairs (tb1) do
        if tb2[key] ~= val then return false end
    end
    return true
end
function Funs.copy(src)
    if type(src) == "table" then
        local des = {}
        for k,v in pairs(src) do
            des[k] = Funs.copy(v)
        end
        return des
    else
        return src
    end
end
function Funs.subStr(str,length)
	local gbkStr = str
	local isUtf8 = HOAux:isUTF8(gbkStr)
	if isUtf8 then	gbkStr = HOAux:UTF2GBK(gbkStr) end
	local strLen = string.len(gbkStr)
	if strLen > length then
		gbkStr = string.sub(gbkStr,1,length)
		local startIdx,endIdx = string.find(gbkStr,"[%p,%w,%s]$")
		if not startIdx then
			local tmp = string.gsub(gbkStr,"[%p,%w,%s]","")
			if string.len(tmp)%2 == 1 then
				gbkStr = string.sub(gbkStr,1,length-1)
			end
		end
	end
	if isUtf8 then 
		str = HOAux:GBK2UTF(gbkStr) 
	else
		str = gbkStr
	end
	return str
end
function Funs.formatStr(str)
	str = string.gsub(str,"\\" ,"\\\\")	
	str =  string.gsub(str,"\'" ,"\\\'")
	return str
end
function Funs.splitStr(str,delim)   
    -- Eliminate bad cases...   
    if string.find(str, delim) == nil then  
        return { str }  
    end  
    local result = {}  
    local pat = "(.-)" .. delim .. "()"   
    local nb = 0  
    local lastPos   
    for part, pos in string.gfind(str, pat) do  
        nb = nb + 1  
        result[nb] = part   
        lastPos = pos   
        if nb == maxNb then break end  
    end  
	local lastStr = string.sub(str, lastPos) 
	if string.len(lastStr) >0 then
		result[nb + 1] = lastStr
	end
    return result   
end  
--ƴ������
function Funs.composeInt(baseNum,params)
	local totalVal = 0
	for key,val in ipairs(params) do
		totalVal = totalVal + val * (baseNum^(key-1))
	end
	return totalVal
end
function Funs.toGBK(str)
	local gbkStr = str
	if HOAux:isUTF8(gbkStr) then gbkStr = HOAux:UTF2GBK(gbkStr) end
	return gbkStr
end
function Funs.toUTF(str)
	local utfStr = str
	if not HOAux:isUTF8(utfStr) then utfStr = HOAux:GBK2UTF(utfStr) end
	return utfStr
end
--��������
function Funs.deComposeInt(val,baseNum,cnt)
    if not val then val = 0 end
	local tb = {}
	for idx=1,cnt do
		table.insert(tb,math.floor((val%(baseNum^idx))/(baseNum^(idx-1))))
	end
	return unpack(tb)
end
function Funs.getTimeWithHMS(h,m,s,offset,isNextDay)
	if not offset then offset = 0 end
	if isNextDay then
		local tb_next = os.date('*t', os.time()+24*3600)
		tb_next.hour = h or 0
		tb_next.min = m or 0
		tb_next.sec = s or 0
		return os.time(tb_next) + offset
	else
		local t_cur = os.time()
		local tb_today = os.date('*t', t_cur)
		tb_today.hour = h
		tb_today.min = m
		tb_today.sec = s
		local t_today = os.time(tb_today) + offset
		if t_today > t_cur then
			return t_today 
		else
			return t_today + 24*3600
		end
	end 
end
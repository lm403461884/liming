TDHelper = {}
--==============================
--TDCCTalkingDataGA 基本类
--==============================
function TDHelper.init()
	--TDCCTalkingDataGA:onStart("E77A7EA9AD3ADDBAEB6F9FED21519245","1up")
end
function TDHelper.onEvent(eventId,eventData)
	if not eventData then eventData = {} end
	TDCCTalkingDataGA:onEvent(eventId,eventData)
end
function TDHelper.setLatitude(latitude,longitude)
	TDCCTalkingDataGA:setLatitude(latitude,longitude)
end
function TDHelper.getDeviceId()
	return TDCCTalkingDataGA:getDeviceId()
end
function TDHelper.onKill()
	TDCCTalkingDataGA:onKill()
end
function TDHelper.setVerboseLogDisabled()
	TDCCTalkingDataGA:setVerboseLogDisabled()
end
function TDHelper.setVerboseLogEnabled()
	TDCCTalkingDataGA:setVerboseLogEnabled()
end
--==============================
--TDCCAccount 帐号相关
--==============================
function TDHelper.setAccount(acctId)
	TDCCAccount:setAccount(acctId)
end
function TDHelper.setAccountName(acctName)
	TDCCAccount:setAccountName(acctName)
end
function TDHelper.setAccountType(acctType)
	TDCCAccount:setAccountType(acctType)
end
function TDHelper.setLevel(lv)
	TDCCAccount:setLevel(lv)
end
function TDHelper.setGender(gender)
	TDCCAccount:setGender(gender)
end
function TDHelper.setAge(age)
	TDCCAccount:setAge(age)
end
function TDHelper.setGameServer(gameServer)
	TDCCAccount:setGameServer(gameServer)
end
function TDHelper.setAccountInfo(acctInfo)
	if acctInfo then
		TDHelper.setAccount(acctInfo.acctId)
		local acctType = acctInfo.acctType
		local acctLv = acctInfo.acctLv
		local acctGender = acctInfo.acctGender
		local acctAge = acctInfo.acctAge
		local gameServer = acctInfo.gameServer
		if acctType then TDHelper.setAccountType(acctType) end
		if acctLv then TDHelper.setLevel(acctLv) end
		if acctGender then TDHelper.setGender(acctGender) end
		if acctAge then TDHelper.setAge(acctAge) end
		if gameServer then TDHelper.setGameServer(gameServer) end
	end
end
--==============================
--TDCCItem 产品相关
--==============================
function TDHelper.onPurchase(item,number,price)
	TDCCItem:onPurchase(item,number,price)
end
function TDHelper.onUseItem(item,number)
	TDCCItem:onUse(item,number)
end
--==============================
--TDCCMission 任务相关
--==============================
function TDHelper.onMissionBegin(missionId)
	TDCCMission:onBegin(missionId)
end
function TDHelper.onMissionCompleted(missionId)
	TDCCMission:onCompleted(missionId)
end
function TDHelper.onMissionFailed(missionId,failedCause)
	if not failedCause then failedCause = "" end
	TDCCMission:onFailed(missionId,failedCause)
end
--==============================
--TDCCVirtualCurrency 支付相关
--==============================
function TDHelper.onChargeRequest(orderId,iapId,currencyAmount,currencyType,virtualCurrencyAmount,paymentType)
	TDCCVirtualCurrency:onChargeRequest(orderId,iapId,currencyAmount,currencyType,virtualCurrencyAmount,paymentType)
end
function TDHelper.onChargeSuccess(orderId)
	TDCCVirtualCurrency:onChargeSuccess(orderId)
end
function TDHelper.onReward(currencyAmount,reason)
	TDCCVirtualCurrency:onReward(currencyAmount,reason)
end
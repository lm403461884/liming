SpeedManager = {}
--��ʼ���ٶ�����
function SpeedManager:init()
	self._values = nil
	self._values = SecurityManager:encrypt({minSpeed = 1,maxSpeed = 2,curSpeed = 1})
	CCDirector:sharedDirector():getScheduler():setTimeScale(self._values.curSpeed)
end
--����
function SpeedManager:speedUp()
	self._values.curSpeed = self._values.maxSpeed
	CCDirector:sharedDirector():getScheduler():setTimeScale(self._values.curSpeed)
end
--��ԭ�ٶ�
function SpeedManager:resetSpeed()
	self._values.curSpeed = self._values.minSpeed
	CCDirector:sharedDirector():getScheduler():setTimeScale(self._values.curSpeed)
end
--��ȡ��ǰ�ٶ�
function SpeedManager:getSpeed()
	return self._values.curSpeed
	
end
function SpeedManager:getMinSpeed()
	return self._values.minSpeed
	
end
function SpeedManager:getMaxSpeed()
	return self._values.maxSpeed
	
end
--�ж��Ƿ�������״̬
function SpeedManager:isSpeedUp()
	return self._values.curSpeed == self._values.maxSpeed
	
end
--��鵱ǰ�ٶ�
function SpeedManager:check()
	if not self._values then return end
	if CCDirector:sharedDirector():getScheduler():getTimeScale() ~= self._values.curSpeed then
		CCDirector:sharedDirector():getScheduler():setTimeScale(self._values.curSpeed)
	end
end
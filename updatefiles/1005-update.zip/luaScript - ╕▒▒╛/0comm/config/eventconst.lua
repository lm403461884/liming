--region eventconst.lua
--Author : Yanlee
--Date   : 2014/12/2
--事件常量
CLTEvent=
{
--SDK相关
	LoginSucceed = "LoginSucceed",
	LoginError = "LoginError",
	LogserSucceed = "LogserSucceed",
	LogserError = "LogserError",
	PurchaseSucceed = "purchaseSucceed",
	PurchaseError = "purchaseError",
	InitPurchaseSucceed = "initPurchaseSucceed",
	InitPurchaseError = "initPurchaseError",
	ExitGame = "ExitGame",
	ContinueGame = "ContinueGame",
	LogOutSucceed = "logOutSucceed",
	LogOutError = "LogOutError",
	SwitchingAccount="SwitchingAccount",
	SwitchingAccountFailed="SwitchingAccountFailed",
--客户端自定义事件
	CServerDownloaded = "s_ser_downloaded", --服务器列表下载完成
	CVerNotMatch = "s_ver_not_match", --版本不符
	CDSFingerError = "s_ds_finger_not_match", --指纹校验错误
	CAcctDownLoad = "s_acct_download", --获取帐号数据成功
	CClubDownLoad = "s_club_download", --公会数据获取 成功
	CClubWarDownLoad = "s_clubwar_download", --公会战数据获取成功
	CGSLoginError = "s_gs_login_error", --登陆GS失败
	CBeenAttack = "s_been_attacking",--正在被攻打
	CReLogin = "s_login_twice", --重复登陆
	CForbidLogin = "s_forbiden_login", --帐号封停
}
kEventClubSearch = "s_clubsearch_data"--公会关键字搜索
kEventGetClubView = "s_lookClub_data" -- 查看公会数据


kEventLicenceUpStart = "s_licenceup_start"
kEventLicenceUpEnd = "s_licenecup_end"
kEventTrainUpStart = "s_trainup_start"
kEventTrainUpEnd = "s_trainup_end"
kEventBuyNewTrain = "s_buy_newtrain"

kEventNoticeMail = "s_newmail_vedios"--主界面邮件监听
kEventNoticeTask = "s_task_finished"--主界面挖掘日志监听
kEventNoticeMission = "s_new_mission" --主界面冒险任务监听

kEventRequestTimeOut = "s_request_timeout" --请求数据超时

kEventSDKAuthorized = "s_sdk_authorized" --SDK第三方登陆验证通过
--endregion
local fx_bgm = "sound/bgm/"
local fx_menu = "sound/menu/"
local fx_sprite = "sound/sprite/"
local fx_item = "sound/item/"
local bgm_ns = ".mp3"
local effect_ns = ".wav"
if CCApplication:sharedApplication():getTargetPlatform() == kTargetAndroid then
	bgm_ns = ".ogg"
	effect_ns = ".ogg"
end
SoundList = {}
SoundList.bgm_ns = bgm_ns
SoundList.effect_ns = effect_ns
SoundList.train_bgm = fx_bgm.."HO_train"..bgm_ns
--SoundList.train2_bgm = fx_bgm.."HO_train2"..bgm_ns
SoundList.train3_bgm = fx_bgm.."HO_train3"..bgm_ns
SoundList.shop_bgm = fx_bgm.."HO_shop"..bgm_ns
SoundList.rish_bgm = fx_bgm.."HO_world_map"..bgm_ns
SoundList.atk_bgm = fx_bgm.."HO_battle_attack"..bgm_ns
SoundList.atk_hard = fx_bgm.."HO_battle_hard"..bgm_ns
SoundList.atk_nomal = fx_bgm.."HO_battle_nomal"..bgm_ns
SoundList.atk_boss = fx_bgm.."HO_battle_boss"..bgm_ns
--SoundList.atk_boss2 = fx_bgm.."HO_battle_boss2"..bgm_ns
SoundList.def_bgm = fx_bgm.."HO_battle_attack"..bgm_ns
SoundList.dig_bgm = fx_bgm.."HO_mining"..bgm_ns
SoundList.comic_bgm = fx_bgm.."HO_opening"..bgm_ns
SoundList.rain_bgm = fx_bgm.."HO_raining"..bgm_ns
SoundList.login_bgm = fx_bgm.."HO_login"..bgm_ns

SoundList.arriveStation = fx_menu.."arrive_station"..effect_ns --到达新地区火车进站
SoundList.battleLose = fx_menu.."battle_lose"..effect_ns --战斗失败
SoundList.battleWin = fx_menu.."battle_win"..effect_ns --战斗胜利
SoundList.clickMenu = fx_menu.."click_menu"..effect_ns --主界面面板按键
SoundList.clickTrain = fx_menu.."click_train"..effect_ns --火车点击
SoundList.clickTrainHead = fx_menu.."click_train_head"..effect_ns --火车头出发
SoundList.digBlock = fx_menu.."dig_block"..effect_ns --挖掘普通砖块
SoundList.digDisabled = fx_menu.."dig_disable"..effect_ns --挖掘等级不足提示
SoundList.digFailed = fx_menu.."dig_failed"..effect_ns --高级土块一次未挖碎
SoundList.digOil = fx_menu.."dig_oil"..effect_ns --挖掘石油
SoundList.digGold = fx_menu.."dig_gold"..effect_ns --挖掘金矿
SoundList.inviteHero = fx_menu.."invite_hero"..effect_ns --招募成功
SoundList.message = fx_menu.."message"..effect_ns --消息
SoundList.up_level = fx_menu.."up_level"..effect_ns --英雄升级
SoundList.up_equip = fx_menu.."up_equip"..effect_ns --装备进阶
SoundList.monsterupdate = fx_menu.."monsterupdate"..effect_ns --怪物升级
SoundList.equipup = fx_menu.."equipup"..effect_ns --装备装上
SoundList.equipdown = fx_menu.."equipdown"..effect_ns --装备分解
SoundList.equipkeep = fx_menu.."equipkeep"..effect_ns --装备保留
SoundList.equipword = fx_menu.."equipword"..effect_ns --装备漂字

SoundList.monster_get = fx_menu.."monster_get"..effect_ns --怪物制造



SoundList.fire_burn = fx_menu.."fire_burn"..effect_ns --点击装备工坊

SoundList.Steam_update = fx_menu.."Steam_update"..effect_ns --车厢升级按钮点击

--temp--
SoundList.destroy_rock = fx_menu.."Destroy_rock"..effect_ns
SoundList.gold_Metal_click = fx_menu.."gold_Metal_click"..effect_ns

--道具音效
SoundList.baseball_attack_01 = fx_item.."baseball_attack_01"..effect_ns
SoundList.baseball_hit_01 = fx_item.."baseball_hit_01"..effect_ns
SoundList.Goods_cookie = fx_item.."Goods_cookie"..effect_ns
SoundList.GasBomb_attack_01 = fx_item.."GasBomb_attack_01"..effect_ns
SoundList.Goods_perk = fx_item.."Goods_perk"..effect_ns
SoundList.Goods_detect = fx_item.."Goods_detect"..effect_ns
SoundList.Goods_potion = fx_item.."Goods_potion"..effect_ns
SoundList.Goods_throw = fx_item.."Goods_throw"..effect_ns

SoundList.energe_ready = fx_item.."energe_ready"..effect_ns
SoundList.energe_fire = fx_item.."energe_fire"..effect_ns

SoundList.open_treasurebox = fx_menu.."open_treasurebox"..effect_ns --开宝箱
--界面音效
SoundList.click_back_button = fx_menu.."click_back_button"..effect_ns --返回
SoundList.click_buy_button = fx_menu.."click_buy_button"..effect_ns --购买
SoundList.click_paper_close = fx_menu.."click_paper_close"..effect_ns --关闭页面
SoundList.click_paper_open = fx_menu.."click_paper_open"..effect_ns --打开页面
SoundList.click_shop_goods = fx_menu.."click_shop_goods"..effect_ns --点击项目
SoundList.click_world_menu = fx_menu.."click_world_menu"..effect_ns --点击音效
SoundList.shop_door_open = fx_menu.."shop_door_open"..effect_ns --打开商店
SoundList.mine_die_01 = fx_item.."mine_die_01"..effect_ns --打开商店
SoundList.mine_hurt_01 = fx_item.."mine_hurt_01"..effect_ns --打开商店
SoundList.box_open_01 = fx_item.."box_open_01"..effect_ns --宝箱点击
SoundList.buy_hero_01 = fx_menu.."buy_hero_01"..effect_ns --点击雇佣
SoundList.buy_message_01 = fx_menu.."buy_message_01"..effect_ns --点击信封
SoundList.update_equip = fx_menu.."update_equip"..effect_ns --点击装备升级
SoundList.click_letter_open = fx_menu.."click_letter_open"..effect_ns --点击信封
SoundList.logo = fx_menu.."logo"..effect_ns --登录音效

--坑洞生物操作音效

SoundList.click_monster_dig = fx_menu.."click_rescar_dig"..effect_ns --点击坑道生物
SoundList.set_monster_dig = fx_menu.."set_rescar_digres"..effect_ns --放置坑道生物
SoundList.click_monster_menu = fx_menu.."click_monster_menu"..effect_ns --坑道生物栏点击
SoundList.click_rescar_dig = fx_menu.."click_rescar_dig"..effect_ns --点击坑道中矿车
SoundList.click_rescar_digres = fx_menu.."click_rescar_digres"..effect_ns --点击坑道中正在挖矿的矿车与放置矿车在矿上
SoundList.set_rescar_digres = fx_menu.."set_rescar_digres"..effect_ns --放置机械怪与放置矿车在非矿上
SoundList.click_rescar_dighasres = fx_menu.."click_rescar_dighasres"..effect_ns --点击有资源的矿车
SoundList.hero_go = fx_menu.."hero_go"..effect_ns --英雄进入战斗点击音效
SoundList.click_Error = fx_menu.."click_Error"..effect_ns --错误提示音通用

--战斗单位用音效
SoundList.battle_uint_effect = {}
function addUnitSoundEffect(unit_name)
	if not SoundList.battle_uint_effect[unit_name] then SoundList.battle_uint_effect[unit_name] = {} end
	for eff_num,eff_name in ipairs(soundEffectUnit[unit_name] or {}) do
		if not SoundList.battle_uint_effect[unit_name][eff_name] then
			SoundList.battle_uint_effect[unit_name][eff_name] = fx_sprite..unit_name.."/"..eff_name..effect_ns
			SoundHelper.preLoadEffect(SoundList.battle_uint_effect[unit_name][eff_name])
		end
	end
end
function removeUnitSoundEffect(unit_name)
	if SoundList.battle_uint_effect[unit_name] then
		for eff_num,eff_name in ipairs(soundEffectUnit[unit_name] or {}) do
			SoundHelper.unloadEffect(SoundList.battle_uint_effect[unit_name][eff_name])
			SoundList.battle_uint_effect[unit_name][eff_name] = nil
		end
		SoundList.battle_uint_effect[unit_name] = nil
	end
end

SoundList.bgm = {
	town = {
		[1]=SoundList.train3_bgm,
		[2]=SoundList.train_bgm,
		[3]=SoundList.train3_bgm,
		[4]=SoundList.train_bgm,
		[5]=SoundList.train_bgm,
		[6]=SoundList.train_bgm,
		[7]=SoundList.train3_bgm,
		[8]=SoundList.train_bgm,
		[9]=SoundList.train3_bgm,
		[10]=SoundList.train3_bgm,
		[11]=SoundList.train_bgm,
		[12]=SoundList.train_bgm,
		[13]=SoundList.train_bgm,
		[14]=SoundList.train_bgm,
		[15]=SoundList.train_bgm,
		[16]=SoundList.train_bgm,
		[15]=SoundList.train_bgm,
		[16]=SoundList.train_bgm,
		},
	battle = {
		[1]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[2]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[3]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[4]={
			[11]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[5]={
			[8]=SoundList.atk_boss,
			[12]=SoundList.atk_bgm,
			[15]=SoundList.atk_bgm,
			[18]=SoundList.atk_bgm,
			[21]=SoundList.atk_bgm,
			[24]=SoundList.atk_bgm,
			},
		[6]={
			[13]=SoundList.atk_bgm,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[7]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[8]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_hard,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[9]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		[10]={
			[13]=SoundList.atk_boss,
			[16]=SoundList.atk_bgm,
			[19]=SoundList.atk_bgm,
			[22]=SoundList.atk_bgm,
			[25]=SoundList.atk_bgm,
			[28]=SoundList.atk_bgm,
			},
		},

}
SoundList.getTownBGM = function(acct)
	local filename = SoundList.bgm.town[acct.sceneID]
	if not filename then filename = SoundList.train_bgm end
	return  filename
end
SoundList.getBattleBGM = function(areaid,stageid)
	local filename = SoundList.atk_bgm
	if not areaid or not stageid then return filename end
	local bgmCfg = SoundList.bgm.battle[areaid]
	if not bgmCfg then return filename  end
	if not  bgmCfg[stageid] then return filename end
	return bgmCfg[stageid]
end


SDKConfig={}
SDKConfig._sdkFlag = 1
SDKConfig._sdkChannel = "1UP"
SDKConfig._acctType = TDCCAccount.kAccountAnonymous
SDKConfig._logoImg = "logo.png"
SDKConfig._hasQuitLayer = false
SDKConfig._needLogout = false
function SDKConfig.getFlag()
	return SDKConfig._sdkFlag
end
function SDKConfig.getChannel()
	return SDKConfig._sdkChannel
end
function SDKConfig.getAcctType()
	return SDKConfig._acctType
end
function SDKConfig.setAcctType(acctType)
	SDKConfig._acctType = acctType
end
function SDKConfig.getLogoImg()
	return SDKConfig._logoImg
end
function SDKConfig.hasQuitLayer()
	return SDKConfig._hasQuitLayer
end
function SDKConfig.needLogOut()
	return SDKConfig._needLogout
end
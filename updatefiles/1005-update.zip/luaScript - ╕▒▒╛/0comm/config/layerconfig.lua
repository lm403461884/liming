TouchLv = 
{
    guidLayer = -254,
    menuLayer = -2,
    btnMaskLayer = -1,
    normalLayer = 0,
    
}
UILv=
{
	particleLayer = 258,
	quitLayer = 257,
    guidLayer = 255,
    cdLayer = 9,
    popLayer = 5,
    loadingLayer = 11
}
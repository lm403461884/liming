local kMaxScrollSpeed = 1000
local kMinScrollSpeed = 10
local kAcceleration = -1000  --���ٶ�
local kMaxScaleTime = 2
local __view={}
function __view.init(obj)
    obj._innerObj = CCLayer:create()
    obj._innerObj:ignoreAnchorPointForPosition(false)
    obj._innerObj:setAnchorPoint(ccp(0,0))
    obj:activeInnerTouch()
    obj:activeInnerUpdate()
    obj:egAddChild(obj._innerObj)
    obj._beganPts = {}
    obj._movePts = {}
    obj._preMovePts = {}
    obj._startPointId = nil 
    obj._m_distance = 0
    obj._m_dir = ccp(0,0)
    obj._pressed = false -- ����Ƿ���
    obj._autoScroll = false --����Ƿ��Զ�����
    obj._slideTime = 0
    obj._originalSpeed = 0
    obj._autoScrolledTime = 0
    --�������
    obj._scaleTime = 0
    obj._scaleRate = 0
    obj._autoScale = false
    obj._scaleOverRange = false
    obj._targetScale = 0
    obj._scaleCenter = nil

    obj._minScale = 1
    obj._maxScale = 1
    --�ƶ����
    obj._hasDes = false
    obj._offsetX = 0
    obj._offsetY = 0
    obj._movedX = 0
    obj._movedY = 0
    obj._usedTime = 0
    obj._des_dir = nil
    obj._des_speed = 0
	obj._frameid = 0
end
--��ȡ���ܵ���С������
function __view.getExtramMinScale(obj)
    local outerSize = obj._egObj:getContentSize()
    local innerSize = obj._innerObj:getContentSize()
    local intval,_ = math.modf(math.max(outerSize.width/innerSize.width,outerSize.height/innerSize.height)*100)
    local minscale = intval/100
    return minscale
end
function __view.activeInnerUpdate(obj)
    local function update(delta)
        if obj._hasDes then
            obj:doScrollToDes(delta)
        else
            if obj._pressed then obj._slideTime = obj._slideTime + delta end --������¼����ʱ��
            if obj._scaleOverRange then obj._scaleTime = obj._scaleTime + delta  end --��������ʱ��
            if obj._autoScroll then
                obj:doAutoScroll(delta)
            end
			if obj._autoScale then
				obj:doAutoScale(delta)
			end
        end
		
    end
    local function exitFuns(eventType)
        if eventType == "exit" then  obj._innerObj:unscheduleUpdate() end
    end
    obj._innerObj:scheduleUpdateWithPriorityLua(update, 0)
    obj._innerObj:registerScriptHandler(exitFuns)
end
function __view.activeInnerTouch(obj)
      local function onTouches(eventType, touches)
        if eventType == "began" then
			if GuideManager:isGuiding() then return false end
			obj:onInnerTouchBegan(touches)
        elseif eventType == "moved" then
			obj:onInnerTouchMoved(touches)
        elseif eventType =="ended" then
            obj:onInnerTouchEnd(touches)
        else
            obj:onInnerTouchCancelled(touches)
        end
    end
    obj._innerObj:registerScriptTouchHandler(onTouches,true,0,true)
    obj._innerObj:setTouchEnabled(true)
end
function __view.getArrayCnt(obj,array)
    local cnt = 0
    for key,val in pairs(array) do  
        cnt = cnt+1
    end
    return cnt
end
function __view.onInnerTouchBegan(obj,touches)
    obj._pressed = true
    for i = 1,#touches ,3 do
        local id = touches[i+2]
        local x = touches[i]
        local y = touches[i+1]
        obj._beganPts[id] = ccp(x,y)
        obj._preMovePts[id] = obj._beganPts[id]
        if not obj._startPointId then  --��δ����ת���Ѱ���״̬ʱ�����û���ʱ��
            obj._startPointId = id 
            obj:stopAutoScroll()
            obj:stopAutoScale()
        end
    end
end
function __view.onInnerTouchMoved(obj,touches)
    local startPointMoved = false
    obj._movePts ={}
    for i = 1,#touches ,3 do
        local id = touches[i+2]
        local x = touches[i]
        local y = touches[i+1]
        obj._movePts[id] = ccp(x,y)
        if id == obj._startPointId then startPointMoved = true end
    end
    if obj:getArrayCnt(obj._beganPts) == 1 then
        obj:onInnerMoved(obj._preMovePts[obj._startPointId],obj._movePts[obj._startPointId])
    elseif obj:getArrayCnt(obj._beganPts) > 1 then
        local beginPts = {}
        local movePts = {}
        if  not startPointMoved then
            table.insert(beginPts,obj._preMovePts[obj._startPointId])
            table.insert(movePts,obj._movePts[obj._startPointId])
        end
        for key,pos in pairs(obj._movePts) do
            table.insert(beginPts,obj._preMovePts[key])
            table.insert(movePts,pos)
        end
        if #movePts < 2 then
            for key,pos in pairs(obj._beganPts) do
                if key ~= obj._startPointId then
                    table.insert(beginPts,obj._preMovePts[key])
                    table.insert(movePts,obj._preMovePts[key])
                    break
                end
            end
        end
        obj:onInnerMultiTouch(beginPts,movePts)
    end
    for key,pos in pairs(obj._movePts ) do
        obj._preMovePts[key] = pos
    end
end
function __view.onInnerMoved(obj,beganPt,movePt)
    local offsetx = movePt.x - beganPt.x
    local offsety = movePt.y - beganPt.y
    local scale = obj._innerObj:getScale()
    local point = obj:getValidMovePoint(offsetx,offsety,scale)
    obj._innerObj:setPosition(point)
end
function __view.onInnerMultiTouch(obj,beganPts,movePts)
    local beginMid = ccpMidpoint(beganPts[1],beganPts[2])
    local moveMid = ccpMidpoint(movePts[1],movePts[2])
    local prescale = obj._innerObj:getScale()
    local curscale = math.max(prescale * ccpDistance(movePts[1],movePts[2])/ccpDistance(beganPts[1],beganPts[2]),obj:getExtramMinScale())
    obj._innerObj:setScale(curscale)
    obj._scaleCenter = moveMid
    if prescale ~= curscale then
         local contentsize = obj._innerObj:getContentSize()
         local midInNode = obj._innerObj:convertToNodeSpace(moveMid)
         local anchor = obj._innerObj:getAnchorPoint()
         local deltaX = (midInNode.x - anchor.x * contentsize.width)* (curscale - prescale)
         local deltaY = (midInNode.y - anchor.y * contentsize.height)*(curscale - prescale)
         local point = obj:getValidMovePoint(-deltaX,-deltaY,curscale)
         obj._innerObj:setPosition(point)
      end
      if not beginMid:equals(moveMid) then
          obj:onInnerMoved(beginMid,moveMid)
      end
end
--���Ź�����
function __view.setPosFocused(obj,scale,innerX,innerY,focusX,focusY,focusObj)
	local prescale = obj._innerObj:getScale()
	local curscale = math.min(math.max(scale,obj._minScale),obj._maxScale)
	obj._innerObj:setScale(scale)
	if prescale ~= curscale then
         local contentsize = obj._innerObj:getContentSize()
         local midInNode = obj._innerObj:convertToNodeSpace(ccp(focusX,focusY))
         local anchor = obj._innerObj:getAnchorPoint()
         local deltaX = (midInNode.x - anchor.x * contentsize.width)* (curscale - prescale)
         local deltaY = (midInNode.y - anchor.y * contentsize.height)*(curscale - prescale)
         local point = obj:getValidMovePoint(-deltaX,-deltaY,curscale)
         obj._innerObj:setPosition(point)
    end
    local prePosX = obj._innerObj:getPositionX()
	local prePosY = obj._innerObj:getPositionY()
	local pos = focusObj:convertToNodeSpace(ccp(focusX,focusY))
	local offsetx = pos.x - innerX
	local offsety = pos.y - innerY
	local newpos = obj:getValidMovePoint(offsetx,offsety,curscale)
    obj._innerObj:setPosition(newpos)
end
function __view.getValidMovePoint(obj,offsetx,offsety,scale)
	if not scale then scale = obj._innerObj:getScale() end
    local x = obj._innerObj:getPositionX() + offsetx
    local y = obj._innerObj:getPositionY() + offsety
    local anchor = obj._innerObj:getAnchorPoint()
    local size = obj._innerObj:getContentSize()
    local left = x - anchor.x * size.width * scale
    local right =  x + size.width * scale *(1-anchor.x)
    local bottom = y - anchor.y * size.height* scale
    local top = y + size.height* scale *(1- anchor.y)
    local outerSize = obj._egObj:getContentSize()
    if left > 0 then  x = anchor.x * size.width * scale end
    if right < outerSize.width then x = outerSize.width - size.width * scale *(1-anchor.x) end
    if bottom >0 then y = anchor.y * size.height* scale end
    if top < outerSize.height then y = outerSize.height - size.height* scale *(1- anchor.y) end
    return ccp(x,y)
end
function __view.onInnerTouchEnd(obj,touches)
    local startPoint = obj._beganPts[obj._startPointId]
    local endPoint = nil
    for i = 1,#touches,3 do
        local id = touches[i+2]
        if obj._startPointId == id then 
            obj._startPointId = nil 
            endPoint = ccp(touches[i],touches[i+1])
        end
        obj._beganPts[id] = nil
        obj._preMovePts[id] = nil
    end
    if not obj._startPointId then
        for key,pos in pairs(obj._beganPts) do
            obj._startPointId = key
            break
        end
        if not obj._startPointId then
            obj._pressed = false
            obj._targetScale = 0
            local scale = math.modf(obj._innerObj:getScale() * 100)/100
            if scale < math.modf(obj._minScale*100)/100 then 
                    obj._targetScale = obj._minScale 
                    obj._scaleOverRange = true
                    if obj._scaleTime == 0 then obj._scaleTime  = obj._slideTime end
            elseif scale > math.modf(obj._maxScale*100)/100  then 
                    obj._targetScale = obj._maxScale 
                    obj._scaleOverRange = true
                     if obj._scaleTime == 0 then obj._scaleTime  = obj._slideTime end
            else
                obj._scaleOverRange = false
            end
           if  obj._scaleOverRange then
                if not obj._scaleCenter then obj._scaleCenter = endPoint end
                obj:startAutoScale()
           else
                if startPoint and endPoint then
                    obj:startAutoScroll(startPoint,endPoint,obj._slideTime)
                else
                    obj:stopAutoScroll()
                end
           end
        end
    end
end
function __view.setMinScale(obj,scale)
    local extraScale = obj:getExtramMinScale()
    if scale < extraScale then scale = extraScale end
    
    local curScale = obj._innerObj:getScale()
    if curScale < scale then obj._innerObj:setScale(scale) end
    if obj._maxScale < scale then obj._maxScale = scale end
    obj._minScale = scale
end
function __view.setMaxScale(obj,scale)
    local extraScale = obj:getExtramMinScale()
    if scale < extraScale then scale = extraScale end
    local curScale = obj._innerObj:getScale()
    if curScale > scale then obj._innerObj:setScale(scale) end
    if obj._minScale > scale then obj._minScale = scale end
    obj._maxScale = scale
end
function __view.onInnerTouchCancelled(obj,touches)
    obj._pressed = false
    obj._beganPts = {}
    obj._movePts = {}
    obj._preMovePts = {}
    obj._startPointId = nil 
    obj._m_distance = 0
    obj._m_dir = ccp(0,0)
end
function __view.getMoveDir(obj,startPt,endPt)
    local offsetx = endPt.x - startPt.x
    local offsety = endPt.y - startPt.y
    local dir = ccpNormalize(ccp(offsetx,offsety))
    return dir
end
function __view.setSize(obj,size)
     obj._egObj:setContentSize(size)
    local innerSize = obj._innerObj:getContentSize()
    local resizeInner = false
    if innerSize.width < size.width then 
        innerSize.width = size.width  
        resizeInner =  true 
    end
    if innerSize.height < size.height then 
        innerSize.height = size.height 
        resizeInner =  true  
    end
    if resizeInner then --scrollview �ߴ�����ڲ������ߴ�
        print("Force increase inner  to match scrollview size")
        obj._innerObj:setContentSize(CCSizeMake(innerSize.width,innerSize.height))
    end
end
--�����ڲ������ߴ�,ScrollView�ߴ���������õĳߴ�ʱ��ǿ����С
function __view.setInnerSize(obj,size)
    obj._innerObj:setContentSize(size)
    local outerSize = obj._egObj:getContentSize()
    local resizeScrollview = false
    if outerSize.width > size.width then 
        outerSize.width = size.width 
        resizeScrollview = true
    end
    if outerSize.height > size.height then 
        outerSize.height = size.height 
        resizeScrollview = true
    end
    if resizeScrollview then
        print("Force decrease scrollview to match inner size")
        obj._egObj:setContentSize(CCSizeMake(outerSize.width,outerSize.height))
    end
end
function __view.startAutoScroll(obj,oldpoint,newpoint,duration)
    obj._m_distance = ccpDistance(newpoint,oldpoint) --�����ƶ�����
    obj._m_dir = obj:getMoveDir(oldpoint,newpoint) --�����ƶ�����
    obj._originalSpeed  = math.min(obj._m_distance/duration,kMaxScrollSpeed)--�����ƶ��ٶ�
    obj._autoScroll = true
    obj._autoScrolledTime = 0
    obj._slideTime = 0
end
function __view.stopAutoScroll(obj)
    obj._autoScroll = false
    obj._autoScrolledTime = 0
    obj._slideTime = 0
    obj._originalSpeed = 0
    obj._m_dir = ccp(0,0)
    obj._m_distance = 0
end
function __view.doAutoScroll(obj,dt)
    local curSpeed = obj._originalSpeed  + kAcceleration * obj._autoScrolledTime
    if curSpeed > 0 then
        local timeParam = obj._autoScrolledTime * 2 + dt
        local offset = (obj._originalSpeed + kAcceleration * timeParam * 0.5) * dt
        local offsetx = offset * obj._m_dir.x
        local offsety = offset * obj._m_dir.y
        local point = obj:getValidMovePoint(offsetx,offsety,obj._innerObj:getScale())
        obj._innerObj:setPosition(point)
        obj._autoScrolledTime = obj._autoScrolledTime + dt
    else
        obj:stopAutoScroll()
    end
end
function __view.startAutoScale(obj)
    local scale = obj._innerObj:getScale()
    local duration = math.min(obj._scaleTime,kMaxScaleTime)
    obj._scaleRate =(obj._targetScale - scale)/duration
    obj._autoScale = true
    obj._scaleTime = 0
end
function __view.stopAutoScale(obj)
    obj._autoScale = false
    obj._scaleRate = 0
    obj._targetScale = 0
    obj._scaleTime = 0
    obj._scaleOverRange = false
    obj._scaleCenter = nil
end
function __view.doAutoScale(obj,dt)
    local preScale = obj._innerObj:getScale()
    local needStop = false
    obj._scaleRate =  obj._scaleRate  + obj._scaleRate * dt
    local curScale = preScale + obj._scaleRate*dt
    if obj._targetScale == obj._minScale then
        if curScale >= obj._targetScale then 
            curScale = obj._targetScale 
            needStop = true
        end
    elseif obj._targetScale == obj._maxScale then
        if curScale <= obj._targetScale then 
            curScale = obj._targetScale 
            needStop = true
        end
    elseif obj._scaleRate > 0 and curScale >= obj._targetScale then 
            curScale = obj._targetScale 
            needStop = true
    elseif obj._scaleRate<0 and curScale <= obj._targetScale then
        curScale = obj._targetScale 
        needStop = true
    end
    obj._innerObj:setScale(curScale)
    local contentsize = obj._innerObj:getContentSize()
    local anchor = obj._innerObj:getAnchorPoint()
    local midInNode = obj._innerObj:convertToNodeSpace(obj._scaleCenter)
    local deltaX = (midInNode.x - anchor.x * contentsize.width)* (curScale - preScale)
    local deltaY = (midInNode.y- anchor.y * contentsize.height)*(curScale - preScale)
    local point = obj:getValidMovePoint(-deltaX,-deltaY,curScale)
    obj._innerObj:setPosition(point)
    if needStop then obj:stopAutoScale() end
    
end
function __view.doScaleToDes(obj,duration,targetScale,x,y)
	obj:stopAutoScale()
	obj._scaleTime = duration
	obj._targetScale = targetScale
	obj._scaleCenter = ccp(x,y)
	obj:startAutoScale()
end
function __view.startScrollToDes(obj,duration,offsetx,offsety)
    obj._hasDes = true
    obj._offsetX = offsetx
    obj._offsetY = offsety
    obj._des_dir = ccpNormalize(ccp(obj._offsetX,obj._offsetY))
    obj._movedX = 0
    obj._movedY = 0
    obj._usedTime = 0
	--
	obj._m_distance = ccpDistance(ccp(0,0),ccp(offsetx,offsety)) --�����ƶ�����
    obj._des_speed  = 2*obj._m_distance/math.pow(duration,2)--�����ƶ����ٶ�
	--
    --obj._des_speed = math.max(math.abs(ccpLength(ccp(obj._offsetX,obj._offsetY)))*2,kMaxScrollSpeed)
    obj._innerObj:setTouchEnabled(false)
end
function __view.stopScrollToDes(obj)
    obj._hasDes = false
    obj._des_dir = ccp(0,0)
    obj._offsetX = 0
    obj._offsetY = 0
    obj._movedX = 0
    obj._movedY = 0
    obj._usedTime = 0
    obj._des_speed = 0
    obj._innerObj:setTouchEnabled(true)
    if obj._arriveDesCallback then 
        obj._arriveDesCallback() 
        obj._arriveDesCallback = nil 
    end
end
function __view.doScrollToDes(obj,dt)
    if obj._frameid < 1 then dt = 0.016 end
	obj._frameid = obj._frameid+1
    --print(curSpeed)
     obj._usedTime = obj._usedTime + dt
    local offset = obj._des_speed * math.pow(obj._usedTime,2)/2

    local offsetx = offset * obj._des_dir.x
    local offsety = offset * obj._des_dir.y
    local tmpx = obj._movedX + offsetx
    local tmpy = obj._movedY + offsety
   
    if math.abs(tmpx) >= math.abs(obj._offsetX) then 
        tmpx = obj._offsetX
        offsetx = obj._offsetX - obj._movedX
    end
    if math.abs(tmpy) >= math.abs(obj._offsetY) then
        tmpy = obj._offsetY
        offsety = obj._offsetY - obj._movedY
    end
    obj._movedX = tmpx
    obj._movedY = tmpy
    
    local point = obj:getValidMovePoint(offsetx,offsety,obj._egObj:getScale())
    local actOffsetX = point.x - obj._egObj:getPositionX()
    local actOffsetY = point.y - obj._egObj:getPositionY()
    obj._innerObj:setPosition(point)
    if obj._moveCallBack then obj._moveCallBack(actOffsetX,actOffsetY) end
    if actOffsetX == 0 and actOffsetY==0 then obj:stopScrollToDes() end
    if math.abs(obj._movedX) >= math.abs(obj._offsetX) and math.abs(obj._movedY) >= math.abs(obj._offsetY) then
        obj:stopScrollToDes()
    end
end
function __view.moveInnerBy(obj,s,offsetx,offsety,scrollEnd)
    obj:stopAutoScroll()
    obj:stopScrollToDes()
    obj._arriveDesCallback = scrollEnd
    obj:startScrollToDes(s,offsetx,offsety)
end
--�ڹ�������������
function __view.addChild(obj,child,zorder,tag)
    if zorder == nil then
        obj._innerObj:addChild(child)
    elseif tag == nil then
        obj._innerObj:addChild(child,zorder)
    else
        obj._innerObj:addChild(child,zorder,tag)
    end
end
function __view.removeChild(obj,child)
    obj._innerObj:removeChild(child,true)
end
function __view.getInnerContainer(obj)
    return obj._innerObj
end
--���ô�������
function __view.setTouchable(obj,enabled)
    obj._innerObj:setTouchEnabled(enabled)
end

--���ù���������
function __view.moveInnerTo(obj,x,y)
    obj._innerObj:setPosition(ccp(x,y))
end
LuaZoomView={}
function LuaZoomView.new() 
    local obj = {}
    Layer.install(obj)
    --LayerColor.install(obj,ccc4(255,128,128,128))
    for name,func in pairs(__view) do
        obj[name] = func
    end
    obj:init()
    return obj
end
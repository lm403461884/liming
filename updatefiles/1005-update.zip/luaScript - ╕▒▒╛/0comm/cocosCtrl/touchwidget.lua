
TouchWidget=class("TouchWidget" )
TouchWidget.__index = TouchWidget
function TouchWidget.extend(target)
    local t = {}
    tolua.setpeer(target, t)
    setmetatable(t, TouchWidget)
    return target
end
function TouchWidget.new(jsonFile)
	local touchgroup = TouchWidget.extend(TouchGroup:create())
	touchgroup._egObj =touchgroup
	touchgroup._widget = GUIReader:shareReader():widgetFromJsonFile(jsonFile)
    touchgroup:addWidget( touchgroup._widget)
    CocosNode.install(touchgroup)
    TouchDelegate.install(touchgroup)
    WNode.install(touchgroup)
	BaseProp.install(touchgroup)
    InnerProp.install(touchgroup)
	return touchgroup
end
function TouchWidget:className()
	return self.__cname
end
function TouchWidget:egGetWidgetByName(widgetName)
    if not widgetName then 
        return self._widget 
    end
    return self:getWidgetByName(widgetName)
end
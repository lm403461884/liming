--! interfaces to operate sprite obj

local __sprite = {}

function __sprite.egSetColor(obj, r, g, b)
	r = r or 255
	g = g or 255
	b = b or 255
	obj._egObj:setColor(ccc3(r, g, b))
end
function __sprite.egSetColor1(obj, color)
	obj._egObj:setColor(color)
end
function __sprite.egSetAlpha(obj, byte)
	obj._egObj:setOpacity(byte)
end
function __sprite.egChangeFrame(obj, frameName)--{{{
	local frame = graphicLoader.getFrame(frameName)
	obj._egObj:setDisplayFrame(frame)
	obj.width = obj._egObj:getContentSize().width
	obj.height = obj._egObj:getContentSize().height
end--}}}

function __sprite.egPlayAnimaEx(obj, act, dir, times, rate)--{{{
	local prefix = obj:getprop('graphName')
	local name = graphicLoader.animaName(prefix, act, dir)
	if obj._lastAnimaName ~= name and obj._egObj then
		obj:egStopAnima()
		local anima = graphicLoader.getAnimation(name)
		local delay = graphicLoader.animaDelay(prefix, act)
		--anima:setRestoreOriginalFrame(true)
		anima:setDelayPerUnit((1 / (rate or 1)) * delay)
		local animate = CCAnimate:create(anima)
		obj._egAnima = CCRepeat:create(animate, times or 1000000)
		obj._egObj:runAction(obj._egAnima)
		obj._lastAnimaName = name
	end
end--}}}

function __sprite.egGetAnimaDurEx(obj, act, dir)--{{{
	return graphicLoader.animaDurMS(obj:getprop('graphName'), act)
end--}}}

function __sprite.egSprite(obj)--{{{
	return obj._egObj
end--}}}

function __sprite.egPlaySound(obj,soundName)--{{{
	if SoundList.battle_uint_effect[obj:getprop('graphName')] then
		local sound_path = SoundList.battle_uint_effect[obj:getprop('graphName')][soundName]
		if sound_path then
			if not SoundList.battle_uint_effect[obj:getprop('graphName')] then
				--print(obj:getprop('graphName').." is not cunzai")
			elseif not SoundList.battle_uint_effect[obj:getprop('graphName')][soundName] then
				--print(obj:getprop('graphName').." "..soundName.." is not cunzai")
			else
				--print(sound_path)
				SoundHelper.playEffect(sound_path)
			end

		end
	end
end--}}}

sprite = {}

function sprite.install(obj,pic,isframe)
    if pic then
        if isframe then
            obj._egObj = CCSprite:createWithSpriteFrameName(pic)
        else
	        obj._egObj = CCSprite:create(pic)
	    end
	else
		--obj._egObj = whiteSprite:create()
	    obj._egObj = linearColorSprite:create()
	end
    CocosNode.install(obj)
	for name, func in pairs(__sprite) do
		obj[name] = func
	end
end

SSHelper = {}
function SSHelper:init(recvBson)
	local acctList = recvBson.acctList or {}
	self._areainfo = recvBson.segList or {}
	self._hosts = recvBson.host or {}
	self._publishInfo = recvBson.notice or {}
	for key,val in pairs(acctList) do
		local lv = val%65536
		local regser = math.floor(val/65536)
		if self._areainfo[regser] then
			self._areainfo[regser].digLv = lv
			self._areainfo[regser].guid = key
		end
	end
end
function SSHelper:getGSParam()
	return self._hosts.ip,self._hosts.port
end
--获取公告板显示消息
function SSHelper:getBeforeLoginInfo()
	local tb = {}
	if self._publishInfo then
		for key,val in pairs(self._publishInfo) do
			if val.displayPos == "beforeLogin" and val.timeBegin <= os.time() and val.timeEnd > os.time() then
				val.infoId = key
				table.insert(tb,val)
			end
		end
		table.sort(tb,function(a,b) return a.timeBegin > b.timeBegin end)
	end
	return tb
end
function SSHelper:isShowable(serList,serid)
	for key,val in ipairs(serList) do
		if val == serid then return true end
	end
	return false
end
--获取在线公告信息
function SSHelper:initAfterLoginInfo()
	FloatNode.clearFlatMsg(6)
	if self._publishInfo then
		local sid = SDKHelper:getSID()
		for key,item in pairs(self._publishInfo) do
			self:addAfterLoginInfo(item,sid)
		end
	end
end
function SSHelper:addAfterLoginInfo(item,sid)
	if not sid then sid = SDKHelper:getSID() end
	if item.displayPos == "afterLogin" and item.timeEnd >= os.time() then
		if self:isShowable(item.srvID,sid) then
			local loopCnt = 1
			if item.timeIntv > 0 then --需要循环显示的公告
				item.timeBegin = item.timeIntv-(os.time()-item.timeBegin)%item.timeIntv + os.time()
				loopCnt = math.max(math.floor((item.timeEnd - item.timeBegin)/item.timeIntv),1)
			else
				item.timeBegin = os.time()
			end
			if item.timeEnd > item.timeBegin then
				FloatNode.addFlatMsg(6,item.content,loopCnt,item.timeBegin,item.timeIntv)
			end
		end
	end
end
function SSHelper:getLastLogServer()
	if self._areainfo then
		local puid = SDKHelper:getHOUID()
		local sid = DBHelper.getLastLogServer(puid)
		if sid then
			if self._areainfo and self._areainfo[sid]then
				return self._areainfo[sid]
			end
		end
	end
	return nil
end
function SSHelper:getAreaInfo()
	return self._areainfo
end

SocketHelper={}
function SocketHelper.isNetConnected()
	return HOAux:isNetConnected()
end
function SocketHelper.isWifiConnected()
	return HOAux:isWifiConnected()
end
--����Socket����
function SocketHelper.createDSSocket()
    local timeout = 20000 
	local host = DSConfig.host
	local port =  DSConfig.port[math.random(#DSConfig.port)]
	local socket,rtn =  AsyncSocket:create(host,port,timeout)
	if not rtn then
		socket:destory()
		socket = nil
	end
	return socket
end
function SocketHelper.createGSSocket()
	local timeout = 20000 
	local host,port = SSHelper:getGSParam()
	local socket,rtn =  AsyncSocket:create(host,port,timeout)
	if not rtn then
		socket:destory()
		socket = nil
	end
	return socket
end
function SocketHelper.setGSParam(gsConfig)
	SocketHelper._gsConfig = gsConfig
end
function SocketHelper.setGSConn(sockfd)
	if SocketHelper._gshandler then AsyncSocket:closeSocket(SocketHelper._gshandler) end
	RecvQueue:bindSocket(sockfd) 
	SocketHelper._gshandler = sockfd
end
function SocketHelper.setDSConn(sockfd)
	if SocketHelper._dshandler then 
		AsyncSocket:closeSocket(SocketHelper._dshandler) 
	end
	RecvQueue:bindSocket(sockfd) 
	SocketHelper._dshandler = sockfd
end
function SocketHelper.isDSConnecting()
	if SocketHelper._dshandler then 
		return true
	else 
		return false 
	end
end
function SocketHelper.clearDSConn()
	RecvQueue:unbindSocket()
	SocketHelper._dshandler = nil
end
function SocketHelper.clearGSConn()
	RecvQueue:unbindSocket()
	SocketHelper._gshandler = nil
end
function SocketHelper.getGSConn()
	return SocketHelper._gshandler
end
function SocketHelper.getDSConn()
	return SocketHelper._dshandler
end


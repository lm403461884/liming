--key发生器生成器
local function randfunc(seed)
	local mul = assert(seed)
	return function(l, h)
		l = l or 0
		h = h or 0x7fffffff
		mul = mul * 0xefff % 0x7fffffff
		return l + mul % (h-l+1)
	end
end
--定义包体类型
local datatype = {
	string = 1,
	bson = 2,
	binary = 3,
}

local function getTableFromPaser()
    local strVal,_ = StreamPaser:readStr()
    local chunck, err1 = loadstring(strVal)
    if not chunck then print(err1) return nil end
    local succ, err2 = pcall(chunck)
    if not succ then print(err2) return nil end
    return err2
end

local function getZipTableFromMsg(blen)
	local srcBytes = StreamPaser:readUserData(blen)
    local zipIns,desBytes,deslen =HOGZip:decompress(srcBytes,blen)
	if deslen then
		if deslen > 0 then
			StreamPaser:initData(desBytes,deslen)
			zipIns:destory()
			getTableFromPaser()
		else
			--待解压数据有问题
			zipIns:destory()
			SocketHelper.clearGSConn()
			SceneManager:show(LogoScene)
		end
	else
		--创建解压对象失败
		SocketHelper.clearGSConn()
		SceneManager:show(LogoScene)
	end
end
local function getZipBsonFromMsg(blen)
	local srcBytes = StreamPaser:readUserData(blen)
    local zipIns,desBytes,deslen =HOGZip:decompress(srcBytes,blen)
	if deslen then
		if deslen > 0 then
			StreamPaser:initData(desBytes,deslen)
			local tb = HOAux:bson2table(desBytes)
			zipIns:destory()
			return tb
		else
			--待解压数据有问题
			zipIns:destory()
			SocketHelper.clearGSConn()
			SceneManager:show(LogoScene)
		end
	else
		--创建解压对象失败
		SocketHelper.clearGSConn()
		SceneManager:show(LogoScene)
	end
end
local function protocol2table(dtype,bComp,blen)
	if dtype == datatype.string then
		if bComp == 1 then 
			return getZipTableFromMsg(blen)
		else 
			return getTableFromPaser()
		end
	elseif dtype == datatype.bson then
		if bComp == 1 then
			return getZipBsonFromMsg(blen)
		else
			local buf = StreamPaser:readUserData(blen)
			return HOAux:bson2table(buf)
		end
	end
end

local _socketParser = {}

function RecvMsg()
	if RecvQueue:hasMsg() then
		local msgHeader,msgLen = RecvQueue:getMsg()
		StreamPaser:initData(msgHeader,msgLen)
		RecvQueue:pop_front()
		local msglen = StreamPaser:readInt()
		if msglen >= 8 then --数据有效
			local msgcode = StreamPaser:readInt()
			print('recv msg',msglen,msgcode)
			if _socketParser[msgcode] then --已定义数据
				_socketParser[msgcode](msglen)
			else
				print("ignore unknown msgcode "..msgcode)
			end
		else
			print("ignore invalid msg ")
		end
	end
end
_socketParser[891001] = function(msglen)
	SocketHelper.clearDSConn()
	local opstate = StreamPaser:readInt()
	if opstate == 0 then
		local bson_len_1 = StreamPaser:readInt()
		StreamPaser:movePtrBy(-4)
		local buf = StreamPaser:readUserData(bson_len_1)
		local recvBson = HOAux:bson2table(buf)
		SSHelper:init(recvBson)
		PlugInHelper:triggerEvent(CLTEvent.CServerDownloaded,"")
	elseif opstate == 1 then
		local latestVer = StreamPaser:readInt()
		PlugInHelper:triggerEvent(CLTEvent.CVerNotMatch,latestVer)
	elseif opstate == 2 then
		PlugInHelper:triggerEvent(CLTEvent.CDSFingerError,"")
	end
end
_socketParser[390000] = function(msglen)
	FloatNode.wakeUp()
end
--==========================
--391001 帐号数据
--==========================
--acct：帐号数据
--==========================
_socketParser[391001] =function(msglen)
	guid = StreamPaser:readInt()
	local opstate,onlinedt,dtype,bComp = StreamPaser:read(4)
	local acct = protocol2table(dtype,bComp,msglen-28)
	if not acct then return end
	AcctManager:init(acct,onlinedt) --初始化客户端帐号数据
	g_keygen = randfunc(acct.lastOffline)
	TDHelper.setAccountInfo(SDKHelper:getAccountInfo())
	PrivateMsgManager:init() --加载私聊记录
	PubMsgManager:init() --公聊记录
	SSHelper:initAfterLoginInfo() --公告消息
	SendMsg[931021](DBHelper.getCMScriptVer())
	SendMsg[931003]() --获取录像摘要数据

	if acct.cid then
		SendMsg[938002]() --获取公会数据
	else
		PlugInHelper:triggerEvent(CLTEvent.CClubDownLoad,"") --通知公会数据接收完毕
		PlugInHelper:triggerEvent(CLTEvent.CClubWarDownLoad,"") --通知公会战数据接收完毕
	end
end

--==========================
 --391002 登陆失败
 --==========================
_socketParser[391002] = function(msglen)
	local lguid,opstate = StreamPaser:read(2)
	SocketHelper.clearGSConn()
	PlugInHelper:triggerEvent(CLTEvent.CGSLoginError,opstate)
end

--==========================
 --391003 录像信息列表
 --==========================
 --recordStr:录像列表字符串
 --[[sumary={}
	sumary.time = os.time()
	sumary.atk_gold = m_gold
	sumary.atk_oil = m_oil
	sumary.atk_elo = m_elo
	sumary.atkName = m_user
	sumary.def_gold = f_gold
	sumary.def_oil = f_oil
	sumary.def_elo = f_elo
	sumary.defName = f_user
	sumary.stars = stars
	sumary.hero = hero
	--]]
 --==========================
local function __getbattleheader()--{{{
	local cnt = StreamPaser:readInt()
	if cnt == 0 then return end
	local ret = {}
	for idx=1, cnt do
		ret[idx] = {vid=StreamPaser:readInt(), sumzlen=StreamPaser:readInt()}
	end
	return ret
 end--}}}

 local function __getbattlesumary()--{{{
	 local sumary = {
		atk_oil = 0,
		def_oil = 0,
		time = StreamPaser:readInt(),
		atkGuid = StreamPaser:readInt(),
		defGuid = StreamPaser:readInt(),
		atk_gold = StreamPaser:readInt(),
		def_gold = StreamPaser:readInt(),
		atk_iron = StreamPaser:readInt(),
		atk_copper = StreamPaser:readInt(),
		atk_stoneR = StreamPaser:readInt(),
		atk_stoneB = StreamPaser:readInt(),
		atk_stoneD = StreamPaser:readInt(),
		atk_elo = StreamPaser:readInt(),
		def_elo = StreamPaser:readInt(),
		stars = StreamPaser:readInt(),
		atkName = StreamPaser:readStr(),
		defName = StreamPaser:readStr(),
	 }
	 sumary.needRevenged = math.floor(sumary.stars/256)
	 sumary.stars = sumary.stars%256
	 sumary.isDefencer = true
	 sumary.atkName = HOAux:hexstr2str(sumary.atkName)
	 sumary.defName = HOAux:hexstr2str(sumary.defName)
	 local acctguid = AcctManager:getParam("guid")
	 if sumary.atkGuid == acctguid or (sumary.atkGuid ~= acctguid and sumary.defGuid ~=acctguid and club_data and club_data.members[sumary.atkGuid])  then
		sumary.isDefencer = false
	 end
	 --read hero data
	 local hero = {}
	 local team = {}
	 local heroList = {}
	 local equipments = {}
	 for i=1, StreamPaser:readInt() do
		 local ctx = StreamPaser:readInt()
		 local equip = StreamPaser:readInt()
		 local sub1 = StreamPaser:readInt()
		 local sub2 = StreamPaser:readInt()
		 local id = math.floor(ctx / 100) % 100
		 local grade = math.floor(ctx / 10000) % 100
		 local lv = math.floor(ctx / 1000000)
		 local eid = ctx % 10000
		 hero[id] = lv
		 table.insert(team, id)
		 heroList[id] = {type=id,lv=lv,eid=eid,grade=grade,eid_s1=sub1,eid_s2=sub2}
		 local elv = equip % 256
		 local eqa = math.floor(equip / 256)
		 equipments[eid] = {elv, eqa}
	 end
	 sumary.hero = hero
	 sumary.team = team
	 sumary.heroList = heroList
	 sumary.equipments = equipments
	 return sumary
 end--}}}

 local function __getbattledetail()--{{{
	 --get attacker data
	 local atk = {
		stars = StreamPaser:readInt(),
		consume = StreamPaser:readInt(),
		startTime = StreamPaser:readInt(),
		endTime = StreamPaser:readInt(),
		frameCnt = StreamPaser:readInt(),
		heroEnterFrame = {},
		heroCreatedFrame = {},
		skillUsageFrame = {},
	 }

	 for i=1, StreamPaser:readInt() do
		 table.insert(atk.heroEnterFrame, StreamPaser:readInt())
	 end

	 for i=1, StreamPaser:readInt() do
		 table.insert(atk.heroCreatedFrame, StreamPaser:readInt())
	 end

	 for i=1, StreamPaser:readInt() do
		 local hid,cnt = StreamPaser:read(2)
		 atk.skillUsageFrame[hid] = {}
		 for p=1, cnt do
			 table.insert(atk.skillUsageFrame[hid], StreamPaser:readInt())
		 end
	 end

	 --get defencer data
		--skip useless data
	 StreamPaser:read(5)
	 local collectorList = {}
	 local monsterLvLook = {}
	 local creatureList = {}
	 local digTrace = {}
	 local mileSpread = {}
	 local def = {
		 sceneID = StreamPaser:readInt(),
		 sceneLv = StreamPaser:readInt(),
		 collectorList = collectorList,
		 monsterLvLook = monsterLvLook,
		 creatureList = creatureList,
		 digTrace = digTrace,
		 mileSpread = mileSpread
	 }
	 --read collector list and mile spread
	 for idx=1, StreamPaser:readInt() do
		 local coll = {
			 lv = StreamPaser:readInt(),
			 st = StreamPaser:readInt(),
			 elapsed = StreamPaser:readInt(),
			 pos = StreamPaser:readInt(),
			 coin = StreamPaser:readInt(),
			 mileLv = StreamPaser:readInt(),
			 mileCnt = StreamPaser:readInt()
		 }
		 table.insert(collectorList, coll)
		 if coll.coin ~= 0 then
			 mileSpread[coll.pos] = {type=coll.coin, lv=coll.mileLv, cnt=coll.mileCnt}
		 end
	 end
	 --read monster level look
	 for idx=1, StreamPaser:readInt() do
		 local mid = StreamPaser:readInt()
		 local mlv = StreamPaser:readInt()
		 monsterLvLook[mid] = mlv
	 end
	 --read creature list
	 for idx=1, StreamPaser:readInt() do
		 local combineddata = StreamPaser:readInt()
		 local pos = math.floor(combineddata / 10000)
		 local mid = combineddata % 10000
		 creatureList[pos] = mid
	 end
	 --read dig trace
	 for idx=1, StreamPaser:readInt() do
		 local combinedpos = StreamPaser:readInt()
		 local pos1 = math.floor(combinedpos / 10000)
		 local pos2 = combinedpos % 10000
		 if pos1 > 0 then
			 digTrace[pos1] = 1
		 end
		 if pos2 > 0 then
			 digTrace[pos2] = 1
		 end
	 end
	 return atk, def
 end--}}}

_socketParser[391003] = function(msglen)
	local lguid,opstate = StreamPaser:read(2)
	local ret = __getbattleheader()
	local readLen = StreamPaser:getPtrPos()
	if ret then
		for _, hdr in ipairs(ret) do
			local sumary = __getbattlesumary()
			readLen = readLen + hdr.sumzlen
			StreamPaser:movePtrTo(readLen)
			sumary.vid = hdr.vid
			videomanager.addsumary(sumary)
		end
	end
	AcctManager:setParam("battleSumaries",videomanager.getsumaries())
    AccountHelper:unlock(kStateVideoList)
end

--==========================
 --391004 录像信息明细
 --==========================
 --atk: 进攻方数据
 --dfs: 防守方数据
 --==========================
_socketParser[391004] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	if opstate == -1 then
	else
		local vid = StreamPaser:readInt()
		local sl = StreamPaser:readInt()
		local dl = StreamPaser:readInt()
		local readLen = StreamPaser:getPtrPos()
		local sumary = __getbattlesumary()
		readLen = readLen + sl
		StreamPaser:movePtrTo(readLen)
		local atk, def = __getbattledetail()
		readLen = readLen + dl
		StreamPaser:movePtrTo(readLen)
		atk.team = sumary.team
		atk.heroList = sumary.heroList
		atk.equipments = sumary.equipments
		videomanager.addvideo(vid, {bpresult=sumary, atk=atk, def=def})
	end
    AccountHelper:unlock(kStateVideo)
end

--==========================
 --391006 ELO排名信息
 --==========================
_socketParser[391006] = function(msglen)
	local lguid,opstate,bodylen = StreamPaser:read(3)
	if bodylen > 0 then
	    local selfIdx,totalPage,curPage,startIdx,endIdx = StreamPaser:read(5)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(2,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.guid,tb.digLv,tb.elo = StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			ELORankHelper:addRankData(totalPage,curPage,tb)
		end
		ELORankHelper:finishDownLoad(true)
	else
		ELORankHelper:finishDownLoad()
	end
end
--==========================
 --391007 登陆错误
--1.	正在被攻打
--2.	重复登录
--3.	指纹校验错误
--4.	登录校验错误
--5.	regSeg非法
--6.	帐号已封停
 --==========================
_socketParser[391007] = function(msglen)
	SocketHelper.clearGSConn()
	local lguid,opstate,flag =  StreamPaser:read(3)
	if flag == 1 then
		PlugInHelper:triggerEvent(CLTEvent.CBeenAttack,flag)
	elseif flag == 2 then
		PlugInHelper:triggerEvent(CLTEvent.CReLogin,flag)
	elseif flag == 6 then
		PlugInHelper:triggerEvent(CLTEvent.CForbidLogin,flag)
	else
		PlugInHelper:triggerEvent(CLTEvent.CGSLoginError,flag)
	end
end

--==========================
 --391008 公共聊天信息
 --==========================
_socketParser[391008] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local newmsg = {}
	newmsg.guid = StreamPaser:readInt()
	newmsg.digLv = StreamPaser:readInt()
	local userName = StreamPaser:readStr()
    newmsg.name = HOAux:hexstr2str(userName)
	newmsg.clubid = StreamPaser:readInt()
	newmsg.clubname  = StreamPaser:readStr()
    newmsg.content  = StreamPaser:readStr()
	newmsg.date = os.time()
	
	PubMsgManager:addMsg(newmsg)
end
--==========================
 --391009 某GUID对应的帐号摘要数据
 --==========================
_socketParser[391009] = function(msglen)
	local lguid,opstate,dtype =  StreamPaser:read(3)
	if dtype == datatype.binary then
		local userbrief = {}
		userbrief.guid,userbrief.diglv,userbrief.digPt,userbrief.elo,userbrief.teamCnt= StreamPaser:read(5)
		userbrief.heroList = {}
		userbrief.equipments = {}
		if userbrief.teamCnt > 0 then
			for idx=1,userbrief.teamCnt do
	            local tb = {}
		        local heroctx,equipmain,equipsub1,equipsub2 = StreamPaser:read(4)
				tb.eid,tb.type,tb.grade,tb.lv = Funs.deComposeInt(heroctx,100,4)
				tb.eid = tb.type*100 + tb.eid
				userbrief.equipments[tb.eid] = {}
			    userbrief.equipments[tb.eid][1],userbrief.equipments[tb.eid][2] = Funs.deComposeInt(equipmain,256,2)
				tb.eid_s1 = equipsub1
				tb.eid_s2 = equipsub2
				userbrief.heroList[tb.type] = tb
			end
		end
		userbrief.cid = StreamPaser:readInt()
		userbrief.cbName = StreamPaser:readStr()
		userbrief.nickName = StreamPaser:readStr()
		userbrief.nickName = HOAux:hexstr2str(userbrief.nickName)
		userbrief.cbName = HOAux:hexstr2str(userbrief.cbName)
		userbrief.refreshTime = os.time()--做个时间标记,2分钟内不重新获取
		 UserManager:addUserBrief(userbrief)
	elseif dtype == datatype.bson then

		local ud = StreamPaser:readUserData(msglen-20)
		local raw = HOAux:bson2table(ud)
		local heroList = {}
		local equipments = {}
		local teamCnt = 0
		for _,hero in pairs(raw.heroList) do
			heroList[hero.type] = hero
			equipments[hero.eid] = {hero.equ%256, math.floor(hero.equ/256)}
			teamCnt=teamCnt+1
		end
		raw.diglv = raw.digLv
		raw.digPt = raw.maxDigPt
		raw.teamCnt = teamCnt
		raw.heroList = heroList
		raw.equipments = equipments
		raw.cbName = HOAux:hexstr2str(raw.cbName)
		raw.nickName = HOAux:hexstr2str(raw.nickName)
		raw.refreshTime = os.time()
		 UserManager:addUserBrief(raw)
	end
end
--==========================
 --391014 私聊信息
 --==========================
_socketParser[391014] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local msginfo = {}
	msginfo.recvmsg = 1 			--msgtype 0发送的消息 1接收到的消息
	msginfo.guid = StreamPaser:readInt()
	msginfo.digLv = StreamPaser:readInt()
	local userName = StreamPaser:readStr()
	msginfo.name = HOAux:hexstr2str(userName)
	msginfo.clubid = StreamPaser:readInt()
	msginfo.clubname  = StreamPaser:readStr()
	msginfo.content  = StreamPaser:readStr()
	msginfo.date = os.time()
	PrivateMsgManager:addMsg(msginfo)
end
--==========================
 --391015 英雄战力排行榜单
 --==========================
_socketParser[391015] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local bodylen = StreamPaser:readInt()
	if bodylen > 0 then
		local selfIdx,totalPage,curPage,startIdx,endIdx = StreamPaser:read(5)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(1,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.guid,tb.digLv,tb.teamBp= StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			TeamBpRankHelper:addRankData(totalPage,curPage,tb)
		end

		TeamBpRankHelper:finishDownLoad(true)
	else
		TeamBpRankHelper:finishDownLoad()
	end
end
--==========================
 --391017 PVE成就排行榜单
 --==========================
_socketParser[391017] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local bodylen = StreamPaser:readInt()
	if bodylen > 0 then
		local selfIdx,totalPage,curPage,startIdx,endIdx = StreamPaser:read(5)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(3,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.guid,tb.digLv,tb.stars= StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			PveRankHelper:addRankData(totalPage,curPage,tb)
		end
		PveRankHelper:finishDownLoad(true)
	else
		PveRankHelper:finishDownLoad()
	end
end

 local function loadZipFileFromMsg(filecount,filetype,blen)
	local srcBytes = StreamPaser:readUserData(blen)
    local zipIns,desBytes,deslen =HOGZip:decompress(srcBytes,blen)
	if deslen then --创建解压对象成功
		if deslen > 0 then --解压成功
			StreamPaser:initData(desBytes,deslen)
			zipIns:destory()
			for i = 1,filecount do
				--local flag,_ = StreamPaser:readStr()
				--if tonumber(flag) ~= filetype then
					--return
				--else
					local filename,_ = StreamPaser:readStr()
					local filedata,_ = StreamPaser:readStr()
					local chunck, err = loadstring(filedata,filename)
					if not chunck then print(err) return end
					local succ, err = pcall(chunck)
					if not succ then print(err) return end
					if filetype == 12 then
						DBHelper.saveCMScript(filename,filedata)
					end
				--end
			end
		else
			--待解压数据有问题
			zipIns:destory()
			print("can not decompress data")
		end
	else
		--创建解压对象失败
		print("can not create decompress object")
	end
end
--==========================
 --391021 常变脚本更新
  --fileCount:    脚本文件数量
 --type:        文件类型
 --filename:    文件名称
 --filedata:    文件内容
 --==========================
_socketParser[391021] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local filecount = StreamPaser:readInt()
    if filecount > 0 then
        loadZipFileFromMsg(filecount,12,msglen-20)
		--修改本地数据库中记录的cmVersion脚本版本号
		DBHelper.setCMScriptVer(cmVersion or 1)
	else
		HOEntryHelper.loadCMScript()
    end 
	PlugInHelper:triggerEvent(CLTEvent.CAcctDownLoad,"")--通知帐号数据接收完毕
end
--==========================
 --391022 运营活动奖励邮件信息
 --==========================
 _socketParser[391022] = function(msglen)
	local lguid,opstate,mailid,cfgid =  StreamPaser:read(4)
	AcctManager:setHashParam("activityAwardMails",mailid,cfgid)
 end
 --==========================
 --391023 GM奖励邮件信息
 --==========================
  _socketParser[391023] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local ud = StreamPaser:readUserData(msglen-16)
	local infotb = HOAux:bson2table(ud)
	AcctManager:setHashParam("gmAwardMails",infotb.ID,infotb)
 end
  --==========================
 --391024 公告
 --==========================
  _socketParser[391024] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local ud = StreamPaser:readUserData(msglen-16)
	local infotb = HOAux:bson2table(ud)
	SSHelper:addAfterLoginInfo(infotb)
 end
--==========================
 --392001 地穴资源分布
 --==========================
 --aid:        地形编号
 --sid:        场景ID
 --en:         入口位置
 --cs:         生物资源分布
 --ms:         未暴露的矿脉分布
 --em:         已暴露的矿脉分布
 --==========================
_socketParser[392001] =function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local scenetb = getTableFromPaser()
    AcctManager:initHoleData(scenetb)
    AccountHelper:unlock(kStateNewHole)
end

--读取消息中的帐号数据
local function getTargetHoleData(curTime)
    local target_data = {}
	target_data.guid = StreamPaser:readInt()
    target_data.elo = StreamPaser:readInt()
    target_data.gold = StreamPaser:readInt()
    target_data.oil = StreamPaser:readInt()
    target_data.digLv = StreamPaser:readInt()
    target_data.sceneID = StreamPaser:readInt()
    target_data.sceneLv = StreamPaser:readInt()
    target_data.collectorList = {}
    target_data.mileSpread = {}
	target_data.resVal = {0,0,0,0,0,0,0} --{gold,oil,iron,copper,sR,sB,sD}
	target_data.carRes = {}
    local rescarCnt = StreamPaser:readInt()
    for idx = 1,rescarCnt do
		local lv,st,elapsed,pos,coin,minelv,minecnt = StreamPaser:read(7)
        local tb = {}
        tb.lv = lv
        tb.st = st
        tb.elapsed = curTime-st
        tb.pos = pos
        tb.coin = coin
		table.insert(target_data.collectorList,tb)
		if tb.coin > 0 then
			 local tbmine = {}
			tbmine.type = coin
			tbmine.lv = minelv
			tbmine.cnt = minecnt
			target_data.mileSpread[pos] = tbmine
			local mine_cfg = mile_data.get(tbmine.type, tbmine.lv)
			target_data.resVal[coin] = target_data.resVal[coin] + mine_cfg.gainVal
		else
			table.insert(target_data.carRes,0)
		end

    end
    --monsterLvLook
    local monsterCnt = StreamPaser:readInt()
    target_data.monsterLvLook = {}
    for idx=1,monsterCnt do
		local monsterid,monsterlv = StreamPaser:read(2)
        target_data.monsterLvLook[monsterid] = monsterlv
    end
    --creatureList
    local creatureCnt = StreamPaser:readInt()
    target_data.creatureList = {}
    for idx=1,creatureCnt do
		local combineddata = StreamPaser:readInt()
		local pos = math.floor(combineddata / 10000)
		local id = combineddata % 10000
		target_data.creatureList[pos] = id
    end
    --digTrace
	local blankCnt = StreamPaser:readInt()
    target_data.holeDeep = blankCnt * 2
    target_data.digTrace = {}
    for idx=1,blankCnt do
		local combinedpos = StreamPaser:readInt()
		local pos1 = math.floor(combinedpos / 10000)
		local pos2 = combinedpos % 10000
		if pos1 > 0 then
		    target_data.digTrace[pos1] = 1
		end
		if pos2 > 0 then
			target_data.digTrace[pos2] = 1
		end
    end

	local defName = StreamPaser:readStr()
    target_data.user = HOAux:hexstr2str(defName)
	return target_data
end
--==========================
--395001 PVP匹配对象数据
--==========================
--pvpacct：匹配的帐号信息
--==========================
_socketParser[395001] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local curTime = StreamPaser:readInt()
    local pvpacct = getTargetHoleData(curTime)
	AcctManager:setPvpAcct("pvp",pvpacct) --设置PVP匹配对象数据
end

--==========================
--395005 复仇对象数据
--==========================
--pvpacct：复仇对象帐号信息
--==========================
_socketParser[395005] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local flag = StreamPaser:readInt()
	if flag > 0 then
		local curTime = StreamPaser:readInt()
		local pvpacct = getTargetHoleData(curTime)
		AcctManager:setPvpAcct("revenge",pvpacct) --设置复仇对象帐号数据
	else
		AcctManager:setPvpAcct("revenge",nil) --设置复仇对象帐号数据
	end
end
--==========================
--398001 新建公会回复
--==========================
_socketParser[398001] = function(msglen)
  local lguid,opstate =  StreamPaser:read(2)
  if opstate > 0 then
		club_data = protocol2table(datatype.bson,0,msglen-16)
		club_data.clubName = HOAux:hexstr2str(club_data.clubName)
		club_data.clubDesc = HOAux:hexstr2str(club_data.clubDesc)
		club_data.manager = HOAux:hexstr2str(club_data.manager)
		club_data.members[AcctManager:getParam("guid")].name = AcctManager:getParam("nickName")
		club_data.startRefreshTime  = os.time()
		AcctManager:setParam("cid", club_data.cid)
		AcctManager:setParam("cbName", club_data.clubName)
		GuildMsgManager:init(club_data.cid)
		task.updateTaskStatus(AcctManager:get(),task.client_event_id.enter_guild)
  else
      AccountHelper:unlock(kStateSetupGuild)
  end
end
--==========================
--398003 搜索公会 返回公会摘要
--==========================
--club_search :公会摘要信息表
--==========================
_socketParser[398003] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local bytelen = msglen - 24
    if AccountHelper:isLocked(kStateGuildData) then --更新公会数据
        AccountHelper:unlock(kStateGuildData)
		local dtype = StreamPaser:readInt()
		local bComp = StreamPaser:readInt()
        local tb = protocol2table(dtype,bComp,bytelen)
        club_data.honor = tb.honor
        club_data.rank = tb.rank
        club_data.reward = tb.reward or 0
        club_data.members = tb.members
        club_data.elo = tb.elo
        club_data.coe = tb.coe
        club_data.membersCount= tb.membersCount
		    for uid, mbr in pairs(club_data.members) do
			     mbr.name = HOAux:hexstr2str(mbr.name)
		    end
	elseif AccountHelper:isLocked(kStateToViewGuild) then--查看公会信息
		     if opstate == 0 then
				local dtype = StreamPaser:readInt()
				local bComp = StreamPaser:readInt()
		         club_cid = {}
		         club_cid[-1] = protocol2table(dtype,bComp,bytelen)
		         club_cid[-1].clubName = HOAux:hexstr2str(club_cid[-1].clubName)
			       club_cid[-1].clubDesc = HOAux:hexstr2str(club_cid[-1].clubDesc)
			       club_cid[-1].manager = HOAux:hexstr2str(club_cid[-1].manager)
			       for uid, mbr in pairs(club_cid[-1].members) do
				        mbr.name = HOAux:hexstr2str(mbr.name)
			       end
			   else
			       club_cid = {}
			   end
			   postEventSignal(kEventGetClubView)
			   AccountHelper:unlock(kStateToViewGuild)
    else --搜索公会
        if opstate == 0 then
			local dtype = StreamPaser:readInt()
			local bComp = StreamPaser:readInt()
            club_search = protocol2table(dtype,bComp,bytelen)
			club_search.clubName = HOAux:hexstr2str(club_search.clubName)
			club_search.clubDesc = HOAux:hexstr2str(club_search.clubDesc)
			club_search.manager = HOAux:hexstr2str(club_search.manager)
			for uid, mbr in pairs(club_search.members) do
				mbr.name = HOAux:hexstr2str(mbr.name)
			end
        else
            club_search = nil
            print("search false")
        end
        --AccountHelper:unlock(kStateSearch)
        postEventSignal(kEventClubSearch)
        --if not club_search then print("search false") return end
        --print("club_search:",table_aux.serial(club_search))
   end
end

local function __formatWarData(cd)
	cd.warData.st = os.time()
	cd.defClub = cd.warData.cb_atk
	if cd.cid == cd.defClub.cid then
		cd.defClub = cd.warData.cb_def
	end
	local atk = cd.warData.cb_atk
	local def = cd.warData.cb_def
	atk.clubName = HOAux:hexstr2str(atk.clubName)
	def.clubName = HOAux:hexstr2str(def.clubName)
	for key,items in pairs(atk.targets) do
		items.nickName = HOAux:hexstr2str(items.nickName)
		items.atkerName =  HOAux:hexstr2str(items.atkerName)
	end
	for key,items in pairs(def.targets) do
		items.nickName = HOAux:hexstr2str(items.nickName)
		items.atkerName =  HOAux:hexstr2str(items.atkerName)
	end
end
--==========================
--398002 公会数据
--==========================
--club_data:公会数据
--==========================
_socketParser[398002] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    if opstate == 0 then
		local dtype = StreamPaser:readInt()
		local bComp = StreamPaser:readInt()
		club_data = protocol2table(dtype,bComp,msglen-24)
		--挖掘日志任务进程更新,加入公会
		task.updateTaskStatus(AcctManager:get(),task.client_event_id.enter_guild)
		----------------------------------------------------------
		--字符串字段转码
		club_data.clubName = HOAux:hexstr2str(club_data.clubName)
		club_data.clubDesc = HOAux:hexstr2str(club_data.clubDesc)
		club_data.manager = HOAux:hexstr2str(club_data.manager)
		AcctManager:setParam("cid",club_data.cid)
		AcctManager:setParam("cbName",club_data.clubName)
		if club_data.lastWarResult then
			club_data.lastWarResult.atkName = HOAux:hexstr2str(club_data.lastWarResult.atkName)
			club_data.lastWarResult.defName = HOAux:hexstr2str(club_data.lastWarResult.defName)
		end
		for uid, mbr in pairs(club_data.members) do
			mbr.name = HOAux:hexstr2str(mbr.name)
		end
		club_data.startRefreshTime  = os.time()
		GuildMsgManager:init(club_data.cid) --公会聊天记录初始化
		--整理公会聊天信息
		for mid, msg in pairs(club_data.message) do
			if msg.name then
				msg.name = HOAux:hexstr2str(msg.name)
			end
			if msg.content then
				msg.content = HOAux:hexstr2str(msg.content)
			end
			GuildMsgManager:addMsg(msg)
		end
		GuildMsgManager:sortMsg()
		local scOffsetTime = AcctManager:getOffsetTime()
		--探险队公会消息
		for tid,item in pairs(club_data.teamMsg) do
			if item.content then
				item.content = HOAux:hexstr2str(item.content)
			end
			  local overTime = item.date+scOffsetTime+numDef.cbTeamInterval
			if overTime < os.time() or not club_data.teamMsg[tid] then 
				item.cbTeamDissolved=true 
			else
				if club_data.members[tid] then
					local newmsg = {}
					newmsg.limit =item.limit
					newmsg.date = item.date
					newmsg.content = item.content
					newmsg.type = 4
					newmsg.guid = tid
					newmsg._mid = -tid
					newmsg.cur = item.cur 
					newmsg.digLv =  club_data.members[tid].digLv
					newmsg.name =  club_data.members[tid].name
					GuildMsgManager:addMsg(newmsg)
				end
			end
		end
		
  		--护盾相关
		if club_data.guardSt > 0 then
			club_data.guardSt = club_data.guardSt + scOffsetTime --调整公会护盾失效时间
		end
		--战争倒时计相关
		if club_data.cbwid then
			SendMsg[9311010](club_data.cbwid)
			SendMsg[9311007](club_data.cbwid)
		else
			PlugInHelper:triggerEvent(CLTEvent.CClubWarDownLoad,"") --通知公会战数据接收完毕
			if club_data.lastWarResult then
				if not club_data.lastWarResult.endTime then club_data.lastWarResult.endTime = 0 end
				if club_data.lastWarResult.endTime > AcctManager:getParam("lastOffline") then
				   local joinClubTime = AcctManager:getParam("joinClubTime")
				   if not joinClubTime or club_data.lastWarResult.endTime>joinClubTime then
						 --公会战结束消息提示
						 local tb = {}
						 tb.type = 5
						 tb.data = {type=1,}
						 tb.data.clubName = club_data.clubName
						 tb.data.atkClubName = club_data.lastWarResult.atkName
						 tb.data.defClubName = club_data.lastWarResult.defName
						 tb.data.atkEloDlt = club_data.lastWarResult.atkEloDlt
						 tb.data.defEloDlt = club_data.lastWarResult.defEloDlt
						 AccountHelper:addNewPrompt(tb)
					end
				end
			end
		end
    else
        club_data = nil
		AcctManager:setParam("cid",0)
		AcctManager:setParam("cbName","")
		GuildMsgManager:clearMsg()
        print("no join club")
		PlugInHelper:triggerEvent(CLTEvent.CClubWarDownLoad,"") --通知公会战数据接收完毕
    end
	PlugInHelper:triggerEvent(CLTEvent.CClubDownLoad,"") --通知公会数据接收完毕
end
--===========================
--398005 已加入公会回复
--===========================
_socketParser[398005] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local guid = StreamPaser:readInt()
	local digLvs = StreamPaser:readInt()
	local elos = StreamPaser:readInt()
	local names = StreamPaser:readStr()
	names = HOAux:hexstr2str(names)
	local acctguid = AcctManager:getParam("guid")
	if guid == acctguid then
		AcctManager:setParam("joinClubTime",os.time())
        SendMsg[938002]()
    else
   	    club_data.members[guid]={name = names,digLv = digLvs,elo = elos,guid= guid,honor=0,atkCount=0}
   	    club_data.membersCount = club_data.membersCount+1
    end
	FloatNode.addFlatMsg(4,string.format(TxtList.guildMsg[4],names))
end

--===========================
--398008 会内聊天广播
--===========================
_socketParser[398008]= function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local userguid = StreamPaser:readInt()
    local mid = StreamPaser:readInt()
    local usermsg  = StreamPaser:readStr()
	if not club_data then return end
	if not club_data.members[userguid] then return end

	local newmsg = {}
	newmsg.type = 3
	newmsg._mid = mid
	newmsg.guid = userguid
	newmsg.content = usermsg
	newmsg.name = club_data.members[userguid].name
	newmsg.digLv =  club_data.members[userguid].digLv
	newmsg.date = os.time()
	GuildMsgManager:addMsg(newmsg)
end
--==========================
--398009 被踢出公会
--==========================
_socketParser[398009] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	if club_data then
		FloatNode.addFlatMsg(4,string.format(TxtList.guildMsg[3],club_data.manager),1,os.time())
	end
	GuildMsgManager:clearMsg()
    club_data = nil
	AcctManager:setParam("cid",0)
	AcctManager:setParam("cbName","")
end
--==========================
--398010 广播解散公会
--==========================
_socketParser[398010] =function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	if club_data then
		FloatNode.addFlatMsg(4,string.format(TxtList.guildMsg[5],club_data.manager),os.time())
	end
	GuildMsgManager:clearMsg()
	AcctManager:setParam("cid",0)
	AcctManager:setParam("cbName","")
	club_data=nil
end

--==========================
--398004 广播申请加入公会
--==========================
_socketParser[398004] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local tableTemp = protocol2table(datatype.bson,0,msglen-16)--getTableFromPaser()
	tableTemp.name = HOAux:hexstr2str(tableTemp.name)
	if not club_data then return end
	local acctguid = AcctManager:getParam("guid")
	if club_data.managerID~=acctguid then return end
	GuildMsgManager:addMsg(tableTemp)
end
--===========================
--398012 全服公会排位数据
--===========================
_socketParser[398012] = function (msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local bodylen = StreamPaser:readInt()
	if bodylen > 0 then
	    local selfIdx,totalPage,curPage,startIdx,endIdx = StreamPaser:read(5)
		if selfIdx > 0 then	RankHelper.setOwnRankIdx(4,selfIdx) end
		for idx=1,(endIdx - startIdx + 1) do
			local tb = {}
			tb.cid,tb.elo,tb.jewel = StreamPaser:read(3)
			local name = StreamPaser:readStr()
			tb.name = HOAux:hexstr2str(name)
			ClubRankHelper:addRankData(totalPage,curPage,tb)
		end
		ClubRankHelper:finishDownLoad(true)
	else
		ClubRankHelper:finishDownLoad()
	end
end
--==========================
 --398013 公会ELO奖励
 --==========================
_socketParser[398013] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local awardVal = StreamPaser:readInt()
	AcctManager:incrParam("jewel",awardVal)
	TDHelper.onReward(awardVal,"Elo ranking award from club")
end
--==========================
--398014 指定GUID帐号对应的公会信息摘要
--==========================
_socketParser[398014] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local bytelen = msglen - 24
    if opstate == 0 then
		local dtype = StreamPaser:readInt()
		local bComp = StreamPaser:readInt()
        local club = protocol2table(dtype,bComp,bytelen)
		club.clubName = HOAux:hexstr2str(club.clubName)
		club.clubDesc = HOAux:hexstr2str(club.clubDesc)
		club.manager = HOAux:hexstr2str(club.manager)
		for uid, mbr in pairs(club.members) do
			mbr.name = HOAux:hexstr2str(mbr.name)
		end
        if not club_cid then
            club_cid={}
            club_cid[club.cid]=club
        else
            club_cid[club.cid]=club
        end
        club_cid[-1] = club --当前搜索的公会
        --AccountHelper:unlock(kStateToViewGuild)
        postEventSignal(kEventGetClubView)
    else
        if not club_cid then club_cid={}end
        --AccountHelper:unlock(kStateToViewGuild)
        postEventSignal(kEventGetClubView)
    end
end
--==========================
-- 398015 模糊查找返回的公会结果
--==========================
_socketParser[398015] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local Count = StreamPaser:readInt()
	if Count > 0 then
		  club_search = {}
		  for idx=1,Count do
		      local tb ={}
		      tb = {cid=StreamPaser:readInt(),elo=StreamPaser:readInt(), membersCount=StreamPaser:readInt(),clubName=StreamPaser:readStr()}
		      tb.clubName = HOAux:hexstr2str(tb.clubName)
		      table.insert(club_search,tb)
		  end
	end
	postEventSignal(kEventClubSearch)
end
--==========================
-- 398016 默认显示公会列表
--==========================
_socketParser[398016] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local Count = StreamPaser:readInt()
	if Count > 0 then
		  club_search = {}
		  for idx=1,Count do
		      local tb ={}
		      tb = {cid=StreamPaser:readInt(),elo=StreamPaser:readInt(), membersCount=StreamPaser:readInt(),clubName=StreamPaser:readStr()}
		      tb.clubName = HOAux:hexstr2str(tb.clubName)
		      table.insert(club_search,tb)
		  end
		   table.sort(club_search,function(a,b) return a.membersCount>b.membersCount end )
	end
	postEventSignal(kEventClubSearch)
end
--==========================
--3911001 搜索对战公会结果信息
--isSucc  --搜索结果 0：没有匹配的公会  >0 有匹配公会
--warData --对战双方数据
--==========================
_socketParser[3911001] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local isSucc = StreamPaser:readInt()
	if isSucc > 0 then
		local warData = protocol2table(datatype.bson,0,msglen-20)
		videomanager.clearwarvideo() --公会战开始时，清除公会战录像记录
		if club_data then
			club_data.warData = warData
			club_data.guardSt = 0
			local acctguid = AcctManager:getParam("guid")
			club_data.members[acctguid].atkCount = numDef.cbWarAtkCount
			__formatWarData(club_data)
			--开战提示
             local tb = {}
             tb.type = 5
             tb.data = {type=0,}
             tb.data.clubName = club_data.clubName
             tb.data.atkClubName = club_data.warData.cb_atk.clubName
             tb.data.defClubName = club_data.warData.cb_def.clubName
             tb.data.atkStars = club_data.warData.cb_atk.sumStars
             tb.data.defStars = club_data.warData.cb_def.sumStars
             AccountHelper:addNewPrompt(tb)
		end
	end
	AccountHelper:unlock(kStateClubPvp)
end
--==========================
--3911002 公会对战防御方玩家及坑道信息
--isSucc  --可否开战 0：当前坑道正在初攻击  >0 可以开战
--lastStars --目标被我方获取过的最大星星
--clubpvpacct -- 目标坑道数据
--==========================
_socketParser[3911002] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local isSucc = StreamPaser:readInt()
	if isSucc > 0 then
		local lastStars = StreamPaser:readInt()
		local clubPvpAcct= getTargetHoleData(os.time())
		clubPvpAcct.lastStars = lastStars
		local defencer = club_data.defClub.targets[clubPvpAcct.guid]
		defencer.digLv = clubPvpAcct.digLv
		defencer.elo = clubPvpAcct.elo
		defencer.nickName = clubPvpAcct.user
		defencer.stars = lastStars
		AcctManager:setPvpAcct("clubpvp",clubPvpAcct)
	else
		AcctManager:setPvpAcct("clubpvp",nil)
	end
end
--==========================
--3911004 1v1战况广播
--cidOfTag(int) 被攻击者所属公会ID
--tagID(int)	被攻击者的GUID
--tagStars(int) 被攻击者最新星星数
--cidOfAtker(int) 攻击者所属公会ID
--sumStarsOfCbAtker(int) 攻击者所属公会最新累计星星数
--sumAtkCountOfCbAtker(int) 攻击者所属公会最新累计进攻计数
--atkerName(hexstr) 攻击者名字
--==========================
_socketParser[3911004] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local cidOfTag =  StreamPaser:readInt()
	local tagID =  StreamPaser:readInt()
	local tagStars =  StreamPaser:readInt()
	local cidOfAtker =  StreamPaser:readInt()
	local sumStarsOfCbAtker = StreamPaser:readInt()
	local sumAtkCountOfCbAtker = StreamPaser:readInt()
	local atkerName,_ = StreamPaser:readStr()
	atkerName = HOAux:hexstr2str(atkerName)
	if club_data and club_data.warData then
		local atk_club = club_data.warData.cb_atk
		local def_club = club_data.warData.cb_def
		if cidOfTag == club_data.warData.cb_atk.cid then
			atk_club = club_data.warData.cb_def
			def_club = club_data.warData.cb_atk
		end
		local defencer = def_club.targets[tagID]
		defencer.stars = tagStars
		defencer.atkerName = atkerName
		atk_club.sumStars = sumStarsOfCbAtker
		atk_club.sumAtkCount = sumAtkCountOfCbAtker
	end
end
--==========================
--3911005 录像摘要广播
--==========================
_socketParser[3911005] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local ret = __getbattleheader()
	local readLen = StreamPaser:getPtrPos()
	if ret then
		for _, hdr in ipairs(ret) do
			local sumary = __getbattlesumary()
			readLen = readLen + hdr.sumzlen
			StreamPaser:movePtrTo(readLen)
			sumary.vid = hdr.vid
			videomanager.addwarsumary(sumary)
		end
	end
	club_data.battleSumaries = videomanager.getwarsumaries()
end
--==========================
--3911006 公会战结束广播
--atkEloDlt  攻方公会ELO变化
--defEloDlt	  防守公会ELO变化
--atkSumStars 攻方公会得到的星星总数
--defSumStars 防守公会得到的星星总数
--==========================
_socketParser[3911006] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local atkEloDlt =  StreamPaser:readInt()
	local defEloDlt =  StreamPaser:readInt()
	local atkSumStars =  StreamPaser:readInt()
	local defSumStars =  StreamPaser:readInt()
	videomanager.clearwarvideo() --公会战结束时，清除公会战录像记录
	if club_data then
		club_data.lastWarResult ={}
		club_data.lastWarResult.atkName = club_data.warData.cb_atk.clubName
		club_data.lastWarResult.defName = club_data.warData.cb_def.clubName
		club_data.lastWarResult.atkEloDlt =  atkEloDlt
		club_data.lastWarResult.defEloDlt = defEloDlt
		club_data.lastWarResult.atkSumStars =  atkSumStars
		club_data.lastWarResult.defSumStars =  defSumStars
		club_data.lastWarResult.endTime = os.time()
		--公会战结束消息提示
		local tb = {}
		tb.type = 5
		tb.data = {type=1,}
		tb.data.clubName = club_data.clubName
		tb.data.atkClubName = club_data.lastWarResult.atkName
		tb.data.defClubName = club_data.lastWarResult.defName
		tb.data.atkEloDlt = club_data.lastWarResult.atkEloDlt
		tb.data.defEloDlt = club_data.lastWarResult.defEloDlt
		AccountHelper:addNewPrompt(tb)

		if club_data.cid == club_data.warData.cb_atk.cid then
			club_data.elo = math.max(club_data.elo + atkEloDlt,0)
			if atkEloDlt < defEloDlt then
				club_data.guardSt = os.time() + numDef.clubPvpGuardInt
			end
		else
			club_data.elo = math.max(club_data.elo + defEloDlt,0)
			if atkEloDlt >= defEloDlt  then
				club_data.guardSt = os.time() + numDef.clubPvpGuardInt
			end
		end

		club_data.warData = nil
	end
end
--==========================
--3911007 公会录像摘要信息
--==========================
_socketParser[3911007] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local ret = __getbattleheader()
	local readLen = StreamPaser:getPtrPos()
	videomanager.clearwarvideo()
	if ret then
		for _, hdr in ipairs(ret) do
			local sumary = __getbattlesumary()
			readLen = readLen + hdr.sumzlen
			StreamPaser:movePtrTo(readLen)
			sumary.vid = hdr.vid
			videomanager.addwarsumary(sumary)
		end
	end
	club_data.battleSumaries = videomanager.getwarsumaries()
end
--==========================
 --3911008 公会战录像信息明细
 --==========================
 --atk: 进攻方数据
 --dfs: 防守方数据
 --==========================
_socketParser[3911008] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	if opstate == -1 then
	else
		local vid = StreamPaser:readInt()
		local sl = StreamPaser:readInt()
		local dl = StreamPaser:readInt()
		local readLen = StreamPaser:getPtrPos()
		local sumary = __getbattlesumary()
		readLen = readLen + sl
		StreamPaser:movePtrTo(readLen)
		
		local atk, def = __getbattledetail()
		readLen = readLen + dl
		StreamPaser:movePtrTo(readLen)
		atk.team = sumary.team
		atk.heroList = sumary.heroList
		atk.equipments = sumary.equipments

		videomanager.addwarvideo(vid, {bpresult=sumary, atk=atk, def=def})
	end
    AccountHelper:unlock(kStateWarVideo)
end
--==========================
 --3911010 公会战数据
 --==========================
 --==========================
_socketParser[3911010] =function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	if opstate == -1 then
		club_data.warData = nil
	else
		local dtype = StreamPaser:readInt()
		local bComp = StreamPaser:readInt()
		club_data.warData = protocol2table(dtype,bComp,msglen-24)
		__formatWarData(club_data)
		if club_data.warData.expire -numDef.cbWarInterval  > AcctManager:getParam("lastOffline") then
			 --交战中提示
			local tb = {}
			tb.type = 5
			tb.data = {type=0,}
			tb.data.clubName = club_data.clubName
			tb.data.atkClubName = club_data.warData.cb_atk.clubName
			tb.data.defClubName = club_data.warData.cb_def.clubName
			tb.data.atkStars = club_data.warData.cb_atk.sumStars
			tb.data.defStars = club_data.warData.cb_def.sumStars
			AccountHelper:addNewPrompt(tb)
		end
		club_data.warData.expire = club_data.warData.expire + AcctManager:getOffsetTime()
	end
	PlugInHelper:triggerEvent(CLTEvent.CClubWarDownLoad,"") --通知公会战数据接收完毕
end
--==========================
--3912001  排行榜奖励
--=========================
_socketParser[3912001] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local key = StreamPaser:readInt()
	local id = StreamPaser:readInt()
	local val = StreamPaser:readInt()
	AcctManager:setHashParam("rewardMails",key,{id=id,val=val})
    postEventSignal(kEventNoticeMail)
end
--===========================
--3913001 广播 创建的探险队
--===========================
_socketParser[3913001] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local newmsg = {}
    local tid = StreamPaser:readInt()
	newmsg.limit = StreamPaser:readInt()
	newmsg.date = StreamPaser:readInt()
	local content = StreamPaser:readStr()
    newmsg.content = HOAux:hexstr2str(content)
	newmsg.type = 4
	newmsg.guid = tid
	newmsg._mid = -tid
	newmsg.digLv =  club_data.members[tid].digLv
	newmsg.name =  club_data.members[tid].name
	newmsg.cur = 1 
	GuildMsgManager:updateMsg(-tid)
	GuildMsgManager:addMsg(newmsg)
    club_data.teamMsg[tid]={guid=tid,limit=newmsg.limit,date=newmsg.date,content = newmsg.content,cur=newmsg.cur  }
    AccountHelper:unlock(kStateAdventureTeam)
end
--==========================
--3913002 查看的探险队数据
--==========================
_socketParser[3913002] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local op = StreamPaser:readInt()
    if op > 0 then
		local dtype = StreamPaser:readInt()
		local acctTid =0
		local acctTeamCnt = 0
		if dtype == datatype.binary then
			local tb={}
			tb.tid = StreamPaser:readInt()
			tb.bp = StreamPaser:readInt()
			tb.consume = StreamPaser:readInt()
			tb.ed = StreamPaser:readInt()
		    tb.startEd = tb.ed + os.time()
	        tb.team = {}
			local cnts = StreamPaser:readInt()
	        local cnt= cnts%256
			tb.wins = math.floor(cnts/256)
			for idx=1,cnt do
	            local stb = {}
				stb.guid =StreamPaser:readInt()
			    local heroCtx  = StreamPaser:readInt()
		        stb.heroid = math.floor(heroCtx/100)%100
	            stb.herolv = math.floor(heroCtx/1000000)
				table.insert(tb.team,stb)
			end
			acctTid = -tb.tid
			acctTeamCnt = cnt
			AcctManager:setParam("lookCbTeam",tb)
			----------------------------------
		elseif dtype == datatype.bson then
			local ud = StreamPaser:readUserData(msglen-24)
			local raw = HOAux:bson2table(ud)
			raw.startEd = raw.ed
			raw.ed = raw.ed - os.time()
			raw.team = raw.heros
			for idx,hero in ipairs(raw.heros) do
				hero.guid = hero.sender
				hero.heroid = math.floor(hero.hctx/100)%100
				hero.herolv = math.floor(hero.hctx/1000000)
			end
			acctTid = -raw.tid
			acctTeamCnt = table.getn(raw.heros)
			AcctManager:setParam("lookCbTeam",raw)
		end
		GuildMsgManager:updateMsg(acctTid,acctTeamCnt)
    else
		AcctManager:setParam("lookCbTeam",nil)
    end
    AccountHelper:unlock(kStateAdventureTeam)
end
--===========================
--3913003 加入探险对回复
--===========================
_socketParser[3913003] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local opstate = StreamPaser:readInt()
    if opstate == 0 then
        local tid = StreamPaser:readInt()
		local ed = StreamPaser:readInt()
		local heroid = StreamPaser:readInt()
		AcctManager:setHashParam("cbTeam",heroid,{tid=tid,ed=os.time()+ed})
		local lookCbTeam = AcctManager:getParam("lookCbTeam")
		GuildMsgManager:updateMsg(-lookCbTeam.tid,table.getn(lookCbTeam.team)+1)

    elseif opstate == 1 then  --重复加入
        print("false")
    elseif opstate == 2 then  --满员
        print("false")
    end
    AccountHelper:unlock(kStateAdventureTeam)
end
--===========================
--3913004 探险队到期英雄回归
--===========================
_socketParser[3913004]= function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
	local heroInfo = {}
	local heroList = {}
    local heroid,gainGold,gainExp,gainBox,winCnt = StreamPaser:read(5)
	table.insert(heroInfo,heroid)
	local newExp,newLv,expChange = RiskHelper.getHeroExpAndLv( gainExp,AcctManager:getParam("digLv"), AcctManager:getHashParam("heroList",heroid))
	heroList[heroid] = {fexp =gainExp,gold = gainGold,boxid = gainBox,wins = winCnt,newExp =newExp,newLv = newLv,expChange = expChange }
	 --有宝箱
	if gainBox > 0 then
		heroList[heroid].awardRes =  baseCalc.treasureBox(AcctManager:get(),gainBox,nil,nil)
	end
	local cbTeamHero = AcctManager:getHashParam("cbTeam",heroid)
    club_data.teamMsg[cbTeamHero.tid]=nil
	AcctManager:setHashParam("cbTeam",heroid,nil)
     -- 英雄回归提示
    local tb = {}
    tb.type = 6
    tb.data = {}
    tb.data.team = heroInfo
    tb.data.heroList = heroList
    AccountHelper:addNewPrompt(tb)
	SendMsg[9313007](heroInfo,heroList)
end
--============================
--3913005 匹配探险队回复
--============================
_socketParser[3913005]= function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local cntOfTeam = StreamPaser:readInt()
    DefTaskHelper.removeAllTeam()
    for idx=1,cntOfTeam,1 do
        local tb = {
            heroList = {},
            equipments = {},
            team = {},
        }
        tb.tid = StreamPaser:readInt()
        tb.bp = StreamPaser:readInt()
        tb.consume =StreamPaser:readInt()
        local cnt = StreamPaser:readInt()
        for idx=1,cnt do
            local heroCtx  = StreamPaser:readInt()
            local eid = heroCtx % 10000
            local heroid = math.floor(heroCtx/100)%100
            local herograde = math.floor(heroCtx/10000)%100
            local herolv = math.floor(heroCtx/1000000)

            local eqCtx = StreamPaser:readInt()
            local eid_lv = eqCtx % 256
            local eid_qa = math.floor(eqCtx/256)

            local seid1 = StreamPaser:readInt()
            local seid2 = StreamPaser:readInt()

            table.insert(tb.team,heroid)
            local heroprop = {type=heroid,lv=herolv,grade=herograde,enterTime=1000,eid=eid,equip={eid_lv,eid_qa},eid_s1=seid1,eid_s2=seid2,}
            table.insert(tb.heroList,heroprop)
            --tb.equipments ={[eid]={eid_lv,eid_qa},}
        end
        tb.name = StreamPaser:readStr()
        tb.name = HOAux:hexstr2str(tb.name)
        tb.costAct = numDef.cbTeamBattleAp
        DefTaskHelper.addTeam(tb)
    end
    AccountHelper:unlock(kStateDefExplore)
end

--==========================
 --399999 脚本文件
 --==========================
 --fileCount:    脚本文件数量
 --type:        文件类型
 --filename:    文件名称
 --filedata:    文件内容
 --==========================
_socketParser[399999] = function(msglen)
	local lguid,opstate =  StreamPaser:read(2)
    local filecount = StreamPaser:readInt()
    loadZipFileFromMsg(filecount,9,msglen - 20)
end

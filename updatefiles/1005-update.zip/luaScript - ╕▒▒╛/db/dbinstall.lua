local curVer =1000
local dbSqlStr=string.format([[
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS TBDBVer(
	rDBVer INTEGER);
CREATE TABLE IF NOT EXISTS TBGameVer (
           rGameVer INTEGER,
		   rDownVer INTEGER,
		   rLatestVer INTEGER
		   );
CREATE TABLE IF NOT EXISTS TBAcctLog (
           rLogName TEXT PRIMARY KEY NOT NULL,
		   rLogServer TEXT
		   );
CREATE TABLE IF NOT EXISTS TBLogHistory (
           rPUserID TEXT
		   );
CREATE TABLE IF NOT EXISTS TBAcctCfg (
		   rCfgKey TEXT PRIMARY KEY NOT NULL,
		   rCfgVal TEXT
		   );
CREATE TABLE IF NOT EXISTS TBPrivateMsg (
			rID INTEGER PRIMARY KEY AUTOINCREMENT,
			rUserID INTEGER,
			rIsRecv INTEGER,
			rTUserID INTEGER,
			rTUserName TEXT,
			rTDigLv INTEGER,
			rTClubID INTEGER,
			rTClubName TEXT,
			rMsg TEXT,
			rDate INTEGER
			);
CREATE TABLE IF NOT EXISTS TBPublicMsg (
			rID INTEGER PRIMARY KEY AUTOINCREMENT,
			rUserID INTEGER,
			rFUserID INTEGER,
			rFUserName TEXT,
			rFDigLv INTEGER,
			rFClubID INTEGER,
			rFClubName TEXT,
			rMsg TEXT,
			rDate INTEGER
			);
CREATE TABLE IF NOT EXISTS TBGuildMsg (
			rID INTEGER PRIMARY KEY AUTOINCREMENT,
			rUserID INTEGER,
			rMsgID INTEGER,
			rMsgType INTEGER,
			rFromId INTEGER,
			rFromName TEXT,
			rMsg TEXT,
			rDate INTEGER,
			rState INTEGER,
			rCurCnt INTEGER,
			rLimitCnt INTEGER
			);
CREATE TABLE IF NOT EXISTS TBCMScript (
		   rFileName TEXT PRIMARY KEY NOT NULL,
		   rFileData TEXT
		   );
CREATE TABLE IF NOT EXISTS TBCMScriptVersion (
		   rCMScriptVer INTEGER
		   );
INSERT INTO TBDBVer(rDBVer) VALUES(%d);
INSERT INTO TBCMScriptVersion(rCMScriptVer) VALUES(1);
INSERT INTO TBGameVer(rGameVer,rDownVer,rLatestVer) VALUES(%d,%d,%d);
CREATE INDEX TBPrivateMsg_Index0 on TBPrivateMsg (rUserID);
CREATE INDEX TBPublicMsg_Index0 on TBPublicMsg (rUserID);
CREATE INDEX TBGuildMsg_Index0 on TBGuildMsg (rUserID);
COMMIT;
]],curVer,curVer,curVer,curVer)
DBUtil:ExecSql(dbSqlStr)
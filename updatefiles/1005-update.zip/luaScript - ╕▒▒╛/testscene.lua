local __testscene={}
function __testscene.bindTouchEvent(obj)
     CCSpriteFrameCache:sharedSpriteFrameCache():addSpriteFramesWithFile("GUIRes/image/sprite/icon.plist")
	local function onTouch(eventType, x,y)
        if eventType == "began" then
			
			 local img = ImageView:create()
			 img:loadTexture("elo.png",UI_TEX_TYPE_PLIST)
			 img:setPosition(ccp(640,360))
			 obj._layer:addChild(img)
        end
	end
	obj._layer:registerScriptTouchHandler(onTouch,false,0,true)
	obj._layer:setTouchEnabled(true)
end
TestScene = {}
function TestScene.new()
	local obj = {}
	Scene.install(obj)
	table_aux.unpackTo(__testscene, obj)
	obj._layer = CCLayerColor:create(ccc4(255,255,255,255))
	obj:egAddChild(obj._layer)
    obj:bindTouchEvent()
    return obj
end

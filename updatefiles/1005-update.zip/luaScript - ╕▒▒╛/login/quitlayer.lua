local function creator()
	local self = TouchWidget.new(JsonList.quitLayer)
	self:setTouchPriority(-1024)
	local function continueCallback(sender)
        sender:setTouchEnabled(false)
		PlugInHelper:triggerEvent(CLTEvent.ContinueGame,"")
    end
    self:egBindTouch("btn_play",nil,nil,continueCallback,nil)
    self:egBindTouch("btn_cancel",nil,nil,continueCallback,nil)
	local function quitCallback(sender)
        sender:setTouchEnabled(false)
		PlugInHelper:triggerEvent(CLTEvent.ExitGame,"")
    end
	self:egBindTouch( "btn_quit",nil,nil,quitCallback,nil)
	return self
end
QuitLayer = class("QuitLayer",creator)
QuitLayer.__index = QuitLayer
function QuitLayer:showWithAction()
	local widget = self:getWidgetByName("img_bg")
    widget:setScale(0)
    local scaleto = CCScaleTo:create(0.2,1)
    local backout = CCEaseBackOut:create(scaleto)
    widget:runAction(backout)
end

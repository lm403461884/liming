
local kPanelItem = "item_panel"
local kLblServer = "lbl_ser_name"
local kLblState = "lbl_ser_state"
local kImgLv = "img_lv"
local kLblLv = "lbl_lv"
local kMaxOnlines = 100000
local kColor
local __switchitem={}
function __switchitem.init(obj,data)
	obj._data = data
	obj:egSetLabelStr(kLblServer,obj._data.name)
	if obj._data.digLv then
		obj:egShowWidget(kImgLv)
		obj:egSetBMLabelStr(kLblLv,obj._data.digLv)
	else
		obj:egHideWidget(kImgLv)
	end
	obj:egSetLabelStr(kLblState,string.format("%s%s%s","(",TxtList.serState[obj._data.state],")"))
	obj:egSetWidgetColor(kLblState,KVariantList.serverColor[obj._data.state])
	obj:egSetWidgetColor(kLblServer,KVariantList.serverColor[obj._data.state])
end
function __switchitem.bindItemEvent(obj,callback)
	obj._clickCallback = callback
	 local function touchEnded (sender)
		if obj._clickCallback then obj._clickCallback(obj) end
	 end
	 obj:egBindTouch(kPanelItem,nil,nil,touchEnded,nil)
end
function __switchitem.getServerData(obj)
	return obj._data
end

local function creator(data)
   local obj =CocosWidget.new(JsonList.switchItem)
   table_aux.unpackTo(__switchitem,obj)
   obj:init(data)
   return obj
end
SwitchItem = class("SwitchItem",creator)
SwitchItem.__index = SwitchItem
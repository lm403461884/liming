FlatMsgItem = class("FlatMsgItem")
FlatMsgItem.__index = FlatMsgItem
local msgColor = {ccc3(255,255,255),ccc3(0,255,0),ccc3(255,0,255),ccc3(255,255,0),ccc3(255,165,0),ccc3(255,0,0)}
function FlatMsgItem.extend(target)
    local t = {}
    tolua.setpeer(target, t)
    setmetatable(t, FlatMsgItem)
    return target
end
function FlatMsgItem.new()
	local obj = FlatMsgItem.extend(CCLayer:create())
	
	local img = CCScale9Sprite:createWithSpriteFrameName(graphicLoader.getTextureFrameName(ImageList.txt_bg))
	img:setContentSize(CCSizeMake(720,52)) --720
	img:setOpacity(0)
	img:setPosition(ccp(680,620))
	obj:addChild(img)
	obj._img = img
	
	local cliper = CCClippingNode:create()
	local shape = CCLayerColor:create(ccc4(128,128,2,255))
	shape:setContentSize(CCSizeMake(675,40))
	cliper:setStencil(shape)
	cliper:setPosition(ccp(340,600))
	obj:addChild(cliper)
	obj._msgList={}
	obj._layer = cliper
	local function callback(eventType)
		if eventType == "exit" then
			if obj._updatehandler then
				CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(obj._updatehandler)
				obj._updatehandler = nil
			end
			obj._layer = nil
			obj._img  = nil
		end
	end
	obj:registerScriptHandler(callback)
	return obj
end

function FlatMsgItem:show()
	if #self._msgList <= 0 then return end
	if self._layer:getChildByTag(1) then return end
	local msginfo = self._msgList[1]
	if msginfo.showtime > os.time() then return end
	local scene = SceneManager:getRunningScene()
	msginfo.cnt = msginfo.cnt - 1
	msginfo.showtime = msginfo.interval + msginfo.showtime
	table.remove(self._msgList,1)
	--主界面聊天窗口打开时,不显示聊天相关信息提示
	if scene._chatWidget and msginfo.flag == 1 or msginfo.flag == 2 or msginfo.flag == 3  then  return end
	if msginfo.cnt > 0 then
		table.insert(self._msgList,msginfo)
		table.sort(self._msgList,function(a,b) return a.showtime < b.showtime end)
	end
	lbl = CCLabelTTF:create(msginfo.text, FNList.STHUPO, 36)
	lbl:setColor(msgColor[msginfo.flag])
	lbl:setAnchorPoint(ccp(0,0))
	lbl:setPosition(ccp(675,0))
	self._layer:addChild(lbl,1,1)
	local step = -5
	local posx = lbl:getPositionX()
	local posy = lbl:getPositionY()
	local lblw = lbl:getContentSize().width
	local function update()
		posx = posx  + step
		lbl:setPosition(posx,posy)
		if posx <= -lblw then
			CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(self._updatehandler)
			self._layer:removeChildByTag(1,true)
			self._updatehandler = nil
			self._img:runAction(CCFadeOut:create(0.5))
		end
	end
	self._img:runAction(CCSequence:createWithTwoActions( CCFadeTo:create(0.5,255),CCCallFunc:create(function() self._updatehandler = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update, 0, false)  end)))
end
--msginfo{flag,text,cnt}
--flag: 1公聊 白 2公会聊天 绿 3私聊 紫 4系统消息 黄 5GM消息 橘 6系统公告 红
--mcnt:滚动次数
--mt:显示时间
--mintv:间隔时间 --未设置时,默认为1个小时
function FlatMsgItem:add(mflag,mtext,mcnt,mt,mintv)
	mcnt = mcnt or 1
	mintv = mintv or 3600
	mt = mt or os.time()
	table.insert(self._msgList,{flag = mflag,text=mtext,cnt=mcnt,showtime = mt,interval = mintv})
	table.sort(self._msgList,function(a,b) return a.showtime < b.showtime end)
end
function FlatMsgItem:clearByType(flag)
	local cnt = #self._msgList 
	if cnt > 0 then
		for idx = cnt,1,-1 do
			if self._msgList[idx].flag == flag then
				table.remove(self._msgList,idx)
			end
		end
	end
end



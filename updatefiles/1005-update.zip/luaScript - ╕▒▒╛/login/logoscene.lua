local function creator()
	local scene = Scene.new() 
	scene._updatehandler = nil
	scene._isCoDead = false
	scene._isLogoShown = false
	local function coFunc()
		HOLoadHelper.loadScript(true)
		SecurityManager:encryptGameData(true)
		GuideManager:clear()
		return 1
	end
	scene._coLoad = coroutine.create(coFunc) 
	local function update(delta)
		if scene._isCoDead and scene._isLogoShown then
			if scene._updatehandler then CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(scene._updatehandler) end
			SceneManager:show(LoadScene)
		elseif not scene._isCoDead then
			local f1,f2 = coroutine.resume(scene._coLoad)
			if f2 == 1 then 
				scene._isCoDead = true
			elseif type(f2) == "string" then 
                if scene._updatehandler then CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(scene._updatehandler) end
				print(f2)
				MessageBox.show(TxtList.getDataError,LogoScene)
			end
		end
    end
	
	local function callback(eventType)
        if eventType == "enter" then
		   scene._updatehandler = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update, 0, false)
           SpeedManager:init()
		   SoundHelper.stopBGM()
		   local layer = CCLayerColor:create(ccc4(255,255,255,255))
		   local img = CCSprite:createWithSpriteFrameName(graphicLoader.getTextureFrameName(ImageList.logo))
		   img:setOpacity(32)
		   img:setPosition(ccp(640,360))
		   layer:addChild(img)
		   scene:addChild(layer)

		   local fadeto = CCFadeTo:create(2,255)
		   local function callfuncCallback()
				local sdkimg= SDKConfig.getLogoImg()
				local frameName = graphicLoader.getTextureFrameName(sdkimg)
				local frame = graphicLoader.getFrame(frameName)
				if sdkimg then img:setDisplayFrame(frame) end
				scene._isLogoShown = true
		   end
		   local callfunc1 = CCCallFunc:create(callfuncCallback)
		   local array = CCArray:create()
		   array:addObject(fadeto)
		   array:addObject(callfunc1)
		   local sequence = CCSequence:create(array)
		   img:runAction(sequence)
		elseif eventType == "exit" then
			if scene._updatehandler then CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(scene._updatehandler) end
        end
    end
	scene:registerScriptHandler(callback)
	return scene
end
LogoScene = class("LogoScene",creator)
LogoScene.__index = LogoScene




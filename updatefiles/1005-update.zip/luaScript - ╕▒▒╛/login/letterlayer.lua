local kImgBg = "img_bg"
local kPanelTxt = "txt_panel"
local kBtnClose = "btn_close"
local kPanelLayer = "panel_info"

local __letterinfo={}
function __letterinfo.init(obj,content)
	local txtlist = Funs.splitStr(content,"\n")	
	local panel = obj:egGetScrollView(kPanelTxt)
	local color = ccc3(83,49,22)
	local fontname = FNList.STHUPO
	local fontsize = 24
	local maxW = panel:getSize().width
	local oldH = panel:getSize().height
	--local layouttype = panel:getLayoutType()
	local totalH = 0
	for key,val in ipairs(txtlist) do
		if string.len(val)>0 then 
			local lbl,showH= obj:addLblCtrl(val,color,fontname,fontsize,maxW)
			totalH = totalH + showH
			panel:addChild(lbl)
			--local layoutparameter = lbl:getLayoutParameter(layouttype)
			--layoutparameter:setMarginTo(0,0,0,fontsize)
			--lbl:setLayoutParameter(layoutparameter)
		end
	end
	if totalH >oldH then
		panel:setInnerContainerSize(CCSizeMake(maxW,totalH))
	end
    obj:showWidthAction()
end
function __letterinfo.addLblCtrl(obj,str,color,fontname,fontsize,maxW)
	local lbl = Label:create()
	lbl:setText(str)
	lbl:setFontSize(fontsize)
	lbl:setColor(color)
	lbl:setFontName(fontname)
	local lblW = lbl:getSize().width
	local lblH = lbl:getSize().height
	if lblW >= maxW then
		local rows = math.ceil(lblW/maxW)
		local rowmod = lblW%maxW
		if rowmod > maxW*2/3 and rows > 3 then rows = rows + 1 end
		lblW = maxW
		lblH = rows*lblH
		--lbl:setTextAreaSize(CCSizeMake(lblW,lblH))
		lbl:setSize(CCSizeMake(lblW,lblH))
		lbl:ignoreContentAdaptWithSize(false)
	end
	return lbl,lblH
end
function __letterinfo.showWidthAction(obj)
    obj._masklayer = CCLayerColor:create(ccc4(0,0,0,0))
    obj:egAddChild(obj._masklayer,-1,1)
    obj._masklayer:runAction(CCFadeTo:create(0.5,100))

    local cardbg = obj:egGetWidgetByName(kImgBg)
    cardbg:setScale(0)
    local scaleto = CCScaleTo:create(0.5,1)
    local backout = CCEaseBackOut:create(scaleto)
    local function callback()
        if obj._onloaded then obj._onloaded() end
        obj:bindCloseListener()
		obj:bindPanelListener()
    end
    local callfunc = CCCallFunc:create(callback)
    local sequence = CCSequence:createWithTwoActions(backout,callfunc)
    cardbg:runAction(sequence)
end

--关闭页面
function __letterinfo.bindCloseListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if GuideManager:isGuiding() then --引导状态
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kBtnClose,nil,nil,touchEnded,touchCanceled)
end
--关闭页面
function __letterinfo.bindPanelListener(obj)
    local function touchEnded(sender)
        SoundHelper.playEffect(SoundList.click_paper_close)
        sender:setTouchEnabled(false)
		obj:egRemoveSelf()
    end
	local function touchCanceled(sender)
		if GuideManager:isGuiding() then --引导状态
			touchEnded(sender)
		end
	end
    obj:egBindTouch(kPanelLayer,nil,nil,touchEnded,touchCanceled)
end

local function creator(content,onload)
    local obj =  TouchWidget.new(JsonList.letterLayer)
    table_aux.unpackTo(__letterinfo, obj)
    obj._onloaded = onload
    obj:init(content)
    return obj
end
LetterLayer = class("LetterLayer",creator)
LetterLayer.__index = LetterLayer

function showLetterLayer(content,onload)
	local layer = LetterLayer.new(content,onload)
    local scene = CCDirector:sharedDirector():getRunningScene()
    scene:addChild(layer:egNode(),UILv.popLayer,UILv.popLayer)
end

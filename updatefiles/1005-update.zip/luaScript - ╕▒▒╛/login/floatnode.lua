
FloatNode=class("FloatNode" )
FloatNode.__index = FloatNode
function FloatNode.extend(target)
    local t = {}
    tolua.setpeer(target, t)
    setmetatable(t, FloatNode)
    return target
end
function FloatNode.new()
	local layer = FloatNode.extend(CCLayerColor:create(ccc4(0,0,0,0)))
	local function onTouch(eventType, x,y)
		if eventType == "began" then return true end
	end
	layer:setTouchEnabled(true)
	layer._priority = -512
	layer:registerScriptTouchHandler(onTouch,false,-512 ,true)
	layer._event = {}
	if numDef then
		layer._beatCounter = numDef.beatInterval or 10
	else
		layer._beatCounter = 10
	end
	layer._sleeping = false --心跳
	layer._flagmsgnode = FlatMsgItem.new() 
	layer:addChild(layer._flagmsgnode)
	return layer
end
--===============================
--创建对象
--===============================
function FloatNode:create()
	local node = FloatNode.new()
	node._objNUM = os.time()
	node:enabledUpdate()
	node:enableKeyPad()
	node:setTouchEnabled(false)
	return node
end
function FloatNode:enabledUpdate()
	local function update(delta)
		--SDK回调事件处理
		self:handleEvent()
		--socket心跳
		self:heartBeating(delta)
		--客户端数据回复
		AcctManager:update()
		--防止用户直接修改动画播放速度
		SpeedManager:check()
		--通讯数据监听
		self:handleMsg()
		if SceneManager:getRunningScene():className() == "TownScene" then
			self._flagmsgnode:show()
		end
	end
	local function callback(eventType)
        if eventType == "enter" then
            self._eghandler = CCDirector:sharedDirector():getScheduler():scheduleScriptFunc(update, 0, false)
			self:unregisterScriptKeypadHandler()
        end
    end
	self:registerScriptHandler(callback)
	self:onEnter()
end

function FloatNode:addEventListener(eventname,eventcallback)
		self._event[eventname] = eventcallback
	end
function FloatNode:enableKeyPad()
	local function onLogoutGameCallBack()
		SDKHelper:destroy()
		NotifyHelper.start()
		CCDirector:sharedDirector():endToLua()
	end
	local function onExitGameCallback()
		if SDKConfig.needLogOut() then
			SDKHelper:logOut()
		else
			onLogoutGameCallBack()
		end
	end
	local function onContinueGameCallBack()
		if self:getChildByTag(999) then
			self:removeChildByTag(999,true)
		end
	end
	--平台登陆失败
	local function onLoginErrorCallback(msg)
		local function callback1()
			 SDKHelper:clearUID()
			 SDKHelper:login()
		end
		local function callback2()
			SDKHelper:destroy()
			NotifyHelper.start()
			CCDirector:sharedDirector():endToLua()
		end
		ConfirmBox.show(TxtList.reOpenLogin,callback1,callback2)
	end
	--监听切换账号登陆成功
	local function onSwitchingAccountCallback(msg)
		SDKHelper:saveUID()
		SocketHelper.clearDSConn()
		SocketHelper.clearGSConn()
		SendQueue:clearQueue()
		AcctManager:clear()
		SceneManager:show(LogoScene)
	end
	--切换账号登陆失败
    local function onSwitchingAccountFailedCallback(msg)
		SDKHelper:clearUID()
		SocketHelper.clearDSConn()
		SocketHelper.clearGSConn()
		SendQueue:clearQueue()
		AcctManager:clear()
		SceneManager:show(LogoScene)
	end
	--重复登陆
	local function onReLoginCallback(msg)
		local function callback1()
			SceneManager:show(LogoScene)
		end
		local function callback2()
			SDKHelper:destroy()
			NotifyHelper.start()
			CCDirector:sharedDirector():endToLua()
		end
		SocketHelper.clearGSConn()
		SendQueue:clearQueue()
		AcctManager:clear()
		ConfirmBox.show(TxtList.reLogin,callback1,callback2)
	end
	self:addEventListener(CLTEvent.LoginError,onLoginErrorCallBack)
	self:addEventListener(CLTEvent.SwitchingAccount,onSwitchingAccountCallBack)
	self:addEventListener(CLTEvent.SwitchingAccountFailed,onSwitchingAccountFailedCallback)
	self:addEventListener(CLTEvent.CReLogin,onReLoginCallback)
	self:addEventListener(CLTEvent.LogOutSucceed,onLogoutGameCallBack)
	self:addEventListener(CLTEvent.LogOutError,onLogoutGameCallBack)
	self:addEventListener(CLTEvent.ExitGame,onExitGameCallback)
	self:addEventListener(CLTEvent.ContinueGame,onContinueGameCallBack)
	local function callback(eventType)
		if eventType == "backClicked" then
			self:setKeypadEnabled(false)
		   --if SceneManager:getRunningScene():className() == "LogoScene" then return end
		   if not SDKConfig.hasQuitLayer() then --没有自带的退出界面时,使用默认退出界面
				if not self:getChildByTag(999) then --退出界面对应Tag值固定为999
					local layer = QuitLayer.new()
					self:addChild(layer,999,999)	
					layer:showWithAction()
				else
					self:removeChildByTag(999,true)
				end
			end
			self:setKeypadEnabled(true)
		end
	end
	self:setKeypadEnabled(true)
	self:registerScriptKeypadHandler(callback)
end

function FloatNode:handleEvent()
	if PlugInHelper:hasEvent() then
		local eventName,params = PlugInHelper:popEvent()
		print(eventName,params)
		if self._event[eventName] then self._event[eventName](params)
		else print("there is no callback binded for event "..eventName) end
	end
end
--发送心跳,保持连接
function FloatNode:heartBeating(delta)
	if self._beatCounter <= 0 then
		if self._sleeping then
			--超时逻辑
			SocketHelper.clearGSConn() --接收超时,断开连接
			self._sleeping = false
			SceneManager:show(LogoScene)
		else
			if numDef then
				self._beatCounter = numDef.beatInterval or 10
			else
				self._beatCounter = 10
			end
			self._sleeping = true
			SendMsg[930000]()
		end
	else 
		self._beatCounter = self._beatCounter - delta
	end
end
function FloatNode.manualBeat()
	local node = FloatNode.getInstance()
	if numDef then
		node._beatCounter = numDef.beatInterval or 10
	else
		node._beatCounter = 10
	end
	node._sleeping = true
	SendMsg[930000]()
end
--接收并处理通讯数据
function FloatNode:handleMsg()
	if RecvQueue:hasError() or SendQueue:hasError() then
		local isDsConnected = SocketHelper.isDSConnecting()
		SocketHelper.clearDSConn()
		SocketHelper.clearGSConn()
		SendQueue:clearQueue()
		AcctManager:clear()
		if isDsConnected then
			MessageBox.show(TxtList.connFailed,LogoScene)
		else
			SceneManager:show(LogoScene)
		end
	else
		RecvMsg()
	end
end
--将FloatNode对象添加到Cocos2dx的NotificationNode对象
function FloatNode.show()
	--先删除之前的对象
	if FloatNodeIns then
		FloatNodeIns:unregisterScriptKeypadHandler()
		if FloatNodeIns._eghandler  then
			CCDirector:sharedDirector():getScheduler():unscheduleScriptEntry(FloatNodeIns._eghandler)
		end
	end
	FloatNodeIns = nil
	CCDirector:sharedDirector():setNotificationNode(FloatNode.getInstance())
end

--获取FloatNode实例
function FloatNode.getInstance()
	if not FloatNodeIns then
		FloatNodeIns = FloatNode:create()
	end
	return FloatNodeIns
end
function FloatNode.wakeUp()
	local node = FloatNode.getInstance()
	node._sleeping = false
end
function FloatNode.bindEvent(eventname,eventcallback)
	local node = FloatNode.getInstance()
	node:addEventListener(eventname,eventcallback)
end
function FloatNode.unbindEvent(eventname)
	local node = FloatNode.getInstance()
	node._event[eventname] = nil
end
function FloatNode.clearEvent()
	local node = FloatNode.getInstance()
	node._event = {}
end
function FloatNode.pushLayer(layer)
	local node =  FloatNode.getInstance()
	if not node._layerList then node._layerList={} end
	table.insert(node._layerList,layer)
	local tag = #node._layerList + 100
	layer:setTouchPriority(-tag + node._priority )
	node:addChild(layer,tag,tag)	
end

function FloatNode.popLayer()
	local node =  FloatNode.getInstance()
	if not node._layerList then return end
	local tag = #node._layerList + 100
	if node:getChildByTag(tag) then
		node:removeChildByTag(tag,true)
	end
	table.remove(node._layerList,tag)	
end
--========================
--扁平消息显示控制 start
--========================
function FloatNode.addFlatMsg(flag,msg,cnt,showtime,intv)
	local node =  FloatNode.getInstance()
	if node._flagmsgnode then
		node._flagmsgnode:add(flag,msg,cnt,showtime,intv)
	end
end
function FloatNode.clearFlatMsg(flag)
	local node =  FloatNode.getInstance()
	if node._flagmsgnode then
		node._flagmsgnode:clearByType(flag)
	end
end
--========================
--扁平消息显示控制 end
--========================
